//请求模拟数据

exports.getData={type:'get'}; 
exports.putData={type:'put'}; 
exports.postData={type:'post'}; 
