var express = require('express')
  , app = express()
  , fixtures = require('./fixtures');


var allowOrigin = function (req, res, next) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "X-Requested-With");
  next();
};

// global setup
app.configure(function () {
  app.set('port', process.env.PORT || 19000);
  app.use(express.favicon());
  app.use(express.logger('dev'));
  app.use(express.bodyParser());
  app.use(express.methodOverride());
  app.use(allowOrigin);
  app.use(app.router);
});

// setup for development
app.configure('development', function () {
  app.use(express.errorHandler());
});

// server listening
app.listen(app.get('port'), function () {
  console.log('server listening on port ' + app.get('port'));
})


//========================================================================================

//get请求示例
app.get('/resources/get',function(req,res){	
     res.send(fixtures.getData);
});

//put请求示例
app.put('/resources/put',function(req,res){
	var app = req.body;
    res.send(fixtures.putData);
});


//post请求示例
app.post('/resources/post',function(req,res){
	var siteApplication = req.body;
    res.send(fixtures.postData);
});






