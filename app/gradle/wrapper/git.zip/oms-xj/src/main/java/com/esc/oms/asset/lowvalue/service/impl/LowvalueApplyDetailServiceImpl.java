package com.esc.oms.asset.lowvalue.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.asset.lowvalue.dao.ILowvalueApplyDao;
import com.esc.oms.asset.lowvalue.dao.ILowvalueApplyDetailDao;
import com.esc.oms.asset.lowvalue.service.ILowvalueInfoService;
import com.esc.oms.asset.lowvalue.service.ILowvalueApplyDetailService;
import com.esc.oms.util.RoleUtils;
import com.esc.oms.util.TaskModel;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;

@Service
@Transactional
public class LowvalueApplyDetailServiceImpl extends BaseOptionService implements ILowvalueApplyDetailService{

	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private ILowvalueApplyDetailDao dao;
	
	@Resource
	private ILowvalueInfoService infoService;
	
	@Resource
	private ILowvalueApplyDao applyDao;

	@Resource
	private MessageSend messageService;
	
	@Resource
	private IUserTaskService userTaskService;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return dao;
	}

	/**
	 * 添加
	 * @param info
	 * @return
	 */
	@EscOptionLog(module=SystemModule.ASSETS_LOWVALUE_APPLY, opType=ESCLogOpType.INSERT, table="assets_lowvalue_apply_detail", primaryKey="id={1.id}",option="新增申请物品：{1.name}/{1.code}")	
	public boolean add(Map info){
		String infoId = (String) info.get("infoId");
		
		Map infoMap = new HashMap<String,Object>();
		infoMap.put("id", info.get("infoId"));
		infoMap.put("status", "1");
		infoService.updateById(infoMap);
		
		return super.add(info);		
	}
	
	@Override
	@EscOptionLog(module=SystemModule.ASSETS_LOWVALUE_APPLY, opType=ESCLogOpType.UPDATE, table="assets_lowvalue_apply_detail", primaryKey="id={1.id}",option="修改申请的物品：{1.name}/{1.code}")	
	public boolean updateById(Map info){
		return super.updateById(info);			
	}
	
	@Override
	@EscOptionLog(module=SystemModule.ASSETS_LOWVALUE_APPLY, opType=ESCLogOpType.DELETE, table="assets_lowvalue_apply_detail",primaryKey="{1}",option="物品申请详单中，删除物品：{name}/{code}")			
	public boolean deleteById(String id){			
		return super.deleteById(id);			
	}
	
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map param) {
		dao.getPageInfo(pageBean, param);
	}
	
	@Override
	@EscOptionLog(module=SystemModule.ASSETS_LOWVALUE_APPLY, opType=ESCLogOpType.GRANT, table="assets_lowvalue_apply_detail", primaryKey="id={1.id}",option="物品申请的{name}/{code}物品发放")	
	public boolean grant(Map info) {
		//更新待确认数量
		String strConfirmStatus = info.get("confirmStatus") == null?"":String.valueOf(info.get("confirmStatus"));
		if("-1".equals(strConfirmStatus)){//驳回或已发放待确认
			//更新待确认数量		
//			Map<String,Object> oldGrant = getById((String) info.get("id"));
//			double oldGrantNum = Double.parseDouble(oldGrant.get("grantNum")==null?"0":oldGrant.get("grantNum").toString()); //原领用数量
			double grantNum = Double.parseDouble(info.get("grantNum")==null?"0":info.get("grantNum").toString()); //领用数量
			
			Map<String,Object> oldInfo = infoService.getById((String) info.get("infoId"));
			double oldNum = Double.parseDouble(oldInfo.get("pendConfirmNum")==null?"0":oldInfo.get("pendConfirmNum").toString()); //原待确认数量
			Map infoMap = new HashMap<String,Object>();	
			infoMap.put("pendConfirmNum", oldNum+grantNum);
			infoMap.put("id", oldInfo.get("id"));
			infoService.updateById(infoMap);
			
		}else if("2".equals(strConfirmStatus)){
			//更新待确认数量		
			Map<String,Object> oldGrant = getById((String) info.get("id"));
			double oldGrantNum = Double.parseDouble(oldGrant.get("grantNum")==null?"0":oldGrant.get("grantNum").toString()); //原领用数量
			double grantNum = Double.parseDouble(info.get("grantNum")==null?"0":info.get("grantNum").toString()); //领用数量
			if(oldGrantNum!=grantNum){
				Map<String,Object> oldInfo = infoService.getById((String) info.get("infoId"));
				double oldNum = Double.parseDouble(oldInfo.get("pendConfirmNum")==null?"0":oldInfo.get("pendConfirmNum").toString()); //原待确认数量
				Map infoMap = new HashMap<String,Object>();	
				infoMap.put("pendConfirmNum", oldNum-oldGrantNum+grantNum);
				infoMap.put("id", oldInfo.get("id"));
				infoService.updateById(infoMap);
			}
		}else if("1".equals(strConfirmStatus)){//待发放
			//更新待确认数量
			Map infoMap = new HashMap<String,Object>();
			infoMap.put("id", info.get("infoId"));
			UTMap<String,Object> oldMap = infoService.getById((String) info.get("infoId"));
			double oldNum = Double.parseDouble(oldMap.get("pendConfirmNum")==null?"0":oldMap.get("pendConfirmNum").toString()); //原待确认数量
			double grantNum = Double.parseDouble(info.get("grantNum")==null?"0":info.get("grantNum").toString()); //领用数量
			infoMap.put("pendConfirmNum", oldNum+grantNum);
			infoService.updateById(infoMap);
			
		}
		
		info.put("confirmStatus", "2");
		super.updateById(info);	
		
		String applyId = (String) info.get("applyId");
		Map<String,Object> param = new HashMap<String,Object>();
		param.put("applyId", applyId);
			
		List<UTMap<String,Object>> list = this.getListMaps(param);
		boolean completeConfirm = true;
		if(list!=null&&list.size()>0){
			for(UTMap<String,Object> ut : list){
				int confirmStatus = (Integer) ut.get("confirmStatus");
				if(confirmStatus!=2 && confirmStatus!=3){
					completeConfirm = false;
				}
			}
		}
		if(completeConfirm){		
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("id", applyId);
			map.put("status", ILowvalueApplyDao.STATUS_PEND_CONFIRM);
			applyDao.updateById(map);
			
			UTMap<String,Object> applyMap = applyDao.getById(applyId);
			String taskUserIds = (String) applyMap.get("applyUserId");
			//发送消息			
			String title = "物品申请【"+applyMap.get("name")+"/"+applyMap.get("code")+"】确认提醒";
			String content = "物品申请：【"+applyMap.get("name")+"/"+applyMap.get("code")+"】已发放，请在系统进行确认！";
			messageService.sendMessage(taskUserIds,title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
			
			//关闭待办任务
			userTaskService.finishTask(applyId, ILowvalueApplyDao.TASK_LOWVALUE_GRANT);
			
			//生成待办任务
			Map<String,Object> dataParam = new HashMap<String,Object>();
			//点击待办事项，打开申请列表tab
			dataParam.put("dataType", "0");
			userTaskService.addTaskByUserId("物品申请【"+applyMap.get("name")+"】已发放待您确认", applyId, ILowvalueApplyDao.TASK_LOWVALUE_CONFIRM, TaskModel.lowvalueApply,taskUserIds,dataParam);
			
		}else{
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("id", applyId);
			map.put("status", ILowvalueApplyDao.STATUS_GRANTING);
			applyDao.updateById(map);
		}		
		return true;
	}
	
	/**
	 * 确认
	 * @param info
	 * @return
	 */
	@Override
	@EscOptionLog(module=SystemModule.ASSETS_LOWVALUE_APPLY, opType=ESCLogOpType.CONFIRM, table="assets_lowvalue_apply_detail", primaryKey="id={1.id}",option="物品申请的{1.name}/{1.code}物品发放确认")		
	public boolean confirm(Map info){
		info.put("confirmTime", UTDate.getCurDateTime());
		info.put("confirmStatus", "3");
		super.updateById(info);	
		
		//更新库存
		String infoId = (String) info.get("infoId");
		double grantNum = Double.parseDouble(info.get("grantNum").toString());
		Object obj = info.get("grantAmount");
		double grantAmount = 0;
		if(obj!=null){
			grantAmount = Double.parseDouble(info.get("grantAmount").toString());
		}else{
			Object pobj = info.get("price");
			Double price = Double.parseDouble(pobj==null?"0":pobj.toString());
			grantAmount = grantNum * price;
		}
		
		updateStock(infoId,grantNum,grantAmount);
		
		String applyId = (String) info.get("applyId");
		Map<String,Object> param = new HashMap<String,Object>();
		param.put("applyId", applyId);
		List<UTMap<String,Object>> list = this.getListMaps(param);
		boolean completeConfirm = true;
		if(list!=null&&list.size()>0){
			for(UTMap<String,Object> ut : list){
				int confirmStatus = (Integer) ut.get("confirmStatus");
				if(confirmStatus!=3){
					completeConfirm = false;
				}
			}
		}
		if(completeConfirm){		
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("id", applyId);
			map.put("status", ILowvalueApplyDao.STATUS_FINISH);
			applyDao.updateById(map);
							
//			//更新库存
//			for(UTMap<String,Object> ut : list){				
//				String infoId = (String) info.get("infoId");
//				double grantNum = Double.parseDouble(info.get("grantNum").toString());
//				double grantAmount = Double.parseDouble(info.get("grantAmount").toString());
//				updateStock(infoId,grantNum,grantAmount);
//			}
			
			//关闭待办任务
			userTaskService.finishTask(applyId, ILowvalueApplyDao.TASK_LOWVALUE_CONFIRM);
			
		}else{
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("id", applyId);
			map.put("status", ILowvalueApplyDao.STATUS_CONFIRMING);
			applyDao.updateById(map);
		}
		return true;
	}
	
	//更新库存
	private void updateStock(String infoId,double grantNum,double grantAmount){
		Map<String,Object> infoMap = infoService.getById(infoId);
		double oldNum = Double.parseDouble(infoMap.get("totalNum")==null?"0":infoMap.get("totalNum").toString()); //总数量
		double oldAmount = Double.parseDouble(infoMap.get("amount")==null?"0":infoMap.get("amount").toString()); //总价
		double oldStockNum = Double.parseDouble(infoMap.get("stockNum")==null?"0":infoMap.get("stockNum").toString()); //库存数量
		double oldStockAmount = Double.parseDouble(infoMap.get("stockAmount")==null?"0":infoMap.get("stockAmount").toString());  //库存总价
		double oldPendConfirmNum = Double.parseDouble(infoMap.get("pendConfirmNum")==null?"0":infoMap.get("pendConfirmNum").toString());  //待确认数
		
		double totalNum = oldNum;
		double amount = oldAmount;
		double stockNum = oldStockNum-grantNum;
		double stockAmount = oldStockAmount-grantAmount;
		double consumeNum = totalNum-stockNum;
		double consumeAmount = amount-stockAmount;
		double pendConfirmNum = oldPendConfirmNum-grantNum;
		
		infoMap.put("totalNum", totalNum);
		infoMap.put("amount", amount);
		infoMap.put("stockNum", stockNum);
		infoMap.put("stockAmount", stockAmount);
		infoMap.put("consumeNum", consumeNum);
		infoMap.put("consumeAmount", consumeAmount);
		infoMap.put("pendConfirmNum", pendConfirmNum);
		
		infoService.updateById(infoMap);
	}
	
	
	@Override
	@EscOptionLog(module=SystemModule.ASSETS_LOWVALUE_APPLY, opType=ESCLogOpType.REJECT, table="assets_lowvalue_apply_detail", primaryKey="id={1.id}",option="物品申请的{1.name}/{1.code}物品驳回")			
	public boolean reject(Map info) {
		info.put("confirmStatus", "-1");
		super.updateById(info);	
		
		String applyId = (String) info.get("applyId");
//		Map<String,Object> param = new HashMap<String,Object>();
//		param.put("applyId", applyId);
//		List<UTMap<String,Object>> list = this.getListMaps(param);
//		boolean completeConfirm = true;
//		if(list!=null&&list.size()>0){
//			for(UTMap<String,Object> ut : list){
//				int confirmStatus = (Integer) ut.get("confirmStatus");
//				if(confirmStatus!=2){
//					completeConfirm = false;
//				}
//			}
//		}
//		if(completeConfirm){		
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("id", applyId);
			map.put("status", ILowvalueApplyDao.STATUS_GRANT_REJECT);
			
			applyDao.updateById(map);
//		}else{
//			Map<String,Object> map = new HashMap<String,Object>();
//			map.put("id", applyId);
//			map.put("status", "4");
//			applyDao.updateById(map);
//		}		
		//更新待确认数
		String infoId = (String) info.get("infoId");
		double grantNum = Double.parseDouble(info.get("grantNum")==null?"0":info.get("grantNum").toString());  //发放数
		double oldPendConfirmNum = Double.parseDouble(info.get("pendConfirmNum")==null?"0":info.get("pendConfirmNum").toString());  //待确认数

		double newPendConfirmNum = oldPendConfirmNum-grantNum;  //待确认数
		Map<String,Object> infoMap = new HashMap<String,Object>();
		infoMap.put("id", infoId);
		infoMap.put("pendConfirmNum", newPendConfirmNum);
		infoService.updateById(infoMap);
		
		return true;
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params){
		return dao.getListAll(params);
	}
	
	/**
	 * 根据领用记录的条件查询领用详单
	 * @param params
	 */
	@Override
	public List<UTMap<String, Object>> getListAllByParentParam(Map params){
		return dao.getListAllByParentParam(params);
	}
	
	/**
	 * 根据领用记录id（applyId）删除
	 * @param infoId
	 * @return
	 */
	@Override
	public boolean deleteByApplyId(String applyId){
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("applyId", applyId);
		return dao.deletes(map);
	}	

}