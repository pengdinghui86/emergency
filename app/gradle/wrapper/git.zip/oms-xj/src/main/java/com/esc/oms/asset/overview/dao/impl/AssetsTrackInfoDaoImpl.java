package com.esc.oms.asset.overview.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.asset.overview.dao.IAssetsTrackInfoDao;
@Repository
public class AssetsTrackInfoDaoImpl extends BaseOptionDao implements IAssetsTrackInfoDao{
	
	@Override
	public String getTableName() {
		return "assets_track_info";
	}
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params,false), pageBean, null);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params) {
		return super.getListBySql(getSearchSql(params,false), null);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListMaps(Map params) {
		return super.getListBySql(getSearchSql(params,false), null);
	}

	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params,boolean isGetById){
		StringBuilder sql = new StringBuilder();
		sql.append(" select info.*,concat(info.assetsName, IF(assetsCode is null or assetsCode='', '', concat('/', assetsCode))) nameCode from assets_track_info info ");
		sql.append(" where 1=1 ");
		if(params!=null && params.size()>0){		
			if(params.get("startDate")!=null &&  StringUtils.isNotEmpty(params.get("startDate").toString())){
				sql.append(" and DATE_FORMAT(info.changeTime,'%Y-%m-%d')>='"+params.get("startDate").toString().trim()+"' ");
			}
			if(params.get("endDate")!=null && StringUtils.isNotEmpty(params.get("endDate").toString())){
				sql.append(" and DATE_FORMAT(info.changeTime,'%Y-%m-%d')<='"+params.get("endDate").toString().trim()+"' ");
			}
			if(params.get("assetsId")!=null &&  StringUtils.isNotEmpty(params.get("assetsId").toString())){
				sql.append(" and assetsId ='"+params.get("assetsId").toString().trim()+"' ");
			}
		}
		sql.append(" order by info.createTime desc");
		return  sql.toString();
	}
}
