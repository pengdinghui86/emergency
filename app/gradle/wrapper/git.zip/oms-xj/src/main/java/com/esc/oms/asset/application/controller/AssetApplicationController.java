package com.esc.oms.asset.application.controller;

import com.esc.oms.asset.allocation.service.IAssetAllocationlService;
import com.esc.oms.asset.application.service.IAssetApplicationService;
import com.esc.oms.asset.collar.service.IAssetCollarService;
import com.esc.oms.asset.overview.dao.IAssetsTrackInfoDao;
import com.esc.oms.asset.overview.service.IAssetsTrackInfoService;
import com.esc.oms.asset.physical.service.IAssetPhysicalService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ExcelUtil;
import com.esc.oms.util.FunctionEnum.AssetRepairApplyType;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.esc.framework.workflow.service.IWorkflowEngine;
import org.esc.framework.workflow.service.impl.WorkflowInstanceDiagramImpl;
import org.esc.framework.workflow.utils.bpmn.Instance;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
@Controller
@RequestMapping("assetApplication")
public class AssetApplicationController extends BaseOptionController {


	@Resource
	private IAssetApplicationService assetApplicationService;
	
	@Resource
	private IAssetPhysicalService assetPhysicalService;
	
	@Resource
	private ISysUserService sysUserService;
	
	@Resource
	private IAssetsTrackInfoService assetsTrackInfoService;
	
	@Resource
	private IAssetAllocationlService assetAllocationlService;
	
	@Resource
	private IUserTaskService userTaskService;
	
	@Resource
	private IAssetCollarService assetCollarService;
	
	@Resource
	private WorkflowInstanceDiagramImpl processInstanceDiagramCmd;
	
	@Resource
	private IWorkflowEngine workflowEngine;
	
	@Override
	public IBaseOptionService optionService() {
		return assetApplicationService;
	}
	

	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			assetApplicationService.getPageInfo(pageBean, params);
			List<Map<String, Object>> list = pageBean.getRows();
			if(null != list && list.size() > 0 ){
				for (Map<String, Object> map : list) {
					if("BM".equals((String)map.get("applyType"))){
						map.put("applyType", "部门");
					}else{
						map.put("applyType", "个人");
					}
				}
			}
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	
	@RequestMapping(value="save", method=RequestMethod.POST)  
    @ResponseBody
    public Map<String, Object> save(@RequestBody Map<String,Object> map1) {
		Map<String, Object> map = CommonUtils.clone(map1);
		try {
			String id = assetApplicationService.save(map);
			map.put("success", true);
			map.put("id", id);
			map.put("msg", "操作成功！");
		}
		catch (Exception e) {
			logger.error("Exception", e);
			map.put("success", false);
			map.put("msg", "操作失败！");
		}
		
		return map;
	}
	
	@RequestMapping(value="finishRejectTask", method=RequestMethod.POST)  
    @ResponseBody
    public void finishRejectTask(@RequestBody Map<String,Object> map) {
		assetApplicationService.finishRejectTask(map.get("id").toString());
	}
	
	/**
	 * 提交审批
	 * @param map
	 * @return
	 */
	@RequestMapping(value="submit", method=RequestMethod.POST)  
    @ResponseBody
    public Map<String, Object> submit(@RequestBody Map<String,Object> map1) {
		Map<String, Object> coloneParam = CommonUtils.clone(map1);
		try{
			String id = assetApplicationService.submit(coloneParam);
			coloneParam.put("success", true);
			coloneParam.put("id", id);
			coloneParam.put("msg", "操作成功！");
		}catch(EscServiceException e) {
			logger.error("EscServiceException", e);
			coloneParam.put("success", false);
			coloneParam.put("msg", e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		coloneParam.put("success", false);
    		coloneParam.put("msg", "操作失败！");
    	}
       return coloneParam;
	}

    
    /**
	 * 根据id查询
	 * @param param
	 * @return
	 */
	@RequestMapping(value="getById")
	@ResponseBody
	public UTMap<String, Object> defgetById(@RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = null;
    	try{
    		map = optionService().getById(param.get("id").toString());
    		if(null != map){
    			List<UTMap<String, Object>> subCategoryList = assetAllocationlService.getSubCategoryByParentId(String.valueOf(map.get("category")));
    			map.put("subCategoryList", subCategoryList);
    		}
    		
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return map;
	}
	
	/**
	 * 领用确认导出
	 * @param param
	 * @return
	 */
	@RequestMapping(value="exportByData")
	@ResponseBody
	public void exportByData(HttpServletRequest request, HttpServletResponse response, @RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = new UTMap<String, Object>();
		List<UTMap<String,Object>> assetIssueList = new ArrayList<UTMap<String, Object>>();
		List<UTMap<String,Object>> list = new ArrayList<UTMap<String, Object>>();
		
    	try{
    		if(null != param.get("appId")){
    			map = optionService().getById((String)param.get("appId"));
    			if(null != map){
    				List<UTMap<String, Object>> subCategoryList = assetAllocationlService.getSubCategoryByParentId(String.valueOf(map.get("category")));
	    			map.put("subCategoryList", subCategoryList);
	    			String applyTypeName = AssetRepairApplyType.getName(map.get("applyType").toString());
    				map.put("applyTypeName", applyTypeName);
    			}
    			assetIssueList = assetApplicationService.getAssetListByAppId(param);
    			
    			if (null != assetIssueList && !assetIssueList.isEmpty()) {
    				for (Map<String, Object> item : assetIssueList) {
    					if((Integer)item.get("status") == 7){
    						item.put("status", "已确认");
    					}else{
    						item.put("status", "未确认");
    					}
    				}
    			}
    			
    			String applyId = param.get("appId").toString();
    			String workflowCode = "physical_asset_apply";
    			response.setCharacterEncoding("UTF-8");
        		response.setContentType("application/vnd.ms-excel");
    			String fileName = "资产申请记录.xls";
    			fileName = URLEncoder.encode(fileName, "UTF-8");
    			response.addHeader("Content-Disposition", "attachment;filename=" + fileName);
    			
/*    	        ExcelUtil excelUtil = new ExcelUtil();
    	        excelUtil.exportProcessImageAndInfo(workflowEngine, processInstanceDiagramCmd, workflowCode, applyId, wb);*/
    			
    	        //流程审批信息
    	        Instance instance = workflowEngine.getInstance(workflowCode, applyId);
    	        List<Object[]> instanceList = new ArrayList<Object[]>();
    	        if (instance != null) {
    	            instance.setAuditInfoList(workflowEngine.getShowAuditInfoList(instance.getInstanceId()));
    	            List<UTMap<String, Object>> maps = workflowEngine.getShowAuditInfoList(instance.getInstanceId());
    	            for(UTMap<String, Object> map2 : maps)
    	            {
    	            	Object[] objs = new Object[5];
    	    	        objs[0] = map2.get("nodeName")==null? "" : map2.get("nodeName").toString();
    	    	        objs[1] = map2.get("createUser")==null? "" : map2.get("createUser").toString();
    	    	        objs[2] = map2.get("createTime")==null? "" : map2.get("createTime").toString();
    	    	        objs[3] = map2.get("auditResult")==null? "" : map2.get("auditResult").toString();
    	    	        objs[4] = map2.get("auditComment")==null? "" : map2.get("auditComment").toString();
    	    	        instanceList.add(objs);
    	            }
    	        }
    	        //创建一个表格
    			HSSFWorkbook wb = new HSSFWorkbook();
    			exportAssetApply(wb, map, assetIssueList, instanceList);
    	        
    			/*list = assetApplicationService.getAssetIssuePageInfo(param);
    			if(null != list && list.size() > 0 ){
    				for (Map<String, Object> item : list) {
    					if((Integer)item.get("status") == 7){
    						item.put("status", "已确认");
    					}else{
    						item.put("status", "未确认");
    					}
    				}
    			}*/
    			/*exportAssetGrant(wb, list);
    			exportAssetReceive(wb, list);*/
    		
    			try {
					OutputStream out = response.getOutputStream();
	    			wb.write(out);
	    			out.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

    		}
    		
    		
		}catch(Exception e){
			logger.error("Exception", e);
    	}
	}
	
	private void exportAssetApply(HSSFWorkbook wb, UTMap<String, Object> map, List<UTMap<String,Object>> assetIssueList, List<Object[]> instanceList) 
	{
        String sheetName = "资产申请";
        //定义表的内容
        List<Object[]> dataList = new ArrayList<Object[]>();
        Object[] objs = new Object[5];
        objs[0] = map.get("title")==null? "" : map.get("title").toString();
        objs[1] = map.get("applyTypeName")==null? "" : map.get("applyTypeName").toString();
        objs[2] = map.get("applyUnitName")==null? "" : map.get("applyUnitName").toString();
        objs[3] = map.get("reason")==null? "" : map.get("reason").toString();
        objs[4] = map.get("remark")==null? "" : map.get("remark").toString();
        dataList.add(objs);
        
        String[] rowsName1 = new String[] { "序号", "资产名称", "型号", "存放地点", "所属部门", "设备负责人","发放人", "发放时间", "状态"};
        //定义表的内容
        List<Object[]> dataList1 = new ArrayList<Object[]>();
        for(UTMap<String, Object> item : assetIssueList)
        {
	        Object[] objs1 = new Object[8];
	        objs1[0] = item.get("assetsNameCode")==null? "" : item.get("assetsNameCode").toString();
	        objs1[1] = item.get("model")==null? "" : item.get("model").toString();
	        objs1[2] = item.get("location")==null? "" : item.get("location").toString();
	        objs1[3] = item.get("resDepartId")==null? "" : item.get("resDepartId").toString();
	        objs1[4] = item.get("resUserId")==null? "" : item.get("resUserId").toString();
	        objs1[5] = item.get("grantUserId")==null? "" : item.get("grantUserId").toString();
	        objs1[6] = item.get("grantTime")==null? "" : item.get("grantTime").toString().
	        		substring(0, item.get("grantTime").toString().indexOf(" ") > -1 ? item.get("grantTime")
	        		.toString().indexOf(" ") : item.get("grantTime").toString().length());
	        objs1[7] = item.get("status")==null? "" : item.get("status").toString();
	        dataList1.add(objs1);
        }
        
        String[] rowName2 = new String[] { "序号", "节点", "提交人", "提交时间", "审批结果", "审批意见" };
        // 创建ExportExcel对象
        ExcelUtil excelUtil = new ExcelUtil();
        try{
            excelUtil.exportAssetApply(sheetName, "资产申请单", dataList, wb);
            excelUtil.exportAssetApplyList(sheetName, "资产列表", rowsName1, dataList1, wb, 7, false);
            int startIndex = 10 + dataList1.size() + 1;
            excelUtil.exportAssetApplyInstance(sheetName, "流程详情", rowName2, instanceList, wb, startIndex, false);
        }catch(Exception e){
            e.printStackTrace();
        }
	}
	
/*	private void exportAssetGrant(HSSFWorkbook wb, List<UTMap<String, Object>> maps) 
	{
        String sheetName = "资产发放";
        //定义表的列名
        String[] rowsName = new String[] { "序号", "资产", "资产类别", "资产级别", "发放人", "发放时间" };
        //定义表的内容
        List<Object[]> dataList = new ArrayList<Object[]>();
        for(UTMap<String, Object> map : maps) 
        {
	        Object[] objs = new Object[5];
	        objs[0] = map.get("assetsId")==null? "" : map.get("assetsId").toString();
	        objs[1] = map.get("category")==null? "" : map.get("category").toString();
	        objs[2] = map.get("subCategory")==null? "" : map.get("subCategory").toString();
	        objs[3] = map.get("grantUserId")==null? "" : map.get("grantUserId").toString();
	        String grantTime = "";
	        if(map.get("grantTime")!=null)
	        {
	        	grantTime = CommonUtils.transferDateFormat(map.get("grantTime").toString());
	        	if(grantTime.equals(""))
	        		grantTime = map.get("grantTime").toString();
	        }
	        objs[4] = grantTime;
	        dataList.add(objs);
        }
        // 创建ExportExcel对象
        ExcelUtil excelUtil = new ExcelUtil();
        try{
            excelUtil.export(sheetName, sheetName, rowsName, dataList, wb, 0, true);
        }catch(Exception e){
            e.printStackTrace();
        }
	}
	
	private void exportAssetReceive(HSSFWorkbook wb, List<UTMap<String, Object>> maps) 
	{
        String sheetName = "领用确认";
        //定义表的列名
        String[] rowsName = new String[] { "序号", "资产", "资产类别", "资产级别", "发放人", "发放时间", "状态" };
        //定义表的内容
        List<Object[]> dataList = new ArrayList<Object[]>();
        for(UTMap<String, Object> map : maps) 
        {
	        Object[] objs = new Object[6];
	        objs[0] = map.get("assetsId")==null? "" : map.get("assetsId").toString();
	        objs[1] = map.get("category")==null? "" : map.get("category").toString();
	        objs[2] = map.get("subCategory")==null? "" : map.get("subCategory").toString();
	        objs[3] = map.get("grantUserId")==null? "" : map.get("grantUserId").toString();
	        String grantTime = "";
	        if(map.get("grantTime")!=null)
	        {
	        	grantTime = CommonUtils.transferDateFormat(map.get("grantTime").toString());
	        	if(grantTime.equals(""))
	        		grantTime = map.get("grantTime").toString();
	        }
	        objs[4] = grantTime;
	        objs[5] = map.get("status")==null? "" : map.get("status").toString();
	        dataList.add(objs);
        }
        // 创建ExportExcel对象
        ExcelUtil excelUtil = new ExcelUtil();
        try{
            excelUtil.export(sheetName, sheetName, rowsName, dataList, wb, 0, true);
        }catch(Exception e){
            e.printStackTrace();
        }
	}*/
	
	/**
	 * 打印预览
	 */
	@RequestMapping(value="printById")
	@ResponseBody
	public Map<String, Object> printById(@RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = new UTMap<String, Object>();
		UTMap<String, Object> result = new UTMap<String, Object>();
		List<UTMap<String,Object>> assetIssueList = new ArrayList<UTMap<String, Object>>();
		
    	try{
    		if(null != param.get("appId")){
    			map = optionService().getById((String)param.get("appId"));
    			if(null != map){
    				List<UTMap<String, Object>> subCategoryList = assetAllocationlService.getSubCategoryByParentId(String.valueOf(map.get("category")));
	    			map.put("subCategoryList", subCategoryList);
	    			String applyTypeName = AssetRepairApplyType.getName(map.get("applyType").toString());
    				map.put("applyTypeName", applyTypeName);
    			}
    			assetIssueList = assetApplicationService.getAssetListByAppId(param);
    			
    			if (null != assetIssueList && !assetIssueList.isEmpty()) {
    				for (Map<String, Object> item : assetIssueList) {
    					if((Integer)item.get("status") == 7){
    						item.put("status", "已确认");
    					}else{
    						item.put("status", "未确认");
    					}
    				}
    			}
    			
    			String applyId = param.get("appId").toString();
    			String workflowCode = "physical_asset_apply";
    	        //流程审批信息
    	        Instance instance = workflowEngine.getInstance(workflowCode, applyId);
    	        List<UTMap<String, Object>> maps = new ArrayList<>();
    	        if (instance != null) {
    	            instance.setAuditInfoList(workflowEngine.getShowAuditInfoList(instance.getInstanceId()));
    	            maps = workflowEngine.getShowAuditInfoList(instance.getInstanceId());   	       
    	        }
    	        result.put("applyInfo", map);
     	        result.put("assetsList", assetIssueList);
     	        result.put("workFlow", maps);
     	        result.put("success", true);
     	        result.put("msg", "操作成功！");
    		}
    		else {
    			result.put("success", false);
			}
 			return result;
		}catch(Exception e){
			logger.error("Exception", e);
			result.put("msg", "查询失败！");
			result.put("success", false);
			return result;
    	}
	}
	
	@RequestMapping(value="addAssetAllocation",method=RequestMethod.POST)  
	@ResponseBody
	public Map<String, Object> addAssetAllocation(@RequestBody Map<String,Object> map){  
		String assetsId = (String)map.get("assetsId");
		UTMap<String, Object> assetInfo = assetCollarService.getAssetByAssetId(assetsId);
		map.put("assetsName", assetInfo.get("assetsNameCode"));
		map.put("assetsType", assetInfo.get("assetsType"));
		map.put("assetsSubType", assetInfo.get("assetsSubType"));
		map.put("success", true);
		map.put("msg", "操作成功！");

		return map;
	}
	
	 @RequestMapping(value="addAssetIssue",method=RequestMethod.POST)  
	 @ResponseBody
	 public String addAssetIssue(@RequestBody Map<String,Object> map1){  
		Map<String,Object> map = CommonUtils.clone(map1);
		String appId = (String)map.get("appId");
		try {
				map.put("applyId", appId);
				assetApplicationService.addAssetIssue(map);
		} catch (Exception e) {
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "操作失败");
		}
		return UTJsonUtils.getJsonMsg(true, "操作成功");
	}
	 
	 @RequestMapping(value="deleteAssetIssue")
	 @ResponseBody
	 public String deleteAssetIssue(@RequestBody Map<String, Object> param){
		boolean flag = false; 
		try {
			flag = assetApplicationService.deleteAssetIssueByAssetId(param.get("id").toString());
		}catch (Exception e) {
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "删除失败");
		}
		if(flag)
			return UTJsonUtils.getJsonMsg(true, "删除成功");
		else
			return UTJsonUtils.getJsonMsg(false, "删除失败");
	}
	
	 @RequestMapping(value="deleteApplyAsset")
	 @ResponseBody
	 public String deleteApplyAsset(@RequestBody Map<String, Object> param){
		try {
			assetApplicationService.deleteAssetIssueByAppId(param.get("id").toString());
		}catch (Exception e) {
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "删除失败");
		}
		return UTJsonUtils.getJsonMsg(true, "删除成功");
	}
	 
	/**
	 * 根据id查询资产发放信息
	 * @param param
	 * @return
	 */
	@RequestMapping(value="getAssetIssueByAppId")
	@ResponseBody
	public List<UTMap<String, Object>> getAssetIssueByAppId(@RequestParam  Map<String, Object> param){		
		List<UTMap<String,Object>> assetIssueList = null;
    	try{
    		assetIssueList = assetApplicationService.getAssetIssueListMaps(param);
		}catch(Exception e){
			logger.error("Exception", e);
			return new ArrayList<UTMap<String, Object>>();
    	}
       return assetIssueList;
	}

	/**
	 * 根据id查询资产列表
	 * @param param
	 * @return
	 */
	@RequestMapping(value="getAssetListByAppId")
	@ResponseBody
	public List<UTMap<String, Object>> getAssetListByAppId(@RequestParam  Map<String, Object> param){		
		List<UTMap<String,Object>> assetIssueList = null;
    	try{
    		assetIssueList = assetApplicationService.getAssetListByAppId(param);
		}catch(Exception e){
			logger.error("Exception", e);
			return new ArrayList<UTMap<String, Object>>();
    	}
       return assetIssueList;
	}
	
	@RequestMapping(value="getAssetIssueByAppIdPage")  
    @ResponseBody
    public List<UTMap<String, Object>> getAssetIssueByAppIdPage(@RequestParam  Map<String, Object> param){ 
		List<UTMap<String, Object>> list = null;
		try{
			list = assetApplicationService.getAssetIssuePageInfo(param);
			if(null != list && list.size() > 0 ){
				for (Map<String, Object> map : list) {
					if((Integer)map.get("status") == 7){
						map.put("status", "已确认");
					}else{
						map.put("status", "未确认");
					}
				}
			}
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return list;
    }
	
	@RequestMapping(value="confirmIssue",method=RequestMethod.POST)  
	@ResponseBody
	public String confirmIssue(@RequestBody Map<String,Object> map){  
		try {
				assetApplicationService.updateIssueStatusById(map.get("ids").toString(),map.get("appId").toString());

				boolean flag = assetApplicationService.checkAssetIssueConfirm((String)map.get("appId"), "7");
				//所有资产发放全部已确认，资产申请状态修改为已完成
				if(flag)
					assetApplicationService.completeAssetIssueConfirm((String)map.get("appId"));
				
		} catch (Exception e) {
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "操作失败");
		}
		return UTJsonUtils.getJsonMsg(true, "操作成功");
	}
	
	@RequestMapping(value="updateAssetIssueById",method=RequestMethod.POST)  
	@ResponseBody
	public String updateAssetIssueById(@RequestBody Map<String,Object> map){  
		boolean flag = false;
		try {
			flag = assetApplicationService.updateAssetIssueById(map);

		} catch (Exception e) {
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "操作失败");
		}
		if(flag) {
			boolean flag1 = assetApplicationService.checkAssetIssueConfirm((String)map.get("appId"), "5");
			//所有资产已发放，资产申请状态修改为待确认
			if(flag1)
				assetApplicationService.completeAssetIssue((String)map.get("appId"));
			else
				assetApplicationService.startAssetIssue((String)map.get("appId"));
			return UTJsonUtils.getJsonMsg(true, "操作成功");
		}
		else
			return UTJsonUtils.getJsonMsg(false, "操作失败");
	}
	
	@RequestMapping(value="completeConfirm",method=RequestMethod.POST)  
	@ResponseBody
	public String completeConfirm(@RequestBody Map<String,Object> map){  
		try {
				UTMap<String, Object> ut = new UTMap<String,Object>();
				ut.put("status", (Integer)map.get("status"));
				ut.put("id", (String)map.get("id"));
				assetApplicationService.updateById(ut);
				assetApplicationService.updateAssetIssueStatusByAppId((String)map.get("id"), "7");
				
				//====关闭待办=====
				userTaskService.finishTask(String.valueOf(map.get("id")), "实物资产发放确认");
				
//				UTMap<String,Object> param = new UTMap<String,Object>();
//				param.put("appId", (String)map.get("id"));
//				List<UTMap<String,Object>> list = assetApplicationService.getAssetIssueListMaps(param);
				if(!StringUtils.isEmpty(String.valueOf(map.get("assetsIds")))){
					String[] assetsId = String.valueOf(map.get("assetsIds")).split(",");
					for (String id : assetsId) {
						UTMap<String,Object> track = new UTMap<String,Object>();
						UTMap<String,Object> assets = new UTMap<String,Object>();
						track.put("assetsId", id);
						track.put("userId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
						track.put("departId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserOrgId());
						track.put("changeRemark", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserOrgName()+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectName()+IAssetsTrackInfoDao.FIELD_ASSETSCOLLAR);
						track.put("type", 1);
						track.put("changeType","领用");
						track.put("changeTime", new Date(System.currentTimeMillis()));
						assetsTrackInfoService.add(track);
						
						//====修改资产责任人====
						assets.put("id", id);
						assets.put("resUserId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
						assets.put("resDepartId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserOrgId());
						assetPhysicalService.updateById(assets);
						
						//修改资产状态为'使用中'
						assetPhysicalService.updateAssetStatusById(id, "2");
						//====如果出库为空则当前时间为出库时间====
						assetPhysicalService.updateOutdateById(id);
					}
				}
				

		} catch (Exception e) {
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "操作失败");
		}
		return UTJsonUtils.getJsonMsg(true, "操作成功");
	}
	
	@RequestMapping(value="getAssetByAssetId")  
    @ResponseBody
    public UTMap<String, Object> getAssetByAssetId(@RequestParam  Map<String, Object> param){ 
		UTMap<String, Object> map = assetPhysicalService.getAssetById(param.get("id").toString());
        return map;
    }
	
	/**
	 * 分页查询资产
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAllApplyAssets")  
    @ResponseBody
    public UTPageBean getAllApplyAssets(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			List<UTMap<String, Object>> list = getIssueAsset(params);
			int total = list.size();
			int page = Integer.parseInt(params.get("page").toString());
			int count = Integer.parseInt(params.get("count").toString());
			List<Map<String, Object>> lastList = new ArrayList<Map<String,Object>>();
			for(int i = (page-1) * count; i < Math.min(total, page * count); i++)
			{
				lastList.add(list.get(i));
			}
			pageBean.setPage(page);
			pageBean.setCount(count);
		    pageBean.setTotal(total);
		    pageBean.setRows(lastList);
			
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	@RequestMapping(value="getIssueAsset")  
    @ResponseBody
    public List<UTMap<String, Object>> getIssueAsset(@RequestParam  Map<String, Object> param){ 
/*		List<UTMap<String, Object>> list = assetPhysicalService.getAssetsList(param);
		List<UTMap<String, Object>> lastList = new ArrayList<UTMap<String,Object>>();
		for (int i = 0; i < list.size(); i++) {
			if(null != list.get(i)){
				List<UTMap<String, Object>> ut = assetApplicationService.getIssueAssetByStatus(String.valueOf(list.get(i).get("id")));
				if(null == ut || ut.size() == 0){
					lastList.add(list.get(i));
				}
			}
		}*/
       return assetApplicationService.getAssetsList(param);
    }
	 
}