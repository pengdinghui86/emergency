package com.esc.oms.outsource.manhour.dao.impl;

import com.esc.oms.outsource.manhour.dao.IOvertimeDao;
import com.esc.oms.util.RoleUtils;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class OvertimeDaoImpl extends BaseOptionDao implements IOvertimeDao {
	@Override
	public String getTableName() {
		return "workhour_overtime";
	}

	@Override
	public List<UTMap<String, Object>> getOvertimeList(Map param) {
		String sql = getSearchSqlString(param);
		List<UTMap<String, Object>> dataList = this.getListBySql(sql);
		for (UTMap<String, Object> data : dataList) {
			if(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId().equals(data.get("createUserId"))) {
				data.put("isOwner", "1");
			}
		}
		return dataList;
	}

	@Override
	public void getOvertimePage(UTPageBean pageBean, Map param) {
		String sql = getSearchSqlString(param);
		this.getPageListMapBySql(sql , pageBean);
		List<UTMap<String, Object>> rows = pageBean.getRows();
		for (UTMap<String, Object> data : rows) {
			if(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId().equals(data.get("createUserId"))) {
				data.put("isOwner", "1");
			}
		}
	}
	
	/**
	 * 不可以根据状态查询
	 * @param param
	 * @return
	 */
	private String getSearchSqlString(Map param) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select DISTINCT s.*,if(hours < actualHours , hours, actualHours) finalHours,DATE_FORMAT(s.beginTime, '%Y-%m-%d %H:%i') beginTimeShow,DATE_FORMAT(s.endTime, '%Y-%m-%d %H:%i') endTimeShow ");
		if(param!=null &&param.get("status")!=null &&  StringUtils.isNotEmpty(param.get("status").toString())){
			String status = (String) param.get("status");
			if("2,3".equals(status)){//待审批
				sql.append(" ,t4.currentExecutor as auditors,t4.currentStepName ");
				sql.append(" from workhour_overtime s  ");
				sql.append(" left join sys_workflow_instance t4 on s.workflowInstanceId=t4.id ");
				sql.append(" where FIND_IN_SET('"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"',t4.currentExecutor) ");
			}else if("3,4,5".equals(status)){//已审批
				sql.append(" from workhour_overtime s  ");
				sql.append(" left join sys_workflow_audit_history t4 on s.workflowInstanceId=t4.instanceId ");
				sql.append(" where FIND_IN_SET('"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"',t4.optionUserId) " );
				sql.append(" and t4.nodeName!='开始' " );//屏蔽开始节点
			}else{ // 其他单个
				sql.append(" , if(b.userId is null, 0, 1) billAudited ");
				sql.append(" from workhour_overtime s ");
				sql.append(" left join workhour_bill b on s.createUserId = b.userId and DATE_FORMAT(s.beginTime, '%Y') = b.`year` and QUARTER(s.beginTime) = b.`quarter` ");
				sql.append(" WHERE 1=1 ");
			}
		}else{
			sql.append(" , if(b.userId is null, 0, 1) billAudited ");
			sql.append(" from workhour_overtime s ");
			sql.append(" left join workhour_bill b on s.createUserId = b.userId and DATE_FORMAT(s.beginTime, '%Y') = b.`year` and QUARTER(s.beginTime) = b.`quarter` ");
			sql.append(" WHERE 1=1 ");
		}
		if(param != null) {
			String id = (String) param.get("id");
			String beginTime = (String) param.get("beginTime");
			String endTime = (String) param.get("endTime");
			String supplierId = (String) param.get("supplierId");
			String orgId = (String) param.get("orgId");
			String supplierName = (String) param.get("supplierName");
			String createUser = (String) param.get("createUser");
			String coalitionId = (String) param.get("coalitionId");
			String submitUser = (String) param.get("submitUser");
			if(StringUtils.isNotEmpty(id)) {
				sql.append(" and s.id = '").append(id).append("' ");
			}
//			if(StringUtils.isNotEmpty(beginTime)) {
//				sql.append(" and s.beginTime >= '").append(beginTime).append("' ");
//			}
//			if(StringUtils.isNotEmpty(endTime)) {
//				sql.append(" and s.beginTime <= '").append(endTime).append("' "); // 查询的结束时间
//			}
			// 查询的开始结束时间需要根据每一天的数据
			if(StringUtils.isNotEmpty(beginTime)) {
				sql.append(" and s.presentDate >= '").append(beginTime).append("' ");
			}
			if(StringUtils.isNotEmpty(endTime)) {
				sql.append(" and s.presentDate <= '").append(endTime).append("' ");
			}
			if(StringUtils.isNotEmpty(orgId)) {
				sql.append(" and s.orgId = '").append(orgId).append("' ");
			}
			if(StringUtils.isNotEmpty(supplierId)) {
				sql.append(" and s.supplierId = '").append(supplierId).append("' ");
			}
			if(StringUtils.isNotEmpty(coalitionId)) {
				sql.append(" and s.coalitionId = '").append(coalitionId).append("' ");
			}
			if(StringUtils.isNotEmpty(supplierName)) {
				sql.append(" and s.supplierName like '%").append(supplierName).append("%' ");
			}
			if(StringUtils.isNotEmpty(createUser)) {
				sql.append(" and s.createUser like '%").append(createUser).append("%' ");
			}
			if(StringUtils.isNotEmpty(submitUser)){
				sql.append(" and s.submitUser like '%"+submitUser+"%'");
			}
		}
		// 权限过滤：个人只能看见自己的、供应商负责人看自己所属供应商的、供应商管理员看所有的、审核人看见自己审核的
		if(!(param != null && "1".equals(param.get("showAll")))) { // 非审核页面
			// 数据权限过滤 lba
			if(EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.OUTSOURCE_MANAGER, RoleUtils.SYSTEM_ADMINISTRATOR)) {//外包管理员
				// 不做限制
			} else if(EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SUPPLIER_LEADERS)) {// 供应商负责人
				// 只能看自己所属供应商的
				sql.append(" and s.supplierId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId()+"' ");
			} else {// 只能看自己的
				sql.append(" and s.createUserId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' ");
			}
		}
		sql.append(" order by s.submitTime desc ");
		return sql.toString();
	}

	@Override
	public void getStatisticDetailPage(UTPageBean pageBean,Map param) {
		String sql = getStatisticDetailSqlString(param);
		this.getPageListMapBySql(sql , pageBean);
	}
	
	@Override
	public List<UTMap<String, Object>> getStatisticDetailList(Map param) {
		String sql = getStatisticDetailSqlString(param);
		return super.getListBySql(sql);
	}
	
	private String getStatisticDetailSqlString(Map param) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select s.* ");
		sql.append(" from workhour_overtime s ");
		sql.append(" WHERE 1=1 ");
		if(param != null) {
			String beginTime = (String) param.get("beginTime");
			String endTime = (String) param.get("endTime");
			String orgId = (String) param.get("orgId");
			String orgName = (String) param.get("orgName");
			String supplierId = (String) param.get("supplierId");
			String supplierName = (String) param.get("supplierName");
			String status = (String) param.get("status");
			String queryStatus = (String) param.get("queryStatus");
			String coalitionId = (String) param.get("coalitionId");
			String createUser = (String) param.get("createUser");
			String createUserId = (String) param.get("createUserId");
			String presentDate = (String) param.get("presentDate");
			String submitUser = (String) param.get("submitUser");
			if(StringUtils.isNotEmpty(status)) {
				sql.append(" and find_in_set(s.status, '").append(status).append("') ");
			}
			if(StringUtils.isNotEmpty(queryStatus)) {
				sql.append(" and find_in_set(s.status, '").append(queryStatus).append("') ");
			}
			if(StringUtils.isNotEmpty(beginTime)) {
				sql.append(" and s.presentDate >= '").append(beginTime).append("' ");
			}
			if(StringUtils.isNotEmpty(endTime)) {
				sql.append(" and s.presentDate <= '").append(endTime).append("' ");
			}
			if(StringUtils.isNotEmpty(presentDate)) {
				sql.append(" and s.presentDate = '").append(presentDate).append("' ");
			}
			if(StringUtils.isNotEmpty(orgId)) {
				sql.append(" and s.orgId = '").append(orgId).append("' ");
			}
			if(StringUtils.isNotEmpty(supplierId)) {
				sql.append(" and s.supplierId = '").append(supplierId).append("' ");
			}
			if(StringUtils.isNotEmpty(supplierName)) {
				sql.append(" and s.supplierName like '%").append(supplierName).append("%' ");
			}
			if(StringUtils.isNotEmpty(orgName)) {
				sql.append(" and s.orgName like '%").append(orgName).append("%' ");
			}
			if(StringUtils.isNotEmpty(createUser)) {
				sql.append(" and s.createUser like '%").append(createUser).append("%' ");
			}
			if(StringUtils.isNotEmpty(createUserId)) {
				sql.append(" and s.createUserId = '").append(createUserId).append("' ");
			}
			if(StringUtils.isNotEmpty(coalitionId)) {
				sql.append(" and s.coalitionId = '").append(coalitionId).append("' ");
			}
			if(StringUtils.isNotEmpty(submitUser)){
				sql.append(" and s.submitUser like'%"+submitUser+"%'");
			}
		}
		// 权限过滤：个人只能看见自己的、供应商负责人看自己所属供应商的、供应商管理员看所有的、审核人看见自己审核的
		// 数据权限过滤 lba
		if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.OUTSOURCE_MANAGER, RoleUtils.SYSTEM_ADMINISTRATOR)) {//外包管理员
			// 只能看自己所属供应商的
			sql.append(" and s.supplierId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId()+"' ");
		}
		sql.append(" order by s.presentDate desc, createUser desc ");
		return sql.toString();		
		
	}

	@Override
	public boolean isExistRecord(Map<String, Object> map) {
		if(map.containsKey("beginTime") && map.containsKey("endTime")) {
			Object beginTime = map.get("beginTime");
			Object endTime = map.get("endTime");
			StringBuilder checkSql = new StringBuilder();
			checkSql.append("select s.beginTime, s.endTime from " + getTableName() + " s ");
			checkSql.append(" where s.createUserId = ? ");
			checkSql.append(" and s.status <> '6' ");
			checkSql.append(" and s.beginTime <?   AND s.endTime > ? ");
//			checkSql.append(" and ((s.beginTime >= ? and s.beginTime < ?) or (s.endTime > ? and s.endTime <= ?) ) ");
//			checkSql.append(" and ((s.beginTime BETWEEN ? and ?) or (s.endTime BETWEEN ? and ?) ) ");
			if(map.containsKey("id")) {
				String id = (String) map.get("id");
				if(StringUtils.isNotEmpty(id))
					checkSql.append(" and id <> '" + id + "' ");
			}
			
			int count = this.getCount(checkSql.toString(), EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId(), endTime, beginTime);
			if(count > 0) {
				return true;
			}
		}
		return false;
	}

	@Override
	public List<UTMap<String, Object>> getListMap(Map<String, Object> param) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select * from workhour_overtime where 1=1 ");
		if(param != null){
			String ids = (String) param.get("ids");
			if(StringUtils.isNotEmpty(ids)){
				sql.append(" and instanceId in("+ids+")");
			}
		}
		return this.getListBySql(sql.toString());
	}

	@Override
	public boolean deleteByTime(String startTime, String endTime, String userIds) {
		StringBuilder sql = new StringBuilder();
		sql.append(" delete from workhour_overtime where (submitTime >= '"+startTime+"' and submitTime <='"+endTime+"') ");
		sql.append(" or(beginTime <= '"+startTime+"' and endTime >='"+endTime+"')");
		sql.append(" or (beginTime <= '"+startTime+"' and endTime >='"+startTime+"' and endTime <='"+endTime+"')");
		sql.append(" or (beginTime >='"+startTime+"' and beginTime <='"+endTime+"' and endTime >='"+endTime+"')");
		sql.append(" or(beginTime >= '"+startTime+"' and endTime <='"+endTime+"')");
		sql.append(" and createUserId in("+userIds+")");
		return this.executeUpdate(sql.toString());
	}

}
