package com.esc.oms.outsource.monitor.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

/**
 * 服务监控评估Dao
 * @author owner
 *
 */
public interface IMonitorEvaluateDao extends IBaseOptionDao{

	public static final String  FIELD_ID = "id";
	public static final String  FIELD_EVALUATE_TITLE = "evaluateTitle";//评估标题
	public static final String  FIELD_EVALUATEBEGINDATE = "evaluateBeginDate";//开始日期
	public static final String  FIELD_EVALUATEENDDATE = "evaluateEndDate";//结束日期
	public static final String  FIELD_EVALUATOR = "evaluator";//评估人员
	public static final String  FIELD_MONITOREVALUATOR = "monitorEvaluator";//检查人员
	public static final String  FIELD_SUPPLIERNAME = "supplierName";//供应商
	public static final String  FIELD_SUPPLIERID = "supplierId";//供应商Id
	public static final String  FIELD_TYPE = "type";//类别
	public static final String  FIELD_OUTSIDE_SPECIALISTS = "outsideSpecialists";//外部专家
	public static final String  FIELD_EVALUATERESULT = "evaluateResult";//评估结果
	public static final String  FIELD_STATUS = "status";//评估结果状态
	public static final String  FIELD_SUBMITTERNAME = "submitterName";//提交人
	public static final String  FIELD_SUBMITTIME = "submitTime";//提交时间
	public static final String  FIELD_RESULT_REMARK = "resultRemark";//评估说明
	public static final String  FIELD_REMARK = "remark";//备注
	
	public static final String[] inFileds = new String[] {
		FIELD_EVALUATE_TITLE,
		FIELD_SUPPLIERID,
		FIELD_TYPE,
		FIELD_EVALUATERESULT,
		FIELD_MONITOREVALUATOR,
		FIELD_EVALUATEBEGINDATE,
		FIELD_EVALUATEENDDATE,
		FIELD_RESULT_REMARK,
		FIELD_REMARK
	};
	
	public static final String[] outFileds = new String[] {
		FIELD_EVALUATE_TITLE,
		FIELD_SUPPLIERNAME,
		FIELD_TYPE,
		FIELD_SUBMITTIME,
		FIELD_SUBMITTERNAME,
		FIELD_EVALUATERESULT,
		FIELD_STATUS,
		FIELD_MONITOREVALUATOR,
		FIELD_EVALUATEBEGINDATE,
		FIELD_EVALUATEENDDATE,
		FIELD_RESULT_REMARK,
		FIELD_REMARK
		
	};
	
	

	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params);
	
	/**
	 * 单一数据评估后，需要删除同一批时间点生成的其它数据
	 * @param id 不用删除的数据id
	 * @param monitorEvaluateConfigId 服务监控配置id
	 * @param createTime 标识同一批时间点生成的监控数据
	 */
	public void deleteBySingle(String id, String monitorEvaluateConfigId, String createTime );
	
}
