package com.esc.oms.outsource.monitor.service;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;

/**
 * 第三方机构检查
 * @author owner
 *
 */
public interface IDuediligenceThirdService extends IBaseOptionService{
	
	/**
	 * 根据模板配置查询对应的第三方机构数据
	 * @param duediligenceEvaluateConfigId
	 * @return
	 */
	public UTMap<String, Object> getByDuediligenceEvaluateConfigId(String duediligenceEvaluateConfigId);
}
