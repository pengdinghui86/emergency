package com.esc.oms.outsource.attendance.service;

import org.esc.framework.service.IBaseOptionService;

/**
 * 联合考勤规则配置Service接口
 * @author owner
 *
 */
public interface ICoalitionConfigService extends IBaseOptionService {
	
	
}
