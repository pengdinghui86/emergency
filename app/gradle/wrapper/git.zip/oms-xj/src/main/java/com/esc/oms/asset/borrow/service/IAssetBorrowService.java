package com.esc.oms.asset.borrow.service;

import java.util.List;
import java.util.Map;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;


public interface IAssetBorrowService extends IBaseOptionService{
	
	public boolean addAssetAllocation(Map info);
	
	public boolean deleteAssetAllocationById(String id);
	
	public List<UTMap<String, Object>> getAssetAllocationListMaps(Map param) ;
	
	public boolean updateAllocationStatusById(String ids,String status,String borrowId);
	
	public void getAssetAllocationPageInfo(UTPageBean pageBean,Map param);
	
	public List<UTMap<String,Object>> getRemindBorrowsList();
	
	public boolean updateAllocationStatusByBorrowId(String borrowId,String status);
	
	public List<UTMap<String,Object>> getBorrowDetailByIdAndStatus(String borrowId);
	
	public List<UTMap<String,Object>> getBorrowDetailByIds(String ids);
	
	public void generate();
	
	public List<UTMap<String, Object>> getBorrowByStatusList(String assetId);

	public boolean deleteAssetAllocationByBorrowId(String borrowId);

	public boolean updateAssetAllocation(Map<String, Object> param);

	public void getAssetsList(Map<String, Object> params, UTPageBean pageBean);

	public void getAssetAllocationPage(Map<String, Object> param, UTPageBean pageBean);
}


