package com.esc.oms.asset.assetCategory.dao.impl;

import com.esc.oms.asset.assetCategory.dao.IAssetCategoryDao;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class AssetCategoryDaoImpl extends BaseOptionDao implements IAssetCategoryDao {
  private String assets_material_category_attr_value="assets_material_category_attr_value";

  @Override
  public String getTableName() {
    return "assets_material_category_attr";
  }

  @Override
  public void getPageInfo(UTPageBean pageBean, Map params) {
    super.getPageListMapBySql(getSearchSql(params), pageBean, null);
  }

  private String getSearchSql(Map params){
    StringBuilder sql = new StringBuilder();
    sql.append(" select amc.id,amc.`name`,amc.`value`,amc.remark ");
    sql.append(" from assets_material_category amc ");
    sql.append(" where 1=1 ");
    if(params != null){
      String name = (String)params.get("name");
      if(StringUtils.isNotEmpty(name)){
        sql.append(" and amc.name like '%"+name+"%' ");
      }
    }
    sql.append("ORDER BY CONVERT(amc.`name` USING gbk) ");
    return sql.toString();
  }

  @Override
  public List<UTMap<String, Object>> getdicts() {
    String sql = "SELECT * FROM sys_param_type WHERE 1=1  AND FIND_IN_SET(IFNULL(TYPE, '2'), '2,3')  ORDER BY createTime DESC";
    return this.getListBySql(sql);
  }
  
  @Override
  public List<UTMap<String, Object>> getdictByDictType(String type) {
    String sql = "SELECT * FROM sys_param WHERE 1=1  AND paramType = '" + type + "' ORDER BY value";
    return this.getListBySql(sql);
  }

  @Override
  public List<UTMap<String, Object>> getdictByDictName(String name) {
    String sql = "SELECT sp.* FROM sys_param sp, sys_param_type spt WHERE sp.paramType = spt.code AND spt.name LIKE '" + name + "' ORDER BY value";
    return this.getListBySql(sql);
  }
  
  @Override
  public void getAttrAll(Map<String, Object> params, UTPageBean pageBean) {
   this.getPageListMapBySql(getAttrSearchSql(params), pageBean);
  }

  private String getAttrSearchSql(Map<String, Object> params){
    StringBuilder sql = new StringBuilder();
    sql.append(" select amca.id,amca.categoryId,amca.attId,amca.attName,amca.valueType type,amca.minFigure min,amca.maxFigure max, ");
    sql.append(" amca.maxLength maxlength,amca.dict,amca.foreignType,amca.defaultValue,amca.sort,amca.place,amca.notNull required ,");
    sql.append(" amca.deleteFlag, amca.createUser,amca.createTime,amca.updateUser,amca.updateTime ");
    sql.append(" from assets_material_category_attr amca where 1=1 and amca.deleteFlag <> 1 ");
    if(params != null){
      String categoryId = (String)params.get("categoryId");
      if(StringUtils.isNotEmpty(categoryId)){
        sql.append(" and amca.categoryId ='"+categoryId+"' ");
      }
    }
    sql.append(" order by amca.sort asc , amca.attId asc");
    return sql.toString();
  }

  @Override
  public List<UTMap<String, Object>> getAttrAllMap(String categoryId) {
    StringBuilder sql = new StringBuilder();
    sql.append(" select amca.id,amca.categoryId,amca.attId,amca.attName,amca.valueType type,amca.minFigure min,amca.maxFigure max, ");
    sql.append(" amca.maxLength,amca.dict,amca.foreignType,amca.defaultValue,amca.sort,amca.place,amca.notNull required ,");
    sql.append(" amca.deleteFlag, amca.createUser,amca.createTime,amca.updateUser,amca.updateTime ");
    sql.append(" from assets_material_category_attr amca where 1=1 and amca.deleteFlag <> 1 ");
    sql.append(" and amca.categoryId ='"+categoryId+"' ");
    sql.append(" order by amca.sort asc , amca.attId asc");
    return this.getListBySql(sql.toString());
  }

  @Override
  public boolean saveAttrValueList(List<UTMap<String, Object>> list) {
    return super.batchSaveToUTMap(assets_material_category_attr_value, list);
  }

  @Override
  public List<UTMap<String, Object>> getAttrValue(String infoId) {
    StringBuilder sql = new StringBuilder();
    sql.append(" select amca.attId,amcav.attValue, amca.attName,amca.valueType type,amca.minFigure min,amca.maxFigure, ");
    sql.append(" amca.maxLength,amca.dict,amca.foreignType,amca.defaultValue,amca.sort,amca.place,amca.notNull required ");
    sql.append(" from assets_material_category_attr amca left join assets_material_category_attr_value amcav ");
    sql.append(" on amca.attId  = amcav.attId  where amca.deleteFlag = 0 and amcav.assetsInfoId='"+infoId+"'");
    sql.append(" order by amca.sort asc, amca.attId asc");
    return this.getListBySql(sql.toString());
  }
  
  @Override
  public String getAssetCategoryIdByName(String name) {
    StringBuilder sql = new StringBuilder();
    sql.append(" select amc.id from assets_material_category amc where 1=1 ");
    sql.append(" and amc.name ='" + name + "' ");
    UTMap<String, Object> map = this.getOneBySql(sql.toString());
    return map.get("id").toString();
  }

  @Override
  public String getAssetCategoryIdByNames(String parentName, String name) {
    StringBuilder sql = new StringBuilder();
    sql.append(" select a1.id from assets_material_category a1 left join assets_material_category a2 ");
    sql.append(" on a1.parentId = a2.id where a1.name = '"+name+"' and a2.name='"+parentName+"'" );
    UTMap<String, Object> map = this.getOneBySql(sql.toString());
    return map.get("id").toString();
  }

  @Override
  public boolean isAssetInfoColumn(String ID) {
    StringBuilder sql = new StringBuilder();
    sql.append(" select 1 from dual where '"+ID+"'");
    sql.append(" in (select COLUMN_NAME from information_schema.COLUMNS where table_name = 'assets_material_info')");
    List<UTMap<String, Object>> result = this.getListBySql(sql.toString());
    return result != null && result.size() >= 1;
  }

  @Override
  public List<UTMap<String, Object>> getAttrList(Map<String, Object> params) {
    return this.getListBySql(getAttrSearchSql(params));
  }
}
