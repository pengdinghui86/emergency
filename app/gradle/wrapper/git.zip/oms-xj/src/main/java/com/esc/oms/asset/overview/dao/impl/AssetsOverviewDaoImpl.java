package com.esc.oms.asset.overview.dao.impl;

import com.esc.oms.asset.overview.dao.IAssetsOverviewDao;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
@Repository
public class AssetsOverviewDaoImpl extends BaseOptionDao implements IAssetsOverviewDao{
	
	@Override
	public String getTableName() {
		return "";
	}
	@Override
	public void getAssetsPageList(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getAssetsListSearchSql(params), pageBean, null);
	}
	
	@Override
	public List<UTMap<String, Object>> getAssetsList(Map params) {
		return super.getListBySql(getAssetsListSearchSql(params), null);
	}
	
	/**
	 * 资产列表--条件查询
	 * @param params
	 * @return
	 */
	private String getAssetsListSearchSql(Map params){
		StringBuilder sql = new StringBuilder();
		sql.append(" select info.*,category.name as categoryName,subCategory.name as subCategoryName,CONCAT(user.name,'/',user.`code`) as resUserName,CONCAT(user2.name,'/',user2.`code`) as EquipmentLeaderName,org.name as resDepartName,"
				+ " org.longName as resDepartLongName,concat(agreement.agreementName,'/',agreement.agreementCode) as maintainContractName, agreement.supplierName as maintainContractSupplierName "
				+ " from assets_material_info info ");		
		sql.append(" LEFT JOIN assets_material_category category on info.category = category.id ");
		sql.append(" LEFT JOIN assets_material_category subCategory on info.subCategory = subCategory.id ");
		sql.append(" LEFT JOIN sys_user user on info.resUserId = user.id ");
		sql.append(" LEFT JOIN sys_user user2 on info.EquipmentLeader = user2.id ");
		sql.append(" LEFT JOIN sys_org org on info.resDepartId = org.id ");
		sql.append(" LEFT JOIN assets_agreement_info agreement on info.maintainContract = agreement.id ");
		sql.append(" where 1=1 ");	
		sql.append(" AND (info.deleteFlag != 1 OR info.deleteFlag IS NULL) AND (info.registStatus is NULL OR info.registStatus = '2') ");
		if(params!=null && params.size()>0){		
			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
				sql.append(" and info.name like '%"+params.get("name").toString().trim()+"%' ");
			}
			if(params.get("code")!=null &&  StringUtils.isNotEmpty(params.get("code").toString())){
				sql.append(" and info.code like '%"+params.get("code").toString().trim()+"%' ");
			}			
			if(params.get("nameCode")!=null &&  StringUtils.isNotEmpty(params.get("nameCode").toString())){
				sql.append(" and (info.codeNum like '%"+params.get("nameCode").toString().trim()+"%' or info.serialNum like '%"+params.get("nameCode").toString().trim()+"%' )");
			}
			if(params.get("serialNum")!=null &&  StringUtils.isNotEmpty(params.get("serialNum").toString())){
				sql.append(" and info.serialNum like '%"+params.get("serialNum").toString().trim()+"%' ");
			}
			if(params.get("category")!=null &&  StringUtils.isNotEmpty(params.get("category").toString())){
				sql.append(" and info.category='"+params.get("category").toString().trim()+"' ");
			}
			if(params.get("assetsLevel")!=null &&  StringUtils.isNotEmpty(params.get("assetsLevel").toString())){
				sql.append(" and info.assetsLevel='"+params.get("assetsLevel").toString().trim()+"' ");
			}
			if(params.get("subCategory")!=null &&  StringUtils.isNotEmpty(params.get("subCategory").toString())){
				sql.append(" and info.subCategory='"+params.get("subCategory").toString().trim()+"' ");
			}
			if(params.get("maintainContractSupplierName")!=null &&  StringUtils.isNotEmpty(params.get("maintainContractSupplierName").toString())){
				sql.append(" and agreement.supplierName like '%"+params.get("maintainContractSupplierName").toString().trim()+"%' ");
			}
			if(params.get("maintainContract")!=null &&  StringUtils.isNotEmpty(params.get("maintainContract").toString())){
				sql.append(" and info.maintainContract='"+params.get("maintainContract").toString().trim()+"' ");
			}
			if(params.get("maintainContractName")!=null &&  StringUtils.isNotEmpty(params.get("maintainContractName").toString())){
//				sql.append(" and (agreement.agreementName like '%"+params.get("maintainContractName").toString().trim()+"%' or agreement.agreementCode like '%"+params.get("maintainContractName").toString().trim()+"%' )");
				sql.append(" and CONCAT(agreement.agreementName,'/',agreement.agreementCode) like '%"+params.get("maintainContractName").toString().trim()+"%' ");
			}
			if(params.get("resUserId")!=null &&  StringUtils.isNotEmpty(params.get("resUserId").toString())){
				sql.append(" and info.resUserId='"+params.get("resUserId").toString().trim()+"' ");
			}
			if(params.get("resUserName")!=null &&  StringUtils.isNotEmpty(params.get("resUserName").toString())){
//				sql.append(" and (user.name like '%"+params.get("resUserName").toString().trim()+"%' or user.code like '%"+params.get("resUserName").toString().trim()+"%')");
				sql.append(" and CONCAT(user.name,'/',user.code) like '%"+params.get("resUserName").toString().trim()+"%' ");
			}
			if(params.get("resDepartId")!=null &&  StringUtils.isNotEmpty(params.get("resDepartId").toString())){
				sql.append(" and info.resDepartId='"+params.get("resDepartId").toString().trim()+"' ");
			}
			if(params.get("resDepartName")!=null &&  StringUtils.isNotEmpty(params.get("resDepartName").toString())){
				sql.append(" and org.name like '%"+params.get("resDepartName").toString().trim()+"%' ");
			}
			if(params.get("resDepartLongName")!=null &&  StringUtils.isNotEmpty(params.get("resDepartLongName").toString())){
				sql.append(" and org.longName like '%"+params.get("resDepartLongName").toString().trim()+"%' ");
			}
			if(params.get("isScrap")!=null && StringUtils.isNotEmpty(params.get("isScrap").toString())){
				sql.append(" AND ifnull(info.isScrap,'0') = '"+params.get("isScrap").toString().trim()+"'");
			}
		}
		sql.append(" order by info.createTime desc,info.sortCode");
		return  sql.toString();
	}
	@Override
	public void getWarnAgreementPageList(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getWarnAgreementListSearchSql(params), pageBean, null);
	}
	
	@Override
	public List<UTMap<String, Object>> getWarnAgreementList(Map params) {
		return super.getListBySql(getWarnAgreementListSearchSql(params), null);
	}
	/**
	 * 到预警期的合同列表
	 * @param params
	 * @return
	 */
	private String getWarnAgreementListSearchSql(Map params){
		StringBuilder sql = new StringBuilder();
		sql.append(" select t1.*,ids_to_name(t1.aleaders) as aleaderNames "
				+ " from (select a.createTime,b.name,b.code,b.beginTime,b.endTime,b.supplierName,b.aleaders,datediff(b.endTime,now()) as leftNum,a.isWarn from assets_agreement_info a "
				+ " LEFT JOIN agreement_info b  on a.agreementId=b.id) t1 "
				+ " where t1.isWarn='1' "
				+ " and t1.leftNum<=(select max(warnDayNum) as maxDayNum from assets_agreement_warn_config) ");	
		if(params!=null && params.size()>0){		
			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
				sql.append(" and t1.name like '%"+params.get("name").toString().trim()+"%' ");
			}
			if(params.get("code")!=null &&  StringUtils.isNotEmpty(params.get("code").toString())){
				sql.append(" and t1.code like '%"+params.get("code").toString().trim()+"%' ");
			}
			if(params.get("supplierName")!=null &&  StringUtils.isNotEmpty(params.get("supplierName").toString())){
				sql.append(" and t1.supplierName like '%"+params.get("supplierName").toString().trim()+"%' ");
			}
		}
		sql.append(" order by t1.leftNum asc");
		return  sql.toString();
	}
	@Override
	public List<UTMap<String, Object>> getOverviewReportCategoy(
			Map<String, Object> params) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select count(*) as num,info.category,category.name as categoryName from assets_material_info info "
				+ " LEFT JOIN assets_material_category category on info.category = category.id ");	
		sql.append(" where (info.status is not null) and ifnull(info.isScrap,'0')='0' and (info.deleteFlag!='1' or info.deleteFlag is null) ");	
		if(params!=null && params.size()>0){		
			if(params.get("inboundStartDate")!=null &&  StringUtils.isNotEmpty(params.get("inboundStartDate").toString())){
				sql.append(" and DATE_FORMAT(info.inboundDate,'%Y-%m-%d')>='"+params.get("inboundStartDate").toString().trim()+"' ");
			}
			if(params.get("inboundEndDate")!=null && StringUtils.isNotEmpty(params.get("inboundEndDate").toString())){
				sql.append(" and DATE_FORMAT(info.inboundDate,'%Y-%m-%d')<='"+params.get("inboundEndDate").toString().trim()+"' ");
			}
		}
		sql.append(" GROUP BY info.category ");
		String typeSql = sql.toString();
		return super.getListBySql(typeSql, null);
	}
	@Override
	public List<UTMap<String, Object>> getOverviewReportMonth(
			Map<String, Object> params) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select count(*) as num,DATE_FORMAT(info.inboundDate,'%Y-%m') as month from assets_material_info info");	
		sql.append(" where (info.status is not null) and ifnull(info.isScrap,'0')='0' and (info.deleteFlag!='1' or info.deleteFlag is null) ");	
		if(params!=null && params.size()>0){		
			if(params.get("inboundStartDate")!=null &&  StringUtils.isNotEmpty(params.get("inboundStartDate").toString())){
				sql.append(" and DATE_FORMAT(info.inboundDate,'%Y-%m-%d')>='"+params.get("inboundStartDate").toString().trim()+"' ");
			}
			if(params.get("inboundEndDate")!=null && StringUtils.isNotEmpty(params.get("inboundEndDate").toString())){
				sql.append(" and DATE_FORMAT(info.inboundDate,'%Y-%m-%d')<='"+params.get("inboundEndDate").toString().trim()+"' ");
			}
		}
		sql.append("  GROUP BY month ");
		String typeSql = sql.toString();
		return super.getListBySql(typeSql, null);
	}
	
}
