package com.esc.oms.outsource.performance.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

/**
 * 外包绩效考核Dao
 * @author owner
 *
 */
public interface IPerformanceEvaluateUserDao extends IBaseOptionDao{
	public static final String  FIELD_ID= "id";
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params);
	
	/**
	 * 根据过程评估删除用户评估数据
	 * @param performanceEvaluateId
	 */
	public void deleteByPerformanceEvaluateId(String performanceEvaluateId);
	
	/**
	 * 校验年份以及月份是否已经存在考核数据
	 * @param performanceEvaluator 被考核对象
	 * @param year 年份
	 * @param month 月份
	 * @return
	 */
	public boolean isExit(String performanceEvaluator,String year,String unit,String half,String quarter,String month, String projectInfoId);
	
	/**
	 * @param performanceEvaluateConfigId 模板配置ID
	 * @param performanceEvaluator 被考核对象
	 * @return
	 */
	public List<UTMap<String,Object>> getAvgEvaluateResult(String performanceEvaluateConfigId,String performanceEvaluator, String projectInfoId);
	
}
