package com.esc.oms.outsource.outperson.dao;

import org.esc.framework.persistence.dao.IBaseOptionDao;

public interface IOutSourcePersonBlacklistDao extends IBaseOptionDao {

}
