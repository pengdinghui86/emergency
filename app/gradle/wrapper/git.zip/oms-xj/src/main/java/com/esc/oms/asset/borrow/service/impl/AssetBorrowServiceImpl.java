package com.esc.oms.asset.borrow.service.impl;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.idgenerator.IDGenerationManager;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.dao.ISysUserDao;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.timetask.anotations.CronTimeTask;
import org.esc.framework.timetask.anotations.TimeTaskMark;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.asset.application.dao.IBusinessNumberDao;
import com.esc.oms.asset.borrow.dao.IAssetBorrowDao;
import com.esc.oms.asset.borrow.service.IAssetBorrowService;
import com.esc.oms.asset.overview.dao.IAssetsTrackInfoDao;
import com.esc.oms.asset.overview.service.IAssetsTrackInfoService;
import com.esc.oms.asset.physical.service.IAssetPhysicalService;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;
import com.esc.oms.util.RoleUtils;
import com.esc.oms.util.TaskModel;

@Service
@Transactional
@TimeTaskMark
public class AssetBorrowServiceImpl extends BaseOptionService implements IAssetBorrowService{
	
	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private IAssetBorrowDao assetBorrowDao;
	
	@Resource
	private IBusinessNumberDao businessNumberDao;
	
	@Resource
	private ISysUserDao sysUserDao;
	
	@Resource
	private IAssetsTrackInfoService assetsTrackInfoService;
	
	@Resource
	private ISysUserService userService;
	
	@Resource
	private MessageSend messageService;
	
	@Resource
	private IUserTaskService userTaskService;
	
	@Resource
	private IAssetPhysicalService assetPhysicalService;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return assetBorrowDao;
	}
	
	/**
	 * 添加
	 * @param info
	 * @return
	 */
	@EscOptionLog(module=SystemModule.assetBorrow, opType=ESCLogOpType.INSERT, table="assets_material_borrow",option="新增名称为{name}的资产借用申请信息。")
	public boolean add(Map info){
//		Calendar cal = Calendar.getInstance();
//		int year = cal.get(Calendar.YEAR);
//		String code = businessNumberDao.saveOrUpdate("JYSQ", String.valueOf(year), "%04d");
//		info.put("code", code);
		info.put("code", IDGenerationManager.nextId("assetsBorrowCode")); // 自动生成编号
		info.put("createUserId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
		return	getOptionDao().add(info);
	}
	
	
	@Override
	@EscOptionLog(module=SystemModule.assetBorrow, opType=ESCLogOpType.UPDATE, table="assets_material_borrow",option="修改名称为{name}的资产借用申请信息。")
	public boolean updateById(Map info){
		if(!info.containsKey("id")){
			throw new EscServiceException("根据id 修改map中不存在key=id");
		}
		return getOptionDao().updateById(info);
	}

	@Override
	public boolean addAssetAllocation(Map info) {
		return assetBorrowDao.addAssetAllocation(info);
	}

	@Override
	public boolean deleteAssetAllocationById(String id) {
		return assetBorrowDao.deleteAssetAllocationById(id);
	}
	
	@Override
	public boolean deleteAssetAllocationByBorrowId(String borrowId) {
		return assetBorrowDao.deleteAssetAllocationByBorrowId(borrowId);
	}

	@Override
	public List<UTMap<String, Object>> getAssetAllocationListMaps(Map param) {
		return assetBorrowDao.getAssetAllocationListMaps(param);
	}

	

	@Override
	public void getAssetAllocationPageInfo(UTPageBean pageBean, Map param) {
		assetBorrowDao.getAssetAllocationPageInfo(pageBean, param);
	}

	@Override
	public boolean updateAllocationStatusById(String ids,String status,String borrowId) {
		boolean flag = false;
		UTMap<String, Object> ut = new UTMap<String,Object>();
		if(ids.indexOf(",") > 0 ){//批量确认
			
			String[] allocationIds = ids.split(",");
			for (String allocationId : allocationIds) {
				if("2".equals(status)){
					UTMap<String,Object> mapUt = assetBorrowDao.getAssetBorrowById(allocationId);
					if(null != mapUt){
						Integer utStatus = (Integer)mapUt.get("status");
						if(3== utStatus){
							continue;
						}
					}
				}
				flag = assetBorrowDao.updateAllocationStatusById(allocationId, status);
				if(flag){
					if("3".equals(status)){
						addAssetsTrack(allocationId);//资产记录---资产归还
					}
					sendConfirmationMessage(allocationId,borrowId);//待办,消息
				}
			}
		}else{
			flag = assetBorrowDao.updateAllocationStatusById(ids, status);
			if(flag){
				if("3".equals(status)){
					addAssetsTrack(ids);//资产记录---资产归还
				}
				if("2".equals(status)){
//					addAssetsTrack(ids);//资产记录---资产归还
					sendConfirmationMessage(ids,borrowId);//待办,消息
				}
			}
		}
		if(flag){
			ut.put("id", borrowId);
			if("2".equals(status)){
				ut.put("status", 4);
				getOptionDao().updateById(ut);
				userTaskService.finishTask(borrowId, "发放");
			}else{
				userTaskService.finishTask(borrowId, "领用");
			}
		}
		return flag;
	}
	
	@EscOptionLog(module=SystemModule.assetBorrow, opType=ESCLogOpType.DELETE, table="assets_material_borrow",option="删除名称为{name}的资产借用申请信息。")
	public boolean deleteById(String id){
		boolean flag = false;
		flag = getOptionDao().deleteByIds(id);
		if(flag){
			flag = assetBorrowDao.deleteAssetAllocationByBorrowId(id);
		}
		return	flag;
	}
	
	
	
	@EscOptionLog(module=SystemModule.ASSET, opType=ESCLogOpType.DELETES, table="assets_material_borrow",option="删除名称为{name}的资产借用申请信息。")
	public boolean deleteByIds(String ids){
		boolean flag = false;
		flag = getOptionDao().deleteByIds(ids);
		if(flag && StringUtils.isNotEmpty(ids)){
			String[] borrowIds = ids.split(",");
			for (String borrowId : borrowIds) {
				flag = assetBorrowDao.deleteAssetAllocationByBorrowId(borrowId);
			}
		}
		return flag;
	}
	
	private void addAssetsTrack(String borrowId){
		UTMap<String,Object> ut = new UTMap<String,Object>();
		UTMap<String,Object> track = new UTMap<String,Object>();
		UTMap<String,Object> assets = new UTMap<String,Object>();
		ut = assetBorrowDao.getAssetBorrowById(borrowId);
		if(null != ut){
			track.put("assetsId", ut.get("assetsId"));
			track.put("userId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
			track.put("departId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserOrgId());
//			track.put("departName", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserOrgName());
			track.put("changeRemark", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserOrgName()+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectName()+IAssetsTrackInfoDao.FIELD_ASSETSBACK);
			track.put("type", 1);
			track.put("changeType","归还");
			track.put("changeTime", ut.get("returnTime"));
			assetsTrackInfoService.add(track);
			
			//====修改资产责任人====
			assets.put("id", ut.get("assetsId"));
			assets.put("resUserId", "");
			assets.put("resDepartId", "");
			assets.put("assetStatus", "3");
			assetPhysicalService.updateById(assets);
			
			
		}
	}
	
   private void sendConfirmationMessage(String assetsId,String borrowId){
	   Map<String,Object> ut = assetBorrowDao.getById(borrowId);
	   if(null != ut){
		   Map<String,Object> borrow = assetBorrowDao.getById(borrowId);
		   Map<String,Object> param = new HashMap<String,Object>();				
		   param.put("signature", RoleUtils.ASSET_MANAGER);
		   String taskUserIds = userService.getUserIds(param);	
		   String title = "资产借用申请【"+borrow.get("title")+"/"+borrow.get("code")+"】归还提醒";
		   String content = "借用申请：【"+borrow.get("title")+"/"+borrow.get("code")+"】已归还，请进入系统进行确认！";
		   messageService.sendMessage(taskUserIds,title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
		   
		   
		   Map<String,Object> dataParam = new HashMap<String,Object>();
		   //点击待办事项，打开申请列表tab
		   dataParam.put("dataType", "0");
		   //生成待办任务
//		UTMap<String,Object> utMap = super.getById(businessRecordId);
		   userTaskService.addTaskByRole("借用申请【"+borrow.get("title")+"/"+borrow.get("code")+"】资产已归还，待您确认", assetsId + borrowId, "实物资产归还确认", TaskModel.AssetBorrow, RoleUtils.ASSET_MANAGER,dataParam);
	   }
	}

	@Override
	public List<UTMap<String, Object>> getRemindBorrowsList() {
		return assetBorrowDao.getRemindBorrowsList();
	}
	
	@CronTimeTask(description="每天凌晨定时更新当天需要提醒的资产借用信息",cron="0 0 0 * * ?")
//	@Override
	public void generate() {
		logger.info("每天凌晨定时更新当天需要提醒的资产借用信息！=========================================================");
		List<UTMap<String,Object>> remindBorrows = assetBorrowDao.getRemindBorrowsList();
		List<UTMap<String,Object>> returnBorrows = assetBorrowDao.getBorrowsReturnList();
		if(null != remindBorrows && remindBorrows.size() > 0){
			for (UTMap<String, Object> remindBorrow : remindBorrows) {
				String title = "资产借用申请【"+remindBorrow.get("title")+"/"+remindBorrow.get("code")+"】距归还日期还剩"+remindBorrow.get("remainDay")+"天，请注意归还！";
				String content = "您的借用申请:【"+remindBorrow.get("title")+"/"+remindBorrow.get("code")+"】到期归还提醒";
				messageService.sendMessage((String)remindBorrow.get("createUserId"),title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
				
			}
		}
		
		if(null != returnBorrows && returnBorrows.size() > 0){
			for (UTMap<String, Object> returnBorrow : returnBorrows) {
				String title = "资产借用申请【"+returnBorrow.get("title")+"/"+returnBorrow.get("code")+"】已到归还日期，请注意归还！";
				String content = "您的借用申请:【"+returnBorrow.get("title")+"/"+returnBorrow.get("code")+"】已到归还日期，详情请进入系统进行查看";
				messageService.sendMessage((String)returnBorrow.get("createUserId"),title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
				
			}
		}
		logger.info("成功定时更新当天需要提醒的资产借用信息！=========================================================");
	}

	@Override
	public boolean updateAllocationStatusByBorrowId(String borrowId,
			String status) {
		return assetBorrowDao.updateAllocationStatusByBorrowId(borrowId, status);
	}

	@Override
	public List<UTMap<String, Object>> getBorrowDetailByIdAndStatus(
			String borrowId) {
		return assetBorrowDao.getBorrowDetailByIdAndStatus(borrowId);
	}

	@Override
	public List<UTMap<String, Object>> getBorrowDetailByIds(String ids) {
		return assetBorrowDao.getBorrowDetailByIds(ids);
	}

	@Override
	public List<UTMap<String, Object>> getBorrowByStatusList(String assetId) {
		return assetBorrowDao.getBorrowByStatusList(assetId);
	}

	@Override
	public boolean updateAssetAllocation(Map<String, Object> param) {
		// TODO Auto-generated method stub
		return assetBorrowDao.updateAssetAllocation(param);
	}

	@Override
	public void getAssetsList(Map<String, Object> params, UTPageBean pageBean) {
		// TODO Auto-generated method stub
		assetBorrowDao.getAssetsList(params, pageBean);
	}

	@Override
	public void getAssetAllocationPage(Map<String, Object> param, UTPageBean pageBean) {
		// TODO Auto-generated method stub
		assetBorrowDao.getAssetAllocationPage(param, pageBean);
	}
}