package com.esc.oms.outsource.outperson.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTListResult;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.outsource.outperson.service.IOutSourcePersonChangeService;
import com.esc.oms.util.CommonUtils;

/**
 * 外包人员变更
 * @author jane
 *
 */
@Controller
@RequestMapping("/personChange")
public class OutSourcePersonChangeController extends BaseOptionController {

	@Resource
	private IOutSourcePersonChangeService outSourcePersonChangeService;
	
	@Override
	public IBaseOptionService optionService() {
		return outSourcePersonChangeService;
	}
	
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> map1){  
		Map<String,Object> cloneMap = CommonUtils.clone(map1);
		UTPageBean clonePageBean = CommonUtils.getPageBean(cloneMap);
		try{
			outSourcePersonChangeService.getPageInfo(clonePageBean, cloneMap);
			List<Map<String, Object>> list = clonePageBean.getRows();
			if(null != list && list.size() > 0 ){
				for (Map<String, Object> map : list) {
					if("1".equals(String.valueOf(map.get("changeType")))){
						map.put("changeType", "部门变更");
						map.put("changeAfter", map.get("detPartName"));
					}else{
						map.put("changeType", "级别变更");
					}
				}
			}
			outSourcePersonChangeService.generate();
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return clonePageBean;
    }
	
	
	@RequestMapping(value="getLevelsByUserId")
	@ResponseBody
	public UTListResult getLevelsByUserId(@RequestParam  Map<String, Object> param){	
		UTListResult result = new UTListResult();
		try{
			List<UTMap<String, Object>> list = outSourcePersonChangeService.getLevelsByUserId(String.valueOf(param.get("userId")));
			result.setRows(list);
			result.setTotal(list.size());
		}catch(Exception e){
			logger.error("Exception", e);
		}
		return result;
	}
	
	@RequestMapping(value = "leadingout")
	public void leadingout(@RequestParam Map<String, Object> map1,
			HttpServletRequest request,
			HttpServletResponse response) {
		Map<String,Object> cloneMap = CommonUtils.clone(map1);
		UTPageBean clonePageBean = CommonUtils.getPageBean(cloneMap);
		
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) cloneMap.get("outType"));
			Object info = cloneMap.get("params");
			JSONObject jsonBean = null;
			if(info != null) {
				jsonBean = JSONObject.fromObject(info);
			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = outSourcePersonChangeService.getListMaps(jsonBean);
			} else {
			// 根据条件 导出当前
			//if (UTExcel.EXCELOUTTYPE_NOW == outType) {
				// getpage
				outSourcePersonChangeService.getPageInfo(clonePageBean, jsonBean);
				data = clonePageBean.getRows();
			}
			response.setCharacterEncoding("UTF-8");
			
			if(null != data && data.size() > 0 ){
				for (Map<String, Object> map : data) {
					if("1".equals(String.valueOf(map.get("changeType")))){
						map.put("changeType", "部门变更");
						map.put("changeAfter", map.get("detPartName"));
					}else{
						map.put("changeType", "级别变更");
					}
				}
			}
			// 解析数据导出
			outSourcePersonChangeService.leadingout(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
}
