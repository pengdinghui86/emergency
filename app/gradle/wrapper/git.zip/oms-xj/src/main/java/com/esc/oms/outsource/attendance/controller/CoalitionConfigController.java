package com.esc.oms.outsource.attendance.controller;

import javax.annotation.Resource;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.esc.oms.outsource.attendance.service.ICoalitionConfigService;



/**
 * 联合考勤规则配置Controller
 * @author owner
 *
 */
@Controller
@RequestMapping("coalitionConfiglController")
public class CoalitionConfigController  extends BaseOptionController {
	
	@Resource
	private ICoalitionConfigService coalitionConfigService;
	
	@Override
	public IBaseOptionService optionService() {
		return coalitionConfigService;
	}

//	/**
//	 * 生成当前年的周末节假日数据
//	 */
//	@RequestMapping(value="initWeekend")  
//	@ResponseBody
//	public String getAgreementManpowerPage() {
//		try {
//			festivalService.initWeekend();
//		} catch (Exception e) {
//			logger.error("Exception", e);
//			return UTJsonUtils.getJsonMsg(false, "生成失败");
//		}
//		return UTJsonUtils.getJsonMsg(true, "生成成功");
//	}
	
}
