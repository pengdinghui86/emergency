package com.esc.oms.asset.inventory.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

public interface IAssetInventoryDao extends IBaseOptionDao{
	
	public boolean addAssetInventory(Map info);
	
	public boolean deleteAssetInventoryById(String id);
	
	public UTMap<String, Object> geyAssetInventoryById(String id);
	
	public List<UTMap<String, Object>> getAssetInventoryListMaps(Map param) ;
	
	public boolean updateInventoryStatusById(String id,String status, String curUserId);
	/**
	 * 批量确认
	 * @param id
	 * @return
	 */
	public boolean batchConfirm(String id);
	
	public boolean updateInventoryStatusByInventoryId(String id,String status);
	
	public void getAssetInventoryPageInfo(UTPageBean pageBean,Map param);
	
	public boolean deleteAssetInventoryByInventoryId(String id);
	
	public List<UTMap<String, Object>> getNowDateInventoryListMaps() ;
	
	public List<UTMap<String, Object>> getAssetsByInventoryIdListMaps(String inventoryId) ;

	public UTMap<String, Object> getInventoryByCode(String code);

	public UTMap<String, Object> getInventoruAsset(String inventoryId, String assetId);

	public boolean updateInverstoryAsset(Map<String, Object> info);
}
