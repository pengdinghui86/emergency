package com.esc.oms.asset.lowvalue.service.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.idgenerator.IDGenerationManager;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.excel.UTExcelValidate;
import org.esc.framework.utils.page.UTPageBean;
import org.hibernate.exception.DataException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.asset.lowvalue.dao.ILowvalueStorageDao;
import com.esc.oms.asset.lowvalue.service.ILowvalueInfoService;
import com.esc.oms.asset.lowvalue.service.ILowvalueStorageService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;

@Service
@Transactional
public class LowvalueStorageServiceImpl extends BaseOptionService implements ILowvalueStorageService{

	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private ILowvalueStorageDao dao;
	
	@Resource
	private ILowvalueInfoService infoService;
	
	@Resource
	private ISysParamService sysParamService;
	
	@Resource
	private ISysUserService userService;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return dao;
	}

	/**
	 * 添加
	 * @param info
	 * @return
	 */
	@EscOptionLog(module=SystemModule.ASSETS_LOWVALUE_STORAGE, opType=ESCLogOpType.INSERT, table="assets_lowvalue_storage", primaryKey="id={1.id}",option="新增物品入库记录：{1.name}/{1.code}")
	public boolean add(Map info){
		String isNew = info.get("isNew")==null?"":info.get("isNew").toString();			
		if("1".equals(isNew)){ //是新物品	
			info.put("code", IDGenerationManager.nextId("lowvalueInfo"));
			Map  infoMap = new HashMap<String,Object>();
			infoMap.putAll(info);
			double storageNum = Double.parseDouble(info.get("storageNum").toString());
			double unitPrice = Double.parseDouble(info.get("unitPrice") == null ? "0" : info.get("unitPrice").toString());	
			double storageAmount = 0;
			if(info.get("storageAmount") == null){
				storageAmount = storageNum*unitPrice;
				info.put("storageAmount", storageAmount);
			}else{
				storageAmount = Double.parseDouble(info.get("storageAmount").toString());
			}
			
			double totalNum = storageNum;
			double amount = storageAmount;
			double stockNum = storageNum;
			double stockAmount = storageAmount;
			
			infoMap.put("totalNum", totalNum);
			infoMap.put("amount", amount);
			infoMap.put("stockNum", stockNum);
			infoMap.put("stockAmount", stockAmount);
			infoMap.put("pendConfirmNum", 0);
			
			if(!infoService.add(infoMap)){
				throw new EscServiceException((String) infoMap.get("msg"));
			}else{
				info.put("infoId", infoMap.get("id"));
			}
		}else{ //不是新物品
			String infoId = (String) info.get("infoId");
			Map<String,Object> map = infoService.getById(infoId);
			double oldNum = Double.parseDouble(map.get("totalNum")==null?"0":map.get("totalNum").toString()); //总数量
			double oldAmount = Double.parseDouble(map.get("amount")==null?"0":map.get("amount").toString()); //总价
			double oldStockNum = Double.parseDouble(map.get("stockNum")==null?"0":map.get("stockNum").toString()); //库存数量
			double oldStockAmount = Double.parseDouble(map.get("stockAmount")==null?"0":map.get("stockAmount").toString());  //库存总价
						
			double storageNum = Double.parseDouble(info.get("storageNum").toString());
			double unitPrice = Double.parseDouble(info.get("unitPrice").toString());
			double storageAmount = 0;
			if(info.get("storageAmount")==null){
				storageAmount = storageNum*unitPrice;
				info.put("storageAmount", storageAmount);
			}else{
				storageAmount = Double.parseDouble(info.get("storageAmount").toString());
			}
			
			double totalNum = oldNum+storageNum;
			double amount = oldAmount+storageAmount;
			double stockNum = oldStockNum+storageNum;
			double stockAmount = oldStockAmount+storageAmount;
			
			map.put("totalNum", totalNum);
			map.put("amount", amount);
			map.put("stockNum", stockNum);
			map.put("stockAmount", stockAmount);
			
			infoService.updateById(map);
		}
		return super.add(info);			
	}
	

	@Override
	@EscOptionLog(module=SystemModule.ASSETS_LOWVALUE_STORAGE, opType=ESCLogOpType.UPDATE, table="assets_lowvalue_storage", primaryKey="id={1.id}",option="修改物品入库记录：{1.name}/{1.code}")	
	public boolean updateById(Map info){
		Map<String,Object> old = getById((String) info.get("id"));
		double oldStorageNum = Double.parseDouble(old.get("storageNum").toString());
		double oldStorageAmount = Double.parseDouble(old.get("storageAmount").toString());
		
		String infoId = (String) info.get("infoId");
		Map<String,Object> map = infoService.getById(infoId);
		double oldNum = Double.parseDouble(map.get("totalNum")==null?"0":map.get("totalNum").toString()); //总数量
		double oldAmount = Double.parseDouble(map.get("amount")==null?"0":map.get("amount").toString()); //总价
		double oldStockNum = Double.parseDouble(map.get("stockNum")==null?"0":map.get("stockNum").toString()); //库存数量
		double oldStockAmount = Double.parseDouble(map.get("stockAmount")==null?"0":map.get("stockAmount").toString());  //库存总价
					
		double storageNum = Double.parseDouble(info.get("storageNum").toString());
		double storageAmount = Double.parseDouble(info.get("storageAmount").toString());
		
		double totalNum = oldNum-oldStorageNum+storageNum;
		double amount = oldAmount-oldStorageAmount+storageAmount;
		double stockNum = oldStockNum-oldStorageNum+storageNum;
		double stockAmount = oldStockAmount-oldStorageAmount+storageAmount;
		double consumeNum = totalNum-stockNum;
		double consumeAmount = amount-stockAmount;
		
		map.put("totalNum", totalNum);
		map.put("amount", amount);
		map.put("stockNum", stockNum);
		map.put("stockAmount", stockAmount);
		map.put("consumeNum", consumeNum);
		map.put("consumeAmount", consumeAmount);
		
		map.put("unitPrice", info.get("unitPrice"));
		map.put("id", infoId);
		infoService.updateById(map);
		
		return super.updateById(info);			
	}
	
	@Override
	@EscOptionLog(module=SystemModule.ASSETS_LOWVALUE_STORAGE, opType=ESCLogOpType.DELETE, table="assets_lowvalue_storage",primaryKey="{1}", option="删除物品入库记录：{name}/{code}")		
	public boolean deleteById(String id){
		Map<String,Object> info = this.getById(id);
		String infoId = (String) info.get("infoId");
		
		//更新库存			
		Map<String,Object> map = infoService.getById(infoId);
		double infoNum = Double.parseDouble(map.get("totalNum")==null?"0":map.get("totalNum").toString()); //总数量
		double infoAmount = Double.parseDouble(map.get("amount")==null?"0":map.get("amount").toString()); //总价
		double infoStockNum = Double.parseDouble(map.get("stockNum")==null?"0":map.get("stockNum").toString()); //库存数量
		double infoStockAmount = Double.parseDouble(map.get("stockAmount")==null?"0":map.get("stockAmount").toString());  //库存总价
						
		double storageNum = Double.parseDouble(info.get("storageNum").toString());
		double storageAmount = Double.parseDouble(info.get("storageAmount").toString());
		boolean isDelete = false;
		//如果入库量与库存量相同，且该物品未被使用，则清除该物品
		if(infoNum==storageNum){
			String status = String.valueOf(map.get("status"));
			//未开始使用
			if("0".equals(status)){
				infoService.deleteById(infoId);
				isDelete = true;
			}else{//已开始使用，不允许删除
				throw new EscServiceException("该物品已被申请或分配，不允许删除！");
			}
		}			
		if(!isDelete){
			double totalNum = infoNum-storageNum;
			double amount = infoAmount-storageAmount;
			double stockNum = infoStockNum-storageNum;
			double stockAmount = infoStockAmount-storageAmount;
			double consumeNum = totalNum-stockNum;
			double consumeAmount = amount-stockAmount;
			
			map.put("totalNum", totalNum);
			map.put("amount", amount);
			map.put("stockNum", stockNum);
			map.put("stockAmount", stockAmount);
			map.put("consumeNum", consumeNum);
			map.put("consumeAmount", consumeAmount);
			
			infoService.updateById(map);
		}	
				
		return super.deleteById(id);			
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map param) {
		dao.getPageInfo(pageBean, param);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params){
		return dao.getListAll(params);
	}

	/**
	 * 从excel中导入数据
	 * @param filePath
	 * @param param
	 * @return
	 */
	@Override
	@EscOptionLog(module=SystemModule.ASSETS_LOWVALUE_STORAGE, opType=ESCLogOpType.LEADINGIN, option="导入物品入库记录")			
	public boolean leadingin(String filePath, Map<String, Object> param) throws Exception {
		List<UTMap<String, Object>> leadinginList = new ArrayList<UTMap<String,Object>>();
		boolean flag = true;
		// 根据路径 获取工作薄
		Sheet sheet = UTExcel.getSheets(filePath)[0];
		// 导入顺序
		String[] cellArray = null;
		String[] fileds = null;
		cellArray = new String[] { 
				"物品类别*", 
				"物品编号", 
				"物品名称*（长度：0-20）", 
				"是否初次入库*", 
				"品牌*（长度：0-20）", 
				"规格型号*（长度：0-30）",
				"单位*（长度：0-10）",
				"单价（元）（格式：最小0，最大100000000，最多俩位小数）",
				"入库数量*（格式：最小1，最大100000000，整数）", 
				"入库日期*（格式：yyyy/MM/dd）", 
				"接收人*" 
		};
		int[] lengthArr = {0, 0, 20, 0, 20, 30, 10, 0, 0, 0, 0};
		fileds = new String[] {
				ILowvalueStorageDao.FIELD_CATEGORY,
				ILowvalueStorageDao.FIELD_CODE,
				ILowvalueStorageDao.FIELD_NAME,
				ILowvalueStorageDao.FIELD_IS_NEW,
				ILowvalueStorageDao.FIELD_BRAND,
				ILowvalueStorageDao.FIELD_MODEL,
				ILowvalueStorageDao.FIELD_MEASURE,
				ILowvalueStorageDao.FIELD_UNIT_PRICE,
				ILowvalueStorageDao.FIELD_STORAGE_NUM,
				ILowvalueStorageDao.FIELD_STORAGE_TIME,
				ILowvalueStorageDao.FIELD_ACCEPT_USER_ID};
		int rowNum = sheet.getLastRowNum();
		int cellNum = fileds.length;
		//检查导入的字段标题
		try {
			List<String> realityCellllist=new ArrayList<String>();
			//标题在第一行
			Row rowtitle=sheet.getRow(0);
			for (int j = 0; j < cellNum;j++) {
				realityCellllist.add(rowtitle.getCell(j).getStringCellValue());
			}
			String[] array =new String[realityCellllist.size()];
			if(!UTExcel.excelValidateByCell(cellArray, realityCellllist.toArray(array))){
				flag = false;
			} else {
				flag = true;
			}
		} catch (Exception e) {
			flag = false;
		}
		
		if(!flag) {
			throw new EscServiceException("导入失败，请选择正确的模板！");
		}		
		StringBuilder error = new StringBuilder();
		Map<String,String> orgUserMap = getUserMap();		
		// 从excel第1行开始添加 数据，全部保存
		for (int i = 1; i <= rowNum; i++) {
			// 遍历excel
			Row row = sheet.getRow(i);
			UTMap<String, Object> map = new UTMap<String, Object>();
			for (int j = 0; j < cellNum; j++) {
				String cellValue = "";
				Cell cell = row.getCell(j);
				if (cell != null) {
					cell.setCellType(Cell.CELL_TYPE_STRING);
					cellValue = cell.getStringCellValue().trim();
					cellValue = StringUtils.isEmpty(cellValue) ? null : cellValue;
				}
				//检查为空的字段
				if(j == 0 || j == 2 || j == 3 || j == 4 || j == 5 || j== 6 || j == 8 || j==9 || j==10 ) {  //不能为空
					flag = StringUtils.isEmpty(cellValue) ? false : true;
					if (!flag) {
						error.append("Excel内容错误，行号为" + (i + 1) + "的【"+ cellArray[j] + "】列内容为空，请检查！" + "<br>");
					}
				}else{  //可以为空
					if(j==7){//单价
						cellValue = StringUtils.isEmpty(cellValue)?"0":cellValue;
					}else{
						cellValue = StringUtils.isEmpty(cellValue) ? null : cellValue;
					}					
				}
				if (cellValue != null) {
					//长度校验
					if (lengthArr[j] != 0 && cellValue.length() > lengthArr[j]){
						error.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "内容长度超出限制，请检查！" + "<br>");
					}
					//检查时间格式
					if(ILowvalueStorageDao.FIELD_STORAGE_TIME.equals(fileds[j])) {
						if (!CommonUtils.validateDate(cellValue)) {
							error.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "格式不正确，请检查！" + "<br>");
						}
					}
					
					//检查物品类别
					if(j==0 && cellValue != null){
						Map<String,String> categoryMap = getLowvalueCategoryMap();
						if(!categoryMap.containsValue(cellValue)){
							error.append("Excel内容错误，行号为" + (i + 1) + "的【"+ cellArray[j] + "】列，不存在该物品类别，请检查！" + "<br>");
						}
					}
					
					//数字格式转换
					if(j==7 && cellValue != null){	
						double d = 0;
						try{
							d = Double.parseDouble(cellValue);
							if (Double.compare(0d, d) == 1 || Double.compare(100000000d, d) == -1) {
								error.append("导入失败，行号为" + (i + 1) + "的【"+ cellArray[j] + "】列，数据格式错误，请检查！" + "<br>");
							}
							if (cellValue.indexOf(".") > -1 && cellValue.indexOf(".") != cellValue.length() - 1) {
								if(cellValue.substring(cellValue.indexOf(".") + 1).length() > 2) {
									error.append("导入失败，行号为" + (i + 1) + "的【"+ cellArray[j] + "】列，数据格式错误，请检查！" + "<br>");
								}
							}
						}catch(NumberFormatException e){
							error.append("导入失败，行号为" + (i + 1) + "的【"+ cellArray[j] + "】列，数据格式错误，请检查！" + "<br>");
						}
						
						//如果是旧品种，更新库存
						String isNew = map.get("isNew").toString();
						if(isNew!=null&&"否".equals(isNew)){
							String name = (String) map.get("name");
							String code = (String) map.get("code");
							
							if (StringUtils.isNotEmpty(name)) {
								Map<String,String> params = new HashMap<String,String>();
								params.put("name", name);
								if(!StringUtils.isEmpty(code)){
									params.put("code", code);
								}else{
									code = "";
								}
								
								params.put("accurateSearch","true");
								List<UTMap<String,Object>> list = infoService.getListAll(params);
								if(list!=null&&list.size()>0){
									if(list.size()>1){
										error.append("Excel内容错误，行号为" + (i + 1) + "的，存在多个【名称："+name+"，编号："+code+"】的物品，无法匹配，请检查！" + "<br>");
									}else{
										UTMap<String,Object> utMap = list.get(0);
										String srtUnitPrice = utMap.get("unitPrice").toString();
										if(srtUnitPrice.equals(String.valueOf(d))){//单价如果不一致，则会导致库存金额计算不正确
											map.put("infoId", utMap.get("id"));
										}else{
											error.append("Excel内容错误，行号为" + (i + 1) + "的，【名称："+name+"，编号："+code+"】的单价不匹配，请检查！" + "<br>");
										}										
									}
								}else{
									error.append("Excel内容错误，行号为" + (i + 1) + "的，未找到【名称："+name+"，编号："+code+"】的物品，请检查！" + "<br>");
								}
							}
						}
					}
					
					if(j==8 && cellValue != null){
						try{
							double d = Double.parseDouble(cellValue);
						}catch(Exception e){
							error.append("导入失败，行号为" + (i + 1) + "的【"+ cellArray[j] + "】列，数据格式错误，请检查！" + "<br>");
						}
					}
					//转换甲方人员
					if(j==10 && cellValue != null){		
						cellValue = cellValue.replaceAll("，", ",");
						String[] users = cellValue.split(",");
						for(String user: users){
							if(user.contains("/")){
								if(orgUserMap.containsKey(user)){
									String id = orgUserMap.get(user);
									cellValue = cellValue.replace(user, id);
								}else{
									error.append("Excel内容错误，行号为" + (i + 1) + "的【"+ cellArray[j] + "】列，不存在该人员【"+user+"】，请检查！" + "<br>");
								}
							}else{
								int num =0;
								for(String key:orgUserMap.keySet()){
									if(key.contains(user)){
										String id = orgUserMap.get(key);
										cellValue = cellValue.replace(user, id);
										num++;
									}
								}
								if(num==0){ //没有找到匹配的用户
									error.append("Excel内容错误，行号为" + (i + 1) + "的【"+ cellArray[j] + "】列，不存在该用户【"+user+"】！" + "<br>");
								}else if(num>1){ //名称重复，无法匹配
									error.append("Excel内容错误，行号为" + (i + 1) + "的【"+ cellArray[j] + "】列，存在重名的用户【"+user+"】，无法匹配，请加入用户编号！" + "<br>");
								}
							}						
						}			
					}
				}
				map.put(fileds[j], cellValue);
			}			
			leadinginList.add(map);
		}
		if (StringUtils.isNotEmpty(error.toString())) {
			throw new EscServiceException(error.toString());
		}
		//替换下拉的值
		Map<String, String> fieldAndParamType = new HashMap<String, String>();
		fieldAndParamType.put(ILowvalueStorageDao.FIELD_CATEGORY, "lowvalueCategory");
		fieldAndParamType.put(ILowvalueStorageDao.FIELD_IS_NEW, "YesNo");
		sysParamService.changeDataToParam(leadinginList, fieldAndParamType);
		
		//保存到数据库
		for (int i = 0; i<leadinginList.size(); i++) {
			UTMap<String, Object> leadingOne = leadinginList.get(i);
			leadingOne.put("sortCode", System.currentTimeMillis());// 导入内容的排序
			//往数据库插入一条数据
			try {
				flag = add(leadingOne);
			} catch (DataException e) {
				try {
		    		SQLException sqlException = e.getSQLException();
		    		if(sqlException != null) {
		    			String message = sqlException.getMessage();
		    			//如果提示是：Data too long for column 'name'，那么可以提示长度
		    			//如果是其他类型的sql错误，不进行处理
		    			if(message != null && message.contains("Data too long for column '")) {
		    				String filed = message.substring(message.indexOf("Data too long for column '") + 26, message.indexOf("' at r"));
		    				String filedName = "";
							//找到字段名称
		    				for (int j = 0; j < fileds.length; j++) {
								if(StringUtils.equals(filed, fileds[j])) {
									filedName = cellArray[j];
									break;
								}
							}
		    				//抛出提示
		    				throw new EscServiceException("Excel内容错误，行号为" + (i + 2) + "的" + filedName + "长度太长，请检查！");
		    			} else {
		    				throw e;
		    			}
		    		}
				} catch (EscServiceException e2) {
    				throw e2;
				} catch (Exception e2) {
					//继续抛出
    				throw e;
				}
			} catch (Exception e) {
				//其他异常
				throw e;
			}
			if (!flag) {
				String msg = leadingOne.get("msg") == null?"数据操作失败！":leadingOne.get("msg").toString();
				throw new EscServiceException(msg);
			}
		}
		return flag;
	}
	
	private Map<String,String> getLowvalueCategoryMap(){
		Map<String,String> map = new HashMap<String,String>();	
		UTMap<String,Object> utmap = sysParamService.getParamValues("lowvalueCategory");
		List<UTMap<String,Object>> list = (List<UTMap<String, Object>>) utmap.get("lowvalueCategory");
		if(list!=null&&list.size()>0){
			for(UTMap<String,Object> categoryMap:list){
				String value = (String) categoryMap.get("value");
				String name = (String) categoryMap.get("name");
				map.put(value, name);
			}
		}
		return map;
	}
	
	private Map<String,String> getUserMap(){
		Map<String,String> orgUsermap = new HashMap<String,String>();		
		Map<String,Object> param = new HashMap<String,Object>();
		param.put("state", "1");
		param.put("userType", "1");
		List<UTMap<String, Object>>  userList = userService.getUserBaseInfo(param);
		for(UTMap<String, Object> utmap : userList){		
			String name = (String) utmap.get("name");
			String code = (String) utmap.get("code");
			String id = (String)utmap.get("id");			
			orgUsermap.put(name+"/"+code, id);					
		}				
		return orgUsermap;
	}
	
	/**
	 * 导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	@Override
	public boolean leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String[] fileds = null;
		String tamlate= null;
		tamlate= "excelOutTamplate.lowvalueStorage";
		fileds = new String[] {
				ILowvalueStorageDao.FIELD_CATEGORY,
				ILowvalueStorageDao.FIELD_CODE,
				ILowvalueStorageDao.FIELD_NAME,
				ILowvalueStorageDao.FIELD_IS_NEW,
				ILowvalueStorageDao.FIELD_BRAND,
				ILowvalueStorageDao.FIELD_MODEL,
				ILowvalueStorageDao.FIELD_MEASURE,
				ILowvalueStorageDao.FIELD_UNIT_PRICE,
				ILowvalueStorageDao.FIELD_STORAGE_NUM,
				ILowvalueStorageDao.FIELD_STORAGE_AMOUNT,
				ILowvalueStorageDao.FIELD_STORAGE_TIME,
				ILowvalueStorageDao.FIELD_ACCEPT_USER_NAME,
				ILowvalueStorageDao.FIELD_CREATE_USER,
				ILowvalueStorageDao.FIELD_CREATE_TIME};
		if (null != data && !data.isEmpty()) {
			for (int i=0;i<data.size();i++) {
				UTMap<String, Object> item = (UTMap<String, Object>) data.get(i);
				item.put(ILowvalueStorageDao.FIELD_STORAGE_TIME, 
						CommonUtils.replaceAll((String) item.get(ILowvalueStorageDao.FIELD_STORAGE_TIME), "-", "/"));
				item.put(ILowvalueStorageDao.FIELD_CREATE_TIME, 
						CommonUtils.replaceAll((String) item.get(ILowvalueStorageDao.FIELD_CREATE_TIME), "-", "/"));
			}
		}
		//替换下拉的值
		Map<String, String> fieldAndParamType = new HashMap<String, String>();
		fieldAndParamType.put(ILowvalueStorageDao.FIELD_CATEGORY, "lowvalueCategory");
		fieldAndParamType.put(ILowvalueStorageDao.FIELD_IS_NEW, "YesNo");
		sysParamService.changeParamData(data, fieldAndParamType);
		
		return	UTExcel.leadingout( fileds, data, tamlate, request, response);
	}
	
	
}