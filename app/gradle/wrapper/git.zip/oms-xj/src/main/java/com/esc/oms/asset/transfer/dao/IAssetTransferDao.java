package com.esc.oms.asset.transfer.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

public interface IAssetTransferDao extends IBaseOptionDao{
	
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_TITLE = "title";
	public static final String  FIELD_ALLOCATIONDATE = "allocationDate";
	public static final String  FIELD_NEWDEPARTID = "newDepart";
	public static final String  FIELD_NEWCHARGEID = "newCharge";
	public static final String  FIELD_NEWPLACE = "newPlaceId";
	public static final String  FIELD_REASON = "reason";
	public static final String  FIELD_CREATEUSERID = "createUserId";
	public static final String  FIELD_CREATETIME = "createTime";
	public static final String  FIELD_STATUS = "status";
	public static final String  FIELD_ISAUDIT = "isAudit";
	public static final String  FIELD_OVERSTATUS = "overStatus";
	
	
	
	public boolean addRelation(Map info);
	

	/**
	 * 根据资产id删除备件联系
	 * @param id
	 * @return
	 */
	public boolean deleteAssetsById(String id);
	
	/**
	 * 查询备件
	 * */
	public List<UTMap<String, Object>> getAssetsById(String id) ;
	

	public List<UTMap<String, Object>> getAssetsList(Map param);
	

	/**
	 * 获取待审列表
	 * @param pageBean
	 * @param params
	 */
	public void getPendApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) ;

	/**
	 * 获取已审列表
	 * @param pageBean
	 * @param params
	 */
	public void getAlreadyApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) ;
	
	

	/** 
	 * 根据Id 获取 tittle
	* @Title: getTittle 
	* @Description: TODO 
	* @param id
	* @return String
	* @author smq
	* @date 2018年9月4日上午9:48:27
	*/ 
	public String getTittle(String id) ;
	
}
