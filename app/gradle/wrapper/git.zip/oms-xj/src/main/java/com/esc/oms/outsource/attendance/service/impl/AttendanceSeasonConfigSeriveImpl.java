package com.esc.oms.outsource.attendance.service.impl;

import com.esc.oms.outsource.attendance.dao.IAttendanceSeasonConfigDao;
import com.esc.oms.outsource.attendance.service.IAttendanceSeasonConfigService;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.BaseOptionService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Map;

@Service
public class AttendanceSeasonConfigSeriveImpl extends BaseOptionService implements IAttendanceSeasonConfigService {
    @Resource
    private IAttendanceSeasonConfigDao attendanceSeasonConfigDao;

    @Override
    public IBaseOptionDao getOptionDao() {
        return attendanceSeasonConfigDao;
    }

    @Override
    public boolean isExistYear(Map<String, Object> params) {
        return attendanceSeasonConfigDao.isExistYear(params);
    }


}
