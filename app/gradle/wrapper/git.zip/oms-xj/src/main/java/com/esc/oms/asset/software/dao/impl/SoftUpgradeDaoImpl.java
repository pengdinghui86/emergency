package com.esc.oms.asset.software.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.asset.software.dao.ISoftUpgradeDao;
import com.esc.oms.util.RoleUtils;

@Repository
public class SoftUpgradeDaoImpl extends BaseOptionDao implements
		ISoftUpgradeDao {

	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params), pageBean, null);
	}
	
	
	public String getSearchSql(Map params){
		StringBuilder sql = new StringBuilder();
		
		sql.append("SELECT asi.name as softwareId,asi.shortName as operation ,asu.id,asu.upVersion,"
				+ "asu.upDatee,asu.isOldDisabled,asu.reason,asu.explainn");
		sql.append(" FROM assets_software_upgrade asu ");
		sql.append(" LEFT JOIN assets_software_library asi ON asu.softwareId = asi.id");
		sql.append(" WHERE 1=1");
		
		//数据权限过滤
		if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR,RoleUtils.ASSET_MANAGER)){
			sql.append("  and asi.chargeId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' ");
		}
		/*
		if(params!=null && params.size()>0){		
			if(params.get("softwareId")!=null &&  StringUtils.isNotEmpty(params.get("softwareId").toString())){
				sql.append(" AND asu.softwareId = '"+params.get("softwareId").toString().trim()+"' ");
			}
		}*/
		if(params!=null && params.size()>0){		
			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
				sql.append(" AND asi.name like '%"+params.get("name").toString().trim()+"%' ");
			}
		}
		
		sql.append(" order by asu.createTime desc");
		return sql.toString();
	}
	
	
	@Override
	public List<UTMap<String, Object>> getSoftUpgradeList(Map param) {
		return super.getListBySql(getSearchSql(param));
	}
	

	@Override
	public String getTableName() {
		return "assets_software_upgrade";
	}


	@Override
	public List<UTMap<String, Object>> getSoftUpgradeListByUpDate(Map param) {
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT asu.id,asu.softwareId,asu.upVersion,asu.upDatee,asu.isOldDisabled,"
				+ "asu.disableDate,asu.reason,asu.explainn,asu.operation,asu.newebsite "
				+ " FROM assets_software_upgrade asu");
		sql.append(" WHERE asu.upDatee = '"+param.get("upDate").toString().trim()+"' ");
		
		return super.getListBySql(sql.toString());
	}

}
