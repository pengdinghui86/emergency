package com.esc.oms.asset.place.service.impl;

import com.esc.oms.asset.application.dao.IBusinessNumberDao;
import com.esc.oms.asset.place.dao.IAssetPlaceDao;
import com.esc.oms.asset.place.service.IAssetPlaceService;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.idgenerator.IDGenerationManager;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.*;


@Service
@Transactional
public class AssetPlaceServiceImpl extends BaseOptionService implements IAssetPlaceService {
	@Resource
	private IAssetPlaceDao assetPlaceDao;
	@Resource
	private IBusinessNumberDao businessNumberDao;

	@Override
	public IBaseOptionDao getOptionDao() {
		return assetPlaceDao;
	}

	/**
	 *  查询全部
	 * @return
	 */
	@Transactional(readOnly=true)
	public List<UTMap<String, Object>> getAll(){
		List<UTMap<String,Object>> list = getOptionDao().getAll();
		if(null != list && list.size() > 0){
			for (UTMap<String, Object> utMap : list) {
				if("-1".equals((String)utMap.get("parentId")) || StringUtils.isEmpty((String)utMap.get("id"))){
					utMap.put("parentName", "所有地点");
				}else{
					UTMap<String,Object> ut = assetPlaceDao.getById((String)utMap.get("parentId"));
					utMap.put("parentName", ut.get("name"));
				}
			}
		}
		return list;
	}
	
	@Override
	@EscOptionLog(module=SystemModule.ASSET, opType=ESCLogOpType.INSERT, table="assets_place", primaryKey="id={1.id}",option="新增名称为{name}的资产存放地点信息。")
	public boolean add(Map info){
		//校验名称是否已经存在
		Object name = info.get("name");
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("name", name);
		if (this.isExist(param)) {
			throw new EscServiceException("名称为【"+ name +"】的地址已存在！");
		}
		
		String isCabinet = (String) info.get("isCabinet");//是否机柜
		String isMachineRoom = (String) info.get("isMachineRoom");//是否机房
		if (StringUtils.equals("1", isMachineRoom) && StringUtils.equals("1", isCabinet)) {//不能同时为机柜和机房
			throw new EscServiceException("资产地址不允许既是机房又是机柜！");
		}
		String parentId = (String) info.get("parentId");
		UTMap<String,Object> ut = assetPlaceDao.getById(parentId);
		if (StringUtils.equals("1", isMachineRoom)) {//如果是机房，那么上级地址就不能是机房或者机柜
			if (StringUtils.isNotEmpty(parentId) && !StringUtils.equals("-1", parentId)) {
				if (StringUtils.equals("1", (String) ut.get("isMachineRoom")) || StringUtils.equals("1", (String) ut.get("isCabinet"))) {
					throw new EscServiceException("机房的上级地址不能是机房或者机柜！");
				}
			} 
		}
		if (StringUtils.equals("1", isCabinet)) {//机柜的上级地址只能是机房
			if (StringUtils.isNotEmpty(parentId) && !StringUtils.equals("-1", parentId)) {
				if (!StringUtils.equals("1", (String) ut.get("isMachineRoom"))) {
					throw new EscServiceException("机柜的上级地址只能是机房！");
				}
			}
/*			//机柜为实物资产，必须关联实物资产
			String isMaterial = (String) info.get("isMaterial");
			if (StringUtils.equals("0", isMaterial)) {
				throw new EscServiceException("机柜需要关联实物资产！");
			}*/
		}
		
		if (StringUtils.equals("1", (String) ut.get("isMachineRoom")) && !StringUtils.equals("1", isCabinet)) {
			throw new EscServiceException("机房的下级地址只能是机柜！");
		}
		
		/*Calendar cal = Calendar.getInstance();
		int year = cal.get(Calendar.YEAR);
		String code = businessNumberDao.saveOrUpdate("AT", String.valueOf(year), "%04d");
		info.put("code", code);*/
		info.put("code", IDGenerationManager.nextId("assetPlaceCode"));
		boolean flag = getOptionDao().add(info);
		List<Map> infos = new ArrayList<Map>();
		if (flag && StringUtils.equals("1", isCabinet)) {//如果是机柜，需要添加相应的u数据
			for (int i=1;i<=42;i++) {//定值42，序号从1开始到42
				Map<String, Object> cabinetU = new HashMap<String, Object>();
				cabinetU.put("orderNum", i);
				cabinetU.put("status", '0');
				cabinetU.put("assets_place_id", info.get("id"));
				infos.add(cabinetU);
			}
			assetPlaceDao.addAssetPlaceU(infos);
		}
		return	flag;
	}
	
	@Override
	@EscOptionLog(module=SystemModule.ASSET, opType=ESCLogOpType.DELETE, table="assets_place", primaryKey="{1}",option="删除名称为{name}的资产存放地点信息。")
	public boolean delete(Map info){
		return	getOptionDao().delete(info);
	}

	@Override
	@EscOptionLog(module=SystemModule.ASSET, opType=ESCLogOpType.UPDATE, table="assets_place", primaryKey="id={1.id}",option="修改名称为{name}的资产存放地点信息。")
	public boolean updateById(Map info){
//		if(!info.containsKey("id")){
//			throw new EscServiceException("根据id 修改map中不存在key=id");
//		}
		String id = (String) info.get("id");
		String name = (String) info.get("name");
		if (StringUtils.isNotEmpty(name)) {//名称不为空时为更新，更新的时候才做校验
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("name", name);
			List<UTMap<String, Object>> places = this.getListMaps(param);
			if (null != places && !places.isEmpty()) {//查询不为空时才校验
				if (places.size() > 1) {
					throw new EscServiceException("名称为【"+ name +"】的地址已存在！");
				}else {
					String oldId = (String) places.get(0).get("id");
					if (!StringUtils.equals(id, oldId)) {
						throw new EscServiceException("名称为【"+ name +"】的地址已存在！");
					}
				}
			}
		}
		return getOptionDao().updateById(info);
	}

	@Override
	public UTMap<String, Object> getIdByNameAndCode(String name, String code) {
		return assetPlaceDao.getIdByNameAndCode(name, code);
	}

	@Override
	public List<UTMap<String, Object>> getListByParentId(String parentId) {
		// TODO Auto-generated method stub
		return assetPlaceDao.getListByParentId(parentId);
	}
	
	@Override 
	public List<UTMap<String, Object>> getAssetPlaceUByPlaceId(String assetPlaceId){
		return assetPlaceDao.getAssetPlaceUByPlaceId(assetPlaceId);
	}

	@Override
	public List<UTMap<String, Object>> getUsableList(Map<String, Object> map) {
		List<UTMap<String, Object>> allUsable = assetPlaceDao.getUsableList(map);
		//当查询条件带开始u，代表要查询的是结束u，此时结束u必须为连续的机柜
		if(map.get("startU") != null && allUsable != null && allUsable.size() > 0){
			List<UTMap<String, Object>> endList = new ArrayList<>();
			int k = 0;
			for(int i = 0; i < allUsable.size(); i++){
				if(i == 0){
					k =Integer.valueOf(allUsable.get(i).get("orderNum")+"");
				}else{
					if(Integer.parseInt(allUsable.get(i).get("orderNum")+"") != ++k){
						break;
					}
				}
				endList.add(allUsable.get(i));
			}
			return endList;
		}
		return allUsable;
	}

}
