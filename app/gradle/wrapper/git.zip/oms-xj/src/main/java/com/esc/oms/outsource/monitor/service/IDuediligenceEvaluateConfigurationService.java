package com.esc.oms.outsource.monitor.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;

/**
 * 尽职调查评估配置
 * @author owner
 *
 */
public interface IDuediligenceEvaluateConfigurationService extends IBaseOptionService{
	
	/**
	 * 总评估或者修改总评估
	 * @param info
	 * @return
	 */
	public boolean evaluate(Map info);
	
	/**
	 * 关闭
	 * @param info
	 * @return
	 */
	public boolean close(Map info);
	
	/**
	 * 根据ID 获取（评估结果需要的数据接口）
	 * @param info
	 * @return
	 */
	public UTMap<String, Object> getByIdToAccessResult(String id);
	
	/**
	 * 导入
	 * @param filePath
	 * @param param
	 * @return
	 * @throws Exception
	 */
	public void leadingin(String filePath, Map<String, Object> param) throws Exception;
	/**
	 * 导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public void leadingout(List data, HttpServletRequest request,HttpServletResponse response) throws Exception;
	
}
