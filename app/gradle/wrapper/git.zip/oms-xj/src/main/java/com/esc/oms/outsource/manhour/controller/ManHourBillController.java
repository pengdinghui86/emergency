package com.esc.oms.outsource.manhour.controller;

import com.esc.oms.outsource.manhour.service.IManHourBillService;
import com.esc.oms.util.CommonUtils;

import net.sf.json.JSONObject;
import org.apache.log4j.Logger;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/**
 * 工时账单
 * @author lenovo
 *
 */
@Controller
@RequestMapping("outsource/manhourbill")
public class ManHourBillController {
	
	private static final Logger logger = Logger.getLogger(ManHourBillController.class);
	
	@Resource
	private IManHourBillService manHourBillService;

	/**
	 * 工时账单
	 * 
	 * @param param
	 * @return
	 */
	@RequestMapping(value = "billPage")
	@ResponseBody
	public Map<String, Object> billPage(@RequestParam Map<String, Object> param) {
		UTPageBean pageBean = CommonUtils.getPageBean(param);
		Map<String, Object> returnMap = new HashMap<String, Object>();
		try {
			manHourBillService.billPage(param, pageBean);
			List<String> evaluateNames = manHourBillService.formatBillEvaluateData(pageBean.getRows());
			returnMap.put("pageBean", pageBean);
			returnMap.put("evaluateNames", evaluateNames);
		} catch (Exception e) {
			logger.error("Exception", e);
		}
		return returnMap;
	}
	
	/**
	 * 工时账单
	 * 
	 * @param param
	 * @return
	 */
	@RequestMapping(value = "getApprovedPage")
	@ResponseBody
	public Map<String, Object> getApprovedPage(@RequestParam Map<String, Object> param) {
		UTPageBean pageBean = CommonUtils.getPageBean(param);
		Map<String, Object> returnMap = new HashMap<String, Object>();
		try {
			manHourBillService.getApprovedPage(param, pageBean);
			List<String> evaluateNames = manHourBillService.formatBillEvaluateData(pageBean.getRows());
			returnMap.put("pageBean", pageBean);
			returnMap.put("evaluateNames", evaluateNames);
		} catch (Exception e) {
			logger.error("Exception", e);
		}
		return returnMap;
	}
	

	@ResponseBody
	@RequestMapping(value="auditBill", method =RequestMethod.POST)  
    public String auditBill(@RequestBody Map<String, Object> param){  
    	try{
    		manHourBillService.auditBill(param);
    	}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "操作成功");
    }
	
	@RequestMapping(value = "leadingoutBill/{outType}/{isAudit}")
	public void leadingoutBill(@ModelAttribute("outType") Integer outType, @ModelAttribute("isAudit") Integer isAudit, @RequestParam Map<String, Object> param, HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean pageBean = CommonUtils.getPageBean(param);
		List<UTMap<String, Object>> data = null;
		try {
			Map queryParam = UTMap.mapObjToString(JSONObject.fromObject(param.get("params")));
			if(isAudit == 1) {
				// 根据条件 导出全部
				if (UTExcel.EXCELOUTTYPE_ALL == outType) {
					// getAll
					data = manHourBillService.getApprovedList(queryParam);
				} else {
					// 根据条件 导出当前
					manHourBillService.getApprovedPage(queryParam, pageBean);
					data = pageBean.getRows();
				}
			} else if(isAudit == 0) {
				// 根据条件 导出全部
				if (UTExcel.EXCELOUTTYPE_ALL == outType) {
					// getAll
					data = manHourBillService.billList(queryParam);
				} else {
					// 根据条件 导出当前
					manHourBillService.billPage(queryParam, pageBean);
					data = pageBean.getRows();
				}
			}
			manHourBillService.formatBillEvaluateData(data);
			// 解析数据导出
			response.setCharacterEncoding("UTF-8");
			manHourBillService.leadingoutBill(data, request, response);
		}catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
}
