package com.esc.oms.outsource.attendance.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTListResult;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.outsource.attendance.service.IAttendanceService;
import com.esc.oms.outsource.attendance.service.IUserConfigService;
import com.esc.oms.util.CommonUtils;
import com.fasterxml.jackson.databind.ObjectMapper;

import net.sf.json.JSONObject;



/**
 * 考勤
 * @author owner
 *
 */
@Controller
@RequestMapping("attendanceController")
public class AttendanceController  extends BaseOptionController {
	
	@Resource
	private IAttendanceService attendanceService;
	
	//用户考勤配置dao
	@Resource
	private IUserConfigService userConfigService;
	
	@Override
	public IBaseOptionService optionService() {
		return attendanceService;
	}

	/**
	 * 根据考勤规则以及节假日配置生成当天的考勤数据
	 */       
	@RequestMapping(value="initCurrentDateAttendance")  
	@ResponseBody
	public String initCurrentDateAttendance() {
		try {
			attendanceService.initCurrentDateAttendance();
		} catch (EscServiceException e) {
			logger.error("EscServiceException", e);
			return UTJsonUtils.getJsonMsg(false, e.getMessage());
		} catch (Exception e) {
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "生成失败");
		}
		return UTJsonUtils.getJsonMsg(true, "生成成功");
	}
	
	/**
	 * 重新计算所有考勤数据的考勤工时
	 */       
	@RequestMapping(value="updateAllAttTime")  
	@ResponseBody
	public String updateAllAttTime() {
		try {
			attendanceService.updateAllAttTime();
		} catch (EscServiceException e) {
			logger.error("EscServiceException", e);
			return UTJsonUtils.getJsonMsg(false, e.getMessage());
		} catch (Exception e) {
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "操作失败");
		}
		return UTJsonUtils.getJsonMsg(true, "操作成功");
	}
	
	/**
	 * 签到前检查当前时间是否已经迟到，迟到要填迟到原因
	 */       
	@RequestMapping(value="checkDateinStyle")  
	@ResponseBody
	public UTMap<String, Object> checkDateinStyle() {
		UTMap<String, Object> map = new UTMap<String, Object>();
		try {
			map.put("att", true);
			//检查是否有考勤规则
			UTMap<String, Object> userConfig = userConfigService.getUserConfigByUserId(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
			if(userConfig == null){
				map.put("success", false);
				map.put("msg", "当前用户没有配置考勤规则，无法进行考勤！");
				return map;
			}
			// 考勤方式:(1.确定时间，2.不确定时间),如果考勤方式是确定时间，需要做是否要生成考勤数据的校验
			if("1".equals(userConfig.get("attendanceDateType").toString())){
				//获取当天的考勤数据
				UTMap<String, Object> att = attendanceService.getCurUserAttendance(UTDate.getCurDate());
				
				if(att == null){
					map.put("att", false);
					map.put("attMsg", "当天不在你的考勤范围之内，确定要进行考勤？");
					map.put("success", true);
					return map;
				}
			}
			
			
			//检查当前时间是否签到异常(//是否迟到 1:迟到;//-1:未签到;0:正常)
			int dateinStyle = attendanceService.checkDateinStyle(userConfig, new Date());
			map.put("dateinStyle", dateinStyle);
			map.put("success", true);
		} catch (Exception e) {
			logger.error("Exception", e);
		}
		return map;
	}
	
	/**
	 * 根据考勤规则和日期手动生成对应用户的考勤数据,这种情况用于用户节假日过来加班，手动生成考勤数据
	 */
	@RequestMapping(value="mnulAddAttendance")  
	@ResponseBody
	public String mnulAddAttendance(HttpServletRequest request,
			HttpServletResponse response) {
		UTMap<String, Object> userConfig = userConfigService.getUserConfigByUserId(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
		try {
			attendanceService.mnulAddAttendance(new Date(),userConfig, request.getRemoteAddr());
		} catch (EscServiceException e) {
			logger.error("EscServiceException", e);
			return UTJsonUtils.getJsonMsg(false, e.getMessage());
		} catch (Exception e) {
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "签到失败");
		}
		return UTJsonUtils.getJsonMsg(true, "签到成功");
	}
	
	/**
	 * 签退前检查当前时间是否已经早退，早退要填早退原因
	 */       
	@RequestMapping(value="checkDateoutStyle")  
	@ResponseBody
	public UTMap<String, Object> checkDateoutStyle() {
		UTMap<String, Object> map = new UTMap<String, Object>();
//		map.put("success", false);
		try {
			UTMap<String, Object> userConfig = userConfigService.getUserConfigByUserId(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
			if(userConfig == null){
				map.put("success", false);
				map.put("msg", "当前用户没有配置考勤规则，无法进行考勤！");
				return map;
			}
			//检查当前时间是否签到异常(//是否迟到 1:迟到;//-1:未签到;0:正常)
			int dateoutStyle = attendanceService.checkDateoutStyle(userConfig, new Date());
			map.put("dateoutStyle", dateoutStyle);
			map.put("success", true);
		} catch (Exception e) {
			logger.error("Exception", e);
		}
		return map;
	}
	
	/**
	 * 根据考勤规则以及节假日配置生成当天的考勤数据
	 */
	@RequestMapping(value="getCurUserAttendance")  
	@ResponseBody
	public UTMap<String, Object> getCurUserAttendance() {
		UTMap<String, Object> map = new UTMap<String, Object>();
		map.put("curDateTime", new Date().getTime());
		Date date = new Date();
		try {
			map.put("attendance", attendanceService.getCurUserAttendance(UTDate.dateToDateString(date)));
			map.put("isAcrossDay", attendanceService.isAcrossDay(date));
		} catch (Exception e) {
			logger.error("Exception", e);
		}
		return map;
	}
	
	
	
	/**
	 * 签到
	 */
	@RequestMapping(value="userDatein")  
	@ResponseBody
	public String userDatein(@RequestBody Map<String,Object> map1,HttpServletRequest request,
			HttpServletResponse response) {
		
		Map<String,Object> param = CommonUtils.clone(map1);
		try {
			param.put("dateinIp", CommonUtils.getRemoteAddr(request));
			attendanceService.userDatein(param);
		} catch (EscServiceException e) {
			logger.error("EscServiceException", e);
			return UTJsonUtils.getJsonMsg(false, e.getMessage());
		} catch (Exception e) {
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "签到失败");
		}
		return UTJsonUtils.getJsonMsg(true, "签到成功");
	}
	
	/**
	 * 签退
	 */
	@RequestMapping(value="userDateout")  
	@ResponseBody
	public String userDateout(@RequestBody Map<String,Object> map1,HttpServletRequest request,
			HttpServletResponse response) {
		Map<String,Object> cloneMap = CommonUtils.clone(map1);
		try {
			cloneMap.put("dateoutIp", CommonUtils.getRemoteAddr(request));
			attendanceService.userDateout(cloneMap);
		} catch (EscServiceException e) {
			logger.error("EscServiceException", e);
			return UTJsonUtils.getJsonMsg(false, e.getMessage());
		} catch (Exception e) {
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "签退失败");
		}
		return UTJsonUtils.getJsonMsg(true, "签退成功");
	}
	
	/**
	 * 获取考勤日历数据
	 */
//	@RequestMapping(value="getAttendanceCalendarDate")  
//	@ResponseBody
//	public List getAttendanceCalendarDate(@RequestBody Map<String,Object> param) {
//		return attendanceService.getAttendanceCalendarDate(param);
//	}
	
	/**
	 * 获取考勤日历数据
	 */
//	@RequestMapping(value="getAttendanceCalendarDate")  
//	@ResponseBody
//	public UTMap<String, Object> getAttendanceCalendarDate(@RequestBody Map<String,Object> param) {
//		UTMap<String, Object> map = new UTMap<String, Object>();
//		try {
//			map.put("rows", attendanceService.getAttendanceCalendarDate(param));
//		} catch (Exception e) {
//			logger.error("Exception", e);
//		}
//		return map;
//	}
	
	/**
	 * 获取考勤日历数据
	 */
	@RequestMapping(value="getAttendanceCalendarDate")
	@ResponseBody
	public UTListResult getAttendanceCalendarDate(@RequestParam  Map<String, Object> param){
//		logger.info("执行默认的条件查询方法");
//		return UTListResult.getListResult(optionService().getListMaps(param));
		UTListResult result = new UTListResult();
		try{
			List<UTMap<String, Object>> list = attendanceService.getAttendanceCalendarDate(param);
			result.setRows(list);
			result.setTotal(list.size());
		}catch(Exception e){
			logger.error("Exception", e);
		}
		return result;
	}
	
	/**
	 * 修改考勤异常原因
	 */
	@RequestMapping(value="updateReason")  
	@ResponseBody
	public String updateReason(@RequestBody Map<String,Object> param,HttpServletRequest request,
			HttpServletResponse response) {
		try {
			attendanceService.updateReason(param);
		} catch (EscServiceException e) {
			logger.error("EscServiceException", e);
			return UTJsonUtils.getJsonMsg(false, e.getMessage());
		} catch (Exception e) {
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "操作失败");
		}
		return UTJsonUtils.getJsonMsg(true, "操作成功");
	}
	
	/**
	 * 修改考勤签到签退时间
	 */
	@RequestMapping(value="updateAttTime")  
	@ResponseBody
	public String updateAttTime(@RequestBody Map<String,Object> param,HttpServletRequest request,
			HttpServletResponse response) {
		try {
			attendanceService.updateAttTime(param,true);
		} catch (EscServiceException e) {
			logger.error("EscServiceException", e);
			return UTJsonUtils.getJsonMsg(false, e.getMessage());
		} catch (Exception e) {
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "操作失败");
		}
		return UTJsonUtils.getJsonMsg(true, "操作成功");
	}
	
	/**
	 * 获取个人考勤工时统计数据
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAttHours")  
    @ResponseBody
    public UTPageBean getAttHours(@RequestParam Map<String, Object> params){  
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			attendanceService.getAttHours(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	/**
	 * 获取联合考勤工时统计数据
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getCoalitionAttHours")  
    @ResponseBody
    public UTPageBean getCoalitionAttHours(@RequestParam Map<String, Object> params){  
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			attendanceService.getCoalitionAttHours(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	/**
	 * 常规考勤统计（供应商）
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getSupplierConventional")  
    @ResponseBody
    public UTPageBean getSupplierConventional(@RequestParam Map<String, Object> params){  
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			attendanceService.getSupplierConventional(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	/**
	 * 常规考勤统计（部门）
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getOrgConventional")  
    @ResponseBody
    public UTPageBean getOrgConventional(@RequestParam Map<String, Object> params){  
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			attendanceService.getOrgConventional(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	/**
	 * 导出
	 * @param param
	 * @param utPageBean
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "leadingout")
	public void leadingout(@RequestParam Map<String, Object> param, HttpServletRequest request, HttpServletResponse response) {
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = null;
			if(info != null) {
				jsonBean = JSONObject.fromObject(info);
			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = attendanceService.getListMaps(jsonBean);
			} else {
				attendanceService.getPageInfo(utPageBean, jsonBean);
				data = utPageBean.getRows();
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			attendanceService.leadingout(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	/**
	 * 导出
	 * @param param
	 * @param utPageBean
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "leadingoutAttendanceHours")
	public void leadingoutAttendanceHours(@RequestParam Map<String, Object> param,
			 HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		Map<String, Object> copym = CommonUtils.clone(param);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			Integer outType = Integer.parseInt((String) copym.get("outType"));
			ObjectMapper mapper = new ObjectMapper();  
			Map params = mapper.readValue(copym.get("params").toString(),Map.class);//转成map
//			Map params = UTMap.transStringToMap(param.get("params").toString());
//			JSONObject jsonBean = null;
//			if(info != null) {
//				jsonBean = JSONObject.fromObject(info);
//			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = attendanceService.getAllAttHours(params);
			} else {
				attendanceService.getAttHours(utPageBean, params);
				data = utPageBean.getRows();
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			attendanceService.leadingoutAttHours(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	/**
	 * 导出联合考勤统计
	 * @param param
	 * @param utPageBean
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "leadingoutCoalitionAttHours")
	public void leadingoutCoalitionAttHours(@RequestParam Map<String, Object> param,
			 HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		Map<String, Object> copym = CommonUtils.clone(param);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			Integer outType = Integer.parseInt((String) copym.get("outType"));
			ObjectMapper mapper = new ObjectMapper();  
			Map params = mapper.readValue(copym.get("params").toString(),Map.class);//转成map
//			Map params = UTMap.transStringToMap(param.get("params").toString());
//			JSONObject jsonBean = null;
//			if(info != null) {
//				jsonBean = JSONObject.fromObject(info);
//			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = attendanceService.getAllCoalitionAttHours(params);
			} else {
				attendanceService.getCoalitionAttHours(utPageBean, params);
				data = utPageBean.getRows();
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			attendanceService.leadingoutCoalitionAttHours(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	/**
	 * 导出常规考勤统计（供应商）
	 * @param param
	 * @param utPageBean
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "leadingoutAttSupplierConventional")
	public void leadingoutAttSupplierConventional(@RequestParam Map<String, Object> param,
			 HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		Map<String, Object> copym = CommonUtils.clone(param);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			Integer outType = Integer.parseInt((String) copym.get("outType"));
			ObjectMapper mapper = new ObjectMapper();  
			Map params = mapper.readValue(copym.get("params").toString(),Map.class);//转成map
//			Map params = UTMap.transStringToMap(param.get("params").toString());
//			JSONObject jsonBean = null;
//			if(info != null) {
//				jsonBean = JSONObject.fromObject(info);
//			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = attendanceService.getAllSupplierConventional(params);
			} else {
				attendanceService.getSupplierConventional(utPageBean, params);
				data = utPageBean.getRows();
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			attendanceService.leadingoutAttSupplierConventional(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	/**
	 * 导出常规考勤统计（部门）
	 * @param param
	 * @param utPageBean
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "leadingoutAttOrgConventional")
	public void leadingoutAttOrgConventional(@RequestParam Map<String, Object> param,
			HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		Map<String, Object> copym = CommonUtils.clone(param);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			Integer outType = Integer.parseInt((String) copym.get("outType"));
			ObjectMapper mapper = new ObjectMapper();  
			Map params = mapper.readValue(copym.get("params").toString(),Map.class);//转成map
//			Map params = UTMap.transStringToMap(param.get("params").toString());
//			JSONObject jsonBean = null;
//			if(info != null) {
//				jsonBean = JSONObject.fromObject(info);
//			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = attendanceService.getAllOrgConventional(params);
			} else {
				attendanceService.getOrgConventional(utPageBean, params);
				data = utPageBean.getRows();
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			attendanceService.leadingoutAttOrgConventional(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	
}
