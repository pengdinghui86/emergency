package com.esc.oms.asset.repair.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.asset.repair.service.IAssetRepairRecordService;
import com.esc.oms.util.CommonUtils;


/**
 *	维修记录登记Controller
 */
@Controller
@RequestMapping("repairRec")
public class AssetRepairRecordController extends BaseOptionController {

	@Resource
	private IAssetRepairRecordService assetRepairRecordService;
	
	
	@Override
	public IBaseOptionService optionService() {
		return assetRepairRecordService;
	}
	
	
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			assetRepairRecordService.getPageInfo(pageBean, params);
			
			List<Map<String, Object>> list = pageBean.getRows();
			
			if(null != list && list.size() > 0 ){
				for (Map<String, Object> map : list) {
					if(1 == (Integer)map.get("result")){
						map.put("result", "维修成功");
					}else{
						map.put("result", "维修失败");
					}
				}
			}
			
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	
	@RequestMapping(value="/saveOrUpdate",method=RequestMethod.POST)  
    @ResponseBody
    public String saveorupdate(@RequestBody Map<String,Object> map){  
    	String id = (String)map.get("id");
    	try{
	    	if(id == null){
	    		assetRepairRecordService.add(map);
	    	}else{
	    		assetRepairRecordService.updateById(map);
	    	}
    	}catch(EscServiceException e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false,e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "操作成功");
    }
	

	
	@RequestMapping(value="getById")
	@ResponseBody
	public UTMap<String, Object> defgetById(@RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = null;
    	try{
    		map = assetRepairRecordService.getRepairRecordById((String)param.get("id"));
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return map;
	}
	
	
}
