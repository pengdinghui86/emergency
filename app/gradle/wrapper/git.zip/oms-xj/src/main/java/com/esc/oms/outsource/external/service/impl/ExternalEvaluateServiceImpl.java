package com.esc.oms.outsource.external.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.exception.EscServiceException;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.upload.annotation.UploadQueryMarks;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.external.dao.IExternalEvaluateConfigurationDao;
import com.esc.oms.outsource.external.dao.IExternalEvaluateDao;
import com.esc.oms.outsource.external.dao.IExternalEvaluateTemplateDao;
import com.esc.oms.outsource.external.dao.IExternalResultEvaluateDao;
import com.esc.oms.outsource.external.service.IExternalEvaluateService;
import com.esc.oms.system.templateconfiguration.dao.ITemplateConfigurationDetailDao;
import com.esc.oms.system.templateconfiguration.dao.ITemplateConfigurationDetailDeputyResultDao;
import com.esc.oms.system.templateconfiguration.service.ITemplateConfigurationDetailDeputyService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;

/**
 * 非驻场外包评估
 * @author owner
 *
 */
@Service
@Transactional
public class ExternalEvaluateServiceImpl extends BaseOptionService implements IExternalEvaluateService{
	
	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private IExternalEvaluateDao dao;
	
	@Resource
	private IExternalEvaluateTemplateDao externalEvaluateTemplateDao;
	
	//模板配置详情dao
	@Resource
	private ITemplateConfigurationDetailDao detailDao;
	
	//非驻场外包评估配置Dao
	@Resource
	private IExternalEvaluateConfigurationDao externalEvaluateConfigurationDao;
	
	//模板配置从属数据操作Service接口
	@Resource
	private ITemplateConfigurationDetailDeputyService templateConfigurationDetailDeputyService;
	
	//模板配置从属数据结果操作dao接口
	@Resource
	private ITemplateConfigurationDetailDeputyResultDao templateConfigurationDetailDeputyResultDao;

	//代办任务
	@Resource
	private IUserTaskService userTaskService;
	
	//检查结果
	@Resource
	private IExternalResultEvaluateDao externalResultEvaluateDao;
	@Override
	public IBaseOptionDao getOptionDao() {
		return dao;
	}

	/**
	 * 添加
	 * @param info
	 * @return
	 */
//	@UploadAddMark//aop拦截绑定上传文件的数据关系
	@EscOptionLog(module = SystemModule.externalEvaluate, opType = ESCLogOpType.INSERT, table = "outsourc_external_evaluate", option = "新增非驻场外包评估配置编号为{externalEvaluateConfigId}的非驻场外包评估。")
	public boolean add(Map info){
		super.add(info);
		return true;
	}
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		UTMap<String, Object> result = super.getById(id);
		String externalEvaluateTemplateId = result.get("externalEvaluateTemplateId")+"";//非驻场外包评估配置模板id
//		String id = result.get("id")+"";
		result.put("treeData", templateConfigurationDetailDeputyService.getDetailsDeputy(externalEvaluateTemplateId, id));
		return result;
	}
	
	/**
	 * 修改
	 * @param info
	 * @return
	 */
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	@EscOptionLog(module = SystemModule.externalEvaluate, opType = ESCLogOpType.UPDATE, table = "outsourc_external_evaluate", option = "更新非驻场外包评估配置编号为{externalEvaluateConfigId}的非驻场外包评估。")
	public boolean updateById(Map info){
		String id = info.get("id")+"";//非驻场外包评估配置模板id
		Map existMap = new HashMap();
		existMap.put("id", id);
		if(!dao.isExist(existMap)){
			throw new EscServiceException("当前数据已经不存在，请刷新页面重新操作！");
		}
		info.put("evaluateTime", UTDate.getCurDateTime());//评估时间
		info.put("submitTime", UTDate.getCurDateTime());//提交时间
		info.put("status", 1);//评估状态
		info.put("submitter", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());//提交人
		List<Map> resultList = new ArrayList<Map>();
		List<Map> list= (List<Map>)info.get("treeData");
		String moduleTemplateConfigurationId = info.get("externalEvaluateTemplateId")+"";
//		String evaluator = info.get("id")+"";
		CommonUtils.setTemplateConfigurationDetailDeputyResult(moduleTemplateConfigurationId, id, list, resultList);
		//先删除
		templateConfigurationDetailDeputyResultDao.deleteByModuleTemplateConfigurationIdEvaluator(moduleTemplateConfigurationId, id);
		if(!resultList.isEmpty()){
			//后添加
			templateConfigurationDetailDeputyResultDao.adds(resultList);
			
		}
//		String externalEvaluateConfigId = info.get("externalEvaluateConfigId")+"";//非驻场外包评估配置模板id
//		UTMap<String, Object> externalEvaluateTemplate = externalEvaluateTemplateDao.getById(moduleTemplateConfigurationId);
//		String isSingle = externalEvaluateTemplate.get("isSingle")+"";//是否单一数据，1：是，0：否，默认否
//		Map param = new HashMap();
//		param.put("externalEvaluateConfigId", externalEvaluateConfigId);//非驻场外包评估配置模板id
		//查询非驻场外包评估对应模板下的所有非驻场外包评估数据
//		List<UTMap<String, Object>> accessEvaluateList = dao.getListMaps(param);
//		boolean temp = false;
//		for (UTMap<String, Object> accessEvaluate : accessEvaluateList) {
//			String accessEvaluateId = accessEvaluate.get("id") + "";
//			String externalEvaluateTemplateId = accessEvaluate.get("externalEvaluateTemplateId") + "";
//			if(id.equals(accessEvaluateId)){//不判断当前数据
//				continue;
//			}
//			//当前评估的数据模板是单一数据，则把改模板下其它人的评估数据都删除
//			if("1".equals(isSingle) && externalEvaluateTemplateId.equals(moduleTemplateConfigurationId)){
//				dao.delete(accessEvaluate);
//			}else{
//				String status = accessEvaluate.get("status") + "";//非驻场外包评估状态 
//				//存在待评估状态的数据
//				if(!temp && "0".equals(status)){
//					temp = true;
////					break;
//				}
//			}
//		}
		//只标识供应商非驻场外包评估模板对应的个人非驻场外包评估是否已经在评估，待评估：0，评估中：1，已评估：2
//		int accessEvaluateConfigurationStatus = 0;
//		if(temp){
//			accessEvaluateConfigurationStatus = 1;
//		}else{
//			accessEvaluateConfigurationStatus = 2;
//		}
//		Map accessEvaluateConfiguration = new HashMap();
//		//修改此状态用户判断评估配置可不可以修改或删除
//		accessEvaluateConfiguration.put("evaluateStatus", accessEvaluateConfigurationStatus);
//		accessEvaluateConfiguration.put("id", externalEvaluateConfigId);
//		//修改对应非驻场外包评估配置的状态
//		externalEvaluateConfigurationDao.updateBy(accessEvaluateConfiguration, "id");
		userTaskService.finishTask(id);//完成代办任务
		//在过程评估后需要将评估人加入到评估配置的评估人字段中
//		CommonUtils.setConfigurationEvaluator(externalEvaluateConfigurationDao,info.get("externalEvaluateConfigId").toString());
		Map param = new HashMap();
		param.put("externalEvaluateConfigId", info.get("externalEvaluateConfigId").toString());
//		List<UTMap<String,Object>> lists = externalResultEvaluateDao.getListMaps(param);
		UTMap<String, Object> map = externalResultEvaluateDao.getListMaps(param).get(0);
		String evaluator = map.get("evaluator") == null?"":map.get("evaluator").toString();
		String curUserId = EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId();
		//评估人中是否已经包含
		if(evaluator.indexOf(curUserId) == -1){
			if(evaluator.length() == 0){
				map.put("evaluator", curUserId)	;
			}else{
				map.put("evaluator", (evaluator + "," + curUserId));
			}
			externalResultEvaluateDao.updateById(map);
		}
		return super.updateById(info);
	}
	
	
//	private void setTemplateConfigurationDetailDeputyResult(String moduleTemplateConfigurationId, String evaluator, List<Map> list, List<Map> resultList){
//		if(list == null){
//			return;
//		}
//		for (Map item : list) {
//			Map info = new HashMap();
//			if(item.get("result") != null){
//				String result = item.get("result").toString();
//				info.put("moduleTemplateConfigurationId", moduleTemplateConfigurationId);
//				String templateConfigurationDetailDeputyId = item.get("id").toString();
//				info.put("evaluator", evaluator);
//				info.put("templateConfigurationDetailDeputyId", templateConfigurationDetailDeputyId);
//				info.put("result", result);
//				resultList.add(info);
//			}
//			
//			String type = item.get("type").toString();//类型，1：填空，2：单选，3：多选，0：是配置项
//			if(("2".equals(type) || "3".equals(type)) && item.get("options") != null){//如果是单选或者多选，保存子配置项
//				List<Map> options = (List<Map>)item.get("options");
//				setTemplateConfigurationDetailDeputyResult(moduleTemplateConfigurationId,evaluator,options,resultList);
//			}
//			if(item.get("children") != null){//如果存在子节点数据
//				List<Map> children = (List<Map>)item.get("children");
//				setTemplateConfigurationDetailDeputyResult(moduleTemplateConfigurationId,evaluator,children,resultList);
//			}
//		}
//	}
	
	@Override
	public boolean deleteById(String id) {
		detailDao.deleteByTemplateConfigurationId(id);
		return super.deleteById(id);
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map param) {
		dao.getPageInfo(pageBean, param);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	@UploadQueryMarks
	public List<UTMap<String, Object>> getListAll(Map params){
		return dao.getListAll(params);
	}

}
