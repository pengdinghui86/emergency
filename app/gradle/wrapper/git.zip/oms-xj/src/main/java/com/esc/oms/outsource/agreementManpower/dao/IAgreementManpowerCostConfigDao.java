package com.esc.oms.outsource.agreementManpower.dao;


import org.esc.framework.persistence.dao.IBaseOptionDao;

/**
 * 人力外包人员费用配置
 * @author smq
 * @date   2016-2-24 上午10:55:10
 */
public interface IAgreementManpowerCostConfigDao extends IBaseOptionDao {

	public static final String  FIELD_ID = "id";
	public static final String  FIELD_MANPOWERID = "manpowerId";
	public static final String  FIELD_CATEGORY = "category";//人员类型
	public static final String  FIELD_LEVEL = "level";//人员级别
	public static final String  FIELD_MONTHLYFEE= "monthlyFee";//月费用
	public static final String  FIELD_ISLOSSCODT = "isLossCodt";//流失是否扣费
	

	public static final String  FIELD_AGREEMENTID = "agreementId";


}
