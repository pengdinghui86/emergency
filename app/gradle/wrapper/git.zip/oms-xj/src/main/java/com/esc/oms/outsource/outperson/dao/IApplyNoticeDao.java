package com.esc.oms.outsource.outperson.dao;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;


public interface IApplyNoticeDao extends IBaseOptionDao{

	public static final String  FIELD_ID = "id";
	public static final String  FIELD_ROLE = "role";
	public static final String  FIELD_PERSONID= "personId";
	public static final String  FIELD_PERSONNAME= "personName";
	public static final String  FIELD_SENDTIME = "sendTime";
	public static final String  FIELD_SENDTITLE = "sendTitle";
	public static final String  FIELD_CONTEXT = "context";
	public static final String  FIELD_SENDTYPE = "sendType";
	public static final String  FIELD_CREATEUSERID = "createUserId";
	public static final String  FIELD_NOTICETYPE = "noticeType";//通知类型 enter exit quit 
	public static final String  FIELD_APPLYID = "applyId";//通知类型 enter exit quit 
	
}
