package com.esc.oms.outsource.outperson.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.dict.dao.ISysParamDao;
import org.esc.framework.dict.util.UTParamTransform;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.idgenerator.IDGenerationManager;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.poi.tempfrom.tempoption.IFormModelData;
import org.esc.framework.security.dao.ISysUserDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.workflow.service.IWorkflowCode;
import org.esc.framework.workflow.service.IWorkflowEngine;
import org.esc.framework.workflow.utils.bpmn.FlowForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.outperson.dao.IApplyEnterDao;
import com.esc.oms.outsource.outperson.dao.IApplyExitDao;
import com.esc.oms.outsource.outperson.dao.IApplyQuitDao;
import com.esc.oms.outsource.outperson.service.IApplyCommonService;
import com.esc.oms.outsource.outperson.service.IApplyExitService;
import com.esc.oms.outsource.outperson.service.IApplyNoticeService;
import com.esc.oms.outsource.outperson.service.IOutSourcePersonConfigService;
import com.esc.oms.outsource.outperson.service.IPersonOptionService;
import com.esc.oms.supplier.project.dao.IProjectInfoDao;
import com.esc.oms.supplier.supplieremp.dao.ISupplierEmpDao;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;
import com.esc.oms.util.FunctionEnum.WorkRecordType;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.TaskModel;

@Service
@Transactional
public class ApplyExitServiceImpl extends BaseOptionService implements IApplyExitService,IFormModelData{
	protected Logger logger = LoggerFactory.getLogger(getClass());
	@Resource
	private IApplyExitDao applyExitDao;

	@Resource
	private ISysParamDao paramDao;
	@Resource
	private ISysUserDao userDao;
	@Resource
	private IOutSourcePersonConfigService personConfigService;
	@Resource
	private IApplyNoticeService noticeService;
	@Resource
	private IUserTaskService userTaskService;
	@Resource
	private IWorkflowEngine workflowEngine;
	@Resource
	private MessageSend messageSend;
	@Resource
	private ISupplierEmpDao supplierEmpDao;
	@Resource
	private IProjectInfoDao projectInfoDao;
	@Resource
	private IApplyQuitDao quitDao;
	@Resource
	private IPersonOptionService personOptionService;
	
	private static final String STATUS_NOT_SUBMIT = "1";	// 未提交 待提交
	private static final String STATUS_APPROVAL  = "2";	//待审批  
	private static final String STATUS_AUDITING = "3";	// 审批中  
	private static final String STATUS_FINISH = "4";	// 审批完成  待通知
	private static final String STATUS_REJECT = "5";	// 驳回
	private static final String STATUS_STOP  = "6";	// 被终止
	private static final String STATUS_CONFIG  = "7";	// 退场确认
	private static final String STATUS_OVER  = "8";	// 完成
	
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return applyExitDao;
	}
	
	public String workflowCode() {
		return IWorkflowCode.OUTSOURCE_PERSON_EXIT;
	}
	
	public String tempCode() {
		return "formTemp.exitApplyTemp";
	}
	//新增
	
	@EscOptionLog(module=SystemModule.outsourcePersonExit, opType=ESCLogOpType.INSERT, table="outsourc_apply_exit_info",
	primaryKey="id={1.id}",option="新增外包人员退场信息：{1.exitUserName}的退场申请记录")
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean add(Map info){
		info.put("createUserId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
		String userId=info.get("exitUserId").toString();
		String exitUserName= userDao.getById(userId).get("name").toString();
		info.put("exitUserName", exitUserName);
		
		if (!info.containsKey("applyNumber")) {
			String exitApplyNumber=	IDGenerationManager.nextId("exitApplyNumber").toString();
			info.put("applyNumber",exitApplyNumber);
		}
		
		if (!info.containsKey("status")) {
			info.put("status",STATUS_NOT_SUBMIT);
		}
		Map<String, Object> map=new HashMap<String, Object>();
		map.put("exitUserId", userId);
		map.put("supplierId", info.get("supplierId").toString());
		if(isExist(map)){
			throw new EscServiceException("外包人员"+exitUserName+"的退场申请已存在");
		}
		
		Map<String, Object> map2=new HashMap<String, Object>();
		map2.put("quitUserId", userId);
		map2.put("supplierId", info.get("supplierId").toString());
		if(quitDao.isExist(map2)){
			throw new EscServiceException("外包人员"+exitUserName+"已提交离职申请");
		}
		return super.add(info);
	}
	
	//根据id 修改
	
	@EscOptionLog(module=SystemModule.outsourcePersonExit, opType=ESCLogOpType.UPDATE, table="outsourc_apply_exit_info", 
	primaryKey="id={1.id}",	option="修改外包人员退场信息：{1.exitUserName}的退场申请记录")
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean updateById(Map info) {
		String id=info.get("id").toString();
		UTMap<String, Object> oldInfo =applyExitDao.getById(id, "exitUserId","supplierId");
		String newExitUserId=info.get("exitUserId").toString();
		String newSupplierId=info.get("supplierId").toString();
		if(!StringUtils.equals(newExitUserId, oldInfo.get("exitUserId").toString())
				||
		!StringUtils.equals(newSupplierId, oldInfo.get("supplierId").toString())){
			String exitUserName= userDao.getById(newExitUserId).get("name").toString();
			Map<String, Object> map=new HashMap<String, Object>();
			map.put("exitUserId", newExitUserId);
			map.put("supplierId",newSupplierId);
			if(isExist(map)){
				throw new EscServiceException("外包人员"+exitUserName+"的退场申请已存在");
			}
			Map<String, Object> map2=new HashMap<String, Object>();
			map.put("quitUserId", newExitUserId);
			map.put("supplierId",newSupplierId);
			if(quitDao.isExist(map2)){
				throw new EscServiceException("外包人员"+exitUserName+"已提交离职申请");
			}

			info.put("exitUserName", exitUserName);
		}
		
		return super.updateById(info);
	}

	
	@EscOptionLog(module=SystemModule.outsourcePersonExit, opType=ESCLogOpType.DELETE, table="outsourc_apply_exit_info", 
	primaryKey="id={1}",	option="删除外包人员退场申请记录")
	public boolean deleteById(String id){
		return applyExitDao.deleteByIds(id);
	}

	
	@EscOptionLog(module=SystemModule.outsourcePersonExit, opType=ESCLogOpType.DELETES, table="outsourc_apply_exit_info", 
	primaryKey="id={1}",	option="删除外包人员退场申请记录")
	public boolean deleteByIds(String ids){
		return applyExitDao.deleteByIds(ids);
	}

	
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		UTMap<String, Object> result = super.getById(id);
		return result;
	}
	
	//提交
	
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public void submit(Map<String,Object> map) {
		map.put("status", STATUS_APPROVAL);
		boolean flog=true;
		if(map.get("id") == null){
			flog=add(map);
    	}
		else{
			flog=updateById(map);
    	}
		String recordId =map.get("id").toString();
		//启动流程
		runInstanceId(recordId);
	}
	
	// 启动流程实例设置
	private void runInstanceId(String recordId){
		//启动流程实例
		String supplierId=applyExitDao.getById(recordId, "supplierId").get("supplierId").toString();
		Map<String, Object> formMap = new HashMap<String, Object>();
		//formMap.put(FlowForm.FormItemValue.TDGYS ,supplierId);
		formMap.put(FlowForm.FormItemValue.TDGYS ,supplierId);
		String workflowInstanceId = workflowEngine.runInstance(IWorkflowCode.OUTSOURCE_PERSON_EXIT, recordId, formMap);
	
	//	String workflowInstanceId = workflowEngine.runInstance(IWorkflowCode.OUTSOURCE_PERSON_EXIT, recordId);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("processId", workflowInstanceId);
		applyExitDao.updateById(map);
		//如果没有流程 则结束流程审批状态
		if(StringUtils.isEmpty(workflowInstanceId)){
			onFinish(recordId);
		}
	}
	

	//审批流程驳回
	public void onReject(String recordId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("status", STATUS_REJECT);
		applyExitDao.updateById(map);
		Map<String, Object> info=	applyExitDao.getById(recordId, "createUserId","exitUserName");
		if(info==null||info.get("createUserId")==null){
			return;
		}
		String userName=info.get("exitUserName").toString();
		messageSend.sendMessage(info.get("createUserId").toString(), 
				"外包人员【"+userName+"】退场申请终止提醒", 
				"外包人员【"+userName+"】的退场申请已被终止，请知悉！详情请进入系统查看", MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
	
	}

	//审批流程结束
	public void onFinish(String recordId) {
		try {
			//	修改申请状态
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("id", recordId);
			map.put("status", STATUS_FINISH);
			applyExitDao.updateById(map);
			//删除 退出的用户
			UTMap<String, Object> applyInfo=applyExitDao.getById(recordId, "exitUserId","exitDate","exitReason","remark", "isQuit");
			Map<String, String> infoMap=	UTMap.mapObjToString(applyInfo);
			String userId=infoMap.get("exitUserId");
			String exitDate=infoMap.get("exitDate");
			String reason=infoMap.get("exitReason");
			UTParamTransform statusTransform2 = new UTParamTransform(paramDao,"exitReasonList");
			reason=StringUtils.isNotEmpty(reason)?statusTransform2.value2Name(reason):"";
			String remark=infoMap.get("remark");
			personOptionService.deletePersonService(userId, exitDate, reason, remark, WorkRecordType.EXITFACTORY);
			//发送退场通知
			sendNodice(recordId);
			
		} catch (Exception e) {
			logger.error("Exception",e);
		}
	}

	//流程终止不进行 外包人员退场信息退出状态的修改
	public void onTerminate(String recordId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("status", STATUS_STOP);
		applyExitDao.updateById(map);
		
		Map<String, Object> info=	applyExitDao.getById(recordId, "createUserId","exitUserName");
		if(info==null||info.get("createUserId")==null){
			return;
		}
		String userName=info.get("exitUserName").toString();
		messageSend.sendMessage(info.get("createUserId").toString(), 
				"外包人员【"+userName+"】退场申请终止提醒", 
				"外包人员【"+userName+"】的退场申请已被终止，请知悉！详情请进入系统查看", MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
	
	}

	//审批流程 操作到某一个节点
	public void optionNode(String workflowCode, String recordId,
			String nodeName, String linkName) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("status", STATUS_AUDITING);
		applyExitDao.updateById(map);
	}

	public void sendTask(String workflowName, String recordId,
			String nodeName, String userId) {
		String userName=applyExitDao.getById(recordId, IApplyExitDao.FIELD_EXITUSERNAME).get( IApplyExitDao.FIELD_EXITUSERNAME).toString();
		//获取供应商名称
		userTaskService.addTaskByUserId("人员【"+userName+"】退场申请待您审批", recordId, nodeName, TaskModel.outSourcePersonExit, userId);
	
	}

	//查询外包人员退场信息列表
	public List<UTMap<String, Object>> searchInfo(Map<String, Object> params) {
		return applyExitDao.searchInfo(params);
	}
	
	//查询外包人员退场信息列表
	public void searchInfoPage( UTPageBean pageBean,Map<String, Object> params) {
		 applyExitDao.searchInfoPage(pageBean, params);
	}
	
	//查询外包人员退场信息 待审列表
	public void getPendApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) {
		applyExitDao.getPendApprovalPageInfo(pageBean, params);
	}

	//查询外包人员退场信息 已审列表
	public void getAlreadyApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) {
		applyExitDao.getAlreadyApprovalPageInfo(pageBean, params);
	}
	
	//导出
	public void exportData(List<UTMap<String, Object>> recordList, HttpServletRequest request, HttpServletResponse response)
		throws Exception {

		UTParamTransform statusTransform = new UTParamTransform(paramDao,"personExitStatus");
		UTParamTransform statusTransform2 = new UTParamTransform(paramDao,"exitReasonList");
		String[] fileds = new String[] {
				IApplyExitDao.FIELD_EXITUSERNAME,
				"createTime",
				"supplierName",
				IApplyEnterDao.FIELD_DEPARTMENTNAME,
				IApplyExitDao.FIELD_EXITDATE,
				IApplyExitDao.FIELD_EXITREASON,
				"remark",
				"status"
			 };
		String tamlate="excelOutTamplate.outSourcePersonExitLeadOut";

		Map<String, Object> p=new HashMap<String, Object>();
		for (Object info : recordList) {
			Map<String, Object> map=(Map<String, Object>) info;
			//时间转换
			Object userName	=	map.get(IApplyExitDao.FIELD_EXITUSERNAME).toString();
			Object orgName=map.get(IApplyEnterDao.FIELD_DEPARTMENTNAME);
			Object EXITDATE=map.get(IApplyExitDao.FIELD_EXITDATE);
			String EXITDATESTR=EXITDATE!=null?UTDate.getDateStr(EXITDATE.toString(), UTDate.DATE_FORMAT):"";

			Object EXITREASON=map.get(IApplyExitDao.FIELD_EXITREASON);
			String oString=orgName!=null?orgName.toString().replaceAll("!","/"):null;
			String REASON =statusTransform2.value2Name(EXITREASON.toString());
			String status=map.get(IApplyQuitDao.FIELD_STATUS)!=null?map.get(IApplyQuitDao.FIELD_STATUS).toString():"1";
			String statusStr=statusTransform.value2Name(status);

			map.put(IApplyExitDao.FIELD_EXITDATE,CommonUtils.replaceAll(EXITDATESTR, "-", "/"));
			map.put("createTime",CommonUtils.replaceAll((String)map.get("createTime"), "-", "/"));
			map.put(IApplyEnterDao.FIELD_DEPARTMENTNAME,oString );
			map.put(IApplyExitDao.FIELD_EXITUSERNAME,userName );
			map.put(IApplyExitDao.FIELD_STATUS,statusStr );
			map.put(IApplyExitDao.FIELD_EXITREASON,REASON );
		}
		
		UTExcel.leadingout( fileds, recordList, tamlate, request,response);
		
	}
	
	//======================退场信息审核通过后 
//
//	//1.信息与 用户，供应商人，外包人员同步 删除(逻辑删除)
//	private void deleteSysSupplierUser(String applyId){
//		UTMap<String, Object> applyInfo=applyExitDao.getById(applyId);
//		Map<String, String> infoMap=	UTMap.mapObjToString(applyInfo);
//		String userId=infoMap.get("exitUserId");
//		String exitDate=infoMap.get("exitDate");
//		String reason=infoMap.get("exitReason");
//		String remark=infoMap.get("remark");
//		personOptionService.deletePersonService(userId, exitDate, reason, remark, WorkRecordType.EXITFACTORY);
//		//获取参与的项目
//
//		
//		//删除用户(逻辑删除)
//		Map<String, String> userInfo=new HashMap<String, String>();
//		userInfo.put("id", userId);
//		userInfo.put("state",ESCDataState.CANCEL.getValue().toString());
//		userDao.updateById(userInfo);
//		
//		Map<String, String> empInfo=new HashMap<String, String>();
//		empInfo.put("userId", userId);
//		empInfo.put("state",ESCDataState.CANCEL.getValue().toString());
//		empInfo.put("endDate", exitDate);
//		empInfo.put(ISupplierEmpDao.FIELD_ISVALID,ESCDataState.CANCEL.getValue().toString());
//		empDao.updateBy(empInfo, "userId");
//		
//		Map<String, String> person=	new HashMap<String, String>();
//		person.put("userId", userId);
//		person.put("state",ESCDataState.CANCEL.getValue().toString());
//		personDao.updateBy(person, "userId");
//
//		//注销系统用默认权限
//		personConfigService.cancelConfigByUserId(userId);
//		//释放项目人力资源
//		projectResService.releaseByProjectAndUser(null,userId);
//		//删除用户考勤规则接口：
//		userConfigService.deleteByUserId( userId);
//		//合同服务团队释放
//		agreementTeamService.release(userId);
//
//		//添加轨迹
//		UTParamTransform statusTransform2 = new UTParamTransform(paramDao,"exitReasonList");
//		String reasonName=statusTransform2.value2Name(reason);
//		workrecordDao.add(userId, "供应商人员退场", exitDate,null, remark, reasonName, WorkRecordType.EXITFACTORY);
//		
//	}

	@Override
	public boolean cancelConfigByUserId(Map<String, Object> param) {
		Map baseInfo=(Map) ((param == null) ? false : param.containsKey("baseInfo")? param.get("baseInfo"):null);
		if(baseInfo != null)
		{
			String applyId=baseInfo.get("applyId").toString();
	   		String submit=baseInfo.get("issubmit").toString();
	   		if(StringUtils.equals(submit, "1")){
	   			List configsInfo =(List) ((param == null) ? false : param.containsKey("configInfo")? param.get("configInfo"):null);
				boolean flog=	personConfigService.cancelConfigByUserId(configsInfo);
	   			//保存并提交
	   			Map<String,Object> applyInfo=new HashMap<String, Object>();
	   			applyInfo.put("id",applyId);
	   			applyInfo.put("confimUserId",EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
	   			applyInfo.put("confimDate",UTDate.getCurDate());
	   			applyInfo.put("status",ApplyExitServiceImpl.STATUS_OVER);
	   			super.updateById(applyInfo);
	   			//发送通知
	   		//	sendNodice(applyId);
	    		return flog;
	   		}else{
	   			//保存信息 但不提交
	   			Map<String,Object> applyInfo=new HashMap<String, Object>();
	   			applyInfo.put("id",applyId);
	   			applyInfo.put("confimUserId",EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
	   			applyInfo.put("confimDate",UTDate.getCurDate());
	   			super.updateById(applyInfo);
				List configsInfo =(List) (param.containsKey("configInfo")? param.get("configInfo"):null);
				return	personConfigService.cancelConfigByUserId(configsInfo);
	   		}
		}
		else {
			return false;
		}
	}
	
	//3.信息配置后发通知
	private void sendNodice(String applyId) {
		noticeService.sendApplyNoticeInfo(applyId, IApplyCommonService.APPLY_TYPE_EXIT);
		Map<String,Object> applyInfo=new HashMap<String, Object>();
			applyInfo.put("id",applyId);
			applyInfo.put("status",ApplyExitServiceImpl.STATUS_CONFIG);
			super.updateById(applyInfo);
	}

	@Override
	public Map<String, Object> setModelData(String recordId) {
		Map<String, String> info=  UTMap.mapObjToString(applyExitDao.getById(recordId));
		Map<String, Object> model= new HashMap<String, Object>();

		UTParamTransform statusTransform2 = new UTParamTransform(paramDao,"exitReasonList");
		
		String exitUserName=info.get("exitUserName")!=null?info.get("exitUserName"):"";
		String idCode=info.get("idCode")!=null?info.get("idCode"):"";
		String phone=info.get("phone")!=null?info.get("phone"):"";
		String orgName=info.get("departmentName")!=null?info.get("departmentName").replaceAll("!", "/"):"";
		String exitDate=StringUtils.isNotEmpty(info.get("exitDate"))?UTDate.chinaDate( info.get("exitDate")):"";
		String exitReason=info.get("exitReason")!=null?statusTransform2.value2Name(info.get("exitReason")):"";
		String supplierName=info.get("supplierName")!=null?info.get("supplierName"):""; 
		String applyNumber=info.get("applyNumber")!=null?info.get("applyNumber"):UTDate.getCurDate();
		String userId=info.get("exitUserId")!=null?info.get("exitUserId"):""; 
		String mainProject="";
		boolean mj=false;
		String mjCancelDate="";
		String mjCancelPerson="";
		boolean wl=false;
		String wlCancelPerson="";
		String wlCancelDate="";
		
		//获取 现阶段 人员入场日期和 所属主项目
		Map<String, String> empInfo=	 UTMap.mapObjToString(supplierEmpDao.getSupplierEmpDetailedByUserId(userId));
		String enterDate=empInfo!=null&&empInfo.size()>0&&StringUtils.isNotEmpty(empInfo.get("exitFactoryDate"))?empInfo.get("exitFactoryDate"):"";//入场日期
		String mainProjectId=empInfo.get("mainProjectId")!=null?empInfo.get("mainProjectId"):"";
		if(StringUtils.isNotEmpty(mainProjectId)){
			mainProject=projectInfoDao.getById(mainProjectId, "name").get("name").toString();
		}
		
		//获取人员配置情况
		List<UTMap<String, Object>> configs= personConfigService.getPersonConfig(userId);
		for (UTMap<String, Object> utMap : configs) {
			String itemName=utMap.get("itemName").toString();
			String cancelPerson=utMap.get("cancelPerson")!=null?utMap.get("cancelPerson").toString():"";
			String cancelDate=utMap.get("cancelDate")!=null&&StringUtils.isNotEmpty(utMap.get("cancelDate").toString())?UTDate.chinaDate(utMap.get("cancelDate").toString()):"";
			boolean isConfig=utMap.get("isConcel")!=null&&(StringUtils.equals(utMap.get("isConcel").toString(), "1"))?true:false;
			if(itemName.indexOf("门禁")>-1){

				mj=isConfig;
				if(!mj){
					continue;
				}
				//获取人员配置属性
				mjCancelPerson	=cancelPerson;
				mjCancelDate=cancelDate;
			}
			if(itemName.indexOf("网络")>-1){
				wl=isConfig;
				if(!wl){
					continue;
				}
				wlCancelPerson=cancelPerson;
				wlCancelDate=cancelDate;
			}
		}
		
		//model.put(IFormModelData.TEMP_FILE_NAME, exitUserName+"入场申请单");
		model.put("applyNumber", applyNumber);
		model.put("exitUserName", exitUserName);
		model.put("supplierName", supplierName);
		model.put("idCode", idCode);
		model.put("projectName",mainProject);
		model.put("phone", phone);
		model.put("orgName", orgName);
		model.put("enterDate",  UTDate.chinaDate(enterDate)  );
		model.put("exitDate",  exitDate);
		
		model.put("sq", true);
		model.put("mj", mj);
		//模板中定义的 为  mjOpenDate，mjOpenPerson，wlOpenPerson，wlOpenDate
		//实际存放值为 取消经办人和取消日期
		model.put("mjOpenDate", mjCancelDate);
		model.put("mjOpenPerson", mjCancelPerson);
		model.put("wl", wl);
		model.put("wlOpenPerson", wlCancelPerson);
		model.put("wlOpenDate",wlCancelDate);
		model.put("exitReason", exitReason);
		return model;
	}
	
	@Override
	public List<UTMap<String, Object>> getUserBaseInfo(Map<String, Object> param){
		return this.applyExitDao.getUserBaseInfo(param);
	}
}