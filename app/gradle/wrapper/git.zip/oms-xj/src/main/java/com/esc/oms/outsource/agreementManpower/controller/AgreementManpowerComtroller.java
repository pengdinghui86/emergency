package com.esc.oms.outsource.agreementManpower.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.service.IBaseOptionService;

import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTListResult;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.outsource.agreementManpower.dao.IAgreementManpowerInfoDao;
import com.esc.oms.outsource.agreementManpower.service.IAgreementManpowerInfoService;
import com.esc.oms.util.CommonUtils;



/**
 * 人力外包合同 配置
 * @author smq
 * @date   2016-2-24 上午10:50:04
 */
@Controller
@RequestMapping("agreementManpower")
public class AgreementManpowerComtroller  extends BaseOptionController {
	@Resource
	private IAgreementManpowerInfoService agreementManpowerInfoService;
	
	@Override
	public IBaseOptionService optionService() {
		return agreementManpowerInfoService;
	}

	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAgreementManpowerPage")  
    @ResponseBody
    public UTPageBean getAgreementManpowerPage(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			if(!setDataPrower(params)){
				pageBean.setRows(new ArrayList<UTMap<String, Object>>());
				return pageBean;
			}
			agreementManpowerInfoService.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	/**
	 * 保存合同配置信息
	 * param中 ： costconfig:合同费用配置，vacationConfig 折算配置
	 * @param param
	 * @return
	 */
	@RequestMapping("saveAgreementManpowerInfo")
	@ResponseBody
	public JSONObject saveAgreementManpowerInfo(@RequestBody Map<String, Object> map1){
		Map<String,Object> param = CommonUtils.clone(map1);
		String msg="操作成功";
	
		List vacationConfigs =(List) (param.containsKey("vacationConfigs")? param.get("vacationConfigs"):null);
		List costConfigs =(List) (param.containsKey("costConfigs")? param.get("costConfigs"):null);
		Map baseInfoMap=(Map) (param.containsKey("baseConfig")? param.get("baseConfig"):null);
		boolean flog=true;
		try {
			 flog=agreementManpowerInfoService.saveAgreementManpowerInfo(baseInfoMap, costConfigs, vacationConfigs);
			 msg=flog?"操作成功":"操作失败";
		} catch (EscServiceException e) {
			logger.error("EscServiceException",e);
			flog=false;
			msg=e.getMessage();
		} catch (Exception e) {
			logger.error("EscServiceException",e);
			flog=false;
			msg="操作失败";
		}
		return UTJsonUtils.getMsgJson(flog, msg);
	}
	
	@RequestMapping("getAgreementManpowerById")
	@ResponseBody
	public Map<String, Object> getAgreementManpowerById(@RequestParam Map<String, Object> param){
		String manpowerId=param.get("id").toString();
		
			Map<String, Object> resultMap=new HashMap<String, Object>();
			resultMap.put("baseConfig", agreementManpowerInfoService.getById(manpowerId));
			resultMap.put("vacationConfigs", agreementManpowerInfoService.getManpowerVacationConfig(manpowerId));
			resultMap.put("costConfigs", agreementManpowerInfoService.getManpowerCostConfigs(manpowerId));
			return resultMap;
	
		//return agreementManpowerInfoService.getAgreementManpowerById(id);
	}
	
	
	@RequestMapping("deletesAgreementManpowerInfo")
	@ResponseBody
	public String deletesAgreementManpowerInfo(@RequestBody Map<String, Object> param){
		try{
			String ids=param.get("ids").toString();
			agreementManpowerInfoService.deletesAgreementManpowerInfo(ids);
    	}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "批量删除失败");
    	}
    	return UTJsonUtils.getJsonMsg(true, "批量删除成功");
	}
	/**
	 * 获取 所有未进行配置的人力外包合同
	 * */
	@RequestMapping("getAgreementManpowerNoConfig")
	@ResponseBody
	public UTListResult getAgreementManpowerNoConfig(){
		return UTListResult.getListResult(agreementManpowerInfoService.getAgreementManpowerNoConfig());
	}
	
	/**
	 * 通过 合同Id 获取 外包人力合同费用配置
	 * @param manpowerId
	 * @return
	 */
	@RequestMapping("getManpowerCostConfigs")
	@ResponseBody
	public UTListResult getManpowerCostConfigs(@RequestParam Map<String, Object> param){
		String manpowerId=param.get("manpowerId").toString();
		return UTListResult.getListResult(agreementManpowerInfoService.getManpowerCostConfigs(manpowerId));
	}
	
	/**
	 * 通过 合同Id 获取 外包人力合同 折算配置
	 * @param manpowerId
	 * @return
	 */
	@RequestMapping("getManpowerVacationConfig")
	@ResponseBody
	public UTListResult getManpowerVacationConfig(@RequestParam Map<String, Object> param){
		String manpowerId=param.get("manpowerId").toString();
		return UTListResult.getListResult(agreementManpowerInfoService.getManpowerVacationConfig(manpowerId));
	}

	/**
	 *获取外包人力合同费用配置中所包括的人员类型  通过 合同Id
	 * @param manpowerId
	 * @return
	 */
	@RequestMapping("getVacationConfigCategory")
	@ResponseBody
	public UTListResult  getVacationConfigCategory(@RequestParam Map<String, Object> param){
		Object agreementId=param.get("agreementId");
		Object manpowerId=param.get("manpowerId");
		if(manpowerId==null&&agreementId!=null&&StringUtils.isNotEmpty(agreementId.toString())){
			Map<String, Object> map=new HashMap<String, Object>();
			map.put("agreementId", agreementId);
			List<UTMap<String, Object>>manpowers=agreementManpowerInfoService.getListMaps(param, IAgreementManpowerInfoDao.FIELD_ID);
			manpowerId=	manpowers!=null&&manpowers.size()>0?manpowers.get(0).get("id"):null;
		}

		if(manpowerId!=null){
			List<String> category=new ArrayList<String>();
			List<UTMap<String, Object>> maps= agreementManpowerInfoService.getVacationConfigCategory(manpowerId.toString());
			List<Map<String, Object>> newMaps= new ArrayList<Map<String,Object>>();
			for (UTMap<String, Object> item : maps) {
				if(!category.contains(item.get("category").toString())){
					category.add(item.get("category").toString());
					newMaps.add(item);
				}
			}
			return UTListResult.getListResult(newMaps);
		}
		return null;
	}
	
	/**
	 * 获取 外包人力合同费用配置中对应人员类型所包括的人员级别 通过 合同Id和人员类型 
	 * @param manpowerId
	 * @return
	 */
	@RequestMapping("getVacationConfigLeve")
	@ResponseBody
	public UTListResult getVacationConfigLeve(@RequestParam Map<String, Object> param){
		Object agreementId=param.get("agreementId");
		Object manpowerId=param.get("manpowerId");
		Object category=param.get("category");
		if(manpowerId==null&&agreementId!=null&&StringUtils.isNotEmpty(agreementId.toString())){
			Map<String, Object> map=new HashMap<String, Object>();
			map.put("agreementId", agreementId);
			List<UTMap<String, Object>>manpowers=agreementManpowerInfoService.getListMaps(param, IAgreementManpowerInfoDao.FIELD_ID);
			manpowerId=	manpowers!=null&&manpowers.size()>0?manpowers.get(0).get("id"):null;
		}
		if(manpowerId!=null&&category!=null){
			return UTListResult.getListResult(agreementManpowerInfoService.getVacationConfigLeve(manpowerId.toString(), category.toString()));
		}
		return null;
	}
	
	
	/***
	 * 添加数据权限 控制
	 * ***/
	private boolean setDataPrower(Map<String, Object> param){
//			if((RoleUtils.isSystemAdministrator()||RoleUtils.isSupplierAdministrator())){
//				return true;
//			}
//			if(StringUtils.isEmpty(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId())){
//				return false;
//			}
//			//如果是 供应商负责人
//			if(RoleUtils.isSupplierLeaders()){
//				//查询所管理的所有 供应商
//				param.put(ISupplierEmpDao.FIELD_SUPPLIERID,EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId());
//			}
			
			return true;
		}
		
	
}
