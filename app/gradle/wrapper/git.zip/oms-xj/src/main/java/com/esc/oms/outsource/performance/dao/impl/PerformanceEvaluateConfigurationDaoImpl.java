package com.esc.oms.outsource.performance.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.performance.dao.IPerformanceEvaluateConfigurationDao;

/**
 * 外包绩效考核配置Dao
 * @author owner
 *
 */
@Repository
public class PerformanceEvaluateConfigurationDaoImpl extends BaseOptionDao implements IPerformanceEvaluateConfigurationDao{

	@Override
	public String getTableName() {
		return "outsourc_performance_evaluate_configuration";
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params,false), pageBean, null);
	}
	
	@Override
	public List<UTMap<String, Object>> getListMaps(Map param) {
		return super.getListBySql(getSearchSql(param,false), null);
	}
	
	@Override
	public UTMap<String, Object> getById(String id) {
		String sql = this.getSearchSql(null,true);
		List<UTMap<String, Object>> list = super.getListBySql(sql, id);
		if(list != null && list.size() > 0){
			return list.get(0);
		}
		return null;
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params,boolean isGetById){
		StringBuilder sql=new StringBuilder();
		sql.append("select tb.*,CONCAT(stc.name , ' ' , stc.versions) as 'templateConfigurationName',su.name as 'submitterName',tb.beginDate > '"+UTDate.getCurDate()+"' as isEdit from " );
		sql.append(getTableName());
//		sql.append(" tb left join supplier_base_info sbi on tb.supplierId = sbi.id ");
		sql.append(" tb left join sys_template_configuration stc on tb.templateConfigurationId = stc.id ");
		sql.append(" left join sys_user su on tb.submitter = su.id where 1=1 ");
		if(isGetById){
			sql.append(" and tb.id = ? ");
		}
		if(params!=null && params.size()>0){
			
			if(params.get("evaluateTitle")!=null &&  StringUtils.isNotEmpty(params.get("evaluateTitle").toString())){
				sql.append(" and tb.evaluateTitle like '%"+params.get("evaluateTitle").toString().trim()+"%' ");
			}
			if(params.get("year")!=null &&  StringUtils.isNotEmpty(params.get("year").toString())){
				sql.append(" and tb.year = '"+params.get("year").toString().trim()+"' ");
			}
			if(params.get("unit")!=null &&  StringUtils.isNotEmpty(params.get("unit").toString())){
				sql.append(" and tb.unit = '"+params.get("unit").toString().trim()+"' ");
			}
			if(params.get("half")!=null &&  StringUtils.isNotEmpty(params.get("half").toString())){
				sql.append(" and tb.half = '"+params.get("half").toString().trim()+"' ");
			}
			if(params.get("quarter")!=null &&  StringUtils.isNotEmpty(params.get("quarter").toString())){
				sql.append(" and tb.quarter = '"+params.get("quarter").toString().trim()+"' ");
			}
			if(params.get("month")!=null &&  StringUtils.isNotEmpty(params.get("month").toString())){
				sql.append(" and tb.month = '"+params.get("month").toString().trim()+"' ");
			}
			if(params.get("status")!=null && StringUtils.isNotEmpty(params.get("status").toString())){
				sql.append(" and tb.status = "+params.get("status").toString().trim()+" ");
			}
			if(params.get("isResult")!=null){//如果是结果评估页面的查询请求，只查询开始时间小于等于当前时间的数据
				sql.append(" and tb.beginDate <= '"+UTDate.getCurDate()+"' ");
			}
			if(params.get("isSendMessageDate")!=null){//如果是查询当天需要发送消息的数据
				sql.append(" and tb.beginDate = '"+UTDate.getCurDate()+"' and tb.status = 0 ");//
			}
//			if(params.get("evaluateTitle")!=null && StringUtils.isNotEmpty(params.get("evaluateTitle").toString())){
//				sql.append(" and sbi.name = '"+params.get("evaluateTitle").toString().trim()+"' ");
//			}
//			if(params.get("subType")!=null && StringUtils.isNotEmpty(params.get("subType").toString())){
//				sql.append(" and tb.subType = "+params.get("subType").toString().trim()+" ");
//			}
		}
		sql.append(" order by tb.year desc,tb.month desc,tb.evaluateTitle desc,  tb.createTime desc");
		return  sql.toString();
	}

}
