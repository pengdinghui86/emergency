package com.esc.oms.asset.physical.service;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;


public interface IAssetPhysicalService extends IBaseOptionService{
	
	public boolean addRelation(Map info);
	
	/**
	 * 查询备件
	 * */
	public List<UTMap<String, Object>> getSparesById(String id) ;
	
	/**
	 * 根据资产id删除备件联系
	 * @param id
	 * @return
	 */
	public boolean deleteSparesById(String id);
	
	public boolean leadingin(String filePath, Map<String, Object> param) throws Exception;
	
	public boolean leadingout(List data, HttpServletRequest request,HttpServletResponse response) throws Exception;
	
	public List<UTMap<String, Object>> getAssetsList(Map param);
	
	public boolean updateInfoByIds(String location,String resUserId,String resDepartId,String ids);
	
	public boolean updateByIds(Map param);
	
	public List<UTMap<String, Object>> getAssetBycodeAndId(String codeNum,String id);
	
	public UTMap<String, Object> getAssetById(String id);
	
	public boolean updateOutdateById(String id);
	
	public boolean updateAssetStatusById(String id, String status);
	
	public boolean updateTotalPriceById(String id,String beforePrice,String nowPrice);
	
	public boolean updateAuxiliaryById(String id);

	/**
	 * 添加或者修改
	 * @param map
	 * @return
	 */
	String saveOrUpdate(Map<String, Object> map)throws Exception;

	/**
	 * 删除资产
	 * @param param
	 * @return
	 */
	String deletePhysical(Map<String, Object> param);

	/**
	 * 转移修改data
	 * @param data
	 */
	void transformData(List<UTMap<String,Object>> data);

	/**
	 * 获取sn号
	 * @return
	 */
	String getSnNum();

	/**
	 * 判断是否存在
	 * @param params
	 * @return
	 */
	public boolean isExistParam(Map<String, Object> params);

}
