package com.esc.oms.asset.assetCategory.service.impl;

import com.esc.oms.asset.assetCategory.dao.IAssetCategoryDao;
import com.esc.oms.asset.assetCategory.service.IAssetCategoryService;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("assetCategoryService")
public class AssetCategoryServiceImpl extends BaseOptionService implements IAssetCategoryService {

  @Resource
  private IAssetCategoryDao assetCategoryDao;
  @Override
  public IBaseOptionDao getOptionDao() {
    return assetCategoryDao;
  }

  @Override
  public List<UTMap<String, Object>> getdicts() {
    return assetCategoryDao.getdicts();
  }

  @Override
  public void getAttrAll(Map<String, Object> params, UTPageBean pageBean) {
    assetCategoryDao.getAttrAll(params, pageBean);
  }

  @Override
  public List<UTMap<String, Object>> getAttrValue(String infoId) {
    return assetCategoryDao.getAttrValue(infoId);
  }

  @Override
  public Map<String, Object> getAttrValueMap(Map<String, Object> map) {
    List<UTMap<String, Object>> attrValueList = this.getAttrValue(map.get("id").toString());
    UTPageBean pageBean = new UTPageBean();
    this.getAttrAll(map, pageBean);
    List<UTMap<String, Object>> all = pageBean.getRows();
    //属性值转为map
    Map<String, Object> attrValueMap = new HashMap<>();
    if(all != null){
      for(UTMap<String, Object> attrValue : all){
        attrValueMap.put((String)attrValue.get("attId"), attrValue.get("attValue"));
      }
    }
    if(attrValueList != null && attrValueList.size()>0){
      for(UTMap<String, Object> attrValue : attrValueList){
        attrValueMap.put((String)attrValue.get("attId"), attrValue.get("attValue"));
      }
    }
    return attrValueMap;
  }

  @Override
  public String getAssetCategoryIdByName(String name) {
    return assetCategoryDao.getAssetCategoryIdByName(name);
  }

  @Override
  public boolean isExistColumn(Map<String, Object> map) {
    //先判断是否存在属性表中 和资产表中
    if(this.isExist(map) || assetCategoryDao.isAssetInfoColumn((String) map.get("attId"))){
      return true;
    }
    return false;
  }

  @Override
  public List<UTMap<String, Object>> getAttrList(Map<String, Object> params) {
    return assetCategoryDao.getAttrList(params);
  }
}
