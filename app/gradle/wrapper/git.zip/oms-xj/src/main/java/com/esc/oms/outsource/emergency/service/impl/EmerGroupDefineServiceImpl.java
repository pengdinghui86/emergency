package com.esc.oms.outsource.emergency.service.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.hibernate.exception.DataException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.emergency.dao.IEmerGroupDefineEditDao;
import com.esc.oms.outsource.emergency.service.IEmerGroupDefineService;
import com.esc.oms.outsource.group.dao.IGroupDefineEditDao;
import com.esc.oms.outsource.grouporg.dao.IGroupOrgDao;
import com.esc.oms.outsource.grouporg.service.IGroupOrgService;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;

@Service
@Transactional
public class EmerGroupDefineServiceImpl extends BaseOptionService implements IEmerGroupDefineService{

	@Resource
	private IEmerGroupDefineEditDao emerGroupDefineEditDao;
	@Resource
	private IGroupOrgService groupOrgService;
	@Override
	public IBaseOptionDao getOptionDao() {
		return emerGroupDefineEditDao;
	}
	
	
	@EscOptionLog(module=SystemModule.energGroupDefine, opType=ESCLogOpType.INSERT, table="outsource_emergroup_define",option="新增名称为{name}的外包管理应急组织架构小组定义。")
	public boolean add(Map info){
		String groupName = (String)info.get("groupName");
		String code=emerGroupDefineEditDao.getNewCode(101, "code");
		info.put("code",code);
		Map param = new HashMap();
		param.put("groupName", groupName);
		if(emerGroupDefineEditDao.isExist(param)){
			throw new EscServiceException("小组名称【"+groupName+"】已经存在！");
		}
		return emerGroupDefineEditDao.add(info);
	}
	
	@EscOptionLog(module=SystemModule.energGroupDefine, opType=ESCLogOpType.DELETE, table="outsource_emergroup_define",option="删除name为{name}的外包管理应急组织架构小组定义。")
	public boolean deleteById(String id){
		groupOrgService.deleteGroupAfter(id, IGroupOrgDao.GROUPORG_YJJG);
		return	getOptionDao().deleteByIds(id);
	}
	
	public boolean deleteByIds(String ids){
		groupOrgService.deleteGroupAfter(ids,  IGroupOrgDao.GROUPORG_YJJG);
		return	getOptionDao().deleteByIds(ids);
	}
	
	
	@Override
	@EscOptionLog(module=SystemModule.energGroupDefine, opType=ESCLogOpType.UPDATE, table="outsource_emergroup_define",option="更新name为{name}的外包管理应急组织架构小组定义。")
	public boolean updateById(Map info){
		String groupName = (String)info.get("groupName");
		List<UTMap<String,Object>> groups = emerGroupDefineEditDao.getGroupDefineByNameAndId(groupName, String.valueOf(info.get("id")));
		if(null != groups && groups.size() > 0){
			throw new EscServiceException("小组名称【"+groupName+"】已经存在！");
		}
		return getOptionDao().updateById(info);
	}
	
	/**
	 * 从excel中导入数据
	 * @param filePath
	 * @param param
	 * @return
	 */
	@Override
	public boolean leadingin(String filePath, Map<String, Object> param) throws Exception {
		List<UTMap<String, Object>> leadinginList = new ArrayList<UTMap<String,Object>>();
		boolean flag = true;
		// 根据路径 获取工作薄
		Sheet sheet = UTExcel.getSheets(filePath)[0];
		// 导入顺序
		String[] cellArray = new String[] { 
				"小组名称*（长度：0-20）", 
				"职责定义*（长度：0-500）"
		};
		int[] lengthArr = {20, 500};
		String[] fileds = new String[] { 
				IEmerGroupDefineEditDao.FIELD_GROUPNAME,
				IEmerGroupDefineEditDao.FIELD_RESPONSDEFINE
		};
		
		int rowNum = sheet.getLastRowNum();
		int cellNum = fileds.length;
		
		//检查导入的字段标题
		try {
			List<String> realityCellllist=new ArrayList<String>();
			Row rowtitle=sheet.getRow(0);
			for (int j = 0; j < cellNum;j++) {
				realityCellllist.add(rowtitle.getCell(j).getStringCellValue());
			}
			String[] array =new String[realityCellllist.size()];
			if(!UTExcel.excelValidateByCell(cellArray, realityCellllist.toArray(array))){
				flag = false;
			}
		} catch (Exception e) {
			flag = false;
		}
		
		if(!flag) {
			throw new EscServiceException("导入失败，请选择正确的模板！");
		}
		StringBuilder error = new StringBuilder();
		// 从excel第二行开始添加 数据，全部保存
		for (int i = 1; i <= rowNum; i++) {
			// 遍历excel
			Row row = sheet.getRow(i);
			UTMap<String, Object> map = new UTMap<String, Object>();
			for (int j = 0; j < cellNum; j++) {
				String cellvalue = null;
				Cell cell = row.getCell(j);
				if (cell != null) {
					cell.setCellType(Cell.CELL_TYPE_STRING);
					cellvalue = cell.getStringCellValue();
					cellvalue = StringUtils.isEmpty(cellvalue) ? null : cellvalue.trim();
				}
				//检查空
				if(j == 0 || j == 1) {
					flag = StringUtils.isEmpty(cellvalue) ? false : true;
					if (!flag) {
						error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "内容为空，请检查！" + "<br>");
					}
				}
				if (cellvalue != null) {
					//长度校验
					if (lengthArr[j] != 0 && cellvalue.length() > lengthArr[j]){
						error.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "内容长度超出限制，请检查！" + "<br>");
					}
					if (StringUtils.equals(IGroupDefineEditDao.FIELD_GROUPNAME,
							fileds[j])){
						try {
							checkExist(fileds[j]);
						}catch(EscServiceException e){
							error.append(e.getMessage() + "<br>");
						}
						
					}
				}
				map.put(fileds[j], cellvalue);
			}
			map.put("code", emerGroupDefineEditDao.getNewCode(101, "code"));
			leadinginList.add(map);
		}
		if (StringUtils.isNotEmpty(error.toString())) {
			throw new EscServiceException(error.toString());
		}
		
		if (!leadinginList.isEmpty()) {
			for (int i = 0; i < leadinginList.size(); i ++) {
				UTMap<String, Object> map = leadinginList.get(i);
				try {
					flag = add(map);
				} catch (DataException e) {
					try {
			    		SQLException sqlException = e.getSQLException();
			    		if(sqlException != null) {
			    			String message = sqlException.getMessage();
			    			//如果提示是：Data too long for column 'name'，那么可以提示长度
			    			//如果是其他类型的sql错误，不进行处理
			    			if(message != null && message.contains("Data too long for column '")) {
			    				String filed = message.substring(message.indexOf("Data too long for column '") + 26, message.indexOf("' at r"));
			    				String filedName = "";
								//找到字段名称
			    				for (int j = 0; j < fileds.length; j++) {
									if(StringUtils.equals(filed, fileds[j])) {
										filedName = cellArray[j];
										break;
									}
								}
			    				//抛出提示
			    				throw new EscServiceException("Excel内容错误，行号为" + (i + 2) + "的" + filedName + "长度太长，请检查！");
			    			} else {
			    				throw e;
			    			}
			    		}
					} catch (EscServiceException e2) {
	    				throw e2;
					} catch (Exception e2) {
						//继续抛出
	    				throw e;
					}
				} catch (Exception e) {
					//其他异常
					throw e;
				}
				if (!flag) {
					throw new EscServiceException("保存数据失败！");
				}
			}
		}
		return flag;
	}

	/**
	 * 导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	@Override
	public boolean leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String[] fileds = new String[] { 
				IEmerGroupDefineEditDao.FIELD_GROUPNAME,
				IEmerGroupDefineEditDao.FIELD_RESPONSDEFINE
		};
		String tamlate="excelOutTamplate.emerGroupDefine";	
		//替换下拉的值
		return	UTExcel.leadingout( fileds, data, tamlate, request,response);
	}
	
	public void checkExist(String groupName) {
		UTMap<String, Object> param = new UTMap<String, Object>();
			param.clear();
			param.put("name", groupName);
			List<UTMap<String, Object>> list = emerGroupDefineEditDao.getListByName(groupName);
			if((list != null) && (list.size()>0)) {
				throw new EscServiceException("名称【" + groupName + "】的已经存在！");
			}
	
	}

	@Override
	public List<UTMap<String, Object>> getGroupDefineByNameAndId(
			String groupName, String id) {
		return emerGroupDefineEditDao.getGroupDefineByNameAndId(groupName, id);
	}
}