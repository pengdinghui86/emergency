//package com.esc.oms.exemple.service;
//
//import org.esc.framework.timetask.anotations.CronTimeTask;
//import org.esc.framework.timetask.anotations.TimeTaskMark;
//import org.springframework.stereotype.Service;
//
///**
// * 定时任务例子
// * @author owner
// *
// */
//@Service
//@TimeTaskMark
////@TimeTaskType("定时任务测试类")
//public class TimeTaskExemple {
//	
////	@Resource
////	private ISysLogDao logDao;
////	
////	@Override
////	public IBaseOptionDao getOptionDao() {
////		return logDao;
////	}
//	
//	@CronTimeTask(description="每天凌晨根据用户考勤规则定时生成考勤数据",cron="0 0 0 * * ?",parameters={"true"})
//	public void timeTaskTest(boolean temp){
//		System.out.println("定时任务timeTaskTest方法被执行"+temp);
//	}
//	
//	@CronTimeTask(description="测试定时任务",cron="0 0 0 * * ?",parameters={"true"})
//	public void timeTaskTest1(boolean temp){
//		System.out.println("定时任务timeTaskTest1方法被执行"+temp);
//	}
//	
//	@CronTimeTask(description="测试定时任务2",cron="0 0 0 * * ?",parameters={"false"})
//	public void timeTaskTest2(boolean temp){
//		System.out.println("定时任务timeTaskTest2方法被执行"+temp);
//	}
//	
////	@TimeTaskMethod("测试方法")
////	public void timeTaskTest3(@TimeTaskParameter("测试参数") boolean temp){
////		System.out.println("定时任务timeTaskTest3方法被执行"+temp);
////	}
//
//}
