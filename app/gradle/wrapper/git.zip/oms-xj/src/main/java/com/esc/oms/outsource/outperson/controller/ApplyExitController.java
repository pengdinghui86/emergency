package com.esc.oms.outsource.outperson.controller;

import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.exception.EscServiceException;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.page.UTListResult;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.outsource.outperson.service.IApplyCommonService;
import com.esc.oms.outsource.outperson.service.IApplyExitService;
import com.esc.oms.util.CommonUtils;

/**
 * 退场申请 控制器
 * @author smq
 * @date   2016-7-9 上午10:37:30
 */
@Controller
@RequestMapping("outsource/person/exit")
public class ApplyExitController extends AbstractApplyController {
	@Resource
	private IApplyExitService applyExitService;

	@Override
	public IApplyCommonService applyService() {
		return applyExitService;
	}
	
	//为人员注销配置
	@RequestMapping(value="cancelConfig",method=RequestMethod.POST)  
    @ResponseBody
	public String cancelConfigByUserId(@RequestBody Map<String,Object> map1){
		Map<String,Object> cloneMap = CommonUtils.clone(map1);
	   	try{
			boolean flog= applyExitService.cancelConfigByUserId(cloneMap);
		    		return UTJsonUtils.getJsonMsg(flog, flog?"操作成功":"操作失败");
	    	}catch(EscServiceException e){
	    		logger.error("EscServiceException", e);
	    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
	    	}catch(Exception e){
	    		logger.error("Exception", e);
	    		return UTJsonUtils.getJsonMsg(false, "操作失败");
	    	}

	}
	
	@RequestMapping("getUserBaseInfo")
	@ResponseBody
	public UTListResult getUserBaseInfo(@RequestParam Map<String, Object>param) {
		return UTListResult.getListResult(applyExitService.getUserBaseInfo(param));
	}
	
	
}