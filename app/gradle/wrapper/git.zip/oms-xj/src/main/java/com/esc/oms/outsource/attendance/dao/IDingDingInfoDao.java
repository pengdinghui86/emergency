package com.esc.oms.outsource.attendance.dao;

import org.esc.framework.persistence.dao.IBaseOptionDao;

public interface IDingDingInfoDao extends IBaseOptionDao {
}
