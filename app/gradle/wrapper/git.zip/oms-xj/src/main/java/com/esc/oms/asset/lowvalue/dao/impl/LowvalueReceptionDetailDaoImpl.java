package com.esc.oms.asset.lowvalue.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.asset.lowvalue.dao.ILowvalueReceptionDetailDao;
@Repository
public class LowvalueReceptionDetailDaoImpl extends BaseOptionDao implements ILowvalueReceptionDetailDao{
	
	@Override
	public String getTableName() {
		return "assets_lowvalue_reception_detail";
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params,false), pageBean, null);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params) {
		return super.getListBySql(getSearchSql(params,false), null);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListMaps(Map params) {
		return super.getListBySql(getSearchSql(params,false), null);
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params,boolean isGetById){
		StringBuilder sql = new StringBuilder();
		sql.append(" select detail.*,info.stockNum,info.pendConfirmNum,CONCAT(receptUser.name,'/',receptUser.`code`) as receptUserName,CONCAT(grantUser.name,'/',grantUser.`code`) as grantUserName,org.name as unitName,"
				+ " reception.type,reception.receptUserId,reception.receptDate,reception.grantUserId,reception.status from assets_lowvalue_reception_detail detail ");
		sql.append(" left join assets_lowvalue_reception reception on detail.receptId=reception.id ");
		sql.append(" left join assets_lowvalue_info info on detail.infoId=info.id  ");		
		sql.append(" left join sys_user receptUser on reception.receptUserId=receptUser.id ");
		sql.append(" left join sys_user grantUser on reception.grantUserId=grantUser.id ");
		sql.append(" left join sys_org org on reception.unit=org.id ");
		sql.append(" where 1=1 ");
		if(params!=null && params.size()>0){		
			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
				sql.append(" and detail.name like '%"+params.get("name").toString().trim()+"%' ");
			}
			if(params.get("code")!=null &&  StringUtils.isNotEmpty(params.get("code").toString())){
				sql.append(" and detail.code like '%"+params.get("code").toString().trim()+"%' ");
			}
			if(params.get("receptId")!=null && StringUtils.isNotEmpty(params.get("receptId").toString())){
				sql.append(" and detail.receptId='"+params.get("receptId").toString().trim()+"' ");
			}
			if(params.get("infoId")!=null && StringUtils.isNotEmpty(params.get("infoId").toString())){
				sql.append(" and detail.infoId='"+params.get("infoId").toString().trim()+"' ");
			}
			if(params.get("startDate")!=null && StringUtils.isNotEmpty(params.get("startDate").toString())){
				sql.append(" and DATE_FORMAT(reception.receptDate,'%Y-%m-%d')>='"+params.get("startDate").toString().trim()+"' ");
			}
			if(params.get("endDate")!=null && StringUtils.isNotEmpty(params.get("endDate").toString())){
				sql.append(" and DATE_FORMAT(reception.receptDate,'%Y-%m-%d')<='"+params.get("endDate").toString().trim()+"' ");
			}
		}
		sql.append(" order by detail.createTime desc");
		return  sql.toString();
	}

	@Override
	public List<UTMap<String, Object>> getListAllByParentParam(Map params) {
		return super.getListBySql(getSearchSqlByParentParam(params), null);
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSqlByParentParam(Map params){
		StringBuilder sql = new StringBuilder();
		sql.append(" select detail.* from assets_lowvalue_reception_detail detail ");
		sql.append(" left join assets_lowvalue_reception reception on detail.receptId=reception.id ");
		sql.append(" where 1=1 ");
		if(params!=null && params.size()>0){		
			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
				sql.append(" and reception.name like '%"+params.get("name").toString().trim()+"%' ");
			}
			if(params.get("startDate")!=null && StringUtils.isNotEmpty(params.get("startDate").toString())){
				sql.append(" and reception.receptDate>='"+params.get("startDate").toString().trim()+"' ");
			}
			if(params.get("endDate")!=null && StringUtils.isNotEmpty(params.get("endDate").toString())){
				sql.append(" and reception.receptDate<='"+params.get("endDate").toString().trim()+"' ");
			}
		}
//		sql.append(" order by detail.receptId desc");
		return  sql.toString();
	}

}
