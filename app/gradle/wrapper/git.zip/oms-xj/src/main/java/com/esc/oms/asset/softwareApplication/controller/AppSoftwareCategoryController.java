package com.esc.oms.asset.softwareApplication.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTListResult;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.esc.oms.asset.software.service.ISoftCategoryService;
import com.esc.oms.asset.softwareApplication.service.IAppSoftwareService;

@Controller
@RequestMapping("appSoftCategory")
public class AppSoftwareCategoryController extends BaseOptionController {

	@Resource
	private IAppSoftwareService appSoftwareService;

	@Resource
	private ISoftCategoryService softCategoryService; 
	
	@Override
	public IBaseOptionService optionService() {
		return softCategoryService;
	}
	
	@RequestMapping(value = "deleteSubCategory", method = RequestMethod.POST)
	@ResponseBody
	public String deleteSubCategory(@RequestBody Map<String, Object> param) {
		if(null != param){
			UTMap<String,Object> ut = new UTMap<String,Object>();
			ut.put("category", String.valueOf(param.get("id")));
			List<UTMap<String,Object>> list = appSoftwareService.getListMaps(ut,"id");
			if(null != list && list.size() > 0){
				return UTJsonUtils.getJsonMsg(false, "该软件子类别已被引用，禁止删除");
			}
		}
		try {
			softCategoryService.deleteSubCategory(param);
		} catch (Exception e) {
			logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "删除失败");
		}
		 return UTJsonUtils.getJsonMsg(true, "删除成功");
	}

	
}