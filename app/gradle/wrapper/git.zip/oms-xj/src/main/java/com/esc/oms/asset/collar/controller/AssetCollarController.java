package com.esc.oms.asset.collar.controller;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.asset.collar.service.IAssetCollarService;
import com.esc.oms.asset.overview.dao.IAssetsTrackInfoDao;
import com.esc.oms.asset.overview.service.IAssetsTrackInfoService;
import com.esc.oms.asset.physical.service.IAssetPhysicalService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.TaskModel;

import net.sf.json.JSONObject;
@Controller
@RequestMapping("assetCollar")
public class AssetCollarController extends BaseOptionController {


	@Resource
	private IAssetCollarService assetCollarService;
	
	@Resource
	private IAssetPhysicalService assetPhysicalService;
	
	@Resource
	private MessageSend messageService;
	
	@Resource
	private IUserTaskService userTaskService;
	
	@Resource
	private IAssetsTrackInfoService assetsTrackInfoService;
	
	@Override
	public IBaseOptionService optionService() {
		return assetCollarService;
	}
	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			assetCollarService.getPageInfo(pageBean, params);
			List<Map<String, Object>> list = pageBean.getRows();
			if(null != list && list.size() > 0 ){
				for (Map<String, Object> map : list) {
					if("GR".equals((String)map.get("receptType"))){
						map.put("receptType", "个人");
					}else{
						map.put("receptType", "部门");
					}
					if("DQR".equals((String)map.get("status"))){
						map.put("status", "待确认");
					}else{
						map.put("status", "已确认");
					}
				}
			}
			
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
    @RequestMapping(value="/saveOrUpdate",method=RequestMethod.POST)  
    @ResponseBody
    public String saveorupdate(@RequestBody Map<String,Object> map){  
    	String id = (String)map.get("id");
    	boolean flag = false;
    	List<Map<String, Object>> assetCollarList = (List<Map<String, Object>>)map.get("assetCollarList");
    	try{
	    	if(id == null){
	    		map.put("status", "DQR");
	    		flag = assetCollarService.add(map);
	    		if (flag) {
	    			for (Map<String, Object> info : assetCollarList) {
	    				Map<String, Object> newInfo = new HashMap<String, Object>();
						newInfo.put("applyId", map.get("id"));
						newInfo.put("assetsId", info.get("id"));
						assetCollarService.addAssetCollar(newInfo);
	    			}
	    		}
	    	}else{
	    		flag = assetCollarService.updateById(map);
	    		if (flag) {
					String applyId = (String) map.get("id");
					//更新的时候先删除借用资产列表，再进行添加
					assetCollarService.deleteAssetCollarByApplyId(applyId);
					for (Map<String, Object> info : assetCollarList) {
						Map<String, Object> newInfo = new HashMap<String, Object>();
						newInfo.put("applyId", applyId);
						newInfo.put("assetsId", info.get("assetsId"));
						assetCollarService.addAssetCollar(newInfo);
					}
				}
	    	}
	    	if(flag){
    			String title = "资产【"+map.get("title")+"】领用确认提醒";
    			String content = "资产:【"+map.get("title")+"】领用记录待您确认！";
    			messageService.sendMessage((String)map.get("receptUserId"),title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
    			//生成待办任务
    			userTaskService.addTaskByUserId("资产领用【"+ map.get("title") + "】记录待您确认",(String) map.get("id"), "实物资产领用确认", TaskModel.AssetCollar,(String)map.get("receptUserId"));			
	    	}
	    	
    	}catch(EscServiceException e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false,e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "操作成功");
    }
    
    
    @RequestMapping(value="defupdate")
	@ResponseBody
	public String defupdate(@RequestBody  Map<String, Object> info){
    	Map<String,Object> cloneMap = CommonUtils.clone(info);
		try{
    		optionService().updateById(cloneMap);
    		Map<String, Object> param = new HashMap<String, Object>();
    		param.put("applyId", cloneMap.get("id"));
    		List<UTMap<String, Object>> assetCollars = assetCollarService.getAssetCollarByApplyId(param);
    		if (null != assetCollars && !assetCollars.isEmpty()) {
    			for (UTMap<String, Object> item : assetCollars) {
		    		//----资产轨迹----领用
		    		UTMap<String,Object> track = new UTMap<String,Object>();
		    		UTMap<String,Object> assets = new UTMap<String,Object>();
		    		track.put("assetsId", item.get("assetsId"));
		    		track.put("userId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
		    		track.put("departId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserOrgId());
		    		track.put("changeRemark", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserOrgName()+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectName()+IAssetsTrackInfoDao.FIELD_ASSETSCOLLAR);
		    		track.put("type", 1);
		    		track.put("changeType","领用");
		    		track.put("changeTime", new Date(System.currentTimeMillis()));
		    		assetsTrackInfoService.add(track);
		    		
		    		//====修改资产责任人====
					assets.put("id", item.get("assetsId"));
					assets.put("resUserId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
					assets.put("resDepartId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserOrgId());
					assets.put("assetStatus", "2");
					assetPhysicalService.updateById(assets);
					
					//====如果出库为空则当前时间为出库时间====
					assetPhysicalService.updateOutdateById(String.valueOf(item.get("assetsId")));
    			}
    		}
    	}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "操作成功");
	}
    
    /**
	 * 根据id查询
	 * @param param
	 * @return
	 */
	@RequestMapping(value="getById")
	@ResponseBody
	public UTMap<String, Object> defgetById(@RequestParam  Map<String, Object> map1){
		Map<String, Object> param = CommonUtils.clone(map1);
		
		UTMap<String, Object> map = null;
    	try{
    		map = assetCollarService.getCollarById((String)param.get("id"));
    		if(null != map){
    			param.put("applyId", param.get("id"));
    			map.put("assetCollarList", assetCollarService.getAssetCollarByApplyId(param));
    		}
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return map;
	}
	
	@RequestMapping(value="getAssetByAssetId")
	@ResponseBody
	public UTMap<String, Object> getAssetByAssetId(@RequestParam  Map<String, Object> param){		
		UTMap<String, Object> asset = null;
    	try{
    		asset = assetCollarService.getAssetByAssetId((String)param.get("assetId"));
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return asset;
	}
	
	
	@RequestMapping(value = "leadingout")
	public void leadingout(@RequestParam Map<String, Object> map1,
			HttpServletRequest request,
			HttpServletResponse response) {
		Map<String,Object> cloneMap = CommonUtils.clone(map1);
		UTPageBean clonePageBean = CommonUtils.getPageBean(cloneMap);
		
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) cloneMap.get("outType"));
			Object info = cloneMap.get("params");
			JSONObject jsonBean = null;
			if(info != null) {
				jsonBean = JSONObject.fromObject(info);
			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = assetCollarService.getCollarList(jsonBean);
			} else {
			// 根据条件 导出当前
			//if (UTExcel.EXCELOUTTYPE_NOW == outType) {
				// getpage
				assetCollarService.getPageInfo(clonePageBean, jsonBean);
				data = clonePageBean.getRows();
			}
			if(null != data && data.size() > 0 ){
				for (Map<String, Object> map : data) {
					if("GR".equals((String)map.get("receptType"))){
						map.put("receptType", "个人");
					}else{
						map.put("receptType", "部门");
					}
					if("DQR".equals((String)map.get("status"))){
						map.put("status", "待确认");
					}else{
						map.put("status", "已确认");
					}
					map.put("receptTime", CommonUtils.replaceAll((String)map.get("receptTime"), "-", "/"));
				}
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			assetCollarService.leadingout(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	
	@RequestMapping(value="getAssetCollar")  
    @ResponseBody
    public List<UTMap<String, Object>> getAssetCollar(@RequestParam  Map<String, Object> param){
       return assetCollarService.getAssetsList(param);
    }
    
    @RequestMapping(value="getAssetCollarPage")  
    @ResponseBody
    public UTPageBean getAssetCollarPage(@RequestParam  Map<String, Object> param){
    	UTPageBean pageBean = CommonUtils.getPageBean(param);
    	assetCollarService.getAssetCollarPage(param, pageBean);
    	return pageBean;
    }
    
    @RequestMapping(value="getAssetCollarByApplyId")  
    @ResponseBody
    public List<UTMap<String, Object>> getAssetCollarByApplyId(@RequestParam  Map<String, Object> param){
    	return assetCollarService.getAssetCollarByApplyId(param);
    }
    
}