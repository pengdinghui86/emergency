package com.esc.oms.outsource.manhour.service.impl;

import com.esc.oms.outsource.attendance.service.IAttendanceService;
import com.esc.oms.outsource.manhour.dao.IOvertimeDao;
import com.esc.oms.outsource.manhour.service.IOvertimeService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.idgenerator.IDGenerationManager;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.workflow.annotation.WorkflowRecordQueryMark;
import org.esc.framework.workflow.dao.IWorkflowInstanceDao;
import org.esc.framework.workflow.service.IWorkflowCode;
import org.esc.framework.workflow.service.IWorkflowEngine;
import org.esc.framework.workflow.utils.bpmn.FlowForm;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class OvertimeServiceImpl extends BaseOptionService implements IOvertimeService {

	@Resource
	private IOvertimeDao overtimeDao;
	
	@Resource
	private IAttendanceService attendanceService;

	@Resource
	private ISysParamService sysParamService;
	
	@Resource
	private ISysUserService sysUserService;
	
	@Resource
	private MessageSend messageService;

	@Resource
	private IWorkflowEngine workflowEngine;
	
	@Resource
	private IWorkflowInstanceDao workflowInstanceDao;
	
	@Resource
	private IUserTaskService userTaskService;

	@Override
	public IBaseOptionDao getOptionDao() {
		return overtimeDao;
	}

	@Override
	@UploadAddMark
	@EscOptionLog(module = SystemModule.overtime, opType = ESCLogOpType.SUBMIT, table = "workhour_overtime", option = "提交{submitUser}/{code}加班申请。")
	public void submit(Map<String, Object> map) {
		map.put("status", STATUS_SUBMITD);
		map.put("submitUser", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectName() + "/" + EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectCode());
		map.put("submitTime", UTDate.getCurDateTime());

		String recordId = saveOrUpdate(map);
		String supplierId = EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId();
		String workflowInstanceId = null;
		if(StringUtils.isNotEmpty(supplierId)) {
			Map<String, Object> formMap = new HashMap<String, Object>();
			formMap.put(FlowForm.FormItemValue.TDGYS ,supplierId);
			
			workflowInstanceId = workflowEngine.runInstance(IWorkflowCode.OUTSOURCE_MANHOUR_OVERTIME, recordId, formMap);
		} else {
			workflowInstanceId = workflowEngine.runInstance(IWorkflowCode.OUTSOURCE_MANHOUR_OVERTIME, recordId);
		}
		setInstanceId(recordId, workflowInstanceId);

	}

	private void setInstanceId(String recordId, String workflowInstanceId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("workflowInstanceId", workflowInstanceId);
		updateById(map);
	}

	private String saveOrUpdate(Map<String, Object> map) {
		if (map.get("id") == null) {
			add(map);
		} else {
			updateById(map);
		}
		return (String) map.get("id");
	}

	@Override
	public void auditing(String recordId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("status", STATUS_AUDITING);
		super.updateById(map);
	}

	@Override
	public void finishAudit(String recordId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("status", STATUS_FINISH);
		updateById(map);
		
		UTMap<String, Object> info = getById(recordId);
		// 完成审核后，加入考勤
//		attendanceService.summarizingManhour((String) info.get("createUserId"), (String) info.get("presentDate"));
	}
	
	/**
	 * @param workflowInstanceId 流程ID
	 * @return 申请人对象
	 */
	private UTMap<String, Object> getApplyUser(String workflowInstanceId){
		List<UTMap<String,Object>> workflowHistorys = workflowInstanceDao.getWorkflowHistorys(workflowInstanceId, "开始");
		if(workflowHistorys != null && workflowHistorys.size() > 0) {
			// 按照创建时间倒叙排序的，如果多次提及，会有多个开始，第一个就是最晚提交的人，name/code
			UTMap<String, Object> beginStep = workflowHistorys.get(0);
			String createUser = (String) beginStep.get("createUser");
			if(StringUtils.isNotEmpty(createUser) && createUser.contains("/")) {
				int regexIndex = createUser.indexOf("/");
				UTMap<String, Object> user = sysUserService.getUserBaseByNameOrCode(createUser.substring(regexIndex+1, createUser.length()), createUser.substring(0, regexIndex));
				if(user != null) {
					return user;
				}
			}
		}
		return  null;
	}
	

	@Override
	@EscOptionLog(module = SystemModule.overtime, opType = ESCLogOpType.REJECT, table = "workhour_overtime", primaryKey = "id={1}", option = "驳回{submitUser}/{code}加班申请。")
	public void rejectAudit(String recordId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("status", STATUS_REJECT);
		updateById(map);
		
		UTMap<String, Object> data = this.getById(recordId);
		
		String beginTime = (String) data.get("beginTime");
		String endTime = (String) data.get("endTime");
		
		UTMap<String, Object> user = this.getApplyUser(data.get("workflowInstanceId").toString());
		if(user != null){
			String applyUserId = (String)user.get("id");
			String title = "加班申请驳回提醒";
			String content = "您的【" + beginTime + "-" + endTime + "】的加班申请已被驳回，请知悉！详情请进入系统查看";
			messageService.sendMessage(applyUserId, title, content, MessageSend.Type.MAIL, MessageSend.Type.SYSTEM);
		}
	}

	@Override
	public void terminateAudit(String recordId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("status", STATUS_TERMINATE);
		updateById(map);
		
		UTMap<String, Object> data = this.getById(recordId);
		
		String beginTime = (String) data.get("beginTime");
		String endTime = (String) data.get("endTime");
		
		UTMap<String, Object> user = this.getApplyUser(data.get("workflowInstanceId").toString());
		if(user != null){
			String applyUserId = (String)user.get("id");
			String title = "加班申请终止提醒";
			String content = "您的【" + beginTime + "-" + endTime + "】的加班申请已被终止，请知悉！详情请进入系统查看";
			messageService.sendMessage(applyUserId, title, content, MessageSend.Type.MAIL, MessageSend.Type.SYSTEM);
		}
	}

	@UploadAddMark
	@EscOptionLog(module = SystemModule.overtime, opType = ESCLogOpType.INSERT, table = "workhour_overtime", option = "新增{submitUser}/{code}加班申请。")
	public boolean add(Map info) {
		Map cloneInfo = CommonUtils.clone(info);
		cloneInfo.put("createUserId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
		cloneInfo.put("supplierId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId());
		cloneInfo.put("supplierName", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierName());
		cloneInfo.put("orgId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserOrgId());
		cloneInfo.put("orgName", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserOrgName());
		cloneInfo.put("code", IDGenerationManager.nextId("overtime")); // 自动生成编号
		cloneInfo.put("presentDate", cloneInfo.get("beginTime"));
		if(cloneInfo.containsKey("hoursMap")) { // 计算工时带过来的数据
			Map hoursMap = (Map) cloneInfo.get("hoursMap");
			cloneInfo.put("dateType", hoursMap.get("dateType")); // 记录节假日类型
			cloneInfo.put("actualHours", hoursMap.get("actualHours"));
			cloneInfo.put("coalitionId", hoursMap.get("coalitionId"));
		}
		
		if(overtimeDao.isExistRecord(cloneInfo)) {
			throw new EscServiceException("当前时间段已经存在有加班信息！");
		}

		return overtimeDao.add(cloneInfo);
	}

	@UploadAddMark
	@EscOptionLog(module = SystemModule.overtime, opType = ESCLogOpType.UPDATE, table = "workhour_overtime", option = "更新{submitUser}/{code}加班申请。")
	public boolean updateById(Map info) {
		if(overtimeDao.isExistRecord(info)) {
			throw new EscServiceException("当前时间段已经存在有加班信息！");
		}
		if(info.containsKey("beginTime")) {
			info.put("presentDate", info.get("beginTime"));
		}
		if(info.containsKey("hoursMap")) {
			Map hoursMap = (Map) info.get("hoursMap");
			info.put("dateType", hoursMap.get("dateType"));
			info.put("actualHours", hoursMap.get("actualHours"));
		}
		
		return overtimeDao.updateById(info);
	}

	@EscOptionLog(module = SystemModule.overtime, opType = ESCLogOpType.DELETE, table = "workhour_overtime", option = "删除{submitUser}/{code}加班申请。")
	public boolean delete(Map info) {
		userTaskService.finishTaskById(info); // 完成可能存在的代办
		return overtimeDao.delete(info);
	}
	
	@EscOptionLog(module = SystemModule.overtime, opType = ESCLogOpType.DELETE, table = "workhour_overtime", option = "撤销{submitUser}/{code}加班申请。")
	public boolean undo(Map info) {
		userTaskService.finishTaskById(info); // 完成可能存在的代办
		return overtimeDao.delete(info);
	}

	@Override
	@UploadQueryMark
	public UTMap<String, Object> getById(String id) {
		return overtimeDao.getById(id);
	}

	@Override
	@WorkflowRecordQueryMark
	public List<UTMap<String, Object>> getOvertimeList(Map param) {
		return overtimeDao.getOvertimeList(param);
	}

	@Override
	@WorkflowRecordQueryMark
	public UTPageBean getOvertimePage(UTPageBean pageBean, Map param) {
		overtimeDao.getOvertimePage(pageBean, param);
		return pageBean;
	}

	/**
	 * 导出
	 * 
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	@Override
	public boolean leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// 编号	申请人	所属部门	所属供应商	申请时间	加班开始时间	加班结束时间	工时（H）	申请原因	状态
		String[] fileds = new String[] { 
				IOvertimeDao.FIELD_CODE,
				IOvertimeDao.FIELD_ORGNAME,
				IOvertimeDao.FIELD_SUPPLIERNAME,
				IOvertimeDao.FIELD_SUBMITUSER,
				IOvertimeDao.FIELD_SUBMITTIME,
				"beginTimeShow",
				"endTimeShow",
				IOvertimeDao.FIELD_HOURS,
				"actualHours",
				"finalHours",
				IOvertimeDao.FIELD_REASON,
				IOvertimeDao.FIELD_STATUS };
		String tamlate = "excelOutTamplate.outsourceOvertime";
		if (null != data && !data.isEmpty()) {
			for (int i=0;i<data.size();i++) {
				UTMap<String, Object> item = (UTMap<String, Object>) data.get(i);
				item.put(IOvertimeDao.FIELD_SUBMITTIME, CommonUtils.replaceAll((String)item.get(IOvertimeDao.FIELD_SUBMITTIME), "-", "/"));
				item.put("beginTimeShow", CommonUtils.replaceAll((String)item.get("beginTimeShow"), "-", "/"));
				item.put("endTimeShow", CommonUtils.replaceAll((String)item.get("endTimeShow"), "-", "/"));
			}
		}
		
		// 替换下拉的值
		Map<String, String> fieldAndParamType = new HashMap<String, String>();
		fieldAndParamType.put(IOvertimeDao.FIELD_STATUS, "overtimeStatus");
		sysParamService.changeParamData(data, fieldAndParamType);

		return UTExcel.leadingout(fileds, data, tamlate, request, response);
	}
}
