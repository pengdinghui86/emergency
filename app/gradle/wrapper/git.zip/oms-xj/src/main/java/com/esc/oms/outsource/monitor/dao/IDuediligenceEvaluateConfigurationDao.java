package com.esc.oms.outsource.monitor.dao;

import org.esc.framework.persistence.dao.IBaseOptionDao;

/**
 * 尽职调查评估配置
 * @author owner
 *
 */
public interface IDuediligenceEvaluateConfigurationDao extends IBaseOptionDao{
	
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_EVALUATE_TITLE = "evaluateTitle";//评估标题
	public static final String  FIELD_BEGIN_DATE = "beginDate";//开始日期
	public static final String  FIELD_END_DATE = "endDate";//结束日期
	public static final String  FIELD_EVALUATOR = "evaluator";//评估人员
	public static final String  FIELD_OUTSIDE_SPECIALISTS = "outsideSpecialists";//外部专家
	public static final String  FIELD_ACCESS_RESULT = "accessResult";//评估结果
	public static final String  FIELD_STATUS = "status";//评估结果状态
	public static final String  FIELD_SUBMITTERNAME = "submitterName";//提交人
	public static final String  FIELD_SUBMITTIME = "submitTime";//提交时间
	public static final String  FIELD_RESULT_REMARK = "resultRemark";//评估说明
	
	public static final String[] inFileds = new String[] {
		FIELD_EVALUATE_TITLE,
		FIELD_BEGIN_DATE,
		FIELD_END_DATE,
		FIELD_EVALUATOR,
		FIELD_OUTSIDE_SPECIALISTS,
		FIELD_ACCESS_RESULT,
		FIELD_RESULT_REMARK
	};
	
	public static final String[] outFileds = new String[] {
		FIELD_EVALUATE_TITLE,
		FIELD_BEGIN_DATE,
		FIELD_END_DATE,
		FIELD_EVALUATOR,
		FIELD_OUTSIDE_SPECIALISTS,
		FIELD_ACCESS_RESULT,
		FIELD_STATUS,
		FIELD_SUBMITTIME,
		FIELD_SUBMITTERNAME,
		FIELD_RESULT_REMARK
	};
	
	
}
