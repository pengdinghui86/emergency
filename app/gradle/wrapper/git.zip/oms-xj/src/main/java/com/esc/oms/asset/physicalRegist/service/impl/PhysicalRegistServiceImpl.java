package com.esc.oms.asset.physicalRegist.service.impl;

import com.esc.oms.asset.allocation.service.IAssetAllocationlService;
import com.esc.oms.asset.physical.dao.IAssetPhysicalDao;
import com.esc.oms.asset.physical.service.IAssetPhysicalService;
import com.esc.oms.asset.physicalRegist.dao.IPhysicalRegistDao;
import com.esc.oms.asset.physicalRegist.service.IPhysicalRegistService;
import com.esc.oms.asset.place.service.IAssetPlaceService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.excel.UTExcelValidate;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.workflow.dao.IWorkflowInstanceDao;
import org.esc.framework.workflow.service.IWorkflowCode;
import org.esc.framework.workflow.service.IWorkflowEngine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.time.LocalDate;
import java.util.*;
import java.util.regex.Pattern;

@Service
@Transactional
public class PhysicalRegistServiceImpl extends BaseOptionService implements IPhysicalRegistService{
	
	
	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private IPhysicalRegistDao physicalRegistDao;
	
	@Resource
	private IAssetAllocationlService assetAllocationlService;
	
	@Resource
	private IAssetPlaceService assetPlaceService;
	
	@Resource
	private IAssetPhysicalService assetPhysicalService;
	
	@Resource
	private IWorkflowEngine workflowEngine;
	
	@Resource
	private IWorkflowInstanceDao workflowInstanceDao;
	
	@Resource
	private MessageSend messageSend;
	
	@Resource
	private ISysUserService userService;

	@Resource
	private IAssetPhysicalDao assetPhysicaDao;

	@Resource
	private ISysParamService sysParamService;
	
	@Override
	public void getPageInfo(Map params, UTPageBean pageBean) throws Exception{
		physicalRegistDao.getPageInfo(params, pageBean);
	}
	
	@EscOptionLog(module=SystemModule.physicalRegist, opType=ESCLogOpType.INSERT, table="assets_material_info",option="新增名称为{name}的实物资产登记信息。")
	public boolean add(Map info){
		boolean flag = false;
		info.put("sortCode", physicalRegistDao.getNewCode(101, "sortCode"));
		info.put("registStatus", "1");
		info.put("inventory_status", "1");
		flag = getOptionDao().add(info);
		if(flag){
			//更改辐设备的parentId
			List<Map> auxiliaryList =  (List<Map>) info.get("auxiliaryList");
			if(null != auxiliaryList && auxiliaryList.size() > 0){
				for (Map auxiliary : auxiliaryList) {
					UTMap<String,Object> map = new UTMap<String,Object>();
					map.put("id", auxiliary.get("id"));
					map.put("parentId", info.get("id"));
					getOptionDao().updateById(map);
				}
			}
		}
		return	flag;
	}
	
	@Override
	@EscOptionLog(module=SystemModule.physicalRegist, opType=ESCLogOpType.UPDATE, table="assets_material_info",option="修改名称为{name}的实物资产登记信息。")
	public boolean updateById(Map info){
		//更改辐设备的parentId
		List<Map> auxiliaryList =  (List<Map>) info.get("auxiliaryList");
		//先删除之前关联的辅设备
		assetPhysicalService.updateAuxiliaryById(String.valueOf(info.get("id")));
    	if(null != auxiliaryList && auxiliaryList.size() > 0){
    		
    		for (Map auxiliary : auxiliaryList) {
    			UTMap<String,Object> map = new UTMap<String,Object>();
    			map.put("id", auxiliary.get("id"));
    			map.put("parentId", info.get("id"));
    			getOptionDao().updateById(map);
			}
    	}
		return getOptionDao().updateById(info);
	}
	
	
	@Override
	@EscOptionLog(module=SystemModule.physicalRegist, opType=ESCLogOpType.DELETE, table="assets_material_info",option="删除名称为{name}的实物资产登记信息。")
	public boolean delete(Map info){
		return	getOptionDao().delete(info);
	}
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return physicalRegistDao;
	}


	@Override
	public boolean leadingin(String filePath, Map<String, Object> param)
			throws Exception {
		List<UTMap<String, Object>> leadinginList = new ArrayList<UTMap<String,Object>>();
		boolean flag = true;
		// 根据路径 获取工作薄
		Sheet sheet = UTExcel.getSheets(filePath)[0];
		// 导入顺序
		String[] cellArray = new String[] { 
				"资产编号（长度：0-20）", 
				"资产名称*（长度：0-20）", 
				"资产大类*",
				"资产小类*",
				"资产级别*",
				"资产序列号（长度：0-20）", 
				"存放地点", 
				"生产商（长度：0-20）", 
				"品牌（长度：0-20）", 
				"型号*（长度：0-20）", 
				"是否主设备",
				"预登记类型*",
				"借用预登记开始时间（格式：yyyy/MM/dd）",
				"借用预登记结束时间（格式：yyyy/MM/dd）", 
				"甲方联系人*（长度：0-50）",
				"甲方联系人电话*",
				"乙方联系人*（长度：0-50）",
				"乙方联系人电话*",
				"资产用途（长度：0-1000）",
				"实物价值（单价：元）（格式：最小值0，最大值999999999，最多俩位小数）",
				"辅设备序列号",
				"备注（长度：0-500）"
		};
		int[] lengthArr = {20, 20, 0, 0,0, 20, 0, 20, 20, 20, 0, 0, 0, 0, 50, 0, 50, 0, 1000, 0, 0, 500};
		String[] fields = new String[] {
				IAssetPhysicalDao.FIELD_CODE,
				IAssetPhysicalDao.FIELD_NAME,
				IAssetPhysicalDao.FIELD_CATEGORY,
				IAssetPhysicalDao.FIELD_SUBCATEGORY,
				IAssetPhysicalDao.FIELD_ASSETS_LEVEL,
				IAssetPhysicalDao.FIELD_SERIALNUM,
				IAssetPhysicalDao.FIELD_LOCATION,
				IAssetPhysicalDao.FIELD_PRODUCER,
				IAssetPhysicalDao.FIELD_BRAND,
				IAssetPhysicalDao.FIELD_MODEL,
				IAssetPhysicalDao.FIELD_AUXILIARYASSET,
				IAssetPhysicalDao.FIELD_PREASSETSCLASS,
				IAssetPhysicalDao.FIELD_PREBORROWASSETSSTARTDATE,
				IAssetPhysicalDao.FIELD_PREBORROWASSETSENDDATE,
				IAssetPhysicalDao.FIELD_PARTA_NAME,
				IAssetPhysicalDao.FIELD_PARTA_TELEPHONE,
				IAssetPhysicalDao.FIELD_PARTB_NAME,
				IAssetPhysicalDao.FIELD_PARTB_TELEPHONE,
				IAssetPhysicalDao.FIELD_ASSETSUSE,
				IAssetPhysicalDao.FIELD_ASSETSCOSTS,
				"serialNums",
				IAssetPhysicalDao.FIELD_REMARK
		};
		
		int rowNum = sheet.getLastRowNum();
		int cellNum = fields.length;
		
		//检查导入的字段标题
		try {
			List<String> realityCellllist=new ArrayList<String>();
			Row rowtitle=sheet.getRow(0);
			for (int j = 0; j < cellNum;j++) {
				realityCellllist.add(rowtitle.getCell(j).getStringCellValue());
			}
			String[] array =new String[realityCellllist.size()];
			if(!UTExcel.excelValidateByCell(cellArray, realityCellllist.toArray(array))){
				flag = false;
			}
		} catch (Exception e) {
			flag = false;
		}
		
		if(!flag) {
			throw new EscServiceException("导入失败，请选择正确的模板！");
		}
		
		//序列号和编号的唯一校验
		Set<String> codeSet = new HashSet<>();
		Set<String> serialNumSet = new HashSet<>();
		//辅资产的唯一校验
		Set<String> anxSet = new HashSet<>();
		StringBuilder error = new StringBuilder();
		for (int i = 1; i <= rowNum; i++) {
			// 遍历excel
			Row row = sheet.getRow(i);
			UTMap<String, Object> map = new UTMap<String, Object>();
			String parentId = null;//查询id
			for (int j = 0; j < cellNum; j++) {
				String cellvalue = null;
				Cell cell = row.getCell(j);
				//检查空 名称
				if( j == 1 || j == 2 || j == 3 || j==4 || j == 9 || j == 11 || j == 14 || j == 15 || j == 16 || j == 17) {
					if (cell == null || StringUtils.isEmpty(cell.getStringCellValue())) {
						error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "内容为空，请检查！" + "<br>");
					}
				}
				if (cell != null) {
					cell.setCellType(Cell.CELL_TYPE_STRING);
					cellvalue = cell.getStringCellValue();
					cellvalue = StringUtils.isEmpty(cellvalue) ? null : cellvalue.trim();
					if (cellvalue != null) {
						//长度校验
						if (lengthArr[j] != 0 && cellvalue.length() > lengthArr[j]){
							error.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "内容长度超出限制，请检查！" + "<br>");
						}
						if (StringUtils.equals(IAssetPhysicalDao.FIELD_CODE,
								fields[j])) {
							if(cellvalue != null){
								Map mapUt = new HashMap();
								mapUt.put("codeNum", cellvalue);
								mapUt.put("deleteFlag", 0);
								if(!codeSet.add(cellvalue)){
									error.append("行号为" + (i+1) + "的资产编号重复！" + "<br>");
								}
								if(super.isExist(mapUt)){
									error.append("行号为" + (i+1) + "的资产编号已经存在！" + "<br>");
								}
							}
						}
	
						//检查序列号唯一性
						if(StringUtils.equals(IAssetPhysicalDao.FIELD_SERIALNUM, fields[j])){
							if(cellvalue != null){
								Map mapUt = new HashMap();
								mapUt.put("serialNum", cellvalue);
								mapUt.put("deleteFlag", 0);
								if(!serialNumSet.add(cellvalue)){
									error.append("行号为" + (i+1) + "的资产序列号重复！" + "<br>");
								}
								if(super.isExist(mapUt)){
									error.append("行号为"+(i+1)+"的资产序列号已经存在！" + "<br>");
								}
							}
						}
	
						//辅资产的唯一性
						if(StringUtils.equals("serialNums", fields[j]) && cellvalue != null){
							if(cellvalue != null){
								String[] serialNumArr = cellvalue.split(",");
								for(String s : serialNumArr){
									if(!anxSet.add(s)){
										error.append("行号为" + (i+1) + "的辅资产重复！" + "<br>");
									}
								}
							}
						}
	
						if (StringUtils.equals(IAssetPhysicalDao.FIELD_CATEGORY,
								fields[j])) {
							Map<String,Object> category = new HashMap<String,Object>(); 
							category.put("name", cellvalue);
							cellvalue = assetAllocationlService.getCategoryIdByName(category);
							parentId = cellvalue;
							if(StringUtils.isEmpty(cellvalue)){
								error.append("Excel内容错误，行号为" + (i+1) + "的资产大类在系统中不存在，请检查！" + "<br>");
							}
						}
						if (StringUtils.equals(IAssetPhysicalDao.FIELD_SUBCATEGORY,
								fields[j])) {
							Map<String,Object> category = new HashMap<String,Object>();
							category.put("name", cellvalue);
							category.put("parentId", parentId);
							cellvalue = assetAllocationlService.getCategoryIdByName(category);
							if(StringUtils.isEmpty(cellvalue)){
								error.append("Excel内容错误，行号为" + (i+1) + "的资产小类在系统中不存在，请检查！" + "<br>");
							}
						}
	
						if (StringUtils.equals(IAssetPhysicalDao.FIELD_ASSETS_LEVEL,
								fields[j])) {
							cellvalue = sysParamService.getParamValueByName("assetsLevel", cellvalue);
							if(StringUtils.isEmpty(cellvalue)){
								error.append("Excel内容错误，行号为" + (i+1) + "的资产级别在系统中不存在，请检查！" + "<br>");
							}
						}
						if (StringUtils.equals(IAssetPhysicalDao.FIELD_LOCATION,
								fields[j])) {
							if(cellvalue != null){
								try {
									cellvalue = getPlaceId(cellvalue,i,"存放地点");
								}catch(EscServiceException e) {
									error.append(e.getMessage());
								}
							}
							
						}
						
						if (StringUtils.equals(IAssetPhysicalDao.FIELD_AUXILIARYASSET,
								fields[j])) {
							if(null != cellvalue && !"".equals(cellvalue)){
								if("是".equals(cellvalue)){
									cellvalue = "1";
								}else if("否".equals(cellvalue)){
									cellvalue = "0";
								}else{
									error.append("Excel内容错误，行号为" + (i+1) + "的"+cellArray[j]+"格式不对，请检查！" + "<br>");
								}
							}
						}
						
						//检查登记类型
						if(StringUtils.equals(IAssetPhysicalDao.FIELD_PREASSETSCLASS, fields[j])) {
							if(cellvalue != null && !"".equals(cellvalue)) {
								if("预登记".equals(cellvalue)) {
									cellvalue = "1";
								}else if("借用预登记".equals(cellvalue)) {
									cellvalue = "2";
								}else {
									error.append("Excel内容错误，行号为" + (i+1) + "的"+cellArray[j]+"格式不对，请检查！" + "<br>");
								}
							}
						}
						
						//检查时间格式
						if(StringUtils.equals(IAssetPhysicalDao.FIELD_PREBORROWASSETSSTARTDATE, fields[j]) ||
								StringUtils.equals(IAssetPhysicalDao.FIELD_PREBORROWASSETSENDDATE, fields[j])) {
							if(cellvalue != null && !"".equals(cellvalue)) {
								if(!CommonUtils.validateDate(cellvalue)) {
									error.append("Excel内容错误，行号为" + (i+1) + "的"+cellArray[j]+"格式不对，请检查！" + "<br>");
								}
							}
						}
						//检查联系方式
						if(StringUtils.equals(IAssetPhysicalDao.FIELD_PARTA_TELEPHONE, fields[j]) ||
								StringUtils.equals(IAssetPhysicalDao.FIELD_PARTB_TELEPHONE, fields[j])){
							if(cellvalue != null)
							{
								if (cellvalue.length() > 20) {
									error.append("Excel内容错误，行号为" + (i+1) + "的"+cellArray[j]+"格式不对，请检查！" + "<br>");
								}
								else {
									String regex = "(^[\\d-]+$)"; 
									if (!Pattern.matches(regex, cellvalue)) {
										error.append("Excel内容错误，行号为" + (i+1) + "的"+cellArray[j]+"格式不对，请检查！" + "<br>");
									}
								}
							}
							/*if(!CommonUtils.isMobile(cellvalue)){
								error.append("Excel内容错误，行号为" + (i+1) + "的"+cellArray[j]+"格式不对，请检查！" + "<br>");
							}*/
						}
						//检查数字
						if(StringUtils.equals(IAssetPhysicalDao.FIELD_ASSETSCOSTS, fields[j])) {
							if(cellvalue != null && !"".equals(cellvalue)) {
								if(!UTExcelValidate.validateNumber(cellvalue)) {
									error.append("Excel内容错误，行号为" + (i+1) + "的"+cellArray[j]+"格式不对，请检查！" + "<br>");
								}
							}
						}
					}
				}
				map.put(fields[j], cellvalue);
			}
			//预登记不需要记录借用时间
			
			if("1".equals(map.get("preAssetsClass"))) {
				map.remove("preBorrowAssetsStartDate");
				map.remove("preBorrowAssetsEndDate");
			}
//			map.put("sortCode", assetPhysicalDao.getNewCode(101, "sortCode"));
			leadinginList.add(map);
		}
		for (int i = 0; i < leadinginList.size(); i++) {
			UTMap riskgMap = leadinginList.get(i);
			String preAssetsClass = (String) riskgMap.get("preAssetsClass");
			////借用预登记开始时间<=借用预登记结束时间
			if(riskgMap.get("preBorrowAssetsStartDate") != null && riskgMap.get("preBorrowAssetsEndDate") != null){
				LocalDate startDate = LocalDate.parse(CommonUtils.replaceAll((String)riskgMap.get("preBorrowAssetsStartDate"), "/", "-"));
				LocalDate endDate = LocalDate.parse(CommonUtils.replaceAll((String)riskgMap.get("preBorrowAssetsEndDate"), "/", "-"));
				if(startDate.isAfter(endDate)){
					error.append("Excel内容错误，行号为" + (i+2) + "的借用预登记开始时间需小于等于借用预登记结束时间，请检查！" + "<br>");
				}
			}
			
			//检查辅资产的合理性
			String value = (String) riskgMap.get("serialNums");
			//辅资产不为空且 当前是主资产
			if(((value == null) ? false : (value.length() > 0)) && "1".equals((String) riskgMap.get("auxiliaryAsset"))){
				String[] serialNumArr = value.split(",");
				List<Map> auxiliaryList = new ArrayList<>();
				for(String s : serialNumArr){
					//根据资产序列号获取资产
					UTMap<String, Object> aserialMap = assetPhysicaDao.getAssetBySerialNum(s);
					if(aserialMap == null){
						error.append("Excel内容错误，行号为"+(i+2)+"的辅资产序列号"+s+"不存在！" + "<br>");
					}else if(!StringUtils.equals(preAssetsClass, (String) aserialMap.get("preAssetsClass"))){
						error.append("Excel内容错误，行号为"+(i+2)+"的所选辅资产类型和主资产类型不匹配！" + "<br>");
					}else if("1".equals(preAssetsClass) && !StringUtils.equals(IPhysicalRegistService.STATUS_FINISH+"", (String) aserialMap.get("status"))){
						error.append("Excel内容错误，行号为"+(i+2)+"的所选辅资产不是审批完成的状态！" + "<br>");
					}else if("1".equals(aserialMap.get("auxiliaryAsset"))){
						error.append("Excel内容错误，行号为"+(i+2)+"的所选辅资产"+s+"为主设备！" + "<br>");
					}
				}
			}
		
		}
		if (StringUtils.isNotEmpty(error.toString())) {
			throw new EscServiceException(error.toString());
		}
		
		//保存到数据库
		for (int i = 0; i < leadinginList.size(); i++) {
			UTMap riskgMap = leadinginList.get(i);

			//资产的类别
			String preAssetsClass = (String) riskgMap.get("preAssetsClass");
			
			//检查辅资产的合理性
			String value = (String) riskgMap.get("serialNums");
			//辅资产不为空且 当前是主资产
			if(((value == null) ? false : (value.length() > 0)) && "1".equals((String) riskgMap.get("auxiliaryAsset"))){
				String[] serialNumArr = value.split(",");
				List<Map> auxiliaryList = new ArrayList<>();
				for(String s : serialNumArr){
					//根据资产序列号获取资产
					UTMap<String, Object> aserialMap = assetPhysicaDao.getAssetBySerialNum(s);
					auxiliaryList.add(aserialMap);
				}
				riskgMap.put("auxiliaryList", auxiliaryList);
			}

			if("1".equals(preAssetsClass)){
				riskgMap.put("status", STATUS_FINISH);
			}
			add(riskgMap);
		}
		return flag;
	}

	@Override
	public boolean leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String[] fileds = new String[] { 
				IAssetPhysicalDao.FIELD_CODE,
				IAssetPhysicalDao.FIELD_NAME,
				IAssetPhysicalDao.FIELD_CATEGORYNAME,
				IAssetPhysicalDao.FIELD_SUBCATEGORYNAME,
				IAssetPhysicalDao.FIELD_ASSETS_LEVEL,
				IAssetPhysicalDao.FIELD_PREASSETSCLASS,
				IAssetPhysicalDao.FIELD_REGISTSTATUS
				
		};
		String tamlate="excelOutTamplate.physicalRegist";	
		return	UTExcel.leadingout( fileds, data, tamlate, request,response);
	}

	
	private String getPlaceId(String placeNameAndplaceCodes, int lineNum, String title) {
		Map<String, Object> param = new HashMap<String, Object>();
		String returnIds = "";
		String tip = "Excel内容错误，行号为" + (lineNum + 1) + "的" + title;
		try {
			if((placeNameAndplaceCodes == null) ? false : (placeNameAndplaceCodes.length() > 0)) {
				for (String placeNameAndplaceCode : StringUtils.split(placeNameAndplaceCodes, ",")) {
//					if(StringUtils.indexOf(placeNameAndplaceCode, "/") != -1) {
						String[] nameAndCode = placeNameAndplaceCode.split("/", 2);
						String name = nameAndCode[0];
						String codeName = "";
						if(nameAndCode.length == 2) {
							codeName = nameAndCode[1];
						}
						
						List<UTMap<String, Object>> places = null;
						param.clear();
						if(StringUtils.isNotEmpty(name)){
							param.put("name", name);
						}
						if(StringUtils.isNotEmpty(codeName)){
							param.put("codeName", codeName);
						}
						places = assetPlaceService.getListMaps(param, "id");
						if(places == null || places.size() == 0) {
							throw new EscServiceException(tip + ":"
									+ placeNameAndplaceCode
									+"在系统中不存在，请检查！");
						}
						if(places.size() > 1) {
							throw new EscServiceException(tip + ":系统存在重名的存放地点【"+placeNameAndplaceCode+"】，无法匹配，请加入用户编号！");
						}
						UTMap<String, Object> place = places.get(0);
						
						if((returnIds == null) ? false : (returnIds.length() > 0)) {
							returnIds += ",";
						}
						returnIds += (String) place.get("id");
//					} else {
//						throw new EscServiceException( tip + "格式不正确，请检查！");
//					}
				}
			}
		} catch (EscServiceException e) {
			throw e;
		} catch (Exception e) {
			logger.error("Exception",e);
			throw new EscServiceException(tip + "格式不正确，请检查！");
		}

		return returnIds;
	}

	@Override
	public List<UTMap<String, Object>> getAssetBycodeAndId(String codeNum,
			String id) {
		return physicalRegistDao.getAssetBycodeAndId(codeNum, id);
	}

	@Override
	public void getPendPageList(Map<String, Object> params, UTPageBean pageBean) throws Exception {
		physicalRegistDao.getPendPageList(params, pageBean);
	}

	@Override
	public void getAlreadyApprovalPageList(Map<String, Object> params, UTPageBean pageBean) throws Exception {
		physicalRegistDao.getAlreadyApprovalPageList(params, pageBean);
	}

	@Override
	public void submit(Map<String, Object> map) throws Exception {
		map.put("registStatus", "1");//预登记
		map.put("status", STATUS_WAITING);
		map.put("deleteFlag", 0);
		//updateById(map);
		String recordId = saveOrUpdateSub(map);
		String workflowInstanceId = workflowEngine.runInstance(IWorkflowCode.PHYSICAL_ASSET_PREAPPLY, recordId);
		//info.put("workflowInstanceId", workflowInstanceId);
		//saveOrUpdate(info);
		setInstanceId(recordId, workflowInstanceId);
	}


	/**
	 * 包含辅助资产的添加和修改
	 * @param map
	 * @return
	 */
	private String saveOrUpdateSub(Map<String,Object> map){
		if(map.get("id") == null){
			this.add(map);
		}
		else{
			this.updateById(map);
		}
		return (String)map.get("id");
	}
	/**
	 * 设置 workflowInstanceId 
	 * @param recordId
	 * @param workflowInstanceId
	 */
	private void setInstanceId(String recordId,String workflowInstanceId){
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("workflowInstanceId", workflowInstanceId);
		super.updateById(map);
	}


	/**
	 * 普通的删除和修改
	 * @param map
	 * @return
	 */
	private String saveOrUpdate(Map<String,Object> map){  
		if(map.get("id") == null){
    		super.add(map);
    	}
		else{
    		super.updateById(map);
    	}
		return (String)map.get("id");
    }


	@Override
	public void finishAudit(String recordId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("status", STATUS_FINISH);
		saveOrUpdate(map);
	}

	@Override
	public void rejectAudit(String recordId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("status", STATUS_REJECT);
		saveOrUpdate(map);
		//黑名单审批被驳回后发送给申请人
		UTMap<String, Object> info = this.getById(recordId);
		UTMap<String, Object> user = this.getApplyUser(info.get("workflowInstanceId").toString());
		
		if (user != null) {
			String applyUserId = (String)user.get("id");
			String title = "资产【" + (String)info.get("name") + "】预登记申请驳回提醒";
			String content = "资产【" +(String)info.get("name") +"】的预登记申请已被驳回，请知悉！详情请进入系统查看";
			messageSend.sendMessage(applyUserId, title, content, MessageSend.Type.MAIL, MessageSend.Type.SYSTEM);
		}
				
	}
	
	/**
	 * @param workflowInstanceId 流程ID
	 * @return 申请人对象
	 */
	private UTMap<String, Object> getApplyUser(String workflowInstanceId){
		List<UTMap<String,Object>> workflowHistorys = workflowInstanceDao.getWorkflowHistorys(workflowInstanceId, "开始");
		if(workflowHistorys != null && workflowHistorys.size() > 0) {
			// 按照创建时间倒序排序的，如果多次提及，会有多个开始，第一个就是最晚提交的人，name/code
			UTMap<String, Object> beginStep = workflowHistorys.get(0);
			String createUser = (String) beginStep.get("createUser");
			if(createUser != null && createUser.contains("/")) {
				int regexIndex = createUser.indexOf("/");
				UTMap<String, Object> user = userService.getUserBaseByNameOrCode(createUser.substring(regexIndex+1, createUser.length()), createUser.substring(0, regexIndex));
				if(user != null) {
					return user;
				}
			}
		}
		return  null;
	}

	@Override
	public void terminateAudit(String recordId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("status", STATUS_TERMINATE);
		saveOrUpdate(map);
		//审批被终止后发送给申请人
		UTMap<String, Object> info = this.getById(recordId);
		UTMap<String, Object> user = this.getApplyUser(info.get("workflowInstanceId").toString());
		
		if (user != null) {
			String applyUserId = (String)user.get("id");
			String title = "资产【" + (String)info.get("name") + "】预登记申请终止提醒";
			String content = "资产【" +(String)info.get("name") +"】的预登记申请已被终止，请知悉！详情请进入系统查看";
			messageSend.sendMessage(applyUserId, title, content, MessageSend.Type.MAIL, MessageSend.Type.SYSTEM);
		}
	}

	@Override
	public void optionNode(String workflowCode, String recordId, String nodeName, String linkName) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("status", STATUS_AUDITING);
		saveOrUpdate(map);
	}
}