package com.esc.oms.outsource.emergency.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.outsource.emergency.service.IEmergCommunService;
import com.esc.oms.outsource.train.service.IOutTrainService;
import com.esc.oms.supplier.commun.service.ICommunRecordService;
import com.esc.oms.util.CommonUtils;
@Controller
@RequestMapping("emergCommun")
public class EmergCommunController extends BaseOptionController {


	@Resource
	private IEmergCommunService emergCommunService;
	
	@Resource 
	private  ISysUserService userService;
	
	@Resource
	private ICommunRecordService communRecordService;
	
	@Resource
	private IOutTrainService outTrainService;
	
	@Override
	public IBaseOptionService optionService() {
		return emergCommunService;
	}
	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			emergCommunService.getPageInfo(pageBean, params);
//			List<Map<String, Object>> list = pageBean.getRows();
//			if( list!= null){
//				for (Map<String, Object> map : list) {
//					String promoterName = "";
//					String promoter = (String) map.get("promoter");
//					promoterName = getUserName(promoter, promoterName);
//					map.put("promoter", promoterName);
//				}
//			}
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
    @RequestMapping(value="/saveOrUpdate",method=RequestMethod.POST)  
    @ResponseBody
    public String saveorupdate(@RequestBody Map<String,Object> map){  
    	String name = (String)map.get("name");
    	String id = (String)map.get("id");
    	try{
	    	if(id == null){
	    		Map param = new HashMap();
	    		param.put("name", name);
	    		if(emergCommunService.isExist(param)){
	    			throw new EscServiceException("演练名称已经存在！");
	    		}
	    		emergCommunService.add(map);
	    	}else{
	    		List<UTMap<String,Object>> titles = emergCommunService.getEmergCommunByNameAndId(name, id);
	    		if(null != titles && titles.size() > 0){
	    			throw new EscServiceException("演练名称已经存在！");
	    		}
	    		emergCommunService.updateById(map);
	    	}
    	}catch(EscServiceException e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false,e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "操作成功");
    }
    
    /**
	 * 根据id查询
	 * @param param
	 * @return
	 */
	@RequestMapping(value="getById")
	@ResponseBody
	public UTMap<String, Object> defgetById(@RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = null;
    	try{
    		map = optionService().getById(param.get("id").toString());
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return map;
	}
	
	public  String getUserName(String param, String userName) {
		if(StringUtils.isNotEmpty(param)){
			String[] ids = param.split(",");
			for (String id : ids) {
				UTMap<String, Object> user = userService.getById(id);
				if(null != user){
					userName += user.get("name")+",";
				}
				continue;
			}
			if(StringUtils.isNotEmpty(userName)){
				userName = userName.substring(0, userName.length()-1);
			}
		}
		return userName;
	}
	
	@RequestMapping(value="defdelete")
	@ResponseBody
	public String defdelete(@RequestBody Map<String, Object> param){
		boolean flag = false;
		try{
			flag = optionService().deleteById(param.get("id").toString());
			if(flag){
				if("YJPX".equals(param.get("communicateType").toString())){
					outTrainService.deleteByEmerCommunId(param.get("id").toString());
				}else if("YJHY".equals(param.get("communicateType").toString())){
					communRecordService.deleteByEmerCommunId(param.get("id").toString());
				}
			}
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "删除失败");
    	}
    	return UTJsonUtils.getJsonMsg(true, "删除成功");
	}
	
}