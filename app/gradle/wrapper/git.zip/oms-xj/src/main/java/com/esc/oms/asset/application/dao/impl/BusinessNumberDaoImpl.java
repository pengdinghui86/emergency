package com.esc.oms.asset.application.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Repository;

import com.esc.oms.asset.application.dao.IBusinessNumberDao;

/**
 * 业务编号
 * @author yinyao
 * @createTime 2015-6-30 上午11:39:04
 */
@Repository
public class BusinessNumberDaoImpl extends BaseOptionDao implements IBusinessNumberDao{

	@Override
	public String getTableName() {
		return "business_number";
	}
	
	@Override
	public List<UTMap<String, Object>> findByParams(Map<String, Object> params) {
		String sql=this.getSearchSql(params);
		return this.getListBySql(sql.toString(), null);
	}

	private String getSearchSql(Map<String, Object> param) {
		StringBuilder sql=new StringBuilder();
		sql.append("select bn.id ,bn.acronym,bn.busType,bn.number ");
		sql.append(" from "+getTableName() +" bn");
		sql.append(" where 1=1 " );
		if(param!=null && param.size()>0){
			String acronym=param.get("acronym")!=null?param.get("acronym").toString():null;
			String busType=param.get("busType")!=null?param.get("busType").toString():null;
			String number=param.get("number")!=null?param.get("number").toString():null;
			String busId=param.get("busId")!=null?param.get("busId").toString():null;
			if((acronym == null) ? false : (acronym.length() > 0)){
				sql.append(" and bn.acronym = '"+acronym.trim()+"'");
			}
			if((busType == null) ? false : (busType.length() > 0)){
				sql.append(" and bn.busType = '"+busType.trim()+"'");
			}
			if((number == null) ? false : (number.length() > 0)){
				sql.append(" and bn.number = '"+number.trim()+"'");
			}
			if((busId == null) ? false : (busId.length() > 0)){
				sql.append(" and bn.busId = '"+busId.trim()+"'");
			}
		}
		return sql.toString();
	}

	@Override
	public boolean updateByParams(Map<String, Object> params) {
		String sql=this.getUpdateSql(params);
		return this.executeUpdate(sql, null);
	}
	
	private String getUpdateSql(Map<String, Object> param){
		StringBuilder sql=new StringBuilder();
		String number = (String) param.get("number");
		sql.append("update "+getTableName()+" bn ");
		sql.append(" set bn.number = '"+number+"'");
		sql.append(" where 1=1 " );
		if(param!=null && param.size()>0){
			String acronym=param.get("acronym")!=null?param.get("acronym").toString():null;
			String busType=param.get("busType")!=null?param.get("busType").toString():null;
			if((acronym == null) ? false : (acronym.length() > 0)){
				sql.append(" and bn.acronym = '"+acronym.trim()+"'");
			}
			if((busType == null) ? false : (busType.length() > 0)){
				sql.append(" and bn.busType = '"+busType.trim()+"'");
			}
		}
		return sql.toString();
	}

	@Override
	public String saveOrUpdate(String acronym, String busType,String formart) {
		Map<String, Object> business = new HashMap<String, Object>();
		String str = "";
		String code = "";
		business.put("acronym", acronym);
		business.put("busType", busType);
		List<UTMap<String, Object>> busList = this.findByParams(business);
		if(null != busList && busList.size() > 0){
			UTMap<String, Object> bus =  busList.get(0);
			if(null != bus){
				Integer num = Integer.parseInt(bus.get("number").toString());
				    num ++;
				    business.put("number", num+"");
				    str = String.format(formart, num); 
			}
			this.updateByParams(business);
		}else{
			 business.put("number", "1");
			 str = String.format(formart, 1);
			 this.add(business);
		}
		code = business.get("acronym")+"-"+business.get("busType")+"-"+str;
		return code;
	}

}