package com.esc.oms.asset.softwareApplication.service;

import java.util.List;
import java.util.Map;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;

public interface IAppSoftHistoryService extends IBaseOptionService {
	public List<UTMap<String, Object>> getHistoryListBySoftId(Map param);

	public List<UTMap<String, Object>> getHistoryListByDisableDate(Map param);
}
