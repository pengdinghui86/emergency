package com.esc.oms.asset.retirement.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.idgenerator.IDGenerationManager;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.workflow.annotation.WorkflowRecordQueryMark;
import org.esc.framework.workflow.service.IWorkflowEngine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.asset.application.dao.IBusinessNumberDao;
import com.esc.oms.asset.mediumDestroy.service.IAssetDestroyService;
import com.esc.oms.asset.overview.service.IAssetsTrackInfoService;
import com.esc.oms.asset.physical.service.IAssetPhysicalService;
import com.esc.oms.asset.retirement.dao.IAssetRetirementDao;
import com.esc.oms.asset.retirement.service.IAssetRetirementService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;

@Service
@Transactional
//public class AssetRetirementServiceImpl extends BaseOptionService implements IAssetRetirementService,IWorkflowCallback{
	

public class AssetRetirementServiceImpl extends BaseOptionService implements IAssetRetirementService{
	protected Logger logger = LoggerFactory.getLogger(getClass());
	
	@Resource
	private IAssetRetirementDao assetRetirementDao;
	@Resource
	private IAssetPhysicalService assetPhysicalService;
	@Resource
	private IBusinessNumberDao businessNumberDao;
	
	@Resource
	private IWorkflowEngine workflowEngine;
	
	@Resource
	private IUserTaskService userTaskService;
	
	@Resource
	private IAssetsTrackInfoService assetsTrackInfoService;
	
	@Resource
	private MessageSend messageService;
	
	@Resource
	private ISysUserService sysUserService;
	
	@Resource
	private IAssetDestroyService destroyService;

	@Override
	public IBaseOptionDao getOptionDao() {
		return assetRetirementDao;
	}
	

	public static final String STATUS_OVER = "1";	// 已完成
	public static final String STATUS_NO_OVER = "0";	// 未完成
	
	@Override
	@WorkflowRecordQueryMark
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageInfo(pageBean, params);
	}
	
	@Override
	@WorkflowRecordQueryMark
	public List<UTMap<String, Object>> getListMaps(Map param) {
		return super.getListMaps(param);
	}
	
	@Override
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	@EscOptionLog(module=SystemModule.assetRetirement, opType=ESCLogOpType.INSERT, table="assets_material_repair_scrap",option="新增名称为{name}的资产报废信息。")
	public boolean add(Map info){
		info.put("createUserId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
		info.put("code", IDGenerationManager.nextId("assetsRetirementCode")); // 自动生成编号
		return	getOptionDao().add(info);
	}
	
	
	@Override
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	@EscOptionLog(module=SystemModule.assetRetirement, opType=ESCLogOpType.UPDATE, table="assets_material_repair_scrap",option="修改名称为{name}的资产报废信息。")
	public boolean updateById(Map info){
		List assetsList =  (List) info.get("assetsList");
		boolean flag = false;
		flag = getOptionDao().updateById(info);
		if(flag){
			if(null != assetsList){
				deleteAssetsById((String)info.get("id"));//先删除关联再重新添加关联
				for (Object obj : assetsList) {
					Map asset = (Map)obj;
					UTMap<String, Object> ut = new UTMap<String,Object>();
					ut.put("applyId", info.get("id"));
					ut.put("assetsId", asset.get("id"));
					addRelation(ut);
				}
			}
			
		}
		return flag;
	}
	
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		return super.getById(id);
	}
	
	private String saveOrUpdate(Map<String,Object> map){  
		List assetsList =  (List) map.get("assetsList");
		String status = (String)map.get("status");
		String scrapDate = map.get("scrapDate").toString();
    	boolean flag = false;
    	if(null != assetsList){
    		flag = updateAssetsInfo(assetsList, map);
    	}
		if(map.get("id") == null){
			flag = add(map);
    	}else{
    		flag = updateById(map);
    	}
		if(flag){
			if(null != assetsList){
				deleteAssetsById((String)map.get("id"));//先删除关联再重新添加关联
				for (Object obj : assetsList) {
					Map asset = (Map)obj;
					UTMap<String, Object> ut = new UTMap<String,Object>();
					ut.put("applyId", map.get("id"));
					ut.put("assetsId", asset.get("id"));
					ut.put("isDestroy", asset.get("isDestroy"));
					addRelation(ut);
				}
			}
			
		}
		//是否已完成
		if(StringUtils.equals(status, STATUS_OVER)) {
		//if(compareDate(scrapDate)&&StringUtils.equals(status, STATUS_OVER)) {
			//destroyService.addDestroyByRetirement(assetsList);
			String id=(String)map.get("id");
			//----资产轨迹----
			//List<UTMap<String,Object>> list = assetRetirementDao.getAssetsById(id);
			UTMap<String,Object> retirement = assetRetirementDao.getById(id);
			if(null != assetsList && assetsList.size() > 0){
				for (Object obj : assetsList) {
					Map assetObj = (Map)obj;
					UTMap<String,Object> assets = new UTMap<String,Object>();
					assets.put("assetsId", assetObj.get("id"));
					assets.put("type", 1);//实物资产
					if(null != assets){
						assets.put("userId", retirement.get("createUserId"));
						UTMap<String,Object> person = sysUserService.getById(String.valueOf(retirement.get("createUserId")));
						if(null != person){
							assets.put("departId",person.get("orgId"));
						}
					}
					assets.put("changeType","报废"); 
					assets.put("changeTime", retirement.get("scrapDate"));
					assets.put("changeRemark", "资产报废，报废原因:"+retirement.get("reason"));
					assetsTrackInfoService.add(assets);
					
					UTMap<String,Object> ut = new UTMap<String,Object>();
					ut.put("id", (String)assetObj.get("id"));
					
					ut.put("isScrap", 1); // add by huangyi 2016-05-12
					ut.put("scrapDate", retirement.get("scrapDate"));
					ut.put("assetStatus", "5");
					assetPhysicalService.updateById(ut);
				}
			}
		}else {
			Map<String,Object> item =new HashMap<String, Object>();
			map.put("id",map.get("id"));
			map.put("status","0");
			updateById(map);
		}
		return (String)map.get("id");
    }
	
//	
//	
//	@CronTimeTask(description="每天凌晨定时更新当天需要作废的资产信息",cron="0 45 19 * * ?")
//	public void generate() {
//		logger.info("开始定时更新当天需要作废的资产信息！=========================================================");
//		UTMap<String,Object> map = new UTMap<String,Object>();
//		map.put("allocationDate", new Date());
//		//不需要审核的 及已经审核完成
//		//是否已完成
//		if(compareDate(scrapDate)&&StringUtils.equals(status, STATUS_OVER)) {
//			//destroyService.addDestroyByRetirement(assetsList);
//			String id=(String)map.get("id");
//			//----资产轨迹----
//			//List<UTMap<String,Object>> list = assetRetirementDao.getAssetsById(id);
//			UTMap<String,Object> retirement = assetRetirementDao.getById(id);
//			if(null != assetsList && assetsList.size() > 0){
//				for (Object obj : assetsList) {
//					Map assetObj = (Map)obj;
//					UTMap<String,Object> assets = new UTMap<String,Object>();
//					assets.put("assetsId", assetObj.get("id"));
//					assets.put("type", 1);//实物资产
//					if(null != assets){
//						assets.put("userId", retirement.get("createUserId"));
//						UTMap<String,Object> person = sysUserService.getById(String.valueOf(retirement.get("createUserId")));
//						if(null != person){
//							assets.put("departId",person.get("orgId"));
//						}
//					}
//					assets.put("changeType","报废"); 
//					assets.put("changeTime", retirement.get("scrapDate"));
//					assets.put("changeRemark", "资产报废，报废原因:"+retirement.get("reason"));
//					assetsTrackInfoService.add(assets);
//					
//					UTMap<String,Object> ut = new UTMap<String,Object>();
//					ut.put("id", (String)assetObj.get("id"));
//					
//					ut.put("isScrap", 1); // add by huangyi 2016-05-12
//					ut.put("scrapDate", retirement.get("scrapDate"));
//					ut.put("assetStatus", "5");
//					assetPhysicalService.updateById(ut);
//				}
//			}
//		}
//		logger.info("成功定时更新当天需要转移的资产信息！=========================================================");
//	}
	

	private boolean compareDate(String allocationDate) {
		   try {
			Date nowDate = new Date();
			   SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			   Date allocDate = sdf.parse(allocationDate);
			   boolean flag = allocDate.before(nowDate);
			   return flag;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			  return false;
		}
	 }
	
	@Override
	public boolean addRelation(Map info) {
		return assetRetirementDao.addRelation(info);
	}

	@Override
	public List<UTMap<String, Object>> getAssetsById(String id) {
		return assetRetirementDao.getAssetsById(id);
	}

	@Override
	public boolean deleteAssetsById(String id) {
		return assetRetirementDao.deleteAssetsById(id);
	}


	@Override
	public boolean leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String[] fileds = new String[] { 
				IAssetRetirementDao.FIELD_CODE,
				IAssetRetirementDao.FIELD_NAME,
				IAssetRetirementDao.FIELD_REASON,
				IAssetRetirementDao.FIELD_SCRAPDATE,
				IAssetRetirementDao.FIELD_CREATEUSER,
				IAssetRetirementDao.FIELD_CREATETIME,
				IAssetRetirementDao.FIELD_REMARK,
				IAssetRetirementDao.FIELD_STATUS
		};
		if (null != data && !data.isEmpty()) {
			for (int i=0;i<data.size();i++) {
				UTMap<String, Object> item = (UTMap<String, Object>) data.get(i);
				item.put(IAssetRetirementDao.FIELD_SCRAPDATE, 
						CommonUtils.replaceAll((String)item.get(IAssetRetirementDao.FIELD_SCRAPDATE), "-", "/"));
				item.put(IAssetRetirementDao.FIELD_CREATETIME, 
						CommonUtils.replaceAll((String)item.get(IAssetRetirementDao.FIELD_CREATETIME), "-", "/"));
			}
		}
		String tamlate="excelOutTamplate.assetRetirement";	
		return	UTExcel.leadingout( fileds, data, tamlate, request,response);
	}

	@Override
	public List<UTMap<String, Object>> getAssetsList(Map param) {
		return assetRetirementDao.getAssetsList(param);
	}


	@Override
	public boolean updateAssetsInfo(List assetsList,Map<String, Object> map) {
		String ids = "";
		String newPlace = (String)map.get("newPlace");
		String newDepartId = (String)map.get("newDepartId");
		String newChargeId = (String)map.get("newChargeId");
		for (Object  obj : assetsList) {
			Map utMap = (Map)obj;
			ids += "'"+utMap.get("id").toString()+"',";
		}
		if(StringUtils.isNotEmpty(ids)){
			ids = ids.substring(0,ids.length()-1);
		}
		return assetPhysicalService.updateInfoByIds(newPlace, newChargeId, newDepartId, ids);
	}
	
	@EscOptionLog(module=SystemModule.assetRetirement, opType=ESCLogOpType.DELETE, table="assets_material_repair_scrap",option="删除名称为{name}的资产报废信息。")
	public boolean deleteById(String id){
		 boolean flag = getOptionDao().deleteByIds(id);
		if(flag){
			flag = assetRetirementDao.deleteAssetsById(id);
		}
		return	flag;
	}
	
	public boolean deleteByIds(String ids){
		boolean flag = false;
			String[] detIds = ids.split(",");
			flag = getOptionDao().deleteByIds(ids);
			if(flag && detIds.length > 0){
				for (String id : detIds) {
					flag = assetRetirementDao.deleteAssetsById(id);
				}
			}
		return flag;
	}

	@Override
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public void save(Map<String, Object> map) {
		saveOrUpdate(map);
	}

}