package com.esc.oms.asset.agreement.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.asset.agreement.dao.IAssetsAgreementWarnConfigDao;
import com.esc.oms.asset.agreement.service.IAssetsAgreementWarnConfigService;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;

@Service
@Transactional
public class AssetsAgreementWarnConfigServiceImpl extends BaseOptionService implements IAssetsAgreementWarnConfigService{

	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private IAssetsAgreementWarnConfigDao dao;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return dao;
	}

	/**
	 * 添加
	 * @param info
	 * @return
	 */
	@EscOptionLog(module=SystemModule.ASSETS_AGREEMENT_WARN_CONFIG, opType=ESCLogOpType.INSERT, table="assets_agreement_warn_config", primaryKey="id={1.id}",option="新增预警类型为{1.type}的资产合同预警配置")
	public boolean add(Map info){
		return super.add(info);		
	}
	
	@Override
	@EscOptionLog(module=SystemModule.ASSETS_AGREEMENT_WARN_CONFIG, opType=ESCLogOpType.UPDATE, table="assets_agreement_warn_config", primaryKey="id={1.id}",option="修改预警类型为{1.type}的资产合同预警配置")
	public boolean updateById(Map info){
		return super.updateById(info);			
	}
	
	@Override
	@EscOptionLog(module=SystemModule.ASSETS_AGREEMENT_WARN_CONFIG, opType=ESCLogOpType.DELETE, table="assets_agreement_warn_config",primaryKey="{1}",option="删除预警类型为{type}的资产合同预警配置")
	public boolean deleteById(String id){			
		return super.deleteById(id);			
	}
	
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map param) {
		dao.getPageInfo(pageBean, param);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params){
		return dao.getListAll(params);
	}
	
	/**
	 * 获取警告天数
	 * @return
	 */
	public UTMap<String, Object> getWarnNumList(){
		return dao.getWarnNumList();
	}
//	
//	/**
//	 * 根据领用记录id（applyId）删除
//	 * @param infoId
//	 * @return
//	 */
//	@Override
//	public boolean deleteByInfoId(String assetsAgreementId){
//		Map<String,Object> map = new HashMap<String,Object>();
//		map.put("assetsAgreementId", assetsAgreementId);
//		return dao.deletes(map);
//	}

	@Override
	public int getMaxWarnNum() {
		return dao.getMaxWarnNum();
	}	

}