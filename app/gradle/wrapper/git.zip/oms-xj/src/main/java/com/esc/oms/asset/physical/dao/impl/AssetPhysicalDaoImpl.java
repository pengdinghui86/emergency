package com.esc.oms.asset.physical.dao.impl;

import com.esc.oms.asset.physical.dao.IAssetPhysicalDao;
import com.esc.oms.util.CommonUtils;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
@Repository
public class AssetPhysicalDaoImpl extends BaseOptionDao implements IAssetPhysicalDao{
	
	private String relationTableName = "assets_material_backup";
	private String assets_material_category_attr_value="assets_material_category_attr_value";

	@Override
	public String getTableName() {
		return "assets_material_info";
	}

	@Override
	public boolean addRelation(Map info) {
		return	super.saveBySql(relationTableName, info);
	}

	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params), pageBean, null);
	}
	
	@Override
	public List<UTMap<String, Object>> getListMaps(Map param) {
		return this.getListBySql(getSearchSql(param));
	}
	
	@Override
	public UTMap<String, Object> getById(String id) {
		return super.getOneBySql(getSearchByIdSql(id));
	}
	
	@Override
	public boolean updateAssetCodeBySerialNum(UTMap<String, Object> map) {
		StringBuilder sql=new StringBuilder();
		sql.append("update assets_material_info ami SET ami.codeNum = '" + map.get("codeNum").toString() + "'");
		sql.append(" WHERE ami.serialNum = '" + map.get("serialNum").toString() + "'");
		return super.executeUpdate(sql.toString());
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT ami.id,ami.sn,ami.`name`,ami.`code`,ami.codeNum,ami.category,amc.`name` categoryName,amsc.`name` subCategoryName,so.`longName` resDepartId,");
		sql.append(" IF(ami.auxiliaryAsset='1',concat(concat('(主)','',ami.`name`), IF ( ami.serialNum IS NULL OR ami.serialNum = '', '', concat('/', ami.serialNum)))," );
		sql.append("concat( concat('(辅)', '', ami.`name`), IF ( ami.serialNum IS NULL OR ami.serialNum = '', '', concat('/', ami.serialNum)))) assetsNameCode," );
//		sql.append(" IF(ami.auxiliaryAsset='1',concat('(主)','',ami.`name`)," );
//		sql.append("concat('(辅)', '', ami.`name`)) assetsNameCode," );
		sql.append(" ami.status,ami.assetPrice,ami.registStatus, ami.serialNum,ami.userId,ami.brand,ami.model,ami.businessName," );
		sql.append(" ami.salvage,ami.useYears,ami.inboundDate,ami.confidentiality, ");
		sql.append(" ami.maintAssetStartDate,ami.maintAssetsEndDate,ami.remark,ami.systemClass,ami.subCategory,ami.assetsLevel ,");
		sql.append(" ami.assetStartDate,ami.assetEndDate,aai.supplierName assetSupplierName,ami.controllable,ami.otherMaint,");
		sql.append(" ami.auxiliaryAsset,ami.ownSystem,ami.producer,ami.integrity,ami.availability,ami.hasBackup,ami.totalAssets,ami.outdate, ");
		sql.append(" ami.assetsUse, ami.assetStatus, ami.assetsCosts, ami.preAssetsClass, ");
		sql.append(" ami.ip, ami.EquipmentUse, ami.isPositive, ami.assetAttributes, ami.systemName, ami.MaintenanceAmount,");
		sql.append(" ami.CabinetStartU, ami.CabinetEndU, ami.businessSystemLeader, ami.EquipmentLeader,ami.assetsType,");
		sql.append(" aai.agreementName buyContract,aai2.agreementName maintainContract,concat(su.`name`, '/', su.`code`) resUserName,");
		sql.append(" ap.`name` location,ami.resUserId resUser,ifnull(ami.isScrap,'0') isScrap,");
		sql.append(" so.`name` resDepartName,aai.agreementName buyContractName,");
		sql.append(" aai2.agreementName maintainContractName,(to_days(ami.maintAssetsEndDate)-to_days(now())) maintAssetsLeftNum,");
		sql.append( " aai2.supplierName maintSupplierName,(to_days(ami.assetEndDate)-to_days(now())) assetsLeftTime,");
		sql.append(" su2.name businessSystemLeaderName,su3.name  EquipmentLeaderName ");
		sql.append(" FROM assets_material_info ami ");
		sql.append(" LEFT JOIN assets_material_category amc ON amc.id = ami.category ");
		sql.append(" LEFT JOIN assets_material_category amsc ON amsc.id = ami.subCategory ");
		sql.append(" LEFT JOIN sys_user su ON su.id = ami.resUserId ");
		sql.append(" LEFT JOIN sys_user su2 on su2.id = ami.businessSystemLeader ");
		sql.append(" LEFT JOIN sys_user su3 on su3.id = ami.EquipmentLeader ");
		sql.append(" LEFT JOIN sys_org so ON so.id = ami.resDepartId ");
		sql.append(" LEFT JOIN assets_place ap ON ap.id = ami.location ");
		sql.append(" LEFT JOIN assets_agreement_info aai ON ami.buyContract = aai.id ");
		sql.append(" LEFT JOIN assets_agreement_info aai2 ON aai2.id = ami.maintainContract ");
		sql.append(" WHERE 1=1 ");
		sql.append(" AND (ami.deleteFlag != 1 OR ami.deleteFlag IS NULL) ");
//		sql.append(" AND ifnull(ami.isScrap,'0') <> '1'");
		if(params!=null && params.size()>0){
			String isExactQuery = (String) params.get("isExactQuery");
			if("1".equals(isExactQuery)){//精确查询，包括 名称，管理人 所属部门 ip
				if(params.get("name")!=null && CommonUtils.notNullStrOrEmpty(params.get("name").toString())){ //资产合同--资产视图
					sql.append(" AND ami.name ='"+params.get("name").toString().trim()+"'");
				}
				if(params.get("resUserId")!=null && CommonUtils.notNullStrOrEmpty(params.get("resUserId").toString())){
//				sql.append(" and (su.name like '%"+params.get("resUserId").toString().trim()+"%' or su.code like '%"+params.get("resUserId").toString().trim()+"%')");
					sql.append(" and CONCAT(su.name,'/',su.code) = '"+params.get("resUserId").toString().trim()+"' ");
				}
				if(params.get("resDepartLongName")!=null && CommonUtils.notNullStrOrEmpty(params.get("resDepartLongName").toString())){
					sql.append(" AND so.`longName` = '"+params.get("resDepartLongName").toString().trim()+"'");
				}
				if(params.get("ip")!=null && CommonUtils.notNullStrOrEmpty(params.get("ip").toString())){
					sql.append(" AND ami.`ip` = '"+params.get("ip").toString().trim()+"'");
				}

			}else{
				if(params.get("name")!=null && CommonUtils.notNullStrOrEmpty(params.get("name").toString())){ //资产合同--资产视图
					sql.append(" AND ami.name like '%"+params.get("name").toString().trim()+"%'");
				}
				if(params.get("resUserId")!=null && CommonUtils.notNullStrOrEmpty(params.get("resUserId").toString())){
//				sql.append(" and (su.name like '%"+params.get("resUserId").toString().trim()+"%' or su.code like '%"+params.get("resUserId").toString().trim()+"%')");
					sql.append(" and CONCAT(su.name,'/',su.code) like '%"+params.get("resUserId").toString().trim()+"%' ");
				}
				if(params.get("resDepartLongName")!=null && CommonUtils.notNullStrOrEmpty(params.get("resDepartLongName").toString())){
					sql.append(" AND so.`longName` like '%"+params.get("resDepartLongName").toString().trim()+"%'");
				}
				if(params.get("ip")!=null && CommonUtils.notNullStrOrEmpty(params.get("ip").toString())){
					sql.append(" AND ami.`ip` like '%"+params.get("ip").toString().trim()+"%'");
				}
			}
			if(params.get("category")!=null && CommonUtils.notNullStrOrEmpty(params.get("category").toString())){
				sql.append(" AND amc.id = '"+params.get("category").toString().trim()+"'");
			}
			if(params.get("subCategory")!=null && CommonUtils.notNullStrOrEmpty(params.get("subCategory").toString())){
				sql.append(" AND amsc.id = '"+params.get("subCategory").toString().trim()+"'");
			}
			if(params.get("agreementId")!=null && CommonUtils.notNullStrOrEmpty(params.get("agreementId").toString())){ //资产合同--资产视图
				sql.append(" AND (ami.buyContract = '"+params.get("agreementId").toString().trim()+"' "
						+ "or ami.maintainContract = '"+params.get("agreementId").toString().trim()+"')");
			}
			if(params.get("codeNum")!=null && CommonUtils.notNullStrOrEmpty(params.get("codeNum").toString())){
				sql.append(" AND (ami.codeNum like '%"+params.get("codeNum").toString().trim()+"%' OR ami.serialNum like '%"+params.get("codeNum").toString().trim()+"%')");
			}
			if(params.get("resDepartId")!=null && CommonUtils.notNullStrOrEmpty(params.get("resDepartId").toString())){
				sql.append(" AND ami.resDepartId = '"+params.get("resDepartId").toString().trim()+"'");
			}
			if(params.get("isScrap")!=null && CommonUtils.notNullStrOrEmpty(params.get("isScrap").toString())){
				sql.append(" AND ifnull(ami.isScrap,'0') = '"+params.get("isScrap").toString().trim()+"'");
			}else{
//				sql.append(" AND ifnull(ami.isScrap,'0') <> '1'");
			}
			if(params.get("ids")!=null && CommonUtils.notNullStrOrEmpty(params.get("ids").toString())){
				sql.append(" AND ami.id in ("+params.get("ids").toString().trim()+")");
			}
			if(params.get("userStatus")!=null && CommonUtils.notNullStrOrEmpty(params.get("userStatus").toString())){
				sql.append(" AND (ami.resUserId is NULL OR ami.resUserId = '') ");
			}
			if(params.get("auxiliaryAsset")!=null && CommonUtils.notNullStrOrEmpty(params.get("auxiliaryAsset").toString())){
				sql.append(" AND ami.auxiliaryAsset = "+params.get("auxiliaryAsset").toString().trim()+" and (ami.parentId IS NULL OR ami.parentId = '' ) ");
			}
			if(params.get("parentId")!=null && CommonUtils.notNullStrOrEmpty(params.get("parentId").toString())){
				sql.append(" AND ami.parentId = '"+params.get("parentId").toString().trim()+"'");
			}
			if(params.get("locationName")!=null && CommonUtils.notNullStrOrEmpty(params.get("locationName").toString())){
				sql.append(" AND ap.name like '%"+params.get("locationName").toString().trim()+"%'");
			}
			
			if(params.get("location")!=null && CommonUtils.notNullStrOrEmpty(params.get("location").toString())){
				sql.append(" AND ami.location like '%"+params.get("location").toString().trim()+"%'");
			}
			if(params.get("resUserName")!=null && CommonUtils.notNullStrOrEmpty(params.get("resUserName").toString())){
				sql.append(" AND su.name like '%"+params.get("resUserName").toString().trim()+"%'");
			}
			if(params.get("registStatus")!=null && CommonUtils.notNullStrOrEmpty(params.get("registStatus").toString())){
				sql.append(" AND ami.registStatus = '"+params.get("registStatus").toString().trim()+"'");
			}else{
				if(params.get("registAssets")!=null && CommonUtils.notNullStrOrEmpty(params.get("registAssets").toString())){}else{
					sql.append(" AND (ami.registStatus is NULL OR ami.registStatus = '2') ");
				}
			}
			if(CommonUtils.notNullStrOrEmpty((String) params.get("assetsLevel"))){
				sql.append(" AND ami.assetsLevel='"+params.get("assetsLevel")+"'");
			}
		}else{
			sql.append(" AND ifnull(ami.isScrap,'0') <> '1'");
		}
		if(params!=null && params.size()>0 && null != params.get("overviewWarn")){
			if("0".equals(String.valueOf(params.get("overviewWarn")))){
				sql.append(" order by assetsLeftTime asc");
			}else{
				sql.append(" order by maintAssetsLeftNum asc");
			}
		}else{
			sql.append(" order by ami.createTime desc,ami.sortCode ");
		}
		return  sql.toString();
	}
	
	
	private String getSparesByIdSql(String id){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT ambi.id,ambi.`code`,ambi.beyondRes,ambi.beyondResCount,ambi.beyondResState, " );
		sql.append(" ambi.endDate,ambi.localRes,ambi.localResCount,ambi.localResState,ambi.model,ambi.`name`,ambi.offTheShelf,");
		sql.append(" ambi.readyRequest,sbi.`name` supplier,ambi.type,ambi.useType ");
		sql.append(" FROM assets_material_backup_info ambi ");
		sql.append(" LEFT JOIN assets_material_backup amb ON amb.backupId = ambi.id ");
		sql.append(" LEFT JOIN assets_material_info ami ON ami.id = amb.assetsId ");
		sql.append(" LEFT JOIN supplier_base_info sbi ON sbi.id =  ambi.supplier ");
		sql.append(" WHERE amb.assetsId = '"+id+"'");
		return  sql.toString();
	}
	
	@Override
	public List<UTMap<String, Object>> getSparesById(String id) {
		return super.getListBySql(getSparesByIdSql(id));
	}

	@Override
	public boolean deleteSparesById(String id) {
		StringBuilder sql=new StringBuilder();
		sql.append(" DELETE  FROM "
				 + relationTableName
				 + " WHERE assetsId = '" +id+"'");
		return super.executeUpdate(sql.toString());
	}

	@Override
	public List<UTMap<String, Object>> getAssetsList(Map param) {
		return super.getListBySql(getSearchSql(param));
	}

	
	private String updateInfoByIdsSql(String location, String resUserId,
			String resDepartId, String ids){
		StringBuilder sql=new StringBuilder();
		sql.append(" UPDATE assets_material_info ami " );
		sql.append(" SET ami.id = ami.id ");
			if(null != location && StringUtils.isNotEmpty(location)){
				sql.append(" ,ami.location = '"+location+"'");
			}
			if(null != resUserId && StringUtils.isNotEmpty(resUserId)){
				sql.append(" ,ami.resUserId = '"+resUserId+"'");
			}
			if(null != resDepartId && StringUtils.isNotEmpty(resDepartId)){
				sql.append(" ,ami.resDepartId = '"+resDepartId+"'");
			}
			if(StringUtils.isEmpty(ids)){
				sql.append(" WHERE ami.id in ('')");
			}else{
				sql.append(" WHERE ami.id in ("+ids+")");
			}
		return  sql.toString();
	}
	
	@Override
	public boolean updateInfoByIds(String location, String resUserId,
			String resDepartId, String ids) {
		return super.executeUpdate(updateInfoByIdsSql(location,resUserId,resDepartId,ids));
	}

	@Override
	public List<UTMap<String, Object>> getAssetBycodeAndId(String codeNum,
			String id) {
		String sql = "SELECT * FROM  assets_material_info ami WHERE ami.codeNum = '"+codeNum+"' AND ami.id != '"+id+"'";
		return super.getListBySql(sql);
	}
	
	@Override
	public UTMap<String, Object> getAssetById(String id) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT ami.id,ami.`name`,ami.`code`,ami.codeNum,amc.`name` category,amsc.`name` subCategory,IF(ami.auxiliaryAsset='1',concat(concat('(主)','',ami.`name`), '/', ami.serialNum),concat(concat('(辅)','',ami.`name`), '/', ami.`codeNum`)) assetsId,ami.status " );
		sql.append(" FROM assets_material_info ami ");
		sql.append(" LEFT JOIN assets_material_category amc ON amc.id = ami.category ");
		sql.append(" LEFT JOIN assets_material_sub_category amsc ON amsc.id = ami.subCategory ");
		sql.append(" LEFT JOIN sys_user su ON su.id = ami.resUserId ");
		sql.append(" LEFT JOIN sys_org so ON so.id = ami.resDepartId ");
		sql.append(" LEFT JOIN assets_place ap ON ap.id = ami.location ");
		sql.append(" LEFT JOIN assets_agreement_info aai ON ami.buyContract = aai.id ");
		sql.append(" LEFT JOIN assets_agreement_info aai2 ON aai2.id = ami.maintainContract ");
		sql.append(" WHERE ami.id = '" + id + "'");
		sql.append(" AND (ami.deleteFlag != 1 OR ami.deleteFlag IS NULL) ");
		return super.getOneBySql(sql.toString());
	}
	
	@Override
	public UTMap<String, Object> getAssetBySerialNum(String serialNum) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT * " );
		sql.append(" FROM assets_material_info WHERE 1=1 AND (deleteFlag =0 or deleteFlag is null)  and  ");
		sql.append(" serialNum = '" + serialNum + "'");
		return super.getOneBySql(sql.toString());
	}
	
	private String getSearchByIdSql(String id){
		StringBuilder sql=new StringBuilder();
		sql.append("select ami.*,ami.assetPrice price FROM assets_material_info ami");
//		sql.append(" SELECT ami.id,ami.`code`,ami.amount,ami.availability,ami.brand,ami.buyContract,ami.parentId,ami.outdate,ami.maintAssetStartDate,ami.maintAssetsEndDate, " );
//		sql.append(" ami.category,ami.confidentiality,ami.controllable,ami.createTime,ami.createUserId,ami.desCode,ami.assetStartDate,ami.assetEndDate, ");
//		sql.append(" ami.hasBackup,ami.inboundDate,ami.integrity,ami.location,ami.maintainContract,ami.maintEndDate,ami.assetPrice,ami.assetPrice price,ami.totalAssets,ami.assetClass, ");
//		sql.append(" ami.maintStartDate,ami.model,ami.`name`,ami.producer,ami.purchaseDate,ami.remark,ami.resDepartId,ami.resUserId, ");
//		sql.append(" ami.salvage,ami.serialNum,ami.`status`,ami.subCategory,ami.supplierId,ami.userId,ami.useYears,ap.`name` locationName, ");
//		sql.append(" ami.assetStatus,");
//		sql.append(" concat(su.`name`,'/',su.`code`) resUserName,so.`name` resDepartName,aai.agreementName buyContractName, ");
//		sql.append(" aai2.agreementName maintainContractName,amc.`name` categoryName,amsc.`name` subCategoryName,su.name resUserName2,ami.otherMaint,ami.auxiliaryAsset,ami.ownSystem,ami.registStatus,ami.systemClass ");
//		sql.append(" FROM assets_material_info ami ");
//		sql.append(" LEFT JOIN assets_place ap ON ap.id = ami.location ");
//		sql.append(" LEFT JOIN sys_user su ON su.id = ami.resUserId ");
//		sql.append(" LEFT JOIN sys_org so ON so.id = ami.resDepartId  ");
//		sql.append(" LEFT JOIN assets_agreement_info aai ON ami.buyContract = aai.id ");
//		sql.append(" LEFT JOIN assets_agreement_info aai2 ON aai2.id = ami.maintainContract ");
//		sql.append(" LEFT JOIN assets_material_category amc ON amc.id = ami.category ");
//		sql.append(" LEFT JOIN assets_material_sub_category amsc ON amsc.id = ami.subCategory ");
		sql.append(" WHERE ami.id = '"+id+"'");
		return  sql.toString();
	}

	@Override
	public boolean updateOutdateById(String id) {
		StringBuilder sql=new StringBuilder();
		sql.append(" UPDATE assets_material_info ami SET ami.outdate = NOW(),ami.status=2 WHERE ami.id = '" +id+"' AND ami.outdate IS NULL ");
		return super.executeUpdate(sql.toString());
	}

	@Override
	public boolean updateAssetStatusById(String id, String status) {
		StringBuilder sql=new StringBuilder();
		sql.append(" UPDATE assets_material_info ami SET ami.assetStatus = '" + status + "' WHERE ami.id = '" +id+"'");
		return super.executeUpdate(sql.toString());
	}
	
	@Override
	public boolean updateTotalPriceById(String id, String beforePrice,
			String nowPrice) {
		StringBuilder sql=new StringBuilder();
		sql.append("UPDATE assets_material_info ami SET ami.totalAssets = (ami.totalAssets-"+beforePrice+"+"+nowPrice+") where ami.id ='"+id+"'");
		return super.executeUpdate(sql.toString());
	}

	@Override
	public boolean updateAuxiliaryById(String id) {
		StringBuilder sql=new StringBuilder();
		sql.append("UPDATE assets_material_info ami SET ami.parentId ='' where ami.parentId ='"+id+"'");
		return super.executeUpdate(sql.toString());
	}
	
	@Override
	public UTMap<String, Object> getAssetInfoByCode(String codeNum){
		StringBuilder sql = new StringBuilder();
		sql.append(" select id, code,codeNum, name, category, subCategory, buyContract, maintainContract, supplierId, status, location, ");
		sql.append(" producer, salvage, useYears, purchaseDate, inboundDate, amount, brand, model, confidentiality, integrity, ");
		sql.append(" availability, maintStartDate, maintEndDate,userId, resUserId, resDepartId, controllable,hasBackup, createUserId, ");
		sql.append(" deleteFlag, isScrap, outdate, maintAssetStartDate, maintAssetsEndDate, assetStartDate, assetEndDate, otherMaint, ");
		sql.append(" auxiliaryAsset, assetPrice, totalAssets, assetClass, ownSystem, inventory_status, registStatus ");
		sql.append(" from " + this.getTableName());
		sql.append(" where codeNum='" + codeNum + "'");
		return super.getOneBySql(sql.toString(), null);
	}
	
	@Override
	public UTMap<String, Object> getAssetInfoByAssetCode(String code){
		StringBuilder sql = new StringBuilder();
		sql.append(" select id, code,codeNum, name, category, subCategory, buyContract, maintainContract, supplierId, status, location, ");
		sql.append(" producer, salvage, useYears, purchaseDate, inboundDate, amount, brand, model, confidentiality, integrity, ");
		sql.append(" availability, maintStartDate, maintEndDate,userId, resUserId, resDepartId, controllable,hasBackup, createUserId, ");
		sql.append(" deleteFlag, isScrap, outdate, maintAssetStartDate, maintAssetsEndDate, assetStartDate, assetEndDate, otherMaint, ");
		sql.append(" auxiliaryAsset, assetPrice, totalAssets, assetClass, ownSystem, inventory_status, registStatus ");
		sql.append(" from " + this.getTableName());
		sql.append(" where code='" + code + "'");
		return super.getOneBySql(sql.toString(), null);
	}

	@Override
	public boolean deleteAttrValueByInfoId(String infoId) {
		String sql = " delete from "+assets_material_category_attr_value+" where assetsInfoId='"+infoId+"'";
		return this.executeUpdate(sql, null);
	}

	@Override
	public boolean isExitSerialNum(String serialNum, String id) {
		String sql = "select * from "+this.getTableName()+" where serialNum = '"+serialNum+"' and id <>'"+id+"' and (deleteFlag is null or deleteFlag = 0)";
		List<UTMap<String, Object>> list = this.getListBySql(sql);
		return list!= null ? list.size() > 0 : false;
	}

	@Override
	public boolean isExistParam(Map<String, Object> params) {
		String id = (String) params.get("id");
		String serialNum = (String) params.get("serialNum");
		String codeNum = (String) params.get("codeNum");
		StringBuilder sql = new StringBuilder(" select * from "+this.getTableName()+" where 1=1 and (deleteFlag is null or deleteFlag = 0) ");
		if(CommonUtils.notNullStrOrEmpty(id)){
			sql.append("  and id <>'"+id+"'");
		}
		if(CommonUtils.notNullStrOrEmpty(serialNum)){
			sql.append(" and  serialNum = '"+serialNum+"' ");
			List<UTMap<String, Object>> list = this.getListBySql(sql.toString());
			return list!= null ? list.size() > 0 : false;
		}
		if(CommonUtils.notNullStrOrEmpty(codeNum)){
			sql.append(" and  codeNum = '"+codeNum+"'  ");
			List<UTMap<String, Object>> list = this.getListBySql(sql.toString());
			return list!= null ? list.size() > 0 : false;
		}
		return false;
	}


}
