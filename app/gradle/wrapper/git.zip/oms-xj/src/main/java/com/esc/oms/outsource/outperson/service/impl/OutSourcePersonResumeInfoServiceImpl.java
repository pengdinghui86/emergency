package com.esc.oms.outsource.outperson.service.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.poi.tempfrom.tempoption.IFormModelData;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.upload.annotation.UploadQueryMarks;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.excel.UTExcelValidate;
import org.esc.framework.utils.page.UTPageBean;
import org.hibernate.exception.DataException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.outperson.dao.IOutSourcePersonResumeEducationDao;
import com.esc.oms.outsource.outperson.dao.IOutSourcePersonResumeInfoDao;
import com.esc.oms.outsource.outperson.service.IOutSourcePersonBlacklistService;
import com.esc.oms.outsource.outperson.service.IOutSourcePersonResumeEducationService;
import com.esc.oms.outsource.outperson.service.IOutSourcePersonResumeInfoService;
import com.esc.oms.outsource.outperson.service.IOutSourcePersonResumeLanguageService;
import com.esc.oms.outsource.outperson.service.IOutSourcePersonResumeProjectService;
import com.esc.oms.outsource.outperson.service.IOutSourcePersonResumeTrainService;
import com.esc.oms.outsource.outperson.service.IOutSourcePersonResumeWorkService;
import com.esc.oms.supplier.info.service.ISupplierBaseInfoService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;
/**
 * 简历-基本信息
 * @author djj
 * @date   2016-07-18
 */
@Service
@Transactional 
public class OutSourcePersonResumeInfoServiceImpl extends BaseOptionService implements IOutSourcePersonResumeInfoService,IFormModelData {
	
	@Resource
	private IOutSourcePersonResumeInfoDao resumeInfoDao;
	@Resource
	private IOutSourcePersonResumeEducationService eduService;
	@Resource
	private IOutSourcePersonResumeWorkService workService;
	@Resource
	private IOutSourcePersonResumeProjectService projectService;
	@Resource
	private IOutSourcePersonResumeTrainService trainService;
	@Resource
	private IOutSourcePersonResumeLanguageService languageService;
	@Resource
	private IOutSourcePersonBlacklistService blackService;
	@Resource
	private ISysParamService sysParamService;
	@Resource
	private ISupplierBaseInfoService supplierBaseInfoService;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return resumeInfoDao;
	}
	public String tempCode() {
		return "formTemp.resumeTemp";
	}
	@Override
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	@EscOptionLog(module=SystemModule.outsourcePersonResumeInfo, opType=ESCLogOpType.INSERT, table="resume_info", primaryKey="id={1.id}",option="新增姓名为{1.name}，身份证号为{1.idCode}的简历信息。")	
	public boolean add(Map info){
		boolean isUnique = isUnique(info);
		if(isUnique){
			return super.add(info);
		}else{
			throw new EscServiceException((String) info.get("msg"));			
		}
	}
	
	private boolean isUnique(Map info){	
		String idCode = (String) info.get("idCode");
//		String supplierId = (String) info.get("supplierId");
		
		String id = (String) info.get("id");
		//判断身份证号与供应商的唯一性
		Map<String,Object> nameMap = new HashMap<String,Object>();	
		if(info.get("idCode")!=null){
			nameMap.put("idCode", info.get("idCode"));
			nameMap.put("supplierId", info.get("supplierId"));
//			nameMap.put("deleteFlag", "0");
			if(resumeInfoDao.isExist(id,nameMap)){
				String msg = "该供应商中存在多个身份证号为【" + idCode + "】的简历";
//				info.put("msg",msg);
				throw new EscServiceException(msg);
			}
		}	
		
		//判断身份证号是否在黑名单中
		Map param = new HashMap<String,Object>();
		param.put("idCode", idCode);
		param.put("isClear", "0");
		List list = blackService.getListMaps(param);
		if(list!=null&&list.size()>0){
			String msg = "身份证号为【" + idCode + "】的人员已被加入黑名单，需解除黑名单后才能添加！";
//			info.put("msg",msg);
			throw new EscServiceException(msg);
		}
		return true;
	} 
	
	@Override
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		UTMap<String, Object> result = super.getById(id);
		return result;
	}
	
	@Override
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public void getPageInfo(UTPageBean pageBean,Map param){
		super.getPageInfo(pageBean, param);
	}
		
	/**
	 * 根据条件查询
	 * @param params
	 */
	@Override
	@UploadQueryMarks
	public List<UTMap<String, Object>> getPageList(UTPageBean pageBean,Map params){
		return resumeInfoDao.getPageList(pageBean, params);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	@Override
	@UploadQueryMarks
	public List<UTMap<String, Object>> getListMaps(Map params){
		return super.getListMaps(params);
	}
	
		
	@Override
	@EscOptionLog(module=SystemModule.outsourcePersonResumeInfo, opType=ESCLogOpType.UPDATE, table="resume_info", primaryKey="id={1.id}",option="修改外包人员姓名为{1.name}，身份证号为{1.idCode}的简历信息")
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean updateById(Map info){
		boolean isUnique = isUnique(info);
		if(isUnique){
			return super.updateById(info);
		}else{
			throw new EscServiceException((String) info.get("msg"));
		}		
	}
	
	/**
	 * 根据id 删除
	 * @param ids
	 * @return
	 */
	public boolean deleteById(String id){
		//删除教育经历
		eduService.deleteByResumeId(id);
		//删除工作经历
		workService.deleteByResumeId(id);
		//删除项目经历
		projectService.deleteByResumeId(id);
		//删除培训经历
		trainService.deleteByResumeId(id);
		//删除语言
		languageService.deleteByResumeId(id);
		return	resumeInfoDao.deleteByIds(id);
	}
	
	public boolean deleteByIds(String ids){
		//删除教育经历
		eduService.deleteByResumeIds(ids);
		//删除工作经历
		workService.deleteByResumeIds(ids);
		//删除项目经历
		projectService.deleteByResumeIds(ids);
		//删除培训经历
		trainService.deleteByResumeIds(ids);
		//删除语言
		languageService.deleteByResumeIds(ids);
		
		return resumeInfoDao.deleteByIds(ids);
	}
	
	@Override
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getExportDataById(String id){
		UTMap<String, Object> result = super.getById(id);
		
		//替换下拉的值
//		Map<String, String> fieldAndParamType = new HashMap<String, String>();
//		fieldAndParamType.put(IOutSourcePersonResumeInfoDao.FIELD_EDUCATIONALBACKGROUND, "educationalType");
		String educationalBackground = sysParamService.getParamNameByValue("educationalType", result.get("educationalBackground").toString());
		result.put("educationalBackground", educationalBackground);
		String ismarriage = result.get("ismarriage")==null?"":result.get("ismarriage").toString();
		result.put("ismarriage", null == ismarriage ? "" : "1".equals(ismarriage)?"已婚":"未婚");
		
		Map<String,Object> param = new HashMap<String,Object>();
		param.put("infoId", id);
		//教育经历
		List<UTMap<String,Object>> eduList = eduService.getListMaps(param);
		//替换下拉的值
		Map<String, String> fieldAndParamType = new HashMap<String, String>();
		fieldAndParamType.put(IOutSourcePersonResumeEducationDao.FIELD_EDUCATION, "educationalType");
		sysParamService.changeParamData(eduList, fieldAndParamType);
		result.put("eduList", eduList);
		//工作经历
		List<UTMap<String,Object>> workList = workService.getListMaps(param);
		result.put("workList", workList);
		//项目经历
		List<UTMap<String,Object>> projectList = projectService.getListMaps(param);
		result.put("projectList", projectList);
		//培训经历
		List<UTMap<String,Object>> trainList = trainService.getListMaps(param);
		result.put("trainList", trainList);
		//语言
		List<UTMap<String,Object>> languageList = languageService.getListMaps(param);
		result.put("languageList", languageList);
		
		return result;
	}
	
	
	private Map<String,Object> getSupplierIdCodeMap(){
		Map<String,Object> 	map = new HashMap<String,Object>();
		List<UTMap<String,Object>> list = resumeInfoDao.getListMaps(null);
		if(list!=null&&list.size()>0){
			for(UTMap<String,Object> utmap:list){
				String supplierName = utmap.get("supplierName")==null?"":utmap.get("supplierName").toString();
				String idCode = utmap.get("idCode")==null?"":utmap.get("idCode").toString();
				map.put(supplierName+"_"+idCode, supplierName+"_"+idCode);
			}
		}
		return map;
	}	
	
	@Override
	public boolean leadingin(String filePath, Map<String, Object> param)
			throws Exception {
		List<UTMap<String, Object>> leadinginList = new ArrayList<UTMap<String,Object>>();
		boolean flag = true;		
		// 根据路径 获取工作薄
		Sheet sheet = UTExcel.getSheets(filePath)[0];
		// 导入顺序
		String[] cellArray = null;
		String[] fileds = null;
		cellArray = new String[] { 
				"姓名*（长度：0-20）", 
				"所属供应商*", 
				"身份证号码*", 
				"性别*", 
				"年龄*（最小值1，最大值100）", 
				"出生日期*（格式：yyyy/MM/dd）",
				"民族*（长度：0-10）",
				"籍贯*（长度：0-20）",
				"婚姻状况*",
				"学历*", 
				"毕业时间*（格式：yyyy/MM/dd）", 
				"工作年限*（最小值1，最大值100）", 
				"手机*", 
				"座机", 
				"email*", 
				"QQ", 
				"技术领域（长度：0-800）", 
				"专长（长度：0-800）" 
		};
		int[] lengthArr = {20, 0, 0, 0, 0, 0, 10, 20, 0, 0, 0, 0, 0, 0, 0, 0, 800, 800};
		fileds = new String[] {
				IOutSourcePersonResumeInfoDao.FIELD_NAME,											
				IOutSourcePersonResumeInfoDao.FIELD_SUPPLIER_ID,
				IOutSourcePersonResumeInfoDao.FIELD_ID_CODE,
				IOutSourcePersonResumeInfoDao.FIELD_SEX,
				IOutSourcePersonResumeInfoDao.FIELD_AGE,
				IOutSourcePersonResumeInfoDao.FIELD_BIRTHDAY,
				IOutSourcePersonResumeInfoDao.FIELD_NATION,
				IOutSourcePersonResumeInfoDao.FIELD_NATIVE_PLACE,
				IOutSourcePersonResumeInfoDao.FIELD_ISMARRIAGE,
				IOutSourcePersonResumeInfoDao.FIELD_EDUCATIONAL_BACKGROUND,
				IOutSourcePersonResumeInfoDao.FIELD_FINISH_SCHOOL_DATE,
				IOutSourcePersonResumeInfoDao.FIELD_SENIORITY,
				IOutSourcePersonResumeInfoDao.FIELD_PHONE,
				IOutSourcePersonResumeInfoDao.FIELD_FIXED_PHONE,
				IOutSourcePersonResumeInfoDao.FIELD_EMAIL,
				IOutSourcePersonResumeInfoDao.FIELD_QQ,
				IOutSourcePersonResumeInfoDao.FIELD_TECHNICAL_FIELD,
				IOutSourcePersonResumeInfoDao.FIELD_SPECIALITY	
			};	
		int rowNum = sheet.getLastRowNum();
		int cellNum = fileds.length;
		//检查导入的字段标题
		try {
			List<String> realityCellllist=new ArrayList<String>();
			//标题在第一行
			Row rowtitle=sheet.getRow(0);
			for (int j = 0; j < cellNum;j++) {
				realityCellllist.add(rowtitle.getCell(j).getStringCellValue());
			}
			String[] array =new String[realityCellllist.size()];
			if(!UTExcel.excelValidateByCell(cellArray, realityCellllist.toArray(array))){
				flag = false;
			} else {
				flag = true;
			}
		} catch (Exception e) {
			flag = false;
		}
		
		if(!flag) {
			throw new EscServiceException("导入失败，请选择正确的模板！");
		}
		StringBuilder error = new StringBuilder();
		Map<String,Object> supplierIdCodeMap = getSupplierIdCodeMap();
		// 从excel第1行开始添加 数据，全部保存
		for (int i = 1; i <= rowNum; i++) {
			// 遍历excel
			Row row = sheet.getRow(i);
			UTMap<String, Object> map = new UTMap<String, Object>();
			for (int j = 0; j < cellNum; j++) {
				String cellValue = null;
				Cell cell = row.getCell(j);
				if (cell != null) {
					cell.setCellType(Cell.CELL_TYPE_STRING);
					cellValue = cell.getStringCellValue().trim();
					cellValue = StringUtils.isEmpty(cellValue) ? null : cellValue;
				}
				//检查为空的字段
				if(j!=13&&j!=15&&j!=16&&j!=17) { //可以为空，其他不允许为空
					flag = StringUtils.isEmpty(cellValue) ? false : true;
					if (!flag) {
						error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "内容为空，请检查！" + "<br>");
					}else{						
						//婚姻状况数据转换
						if( j == 8){
							if("已婚".equals(cellValue)||"未婚".equals(cellValue)){
								if("已婚".equals(cellValue)){
									cellValue = "1";
								}else{
									cellValue = "0";
								}						
							}else{
								error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "列，不存在该婚姻状况【"+cellValue+"】，请检查！" + "<br>");
							}
						}							
					}
				}else{  //可以为空
					cellValue = StringUtils.isEmpty(cellValue) ? null : cellValue;
				}
				
				//检查时间格式
				if(IOutSourcePersonResumeInfoDao.FIELD_BIRTHDAY.equals(fileds[j]) || IOutSourcePersonResumeInfoDao.FIELD_FINISH_SCHOOL_DATE.equals(fileds[j])) {
					if(cellValue != null)
					{
						if (!CommonUtils.validateDate(cellValue)) {
							error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "格式不正确，请检查！" + "<br>");
						}
					}
				}		
				if (cellValue != null) {
					//长度校验
					if (lengthArr[j] != 0 && cellValue.length() > lengthArr[j]){
						error.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "内容长度超出限制，请检查！" + "<br>");
					}
					if ((j == 4 || j == 11) && cellValue != null) {
						try {
							int value = Integer.parseInt(cellValue);
							if (value < 1 || value > 100) {
								error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "内容不正确，请检查！" + "<br>");
							}
						}catch(NumberFormatException e) {
							error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "格式不正确，请检查！" + "<br>");
						}
						
					}
				}
				map.put(fileds[j], cellValue);
			}			
			leadinginList.add(map);
		}
		
		//对每一个进行检查重复		
		for (int i = 0; i < leadinginList.size(); i ++) {
			UTMap origMap = leadinginList.get(i);
			String supplierName = (String) origMap.get(IOutSourcePersonResumeInfoDao.FIELD_SUPPLIER_ID);
			String idCode = (String) origMap.get(IOutSourcePersonResumeInfoDao.FIELD_ID_CODE);
			
			if(supplierIdCodeMap.containsKey(supplierName+"_"+idCode)){
				error.append("存在多个身份证号为【" + idCode + "】，且供应商为【"+supplierName+"】的简历！" + "<br>");
			}else{			
				//先检查当前excel
				for (int j = i + 1; j < leadinginList.size(); j ++) {
					UTMap<String, Object> checkMap = leadinginList.get(j);
					String name = (String) checkMap.get(IOutSourcePersonResumeInfoDao.FIELD_SUPPLIER_ID);
					String code = (String) checkMap.get(IOutSourcePersonResumeInfoDao.FIELD_ID_CODE);
					if(StringUtils.equals(supplierName, name)&&StringUtils.equals(idCode, code)) {
						error.append("存在多个身份证号为【" + idCode + "】，且供应商为【"+supplierName+"】的简历！" + "<br>");
					}
				}	
			}	
		}
		
		//替换下拉的值
		Map<String, String> fieldAndParamType = new HashMap<String, String>();
		fieldAndParamType.put(IOutSourcePersonResumeInfoDao.FIELD_EDUCATIONAL_BACKGROUND, "educationalType");
		fieldAndParamType.put(IOutSourcePersonResumeInfoDao.FIELD_SUPPLIER_ID,"suppliers");		
		List<UTMap<String,Object>> listMaps = supplierBaseInfoService.getListMaps(null);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("suppliers", listMaps);	
		sysParamService.changeDataToParam(leadinginList, fieldAndParamType, ",", map);
		
		for (int i = 0; i<leadinginList.size(); i++) {
			UTMap<String, Object> leadingOne = leadinginList.get(i);
			//判断参数是否存在			
			if(StringUtils.isEmpty((String) leadingOne.get(IOutSourcePersonResumeInfoDao.FIELD_EDUCATIONAL_BACKGROUND))) {
				error.append("Excel内容错误，行号为" + (i + 2) + "中的学历系统中不存在，请检查，若需配置请联系管理员！" + "<br>");
			}
			//判断参数是否存在			
			if(StringUtils.isEmpty((String) leadingOne.get(IOutSourcePersonResumeInfoDao.FIELD_SUPPLIER_ID))) {
				error.append("Excel内容错误，行号为" + (i + 2) + "中的供应商系统中不存在，请检查，若需配置请联系管理员！" + "<br>");
			}
		}
		if (StringUtils.isNotEmpty(error.toString())) {
			throw new EscServiceException(error.toString());
		}
		
		//保存到数据库
		for (int i = 0; i<leadinginList.size(); i++) {
			UTMap<String, Object> leadingOne = leadinginList.get(i);
			
			leadingOne.put("sortCode", System.currentTimeMillis()); // 导入排序
			//往数据库插入一条数据
			try {
				flag = add(leadingOne);
			} catch (DataException e) {
				try {
		    		SQLException sqlException = e.getSQLException();
		    		if(sqlException != null) {
		    			String message = sqlException.getMessage();
		    			//如果提示是：Data too long for column 'name'，那么可以提示长度
		    			//如果是其他类型的sql错误，不进行处理
		    			if(message != null && message.contains("Data too long for column '")) {
		    				String filed = message.substring(message.indexOf("Data too long for column '") + 26, message.indexOf("' at r"));
		    				String filedName = "";
							//找到字段名称
		    				for (int j = 0; j < fileds.length; j++) {
								if(StringUtils.equals(filed, fileds[j])) {
									filedName = cellArray[j];
									break;
								}
							}
		    				//抛出提示
		    				throw new EscServiceException("Excel内容错误，行号为" + (i + 2) + "的" + filedName + "长度太长，请检查！");
		    			} else {
		    				throw e;
		    			}
		    		}
				} catch (EscServiceException e2) {
    				throw e2;
				} catch (Exception e2) {
					//继续抛出
    				throw e;
				}
			} catch (Exception e) {
				//其他异常
				throw e;
			}
			if (!flag) {
				throw new EscServiceException("保存数据失败！");
			}
		}
		return flag;
	}

	@Override
	public boolean leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String tamlate="excelOutTamplate.resumeInfoLeadOut";
		String[] fileds = new String[] {
				IOutSourcePersonResumeInfoDao.FIELD_NAME,											
				IOutSourcePersonResumeInfoDao.FIELD_SUPPLIER_NAME,
				IOutSourcePersonResumeInfoDao.FIELD_ID_CODE,
				IOutSourcePersonResumeInfoDao.FIELD_SEX,
				IOutSourcePersonResumeInfoDao.FIELD_AGE,
				IOutSourcePersonResumeInfoDao.FIELD_BIRTHDAY,
				IOutSourcePersonResumeInfoDao.FIELD_NATION,
				IOutSourcePersonResumeInfoDao.FIELD_NATIVE_PLACE,
				IOutSourcePersonResumeInfoDao.FIELD_ISMARRIAGE,
				IOutSourcePersonResumeInfoDao.FIELD_EDUCATIONAL_BACKGROUND,
				IOutSourcePersonResumeInfoDao.FIELD_FINISH_SCHOOL_DATE,
				IOutSourcePersonResumeInfoDao.FIELD_SENIORITY,
				IOutSourcePersonResumeInfoDao.FIELD_PHONE,
				IOutSourcePersonResumeInfoDao.FIELD_FIXED_PHONE,
				IOutSourcePersonResumeInfoDao.FIELD_EMAIL,
				IOutSourcePersonResumeInfoDao.FIELD_QQ,
				IOutSourcePersonResumeInfoDao.FIELD_TECHNICAL_FIELD,
				IOutSourcePersonResumeInfoDao.FIELD_SPECIALITY		
			 };
		
		//替换下拉的值
		Map<String, String> fieldAndParamType = new HashMap<String, String>();
		fieldAndParamType.put(IOutSourcePersonResumeInfoDao.FIELD_EDUCATIONAL_BACKGROUND, "educationalType");
		sysParamService.changeParamData(data, fieldAndParamType);
		
		//转换婚姻状况		
		for(int i=0;i<data.size();i++){
			Map<String,Object> item = (Map<String, Object>) data.get(i);
			//转换完成率
			Object obj = item.get(IOutSourcePersonResumeInfoDao.FIELD_ISMARRIAGE);
			if (null == obj) {
				item.put(IOutSourcePersonResumeInfoDao.FIELD_ISMARRIAGE,"");
			}
			else if(obj!=null&&"1".equals(obj.toString())){				
				item.put(IOutSourcePersonResumeInfoDao.FIELD_ISMARRIAGE,"已婚");
			}else{
				item.put(IOutSourcePersonResumeInfoDao.FIELD_ISMARRIAGE,"未婚");
			}
		}		
		return	UTExcel.leadingout( fileds, data, tamlate, request,response);
	}

	@Override
	public List<UTMap<String, Object>> getRecommendResumeList(Map<String, Object> param) {		
		return resumeInfoDao.getRecommendResumeList(param);
	}
	@Override
	public Map<String, Object> setModelData(String recordId) {
		Map<String, String> info=  UTMap.mapObjToString(resumeInfoDao.getById(recordId));
		Map<String, Object> model= new HashMap<String, Object>();
		
		model.put("name", info.get("name"));
		model.put("sex", info.get("sex"));
		model.put("birthday", info.get("birthday"));
		model.put("age", info.get("age"));
		model.put("nation",info.get("nation"));
		model.put("nativePlace", info.get("nativePlace"));
		model.put("educationalBackground", info.get("educationalBackground"));
		model.put("finishSchoolDate", info.get("finishSchoolDate"));
		model.put("seniority", info.get("seniority"));
		model.put("ismarriage", info.get("ismarriage"));
		model.put("idCode", info.get("idCode"));
		model.put("phone", info.get("phone"));
		model.put("fixedPhone", info.get("fixedPhone"));
		model.put("email", info.get("email"));
		model.put("qq", info.get("qq"));
		model.put("technicaField", info.get("technicalField"));
		model.put("speciality", info.get("speciality"));
		
		Map<String,Object> param = new HashMap<String,Object>();
		param.put("infoId", recordId);
		//教育经历
		List<UTMap<String,Object>> eduList = eduService.getListMaps(param);
		//替换下拉的值
		Map<String, String> fieldAndParamType = new HashMap<String, String>();
		fieldAndParamType.put(IOutSourcePersonResumeEducationDao.FIELD_EDUCATION, "educationalType");
		sysParamService.changeParamData(eduList, fieldAndParamType);
		model.put("edu", eduList);
		//工作经历
		List<UTMap<String,Object>> workList = workService.getListMaps(param);
		model.put("work", workList);
		//项目经历
		List<UTMap<String,Object>> projectList = projectService.getListMaps(param);
		model.put("project", projectList);
		//培训经历
		List<UTMap<String,Object>> trainList = trainService.getListMaps(param);
		model.put("train", trainList);
		//语言
		List<UTMap<String,Object>> languageList = languageService.getListMaps(param);
		model.put("language", languageList);
//		
//		List<Map<String, String>> edus=new ArrayList<Map<String,String>>();
//		Map<String, String> edu1=new HashMap<String, String>();
//		edu1.put("beginDate", "2016-03-04");
//		edu1.put("endDate", "2016-03-04");
//		edu1.put("education", "你猜你猜");
//		edu1.put("school", "猜猜猜猜猜猜猜猜猜猜猜猜");
//		edu1.put("vocation", "不猜不猜不猜不猜不猜不猜不猜不猜");
//		edus.add(edu1);
//		Map<String, String> edu2=new HashMap<String, String>();
//		edu2.put("beginDate", "2016-03-07");
//		edu2.put("endDate", "2016-03-07");
//		edu2.put("education", "你好你好");
//		edu2.put("school", "好好好好好好");
//		edu2.put("vocation", "不好不好不好不好不好不好");
//		edus.add(edu2);
//		model.put("edu", edus);
		
		return model;
	}

	
}
