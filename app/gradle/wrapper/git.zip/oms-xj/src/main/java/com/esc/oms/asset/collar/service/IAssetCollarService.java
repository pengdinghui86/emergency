package com.esc.oms.asset.collar.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;


public interface IAssetCollarService extends IBaseOptionService{
	
	public UTMap<String, Object> getAssetByAssetId(String assetId);
	
	public UTMap<String, Object> getCollarById(String id);
	
	public boolean leadingout(List data, HttpServletRequest request,HttpServletResponse response) throws Exception;
	
	public List<UTMap<String, Object>> getCollarList(Map param);
	
	public UTMap<String, Object> getCollarByStatusList(String assetId);

	public List<UTMap<String, Object>> getAssetsList(Map<String, Object> param);

	public void getAssetCollarPage(Map<String, Object> param, UTPageBean pageBean);

	public List<UTMap<String, Object>> getAssetCollarByApplyId(Map<String, Object> param);

	public boolean addAssetCollar(Map<String, Object> newInfo);

	public boolean deleteAssetCollarByApplyId(String applyId);
	
}
