package com.esc.oms.asset.software.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.asset.software.dao.ISoftCategoryDao;
import com.esc.oms.asset.software.service.ISoftCategoryService;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;

@Service
@Transactional
public class SoftCategoryServiceImpl extends BaseOptionService implements ISoftCategoryService{

	@Resource
	private ISoftCategoryDao softCategoryDao;

	@Override
	public IBaseOptionDao getOptionDao() {
		return softCategoryDao;
	}

	public List<UTMap<String, Object>> getListCategory(Map params) {
		return softCategoryDao.getListCategory(params);
	}
	
	@Override
	public boolean add(Map info){
		Map param = new HashMap();
		param.put("name", info.get("name"));
		if(softCategoryDao.isExist(param)){
			throw new EscServiceException("软件类别"+info.get("name")+"已经存在！");
		}
		return	getOptionDao().add(info);
	}
	
	@Override
	public boolean updateById(Map info){
		if(!info.containsKey("id")){
			throw new EscServiceException("根据id 修改map中不存在key=id");
		}
		return getOptionDao().updateById(info);
	}
	
/*	@Override
	public boolean addProperty(Map info) {
		return softCategoryDao.addProperty(info);
	}

	@Override
	public boolean addPropertyOption(Map info) {
		return softCategoryDao.addPropertyOption(info);
	}

	@Override
	public List<UTMap<String, Object>> getPropertyByCategoryId(String categoryId) {
		return softCategoryDao.getPropertyByCategoryId(categoryId);
	}

	@Override
	public List<UTMap<String, Object>> getOptionByPropertyId(String propertyId) {
		return softCategoryDao.getOptionByPropertyId(propertyId);
	}

	@Override
	public boolean updatePropertyByCategoryId(Map info) {
		return softCategoryDao.updatePropertyByCategoryId(info);
	}

	@Override
	public boolean updateOptionByPropertyId(Map info) {
		return softCategoryDao.updateOptionByPropertyId(info);
	}*/

	@Override
//	@EscOptionLog(module=SystemModule.ASSET, opType=ESCLogOpType.INSERT, table="assets_material_sub_category", primaryKey="id={1.id}",option="新增id为{1.id}的资产小类信息。")
	public boolean addSubCategory(Map info) {
//		Map param = new HashMap();
////		param.put("name", info.get("name"));
		if(softCategoryDao.checkSubCategory(info)){
			throw new EscServiceException("此软件类别的子类别中已经存在"+info.get("name"));
		}
		return softCategoryDao.addSubCategory(info);
	}

	/*@Override
	public boolean addSubPropertyOption(Map info) {
		return softCategoryDao.addSubPropertyOption(info);
	}*/

	@Override
//	@EscOptionLog(module=SystemModule.ASSET, opType=ESCLogOpType.UPDATE, table="assets_material_sub_category", primaryKey="id={1.id}",option="更新id为{1.id}的资产小类信息。")
	public boolean updateSubCategoryById(Map info) {
		return softCategoryDao.updateSubCategoryById(info);
	}

	/*@Override
	public boolean updateSubPropertyById(Map info) {
		return softCategoryDao.updateSubPropertyById(info);
	}*/

	/*public List<UTMap<String, Object>> getSubOptionById(String id) {
		return softCategoryDao.getSubOptionById(id);
	}
*/
	@Override
	public UTMap<String, Object> getSubCategoryById(String id) {
		return softCategoryDao.getSubCategoryById(id);
	}

	/*@Override
	public List<UTMap<String, Object>> getSubPropertyById(String id) {
		return softCategoryDao.getSubPropertyById(id);
	}*/
	
	@Override
//	@EscOptionLog(module=SystemModule.ASSET, opType=ESCLogOpType.DELETE, table="assets_material_sub_category", primaryKey="id={1}",option="删除id为{1.id}的资产大类信息。")
	public boolean delete(Map info) {
		boolean flag = false;
		String parentId = (String) info.get("parentId");
		UTMap<String, Object> map = null;
		if(StringUtils.isNotEmpty(parentId)){
			flag = softCategoryDao.deleteSubCategoryByParentId(parentId);//删除资产小类
			flag = softCategoryDao.deleteByIds(parentId);
			/*map = softCategoryDao.getById(parentId);
			flag = softCategoryDao.deleteByIds(parentId);
			if(null != map){
				List<UTMap<String, Object>> subCategory = softCategoryDao.getSubCategoryByParentId(parentId);//资产小类
				if(null != subCategory && subCategory.size() > 0){
					if(flag){
						flag = softCategoryDao.deleteSubCategoryByParentId(parentId);//删除资产小类
					}
					if(null != subCategory && subCategory.size() > 0){
						for (UTMap<String, Object> subCate : subCategory) {
							List<UTMap<String, Object>> subPropertyList = softCategoryDao.getSubPropertyById(subCate.get("id").toString());
									if(null != subPropertyList && subPropertyList.size() > 0){
										flag = softCategoryDao.deleteProperty(subCate.get("id").toString());//删除资产小类下的扩展属性
										for (Map<String, Object> utMap : subPropertyList) {
											List<UTMap<String, Object>> options = softCategoryDao.getOptionByPropertyId(utMap.get("id").toString());
											if(null != options && options.size() > 0){
												flag = softCategoryDao.deleteOption(utMap.get("id").toString());//删除资产小类下的扩展属性的值
											}
										}
									}
						}
					}
					
				}
					List<UTMap<String, Object>> propertyList = softCategoryDao.getPropertyByCategoryId(map.get("id").toString());
					if(null != propertyList && propertyList.size() > 0){
						flag = softCategoryDao.deleteProperty(map.get("id").toString());//级联删除扩展属性
						for (Map<String, Object> utMap : propertyList) {
							List<UTMap<String, Object>> options = softCategoryDao.getOptionByPropertyId(utMap.get("id").toString());
							if(null != options && options.size() > 0){
								flag = softCategoryDao.deleteOption(utMap.get("id").toString());//删除资产小类下的扩展属性的值
							}
						}
				}
			}*/
		}
		return flag;
	}

	@Override
	public boolean deleteSubCategory(Map info) {
		boolean flag = false;
		String id = (String) info.get("id");
		UTMap<String, Object> map = null;
		if(StringUtils.isNotEmpty(id)){
			flag = softCategoryDao.deleteSubCategory(id);//删除资产小类
			/*List<UTMap<String, Object>> subPropertyList = softCategoryDao.getSubPropertyById(id);//获取资产小类下的扩展属性
					if(null != subPropertyList && subPropertyList.size() > 0){
						if(flag){
							flag = softCategoryDao.deleteSubProperty(id);//删除资产小类下的扩展属性
						}
						for (Map<String, Object> utMap : subPropertyList) {
							List<UTMap<String, Object>> options = softCategoryDao.getOptionByPropertyId(utMap.get("id").toString());
							if(null != options && options.size() > 0){
								flag = softCategoryDao.deleteOption(utMap.get("id").toString());//删除资产小类下的扩展属性的值
							}
						}
					}*/
		}
		return flag;
	}

	@Override
	public List<UTMap<String, Object>> getSubCategoryByParentId(String parentId) {
		return softCategoryDao.getSubCategoryByParentId(parentId);
	}

	@Override
	public String getCategoryIdByName(Map<String, Object> params) {
		return softCategoryDao.getCategoryIdByName(params);
	}

	@Override
	public String getSubCategoryIdByName(Map<String, Object> params) {
		return softCategoryDao.getSubCategoryIdByName(params);
	}


	/*@Override
	public boolean deleteProperty(String categoryId) {
		return softCategoryDao.deleteProperty(categoryId);
	}*/


	/*@Override
	public boolean deleteOption(String categoryId) {
		return softCategoryDao.deleteOption(categoryId);
	}*/


	/*@Override
	public boolean deleteSubProperty(String categoryId) {
		return softCategoryDao.deleteSubProperty(categoryId);
	}*/


	@Override
	public List<UTMap<String, Object>> getCategoryByNameAndId(String name,
			String id) {
		return softCategoryDao.getCategoryByNameAndId(name, id);
	}


	@Override
	public UTMap<String, Object> getSubCategoryByNameAndCategoryId(
			String name, String id) {
		return softCategoryDao.getSubCategoryByNameAndCategoryId(name, id);
	}


	@Override
	public List<UTMap<String, Object>> getSubCategoryByNameAndCategoryIdAndSubCategoryId(
			String name, String id, String parentId) {
		return softCategoryDao.getSubCategoryByNameAndCategoryIdAndSubCategoryId(name,id, parentId);
	}

	public List<UTMap<String, Object>> getCategoryByType(String type) {
		return softCategoryDao.getCategoryByType(type);
	}

//	@Override
//	public UTMap<String, Object> getIdBySubCategoryNameAndCategoryName(
//			String categoryName, String subCategoryName) {
//		return softCategoryDao.getIdBySubCategoryNameAndCategoryName(categoryName, subCategoryName);
//	}
}