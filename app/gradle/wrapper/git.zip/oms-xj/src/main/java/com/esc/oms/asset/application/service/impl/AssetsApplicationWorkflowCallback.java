package com.esc.oms.asset.application.service.impl;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.message.send.MessageSend;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.workflow.service.IWorkflowCallback;
import org.esc.framework.workflow.service.IWorkflowCode;
import org.springframework.stereotype.Service;

import com.esc.oms.asset.application.service.IAssetApplicationService;
import com.esc.oms.asset.lowvalue.dao.ILowvalueApplyDao;
import com.esc.oms.util.TaskModel;

@Service
public class AssetsApplicationWorkflowCallback implements IWorkflowCallback {
	
	@Resource
	private IAssetApplicationService assetApplicationService;
	@Resource
	private IUserTaskService userTaskService;
	
	public static final String STATUS_TERMINATE = "9";	// 被终止
	
	@Resource
	private MessageSend messageService;
	
	/**
	 * 返回流程编码
	 * @return
	 */
	public String workflowCode() {
		return IWorkflowCode.PHYSICAL_ASSET_APPLY;
	}
	
	/**
	 * 回调方法。
	 * 流程完成时，业务上需要进行的相应操作。
	 * @param businessRecordId
	 */
	public void onFinish(String businessRecordId) {
		assetApplicationService.finishAudit(businessRecordId);
	}
	
	/**
	 * 回调方法。
	 * 流程回到开始节点时，业务上需要进行的相应操作。
	 * @param businessRecordId
	 */
	public void onReject(String businessRecordId) {
		assetApplicationService.rejectAudit(businessRecordId);
	}

	/**
	 * 回调方法。
	 * 流程节点 待办任务 可自定义内容
	 * @param businessRecordId
	 */
	public void sendTask(String workflowName, String businessRecordId,	String nodeName, String userId) {
		Map<String,Object> dataParam = new HashMap<String,Object>();
		UTMap<String,Object> utMap = assetApplicationService.getById(businessRecordId);
		//点击待办事项，打开待审批列表tab
		dataParam.put("dataType", "1");
		userTaskService.addTaskByUserId("资产申请【"+utMap.get("title")+"/"+utMap.get("code")+"】待您审批", businessRecordId, nodeName, TaskModel.PhysicalAssetApply, userId,dataParam);
	}

	
	public void optionNode(String workflowCode, String businessRecordId,
			String nodeName, String linkName) {
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("status", ILowvalueApplyDao.STATUS_AUDITING);
			map.put("id", businessRecordId);
			assetApplicationService.updateById(map);	
	
		}

	@Override
	public void onTerminate(String businessRecordId) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("status", STATUS_TERMINATE);
		map.put("id", businessRecordId);
		assetApplicationService.updateById(map);	
		
		UTMap<String,Object> appInfo = assetApplicationService.getById(businessRecordId);
		if(null != appInfo){
			String title = "资产申请【"+appInfo.get("title")+"/"+appInfo.get("code")+"】终止提醒";
			String content = "资产申请：【"+appInfo.get("title")+"/"+appInfo.get("code")+"】已被终止，请知悉！详情请进入系统查看";
			messageService.sendMessage(String.valueOf(appInfo.get("createUserId")),title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
		}
	}
	
}
