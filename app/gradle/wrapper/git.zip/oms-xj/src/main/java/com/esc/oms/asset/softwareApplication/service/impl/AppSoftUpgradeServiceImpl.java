package com.esc.oms.asset.softwareApplication.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.timetask.anotations.CronTimeTask;
import org.esc.framework.timetask.anotations.TimeTaskMark;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.upload.service.ISysProjectFileService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.asset.softwareApplication.dao.IAppSoftDisableDao;
import com.esc.oms.asset.softwareApplication.dao.IAppSoftUpgradeDao;
import com.esc.oms.asset.softwareApplication.service.IAppSoftHistoryService;
import com.esc.oms.asset.softwareApplication.service.IAppSoftUpgradeService;
import com.esc.oms.asset.softwareApplication.service.IAppSoftwareService;
import com.esc.oms.util.CommonUtils;



@Service
@Transactional
@TimeTaskMark
public class AppSoftUpgradeServiceImpl extends BaseOptionService implements IAppSoftUpgradeService {

	
	@Resource
	private IAppSoftUpgradeDao softUpgradeDao;
	
	@Resource
	private ISysProjectFileService sysProjectFileService;
	
	@Resource
	private IAppSoftwareService assetSoftwareService;
	
	@Resource
	private IAppSoftHistoryService softHistoryService;
	
	@Resource
	private IAppSoftDisableDao softDisableDao;
	
	
	protected Logger logger = LoggerFactory.getLogger(getClass());
	
	
	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	
	/**
	 * 添加
	 * @param info
	 * @return
	 */
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean add(Map info){
		return super.add(info);
	}
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		return super.getById(id);
	}
	

	/**
	 * 修改
	 * @param info
	 * @return
	 */
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean updateById(Map info){
		return super.updateById(info);
	}
	
	
//	@UploadQueryMarks
//	public void getPageInfo(UTPageBean pageBean, Map params) {
//		super.getPageInfo(pageBean, params);
//	}
	
	
	
	@Override
	public List<UTMap<String, Object>> getSoftUpgradeList(Map param) {
		return softUpgradeDao.getSoftUpgradeList(param);
	}

	@Override
	public boolean leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String[] fileds = new String[] { 
				IAppSoftUpgradeDao.FIELD_SOFTWAREID,  //名称  asi.`name` as softwareId
				IAppSoftUpgradeDao.FIELD_OPERATION,   //简称  asi.`shortName` as operation
				IAppSoftUpgradeDao.FIELD_UPVERSION,
				IAppSoftUpgradeDao.FIELD_UPDATEE,
				IAppSoftUpgradeDao.FIELD_ISOLDDISABLED,
				IAppSoftUpgradeDao.FIELD_REASON,
				IAppSoftUpgradeDao.FIELD_EXPLAINN
		};
		if (null != data && !data.isEmpty()) {
			for (int i=0;i<data.size();i++) {
				UTMap<String, Object> item = (UTMap<String, Object>) data.get(i);
				item.put(IAppSoftUpgradeDao.FIELD_UPDATEE, 
						CommonUtils.replaceAll((String) item.get(IAppSoftUpgradeDao.FIELD_UPDATEE), "-", "/"));
			}
		}
		String tamlate="excelOutTamplate.appSoftUp";	
		return	UTExcel.leadingout( fileds, data, tamlate, request,response);
	}

	@Override
	public IBaseOptionDao getOptionDao() {
		return softUpgradeDao;
	}

	@CronTimeTask(description="扫描软件升级记录及软件禁用更新软件版本并生成软件历史记录",cron="0 0 23 * * ?")
	@Override
	public void execute() {
		logger.info("开始扫描软件升级记录！=========================================================");
		Map param = new HashMap();
		param.put("upDate", sdf.format(new Date()));
		
		//获取停用时间为当天的软件升级记录
		List<UTMap<String, Object>> list = softUpgradeDao.getSoftUpgradeListByUpDate(param);
		if (null != list && list.size() > 0) {
			for(Map<String,Object> map : list){
				UTMap<String,Object> softMap = assetSoftwareService.getById(map.get("softwareId").toString());
				map.put("status", softMap.get("status"));			 
				try {
					upgrade(map);
				} catch (ParseException e) {					
					logger.error("ParseException",e);
				}
			}		
		}
		
		Map disableParam = new HashMap();
		disableParam.put("disableDate", sdf.format(new Date()));
		//获取停用时间为当天的软件停用记录
		List<UTMap<String, Object>> disablelist = softDisableDao.getSoftDisableListByDisableDate(disableParam);
		if (null != disablelist && disablelist.size() > 0) {
			for (Map<String, Object> map : disablelist) {
//				if ("1".equals((String) map.get("isOldDisabled"))) {
				disable(map);
//				}
			}
		}
		
		//获取停用时间为当天的软件历史记录
		List<UTMap<String, Object>> historylist = softHistoryService.getHistoryListByDisableDate(disableParam);
		if (null != historylist && historylist.size() > 0) {
			for (Map<String, Object> map : historylist) {
				map.put("status", "4");
				softHistoryService.updateById(map);
			}
		}
		
	}

	public void disable(Map<String, Object> map){
		UTMap<String, Object> softInfo = assetSoftwareService.getById((String)map.get("softwareId"));		
		addHistory(softInfo,map);
		softInfo.put("status", AppSoftwareServiceImpl.APP_SOFT_END);
		softInfo.put("endDate", map.get("disableDate"));
		assetSoftwareService.updateById(softInfo);
	}
	
	private void addHistory(UTMap<String, Object> softInfo,Map<String, Object> map){
		//add histroy info
		UTMap<String, Object> hisInfo = new UTMap<String, Object>();
		hisInfo.put("softwareId",softInfo.get("id"));
		hisInfo.put("softwareName",softInfo.get("name"));
		hisInfo.put("version",softInfo.get("version"));
		hisInfo.put("versionAddress",softInfo.get("versionAddress"));
		hisInfo.put("scCodeAddress",softInfo.get("scCodeAddress"));
		hisInfo.put("documentAddress",softInfo.get("documentAddress"));
		//hisInfo.put("website",softInfo.get("website"));
		hisInfo.put("chargeId",softInfo.get("chargeId"));
		//hisInfo.put("operation",softInfo.get("operation"));
		hisInfo.put("chargeNumber",softInfo.get("chargeNumber"));
		hisInfo.put("useDepartIds",softInfo.get("useDepartIds"));
		hisInfo.put("introducation",softInfo.get("introducation"));
		hisInfo.put("disableDate", map.get("disableDate")); //停用时间
		//历史版本状态为已停用
		Object status = map.get("status");
		if(status==null){
			status =  AppSoftwareServiceImpl.APP_SOFT_END;
		}
		hisInfo.put("status", status);
		List<String> softFileIds = queryFileIdsByPorjectId((String)softInfo.get("id"));
		hisInfo.put("fileIds", softFileIds);
		softHistoryService.add(hisInfo);
	}
	
	@Override
	public void upgrade(Map<String, Object> map) throws ParseException {	
		UTMap<String, Object> softInfo = assetSoftwareService.getById((String)map.get("softwareId"));	
		if ("1".equals((String) map.get("isOldDisabled"))) {//旧版本停用
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String today = sdf.format(new Date());
			//停用日期
			Date disableDate = sdf.parse((String) map.get("disableDate"));
			if (disableDate.before(sdf.parse(today))) { //今天之前（不包括今天）
				map.put("status", AppSoftwareServiceImpl.APP_SOFT_END);
			} 
		}else{
			map.put("disableDate", null); //停用时间
		}
		addHistory(softInfo,map);
		//update software info
		softInfo.put("version",map.get("upVersion"));
		softInfo.put("introducation",map.get("explainn"));
		softInfo.put("versionAddress",map.get("versionAddress"));
		softInfo.put("scCodeAddress",map.get("scCodeAddress"));
		softInfo.put("documentAddress",map.get("documentAddress"));
		
		//更新软件资产附件
		String projectId = (String) map.get("id");
		List<String> upFileIds = queryFileIdsByPorjectId(projectId);
		softInfo.put("fileIds", upFileIds);
		assetSoftwareService.updateById(softInfo);
	}

	@Override
	public List<String> queryFileIdsByPorjectId(String projectId) {
		List<UTMap<String, Object>> files = sysProjectFileService.getFilesByProjectAndType(projectId);
		List<String> fileIds = new ArrayList<String>();
		
		if (files != null && files.size() > 0) {
			for (Map utmap : files) {
				fileIds.add((String) utmap.get("id"));
			}
		}
		return fileIds;
	}

}
