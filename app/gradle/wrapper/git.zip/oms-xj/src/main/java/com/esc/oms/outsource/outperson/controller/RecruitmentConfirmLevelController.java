package com.esc.oms.outsource.outperson.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.outsource.outperson.service.IRecruitmentConfirmLevelService;
import com.esc.oms.util.CommonUtils;

/**
 * 人员定级
 * @author panyi 2018-11-19
 *
 */
@Controller
@RequestMapping("/recruitmentConfirmLevel")
public class RecruitmentConfirmLevelController extends BaseOptionController{

	@Resource
	private IRecruitmentConfirmLevelService service;
	
	@Override
	public IBaseOptionService optionService() {
		return service;
	}
	
	@RequestMapping("getPageInfo")
	@ResponseBody
	public UTPageBean getPageInfo(@RequestParam Map<String, Object> params) {
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			service.getPageInfo(pageBean, params);
			List datas = pageBean.getRows();
			if (null != datas && !datas.isEmpty()){
				for (int i=0;i<datas.size();i++) {
					Map item = (Map) datas.get(i);
					item.put("interviewResult", StringUtils.equals((String)item.get("interviewResult"), "1") ? "通过" : "不通过");
					String managerReviewResult = (String)item.get("managerReviewResult");
					if (StringUtils.isEmpty(managerReviewResult)) {
						item.put("managerReviewResult", "");
					}else if (StringUtils.equals(managerReviewResult, "1")) {
						item.put("managerReviewResult", "通过");
					}else {
						item.put("managerReviewResult", "不通过");
					}
					//item.put("managerReviewResult", StringUtils.equals((String)item.get("managerReviewResult"), "1") ? "通过" : "不通过");
				}
			}
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
		return pageBean;
	}
	
	@RequestMapping("getAlreadyPageInfo")
	@ResponseBody
	public UTPageBean getAlreadyPageInfo(@RequestParam Map<String, Object> params) {
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			service.getAlreadyPageInfo(pageBean, params);
			List datas = pageBean.getRows();
			if (null != datas && !datas.isEmpty()){
				for (int i=0;i<datas.size();i++) {
					Map item = (Map) datas.get(i);
					item.put("interviewResult", StringUtils.equals((String)item.get("interviewResult"), "1") ? "通过" : "不通过");
					String managerReviewResult = (String)item.get("managerReviewResult");
					if (StringUtils.isEmpty(managerReviewResult)) {
						item.put("managerReviewResult", "");
					}else if (StringUtils.equals(managerReviewResult, "1")) {
						item.put("managerReviewResult", "通过");
					}else {
						item.put("managerReviewResult", "不通过");
					}
					//item.put("managerReviewResult", StringUtils.equals((String)item.get("managerReviewResult"), "1") ? "通过" : "不通过");
				}
			}
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
		return pageBean;
	}
	
	@RequestMapping("getInfoById")
	@ResponseBody
	public UTMap<String, Object> getInfoById(@RequestParam Map<String, Object> param){
		return service.getInfoById((String)param.get("id"));
	}
	
	@RequestMapping(value = "confirmLevel",method =RequestMethod.POST)
	@ResponseBody
	public String confirmLevel(@RequestBody Map<String, Object> param) {
		boolean flag = false;
		try {
			flag = service.confirmLevel(param);
		}catch(EscServiceException e) {
			return UTJsonUtils.getJsonMsg(false, e.getMessage());
		}
		if (!flag) {
			return UTJsonUtils.getJsonMsg(false, "操作失败");
		}
		return UTJsonUtils.getJsonMsg(true, "操作成功");
	}

}
