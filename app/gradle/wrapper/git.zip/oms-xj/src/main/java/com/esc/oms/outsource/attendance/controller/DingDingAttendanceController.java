package com.esc.oms.outsource.attendance.controller;

import com.esc.oms.outsource.attendance.service.IDingDingAttendanceService;
import com.esc.oms.util.LocalDateUtil;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Map;

@Controller
@RequestMapping("dingDingAttendance")
public class DingDingAttendanceController{

    @Resource
    IDingDingAttendanceService dingDingAttendanceService;


    /**
     * 获取打卡结果，起始和工作日最多相隔7天，所以，我们以7天为一个间隔，获取数据
     * @param param
     * @return
     */
    @RequestMapping(value = "getAttenanceByTime")
    @ResponseBody
    public String getAttendanceResultByTime(@RequestBody Map<String,Object> param){
        DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        DateTimeFormatter df2 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String sTime = (String) param.get("startTime");//开始时间
        String eTime = (String) param.get("endTime");//结束时间
        LocalDate sTimeLocal = LocalDate.parse(sTime, df);//开始时间
        LocalDate eTimeLocal = LocalDate.parse(eTime, df);//结束时间

        int days = Integer.parseInt(String.valueOf(eTimeLocal.toEpochDay() -sTimeLocal.toEpochDay()))+1;//这里加一天，获取多一天的数据
        int toIndex = 6;
        try {
            for(int i = 0; i <= days; i+=7){
                if(i + 6 >= days){
                    toIndex = days-i;
                    dingDingAttendanceService.getAttendanceListByTime(df2.format(LocalDateUtil.toLocalDateTime(sTimeLocal.plusDays(i))),
                            df2.format(LocalDateUtil.toLocalDateTimeMax((sTimeLocal.plusDays(i+toIndex)))),true);
                    dingDingAttendanceService.getAndAddNonExistent(df2.format(LocalDateUtil.toLocalDateTime(sTimeLocal.plusDays(i))), null);
                }else{
                    dingDingAttendanceService.getAttendanceListByTime(df2.format(LocalDateUtil.toLocalDateTime(sTimeLocal.plusDays(i))),
                            df2.format(LocalDateUtil.toLocalDateTimeMax((sTimeLocal.plusDays(i+toIndex)))),false);
                    dingDingAttendanceService.getAndAddNonExistent(df2.format(LocalDateUtil.toLocalDateTime(sTimeLocal.plusDays(i))),
                            df2.format(LocalDateUtil.toLocalDateTimeMax((sTimeLocal.plusDays(i+toIndex)))));
                }
            }
            dingDingAttendanceService.getAndMergeApprove(sTime, eTime);
            dingDingAttendanceService.mergeApproves();

        } catch (Exception e) {
            e.printStackTrace();
            return UTJsonUtils.getJsonMsg(false, "生成失败");
        }

        return UTJsonUtils.getJsonMsg(true, "生成成功");
    }

    /**
     * 同步请假加班调休记录
     * @param param
     * @return
     */
    @RequestMapping(value="getApproveList")
    @ResponseBody
    public String getApproveList(@RequestBody Map<String, Object> param){
        DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        DateTimeFormatter df2 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String sTime = (String) param.get("startTime");//开始时间
        String eTime = (String) param.get("endTime");//结束时间
        try {
            dingDingAttendanceService.getAndMergeApprove(sTime, eTime);
            dingDingAttendanceService.mergeApproves();
        } catch (Exception e) {
            e.printStackTrace();
            return UTJsonUtils.getJsonMsg(false, "同步审批记录失败");
        }
        return UTJsonUtils.getJsonMsg(true, "同步审批记录成功");
    }

    /**
     * 导入
     * @param filePath
     * @return
     */
    @RequestMapping(value = "leadingin")
    @ResponseBody
    public UTMap<String, Object> leadingin(@RequestParam String filePath) {
        UTMap<String, Object> utMap = new UTMap<String, Object>();
        try {
            utMap.put("success", dingDingAttendanceService.leadingInExcel(filePath));
            utMap.put("msg", "导入成功");
        }catch (EscServiceException e) {
            e.printStackTrace();
            utMap.put("success", false);
            utMap.put("msg", e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            utMap.put("success", false);
            utMap.put("msg", "导入失败");
        }
        return utMap;
    }
}
