package com.esc.oms.outsource.agreementManpower.dao.impl;

import org.esc.framework.persistence.dao.BaseOptionDao;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.agreementManpower.dao.IAgreementManpowerCostConfigDao;


/**
 * 人力外包人员费用配置
 * @author smq
 * @date   2016-2-24 上午10:55:10
 */
@Repository
public class AgreementManpowerCostConfigDaoImpl extends BaseOptionDao implements IAgreementManpowerCostConfigDao {

	@Override
	public String getTableName() {
		return "agreement_manpower_cost_config";
	}

}
