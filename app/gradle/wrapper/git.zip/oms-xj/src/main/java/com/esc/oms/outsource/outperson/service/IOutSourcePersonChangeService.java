package com.esc.oms.outsource.outperson.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;

/**
 * 外包人员更改记录
 * @author jane
 *
 */
public interface IOutSourcePersonChangeService extends IBaseOptionService {

	public List<UTMap<String,Object>> getLevelsByUserId(String userId);
	
	public boolean leadingout(List data, HttpServletRequest request,HttpServletResponse response) throws Exception;
	
	public void generate();
	
}
