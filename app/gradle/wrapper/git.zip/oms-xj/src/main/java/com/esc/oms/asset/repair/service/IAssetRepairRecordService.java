package com.esc.oms.asset.repair.service;

import java.util.List;
import java.util.Map;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;

public interface IAssetRepairRecordService extends IBaseOptionService {
	
	public UTMap<String, Object> getRepairRecordById(String id);
	
	public List<UTMap<String, Object>> getRepairRecordList(Map param);
}
