package com.esc.oms.outsource.monitor.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.monitor.dao.IMonitorEvaluateConfigurationDao;

/**
 * 服务监控评估配置模板Dao
 * @author owner
 *
 */
@Repository
public class MonitorEvaluateConfigurationDaoImpl extends BaseOptionDao implements IMonitorEvaluateConfigurationDao{

	@Override
	public String getTableName() {
		return "outsourc_monitor_evaluate_configuration";
	}
	
	@Override
	public List<UTMap<String, Object>> getListMaps(Map param) {
		return super.getListBySql(getSearchSql(param,false), null);
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params,false), pageBean, null);
	}
	
	@Override
	public UTMap<String, Object> getById(String id) {
		String sql = this.getSearchSql(null,true);
		List<UTMap<String, Object>> list = super.getListBySql(sql, id);
		if(list != null && list.size() > 0){
			return list.get(0);
		}
		return null;
	}
	
	/**
	 * 根据当前时间查询服务监控模板配置数据，用来生成评估数据
	 * @return
	 */
	@Override
	public List<UTMap<String, Object>> getListAllByMonitorPeriod(){
		String month = UTDate.getNowMonth()+"";// 多少月
		String day = UTDate.getNowDay() + "";// 多少号
		StringBuilder sql=new StringBuilder();
		sql.append(" select * from ");
		sql.append(getTableName());
		//monitorPeriod监控周期（每月:1、每季度:2、每年:3）
		sql.append(" where ((monitorPeriod = 1 and day = '"+day+"') ");//每月几号
		sql.append(" or (monitorPeriod = 2 and month = "+UTDate.switchQuarterMonth()+" and day = '"+day+"')  ");//每季度
		sql.append(" or (monitorPeriod = 3 and month = '"+month+"' and day = '"+day+"')) ");//每年
		sql.append(" and status = 0 ");//启用状态（状态.启用：0，禁用：1）
//		sql.append(" and manner = 1");//巡检方式,1：定期巡检，2：临时巡检
		sql.append(" and ( generateTime is  null or (generateTime is not null and '"+UTDate.getCurDate()+"' != DATE_FORMAT(generateTime,'%Y-%m-%d'))) ");//根据generateTime判断当天是否已经生成过了
		return this.getListBySql(sql.toString(), null);
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params,boolean isGetById){
		StringBuilder sql=new StringBuilder();
		sql.append("select tb.*,sbi.name as 'supplierName',CONCAT(tb.templateConfigurationName , ' ' , tb.templateConfigurationVersions) as 'templateConfiguration',su.name as 'pauseUserName' from " );
		sql.append(getTableName());
		sql.append(" tb left join supplier_base_info sbi on tb.supplierId = sbi.id");
		sql.append(" left join sys_user su on tb.pauseUserId = su.id where 1=1 ");
		if(isGetById){
			sql.append(" and tb.id = ? ");
		}
		if(params!=null && params.size()>0){
			if(params.get("evaluateTitle")!=null &&  StringUtils.isNotEmpty(params.get("evaluateTitle").toString())){
				sql.append(" and tb.evaluateTitle like '%"+params.get("evaluateTitle").toString().trim()+"%' ");
			}
			if(params.get("supplierName")!=null &&  StringUtils.isNotEmpty(params.get("supplierName").toString())){
				sql.append(" and sbi.name like '%"+params.get("supplierName").toString().trim()+"%' ");
			}
//			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
//				sql.append(" and tb.supplierId like '%"+params.get("name").toString().trim()+"%' ");
//			}
			if(params.get("supplierId")!=null && StringUtils.isNotEmpty(params.get("supplierId").toString())){
				sql.append(" and tb.supplierId = '"+params.get("supplierId").toString().trim()+"' ");
			}
			if(params.get("type")!=null && StringUtils.isNotEmpty(params.get("type").toString())){
				sql.append(" and tb.type = "+params.get("type").toString().trim()+" ");
			}
			if(params.get("status")!=null && StringUtils.isNotEmpty(params.get("status").toString())){
				sql.append(" and tb.status = "+params.get("status").toString().trim()+" ");
			}
		}
		sql.append(" order by createTime desc");
		return  sql.toString();
	}

}
