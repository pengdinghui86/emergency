package com.esc.oms.asset.softwareApplication.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.asset.software.service.ISoftCategoryService;
import com.esc.oms.asset.softwareApplication.dao.IAppSoftwareDao;
import com.esc.oms.asset.softwareApplication.service.IAppSoftHistoryService;
import com.esc.oms.asset.softwareApplication.service.IAppSoftwareService;
import com.esc.oms.util.CommonUtils;


@Controller
@RequestMapping("appSoftware")
public class AppSoftwareController extends BaseOptionController {

	@Resource
	private IAppSoftwareService assetSoftwareService;
	
	@Resource
	private IAppSoftHistoryService softHistoryService;
	
	@Resource
	private ISoftCategoryService softCategoryService;

	@Resource
	private ISysParamService sysParamService;
	
	
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			assetSoftwareService.getPageInfo(pageBean, params);
			
		
			
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	
	@RequestMapping(value="/saveOrUpdate",method=RequestMethod.POST)  
    @ResponseBody
    public JSONObject saveorupdate(@RequestBody Map<String,Object> map){  
    	String id = (String)map.get("id");
    	try{
	    	if(id == null){
//	    		map.put("code", System.currentTimeMillis());
	    		assetSoftwareService.add(map);
	    		id=(String)map.get("id");
	    	}else{
	    		assetSoftwareService.updateById(map);
	    	}
    	}catch(EscServiceException e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getMsgJson(false,e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getMsgJson(false, "操作失败");
    	}
    	Map<String,Object> item=new HashMap<String,Object>();
    	item.put("id",id);
       return UTJsonUtils.getMsgJson(true, "操作成功", item);
    }
	

	
	@RequestMapping(value="getById")
	@ResponseBody
	public UTMap<String, Object> defgetById(@RequestParam  Map<String, Object> param){		
		UTMap<String, Object> utmap  = null;
		try{
    		String id = param.get("id").toString();
    		utmap = optionService().getById(id);
    		
    		Map params = new HashMap();
    		params.put("softwareId", id);
    		List<UTMap<String, Object>> list = softHistoryService.getHistoryListBySoftId(params);
//    		
//    		if (null != list && list.size() > 0) {
//    			for (Map<String, Object> map : list) {
//    				int status = (Integer) map.get("status");
//    				if (1 == status) {
//    					map.put("status", "待启用");
//    				} else if (2 == status) {
//    					map.put("status", "正在使用");
//    				} else if (3 == status) {
//    					map.put("status", "维护期");
//    				} else {
//    					map.put("status", "停用");
//    				}
//    			}
//    		}
    		utmap.put("historyList", list);
    		
    		String category = (String)utmap.get("category");
    		List<UTMap<String, Object>> list2 = softCategoryService.getSubCategoryByParentId(category);
    		utmap.put("subCategoryList", list2);
    		
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return utmap;
	}
	
	
	@RequestMapping(value = "leadingout")
	public void leadingout(@RequestParam Map<String, Object> param,
			HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();

			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = null;
			if (info != null) {
				jsonBean = JSONObject.fromObject(info);
			}

			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = assetSoftwareService.getSoftwareList(jsonBean);
			} else {
				// 根据条件 导出当前
				assetSoftwareService.getPageInfo(utPageBean, jsonBean);
				data = utPageBean.getRows();
			}
			//替换下拉的值
			Map<String, String> fieldAndParamType = new HashMap<String, String>();
			fieldAndParamType.put(IAppSoftwareDao.FIELD_EXPLOIT_TYPE, "exploitType");
			fieldAndParamType.put(IAppSoftwareDao.FIELD_STATUS, "appSoftStatus");
			sysParamService.changeParamData(data, fieldAndParamType);
			if (null != data && data.size() > 0) {
				for (Map<String, Object> map : data) {
					
					String maintenance = String.valueOf(map.get("maintenance"));
					if("1".equals(maintenance)){
						map.put("maintenance", "是");
					}else{
						map.put("maintenance", "否");
					}
					
					String isSteerable = String.valueOf(map.get("isSteerable"));
					if("1".equals(isSteerable)){
						map.put("isSteerable", "是");
					}else{
						map.put("isSteerable", "否");
					}
					String isExpire =map.get("isExpire")!=null? String.valueOf(map.get("isExpire")):null;
					if(isExpire!=null&&"1".equals(isExpire)){
						map.put("isExpire", "是");
					}else{
						map.put("isExpire", "否");
					}
					
				}
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			assetSoftwareService.leadingout(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	/**
	 * 从excel导入
	 * 
	 * @param params
	 * @param filePath
	 * @return
	 */
	@RequestMapping(value = "leadingin")
	@ResponseBody
	public UTMap<String, Object> leadingin(@RequestParam Map<String, Object> param, String filePath) {
		UTMap<String, Object> utMap = new UTMap<String, Object>();
		try {
			utMap.put("success", assetSoftwareService.leadingin(filePath, param));
			utMap.put("msg", "导入成功！");
		} catch (EscServiceException e) {
			logger.error("EscServiceException",e);
			utMap.put("success", false);
			utMap.put("msg", e.getMessage());
		} catch (Exception e) {
			logger.error("EscServiceException",e);
			utMap.put("success", false);
			utMap.put("msg", "导入失败");
		}
		return utMap;
	}

	@Override
	public IBaseOptionService optionService() {
		return assetSoftwareService;
	}

}
