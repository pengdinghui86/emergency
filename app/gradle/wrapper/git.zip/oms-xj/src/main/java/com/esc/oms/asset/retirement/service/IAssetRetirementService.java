package com.esc.oms.asset.retirement.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;


public interface IAssetRetirementService extends IBaseOptionService{
	
	public boolean addRelation(Map info);
	
	/**
	 * 查询备件
	 * */
	public List<UTMap<String, Object>> getAssetsById(String id) ;
	
	/**
	 * 根据资产id删除备件联系
	 * @param id
	 * @return
	 */
	public boolean deleteAssetsById(String id);
	
	
	public boolean leadingout(List data, HttpServletRequest request,HttpServletResponse response) throws Exception;
	
	public List<UTMap<String, Object>> getAssetsList(Map param);
	
	public boolean updateAssetsInfo(List assetsList,Map<String, Object> map);
	
	/**
	 * 保存数据
	 * @param map
	 */
	public void save(Map<String, Object> map);
	
//	/**
//	 * 保存数据并提交
//	 * @param map
//	 */
//	public void submit(Map<String,Object> map);
//	
//	/**
//	 * 完成审核
//	 * @param recordId 记录ID
//	 */
//	public void finishAudit(String id);
//	
//	/**
//	 * 驳回审核
//	 * @param recordId 记录ID
//	 */
//	public void rejectAudit(String id);
}
