package com.esc.oms.asset.software.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

public interface ISoftUpgradeDao extends IBaseOptionDao{
	
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_SOFTWAREID = "softwareId";
	public static final String  FIELD_UPVERSION = "upVersion";
	public static final String  FIELD_UPDATEE = "upDatee";
	public static final String  FIELD_ISOLDDISABLED = "isOldDisabled";
	public static final String  FIELD_DISABLEDATE	 = "disableDate";
	public static final String  FIELD_REASON = "reason";
	public static final String  FIELD_EXPLAINN = "explainn";
	public static final String  FIELD_OPERATION = "operation";
	public static final String  FIELD_NEWEBSITE = "newebsite";
	public static final String  FIELD_CREATEUSERID = "createUserId";
	public static final String  FIELD_CREATETIME = "createTime";
	
	
	
	public List<UTMap<String, Object>> getSoftUpgradeList(Map param);
	
	public List<UTMap<String, Object>> getSoftUpgradeListByUpDate(Map param);

}
