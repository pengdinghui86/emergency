package com.esc.oms.outsource.manhour.dao.impl;

import com.esc.oms.outsource.manhour.dao.IOverTimeDetailDao;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.springframework.stereotype.Repository;

@Repository
public class OverTimeDetailDaoImpl extends BaseOptionDao implements IOverTimeDetailDao {
    @Override
    public String getTableName() {
        return "workhour_overtime_detail";
    }

    @Override
    public boolean deleteByTime(String startTime, String endTime, String userIds) {
        StringBuilder sql = new StringBuilder();
        sql.append("  delete from workhour_overtime_detail where infoId in (");
        sql.append(" select id from workhour_overtime where (submitTime >= '"+startTime+"' and submitTime <='"+endTime+"') ");
        sql.append(" or(beginTime <= '"+startTime+"' and endTime >='"+endTime+"')");
        sql.append(" or (beginTime <= '"+startTime+"' and endTime >='"+startTime+"' and endTime <='"+endTime+"')");
        sql.append(" or (beginTime >='"+startTime+"' and beginTime <='"+endTime+"' and endTime >='"+endTime+"')");
        sql.append(" or(beginTime >= '"+startTime+"' and endTime <='"+endTime+"')");
        sql.append(" and createUserId in("+userIds+"))");
        return this.executeUpdate(sql.toString());
    }
}
