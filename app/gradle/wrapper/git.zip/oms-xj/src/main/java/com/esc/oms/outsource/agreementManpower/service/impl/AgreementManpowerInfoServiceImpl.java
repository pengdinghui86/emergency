package com.esc.oms.outsource.agreementManpower.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.agreementManpower.dao.IAgreementManpowerCostConfigDao;
import com.esc.oms.outsource.agreementManpower.dao.IAgreementManpowerInfoDao;
import com.esc.oms.outsource.agreementManpower.dao.IAgreementManpowerVacationConfigDao;
import com.esc.oms.outsource.agreementManpower.service.IAgreementManpowerInfoService;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;


/**
 * 人力外包合同 配置
 * @author smq
 * @date   2016-2-24 上午10:50:04
 */
@Service
@Transactional
public class AgreementManpowerInfoServiceImpl  extends BaseOptionService implements  IAgreementManpowerInfoService {
	@Resource
	private IAgreementManpowerInfoDao agreementManpowerInfoDao;
	@Resource
	private IAgreementManpowerCostConfigDao costConfigDao;
	@Resource
	private IAgreementManpowerVacationConfigDao vacationConfigDao;
	@Override
	public IBaseOptionDao getOptionDao() {
		return agreementManpowerInfoDao;
	}
//	
//	@UploadAddMark
//	public boolean saveBaseInfo(Map<String, Object> baseInfoMap){
//		boolean flog=true;
//	
//		//保存基础配置
//		if(!baseInfoMap.containsKey("id")){
//			baseInfoMap.put("code",agreementManpowerInfoDao.getNewCode(101, "code"));
//			flog=	agreementManpowerInfoDao.add(baseInfoMap);
//		//	manpowerId=baseInfoMap.get("id").toString();
//		}else{
//		//	manpowerId=baseInfoMap.get("id").toString();
//			flog=agreementManpowerInfoDao.updateById(baseInfoMap);
//		}
//		return flog;
//	}
	

	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		UTMap<String, Object> result = super.getById(id);
		return result;
	}
	
	//保存合同配置 合同配置信息包括 （基础配置:baseInfoMap  费用配置costConfigs 折算配置 vacationConfigs）
	@Override
	@EscOptionLog(module=SystemModule.outsourceAgreementManpower, opType=ESCLogOpType.UPDATE, table="agreement_manpower_info", 
	primaryKey="id={1.id}",	option="保存{1.agreementName}的合同配置")
	@UploadAddMark
	public boolean saveAgreementManpowerInfo(Map<String, Object> baseInfoMap,	List<Map<String, Object>> costConfigs,	List<Map<String, Object>> vacationConfigs)throws EscServiceException {
		boolean flog=true;
		try {
			String manpowerId=null;
			//保存基础配置
			if(!baseInfoMap.containsKey("id")){
				baseInfoMap.put("code",agreementManpowerInfoDao.getNewCode(101, "code"));
				flog=	agreementManpowerInfoDao.add(baseInfoMap);
				manpowerId=baseInfoMap.get("id").toString();
			}else{
				manpowerId=baseInfoMap.get("id").toString();
				flog=agreementManpowerInfoDao.updateById(baseInfoMap);
			}
			//保存费用配置
			flog=costConfigs!=null &&costConfigs.size()>0?saveCostConfigs(manpowerId,costConfigs):true;
		
			//保存折算配置
			flog=vacationConfigs!=null &&vacationConfigs.size()>0?saveVacationConfig(manpowerId,vacationConfigs):true;
			
		} 
		catch (EscServiceException e) {
			throw e;
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			throw new EscServiceException("操作异常");
		}
		return flog;
	}
	

	@Override
	@EscOptionLog(module=SystemModule.outsourceAgreementManpower, opType=ESCLogOpType.DELETES, table="agreement_manpower_info", 
	primaryKey="id={1}",	option="删除的合同配置")
	public boolean deletesAgreementManpowerInfo(String ids) { 
		Map<String, Object> param=new HashMap<String, Object>();
		param.put(IAgreementManpowerCostConfigDao.FIELD_MANPOWERID, ids);
		 costConfigDao.deletes(param);
		 vacationConfigDao.deletes(param);

		 agreementManpowerInfoDao.deleteByIds(ids);
		 return true;
	}
	
	//获取 所有未进行配置的人力外包合同
	@Override
	public List<UTMap<String, Object>> getAgreementManpowerNoConfig() {
		return agreementManpowerInfoDao.getAgreementManpowerNoConfig();
	}
	
	//通过 合同配置id 获取 外包人力合同费用配置
	@Override
	public List<UTMap<String, Object>> getManpowerCostConfigs(String manpowerId) {
		Map<String, Object> param=new HashMap<String, Object>();
		param.put(IAgreementManpowerCostConfigDao.FIELD_MANPOWERID, manpowerId);
		return costConfigDao.getListMaps(param);
	}

	//通过 合同配置id 获取 外包人力合同 折算配置
	@Override
	public List<UTMap<String, Object>> getManpowerVacationConfig(
			String manpowerId) {
		Map<String, Object> param=new HashMap<String, Object>();
		param.put(IAgreementManpowerVacationConfigDao.FIELD_MANPOWERID, manpowerId);
		return vacationConfigDao.getListMaps(param);
	}

	//获取外包人力合同费用配置中所包括的人员类型 通过 合同配置Id
	@Override
	public List<UTMap<String, Object>> getVacationConfigCategory(
			String manpowerId) {
		Map<String, Object> param=new HashMap<String, Object>();
		param.put(IAgreementManpowerVacationConfigDao.FIELD_MANPOWERID, manpowerId);
		return costConfigDao.getListMaps(param, IAgreementManpowerCostConfigDao.FIELD_MANPOWERID,IAgreementManpowerCostConfigDao.FIELD_CATEGORY);
	}

	//获取 外包人力合同费用配置中对应人员类型所包括的人员级别 通过 合同配置Id和人员类型
	@Override
	public List<UTMap<String, Object>> getVacationConfigLeve(
			String manpowerId, String category) {	
		Map<String, Object> param=new HashMap<String, Object>();
			param.put(IAgreementManpowerCostConfigDao.FIELD_MANPOWERID, manpowerId);
			param.put(IAgreementManpowerCostConfigDao.FIELD_CATEGORY, category);
			return costConfigDao.getListMaps(param, IAgreementManpowerCostConfigDao.FIELD_MANPOWERID,IAgreementManpowerCostConfigDao.FIELD_CATEGORY,IAgreementManpowerCostConfigDao.FIELD_LEVEL,IAgreementManpowerCostConfigDao.FIELD_MONTHLYFEE);
	}

	@UploadQueryMark
	public Map<String, Object> getAgreementManpowerById(String manpowerId){
		Map<String, Object> resultMap=new HashMap<String, Object>();
		resultMap.put("baseConfig", this.getById(manpowerId));
		resultMap.put("vacationConfigs", this.getManpowerVacationConfig(manpowerId));
		resultMap.put("costConfigs", this.getManpowerCostConfigs(manpowerId));
		return resultMap;
	}
	
	public Map<String, Object> getAgreementManpowerByAgreementId(String agreementId){
		Map<String, Object> param=new HashMap<String, Object>();
		param.put("agreementId",agreementId);
		List<UTMap<String, Object>> list=agreementManpowerInfoDao.getListMaps(param, IAgreementManpowerInfoDao.FIELD_ID);
		String id=list!=null&&list.size()>0?list.get(0).get("id").toString():null;
		return StringUtils.isNotEmpty(id)?getAgreementManpowerById(id):null;
	}
	
	/**
	 * 保存 费用配置
	 * @param costConfigs
	 * @return
	 */
	private boolean saveCostConfigs(String manpowerId,List<Map<String, Object>> costConfigs){
		boolean flog=true;
		for (Map<String, Object> item : costConfigs) {
			if(!item.containsKey("optionType")){
				continue;
			}
			String optionType=item.get("optionType").toString();
			item.put(costConfigDao.FIELD_MANPOWERID, manpowerId);
			if(StringUtils.equals("add", optionType)){
				flog=	costConfigDao.add(item);
			}
			else if (StringUtils.equals("update", optionType)&&item.containsKey("id")) {
				flog=costConfigDao.updateById(item);
			}
			else if (StringUtils.equals("delete", optionType)&&item.containsKey("id")) {
				flog=costConfigDao.deleteByIds(item.get("id").toString());
			}else {
				continue;
			}
			if(!flog){
				break;
			}
		}
		if(!flog){
			flog=false;
			throw new EscServiceException("费用配置操作失败");
		}
		return flog;
	}
	
	/**
	 * 保存 折算配置
	 * @param costConfigs
	 * @return
	 */
	private boolean saveVacationConfig(String manpowerId,List<Map<String, Object>>vacationConfig){
		boolean flog=true;
		for (Map<String, Object> item : vacationConfig) {
			if(!item.containsKey("optionType")){
				continue;
			}
			String optionType=item.get("optionType").toString();
			item.put(vacationConfigDao.FIELD_MANPOWERID, manpowerId);
			if(StringUtils.equals("add", optionType)){
				flog=vacationConfigDao.add(item);
			}
			else if (StringUtils.equals("update", optionType)&&item.containsKey("id")) {
				flog=vacationConfigDao.updateById(item);
			}
			else if (StringUtils.equals("delete", optionType)&&item.containsKey("id")) {
				flog=vacationConfigDao.deleteByIds(item.get("id").toString());
			}else {
				continue;
			}
			if(!flog){
				break;
			}
		}
		if(!flog){
			flog=false;
			throw new EscServiceException("费用配置操作失败");
		}
		return flog;
	}
	
	/**
	 * 根据用户编号获取外包合同
	 * @param userId
	 * @return
	 */
	public UTMap<String, Object> getByUserId(String userId){
		return agreementManpowerInfoDao.getByUserId(userId);
	}



}
