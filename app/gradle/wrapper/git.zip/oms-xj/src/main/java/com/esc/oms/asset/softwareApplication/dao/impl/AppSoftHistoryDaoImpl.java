package com.esc.oms.asset.softwareApplication.dao.impl;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Repository;

import com.esc.oms.asset.softwareApplication.dao.IAppSoftHistoryDao;



@Repository
public class AppSoftHistoryDaoImpl extends BaseOptionDao implements IAppSoftHistoryDao {
	private static final String  TABLE_NAME="software_application_history";

	@Override
	public String getTableName() {
		return TABLE_NAME;
	}

	@Override
	public List<UTMap<String, Object>> getHistoryListBySoftId(Map param) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT ");
		sql.append(" ash.id,ash.version,ash.versionAddress,ash.scCodeAddress,ash.documentAddress,CONCAT(su.name,'/',su.code) as chargeName, ash.chargeNumber,ash.status,ash.introducation,ash.operation,ash.disableDate");
		sql.append(" FROM "+TABLE_NAME+" ash");
		sql.append(" LEFT JOIN sys_user su ON su.id = ash.chargeId ");
		sql.append(" WHERE ash.softwareId='"+param.get("softwareId").toString().trim()+"'");
		sql.append(" order by ash.createTime desc,ash.disableDate desc");
		return super.getListBySql(sql.toString());
	}
	
	@Override
	public List<UTMap<String, Object>> getHistoryListByDisableDate(Map param) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT ash.id,ash.version,ash.versionAddress,ash.scCodeAddress,ash.documentAddress, ash.chargeNumber,ash.status,ash.introducation,ash.operation,ash.disableDate");
		sql.append(" FROM "+TABLE_NAME+" ash");
		sql.append(" WHERE ash.disableDate='"+param.get("disableDate").toString().trim()+"' "
				+ " and ash.status!='3'");
		sql.append(" order by ash.createTime desc,ash.disableDate desc");
		return super.getListBySql(sql.toString());
	}

}
