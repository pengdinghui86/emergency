package com.esc.oms.asset.agreement.service;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;


public interface IAssetsAgreementInfoService extends IBaseOptionService{
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params);
	/**
	 * 导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public boolean leadingout(List data, HttpServletRequest request,HttpServletResponse response) throws Exception;
	/**
	 * 列表，分页（包括领用详单）
	 * @param pageBean
	 * @param param
	 */
	public void getPageInfoDetail(UTPageBean pageBean, Map param);
	
	public List<UTMap<String, Object>> getAgreementList(Map<String, Object> params);
	/**
	 * 手动发布合同预警信息
	 * @return
	 */
	public boolean generateWarn() ;

	/**
	 * 根据ids获取数据
	 * @param ids
	 * @return
	 */
	public List<UTMap<String, Object>> getListByIds(String ids);
}


