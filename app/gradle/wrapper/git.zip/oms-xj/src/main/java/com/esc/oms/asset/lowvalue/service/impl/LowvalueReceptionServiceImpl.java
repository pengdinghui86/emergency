package com.esc.oms.asset.lowvalue.service.impl;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.util.CellRangeAddress;
import org.esc.framework.EscPropertyHolder;
import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcelTamplate;
import org.esc.framework.utils.page.UTPageBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.asset.lowvalue.dao.ILowvalueReceptionDao;
import com.esc.oms.asset.lowvalue.dao.ILowvalueReceptionDetailDao;
import com.esc.oms.asset.lowvalue.service.ILowvalueInfoService;
import com.esc.oms.asset.lowvalue.service.ILowvalueReceptionDetailService;
import com.esc.oms.asset.lowvalue.service.ILowvalueReceptionService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;
import com.esc.oms.util.TaskModel;

@Service
@Transactional
public class LowvalueReceptionServiceImpl extends BaseOptionService implements ILowvalueReceptionService{

	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private ILowvalueReceptionDao dao;
	
	@Resource
	private ILowvalueInfoService infoService;
	
	@Resource
	private ILowvalueReceptionDetailService detailService;
	
	@Resource
	private ISysParamService sysParamService;
	
	@Resource
	private ISysUserService userService;
	
	@Resource
	private MessageSend messageService;
	
	@Resource
	private IUserTaskService userTaskService;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return dao;
	}

	/**
	 * 添加
	 * @param info
	 * @return
	 */
	@EscOptionLog(module=SystemModule.ASSETS_LOWVALUE_RECEPTION, opType=ESCLogOpType.INSERT, table="assets_lowvalue_reception", primaryKey="id={1.id}",option="新增名称为{1.name}的物品领用记录")
	public boolean add(Map info){
//		String status = ILowvalueReceptionDao.STATUS_NOT_SUBMIT;
//		String isSubmit = info.get("isSubmit")==null?"":String.valueOf(info.get("isSubmit"));
//		//保存并提交
//		if(!StringUtils.isEmpty(isSubmit)){	
//			status = ILowvalueReceptionDao.STATUS_NOT_CONFIRM;
//		}
		info.put("status",  ILowvalueReceptionDao.STATUS_NOT_CONFIRM);
		boolean addStatus = super.add(info);		
		if(addStatus){
			List detailList = (List) info.get("detailList");
			if(detailList!=null&&detailList.size()>0){
				String receptId = (String) info.get("id");
				for(int i=0;i<detailList.size();i++){
					Map map = (Map) detailList.get(i);
					map.put("receptId", receptId);
					map.put("confirmStatus", "0");
					detailService.add(map);							
				}
			}
//			if(ILowvalueReceptionDao.STATUS_NOT_CONFIRM.equals(status)){
				sendTaskAndMessage(info);//发送消息和待办
//			}
		}	
		return addStatus;			
	}
	
	private void sendTaskAndMessage(Map info){
		String taskUserIds = (String) info.get("receptUserId");
		//发送消息			
		String title = "物品领用【"+info.get("name")+"】确认提醒";
		String content = "物品领用：【"+info.get("name")+"】待您确认！";
		messageService.sendMessage(taskUserIds,title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
					
		//生成待办任务
		userTaskService.addTaskByUserId("物品领用【"+info.get("name")+"】待您确认",(String) info.get("id"), ILowvalueReceptionDao.TASK_RECEPTION_CONFIRM, TaskModel.lowvalueReception,taskUserIds);			
	}
	
	/**
	 * 修改
	 * @param info
	 * @return
	 */
	@EscOptionLog(module=SystemModule.ASSETS_LOWVALUE_RECEPTION, opType=ESCLogOpType.UPDATE, table="assets_lowvalue_reception", primaryKey="id={1.id}",option="修改名称为{1.name}的物品领用记录")
	public boolean updateById(Map info){
//		String isSubmit = info.get("isSubmit")==null?"":String.valueOf(info.get("isSubmit"));
//		//保存并提交
//		if(!StringUtils.isEmpty(isSubmit)){		
//			info.remove("isSubmit");
//			info.put("status", ILowvalueReceptionDao.STATUS_NOT_CONFIRM);
//			sendTaskAndMessage(info);//发送消息和待办
//		}			
		//被删除的领用物品详情
		List removeDetailList = (List) info.get("removeDetailList");
		if(removeDetailList!=null&&removeDetailList.size()>0){
			for(int i=0;i<removeDetailList.size();i++){
				Map map = (Map) removeDetailList.get(i);
				String id = (String) map.get("id");
				detailService.deleteById(id);
			}
		}
		List detailList = (List) info.get("detailList");
		if(detailList!=null&&detailList.size()>0){
			String receptId = (String) info.get("id");
			for(int i=0;i<detailList.size();i++){
				Map map = (Map) detailList.get(i);
				if(map.containsKey("id")){ //修改领用物品
					detailService.updateById(map);
				}else{ //新增领用物品
					map.put("receptId", receptId);					
					map.put("confirmStatus", "0");
					detailService.add(map);
				}				
			}
		}
		return super.updateById(info);	
	}
	
	/**
	 * 根据id 删除
	 * @param ids
	 * @return
	 */
	@EscOptionLog(module=SystemModule.ASSETS_LOWVALUE_RECEPTION, opType=ESCLogOpType.DELETE, table="assets_lowvalue_reception",primaryKey="{1}", option="删除名称为{name}的物品领用记录")	
	public boolean deleteById(String id){
		//删除领用详单
		detailService.deleteByReceptId(id);	
		//关闭待办任务
		userTaskService.finishTask(id, ILowvalueReceptionDao.TASK_RECEPTION_CONFIRM);
		
		return super.deleteById(id);
	}
	
	@EscOptionLog(module=SystemModule.ASSETS_LOWVALUE_RECEPTION, opType=ESCLogOpType.DELETES, table="assets_lowvalue_reception",option="删除名称为{name}的物品领用记录")		
	public boolean deleteByIds(String ids){
		//删除领用详单
		if(ids!=null&&ids.length()>0){
			String receptIds[] = ids.split(",");
			for(String receptId:receptIds){
				detailService.deleteByReceptId(receptId);	
			}	
		}		
		return super.deleteByIds(ids);
	}
	
	
	@Override
	public UTMap<String, Object> getById(String id) {
		UTMap<String, Object> rec = super.getById(id);
		Map<String,Object> param = new HashMap<String,Object>();
		param.put("receptId", id);
		List<UTMap<String, Object>> detailList = detailService.getListAll(param);
		rec.put("detailList", detailList);
		return rec;
	}
	
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map param) {
		dao.getPageInfo(pageBean, param);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params){
		return dao.getListAll(params);
	}
	
	/**
	 * 包括领用详单
	 * @param pageBean
	 * @param param
	 */
	@Override
	public void getPageInfoDetail(UTPageBean pageBean, Map param) {
		dao.getPageInfo(pageBean, param);
		List list = pageBean.getRows();
		if(list!=null&&list.size()>0){
			Map<String,Object> detailMap = this.getDetailMap(param);
			for(int i=0;i<list.size();i++){
				Map<String,Object> map = (Map<String, Object>) list.get(i);
				String receptId = (String) map.get("id");
				List<UTMap<String,Object>> detailList = (List<UTMap<String, Object>>) detailMap.get(receptId);
				map.put("detailList", detailList);
			}
		}
	}
	
	private Map<String,Object> getDetailMap(Map param){
		List<UTMap<String,Object>> list = detailService.getListAllByParentParam(param);
		Map<String,Object> detailMap = new HashMap<String,Object>();
		if(list!=null){
			for(UTMap<String,Object> map:list){
				String receptId = (String) map.get("receptId");
				List<UTMap<String,Object>> detailList = (List<UTMap<String, Object>>) detailMap.get(receptId);
				if(detailList==null){
					detailList = new ArrayList<UTMap<String,Object>>();
				}
				detailList.add(map);
				detailMap.put(receptId, detailList);
			}
		}
		return detailMap;
	}
	
	/**
	 * 根据条件查询，包括领用详单
	 * @param params
	 */
	@Override
	public List<UTMap<String, Object>> getListAllDetail(Map params){
		List<UTMap<String, Object>> list = dao.getListAll(params);
		if(list!=null&&list.size()>0){
			Map<String,Object> detailMap = this.getDetailMap(params);
			for(int i=0;i<list.size();i++){
				Map<String,Object> map = (Map<String, Object>) list.get(i);
				String receptId = (String) map.get("id");
				List<UTMap<String,Object>> detailList = (List<UTMap<String, Object>>) detailMap.get(receptId);
				map.put("detailList", detailList);
			}
		}
		return list;
	}
	
	/**
	 * 导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	@Override
	public boolean leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String path = EscPropertyHolder.instance.getProperty("excelOutTamplate.lowvalueReception");
		String[] fields = new String[] { 
				"row_num",
				ILowvalueReceptionDao.FIELD_NAME, 
				ILowvalueReceptionDao.FIELD_TYPE,
				ILowvalueReceptionDao.FIELD_RECEPT_USER_NAME,
				ILowvalueReceptionDao.FIELD_UNIT_NAME,
				ILowvalueReceptionDao.FIELD_RECEPT_DATE,
				ILowvalueReceptionDao.FIELD_REMARK,
				ILowvalueReceptionDao.FIELD_STATUS,
				ILowvalueReceptionDetailDao.FIELD_NAME,
				ILowvalueReceptionDetailDao.FIELD_CODE,
				ILowvalueReceptionDetailDao.FIELD_BRAND,
				ILowvalueReceptionDetailDao.FIELD_MODEL,
				ILowvalueReceptionDetailDao.FIELD_MEASURE,
				ILowvalueReceptionDetailDao.FIELD_UNITPRICE,
				ILowvalueReceptionDetailDao.FIELD_RECEPT_NUM
				};
		// 获取导出文件名称
		int l = path.lastIndexOf("/");
		int j = path.lastIndexOf("--");
		String fileName = "";
		String title = "";
		if (j > 0) {
			fileName = path.substring(j + 2);
			title = fileName;
			path = path.substring(0, j);
			fileName = fileName + path.substring(path.lastIndexOf("."));
		} else {
			fileName = path.substring(l + 1);
			title = fileName.substring(0, fileName.lastIndexOf("."));
		}
		// 创建模板对象
		UTExcelTamplate tamplate = UTExcelTamplate.getInstance();
		// 加载模板
		tamplate.readTemplateByClasspath(path);
		// 模板常量参数赋值
		Map<String, String> map = new HashMap<String, String>();
		map.put("title", title);
		map.put("time", "日期：" + UTDate.getCurDate());
		tamplate.replaceFinalData(map);
		
		//替换下拉的值
		Map<String, String> fieldAndParamType = new HashMap<String, String>();
		fieldAndParamType.put(ILowvalueReceptionDao.FIELD_TYPE, "lowvalueType");
		fieldAndParamType.put(ILowvalueReceptionDao.FIELD_STATUS, "lowvalueReceptionStatus");
		sysParamService.changeParamData(data, fieldAndParamType);	
				
		int startDataRow = 2;
		// 循环填充excel
		for(int num=0;num<data.size();num++){
			UTMap<String, Object>  utmap = (UTMap<String, Object>) data.get(num);	
			List<UTMap<String, Object>> classifys = (List<UTMap<String, Object>>) utmap.get("detailList");		
			if(classifys==null){
				classifys = new ArrayList<UTMap<String, Object>>();
			}
			
			for (UTMap<String, Object> info : classifys) {
				tamplate.createNewRow();
				tamplate.createCell(num + 1); // 第一列是序号
			
				for (int ci = 1; ci <= 7; ci++){
					String f = fields[ci];
					String v = utmap.get(f) != null ? utmap.get(f).toString() : "";
//					//类别转换
//					if(f.equals(ILowvalueReceptionDao.FIELD_TYPE)){
//						v = getTypeDesc(v);
//					}						
//					//状态转换	
//					if(f.equals(ILowvalueReceptionDao.FIELD_STATUS)){
//						v = getStatusDesc(v);
//					}
					//时间转换	
					if(f.equals(ILowvalueReceptionDao.FIELD_RECEPT_DATE)){
						v = UTDate.getDateStr(v, "yyyy-MM-dd");
						v = CommonUtils.replaceAll(v, "-", "/");
					}
					tamplate.createCell(v);					
				}
				//分类和级别
				for (int i = 8; i < fields.length; i++) {
					String f = fields[i];
					String v = info.get(f) != null ? info.get(f).toString() : "";
					tamplate.createCell(v);
				}
			}
			//合并单元格，开始行到结束行，开始单元格到结束单元格
			int endDataRow = startDataRow + classifys.size() - 1;
			for (int ci = 0; ci <= 7; ci++){
				tamplate.addMergedRegion(new CellRangeAddress(
						startDataRow, //first row (0-based)  from 行     
						endDataRow, //last row  (0-based)  to 行     
						ci, //first column (0-based) from 列     
						ci //last column  (0-based)  to 列     
	        	));
			}	
			startDataRow = endDataRow + 1;
		}		
		tamplate.setSheet(new String[]{title});
		
		try {
			fileName = new String( fileName.getBytes("GBK"), "ISO8859-1" ) ;
		} catch (UnsupportedEncodingException e) {
			logger.error("UnsupportedEncodingException",e);
		}
		try {
			OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
			response.addHeader("Content-Disposition", "attachment;filename=" + fileName);
			response.setContentType("application/octet-stream");
			tamplate.writeToStream(toClient);
		} catch (IOException e) {
			logger.error("IOException",e);
		}
		return true;
	}

//	public static String getTypeDesc(String type){
//		if(StringUtils.isEmpty(type)){
//			return "";
//		}else{
//			if("1".equals(type)){
//				return "个人";
//			}else if("2".equals(type)){
//				return "部门";
//			}else{
//				return "";
//			}
//		}	
//	}
	
//	public static String getStatusDesc(String status){
//		if(StringUtils.isEmpty(status)){
//			return "";
//		}else{	
//			if("0".equals(status)){
//				return "未确认";
//			}else if("1".equals(status)){
//				return "确认中";
//			}else if("2".equals(status)){
//				return "已确认";
//			}else{
//				return "";
//			}
//		}	
//	}
	
}