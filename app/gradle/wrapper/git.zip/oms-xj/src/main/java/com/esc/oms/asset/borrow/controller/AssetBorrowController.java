package com.esc.oms.asset.borrow.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.asset.borrow.service.IAssetBorrowService;
import com.esc.oms.asset.collar.service.IAssetCollarService;
import com.esc.oms.asset.overview.dao.IAssetsTrackInfoDao;
import com.esc.oms.asset.overview.service.IAssetsTrackInfoService;
import com.esc.oms.asset.physical.service.IAssetPhysicalService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.RoleUtils;
import com.esc.oms.util.TaskModel;
@Controller
@RequestMapping("assetBorrow")
public class AssetBorrowController extends BaseOptionController {


	@Resource
	private IAssetBorrowService assetBorrowService;
	
	@Resource
	private ISysUserService userService;
	
	@Resource
	private MessageSend messageService;
	
	@Resource
	private IUserTaskService userTaskService;
	
	@Resource
	private IAssetPhysicalService assetPhysicalService;
	
	@Resource
	private ISysUserService sysUserService;
	
	@Resource
	private IAssetsTrackInfoService assetsTrackInfoService;
	
	@Resource
	private IAssetCollarService assetCollarService;
	
	@Override
	public IBaseOptionService optionService() {
		return assetBorrowService;
	}
	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			assetBorrowService.getPageInfo(pageBean, params);
			List<Map<String, Object>> list = pageBean.getRows();
			if(null != list && list.size() > 0 ){
				for (Map<String, Object> map : list) {
					Map<String, Object> info = new HashMap<String, Object>();
					info.put("borrowId", map.get("id"));
					boolean allAllocation = true;//全部分配完毕
					boolean allReturn = true;//全部归还完毕
					boolean allConfirm = true;//全部确认完毕
					List<UTMap<String, Object>> aList = assetBorrowService.getAssetAllocationListMaps(info);
					if(null != aList && !aList.isEmpty()){
						for (UTMap<String, Object> at : aList) {
							Integer status = (Integer) at.get("detailStatus");
							if (null == status) {//存在为null的就表示还存在未分配的资产
								allAllocation = false;
							}else if (1 == status) {//存在为1的就表示还存在未归还的资产
								allReturn = false;
							}else if (2 == status) {//存在为2的就表示还存在未确认的资产
								allConfirm = false;
							}
						}
					}
					map.put("allAllocation", allAllocation);
					map.put("allReturn", allReturn);
					map.put("allConfirm", allConfirm);
					
					if((Integer)map.get("borrowType") == 1){
						map.put("borrowType", "个人");
					}else{
						map.put("borrowType", "部门");
					}
				}
			}
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	/**
	 * 新增，需要返回一个给前台的其他标签
	 * @param info
	 * @return
	 */
	@RequestMapping(value="add")
	@ResponseBody
	public Map<String, Object> add(@RequestBody  Map<String, Object> map1){
		Map<String,Object> cloneMap = CommonUtils.clone(map1);
		
		boolean flag = false;
		boolean submitStatus = (Boolean)cloneMap.get("submitStatus");
		try{
			//先验证资产列表里面的资产是否已经被占用了
			List<Map<String, Object>> assetAllocationList = (List<Map<String, Object>>)cloneMap.get("assetAllocationList");
			for (Map<String, Object> map : assetAllocationList) {
				List<UTMap<String, Object>> ut = assetBorrowService.getBorrowByStatusList(String.valueOf(map.get("assetsId")));
				if (null != ut && !ut.isEmpty()) {
					Map<String, Object> assetInfo = assetPhysicalService.getById(String.valueOf(map.get("assetsId")));
					cloneMap.put("success", false);
					String codeNum = (String) assetInfo.get("codeNum");
					if (StringUtils.isNotEmpty(codeNum)) {
						codeNum = "/" + codeNum;
					}else {
						codeNum = "";
					}
					cloneMap.put("msg", "资产【" + assetInfo.get("name")+codeNum+"】已被占用！");
					return cloneMap;
				}
			}
			flag = optionService().add(cloneMap);
			if(flag && submitStatus){
				sendMessage(cloneMap);
			}
			//添加借用资产
			if (flag) {
				for (Map<String, Object> map : assetAllocationList) {
					Map<String, Object> newInfo = new HashMap<String, Object>();
					newInfo.put("applyId", cloneMap.get("id"));
					newInfo.put("assetsId", map.get("id"));
					assetBorrowService.addAssetAllocation(newInfo);
				}
			}
			
			cloneMap.put("success", true);
			cloneMap.put("msg", "操作成功！");
    	}catch(Exception e){
    		logger.error("Exception", e);
    		cloneMap.put("success", false);
    		cloneMap.put("msg", "操作失败！");
    	}
       return cloneMap;
	}
	
	/**
	 * 修改
	 * @param info
	 * @return
	 */
	@RequestMapping(value="update")
	@ResponseBody
	public String update(@RequestBody  Map<String, Object> map1){
		Map<String,Object> cloneMap = CommonUtils.clone(map1);
		
		boolean flag = false;
		boolean submitStatus = (Boolean)cloneMap.get("submitStatus");
		try{
			String id = (String) cloneMap.get("id");
			//先验证资产列表里面的资产是否已经被占用了
			List<Map<String, Object>> assetAllocationList = (List<Map<String, Object>>)cloneMap.get("assetAllocationList");
			for (Map<String, Object> map : assetAllocationList) {
				List<UTMap<String, Object>> uts = assetBorrowService.getBorrowByStatusList(String.valueOf(map.get("assetsId")));
				if (null != uts && !uts.isEmpty()) {
					for (UTMap<String, Object> ut : uts) {
						String applyId = (String) ut.get("applyId");
						if (!StringUtils.equals(id, applyId)) {
							Map<String, Object> assetInfo = assetPhysicalService.getById(String.valueOf(map.get("assetsId")));
							String codeNum = (String) assetInfo.get("codeNum");
							if (StringUtils.isNotEmpty(codeNum)) {
								codeNum = "/" + codeNum;
							}else {
								codeNum = "";
							}
							return UTJsonUtils.getJsonMsg(false, "资产【" + assetInfo.get("name")+codeNum+"】已被占用！");
						}
					}
				}
			}
			flag = optionService().updateById(cloneMap);
			if(flag && submitStatus){
				sendMessage(cloneMap);
			}
			//添加借用资产
			if (flag) {
				String applyId = (String) cloneMap.get("id");
				//更新的时候先删除借用资产列表，再进行添加
				assetBorrowService.deleteAssetAllocationByBorrowId(applyId);
				for (Map<String, Object> map : assetAllocationList) {
					Map<String, Object> newInfo = new HashMap<String, Object>();
					newInfo.put("applyId", applyId);
					newInfo.put("assetsId", map.get("assetsId"));
					assetBorrowService.addAssetAllocation(newInfo);
				}
			}
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "操作成功");
	}

    
    /**
	 * 根据id查询
	 * @param param
	 * @return
	 */
	@RequestMapping(value="getById")
	@ResponseBody
	public UTMap<String, Object> defgetById(@RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = null;
    	try{
    		map = optionService().getById(param.get("id").toString());
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return map;
	}
	
	@RequestMapping(value="addAssetAllocation",method=RequestMethod.POST)  
	@ResponseBody
	public Map<String, Object> addAssetAllocation(@RequestBody Map<String,Object> map){  
		String assetsId = (String)map.get("assetsId");
		UTMap<String, Object> assetInfo = assetCollarService.getAssetByAssetId(assetsId);
		map.put("assetsName", assetInfo.get("assetsNameCode"));
		map.put("assetsType", assetInfo.get("assetsType"));
		map.put("assetsSubType", assetInfo.get("assetsSubType"));
		
		String grantUserId = (String) map.get("grantUserId");
		if (StringUtils.isNotEmpty(grantUserId)) {
			UTMap<String, Object> userMap = sysUserService.getById(grantUserId);
			map.put("grantUser", userMap);
		}else {
			map.put("grantUser", new UTMap<String, Object>());
		}
		map.put("success", true);
		map.put("msg", "操作成功！");
	/*	boolean flag = false;
		try {
				map.put("applyId", borrowId);
				if(null != ut){
					map.put("returnTime", (String)ut.get("endDate"));
				}
				flag = assetBorrowService.addAssetAllocation(map);
				map.put("success", true);
				map.put("msg", "操作成功！");
		} catch (Exception e) {
			logger.error("Exception", e);
			map.put("success", false);
			map.put("msg", "操作失败！");
		}*/
		

		return map;
	}
	
	@RequestMapping(value="updateAssetAllocation")
	 @ResponseBody
	 public String updateAssetAllocation(@RequestBody Map<String, Object> param){
		try {
			Map<String, Object> info = new HashMap<String, Object>();
			info.put("id", param.get("id"));
			info.put("grantUserId", param.get("grantUserId"));
			info.put("grantTime", param.get("grantTime"));
			assetBorrowService.updateAssetAllocation(info);
		}catch (Exception e) {
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "操作失败");
		}
		return UTJsonUtils.getJsonMsg(true, "操作成功");
	}
	
	
	@RequestMapping(value="confirmAssetAllocation",method=RequestMethod.POST)  
	@ResponseBody
	public Map<String, Object> confirmAssetAllocation(@RequestBody Map<String,Object> map){  
		String borrowId = (String) map.get("borrowId");
		 UTMap<String, Object> utMap = null;
		boolean flag = false;
		try {
			// ====修改借用详细列表状态========
			flag = assetBorrowService.updateAllocationStatusById(map.get("id")
					.toString(), "1", String
					.valueOf(map.get("borrowId")));
			
			utMap = optionService().getById(borrowId);
			if(flag){
				if(null != utMap  && ((Integer)utMap.get("status") != 3) && ((Integer)utMap.get("status") != 4)){
					utMap.put("status", 3);
					optionService().updateById(utMap);
				}

			// ====添加资产轨迹---资产分配=====
			UTMap<String, Object> ut = new UTMap<String, Object>();
			UTMap<String, Object> assets = new UTMap<String, Object>();
			if (null != utMap) {
				ut.put("assetsId", map.get("assetsId"));
				ut.put("userId", utMap.get("createUserId"));
				ut.put("departId", utMap.get("borrowUnit"));
				if (null != sysUserService.getById(String.valueOf(utMap
						.get("createUserId")))) {
					UTMap<String, Object> user = sysUserService.getById(String
							.valueOf(utMap.get("createUserId")));
					ut.put("changeRemark", user.get("orgName").toString()
							+ user.get("name").toString()
							+ IAssetsTrackInfoDao.FIELD_ASSETSBORROW);
				}
				ut.put("type", 1);
				ut.put("changeType", "借用");
				ut.put("changeTime", map.get("grantTime"));
				assetsTrackInfoService.add(ut);

				// ====修改资产责任人====
				assets.put("id", map.get("assetsId"));
				assets.put("resUserId", utMap.get("createUserId"));
				assets.put("resDepartId", utMap.get("borrowUnit"));
				assets.put("assetStatus", "2");
				assetPhysicalService.updateById(assets);
				
				
				//====如果出库为空则当前时间为出库时间====
				assetPhysicalService.updateOutdateById(String.valueOf(map.get("assetsId")));
			}
			// =====发送代办和消息=====
			UTMap<String, Object> assetsInfo = assetPhysicalService.getById((String) map.get("assetsId"));
			if (null != assetsInfo) {
				String title = "资产借用申请【" + utMap.get("title") + "/"
						+ utMap.get("code") + "】分配提醒";
				String content = "您的借用申请【" + utMap.get("title") + "/"
						+ utMap.get("code")
						+ "】已分配，请知悉！详情请进入系统查看 ";
				messageService.sendMessage((String) utMap.get("createUserId"),
						title, content, MessageSend.Type.MAIL,
						MessageSend.Type.SYSTEM);
			}
			userTaskService.finishTask(borrowId, "实物资产借用");
			map.put("status", utMap.get("status"));
		}
			map.put("success", true);
			map.put("msg", "操作成功！");
		} catch (Exception e) {
			logger.error("Exception", e);
			map.put("success", false);
			map.put("msg", "操作失败！");
		}
		return map;
	}
	 
	 @RequestMapping(value="deleteAssetAllocation")
	 @ResponseBody
	 public String deleteAssetAllocation(@RequestBody Map<String, Object> param){
		try {
			assetBorrowService.deleteAssetAllocationById(param.get("id").toString());
		}catch (Exception e) {
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "删除失败");
		}
		return UTJsonUtils.getJsonMsg(true, "删除成功");
	}
	
	/**
	 * 根据id查询
	 * @param param
	 * @return
	 */
	@RequestMapping(value="getAssetAllocationByBorrowId")
	@ResponseBody
	public List<UTMap<String, Object>> getAssetAllocationByBorrowId(@RequestParam  Map<String, Object> param){		
		List<UTMap<String,Object>> assetAllocationList = null;
	   	try{
	   		assetAllocationList = assetBorrowService.getAssetAllocationListMaps(param);
			}catch(Exception e){
				logger.error("Exception", e);
				return new ArrayList<UTMap<String, Object>>();
	   	}
	   	return assetAllocationList;
	}
	
	@RequestMapping(value="getAssetAllocationPage")
	@ResponseBody
	public UTPageBean getAssetAllocationPage(@RequestParam  Map<String, Object> param){
		UTPageBean pageBean = CommonUtils.getPageBean(param);
	   	assetBorrowService.getAssetAllocationPage(param, pageBean);
	   	return pageBean;
	}

	@RequestMapping(value="getAssetAllocationByAppIdPage")  
   @ResponseBody
   public UTPageBean getAssetAllocationByAppIdPage(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			assetBorrowService.getAssetAllocationPageInfo(pageBean, params);
		}catch(Exception e){
   		logger.error("Exception", e);
   	}
      return pageBean;
   }
	
	@RequestMapping(value="confirmAllocation",method=RequestMethod.POST)  
	@ResponseBody
	public Map<String, Object> confirmAllocation(@RequestBody Map<String,Object> map){  
		try {	
			String status = map.get("status").toString();
			List<UTMap<String,Object>> uts = null;
			String ids = "";
			if("3".equals(status)){
				String[] allocationIds = map.get("ids").toString().split(",");
				for (String allocationId : allocationIds) {
					ids += "'"+allocationId+"',";
				}
				ids = ids.substring(0,ids.length()-1);
				 uts = assetBorrowService.getBorrowDetailByIds(ids);
				 if(null != uts && uts.size() > 0){
						map.put("success", false);
						map.put("msg", "有未归还的资产，请核对！");
						return map;
					}
			}
			assetBorrowService.updateAllocationStatusById(map.get("ids").toString(),status,map.get("borrowId").toString());
			if (StringUtils.equals("3", status)) {//实物资产归还确认的时候
				//完成待办
				String[] assetIds = map.get("ids").toString().split(",");
				for (String assetId : assetIds) {
					userTaskService.finishTask(assetId + map.get("borrowId"),  "实物资产归还确认");
				}
			}
			//如果所有的资产都已经归回确认了，就自动完成完成确认操作
			List<UTMap<String,Object>> assetList = assetBorrowService.getBorrowDetailByIdAndStatus((String)map.get("borrowId"));
			if(null == assetList || assetList.isEmpty()){
				UTMap<String, Object> ut = new UTMap<String,Object>();
				ut.put("status", 5);
				ut.put("id", (String)map.get("borrowId"));
				assetBorrowService.updateById(ut);
				assetBorrowService.updateAllocationStatusByBorrowId((String)map.get("borrowId"), "3");
			}
			
			UTMap<String,Object> ut = optionService().getById((String)map.get("borrowId"));
			if(null != ut){
				map.put("status", ut.get("status"));
			}
			map.put("success", true);
			map.put("msg", "操作成功！");
		} catch (Exception e) {
			logger.error("Exception", e);
			map.put("success", false);
			map.put("msg", "操作失败！");
		}
		return map;
	}
	 
	private void sendMessage(Map<String,Object> map){
		Map<String,Object> param = new HashMap<String,Object>();				
		param.put("signature", RoleUtils.ASSET_MANAGER);
		String taskUserIds = userService.getUserIds(param);	
		String title = "资产借用申请【"+map.get("title")+"/"+map.get("code")+"】处理提醒";
		String content = "资产借用申请：【"+map.get("title")+"/"+map.get("code")+"】已提交，请进入系统查看并处理！ ";
		messageService.sendMessage(taskUserIds,title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
		
		//生成待办任务
//		UTMap<String,Object> utMap = super.getById(businessRecordId);
		userTaskService.addTaskByRole("资产借用申请：【"+map.get("title")+"/"+map.get("code")+"】已提交，待您进行处理", (String)map.get("id"), "实物资产借用", TaskModel.AssetBorrow, RoleUtils.ASSET_MANAGER);
	}
	
	@RequestMapping(value="completeConfirm",method=RequestMethod.POST)  
	@ResponseBody
	public String completeConfirm(@RequestBody Map<String,Object> map){  
		try {
				List<UTMap<String,Object>> uts = assetBorrowService.getBorrowDetailByIdAndStatus((String)map.get("id"));
				if(null != uts && uts.size() > 0){
					return UTJsonUtils.getJsonMsg(false, "有未归还或者未确认的资产，请核对");
				}else{
					UTMap<String, Object> ut = new UTMap<String,Object>();
					ut.put("status", (Integer)map.get("status"));
					ut.put("id", (String)map.get("id"));
					assetBorrowService.updateById(ut);
					assetBorrowService.updateAllocationStatusByBorrowId((String)map.get("id"), "3");
				}
//				assetBorrowService.updateAllocationStatusById(map.get("ids").toString(),map.get("status").toString(),map.get("borrowId").toString());

		} catch (Exception e) {
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "操作失败");
		}
		return UTJsonUtils.getJsonMsg(true, "操作成功");
	}
	
	@RequestMapping(value="getBorrowAsset")  
    @ResponseBody
    public UTPageBean getBorrowAsset(@RequestParam Map<String, Object> params){ 
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		assetBorrowService.getAssetsList(params, pageBean);
		return pageBean;
    }
	
	@RequestMapping("deleteAssetAllocationById")
	@ResponseBody
	public Map<String, Object> deleteAssetAllocationById(@RequestBody Map<String, Object> param){
		String id = (String) param.get("id");
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("success", true);
		result.put("msg", "操作成功！");
		boolean flag = assetBorrowService.deleteAssetAllocationById(id);
		if (!flag) {
			result.put("success", false);
			result.put("msg", "操作失败！");
		}
		return result;
	}
}