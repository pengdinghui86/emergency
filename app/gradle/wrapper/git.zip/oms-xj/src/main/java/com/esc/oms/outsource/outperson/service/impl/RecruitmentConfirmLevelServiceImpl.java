package com.esc.oms.outsource.outperson.service.impl;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.workflow.service.IWorkflowCallback;
import org.esc.framework.workflow.service.IWorkflowCode;
import org.esc.framework.workflow.service.IWorkflowEngine;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.outperson.dao.IRecruitmentConfirmLevelDao;
import com.esc.oms.outsource.outperson.dao.IRecruitmentResumeDao;
import com.esc.oms.outsource.outperson.service.IRecruitmentConfirmLevelService;
import com.esc.oms.util.RoleUtils;
import com.esc.oms.util.TaskModel;

@Service
@Transactional
public class RecruitmentConfirmLevelServiceImpl 
	extends BaseOptionService 
	implements IRecruitmentConfirmLevelService, IWorkflowCallback{

	@Resource
	private IRecruitmentConfirmLevelDao dao;
	
	@Resource
	private IRecruitmentResumeDao recruitmentResumeDao;
	
	@Resource
	private IWorkflowEngine workflowEngine;
	
	@Resource
	private IUserTaskService userTaskService;
	
	@Resource
	private ISysUserService userService;
	
	@Resource
	private MessageSend messageSend;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		// TODO Auto-generated method stub
		return dao;
	}
	
	public String workflowCode() {
		return IWorkflowCode.RECRUITMENT_CONFIRM_LEVEL;
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean,Map param) {
		dao.getPageInfo(pageBean, param);
	}
	
	@Override
	public UTMap<String, Object> getInfoById(String id){
		UTMap<String, Object> info = dao.getInfoById(id);
		if (null != info && !info.isEmpty()) {
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("recruitmentResumeId", id);
			info.put("interviewList", recruitmentResumeDao.getInterviewByInfo(param));
			String managerReviewResult = (String) info.get("managerReviewResult");
			if (StringUtils.isEmpty(managerReviewResult)) {
				info.put("managerReviewResult", info.get("interviewResult"));
			}
		}
		return info;
	}

	@Override
	public boolean confirmLevel(Map<String, Object> param) {
		boolean flag = dao.updateById(param);
		String workflowStatus = (String) param.get("workflowStatus");
		if (StringUtils.equals("1", workflowStatus)) {
			String recordId = (String) param.get("id");
			try {
				//启动流程
				runInstanceId(recordId);
			}catch(Exception e){
				throw new EscServiceException("流程启动失败" + e.getMessage());
			}
			
		}
		return flag;
	}
	
	// 启动流程实例设置
	private void runInstanceId(String recordId){
		//启动流程实例
		UTMap<String, Object> info = dao.getInfoById(recordId);
		String unit = (String) info.get("applyDepartId");
		String workflowInstanceId = workflowEngine.runInstance(IWorkflowCode.RECRUITMENT_CONFIRM_LEVEL, recordId, unit);//如果没有配置流程，则直接调用onFinish接口
		Map<String, Object> map = new HashMap<String, Object>();
		if (StringUtils.isEmpty(workflowInstanceId)) {
			map.put("workflowStatus", "3");
		}else {
			map.put("workflowStatus", "1");
			map.put("processId", workflowInstanceId);
		}
		map.put("id", recordId);
		this.updateById(map);
	}

	@Override
	public void onReject(String businessRecordId) {
		Map<String, Object> info = new HashMap<String, Object>();
		info.put("id", businessRecordId);
		info.put("workflowStatus", "4");
		dao.updateById(info);
		
		UTMap<String, Object> reInfo = dao.getById(businessRecordId);
		String userName = "";
		if (null != reInfo && !reInfo.isEmpty()) {
			userName = (String) reInfo.get("name");
		}
		if (StringUtils.isEmpty(userName)) {
			return;
		}
		//被驳回之后发送消息给外包管理员
		Map<String,Object> param = new HashMap<String,Object>();				
		param.put("signature", RoleUtils.OUTSOURCE_MANAGER);
		String userIds = userService.getUserIds(param);	
		messageSend.sendMessage(userIds, 
				"人员【"+userName+"】定级申请驳回提醒", 
				"人员【"+userName+"】的定级申请已被驳回，请知悉！详情请进入系统查看", MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
	}

	@Override
	public void onFinish(String businessRecordId) {
		Map<String, Object> info = new HashMap<String, Object>();
		info.put("id", businessRecordId);
		info.put("workflowStatus", "3");
		dao.updateById(info);
	}

	@Override
	public void onTerminate(String businessRecordId) {
		Map<String, Object> info = new HashMap<String, Object>();
		info.put("id", businessRecordId);
		info.put("workflowStatus", "5");
		dao.updateById(info);
		
		UTMap<String, Object> reInfo = dao.getById(businessRecordId);
		String userName = "";
		if (null != reInfo && !reInfo.isEmpty()) {
			userName = (String) reInfo.get("name");
		}
		if (StringUtils.isEmpty(userName)) {
			return;
		}
		Map<String,Object> param = new HashMap<String,Object>();				
		param.put("signature", RoleUtils.OUTSOURCE_MANAGER);
		String userIds = userService.getUserIds(param);	
		messageSend.sendMessage(userIds, 
				"人员【"+userName+"】定级申请终止提醒", 
				"人员【"+userName+"】的定级申请已被终止，请知悉！详情请进入系统查看", MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
	}

	@Override
	public void sendTask(String workflowName, String businessRecordId, String nodeName, String userId) {
		// TODO Auto-generated method stub
		UTMap<String, Object> info = dao.getById(businessRecordId, "name");
		String userName = "";
		if (null != info && !info.isEmpty()) {
			userName = (String) info.get("name");
		}
		if (StringUtils.isEmpty(userName)) {
			return;
		}
		userTaskService.addTaskByUserId("人员【"+userName+"】定级申请待您审批", businessRecordId, nodeName, TaskModel.recruitmentConfirmLevel, userId);
	}

	@Override
	public void optionNode(String workflowCode, String businessRecordId, String nodeName, String linkName) {
		Map<String, Object> info = new HashMap<String, Object>();
		info.put("id", businessRecordId);
		info.put("workflowStatus", "2");
		dao.updateById(info);
	}

	@Override
	public void getAlreadyPageInfo(UTPageBean pageBean, Map<String, Object> params) {
		// TODO Auto-generated method stub
		dao.getAlreadyPageInfo(pageBean, params);
	}
}
