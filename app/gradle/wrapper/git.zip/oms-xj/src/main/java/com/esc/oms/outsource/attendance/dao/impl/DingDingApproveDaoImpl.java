package com.esc.oms.outsource.attendance.dao.impl;

import com.esc.oms.outsource.attendance.dao.IDingDingApproveDao;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
@Repository
public class DingDingApproveDaoImpl extends BaseOptionDao implements IDingDingApproveDao {
    @Override
    public String getTableName() {
        return "dingding_approve";
    }

    @Override
    public List<UTMap<String, Object>> getListMap(Map<String, Object> param) {
        StringBuilder sql = new StringBuilder();
        sql.append("select * from "+getTableName()+" where 1=1 ");
        if(param != null){
            String ids = (String) param.get("ids");
            String startTime = (String) param.get("startTime");
            String endTime = (String) param.get("endTime");
            String notDone = (String) param.get("notDone");
            String isSynchronized = (String) param.get("isSynchronized");
            if(StringUtils.isNotEmpty(ids)){
                sql.append(" and processInstanceId in("+ids+")");
            }
            if(StringUtils.isNotEmpty(startTime)){
                sql.append(" and createTime >= '"+startTime+"'");
            }
            if(StringUtils.isNotEmpty(endTime)){
                sql.append(" and createTime <='"+endTime+"'");
            }
            if(StringUtils.isNotEmpty(notDone)){//查找未完成的
                sql.append(" and (status = 'RUNNING' or status = 'NEW')");
            }
            if(StringUtils.isNotEmpty(isSynchronized)){
                sql.append(" and isSynchronized = '"+isSynchronized+"')");
            }
        }
        return this.getListBySql(sql.toString());
    }

    @Override
    public List<UTMap<String, Object>> getUnSynchronized() {
        StringBuilder sql = new StringBuilder();
        sql.append(" select da.*,opl.userId,opl.supplierId,opl.supplierName from dingding_approve da  ");
        sql.append(" left join outsource_person_list opl on di.dingDingId = opl.dingDingId where da.isSynchronized=0 ");
        return this.getListBySql(sql.toString());
    }

    @Override
    public List<UTMap<String, Object>> getDetailListMap(Map<String, Object> param) {
        StringBuilder sql = new StringBuilder();
        sql.append(" select da.*, opl.name,CONCAT(opl.name,'/',u.code) nameAndCode,opl.supplierId,sbi.name supplierName," );
        sql.append(" REPLACE( u.orgName,'!','/')  orgName,u.orgId,opl.userId ");
         sql.append( " from  dingding_approve da");
        sql.append(" left join outsource_person_list opl on da.originatorUserId = opl.dingDingId ");
        sql.append(" left join supplier_base_info sbi on sbi.id=opl.supplierId ");
        sql.append("	LEFT JOIN sys_user u ON opl.userId=u.id ");
        if(param != null){
            String ids = (String) param.get("ids");
            String startTime = (String) param.get("startTime");
            String endTime = (String) param.get("endTime");
            String notDone = (String) param.get("notDone");
            String isSynchronized = (String) param.get("isSynchronized");
            if(StringUtils.isNotEmpty(ids)){
                sql.append(" and da.processInstanceId in("+ids+")");
            }
            if(StringUtils.isNotEmpty(startTime)){
                sql.append(" and da.createTime >= '"+startTime+"'");
            }
            if(StringUtils.isNotEmpty(endTime)){
                sql.append(" and da.createTime <='"+endTime+"'");
            }
            if(StringUtils.isNotEmpty(notDone)){//查找未完成的
                sql.append(" and (da.status = 'RUNNING' or da.status = 'NEW')");
            }
            if(StringUtils.isNotEmpty(isSynchronized)){
                sql.append(" and da.isSynchronized = '"+isSynchronized+"')");
            }
        }
        return this.getListBySql(sql.toString());
    }

    @Override
    public boolean deleteByTime(String startTime, String endTime, String dingDingIds) {
        StringBuilder sql = new StringBuilder();
        sql.append(" delete from dingding_approve where createTime >= '"+startTime+"' and createTime<= '"+endTime+"' ");
        sql.append(" and originatorUserId in ("+dingDingIds+")");
        return this.executeUpdate(sql.toString());
    }
}
