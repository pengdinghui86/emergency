package com.esc.oms.outsource.outperson.controller;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.workflow.service.IWorkflowCode;
import org.esc.framework.workflow.service.IWorkflowEngine;
import org.esc.framework.workflow.utils.bpmn.Instance;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.outsource.outperson.service.IApplyCommonService;
import com.esc.oms.outsource.outperson.service.IApplyEnterService;
import com.esc.oms.util.CommonUtils;

import net.sf.json.JSONObject;

/**
 * 入场申请 控制器
 * @author smq
 * @date   2016-7-9 上午10:37:30
 */
@Controller
@RequestMapping("outsource/person/enter")
public class ApplyEnterController extends AbstractApplyController {

	@Resource
	private IApplyEnterService enterService;
	@Resource
	private ISysUserService userService;
	
	@Resource
	private IWorkflowEngine workflowEngine;
	
	@Override
	public IApplyCommonService applyService() {
		return enterService;
	}
	

	//唯一项验证验证
	@RequestMapping("isExitItem")
	@ResponseBody
	public JSONObject isExitItem(@RequestParam Map<String, Object> param){
		String longName=param.get("loginName")!=null?param.get("loginName").toString():"";
		String idCode=param.get("idCode")!=null?param.get("idCode").toString():"";
		String mobilePhone = (String) param.get("mobilePhone");
		
		String longName1 = param.get("loginName1")!=null?param.get("loginName1").toString():"";
		String idCode1 = param.get("idCode1")!=null?param.get("idCode1").toString():"";
		String mobilePhone1 = (String) param.get("mobilePhone1");
		
		if(StringUtils.isNotEmpty(longName)){
			Map<String, Object> map=new HashMap<String, Object>();
			map.put("loginName",longName);
			if(userService.isExist(map)){
				return UTJsonUtils.getMsgJson(false, "请保证登陆名唯一");
			}
		}
		
		
		if(StringUtils.isNotEmpty(longName)){
			Map<String, Object> map=new HashMap<String, Object>();
			map.put("loginName",longName);
			if(enterService.isExist(map)){
				return UTJsonUtils.getMsgJson(false, "请保证登陆名唯一");
			}
		}

		if(StringUtils.isNotEmpty(idCode)){
			Map<String, Object> map=new HashMap<String, Object>();
			map.put("idCode",idCode);
			if(userService.isExist(map)){
				return UTJsonUtils.getMsgJson(false, "身份证号码唯一");
			}
		}
		
		if(StringUtils.isNotEmpty(idCode)){
			Map<String, Object> map=new HashMap<String, Object>();
			map.put("idCode",idCode);
			if(enterService.isExist(map)){
				return UTJsonUtils.getMsgJson(false, "身份证号码唯一");
			}
		}
		
		if(StringUtils.isNotEmpty(mobilePhone)){
			Map<String, Object> map=new HashMap<String, Object>();
			map.put("phone",mobilePhone);
			if(userService.isExist(map)){
				return UTJsonUtils.getMsgJson(false, "联系电话唯一");
			}
		}
		
		if(StringUtils.isNotEmpty(mobilePhone)){
			Map<String, Object> map=new HashMap<String, Object>();
			map.put("mobilePhone",mobilePhone);
			if(enterService.isExist(map)){
				return UTJsonUtils.getMsgJson(false, "联系电话唯一");
			}
		}
		//--generateAccount
		if(StringUtils.isNotEmpty(longName1)){
			Map<String, Object> map=new HashMap<String, Object>();
			map.put("loginName",longName1);
			if(userService.isExist(map)){
				return UTJsonUtils.getMsgJson(false, "请保证登陆名唯一");
			}
		}
		
		
		if(StringUtils.isNotEmpty(longName1)){
			Map<String, Object> map=new HashMap<String, Object>();
			map.put("loginName",longName1);
			if(enterService.isExist(map)){
				return UTJsonUtils.getMsgJson(false, "请保证登陆名唯一");
			}
		}

		if(StringUtils.isNotEmpty(idCode1)){
			Map<String, Object> map=new HashMap<String, Object>();
			map.put("idCode",idCode1);
			if(userService.isExist(map)){
				return UTJsonUtils.getMsgJson(false, "身份证号码唯一");
			}
		}
		
		if(StringUtils.isNotEmpty(idCode1)){
			Map<String, Object> map=new HashMap<String, Object>();
			map.put("idCode",idCode1);
			if(enterService.isExist(map)){
				return UTJsonUtils.getMsgJson(false, "身份证号码唯一");
			}
		}
		
		if(StringUtils.isNotEmpty(mobilePhone1)){
			Map<String, Object> map=new HashMap<String, Object>();
			map.put("phone",mobilePhone1);
			if(userService.isExist(map)){
				return UTJsonUtils.getMsgJson(false, "联系电话唯一");
			}
		}
		
		if(StringUtils.isNotEmpty(mobilePhone1)){
			Map<String, Object> map=new HashMap<String, Object>();
			map.put("mobilePhone",mobilePhone1);
			if(enterService.isExist(map)){
				return UTJsonUtils.getMsgJson(false, "联系电话唯一");
			}
		}
		
		return UTJsonUtils.getMsgJson(true, "");
	}
	
	
	//为人员添加配置
	@RequestMapping(value="saveConfig",method=RequestMethod.POST)  
    @ResponseBody
	public String saveConfigByUserId(@RequestBody Map<String,Object> map1){
		Map<String, Object> param = CommonUtils.clone(map1);
		
	   	try{
	   		boolean flog=enterService.saveConfigByUserId(param);
    		return UTJsonUtils.getJsonMsg(flog, flog?"操作成功":"操作失败");
    	}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
	}
	
	/**
	 * 入场申请-流程配置-选择执行人-特定项目-特定岗位角色
	 * @param pageBean
	 * @return
	 */
	@RequestMapping("getWorkflowTableData")
	@ResponseBody
	public UTPageBean getWorkflowTableData(){
		UTPageBean pageBean = new UTPageBean();
		//UTPageBean pageBean = CommonUtils.getPageBean(map);
		List<UTMap<String, Object>> list = new ArrayList<UTMap<String, Object>>();
		UTMap<String, Object> m1 = new UTMap<String, Object>();
		m1.put("id", "1");
		m1.put("name", "甲方负责人");
		list.add(m1);
		
		UTMap<String, Object> m2 = new UTMap<String, Object>();
		m2.put("id", "2");
		m2.put("name", "乙方负责人");
		list.add(m2);
		pageBean.setRows(list);
		pageBean.setTotal(2);
		return pageBean;
	}
	
	/**
	 * 导出人员入场审批流程详情
	 * @param param
	 * @param request
	 * @param response
	 */
	@RequestMapping("exportAuditInfo")
	public void exportAuditInfo(@RequestParam Map<String,Object> param, HttpServletRequest request, HttpServletResponse response) {
		String applyId = (String) param.get("id");
		String workflowCode = IWorkflowCode.OUTSOURCE_PERSON_ENTER;
		Instance instance = workflowEngine.getInstance(workflowCode, applyId);
		List<UTMap<String, Object>> instanceList = new ArrayList<UTMap<String, Object>>();
		if (instance != null) {
			instanceList = workflowEngine.getShowAuditInfoList(instance.getInstanceId());
			if (null != instanceList && !instanceList.isEmpty()) {
				for(int i=0;i<instanceList.size();i++) {
					UTMap<String, Object> item = instanceList.get(i);
					String createTime = item.get("createTime") == null ? "" : CommonUtils.replaceAll(item.get("createTime").toString(), "-", "/");
					item.put("createTime", createTime);
				}
			}
        }
		String[] fileds = new String[] { 
				"nodeName",
				"createUser",
				"createTime",
				"auditResult",
				"auditComment"				
		};
		String tamlate="excelOutTamplate.applyEnterAuditInfoLeadOut";	
		try {
			UTExcel.leadingout( fileds, instanceList, tamlate, request,response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}