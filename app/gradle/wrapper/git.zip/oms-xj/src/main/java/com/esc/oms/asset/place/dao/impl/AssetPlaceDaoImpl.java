package com.esc.oms.asset.place.dao.impl;

import com.esc.oms.asset.place.dao.IAssetPlaceDao;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class AssetPlaceDaoImpl extends BaseOptionDao implements IAssetPlaceDao{

	@Override
	public String getTableName() {
		return "assets_place";
	}

	@Override
	public boolean addAssetPlaceU(List<Map> infos) {
		return super.batchSave("assets_place_u", infos);
	}

	@Override
	public List<UTMap<String, Object>> getChildrenResource(String parentLongCode) {
		StringBuilder sql=new StringBuilder();
		sql.append("select r.id,r.code,r.longName,r.longCode, r.routers,r.signature from  sys_resource r where ( r.longCode like '"+parentLongCode+"%' or r.longCode='"+parentLongCode+"' )");
		return super.getListBySql(sql.toString(),null);
	}

	public List<UTMap<String, Object>> getResourceList(Map param) {
		String longName=param!=null&&param.containsKey("longName")&&param.get("longName")!=null?param.get("longName").toString():null;
		StringBuilder sql=new StringBuilder();
		sql.append(" select r.id,r.code,r.longName,r.longCode,r.updateTime,r.routers,r.signature ,r.parentId,r.icon,r.name,r.resourceType from sys_resource r where 1=1 ");
		if(StringUtils.isNotEmpty(longName)){
			sql.append(" and  r.longName like '%"+longName+"%'");
		}
		sql.append(" order by r.code asc");
		return super.getListBySql(sql.toString(),null);
	}
	
	/**
	 * 根据条件查询
	 * @param param 查询条件
	 * @return
	 */
	public List<UTMap<String, Object>> getListMaps(Map param) {
		StringBuilder sql=new StringBuilder();
		sql.append(" select tb.id,tb.name,tb.code,tb.parentId pId,tb.isMaterial,tb.isMachineRoom,tb.isCabinet,tb.assetsId,tb.remark, true isSelect,ifnull(ap2.`name`,'所有地点') parentName from  "
				 +getTableName()+" tb LEFT JOIN assets_place ap2 ON ap2.id = tb.parentId "
				 + " where 1=1 ");
		sql.append(" AND (tb.deleteFlag != 1 OR tb.deleteFlag IS NULL) ");
		if (null != param && !param.isEmpty()) {
			Object isNoCabinet=param.get("isNoCabinet");
			if(isNoCabinet!=null) {
				sql.append(" AND tb.isCabinet<>1 ");
			}
			
			String name = (String) param.get("name");//精确查询 -py 2019-01-10
			if (StringUtils.isNotEmpty(name)) {
				sql.append(" and tb.name='" + name + "' ");
			}
		}
		sql.append(" order by tb.name ");
		return super.getListBySql(sql.toString(),null);
	}

	@Override
	public List<UTMap<String, Object>> getListByParentId(String parentId){
		StringBuilder sql=new StringBuilder();
		sql.append(" select tb.id,tb.name,tb.code,tb.parentId pId,tb.isMaterial,tb.isMachineRoom,tb.isCabinet,tb.assetsId,tb.remark, true isSelect,ifnull(ap2.`name`,'所有地点') parentName from  "
				 +getTableName()+" tb LEFT JOIN assets_place ap2 ON ap2.id = tb.parentId "
				 + " where 1=1 ");
		sql.append(" AND (tb.deleteFlag != 1 OR tb.deleteFlag IS NULL) ");
		sql.append(" AND tb.parentId='" + parentId + "' ");
		sql.append(" order by tb.name ");
		return super.getListBySql(sql.toString(),null);
	}

	@Override
	public UTMap<String, Object> getIdByNameAndCode(String name, String code) {
		StringBuilder sql=new StringBuilder();
		sql.append(" select * from  "+getTableName()+" tb "
				 + " where 1=1 and tb.name = '"+name+"' and tb.code = '"+code+"'");
		return super.getOneBySql(sql.toString());
	}

	@Override
	public List<UTMap<String, Object>> getAssetPlaceUByPlaceId(String assetPlaceId) {
		// TODO Auto-generated method stub
		StringBuilder sql = new StringBuilder();
		sql.append("select id, assets_place_id,orderNum,status,assetId from assets_place_u where assets_place_id='"+assetPlaceId+"' order by orderNum asc");
		return  super.getListBySql(sql.toString(), null);
	}

	@Override
	public List<UTMap<String, Object>> getUsableList(Map<String, Object> map) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select id, assets_place_id, orderNum, status from assets_place_u ");
		sql.append(" where 1=1 ");
		String assetId = null;
		if(map != null){
			String assets_place_id = (String) map.get("assets_place_id");
			String startU = (String)map.get("startU");//开始U
			assetId = (String)map.get("assetId");//资产id
			if(StringUtils.isNotEmpty(assets_place_id)){
				sql.append(" and assets_place_id ='"+assets_place_id+"'");
			}
			if(StringUtils.isNotEmpty(startU)){
				sql.append(" and orderNum >="+startU);

			}
		}
		if(StringUtils.isNotEmpty(assetId)){//当存在资产id时说明占用的也需要查询
			sql.append(" and(assetId is null or assetId = '' " );//为空的
			sql.append(" or assetId = '"+assetId+"' ) ");

		}else{
			sql.append(" and (assetId is null or assetId = '')");
		}
		sql.append(" order by orderNum asc");
		return this.getListBySql(sql.toString());
	}

	@Override
	public boolean relievePlaceU(String assetId) {
		String sql = " update assets_place_u set assetId = null,status='0' where assetId = ? ";
		return this.executeUpdate(sql, assetId);
	}

	@Override
	public boolean batchRelievePlaceU(String assetIds) {
		String sql = " update assets_place_u set assetId = null,status='0' where assetId in ("+assetIds+")";
		return this.executeUpdate(sql, null);
	}

	@Override
	public String getOccupyPlaceU(String assets_place_id, int startU, int endU) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select group_concat(ap.orderNum) from (select * from assets_place_u ORDER BY orderNum asc) ap ");
		sql.append(" where ap.orderNum >= "+startU+" and ap.orderNum <="+endU);
		sql.append(" and ap.status='1' and ap.assets_place_id='" + assets_place_id + "' ");
		return (String) this.searchOneBySql(sql.toString(), null);
	}

	@Override
	public boolean bindingsPlaceU(String assets_place_id, String assetId, int startU, int endU) {
		StringBuilder sql = new StringBuilder();
		sql.append(" update assets_place_u set assetId = '"+assetId+"', status='1' where assets_place_id='"+assets_place_id+"' ");
		sql.append(" and orderNum >= "+startU+" and orderNum <= "+ endU);
		return this.executeUpdate(sql.toString());
	}
}
