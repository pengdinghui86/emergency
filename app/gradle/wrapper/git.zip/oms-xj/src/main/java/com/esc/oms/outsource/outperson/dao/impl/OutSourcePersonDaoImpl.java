package com.esc.oms.outsource.outperson.dao.impl;

import com.esc.oms.outsource.outperson.dao.IOutSourcePersonDao;
import com.esc.oms.util.RoleUtils;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 外包人员列表
 * @author smq
 * @date   2016-2-24 上午10:39:04
 */
@Repository
public class OutSourcePersonDaoImpl extends BaseOptionDao implements IOutSourcePersonDao {

	@Override
	public String getTableName() {
		return "outsource_person_list";
	}
	
	public UTMap<String, Object> getById(String id){
		Map<String, Object> param=new HashMap<String, Object>();
		param.put(IOutSourcePersonDao.FIELD_ID,id);
		param.put("isAll", true);
		String sql=getSearchSql(param);
		UTMap<String, Object> map= super.getOneBySql(sql, null);
		if(map.get("servicePersonId")!=null){
			Object servicePerson=super.searchOneBySql("select CONCAT(u.name,'/',u.code) from sys_user u where u.id='"+map.get("servicePersonId")+"' ", null);
			map.put("servicePersonName",servicePerson!=null?servicePerson.toString():"");
		}
		if(map.get("skillPersonId")!=null){
			Object servicePerson=super.searchOneBySql("select CONCAT(u.name,'/',u.code) from sys_user u where u.id='"+map.get("skillPersonId")+"' ", null);
			map.put("skillPersonName",servicePerson!=null?servicePerson.toString():"");
		}
		if(map.get("mainProjectId")!=null){
			Object mainProjectName=super.searchOneBySql("select u.name from project_info u where u.id='"+map.get("mainProjectId")+"' ", null);
			map.put("mainProjectName",mainProjectName!=null?mainProjectName.toString():"");
		}
		return map;
	}
	
	public UTMap<String, Object> getOutEmpByUserId(String userId){
		Map<String, Object> param=new HashMap<String, Object>();
		param.put(IOutSourcePersonDao.FIELD_USERID,userId);
		String sql=getSearchSql(param);
		UTMap<String, Object> map= super.getOneBySql(sql, null);
		if(map.get("servicePersonId")!=null){
			Object servicePerson=super.searchOneBySql("select CONCAT(u.name,'/',u.code) from sys_user u where u.id='"+map.get("servicePersonId")+"' ", null);
			map.put("servicePersonName",servicePerson!=null?servicePerson.toString():"");
		}
		if(map.get("skillPersonId")!=null){
			Object servicePerson=super.searchOneBySql("select CONCAT(u.name,'/',u.code) from sys_user u where u.id='"+map.get("skillPersonId")+"' ", null);
			map.put("skillPersonName",servicePerson!=null?servicePerson.toString():"");
		}
		return map;
	}

    @Override
    public List<UTMap<String, Object>> getAllDingDingId() {
	    StringBuilder sql = new StringBuilder();
	    sql.append(" select opl.dingDingId, opl.userId from outsource_person_list opl where opl.state <>0 and opl.state is not null");
	    sql.append(" and opl.dingDingId <> '' and opl.dingDingId is not null ");
        return this.getListBySql(sql.toString());
    }

	@Override
	public boolean changeOutPersonById(List<Map<String, Object>> paramList)throws Exception {
		Connection conn = this.getConnection();
		Statement ps = conn.createStatement();
		try{
			StringBuilder sql = new StringBuilder();
			for(Map<String, Object> map : paramList){
				ps.addBatch("update outsource_person_list set dingDingId='"+map.get("dingDingId")+"' where id='"+map.get("id")+"'" );
			}
			int[] result = ps.executeBatch();
			ps.clearBatch();
			ps.close();
			return result.length > 0;
		} catch (Exception var17) {
			var17.printStackTrace();
			throw var17;
		} finally {
			try {
				if (ps != null) {
					ps.close();
					ps = null;
				}
			} catch (Exception var16) {
			}

		}
	}

	@Override
	public boolean deleteDingDingId(String dingDingIds) {
		String sql = "update outsource_person_list set dingDingId = NULL where dingDingId in("+dingDingIds+")";
		return this.executeUpdate(sql);
	}

	public List<UTMap<String, Object>> getListMaps(Map param) {
		String sql=getSearchSql(param);
		return super.getListBySql(sql, null);
	}

	public void getPageInfo(UTPageBean pageBean,Map param){
		String sql=getSearchSql(param);
		 super.getPageListMapBySql(sql,pageBean, null);
	}
	/**
	 * 用户 查询sql 拼接器
	 * 注 roler 标识 系统角色  postr 标识 岗位角色
	 * @param param
	 * @return
	 */
	private String getSearchSql(Map<String, Object> param){
		Map<String, String> p=UTMap.mapObjToString(param);
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT opl.id, opl.mainProjectId, opl.userId,opl.`name`,opl.supplierId,opl.`level`,opl.updateTime,opl.updateUser,opl.departId,opl.state,");
		sql.append(" opl.isHumanRes ,opl.isAccess,opl.isAssess,opl.isKeyPerson,opl.servicePersonId,opl.skillPersonId,opl.monthlyFee,");
		sql.append(" 	opl.changeBeginDate,opl.changeEndDate,opl.category,opl.agreementId,opl.dingDingId,");
		sql.append(" u.email,u.phone,u.idCode,u.sex,u.age,u.fixedPhone,u.code,u.img, REPLACE( u.orgName,'!','/')  orgName,u.qq, ");
		sql.append(" ai.`name` agreementName,CONCAT(opl.name,'/',u.code) nameAndCode, ");
		sql.append(" sbi.`name` supplierName ");
	//	sql.append(" replace(org.longName,'!','/') orgName");
		sql.append(" from outsource_person_list opl ");
		sql.append("	LEFT JOIN sys_user u ON opl.userId=u.id ");
		sql.append("	LEFT JOIN supplier_base_info sbi on sbi.id=opl.supplierId ");
		sql.append(" left JOIN agreement_info ai on opl.agreementId=ai.id ");
	//	sql.append("	LEFT JOIN sys_org org ON org.id=opl.departId  ");
		sql.append("	WHERE 1=1 ");
		//系统管理员和外包管理员可以看所有的数据
		if(EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR) || RoleUtils.isOutsourceManagerPerson()){
			
		}
		//供应商负责人可以查看并编辑本供应商人员的数据
		else if(RoleUtils.isSupplierAdministrator() || RoleUtils.isSupplierLeaders()){
			sql.append(" and opl.supplierId='"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId()+"'");
		}
		//普通用户只能看自己的
		else{
			sql.append(" and opl.userId='"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"'");
		}

		String id=p.get(IOutSourcePersonDao.FIELD_ID); 
		String userId=p.get(IOutSourcePersonDao.FIELD_USERID); 
		String name=p.get(IOutSourcePersonDao.FIELD_NAME);
		String departId=p.get(IOutSourcePersonDao.FIELD_DEPARTID);
		String isAssess=p.get(IOutSourcePersonDao.FIELD_ISASSESS);
		String state=p.get(IOutSourcePersonDao.FIELD_STATE);
		String orgName=p.get("orgName");
		String orgLongName=p.get("orgLongName");
		String supplierId=p.get(IOutSourcePersonDao.FIELD_SUPPLIERID);
		String supplierName=p.get("supplierName");
		String isHumanRes=p.get("isHumanRes");
		String code=p.get("code");
		String codes = p.get("codes");
		String isAll=p.get("isAll");
		
		if (StringUtils.isEmpty(isAll)) {
			sql.append(" and   opl.state <>0 and opl.state is not null ");
		}
		
		if (StringUtils.isNotEmpty(id)) {
			sql.append(" and opl.id='"+id+"'");
		}
		if (StringUtils.isNotEmpty(userId)) {
			sql.append(" and opl.userId='"+userId+"'");
		}
		if (StringUtils.isNotEmpty(code)) {
			sql.append(" and u.code like '%"+code+"%'");
		}
		if (name!=null&&StringUtils.isNotEmpty(name.toString())) {
			sql.append(" and  opl.name like '%"+name+"%' ");
		}
		
		if (StringUtils.isNotEmpty(supplierId)) {
			sql.append(" and  opl.supplierId='"+supplierId+"' ");
		}
		
		if ( supplierName!=null&&StringUtils.isNotEmpty( supplierName.toString())) {
			sql.append(" and  sbi. name like '%"+ supplierName+"%' ");
		}
		
		if (StringUtils.isNotEmpty(departId)) {
			sql.append(" and  opl.departId='"+departId+"'");
		}
		
		if (StringUtils.isNotEmpty(state)) {
			sql.append(" and  u.state='"+state+"'");
		}
		
		if (StringUtils.isNotEmpty(isAssess)) {//是否考核
			sql.append(" and  opl.isAssess='"+isAssess+"'");
		}
		
		if (orgName!=null&&StringUtils.isNotEmpty(orgName)) {
			orgName=orgName.replace("!","/");
			sql.append(" and u.orgName like'%"+orgName+"%'");
		}
		
		if (orgLongName!=null&&StringUtils.isNotEmpty(orgLongName.toString())) {
			orgLongName=orgLongName.replace("!","/");
			sql.append(" and (u.orgName like '" + orgLongName + "%'  or u.orgName='"+orgLongName+"')");
		}
		
		if (isHumanRes!=null&&StringUtils.isNotEmpty(isHumanRes.toString())) {
			sql.append(" and opl.isHumanRes='"+isHumanRes+"' ");
		}
		if(StringUtils.isNotEmpty(codes)){
			sql.append(" and u.code in("+codes+")");
		}
		sql.append("	ORDER BY opl.sortCode desc ");
		//sql.append("	ORDER BY opl.createTime desc, (u.code) asc ");
		
		// sql.append("	ORDER BY (sbi.code+0) asc, opl.createTime desc,(opl.code+0) asc ");
		return sql.toString();
	}

}
