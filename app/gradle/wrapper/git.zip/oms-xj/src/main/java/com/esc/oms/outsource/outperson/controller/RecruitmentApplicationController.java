package com.esc.oms.outsource.outperson.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.upload.service.ISysFileService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTListResult;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.outsource.outperson.service.IRecruitmentApplicationService;
import com.esc.oms.util.CommonUtils;

import net.sf.json.JSONObject;

@Controller
@RequestMapping("/recruitmentApplication")
public class RecruitmentApplicationController extends BaseOptionController {

	@Resource
	private IRecruitmentApplicationService service;
	
	@Resource
	private ISysFileService fileService;
	
	@Override
	public IBaseOptionService optionService() {
		return service;
	}
	
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			service.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	@RequestMapping(value="getPageList")  
    @ResponseBody
    public UTPageBean getPageList(@RequestParam Map<String, Object> params){  
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		List<UTMap<String,Object>> list = new ArrayList<UTMap<String,Object>>();
		try{
			//service.getPageInfo(pageBean, params);
			//list = 
			service.getPageList(pageBean, params);
			//pageBean.setRows(list);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
        return pageBean;
    }
	
	/**
	 * 待审批列表--分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getPendApprovalPageList")  
    @ResponseBody
    public UTPageBean getPendApprovalPageList(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			service.getPendApprovalPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	/**
	 * 已审批列表--分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAlreadyApprovalPageList")  
    @ResponseBody
    public UTPageBean getAlreadyApprovalPageList(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			service.getAlreadyApprovalPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	/**
	 * 查询人力外包供应商
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getManpowerSuppliers")  
    @ResponseBody
    public UTListResult getDistributeSuppliers(@RequestParam  Map<String, Object> param){
		UTListResult result = new UTListResult();
		try{
			List<UTMap<String, Object>> list = service.getManpowerSuppliers(param);
			result.setRows(list);
			result.setTotal(list.size());
		}catch(Exception e){
			logger.error("Exception", e);
		}
		return result;
	}
	
	/**
	 * 查询人力外包人力类型
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getManpowerCategorys")  
    @ResponseBody
    public UTListResult getManpowerCategorys(@RequestParam  Map<String, Object> param){
		UTListResult result = new UTListResult();
		try{
			List<UTMap<String, Object>> list = service.getManpowerCategorys(param);
			result.setRows(list);
			result.setTotal(list.size());
		}catch(Exception e){
			logger.error("Exception", e);
		}
		return result;
	}
	
	
	/**
	 * 新增，需要返回一个id给前台的其他标签
	 * @param info
	 * @return
	 */
	@RequestMapping(value="add",method =RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> add(@RequestBody  Map<String, Object> map1){
		Map<String,Object> cloneMap = CommonUtils.clone(map1);
		try{ 
    		boolean result = optionService().add(cloneMap);
    		if(result){
    			cloneMap.put("success", true);
    			cloneMap.put("msg", "操作成功！");
    		}else{
    			cloneMap.put("success", false);
//        		info.put("msg", "操作失败！");
    		}   		
    	}catch(EscServiceException e){
    		cloneMap.put("success", false);
    		cloneMap.put("msg", e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		cloneMap.put("success", false);
    		cloneMap.put("msg", "操作失败！");
    	}
       return cloneMap;
	}
	
	

	/**
	 * 申请单分发
	 * @param info
	 * @return
	 */
	@RequestMapping(value="distribute",method =RequestMethod.POST)
	@ResponseBody
	public String distribute(@RequestBody  Map<String, Object> info){
		try{
			service.distribute(info);
    	}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "操作成功");
	}
	
	
	/**
	 * 申请单关闭
	 * @param info
	 * @return
	 */
	@RequestMapping(value="close",method =RequestMethod.POST)
	@ResponseBody
	public String close(@RequestBody  Map<String, Object> info){
		try{
			service.close(info);
    	}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "操作成功");
	}
	
	@RequestMapping(value = "leadingout")
	public void leadingout(@RequestParam Map<String, Object> param, HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();

			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = null;
			if (info != null) {
				jsonBean = JSONObject.fromObject(info);
			}

			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = service.getListMaps(jsonBean);
			} else {
				// 根据条件 导出当前
				service.getPageInfo(utPageBean, jsonBean);
				data = utPageBean.getRows();
			}
			
			if (null != data && !data.isEmpty()) {
				for (int i=0;i<data.size();i++) {
					UTMap<String, Object> item = data.get(i);
					item.put("applyDate", CommonUtils.replaceAll((String)item.get("applyDate"), "-", "/"));
				}
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			service.leadingout(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	@RequestMapping(value = "leadingoutDetail")
	public void leadingoutDetail(@RequestParam Map<String, Object> param,
			HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = null;
			if(info != null) {
				jsonBean = JSONObject.fromObject(info);
			}
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = service.getListAllDetail(jsonBean);
			} else {
				service.getPageInfoDetail(utPageBean, jsonBean);
				data = utPageBean.getRows();
			}
			if (null != data && !data.isEmpty()) {
				for (int i=0;i<data.size();i++) {
					UTMap<String, Object> item = data.get(i);
					item.put("applyDate", CommonUtils.replaceAll((String)item.get("applyDate"), "-", "/"));
				}
			}
			
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			service.leadingoutDetail(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	
	/**
	 * 首页-报表--部门人力需求统计
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getOrgReport")  
    @ResponseBody
    public Map<String,Object> getOrgReport(@RequestParam Map<String, Object> params){  
		Map<String,Object> map = new HashMap<String,Object>();
		try{
			map = service.getOrgReport(params);
		}catch(Exception e){
			logger.error("Exception", e);
		}
		return map;
    }
	
	@RequestMapping("getReviewFile")
	@ResponseBody
	public UTMap<String, Object> getReviewFile(@RequestParam Map<String, Object> param){
		UTMap<String, Object> map = service.getReviewFile((String)param.get("applyId"));
		if (null != map && !map.isEmpty()) {
			map = service.getReviewFileById(map.get("id").toString());
		}
		return map;
	}
	
	@RequestMapping("submitViewForm")
	@ResponseBody
	public String submitViewForm(@RequestBody Map<String, Object> param) {
		try {
			service.submitViewForm(param);
		}catch(Exception e) {
			return UTJsonUtils.getJsonMsg(false, "操作失败");
		}
		return UTJsonUtils.getJsonMsg(true, "操作成功");
	}
	
	@RequestMapping("getProjectRes")
	@ResponseBody
	public List<UTMap<String, Object>> getProjectRes(@RequestParam Map<String, Object> param){
		List<UTMap<String, Object>> list = service.getProjectRes(param);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		if (null != list && !list.isEmpty()) {
			for (int i=0;i<list.size(); i++) {
				UTMap<String, Object> item = list.get(i);
				Object endDateObj = item.get("endDate");
				if (endDateObj != null) {
					try {
						Date endDate = sdf.parse(endDateObj.toString());
						Date nowDate = sdf.parse(sdf.format(new Date()));
						if (!endDate.after(nowDate)) {
							item.put("isTimeOut", "-1");
						}
					}catch(Exception e){
						
					}
					
				}
			}
		}
		return list;
	}
}
