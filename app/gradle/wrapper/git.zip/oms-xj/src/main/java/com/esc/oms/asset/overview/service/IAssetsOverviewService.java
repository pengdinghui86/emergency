package com.esc.oms.asset.overview.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;


public interface IAssetsOverviewService{
	
	/**
	 * 根据条件查询资产列表
	 * @param params
	 */
	public List<UTMap<String, Object>> getAssetsList(Map params);

	/**
	 * 根据条件查询资产列表--分页
	 * @param params
	 */
	public void getAssetsPageList(UTPageBean pageBean,Map<String, Object> params);
	
	/**
	 * 根据条件查询预警资产合同列表
	 * @param params
	 */
	public List<UTMap<String, Object>> getWarnAgreementList(Map params);

	/**
	 * 根据条件查询预警资产合同列表--分页
	 * @param params
	 */
	public void getWarnAgreementPageList(UTPageBean pageBean,Map<String, Object> params);
	/**
	 * 资产统计--类别维度
	 * @param params
	 * @return
	 */
	public Map<String,Object> getOverviewReportCategoy(Map<String, Object> params);
	/**
	 * 资产统计--月维度
	 * @param params
	 * @return
	 */
	public Map<String,Object> getOverviewReportMonth(Map<String, Object> params);
	
}


