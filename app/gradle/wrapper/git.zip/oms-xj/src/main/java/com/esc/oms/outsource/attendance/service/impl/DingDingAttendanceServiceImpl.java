package com.esc.oms.outsource.attendance.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.dingtalk.api.response.*;
import com.esc.oms.outsource.attendance.dao.*;
import com.esc.oms.outsource.attendance.service.IAttendanceDefaultService;
import com.esc.oms.outsource.attendance.service.IAttendanceService;
import com.esc.oms.outsource.attendance.service.IDingDingAttendanceService;
import com.esc.oms.outsource.manhour.dao.*;
import com.esc.oms.outsource.manhour.service.IManHourStatisticService;
import com.esc.oms.outsource.outperson.dao.IOutSourcePersonDao;
import com.esc.oms.supplier.project.dao.IProjectResDao;
import com.esc.oms.supplier.supplieremp.service.ISupplierEmpService;
import com.esc.oms.util.*;
import com.taobao.api.ApiException;
import com.taobao.api.TaobaoParser;
import com.taobao.api.internal.parser.json.ObjectJsonParser;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.esc.framework.EscPropertyHolder;
import org.esc.framework.dict.dao.ISysParamDao;
import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.idgenerator.IDGenerationManager;
import org.esc.framework.persistence.dao.AbstractBaseSqlDao;
import org.esc.framework.timetask.anotations.CronTimeTask;
import org.esc.framework.timetask.anotations.TimeTaskMark;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * 钉钉同步service
 * 先将钉钉上的数据同步至服务器的数据库中，再对库中的数据进行分析对比，
 * 将数据同步至考勤中
 * 包括考勤打卡，加班，请假，调休
 *
 * 每1个小时调用钉钉，获取token
 */
@Service("dingDingAttendanceService")
@Transactional
@TimeTaskMark
public class DingDingAttendanceServiceImpl implements IDingDingAttendanceService {

    private static final Logger logger = LoggerFactory.getLogger(DingDingAttendanceServiceImpl.class);
    /**
     * 设置一个全局变量
     */
    public String access_token = "";

    public static boolean isFirst = false;

    private String proxyip = "https://oapi.dingtalk.com";

    private String season = FunctionEnum.SeasonType.summer.getCode();//默认夏令时
    private int count = 50;

    @Resource
    private IFestivalDao festivalDao;
    @Resource
    private IOutSourcePersonDao outSourcePersonDao;

    @Resource
    private ISysParamDao sysParamDao;

    @Resource
    private IDingDingInfoDao dingDingInfoDao;

    @Resource
    private IAttendanceDao attendanceDao;

    @Resource
    private IUserConfigDao userConfigDao;

    @Resource
    private ICoalitionConfigDao coalitionConfigDao;

    @Resource
    private IAttendanceService attendanceService;

    @Resource
    private ISupplierEmpService supplierEmpService;

    @Resource
    private IManHourStatisticService manHourStatisticService;

    @Resource
    private IDingDingApproveDao dingDingApproveDao;

    @Resource
    private ISysParamService sysParamService;

    @Resource
    private IVacationDetailDao vacationDetailDao;

    @Resource
    private IVacationDao vacationDao;

    @Resource
    private IOvertimeDao overtimeDao;

    @Resource
    private ITravelDao travelDao;

    @Resource
    private IProjectResDao projectResDao;

    @Resource
    private IAttendanceSeasonConfigDao attendanceSeasonConfigDao;

    @Resource
    private IAttendanceDefaultService attendanceDefaultService;

    @Resource
    private IOverTimeDetailDao overTimeDetailDao;

    @Override
    public String getaAccess_token() {
        proxyip = getProxyIp();//设置跳板服务器
        String corpId = EscPropertyHolder.instance.getProperty("dingding.corpId");
        String corpSecret = EscPropertyHolder.instance.getProperty("dingding.corpSecret");
//        RestTemplate restTemplate = new RestTemplate();
//        String tokenResult = restTemplate.getForObject("https://oapi.dingtalk.com/gettoken?corpid="+corpId+"&corpsecret="+corpSecret,String.class);
//        //System.out.println(JSON.parseObject(tokenResult).get("access_token"));
//        access_token = JSON.parseObject(tokenResult).get("access_token").toString();
        Map<String, String> param = new HashMap<>();
        param.put("corpid",corpId);
        param.put("corpsecret", corpSecret);
        String str = WebServiceUtil.invokeWS(proxyip+"/gettoken", param);
        if(str != null){
            access_token = JSON.parseObject(str).get("access_token").toString();
        }
        return access_token;
    }

    /**
     * 获取token ，防止重启时token为空的情况
     * @return
     */
    private String getSingletonToken(){
        proxyip = getProxyIp();
        if(StringUtils.isNotEmpty(access_token)){
            return access_token;
        }else{
            return getaAccess_token();
        }
    }

    /**
     * 获取50个人的考勤信息 ,并获取关联的审批id
     * @param list
     * @return
     */
    private List<String> getAllAttendance(List<UTMap<String, Object>> list, String startTime, String endTime){
        List<String> idList = new ArrayList<>();
        for(UTMap<String, Object> map : list){
            idList.add(map.get("dingDingId").toString());
        }
        try {
//            DingTalkClient client = new DefaultDingTalkClient("https://oapi.dingtalk.com/attendance/listRecord");
//            OapiAttendanceListRecordRequest request = new OapiAttendanceListRecordRequest();
//            request.setCheckDateFrom(startTime);
//            request.setCheckDateTo(endTime);
//            request.setUserIds(idList);
//            OapiAttendanceListRecordResponse response = client.execute(request,access_token);

            Map<String, String> param = new HashMap<>();
            param.put("access_token", access_token);
            param.put("userIds", net.sf.json.JSONArray.fromObject(idList.toArray()).toString());
            param.put("checkDateFrom", startTime);
            param.put("checkDateTo",endTime);
            String str = WebServiceUtil.httpPostWithJson(proxyip+"/attendance/listRecord", param);
            TaobaoParser parser = new ObjectJsonParser(OapiAttendanceListRecordResponse.class, true);
            OapiAttendanceListRecordResponse  response= (OapiAttendanceListRecordResponse)parser.parse(str, "dingtalk");
            if(response.isSuccess()){
                if(response.getRecordresult() != null && response.getRecordresult().size()>0){//存在数据，然后数据入库
                    return addDingDingInfo(response.getRecordresult());
                }
            }else{
                throw new ApiException("获取数据失败");
            }
        } catch (ApiException e) {
            e.printStackTrace();
        }
        return new ArrayList<>();
    }

    @Override
    @CronTimeTask(description="每天7:15,10:15,14:15,20:15同步钉钉过来的打卡详细数据",cron="0 15 7,10,14,20 * * ? ")
    public void getAndMergeAttendance() {
        if(isFirst == true){//第一次启动时阻止他运行，
            isFirst = false;
            return;
        }
        try {
            access_token = getaAccess_token();
            DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            LocalDateTime zeroDate = LocalDateTime.of(LocalDate.now(), LocalTime.MIN);//当天零点
            String startTime = df.format(zeroDate);//开始时间//当天零点
            String endTime = df.format(LocalDateTime.now());//结束时间
            getAllAttendanceListByTime(startTime, endTime,true, false);
            //处理审批记录
            getAndAddNonExistent(startTime, endTime);
            //加班等审批数据
            getAndMergeApprove(null, null);
            mergeApproves();
        } catch (EscServiceException e) {
            logger.error("同步考勤详细数据失败",e);
        }

    }

    @Override
//    @CronTimeTask(description="每天凌晨两点和24点同步打卡结果",cron="0,59 0 2,23 * * ?")
    public void getAndMergeAttendanceTwo() {
//        try {
//            access_token = getSingletonToken();
//            if(access_token == null){
//                return;
//            }
//            //获取当前时间
//            DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
//            String startTime = df.format(LocalDateTime.of(LocalDate.now(), LocalTime.MIN));//当天零点
//            String endTime = df.format(LocalDateTime.now());//结束时间 当天12点
//            getAllAttendanceResultByTime(startTime, endTime);
//            //处理审批记录
//        } catch (EscServiceException e) {
//            logger.error("同步考勤打卡结果失败",e);
//        }
    }

    /**
     * 每天凌晨3点同步一个月内的补卡审批记录
     */
    @CronTimeTask(description="每天凌晨3点同步一月内补卡审批记录",cron="0 0 3 * * ?")
    public void getCardApply(){
        try {
            access_token = getSingletonToken();
            if(access_token == null){
                return;
            }
            //在这里顺便处理获取所有的审批单code
            getOverTimeApproveId();
            //获取当前时间
            DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            LocalDateTime now = LocalDateTime.now();
            String endTime = df.format(now);//结束时间
            now = now.plusMonths(-1);//一个月之前
            String startTime = df.format(now);//开始时间一个月前
            getCardApplyByTime(startTime, endTime);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void getAttendanceListByTime(String startTime, String endTime, boolean isFinal) {
        access_token = getSingletonToken();
        if(access_token == null){
            return;
        }
        getAllAttendanceListByTime(startTime, endTime,false, isFinal);
    }

    @Override
    public void getOverTimeApproveId() {
        access_token = getSingletonToken();
        if(access_token == null){
            return;
        }
        try {
//            DingTalkClient client = new DefaultDingTalkClient("https://oapi.dingtalk.com/topapi/process/listbyuserid");
//            OapiProcessListbyuseridRequest request = new OapiProcessListbyuseridRequest();
//            request.setOffset(0L);
//            request.setSize(100L);
//            OapiProcessListbyuseridResponse response = client.execute(request, access_token);

            Map<String, String> param = new HashMap<>();
            param.put("access_token", access_token);
            param.put("offset", "0");
            param.put("size", "100");
            String str = WebServiceUtil.invokeWS(proxyip+"/topapi/process/listbyuserid", param);
            TaobaoParser parser = new ObjectJsonParser(OapiProcessListbyuseridResponse.class, true);
            OapiProcessListbyuseridResponse  response= (OapiProcessListbyuseridResponse)parser.parse(str, "dingtalk");

            if(response.getErrcode() == 0 && response.getResult().getProcessList() != null && response.getResult().getProcessList().size() >0){//成功
                List<OapiProcessListbyuseridResponse.ProcessTopVo> list = response.getResult().getProcessList();
                for(OapiProcessListbyuseridResponse.ProcessTopVo vo : list){
                    if(vo.getName().indexOf("加班") >= 0){//表示是加班的，则我们将加班数据填上
                        Map<String, Object> params = new HashMap<>();
                        params.put("paramType", "dingProcessCode");
                        List<UTMap<String, Object>> paramsList = sysParamDao.getListMaps(params);
                        for(UTMap<String, Object> map : paramsList){
                            if("overTime".equals(map.get("name"))){
                                map.put("value", vo.getProcessCode());
                                sysParamDao.updateById(map);
                            }

                        }
                    }else if(vo.getName().indexOf("请假") >= 0){//表示请假
                        Map<String, Object> params = new HashMap<>();
                        params.put("paramType", "dingProcessCode");
                        List<UTMap<String, Object>> paramsList = sysParamDao.getListMaps(params);
                        for(UTMap<String, Object> map : paramsList){
                            if("vacation".equals(map.get("name"))){//请假
                                map.put("value", vo.getProcessCode());
                                sysParamDao.updateById(map);
                            }
                        }
                    }else if(vo.getName().indexOf("补卡申请") >= 0){
                        Map<String, Object> params = new HashMap<>();
                        params.put("paramType", "dingProcessCode");
                        List<UTMap<String, Object>> paramsList = sysParamDao.getListMaps(params);
                        for(UTMap<String, Object> map : paramsList){
                            if("cardApply".equals(map.get("name"))){//请假
                                map.put("value", vo.getProcessCode());
                                sysParamDao.updateById(map);
                            }
                        }
                    }
                }
            }
        } catch (ApiException e) {
            e.printStackTrace();
        }
    }

    /**
     * 根据时间获取加班的审批单
     * @param startTime
     * @param endTime
     */
    private List<Map<String, Object>> getOverTimeApproveByTime(String startTime, String endTime){
        //获取审批单的id
        List<Map<String, Object>> mapList = new ArrayList<>();
        Map<String, Object> params = new HashMap<>();
//        params.put("paramType", "dingProcessCode");
//        List<UTMap<String, Object>> paramsList = sysParamDao.getListMaps(params);
//        UTMap<String, Object> p = paramsList.get(0);
//        String proCode = (String) p.get("value");
        String proCode =  sysParamService.getParamValueByName("dingProcessCode", "overTime");
        //获取审批单Id
        OapiProcessinstanceListidsResponse.PageResult result = getOverTimeApproveIds(startTime, endTime, proCode);
        if(result != null && result.getList() != null && result.getList().size() > 0){
            List<String> list = result.getList();
            for(String s : list){
                mapList.add(getApproveDetail(s));
            }
        }
        return mapList;
    }

    /**
     * 根据时间获取补卡审批的审批单
     * @param startTime
     * @param endTime
     */
    private void getCardApplyByTime(String startTime, String endTime){
        //获取审批单的id
        List<Map<String, Object>> mapList = new ArrayList<>();
        String proCode =  sysParamService.getParamValueByName("dingProcessCode", "cardApply");
        //获取审批单Id
        OapiProcessinstanceListidsResponse.PageResult result = getOverTimeApproveIds(startTime, endTime, proCode);
        if(result != null && result.getList() != null && result.getList().size() > 0){
            List<String> list = result.getList();
            for(String s : list){
                mapList.add(getApproveDetail(s));
            }
        }

        if(mapList.size() <= 0){
            return ;
        }
        String[] presentDateTime = null;
        String dingDingId = null;
        String signTime = null;
        String presentDate = null;
        String planText = null;
        String userCheckTime = null;
        List<Map<String, Object>> attMapList = new ArrayList<>();
        String state = null;
        String status = null;
        for(Map<String, Object> map : mapList){
            state = (String) map.get("result");
            status = (String) map.get("status");
            if(!"agree".equals(state) || "COMPLETED".equals(status) ){
                continue;
            }
            presentDateTime = ((String) map.get("presentDate")).split(" ");
            planText = (String) map.get("planText");
            signTime = presentDateTime[1];
            presentDate = presentDateTime[0];
            dingDingId = (String) map.get("originatorUserId");
            userCheckTime = (String) map.get("userCheckTime");
            //根据钉钉id和当前时间获取打卡时间，
            Map<String, Object> attMap = attendanceDao.getAttendance(presentDate, dingDingId);
            if(attMap == null){
                continue;
            }
            if(planText.indexOf("上班时间") >= 0){//补上班卡
                if(!userCheckTime.equals((String)attMap.get("startTime"))){//不一致，则补上班卡
                    attMap.put("startTime", userCheckTime);
                    attMap.put("dateinStyle", 0);
                    attMapList.add(attMap);
                }
            }else if(planText.indexOf("下班时间") >= 0){
                if(!userCheckTime.equals((String)attMap.get("endTime"))){
                    attMap.put("endTime", userCheckTime);
                    attMap.put("dateoutStyle", 0);
                    attMapList.add(attMap);
                }
            }
        }
        if(attMapList.size() > 0){
            attendanceDao.batchUpdate(attMapList, new String[]{"id"});
        }
    }

    /**
     * 根据时间获取请假的审批单
     * @param startTime
     * @param endTime
     */
    private List<Map<String, Object>> getVacationApproveByTime(String startTime, String endTime){
        //获取审批单的id
        List<Map<String, Object>> mapList = new ArrayList<>();
        String proCode =  sysParamService.getParamValueByName("dingProcessCode", "vacation");
        //获取审批单Id
        OapiProcessinstanceListidsResponse.PageResult result = getOverTimeApproveIds(startTime, endTime, proCode);
        if( result != null && result.getList() != null && result.getList().size() > 0){
            List<String> list = result.getList();
            for(String s : list){
                mapList.add(getApproveDetail(s));
            }
        }
        return mapList;
    }

    private OapiProcessinstanceListidsResponse.PageResult getOverTimeApproveIds(String startTime, String endTime, String code){
        try {
//            DingTalkClient client = new DefaultDingTalkClient("https://oapi.dingtalk.com/topapi/processinstance/listids");
//            OapiProcessinstanceListidsRequest req = new OapiProcessinstanceListidsRequest();
//            req.setProcessCode(code);
//            req.setStartTime(LocalDateUtil.getTimestamp(startTime));
//            req.setEndTime(LocalDateUtil.getTimestamp(endTime));
////            req.setSize(10L);
////            req.setCursor(0L);
//            OapiProcessinstanceListidsResponse response = client.execute(req, access_token);
//            if(response.getErrcode() == 0){
//                return response.getResult();
//            }
            //代理的写法
            Map<String, String> param = new HashMap<>();
            param.put("access_token", access_token);
            param.put("process_code", code);
            param.put("start_time", LocalDateUtil.getTimestamp(startTime)+"");
            param.put("end_time", endTime != null ? (LocalDateUtil.getTimestamp(endTime)+"") : null);
            String str = WebServiceUtil.httpPostWithJson(proxyip+"/topapi/processinstance/listids", param);
            TaobaoParser parser = new ObjectJsonParser(OapiProcessinstanceListidsResponse.class, true);
            OapiProcessinstanceListidsResponse  response= (OapiProcessinstanceListidsResponse)parser.parse(str, "dingtalk");
            if(response.getErrcode() == 0){
                return response.getResult();
            }
        } catch (ApiException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 根据中间表审批数据id从钉钉获取审批数据和中间表对比，状态变化就修改
     * @param startTime
     * @param endTime
     */
    public void getAndMergeApprove(String startTime, String endTime){
        Map<String, Object> param = new HashMap<>();
        param.put("startTime", startTime);
        param.put("endTime", endTime);
        param.put("notDone", "1");
        List<UTMap<String, Object>> allApproveList = dingDingApproveDao.getListMap(param);
        if(allApproveList == null || allApproveList.size() <= 0){
            return ;
        }
        List<Map<String, Object>> updateList = new ArrayList<>();
        for(UTMap<String, Object> map : allApproveList){
            OapiProcessinstanceGetResponse.ProcessInstanceTopVo vo= getApprove((String) map.get("processInstanceId"));
            //依次去钉钉中查找数据，当出现状态不一致的时候，我们就回来处理我们这边的数据
            if(vo != null && !vo.getStatus().equals((String) map.get("status"))){
                map.put("status", vo.getStatus());
                map.put("result", vo.getResult());
                map.put("attachedProcessInstanceIds", vo.getAttachedProcessInstanceIds());
                updateList.add(map);
            }
        }
        dingDingApproveDao.batchUpdate(updateList, new String[]{"id"});
    }

    private void getAllAttendanceListByTime(String startTime, String endTime,boolean daylily, boolean isFinal){

        //清空缓存
        attendanceDefaultService.clearCache();
        //获取所有的需要考勤的用户
        List<UTMap<String, Object>> allDingList =  outSourcePersonDao.getAllDingDingId();
        if(allDingList == null || allDingList.size() <= 0){
            logger.info("没有需要考勤的用户");
            return;
        }
        StringBuilder dingIds = new StringBuilder();//所有的钉钉id
        List<String> userIds = new ArrayList<>();
        for(UTMap<String, Object> map : allDingList){
            dingIds.append(map.get("dingDingId")+",");
            userIds.add((String) map.get("userId"));
        }

        //先删除这段时间内的所有考勤
        initAttendance(startTime, endTime, userIds,dingIds.toString(),daylily, isFinal);
        //先删除这段时间内，人员的请假加班记录

        //根据钉钉ID获取当前所有的用户考勤数据（根据开始时间和结束时间来获取，然后根据时间来进行配对）
        Map<String, Object> param = new HashMap<>();
        param.put("startTime", startTime);
        param.put("endTime", endTime);
        param.put("dingDingIds", CommonUtils.getSqlId(dingIds.toString()));
        List<UTMap<String, Object>> allAttendanceList = attendanceDao.getAllAttendanceList(param);
        //将用户的考勤数据根据时间分离  钉钉号+日期为key
        Map<String, UTMap<String, Object>> allAttendanceMap = new HashMap<>();
        if(allAttendanceList != null){
            for(UTMap<String, Object> map : allAttendanceList){
                allAttendanceMap.put((String) map.get("dingDingId") + map.get("date"), map);
            }
        }

        int totalSize = allDingList.size();
        int toIndex = count;
        List<String> procInstIdList = new ArrayList<>(); //关联的审批
        for(int i = 0; i<allDingList.size();i+=count){
            if(i+count>totalSize){
                toIndex = totalSize-i-1;
            }
            List<UTMap<String, Object>> newList = allDingList.subList(i,i+toIndex);
//            //这个时候分批去取所有的打卡记录,并记录下关联的审批id
            procInstIdList.addAll(getAllAttendance(newList, startTime, endTime));
        }
        //再对数据进行批处理
        param.clear();
        param.put("isSynchronized", 0);//未同步
//        param.put("isLegal", "Y");//合法
//        param.put("locationResult","Normal");//范围内
        List<UTMap<String, Object>> allList = dingDingInfoDao.getListMaps(param);//从数据库获取所有数据
        if(allList == null || allList.size() <= 0){
            return;
        }
        //获取需要修改时间的数据
        List<Map<String, Object>> mergeTimeList = new ArrayList<>();
        //需要手动生成的数据
        List<Map<String, Object>> addMergeList = new ArrayList<>();
        mergeAttenceList(allList, mergeTimeList, allAttendanceMap);
        if(mergeTimeList != null && mergeTimeList.size() > 0){
            for(Map<String, Object> map : mergeTimeList){
                map.remove("dingDingId");
                map.remove("code");
            }
            attendanceDao.batchUpdate(mergeTimeList, new String[]{"id"});
        }
        if(addMergeList != null && addMergeList.size() > 0){
            for(Map<String, Object> map : addMergeList){
                map.remove("dingDingId");
            }
            attendanceDao.adds(CommonUtils.mergeToMap(addMergeList));
        }
        //修改钉钉的数据
        //处理完数据，批量修改数据
        //修改钉钉数据
        List<Map<String, Object>> allMapList = new ArrayList<>();//数据转换
        allMapList.addAll(allList);
        for(Map<String, Object> map : allMapList){
            map.remove("userId");
        }
        dingDingInfoDao.batchUpdate(allMapList, new String[]{"id"});
//        //处理所有的审批实例
//        getAndAddNonExistent(procInstIdList, startTime, endTime);
    }
    /**
     * 根据时间来获取考勤结果数据
     * @param startTime
     * @param endTime
     */
    private void getAllAttendanceResultByTime(String startTime, String endTime){
        //获取所有的需要考勤的用户
        List<UTMap<String, Object>> allDingList =  outSourcePersonDao.getAllDingDingId();
        if(allDingList == null || allDingList.size() <= 0){
            return;
        }

        Map<String, String> dingUserMap = new HashMap<>();//钉钉和用户的对应
        StringBuilder dingIds = new StringBuilder();//所有的钉钉id
        for(UTMap<String, Object> map : allDingList){
            dingUserMap.put((String) map.get("dingDingId"), (String) map.get("userId"));
            dingIds.append(map.get("dingDingId")+",");
        }

        //根据钉钉ID获取当前所有的用户考勤数据（根据开始时间和结束时间来获取，然后根据时间来进行配对）
        Map<String, Object> param = new HashMap<>();
        param.put("startTime", startTime);
        param.put("endTime", endTime);
        param.put("dingDingIds", CommonUtils.getSqlId(dingIds.toString()));
        List<UTMap<String, Object>> allAttendanceList = attendanceDao.getAllAttendanceList(param);
        //将用户的考勤数据根据时间分离  钉钉号+日期为key
        Map<String, UTMap<String, Object>> allAttendanceMap = new HashMap<>();
        if(allAttendanceList != null){
            for(UTMap<String, Object> map : allAttendanceList){
                allAttendanceMap.put((String) map.get("dingDingId")+ map.get("date"), map);
            }
        }

        int totalSize = allDingList.size();
        int toIndex = count;
        for(int i = 0; i<allDingList.size();i+=count){
            if(i+count>totalSize){
                toIndex = totalSize-i-1;
            }
            List<UTMap<String, Object>> newList = allDingList.subList(i,i+toIndex);
            //这个时候分批去取所有的打卡结果，并合并入数据库，注意，我们的打卡结果是不入库的，只做数据的比较
            List<String> idList = new ArrayList<>();
            for(UTMap<String, Object> map : newList){
                idList.add(map.get("dingDingId").toString());
            }
            //获取所有钉钉打卡的数据
            List<OapiAttendanceListResponse.Recordresult> allDingAttendanceList = new ArrayList<>();
            getAllAttendenceResult(allDingAttendanceList ,idList, startTime, endTime, 0l);
            if(allDingAttendanceList == null || allDingAttendanceList.size() < 0){
                return ;
            }
            //将钉钉获取的数据变为可操作的数据，并获取审批实例id
            List<UTMap<String, Object>> allList = new ArrayList<>();
            handleDingResult(allDingAttendanceList, allList, dingUserMap);//审批实例id
            //获取需要修改时间的数据
            List<Map<String, Object>> mergeTimeList = new ArrayList<>();
            try {
                mergeAttenceList(allList, mergeTimeList, allAttendanceMap);
            } catch (RuntimeException e) {
                logger.error("处理考勤异常",e);
            }
            if(mergeTimeList != null && mergeTimeList.size() > 0){
                for(Map<String, Object> map : mergeTimeList){
                    map.remove("dingDingId");
                }
                attendanceDao.batchUpdate(mergeTimeList, new String[]{"id"});
            }
        }
    }

    /**
     * 递归获取所有考勤数据
     * @param allAttendanceList
     * @param idList
     * @param startTime
     * @param endTime
     * @param offset
     */
    private void getAllAttendenceResult(List<OapiAttendanceListResponse.Recordresult> allAttendanceList,
                                                                                 List<String> idList, String startTime,
                                                                                 String endTime, long offset){

        try {
//            DingTalkClient client = new DefaultDingTalkClient("https://oapi.dingtalk.com/attendance/list");
//            OapiAttendanceListRequest request = new OapiAttendanceListRequest();
//            request.setWorkDateFrom(startTime);
//            request.setWorkDateTo(endTime);
//            request.setUserIdList(idList);
//            request.setOffset(offset);
//            request.setLimit(50L);
//            OapiAttendanceListResponse response = client.execute(request,access_token);

            Map<String, String> param = new HashMap<>();
            param.put("access_token", access_token);
            param.put("workDateFrom", startTime);
            param.put("workDateTo", endTime);
            param.put("userIdList", net.sf.json.JSONArray.fromObject(idList.toArray()).toString());
            param.put("offset", offset+"");
            param.put("limit", "50");
            String str = WebServiceUtil.httpPostWithJson(proxyip+"/attendance/list", param);
            TaobaoParser parser = new ObjectJsonParser(OapiAttendanceListResponse.class, true);
            OapiAttendanceListResponse  response= (OapiAttendanceListResponse)parser.parse(str, "dingtalk");

            if(response.isSuccess()){
                if(response.getRecordresult() != null && response.getRecordresult().size() > 0){
                    allAttendanceList.addAll(response.getRecordresult());
                }
                if(response.getHasMore()){
                    getAllAttendenceResult(allAttendanceList ,idList, startTime, endTime, offset+50l);
                }
            }else{
                throw new ApiException("获取数据失败");
            }
        } catch (ApiException e) {
            e.printStackTrace();
        }
    }

    /**
     * 处理获取的钉钉结果为我们需要的map
     * @param allAttendanceList
     * @param allList
     * @return
     */
    private List<String> handleDingResult(List<OapiAttendanceListResponse.Recordresult> allAttendanceList,
                                                       List<UTMap<String, Object>> allList,
                                          Map<String, String> dingUserMap){
        List<String> procInstIdList = new ArrayList<>();
        for(OapiAttendanceListResponse.Recordresult result : allAttendanceList){
            UTMap<String, Object> map = new UTMap<>();
            map.put("id", result.getId());
            map.put("groupId", result.getGroupId());
            map.put("planId", result.getPlanId());
            map.put("workDate", result.getWorkDate() != null ?
                    UTDate.dateToDateString(result.getWorkDate(), "yyyy-MM-dd") : null);
            map.put("dingDingId", result.getUserId());//用户id即为唯一的钉钉ID
            map.put("checkType", result.getCheckType());
            map.put("sourceType", result.getSourceType());
            map.put("timeResult", result.getTimeResult());
            map.put("locationResult", result.getLocationResult());
            map.put("baseCheckTime", result.getBaseCheckTime() != null ?
                    UTDate.dateToDateString(result.getBaseCheckTime(), "yyyy-MM-dd HH:mm:ss") : null);
            map.put("userCheckTime", result.getUserCheckTime() != null ?
                    UTDate.dateToDateString(result.getUserCheckTime(), "yyyy-MM-dd HH:mm:ss") : null);
            map.put("userId", dingUserMap.get(result.getUserId()));
//            map.put("isLegal", result.getIsLegal());
//            map.put("locationMethod", result.getLocationMethod());
//            map.put("deviceId", result.getDeviceId());
//            map.put("userAddress", result.getUserAddress());
//            map.put("gmtCreate", result.getGmtCreate());
//            map.put("gmtModified", result.getGmtModified());
//            map.put("outsideRemark", result.getOutsideRemark());
//            map.put("isSynchronized", 0);//默认是没有经过同步的数据
//            map.put("procInstId", result.getProcInstId());//关联的审批实例ID
//            if(result.getProcInstId() != null){//如果当前的审批实例id不等于空，说明存在审批实例数据
//                procInstIdList.add(result.getProcInstId());
//            }
            allList.add(map);
        }
        return procInstIdList;
    }


    /**
     * 处理考勤结果等数据
     * @param allDingList
     */
    private void mergeAttenceList(List<UTMap<String, Object>> allDingList, List<Map<String, Object>> mergeTimeList,
                                  Map<String, UTMap<String, Object>> allAttendanceMap){
        StringBuilder dingIds = new StringBuilder();//获取所有的钉钉id
        List<UTMap<String, Object>> onDutyList = new ArrayList<>();
        List<UTMap<String, Object>> offDutyList = new ArrayList<>();
        for(UTMap<String, Object> map : allDingList){
            //将该条数据设置为已经同步
            map.put("isSynchronized", 1);
            dingIds.append(map.get("dingDingId")+",");
            //将钉钉的数据分为签到和签退两个list，先签到，再签退，计算工时
            if("OnDuty".equals((String) map.get("checkType")) ){//!"SYSTEM".equals((String) map.get("sourceType")
                onDutyList.add(map);
            }else if("OffDuty".equals((String) map.get("checkType"))){//!"SYSTEM".equals((String) map.get("sourceType"))
                offDutyList.add(map);
            }
        }

        //处理冬令时和夏令时
        List<UTMap<String, Object>> seasonList = getSeason();
        String seasonType = FunctionEnum.SeasonType.summer.getCode();//默认夏令时

        //涉及联合考勤的数据
        Map<String, List<UTMap<String, Object>>> coalitionMap = new HashMap<>();
        Map<String, Object> param = new HashMap<>();
        //先判断上班打卡的数据
        if(onDutyList .size() > 0){
            //钉钉数据迭代
            Iterator<UTMap<String, Object>> onDutyIt = onDutyList.iterator();
            while(onDutyIt.hasNext()){
                UTMap<String, Object> onDutyMap = onDutyIt.next();
                //判断时令
                seasonType = checkSeason(LocalDateUtil.getLocalDatestamp((String)onDutyMap.get("workDate")), seasonList);
                this.season = seasonType;
                //用户的规则
                UTMap<String, Object> userConfig = userConfigDao.getUserConfigByUserId((String) onDutyMap.get("userId"));
                UTMap<String, Object> attendanceValue = allAttendanceMap.get((String) onDutyMap.get("dingDingId")+onDutyMap.get("workDate"));
                Map<String, Object> user = projectResDao.getResByUserId((String) onDutyMap.get("workDate"), (String) onDutyMap.get("userId"));
//                UTMap<String, Object> user = supplierEmpService.getSupplierEmpDetailedByUserId((String) onDutyMap.get("userId"));
                if (attendanceValue == null) {//表示根据钉钉的id+工作日没有找到考勤记录，说明没有生成考勤记录，我们手动生成记录
                    //这时还得判断这个打卡记录的时间是否在当前打卡记录的天数中，如果不相等，则找到那天的记录再进行判断添加
                    attendanceValue = attendanceService.getCurUserAttendance((String) onDutyMap.get("workDate"), (String) onDutyMap.get("userId"));
                    if(attendanceValue == null){
                        attendanceValue = new UTMap<>();
                        attendanceValue.put("projectId", user.get("projectId"));
                        attendanceValue.put("date", onDutyMap.get("workDate"));
                        attendanceValue.put("userId", onDutyMap.get("userId"));
                        attendanceValue.put("attendanceDateType",1);
                        attendanceValue.put("attType", 1);
                        if (userConfig != null) {//考勤规则不为空，则添加考勤规则数据
                            //如果用户的是不确定时间的考勤
//                        attendanceValue.put("attType", 0);
                            //联合考勤用户取联合考勤配置的部门，统计也按联合考勤配置的部门进行统计
                            attendanceValue.put("attendanceDateType", getAttendanceDateType(userConfig));
                        }
                        attendanceValue.put("supplierId", user.get("supplierId"));
                        attendanceValue.put("departId", user.get("departId"));
                        //先给默认值
                        attendanceValue.put("dateinStyle", -1);
                        attendanceValue.put("dateoutStyle", -1);
                        attendanceValue.put("attHours", 0d);//考勤工时(小时)
                        attendanceValue.put("attHoursSecond", 0d);//考勤工时(秒)
                        attendanceDao.add(attendanceValue);
                        allAttendanceMap.put((String) onDutyMap.get("dingDingId") + onDutyMap.get("workDate"), attendanceValue);//将数据塞回去
                }

                }
                //判断是否是最新，签到按最早的来，签退按最晚的来
                String dingTime = (String) onDutyMap.get("userCheckTime");//钉钉打卡时间
                String startTime = (String) attendanceValue.get("startTime");//库中打卡日期
//                attendanceValue.put("attType", 1);
                attendanceValue.put("supplierId", user.get("supplierId"));
                attendanceValue.put("departId", user.get("departId"));
                attendanceValue.put("attendanceDateType",1);
                if (userConfig != null) {//考勤规则不为空，则添加考勤规则数据
                    if ("2".equals(userConfig.get("attendanceDateType").toString())) {
                        attendanceValue.put("attType", 0);
                    }
//                    attendanceValue.put("attType", 0);
                    //联合考勤用户取联合考勤配置的部门，统计也按联合考勤配置的部门进行统计
                    attendanceValue.put("attendanceDateType", getAttendanceDateType(userConfig));
                }
                //判断是否未系统给定值，如果为系统给定值，则为未签到
                if("SYSTEM".equals((String) onDutyMap.get("sourceType"))){
                    mergeTimeList.add(attendanceValue);
                    continue;
                }

                if (startTime == null || UTDate.dateCompare(dingTime, startTime, "yyyy-MM-dd HH:mm:ss") || (dingTime != null && dingTime.equals(startTime.trim()))) {//为空或者钉钉日期更前，则修改打卡日期
                    attendanceValue.put("startTime", dingTime);
                    attendanceValue.put("dateinIp", onDutyMap.get("deviceId"));
//                    attendanceValue.put("dateinStyle",checkTimeResult((String) onDutyMap.get("timeResult")));
                    //如果是节假日，上班卡为正常的
                    if(1 == (Integer) attendanceValue.get("attType")){
                        attendanceValue.put("dateinStyle", 0);
                    }else{
                        attendanceValue.put("dateinStyle", attendanceService.checkDateinStyle(userConfig, UTDate.parseDateTime(dingTime), seasonType));
                    }
                    attendanceValue.put("dateinAddress", onDutyMap.get("userAddress"));
                    attendanceValue.put("dateinSourceType", onDutyMap.get("sourceType"));
//                    attendanceValue.put("dateinStyle", attendanceService.checkDateinStyle(userConfig, UTDate.parseDateTime(dingTime)));
//                        attendanceValue.put("startType", "1");//默认给1
                    mergeTimeList.add(attendanceValue);
                }
                //分拣联合考勤的数据
                if (attendanceValue.get("coalitionId") != null) {
                    List<UTMap<String, Object>> mapList = coalitionMap.get((String) attendanceValue.get("coalitionId"));
                    if (mapList == null) {
                        mapList = new ArrayList<>();
                    }
                    mapList.add(attendanceValue);
                    coalitionMap.put((String) attendanceValue.get("coalitionId"), mapList);
                }
            }
        }
        if(offDutyList.size() > 0){
            //钉钉数据迭代
            Iterator<UTMap<String, Object>> offDutyIt = offDutyList.iterator();
            while(offDutyIt.hasNext()){
                UTMap<String, Object> offDutyMap = offDutyIt.next();
                //判断时令
                seasonType = checkSeason(LocalDateUtil.getLocalDatestamp((String)offDutyMap.get("workDate")), seasonList);
                //用户的规则
                UTMap<String, Object> userConfig = userConfigDao.getUserConfigByUserId((String) offDutyMap.get("userId"));
                UTMap<String, Object> attendanceValue = allAttendanceMap.get((String) offDutyMap.get("dingDingId")+offDutyMap.get("workDate"));
//                UTMap<String, Object> user = supplierEmpService.getSupplierEmpDetailedByUserId((String) offDutyMap.get("userId"));
                Map<String, Object> user = projectResDao.getResByUserId((String) offDutyMap.get("workDate"), (String) offDutyMap.get("userId"));
                if (attendanceValue == null) {//表示根据钉钉的id+工作日没有找到考勤记录，说明没有生成考勤记录，我们手动生成记录
                    //这时还得判断这个打卡记录的时间是否在当前打卡记录的天数中，如果不相等，则找到那天的记录再进行判断添加
                    attendanceValue = attendanceService.getCurUserAttendance((String) offDutyMap.get("workDate"), (String) offDutyMap.get("userId"));
                    if(attendanceValue == null){
                        attendanceValue = new UTMap<>();
                        attendanceValue.put("projectId", user.get("projectId"));
                        attendanceValue.put("departId", user.get("departId"));
                        attendanceValue.put("supplierId", user.get("supplierId"));
                        attendanceValue.put("date", offDutyMap.get("workDate"));
                        attendanceValue.put("userId", offDutyMap.get("userId"));
                        attendanceValue.put("attType", 1);
                        attendanceValue.put("attendanceDateType",1);
                        if (userConfig != null) {//考勤规则不为空，则添加考勤规则数据
                            if ("2".equals(userConfig.get("attendanceDateType").toString())) {
                                attendanceValue.put("attType", 0);
                            }
//                        attendanceValue.put("attType", 0);
                            attendanceValue.put("coalitionId", userConfig.get("coalitionId"));
                            //联合考勤用户取联合考勤配置的部门，统计也按联合考勤配置的部门进行统计
                            attendanceValue.put("attendanceDateType", getAttendanceDateType(userConfig));
                        }
                        //先给默认值
                        attendanceValue.put("dateinStyle", -1);
                        attendanceValue.put("dateoutStyle", -1);
                        attendanceDao.add(attendanceValue);
                        allAttendanceMap.put((String) offDutyMap.get("dingDingId") + offDutyMap.get("workDate"), attendanceValue);//将数据塞回去
                    }
                }
//                attendanceValue.put("attType", 1);
                attendanceValue.put("supplierId", user.get("supplierId"));
                attendanceValue.put("attendanceDateType",1);
                attendanceValue.put("departId", user.get("departId"));
                if (userConfig != null) {//考勤规则不为空，则添加考勤规则数据
//                    attendanceValue.put("attType", 0);
                    attendanceValue.put("coalitionId", userConfig.get("coalitionId"));
                    //联合考勤用户取联合考勤配置的部门，统计也按联合考勤配置的部门进行统计
                    attendanceValue.put("attendanceDateType", getAttendanceDateType(userConfig));
                }
                //判断是否未系统给定值，如果为系统给定值，则为未签到
                if("SYSTEM".equals((String) offDutyMap.get("sourceType"))){
                    mergeTimeList.add(attendanceValue);
                    continue;
                }
                //判断是否是最新，签到按最早的来，签退按最晚的来
                String dingTime = (String) offDutyMap.get("userCheckTime");//钉钉打卡时间
                String startTime = (String) attendanceValue.get("startTime");//库中打卡日期
                String endTime = (String) attendanceValue.get("endTime");//签退时间
                if (endTime == null || UTDate.dateCompare(endTime,dingTime, "yyyy-MM-dd HH:mm:ss") || (dingTime != null && dingTime.equals(endTime.trim()))) {
                    attendanceValue.put("endTime", dingTime);
                    attendanceValue.put("dateoutIp", offDutyMap.get("deviceId"));
//                    attendanceValue.put("dateoutStyle",checkTimeResult((String) offDutyMap.get("timeResult")));
                    if(1 == (Integer) attendanceValue.get("attType")){//不是工作日，就把签退正常
                        attendanceValue.put("dateoutStyle", 0);
                    }else{
                        attendanceValue.put("dateoutStyle", attendanceService.checkDateoutStyle(userConfig, UTDate.parseDateTime(dingTime), seasonType, (String) offDutyMap.get("workDate")));
                    }

                    attendanceValue.put("dateoutAddress", offDutyMap.get("userAddress"));
                    attendanceValue.put("dateoutSourceType", offDutyMap.get("sourceType"));
//                    attendanceValue.put("dateoutStyle", attendanceService.checkDateoutStyle(userConfig, UTDate.parseDateTime(dingTime)));
//                        attendanceValue.put("startType", "1");//默认给1
                    //签退计算时间，
                    if (userConfig != null && startTime != null && 0 == (Integer) attendanceValue.get("attType")) {//配置了考勤规则的用户才去计算考勤工时
                        Map<String, Object> seconds = manHourStatisticService.calculateSecondsNew(startTime, dingTime, userConfig, seasonType);
                        double attHours = 0d;
                        long attHoursSecond = Long.valueOf(seconds.get("seconds").toString());
                        attHours = UTDate.transformSecondToHour(attHoursSecond, false);
                        attendanceValue.put("attHours", attHours);//考勤工时(小时)
                        attendanceValue.put("attHoursSecond", attHoursSecond);//考勤工时(秒)
                    }
                    mergeTimeList.add(attendanceValue);
                }
                //分拣联合考勤的数据
                if (attendanceValue.get("coalitionId") != null) {
                    List<UTMap<String, Object>> mapList = coalitionMap.get((String) attendanceValue.get("coalitionId"));
                    if (mapList == null) {
                        mapList = new ArrayList<>();
                    }
                    mapList.add(attendanceValue);
                    coalitionMap.put((String) attendanceValue.get("coalitionId"), mapList);
                }
            }
        }
        //处理联合考勤的数据
        //根据钉钉id查找联合考勤的数据
        param.clear();
        param.put("dingDingIds", dingIds.toString());
        List<UTMap<String, Object>> colitionList = coalitionConfigDao.getCoalitionConfigs(param);
        //要修改时间的数据
        if (colitionList != null && coalitionMap.size() > 0) {
            for (UTMap<String, Object> map : colitionList) {
                List<UTMap<String, Object>> attendList = coalitionMap.get(map.get("id"));
                if (attendList != null && attendList.size() > 0) {
                    Date startTime = null;
                    Date endTime = null;
                    //考勤时长
                    double attHours = 0d;
                    long attHoursSecond = 0l;
                    for (Map<String, Object> attendMap : attendList) {
                        if (attendMap.get("startTime") != null) {
                            if (startTime == null || startTime.after((Date) attendMap.get("startTime"))) {
                                startTime = (Date) attendMap.get("startTime");
                            }
                        }
                        if (attendMap.get("endTime") != null) {
                            if (endTime == null || endTime.before((Date) attendMap.get("endTime"))) {
                                endTime = (Date) attendMap.get("startTime");
                            }
                            //结束时间不为空，说明已经计算过时间了，直接拿来用就好了，并得出结果
                            if (attendMap.get("attHours") != null) {
                                attHoursSecond = attHoursSecond < (long) attendMap.get("attHoursSecond") ?
                                        (long) attendMap.get("attHoursSecond") : attHoursSecond;
                            }

                        }
                    }
                    attHours = UTDate.transformSecondToHour(attHoursSecond, false);
                    for (Map<String, Object> attendMap : attendList) {//再循环一次修改日期
                        attendMap.put("attHours", attHours);
                        attendMap.put("attHoursSecond", attHoursSecond);
                    }
                    mergeTimeList.addAll(attendList);
                }
            }
        }
    }



    /**
     * 获取还未入库的审批并入库
     * @param idList
     */
    private List<Map> getAndAddNonExistent(List<String> idList, String startTime, String endTime){
        //这时候去查询单个审批实例id
        List<Map> approveList = new ArrayList<>();
        List<Map<String, Object>> overTimeList = getOverTimeApproveByTime(startTime, endTime);
        List<Map<String, Object>> vacationList = getVacationApproveByTime(startTime, endTime);
       if(overTimeList != null && overTimeList.size() > 0){
           for(Map<String, Object> map : overTimeList){
               idList.add((String) map.get("processInstanceId"));
           }
       }
        if(vacationList != null && vacationList.size() > 0){
            for(Map<String, Object> map : vacationList){
                idList.add((String) map.get("processInstanceId"));
            }
        }
        if(idList != null && idList.size() > 0){
            idList = CommonUtils.unique(idList);
            Map<String, Object> param = new HashMap<>();
            param.put("ids", CommonUtils.getSqlId(String.join(",",idList)));
            List<UTMap<String, Object>> allExistentList =  dingDingApproveDao.getListMap(param);
            if(allExistentList != null && allExistentList.size() > 0){
                for(UTMap<String, Object> map : allExistentList){
                    idList.remove((String) map.get("processInstanceId"));
                }
            }
            if(idList != null && idList.size() > 0){

                for(String id : idList){
                    approveList.add(getApproveDetail(id));
                }
            }
        }
        //加班审批单
        if(approveList.size() > 0){
            dingDingApproveDao.adds(approveList);
        }
        return approveList;
    }

    private OapiProcessinstanceGetResponse.ProcessInstanceTopVo getApprove(String instanceId){
        try {
//            DingTalkClient client = new DefaultDingTalkClient("https://oapi.dingtalk.com/topapi/processinstance/get");
//            OapiProcessinstanceGetRequest request = new OapiProcessinstanceGetRequest();
//            request.setProcessInstanceId(instanceId);
//            OapiProcessinstanceGetResponse response = client.execute(request,access_token);

            Map<String, String> param = new HashMap<>();
            param.put("access_token", access_token);
            param.put("process_instance_id", instanceId);
            String str = WebServiceUtil.invokeWS(proxyip+"/topapi/processinstance/get", param);
            TaobaoParser parser = new ObjectJsonParser(OapiProcessinstanceGetResponse.class, true);
            OapiProcessinstanceGetResponse  response= (OapiProcessinstanceGetResponse)parser.parse(str, "dingtalk");

            if(!response.isSuccess()){
                throw new ApiException("获取审批实例失败:"+instanceId+","+response.getErrmsg());
            }
            if(response.getProcessInstance() != null){
                return response.getProcessInstance();
            }
        } catch (ApiException e) {
            e.printStackTrace();
        }
        return null;
    }

    private Map<String, Object> getApproveDetail(String instanceId){
        OapiProcessinstanceGetResponse.ProcessInstanceTopVo vo = getApprove(instanceId);
        if(vo != null){
            Map<String, Object> map = new HashMap<>();
            map.put("processInstanceId", instanceId);
            map.put("title", vo.getTitle());
            map.put("originatorUserId", vo.getOriginatorUserid());
            map.put("status", getStatus(vo));
//            map.put("approverUserIds", vo.getApproverUserids() != null && vo.getApproverUserids().size() > 0 ?
//                    StringUtils.join(vo.getApproverUserids(), ",") : null);
            map.put("ccUserIds", vo.getCcUserids() != null && vo.getCcUserids() .size() > 0 ?
                    StringUtils.join(vo.getCcUserids(),",") : null);
            map.put("result", vo.getResult());
            map.put("bizAction", vo.getBizAction());
            map.put("createTime", LocalDateUtil.toTimeString(vo.getCreateTime().getTime()));
            map.put("finishTime",vo.getFinishTime() != null ? LocalDateUtil.toTimeString(vo.getFinishTime().getTime()): null);
            map.put("attachedProcessInstanceIds", vo.getAttachedProcessInstanceIds() != null && vo.getAttachedProcessInstanceIds().size() > 0 ?
                    StringUtils.join(vo.getAttachedProcessInstanceIds(), ",") : null);
            //是否是请假，请假的类别是什么
            List<OapiProcessinstanceGetResponse.FormComponentValueVo> formVoList= vo.getFormComponentValues();
            String[] timeArr = null;//从得到的json字符串来进行分析得到结果
            Map<String, String> resultMap = null;
            if(vo.getTitle().indexOf("请假") >= 0){//表示请假。我们获取请假的类型
                map.put("approveType", 1);
                if(formVoList.size() == 3){
                    timeArr =StringUtils.split(formVoList.get(0).getValue(),"\\[,\\]\"");
                    map.put("vacationType", getVacationType(timeArr[4]));
                    map.put("reason", formVoList.get(1).getValue());
                }else{
                    timeArr =StringUtils.split(formVoList.get(1).getValue(),"\\[,\\]\"");
                    map.put("vacationType", getVacationType(formVoList.get(0).getValue()));
                    map.put("reason", formVoList.get(2).getValue());
                }
               //请假事由
                map.put("startTime", changeTime(timeArr[0]));
                map.put("endTime", changeTimeEndTime(timeArr[1]));
                //时长
                map.put("duration", getDuration(timeArr));
                //修改startTime和endTime
                changeStartTimeAndEnd(map, timeArr[0], timeArr[1]);
            }else if(vo.getTitle().indexOf("加班") >=0){//表示加班
//                timeArr = StringUtils.split(formVoList.get(0).getValue(),"\\[,\\]\"");
                resultMap = getUseInfo(formVoList.get(0).getValue());
                map.put("approveType", 2);
                map.put("startTime", resultMap.get("startTime"));
                map.put("endTime", resultMap.get("finishTime"));
                map.put("duration", resultMap.get("duration"));
                map.put("reason", formVoList.size() > 1 ? formVoList.get(1).getValue() : null);
            }else if(vo.getTitle().indexOf("补卡申请") >=0){
                Map<String, Object> cardMap = JSONObject.parseObject(formVoList.get(2).getExtValue(), Map.class);
                map.put("planText", cardMap.get("planText"));
                if(cardMap.get("workDate") != null){
                    map.put("presentDate", LocalDateUtil.toTimeString((Long) cardMap.get("workDate")));
                }else{
                    map.put("presentDate", LocalDateUtil.toTimeStringStr(cardMap.get("timeStamp").toString()).split(" ")[0]);
                }
                map.put("userCheckTime", LocalDateUtil.toTimeStringStr(cardMap.get("userCheckTime").toString()));
            }
//            else if(vo.getTitle().indexOf("出差") >= 0){//表示出差
//                map.put("approveType", 3);
//                JSONArray myJson = JSONArray.parseArray(formVoList.get(0).getValue());
//                JSONArray s = (JSONArray) ((JSONObject)myJson.get(0)).get("rowValue");
//                timeArr =  StringUtils.split(((JSONObject)s.get(1)).get("value").toString(),"\\[,\\]\"");
//                map.put("startTime", timeArr[0]);
//                map.put("endTime", timeArr[1]);
//            }
            return map;
        }

        return null;
    }
    /**
     * 处理所有的审批分拣到数据库中
     * @param allApproveList
     */
    @Override
    public void mergeApproves()throws EscServiceException {
        //先把所有的数据
        //获取所有的数据，
        Map<String, Object> params = new HashMap<>();
        //params.put("notDone", 1);//表示查询还没有审批通过的数据
        List<UTMap<String, Object>> allApproveList = dingDingApproveDao.getDetailListMap(params);
        if(allApproveList == null || allApproveList.size() <= 0){
            return;
        }
        List<Map<String, Object>> leaveList = new ArrayList<>();//请假
        List<String> leaveIds = new ArrayList<>();//请假的id
        Map<String, Map<String, Object>>  leaveIdMap = new HashMap<>();//请假的map
        List<Map<String, Object>> overtimeList = new ArrayList<>();//加班
        List<String> overtimeIds = new ArrayList<>();//加班的id
        Map<String, Map<String, Object>> overtimeIdMap = new HashMap<>();//加班的map
        List<Map<String, Object>> businessList = new ArrayList<>();//出差
        List<String> businessIds = new ArrayList<>();//出差的id
        Map<String, Map<String, Object>> businessIdMap = new HashMap<>();//出差的map
        for(Map<String, Object> map : allApproveList){
            if(map.get("approveType") == null ){
                continue;
            }
            if(1 == (int) map.get("approveType") || 8 == (int) map.get("approveType")){//请假
                leaveList.add(map);
                leaveIds.add((String) map.get("processInstanceId"));
            }else if(2 == (int)map.get("approveType")){//加班
                overtimeList.add(map);
                overtimeIds.add((String) map.get("processInstanceId"));
            }else if(3 ==(int)map.get("approveType")){//出差
                businessList.add(map);
                businessIds.add((String) map.get("processInstanceId"));
            }
        }

        //获取请假
        params.clear();
        params.put("ids", CommonUtils.getSqlId(String.join(",", leaveIds)));
        List<UTMap<String, Object>> leaveMapList = vacationDao.getMapList(params);
        if(leaveMapList != null && leaveMapList.size() > 0){
            for(UTMap<String, Object> leaveMap : leaveMapList){
                leaveIdMap.put((String) leaveMap.get("instanceId"), leaveMap);
            }
        }

        //获取加班
        params.clear();
        params.put("ids", CommonUtils.getSqlId(String.join(",", overtimeIds)));
        List<UTMap<String, Object>> overtimeMapList = overtimeDao.getListMap(params);
        if(overtimeMapList != null && overtimeMapList.size() > 0){
            for(UTMap<String, Object> overtimeMap : overtimeMapList){
                overtimeIdMap.put((String) overtimeMap.get("instanceId"), overtimeMap);
            }
        }

        //获取出差
        params.clear();
        params.put("ids", CommonUtils.getSqlId(String.join(",", businessIds)));
        List<UTMap<String, Object>> businessMapList = travelDao.getMapList(params);
        if(businessMapList != null && businessMapList.size() > 0){
            for(UTMap<String, Object> businessMap : businessMapList){
                businessIdMap.put((String) businessMap.get("instanceId"), businessMap);
            }
        }
        Map<String, Object> param = new HashMap<>();

        if(leaveList.size() > 0){//处理请假
            //此时数据量会比较少，我们可以循环处理
            List<Map<String, Object>> updateLeaveList = new ArrayList<>();
            //处理冬令时和夏令时
            List<UTMap<String, Object>> seasonList = getSeason();
            String seasonType = FunctionEnum.SeasonType.summer.getCode();//默认夏令时
            List<Map<String, Object>> updateMaps = new ArrayList<>();
            List<Map> updateDetails = new ArrayList<>();
            String workDate = null;
            for(Map<String, Object> map : leaveList){
                param.put("instanceId", map.get("processInstanceId"));
                Map<String, Object> mergeMap = leaveIdMap.get((String) map.get("processInstanceId"));
                if(mergeMap == null){//不存在时，添加
                    if(map.get("userId") == null){
                        continue;
                    }
                    Map<String, Object> leaveMap = new HashMap<>();
                    leaveMap.put("dingStatus", (String) map.get("status"));//钉钉的状态
                    leaveMap.put("status", mergeStatus((String) map.get("status"), (String) map.get("result")));
                    leaveMap.put("instanceId", map.get("processInstanceId"));
                    leaveMap.put("code", IDGenerationManager.nextId("vacation"));
                    leaveMap.put("presentDate",map.get("createTime"));
                    leaveMap.put("beginTime", map.get("startTime"));
                    leaveMap.put("endTime", map.get("endTime"));
                    leaveMap.put("duration", map.get("duration"));
                    //先添加一下
                    vacationDao.add(leaveMap);
                    //根据钉钉Id获取用户id
                    UTMap<String, Object> userConfig = userConfigDao.getUserConfigByUserId((String) map.get("userId"));
                    List<Map<String, Object>> hoursList = manHourStatisticService.calculateVacationSeconds(map.get("startTime").toString(), map.get("endTime").toString(), userConfig);
                    BigDecimal totalHour = new BigDecimal(0);
                    if(hoursList != null && hoursList.size() > 0){
                        for (Map<String, Object> hour : hoursList) {
                            Long second = (Long) hour.get("seconds");
                            totalHour = BigDecimal.valueOf(UTDate.transformSecondToHour(second, true))
                                    .add(totalHour);
                            Map<String, Object> detail = new HashMap<String, Object>();
                            detail.put("infoId", leaveMap.get("id"));
                            detail.put("presentDate", hour.get("beginTime"));
                            detail.put("hours", UTDate.transformSecondToHour(second, true));
                            detail.put("beginTime", hour.get("beginTime"));
                            detail.put("endTime", hour.get("endTime"));
                            detail.put("dateType", hour.get("dateType")); // 记录节假日类型
                            detail.put("coalitionId", hour.get("coalitionId")); // 记录节假日类型
                            detail.put("createUserId", map.get("userId"));
                            //根据请假的当天天数，和请假开始结束时间以及用户配置及时令规则
                            if(userConfig != null && "COMPLETED".equals((String)map.get("status"))){//完成才需要判断
                                //判断时令
                                workDate = ((String)detail.get("presentDate")).split(" ")[0];
                                seasonType = checkSeason(LocalDateUtil.getLocalDatestamp(workDate), seasonList);
                                Map<String, Object> attMap = changeAttendanceStatus(detail,userConfig, workDate, seasonType);
                                if(attMap != null){
                                    updateMaps.add(attMap);
                                }

                            }
                            updateDetails.add(detail);
                        }
                    }
                    leaveMap.put("hours", totalHour);//最后时间结果
                    leaveMap.put("type", map.get("vacationType"));//事假和调休
                    leaveMap.put("reason", map.get("reason"));
                    leaveMap.put("supplierId",map.get("supplierId"));//
                    leaveMap.put("supplierName", map.get("supplierName"));
                    leaveMap.put("orgId", map.get("orgId"));
                    leaveMap.put("orgName", map.get("orgName"));
                    leaveMap.put("submitUser", map.get("nameAndCode"));
                    leaveMap.put("submitTime", map.get("createTime"));
                    leaveMap.put("createTime", map.get("createTime"));
                    leaveMap.put("createUserId", map.get("userId"));
                    leaveMap.put("updateTime", map.get("createTime"));
                    leaveMap.put("updateUser",  map.get("nameAndCode"));
                    vacationDao.updateById(leaveMap);
                }else if(!((String) map.get("status")).equals((String)mergeMap.get("dingStatus"))){//如果存在，则判断是否状态发生了改变
                    mergeMap.put("dingStatus", mergeDingStatus(map));
                    mergeMap.put("status", mergeStatus((String) map.get("status"),(String) map.get("result")));
                    updateLeaveList.add(mergeMap);
                    if("COMPLETED".equals((String)map.get("status"))){//如果变更后，状态为已完成，则需要修改考勤的记录
                        //根据钉钉Id获取用户id
                        UTMap<String, Object> userConfig = userConfigDao.getUserConfigByUserId((String) map.get("userId"));
                        param.clear();
                        param.put("infoId", mergeMap.get("id"));
                        List<UTMap<String, Object>> vacationDetailList = vacationDetailDao.getListMaps(param);
                        if(vacationDetailList != null){
                            for(Map<String, Object> detail : vacationDetailList){
                                //根据请假的当天天数，和请假开始结束时间以及用户配置及时令规则
                                if(userConfig != null){
                                    //判断时令
                                    workDate = ((String)detail.get("presentDate")).split(" ")[0];
                                    seasonType = checkSeason(LocalDateUtil.getLocalDatestamp(workDate), seasonList);
                                    Map<String, Object> attMap = changeAttendanceStatus(detail,userConfig, workDate, seasonType);
                                    if(attMap != null){
                                        updateMaps.add(attMap);
                                    }
                                }
                            }
                        }
                    }
                    //再修改detail的值
                    vacationDetailDao.changeDingStatus((String) map.get("status"), (String) map.get("infoId"));
                }

            }
            //修改请假的值
            if(updateLeaveList.size() > 0){
                vacationDao.batchUpdate(updateLeaveList, new String[]{"id"});
            }

            if(updateDetails.size() > 0){
                vacationDetailDao.adds(updateDetails);
            }
            if(updateMaps.size() > 0){
                attendanceDao.batchUpdate(updateMaps, new String[]{"id"});
            }
        }
        if(overtimeList.size() > 0){//处理加班
            //加班处理
            List<Map<String, Object>> updateOvertimeList = new ArrayList<>();
            for(Map<String, Object> map : overtimeList){
                Map<String, Object> mergeMap =overtimeIdMap.get((String) map.get("processInstanceId"));
                if(mergeMap == null){//加班数据不存在，则添加
                    if(map.get("userId") == null){
                        continue;
                    }
                    Map<String, Object> overtimeMap = new HashMap<>();
                    overtimeMap.put("dingStatus", mergeDingStatus(map));//钉钉的状态
                    overtimeMap.put("status", mergeStatus((String) map.get("status"), (String) map.get("result")));
                    overtimeMap.put("instanceId", map.get("processInstanceId"));
                    overtimeMap.put("code", IDGenerationManager.nextId("overtime"));
//                    overtimeMap.put("presentDate", )
                    overtimeMap.put("presentDate",map.get("startTime"));
                    overtimeMap.put("beginTime",map.get("startTime"));
                    overtimeMap.put("endTime", map.get("endTime"));
                    overtimeMap.put("reason", map.get("reason"));
                    overtimeMap.put("supplierId", map.get("supplierId"));
                    overtimeMap.put("supplierName", map.get("supplierName"));
                    overtimeMap.put("orgId", map.get("orgId"));
                    overtimeMap.put("orgName", map.get("orgName"));
                    overtimeMap.put("submitUser", map.get("nameAndCode"));
                    overtimeMap.put("submitTime", map.get("createTime"));
                    overtimeMap.put("createTime", map.get("createTime"));
                    overtimeMap.put("createUserId", map.get("userId"));
                    overtimeMap.put("updateTime", map.get("createTime"));
                    overtimeMap.put("updateUser",  map.get("nameAndCode"));
                    //先添加一下
                    overtimeDao.add(overtimeMap);
                    UTMap<String, Object> userConfig = userConfigDao.getUserConfigByUserId((String) map.get("userId"));
                    List<Map<String, Object>> hoursList = manHourStatisticService.calculateOvertimeHoursDays(map.get("startTime").toString(), map.get("endTime").toString(), userConfig, (String) map.get("userId"));
                    BigDecimal totalHour = new BigDecimal(0);
                    BigDecimal actTotalHour = new BigDecimal(0);
                    if(hoursList != null && hoursList.size() > 0){
                        for (Map<String, Object> hour : hoursList) {
                            Map<String, Object> detail = new HashMap<String, Object>();
                            detail.put("infoId", overtimeMap.get("id"));
                            detail.put("presentDate", hour.get("beginTime"));
                            detail.put("beginTime", hour.get("beginTime"));
                            detail.put("endTime", hour.get("endTime"));
//                            detail.put("dateType", hour.get("dateType")); // 记录节假日类型
                            detail.put("createUserId", map.get("userId"));
                            detail.put("actBeginTime", hour.get("actBeginTime"));
                            detail.put("actEndTime", hour.get("actEndTime"));
                            detail.put("hours", hour.get("hours"));
                            detail.put("actualHours", hour.get("actualHours"));
                            if(hour.get("hours") != null){
                                totalHour = BigDecimal.valueOf((Double) hour.get("hours")).add(totalHour);
                            }
                            if(hour.get("actualHours") != null){
                                actTotalHour = BigDecimal.valueOf((Double) hour.get("actualHours")).add(actTotalHour);
                            }
                            overTimeDetailDao.add(detail);
                        }
                    }
//                    overtimeMap.put("hours", totalHour);
                    overtimeMap.put("hours", changeTimeToHours((String) map.get("duration")));
                    overtimeMap.put("actualHours", actTotalHour);
                    overtimeDao.updateById(overtimeMap);
                }else if(!((String) map.get("status")).equals((String)mergeMap.get("dingStatus"))) {//如果存在，则判断是否状态发生了改变
                    mergeMap.put("dingStatus", mergeDingStatus(map));
                    mergeMap.put("status", mergeStatus((String) map.get("status"), (String) map.get("result")));
                    updateOvertimeList.add(mergeMap);
                }
                //修改加班的值
                overtimeDao.batchUpdate(updateOvertimeList, new String[]{"id"});
            }
        }
        if(businessList.size() > 0){//处理出差

        }
    }
    /**
     * 添加钉钉数据
     * @param list
     */
    private List<String> addDingDingInfo( List<OapiAttendanceListRecordResponse.Recordresult> list){
        List<Map> listMap = new ArrayList<>();
        List<String> procInstIdList = new ArrayList<>();
        for(OapiAttendanceListRecordResponse.Recordresult result : list){
            Map<String, Object> map = new HashMap<>();
            //map.put("id", result.getId());
            map.put("groupId", result.getGroupId());
            map.put("planId", result.getPlanId());
            map.put("workDate", UTDate.dateToDateString(result.getWorkDate()));
            map.put("dingDingId", result.getUserId());//用户id即为唯一的钉钉ID
            map.put("checkType", result.getCheckType());
            map.put("sourceType", result.getSourceType());
            map.put("timeResult", result.getTimeResult());
            map.put("locationResult", result.getLocationResult());
            map.put("baseCheckTime",result.getBaseCheckTime() != null ?
                    UTDate.dateToDateString(result.getBaseCheckTime(),"yyyy-MM-dd HH:mm:ss") : null);
            map.put("userCheckTime", result.getUserCheckTime()!= null ?
                    UTDate.dateToDateString(result.getUserCheckTime(), "yyyy-MM-dd HH:mm:ss") : null);
            map.put("isLegal", result.getIsLegal());
            map.put("locationMethod", result.getLocationMethod());
            map.put("deviceId", result.getDeviceId());
            map.put("userAddress", result.getUserAddress());
            map.put("gmtCreate", result.getGmtCreate() != null ?
                    UTDate.dateToDateString(result.getGmtCreate(), "yyyy-MM-dd HH:mm:ss"): null);
            map.put("gmtModified", result.getGmtCreate() != null ?
                    UTDate.dateToDateString(result.getGmtModified(), "yyyy-MM-dd HH:mm:ss"): null);
//            map.put("outsideRemark", result.getOutsideRemark());
            map.put("isSynchronized", 0);//默认是没有经过同步的数据
            map.put("procInstId", result.getProcInstId());//关联的审批实例ID
            map.put("approveId", result.getApproveId());
            if(result.getProcInstId() != null){//如果当前的审批实例id不等于空，说明存在审批实例数据
                procInstIdList.add(result.getProcInstId());
            }
            listMap.add(map);
        }
        dingDingInfoDao.adds(listMap);
        return procInstIdList;
    }


    /**
     * 获取考勤方式:(1.确定时间，2.不确定时间统计考勤次数,3.不确定时间统计考勤时间)
     * @param userConfig
     * @return
     */
    private int getAttendanceDateType(UTMap<String, Object> userConfig){
        //考勤方式:(1.确定时间，2.不确定时间)
        String attendanceDateType = userConfig.get("attendanceDateType").toString();
        if("1".equals(attendanceDateType)){
            return 1;
        }else{
            //不确定时间的考勤统计方式：（1.统计考勤次数；2.统计考勤时间（单位是小时））
            String attendanceType = userConfig.get("attendanceType").toString();
            if("1".equals(attendanceType)){
                return 2;//2.不确定时间统计考勤次数
            }else{
                return 3;//3.不确定时间统计考勤时间)
            }
        }
    }

    /**
     * 获取请假类型
     * @param name
     * @return
     */
    private int getVacationType(String name){
        if("年假".equals(name)){
            return 1;
        }else if("工龄假".equals(name)){
            return 2;
        }else if("事假".equals(name)){
            return 3;
        }else if("产假".equals(name)){
            return 4;
        }else if("丧假".equals(name)){
            return 5;
        }else if("病假".equals(name)){
            return 6;
        }else if("婚假".equals(name)){
            return 7;
        }else if("调休".equals(name)){
            return 8;
        }else if("陪产假".equals(name)){
            return 10;
        }else if("路途假".equals(name)){
            return 11;
        }else{//其他
            return 9;
        }
    }
    /**
     * 判断冬令时或者夏令时 默认返回夏令时
     * @param time
     * @return
     */
    public String checkSeason(long time, List<UTMap<String, Object>> list){

        if(list == null || list.size() <= 0){
            return FunctionEnum.SeasonType.summer.getCode();
        }
        //list已经按年份升序
        for(int i = 0; i < list.size(); i++){
            UTMap<String, Object> map = list.get(i);
            if(time < (long)map.get("summerTimeSec")){//小于夏令时开始时间，则为冬令时
                return FunctionEnum.SeasonType.winter.getCode();
            }else if(map.get("winterTimeSec") != null && time  <  (long)map.get("winterTimeSec")){//小于冬令时开始时间，则为夏令时
                return FunctionEnum.SeasonType.summer.getCode();
            }
            if(i == list.size()-1){//当为最后一个list时，且time > 冬令时，
                if(map.get("winterTimeSec") == null){//冬令时开始时间没填，说明 是夏令时
                    return FunctionEnum.SeasonType.summer.getCode();
                }
                return FunctionEnum.SeasonType.winter.getCode();
            }
        }
        return FunctionEnum.SeasonType.summer.getCode();
    }

    @Override
    public List<Map> getAndAddNonExistent(String startTime, String endTime) {
        //这时候去查询单个审批实例id
        List<String> idList = new ArrayList<>(); //关联的审批
        List<Map> approveList = new ArrayList<>();
        List<Map<String, Object>> overTimeList = getOverTimeApproveByTime(startTime, endTime);
        List<Map<String, Object>> vacationList = getVacationApproveByTime(startTime, endTime);
        if(overTimeList != null && overTimeList.size() > 0){
            for(Map<String, Object> map : overTimeList){
                idList.add((String) map.get("processInstanceId"));
            }
        }
        if(vacationList != null && vacationList.size() > 0){
            for(Map<String, Object> map : vacationList){
                idList.add((String) map.get("processInstanceId"));
            }
        }
        if(idList != null && idList.size() > 0){
            idList = CommonUtils.unique(idList);
            Map<String, Object> param = new HashMap<>();
            param.put("ids", CommonUtils.getSqlId(String.join(",",idList)));
            List<UTMap<String, Object>> allExistentList =  dingDingApproveDao.getListMap(param);
            if(allExistentList != null && allExistentList.size() > 0){
                for(UTMap<String, Object> map : allExistentList){
                    idList.remove((String) map.get("processInstanceId"));
                }
            }
            if(idList != null && idList.size() > 0){

                for(String id : idList){
                    approveList.add(getApproveDetail(id));
                }
            }
        }
        //加班审批单
        if(approveList.size() > 0){
            dingDingApproveDao.adds(approveList);
        }
        return approveList;
    }

    @Override
    public boolean initAttendance(String startTime, String endTime, List<String> userIds, String dingIds, boolean daylily, boolean isFinal) {
        if(isFinal){//如果是最后的一个循环，需要注意，我们在手动同步时，加了结束日加了一天，需要再这里减去一天
            //这里属于值传递，不会影响后面endTime的数据
            endTime = LocalDateUtil.addDays(endTime, -1l);
        }
        //先删除这段时间内的所有考勤数据
        String userIdSqlstr = CommonUtils.getSqlId(String.join(",", userIds));

        //删除审批等数据
        overTimeDetailDao.deleteByTime(startTime,endTime,userIdSqlstr);
        vacationDetailDao.deleteByTime(startTime,endTime,userIdSqlstr);
        overtimeDao.deleteByTime(startTime,endTime,userIdSqlstr);
        vacationDao.deleteByTime(startTime,endTime,userIdSqlstr);
        if(dingIds != null){
            String dingIdSqlstr = CommonUtils.getSqlId(dingIds);
            dingDingApproveDao.deleteByTime(startTime,endTime,dingIdSqlstr);
        }
        //获取两个时间差
        LocalDateTime startDateTime = LocalDateUtil.toLocalDateTime(startTime);
        LocalDateTime endDateTime = LocalDateUtil.toLocalDateTime(endTime);
        LocalDate startDate = LocalDate.of(startDateTime.getYear(),startDateTime.getMonth(),startDateTime.getDayOfMonth());
        LocalDate endDate = LocalDate.of(endDateTime.getYear(),endDateTime.getMonth(),endDateTime.getDayOfMonth());
        Date date = null;
        if(!daylily){//每天的定时任务，就不删除,也不添加基础考勤
            attendanceDao.deleteByTime(startTime, endTime, userIdSqlstr);
            while(true){//
                Map<String, Object> map = new HashMap<>();
                date = Date.from(startDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
                //获取指定日期的节假日配置
                UTMap<String, Object> festival = festivalDao.getByDate(LocalDateUtil.localDateToStr(startDate));
                List<UTMap<String, Object>> userConfigs = null;
                if(festival != null){
                    //节假日类型：1.工作日  2.周末  3.法定节假日  4.调休  5.其他. 工作日为1，周末为2，法定节假日为3 已经写入代码中，不可更改
                    String festivalType = festival.get("festivalType").toString();
                    if("1".equals(festivalType)){
                        //查询确认时间的考勤规则数据
                        userConfigs = userConfigDao.getAttUserConfigByAttendanceDateType(date);
                    }else if("2".equals(festivalType)){
                        //查询指定日期需要考勤的考勤规则
                        userConfigs = userConfigDao.getAttUserConfig(date);
                    }else{
                        //查询确认时间，并且考勤时间点为周一到周日的考勤规则数据(如果考勤规则配置为周一至周日均需考勤，则为全年无休情况，不考虑节假日等因素，全年生成考勤)
                        userConfigs = userConfigDao.getAttUserConfigByAttendanceDate(date);
                    }
                }else{//没有节假日配置表示正常工作日
                    //查询指定日期需要考勤的考勤规则
                    userConfigs = userConfigDao.getAttUserConfig(date);
                }

                if(userConfigs != null){
                    List<Map> tempMaps = AttendanceSyncUtil.addAttendanceSync(userConfigs,date);
                    if(tempMaps.size() > 0){//每一天添加
                        attendanceDao.adds(tempMaps);
                    }

//                for (UTMap<String, Object> userConfig : userConfigs) {
//                    try{
//                        map = addAttendance(date, userConfig);
//                        if(map != null){
//                            maps.add(map);
//                        }
//                    }catch(Exception ex){
//                        ex.printStackTrace();
//                        logger.error("考勤数据生成失败，userId="+userConfig.get("userId"));
//                    }
//
//                }
                }
                //末尾的时候，加一天
                startDate = startDate.plusDays(1);
                if(startDate.isAfter(endDate)){//大于不生成了,跳出循环
                    break;
                }
            }
        }

        //批量生成考勤数据
        return true;
    }
    @Override
    public boolean leadingInExcel(String filePath)throws Exception {
        List<UTMap<String, Object>> leadinginList = new ArrayList<UTMap<String,Object>>();
        boolean flag = true;
        // 根据路径 获取工作薄
        Sheet sheet = UTExcel.getSheets(filePath)[1];//获取每日统计的值
        //获取统计的年份
        Row row1 = sheet.getRow(0);
        String[] times = row1.getCell(0).getStringCellValue().split(" |：");
        String startTime = times[2]+" 00:00:00";//开始时间
        String endTime = times[4]+" 23:59:59";//结束时间
        Row row=sheet.getRow(2);//获取title
        //根据title我们主要获取打卡记录和审批单
        int rowNum = sheet.getLastRowNum();
        int cellNum = row.getLastCellNum();
        Map<String, Integer> titleNumMap = new HashMap<>();
        int lastTimeNum = 0;
        for(int i = 0; i < row.getLastCellNum(); i++){
            //取第一二个打卡时间，为上下班打卡记录
            if("打卡时间".equals(row.getCell(i).getStringCellValue())){
                lastTimeNum = i;
                if(titleNumMap.get("上班卡") == null){
                    titleNumMap.put("上班卡", i);
                }else if(titleNumMap.get("下班卡") == null){
                    titleNumMap.put("下班卡", i);
                }
            } else if("关联的审批单".equals(row.getCell(i).getStringCellValue())){
                titleNumMap.put("审批单", i);
            } else if("工号".equals(row.getCell(i).getStringCellValue())){
                titleNumMap.put("工号", i);
            } else if("日期".equals(row.getCell(i).getStringCellValue())){
                titleNumMap.put("日期", i);
            }
        }
        row=sheet.getRow(3);//获取title
        for(int i = 0; i < row.getLastCellNum(); i++){
            //取第一二个打卡时间，为上下班打卡记录
            if("打卡时间".equals(row.getCell(i).getStringCellValue())){
                lastTimeNum = i;
                if(titleNumMap.get("上班卡") == null){
                    titleNumMap.put("上班卡", i);
                }else if(titleNumMap.get("下班卡") == null){
                    titleNumMap.put("下班卡", i);
                }
            } else if("关联的审批单".equals(row.getCell(i).getStringCellValue())){
                titleNumMap.put("审批单", i);
            } else if("工号".equals(row.getCell(i).getStringCellValue())){
                titleNumMap.put("工号", i);
            } else if("日期".equals(row.getCell(i).getStringCellValue())){
                titleNumMap.put("日期", i);
            }
        }
        titleNumMap.put("末下班卡", lastTimeNum);//最后一个打卡时间，即下班卡
        //为获取打卡地址
        Map<String, String> resultMap = new HashMap<>();
        //code+日期 对应打卡信息
        Map<String, Map<String, Object>> codeMap = new HashMap<>();
        //全部的工号
        Set<String> codeSet = new HashSet<>();
        Map<String, Map<String, Object>> vacationCastMap = new HashMap<>();//请假审批单
        Map<String, Map<String, Object>> overTimeCastMap = new HashMap<>();//加班审批单
        //循环获取数据
        for(int i = 4; i <= rowNum; i++){
            Row rowData = sheet.getRow(i);
            String code = null;
            Map<String, Object> attendanceMap = new HashMap<>();
            for(int j = 0; j < cellNum; j++){
                String cellValue = "";
                Cell cell = rowData.getCell(j);
                if (cell != null) {
//                    cell.setCellType(Cell.CELL_TYPE_STRING);
                    cellValue = cell.toString();
                    cellValue = StringUtils.isEmpty(cellValue) ? "" : cellValue.trim();
                }
               if(j == titleNumMap.get("工号") && StringUtils.isEmpty(cellValue)){//没用工号，不作考虑
                   attendanceMap = null;
                    break;//跳出循环
               }
               if(j == titleNumMap.get("工号")){
                   attendanceMap.put("code", cellValue);
                   codeSet.add(cellValue);//去重
                   //根据工号获取用户id
                   code = cellValue;
               }else if(j == titleNumMap.get("日期")){
                   attendanceMap.put("date",20+cellValue.split(" ")[0]);
                   code += attendanceMap.get("date");
               }else if(j == titleNumMap.get("上班卡")){
                   attendanceMap.put("startTime",StringUtils.isNotEmpty(cellValue)? attendanceMap.get("date")+" "+cellValue : null);
               }else if(j == titleNumMap.get("下班卡")) {
                   attendanceMap.put("endTime", StringUtils.isNotEmpty(cellValue)? mergeEndTime((String) attendanceMap.get("date"), cellValue) : null);
               }else if(j == titleNumMap.get("末下班卡")){//最后一个打卡时间，与下班卡判断大小
                   if(StringUtils.isNotEmpty(cellValue)){
                       if(attendanceMap.get("endTime") == null){
                           attendanceMap.put("endTime", attendanceMap.get("date")+" "+cellValue);
                       }else{//判断两个值的大小
                           LocalDateTime lendTime = LocalDateUtil.toLocalDateTime((String)attendanceMap.get("endTime"), LocalDateUtil.localDateTimeYMDHM);
                           LocalDateTime llastTime = LocalDateUtil.toLocalDateTime(attendanceMap.get("date")+" "+cellValue, LocalDateUtil.localDateTimeYMDHM);
                           if(llastTime.isAfter(lendTime)){//最后的值大于endTime
                               attendanceMap.put("endTime", attendanceMap.get("date")+" "+cellValue);
                           }
                       }
                   }
               }else if(j == titleNumMap.get("审批单") && cellValue != null){//审批单
                   String[] valueArr = cellValue.split("\r|\n");
                   for(String s : valueArr){
                       if(s.indexOf("调休") >= 0 || s.indexOf("事假") >= 0 || s.indexOf("年假") >= 0){//调休
                            Map<String, Object> vacationMap = new HashMap<>();
                            vacationMap.put("code", attendanceMap.get("code"));
                            vacationMap.put("type",getVacationType(s.substring(0,2))+"");
                            vacationMap.put("beginTime", s.substring(2,13)+":00");
                            vacationMap.put("endTime", s.substring(14,25)+":00");
                            vacationMap.put("duration", s.substring(26));//时长
                            vacationCastMap.put(attendanceMap.get("code")+s, vacationMap);
                       }else if(s.indexOf("加班") >= 0){//加班
                           Map<String, Object> overTimeMap = new HashMap<>();
                           overTimeMap.put("code", attendanceMap.get("code"));
                           overTimeMap.put("type",getVacationType(s.substring(0,2))+"");
                           overTimeMap.put("beginTime", s.substring(2,13)+":00");
                           overTimeMap.put("endTime", s.substring(14,25)+":00");
                           overTimeMap.put("hours", changeTimeToHours(s.substring(26)));//时长
                           overTimeCastMap.put(attendanceMap.get("code")+s, overTimeMap);
                       }
                   }
               }
            }
            if(attendanceMap != null){//存在
                if(attendanceMap.get("startTime") != null){
                    resultMap.put(""+attendanceMap.get("code")+attendanceMap.get("date")+attendanceMap.get("startTime"),
                            "onDuty");//上班卡
                }
               if(attendanceMap.get("endTime") != null){
                   resultMap.put(""+attendanceMap.get("code")+attendanceMap.get("date")+attendanceMap.get("endTime"),
                           "offDuty");//下班卡
               }
                codeMap.put(""+attendanceMap.get("code")+attendanceMap.get("date"), attendanceMap);
            }
        }

        //循环第三个sheet，获取打卡地址
        Sheet sheetAddress = UTExcel.getSheets(filePath)[2];//主要获取打卡地址
        rowNum = sheetAddress.getLastRowNum();
        row = sheetAddress.getRow(2);//获取title行
        cellNum = row.getLastCellNum();
        titleNumMap = new HashMap<>();
        for(int i = 0; i < row.getLastCellNum(); i++){//主要获取工号 考勤日期  打卡时间 打卡地址 行
            if("工号".equals(row.getCell(i).getStringCellValue())){
                titleNumMap.put("工号", i);
            }else if("考勤日期".equals(row.getCell(i).getStringCellValue())){
                titleNumMap.put("考勤日期", i);
            }else if("打卡时间".equals(row.getCell(i).getStringCellValue())){
                titleNumMap.put("打卡时间", i);
            }else if("打卡地址".equals(row.getCell(i).getStringCellValue())){
                titleNumMap.put("打卡地址", i);
            }else if("打卡设备".equals(row.getCell(i).getStringCellValue())){
                titleNumMap.put("打卡设备", i);
            }
        }
        //循环整个sheet获取数据
        String address = null;
        String sourceType = null;//数据来源
        for(int i = 3; i <= rowNum; i++){
            address = null;
            sourceType = null;
            Row rowData = sheetAddress.getRow(i);
            StringBuilder codeDateTime = new StringBuilder();
            StringBuilder codeDate = new StringBuilder();
            for(int j = 0; j < cellNum; j++ ){
                String cellValue = "";
                Cell cell = rowData.getCell(j);
                if (cell != null) {
//                    cell.setCellType(Cell.CELL_TYPE_STRING);
                    cellValue = cell.toString();
                    cellValue = ((cellValue == null) ? true : (cellValue.length() == 0)) ? "" : cellValue.trim();
                }
                if(j == titleNumMap.get("工号") && StringUtils.isEmpty(cellValue)){//没用工号，不作考虑
                    break;//跳出循环
                }
                if(j == titleNumMap.get("工号")){
                    codeDate.append(cellValue);
                    codeDateTime.append(cellValue);
                }else if(j == titleNumMap.get("考勤日期")){
                    codeDate.append(20+cellValue.split(" ")[0]);
                    codeDateTime.append(20+cellValue.split(" ")[0]);
                }else if(j == titleNumMap.get("打卡时间")){
                    codeDateTime.append(cellValue);
                }else if(j == titleNumMap.get("打卡地址")){
                    address = cellValue;
                }else if(j == titleNumMap.get("打卡设备")){
                    sourceType = cellValue;
                }
            }
            //判断打卡地址等信息
            if("onDuty".equals(resultMap.get(codeDateTime.toString()))){//上班卡
                //修改上班的信息
                if(codeMap.get(codeDate.toString()) != null) {
                    codeMap.get(codeDate.toString()).put("dateinAddress", address);
                    codeMap.get(codeDate.toString()).put("dateinSourceType", sourceType);
                }
            }else if("offDuty".equals(resultMap.get(codeDateTime.toString()))){//下班卡
                //修改下班的信息
                if(codeMap.get(codeDate.toString()) != null) {
                    codeMap.get(codeDate.toString()).put("dateoutAddress", address);
                    codeMap.get(codeDate.toString()).put("dateoutSourceType", sourceType);
                }
            }
        }
        //获取所有的用户信息
        Map<String, Object> params = new HashMap<>();
        params.put("codes", CommonUtils.getSqlId(StringUtils.join(codeSet, ",")));
        List<UTMap<String, Object>> userList = supplierEmpService.getSupplierEmpDetailedList(params);
//        List<UTMap<String, Object>> userList = outSourcePersonDao.getListMaps(params);
        Map<String, Map<String, Object>> codeUserMap = new HashMap<>();
        List<String> userIds  = new ArrayList<>();
        if(userList == null){
            return false;
        }
        for(Map<String, Object> map : userList){
            codeUserMap.put((String)map.get("code"), map);
            userIds.add((String) map.get("userId"));
        }

        initAttendance(startTime, endTime, userIds, null,false,false);
        params.clear();
        params.put("userIds", CommonUtils.getSqlId(String.join(",",userIds)));
        List<UTMap<String, Object>> userConfigList = userConfigDao.getUserConfigs(params);
        Map<String, UTMap<String, Object>> userConfigMap = new HashMap<>();
        for(UTMap<String, Object> map : userConfigList){
            userConfigMap.put((String) map.get("userId"), map);
        }
        //获取当前时间段的所有的打卡数据
        params.clear();
        params.put("startTime", startTime);
        params.put("endTime", endTime);
        params.put("userIds", CommonUtils.getSqlId(String.join(",", userIds)));
        List<UTMap<String, Object>> allAttendanceList = attendanceDao.getAllAttendanceList(params);
        //将用户的考勤数据根据时间分离  钉钉号+日期为key
        Map<String, UTMap<String, Object>> allAttendanceMap = new HashMap<>();
        if(allAttendanceList != null){
            for(UTMap<String, Object> map : allAttendanceList){
                allAttendanceMap.put((String) map.get("code")+ map.get("date"), map);
            }
        }
        //获取所有的打卡记录
        List<Map<String, Object>> attendanceList = new ArrayList<Map<String, Object>>(codeMap.values());
        if(attendanceList == null){
            return false;
        }
        List<Map<String, Object>> mergeList = new ArrayList<>();//批量修改的值
        String seasonType = FunctionEnum.SeasonType.summer.getCode();//默认夏令时
        //处理冬令时和夏令时
        List<UTMap<String, Object>> seasonList = getSeason();
        for(Map<String, Object> map : attendanceList){
            if(map.get("startTime") == null && map.get("endTime") == null){//签到签退都为空，这一天不计算
                continue;
            }
            seasonType = checkSeason(LocalDateUtil.getLocalDatestamp((String)map.get("date")), seasonList);
            UTMap<String, Object> attendanceValue = allAttendanceMap.get(""+map.get("code")+map.get("date"));
            Map<String, Object> user = codeUserMap.get((String) map.get("code"));
            if(user == null){//用户不存在，不考虑
                continue;
            }
            //获取用户数据，主要是获取当天属于哪个项目
           Map<String, Object> userProject = projectResDao.getResByUserId((String) map.get("date"), (String) user.get("userId"));
            UTMap<String, Object> userConfig = userConfigMap.get(user.get("userId"));
            if(attendanceValue == null){//说明是在规则之外的数据
                attendanceValue = new UTMap<>();
                if(userProject != null){
                    attendanceValue.put("projectId", userProject.get("projectId"));
                    attendanceValue.put("departId", userProject.get("departId"));
                    attendanceValue.put("supplierId", userProject.get("supplierId"));
                }
                attendanceValue.put("date", map.get("date"));
                attendanceValue.put("userId", user.get("userId"));
                attendanceValue.put("attType", 1);
                attendanceValue.put("attendanceDateType",1);
                attendanceValue.put("attHours", 0);//考勤工时(小时)
                attendanceValue.put("attHoursSecond", 0);//考勤工时(秒)
                if (userConfig != null) {//考勤规则不为空，则添加考勤规则数据
                    if ("2".equals(userConfig.get("attendanceDateType").toString())) {
                        attendanceValue.put("attType", 0);
                    }
//                        attendanceValue.put("attType", 0);
                    attendanceValue.put("coalitionId", userConfig.get("coalitionId"));
                    //联合考勤用户取联合考勤配置的部门，统计也按联合考勤配置的部门进行统计
                    attendanceValue.put("attendanceDateType", getAttendanceDateType(userConfig));
                }
                //先给默认值
                attendanceValue.put("dateinStyle", -1);
                attendanceValue.put("dateoutStyle", -1);
                attendanceDao.add(attendanceValue);
            }
            attendanceValue.put("startTime", map.get("startTime") != null ? map.get("startTime")+":00" : null);
            attendanceValue.put("endTime", map.get("endTime") != null ? map.get("endTime")+":00" : null);
            attendanceValue.put("dateinAddress", map.get("dateinAddress"));
            attendanceValue.put("dateoutAddress", map.get("dateoutAddress"));
            attendanceValue.put("dateinSourceType", map.get("dateinSourceType"));
            attendanceValue.put("dateoutSourceType", map.get("dateoutSourceType"));
            if(0 == (Integer) attendanceValue.get("attType")){//工作日
                if(attendanceValue.get("startTime") != null){//判断签到状态
                    attendanceValue.put("dateinStyle", attendanceService.checkDateinStyle(userConfig, UTDate.parseDateTime((String) attendanceValue.get("startTime")), seasonType));
                }
                if(attendanceValue.get("endTime") != null){//判断签退状态
                    attendanceValue.put("dateoutStyle", attendanceService.checkDateoutStyle(userConfig, UTDate.parseDateTime((String) attendanceValue.get("endTime")), seasonType,(String) map.get("date")));
                }
                if(userConfig != null &&attendanceValue.get("startTime") != null && attendanceValue.get("endTime") != null){//再来计算时间
                    Map<String, Object> seconds = manHourStatisticService.calculateSecondsNew((String) attendanceValue.get("startTime"),  (String) attendanceValue.get("endTime"), userConfig, seasonType);
                    double attHours = 0d;
                    long attHoursSecond = Long.valueOf(seconds.get("seconds").toString());
                    attHours = UTDate.transformSecondToHour(attHoursSecond, false);
                    attendanceValue.put("attHours", attHours);//考勤工时(小时)
                    attendanceValue.put("attHoursSecond", attHoursSecond);//考勤工时(秒)
                }
            }else{//非工作日
                attendanceValue.put("dateinStyle", 0);
                attendanceValue.put("dateoutStyle", 0);
            }


            attendanceValue.remove("code");
            attendanceValue.remove("dingDingId");
            mergeList.add(attendanceValue);
        }
        attendanceDao.batchUpdate(mergeList, new String[]{"id"});//批量修改数据
        //处理审批单信息
        //请假
        List<Map<String, Object>> vacationList = new ArrayList<>(vacationCastMap.values());
        List<Map<String, Object>> overTimeList = new ArrayList<>( overTimeCastMap.values());
        Integer year = Integer.parseInt(startTime.split("-")[0]);
        addOvertime(year, overTimeList, codeUserMap,userConfigMap);
        addVacation(year, vacationList, codeUserMap,userConfigMap);
        return true;
    }

    /**
     * 添加请假申请单
     * @param year
     * @param vacationList
     * @param codeUserMap
     * @param userConfigMap
     * @return
     */
    private boolean addVacation(Integer year,List<Map<String, Object>> vacationList,Map<String, Map<String, Object>> codeUserMap,
                                Map<String, UTMap<String, Object>> userConfigMap){
        if(vacationList != null){
            List<UTMap<String, Object>> seasonList = getSeason();
            String seasonType = FunctionEnum.SeasonType.summer.getCode();//默认夏令时
            List<Map<String, Object>> updateMaps = new ArrayList<>();
            String workDate = null;
            List<Map<String, Object>> vacationUpdateList = new ArrayList<>();
            for(Map<String, Object> map : vacationList){
                Map<String, Object> user = codeUserMap.get((String) map.get("code"));
                if(user == null){
                    continue;
                }
                UTMap<String, Object> userConfig = userConfigMap.get(user.get("userId"));
                //结束时间判断是否有跨年的问题 1.刚好在年末跨年，结束时间<开始时间，存在跨年 2.根据请假的时间判断，当请假的时长大于365天的时候，存在跨年
                String[] endArr = map.get("endTime").toString().split("-| ");
                String[] startArr = map.get("beginTime").toString().split("-| ");
                int hours = map.get("hours") != null ? Math.round(Float.valueOf((String)map.get("hours"))) : 0;
                map.put("beginTime", year+"-"+map.get("beginTime"));
                if(Integer.parseInt(endArr[0]) < Integer.parseInt(startArr[0])){//月份更小
                    map.put("endTime", (year+1)+"-"+map.get("beginTime"));
                }else{//请假时间长
                    map.put("endTime", (year+hours/(365*24))+"-"+map.get("endTime"));
                }
                map.put("dingStatus", "COMPLETED");//钉钉的状态
                map.put("status", mergeStatus("COMPLETED", null));
                map.put("code", IDGenerationManager.nextId("vacation"));
//                map.put("userId", user.get("userId"));
                //先添加一下
                vacationDao.add(map);
                //根据钉钉Id获取用户id
                List<Map<String, Object>> hoursList = manHourStatisticService.calculateVacationSeconds(map.get("beginTime").toString(), map.get("endTime").toString(), userConfig);
                BigDecimal totalHour = new BigDecimal(0);
                if(hoursList != null && hoursList.size() > 0){
                    for (Map<String, Object> hour : hoursList) {
                        Long second = (Long) hour.get("seconds");
                        totalHour = BigDecimal.valueOf(UTDate.transformSecondToHour(second, true))
                                .add(totalHour);
                        Map<String, Object> detail = new HashMap<String, Object>();
                        detail.put("infoId", map.get("id"));
                        detail.put("presentDate", hour.get("beginTime"));
                        detail.put("hours", UTDate.transformSecondToHour(second, true));
                        detail.put("beginTime", hour.get("beginTime"));
                        detail.put("endTime", hour.get("endTime"));
                        detail.put("dateType", hour.get("dateType")); // 记录节假日类型
                        detail.put("coalitionId", hour.get("coalitionId")); // 记录节假日类型
                        detail.put("createUserId", user.get("userId"));
                        //根据请假的当天天数，和请假开始结束时间以及用户配置及时令规则
                        if(userConfig != null){
                            //判断时令
                            workDate = ((String)detail.get("presentDate")).split(" ")[0];
                            seasonType = checkSeason(LocalDateUtil.getLocalDatestamp(workDate), seasonList);
                            Map<String, Object> attMap = changeAttendanceStatus(detail,userConfig, workDate, seasonType);
                            if(attMap != null){
                                updateMaps.add(attMap);
                            }

                        }
                        vacationDetailDao.add(detail);

                    }
                }
                map.put("hours", totalHour);//最后时间结果
                map.put("supplierId",user.get("supplierId"));//
                map.put("supplierName", user.get("supplierName"));
                map.put("orgId", user.get("orgId"));
                map.put("orgName", user.get("orgName"));
                map.put("submitUser", user.get("nameAndCode"));
                map.put("submitTime", map.get("beginTime"));
                map.put("createTime", map.get("beginTime"));
                map.put("createUserId", user.get("userId"));
                map.put("updateTime", map.get("beginTime"));
                map.put("updateUser",  user.get("nameAndCode"));
                vacationUpdateList.add(map);
            }
            if(vacationUpdateList.size() > 0){
                vacationDao.batchUpdate(vacationUpdateList, new String[]{"id"});
            }
            if(updateMaps.size() > 0){
                attendanceDao.batchUpdate(updateMaps, new String[]{"id"});
            }

        }

        return true;
    }

    /**
     * 添加加班审批单
     * @param year
     * @param overTimeList
     * @param codeUserMap
     * @param userConfigMap
     * @return
     */
    private boolean addOvertime(Integer year,List<Map<String, Object>> overTimeList, Map<String, Map<String, Object>> codeUserMap,
                                Map<String, UTMap<String, Object>> userConfigMap){

        if(overTimeList != null ){
            for(Map<String, Object> map : overTimeList){
                Map<String, Object> user = codeUserMap.get((String) map.get("code"));
                if(user == null){
                    continue;
                }
                UTMap<String, Object> userConfig = userConfigMap.get(user.get("userId"));
                //加班不存在跨天和跨年问题
                map.put("beginTime", year+"-"+map.get("beginTime"));
                map.put("endTime",  year+"-"+map.get("endTime"));
                map.put("dingStatus", "COMPLETED");//钉钉的状态
                map.put("status", mergeStatus("COMPLETED", null));
                map.put("code", IDGenerationManager.nextId("overtime"));
                map.put("presentDate",map.get("beginTime"));
                map.put("supplierId", user.get("supplierId"));
                map.put("supplierName", user.get("supplierName"));
                map.put("orgId", user.get("orgId"));
                map.put("orgName", user.get("orgName"));
                map.put("submitUser", user.get("nameAndCode"));
                map.put("submitTime", map.get("beginTime"));
                map.put("createTime", map.get("beginTime"));
                map.put("createUserId", user.get("userId"));
                map.put("updateTime", map.get("beginTime"));
                map.put("updateUser",  user.get("nameAndCode"));
                //先添加一下
                overtimeDao.add(map);
                List<Map<String, Object>> hoursList = manHourStatisticService.calculateOvertimeHoursDays(map.get("beginTime").toString(), map.get("endTime").toString(), userConfig,(String) user.get("userId"));
                BigDecimal totalHour = new BigDecimal(0);
                BigDecimal actTotalHour = new BigDecimal(0);
                if(hoursList != null && hoursList.size() > 0){
                    for (Map<String, Object> hour : hoursList) {
                        Map<String, Object> detail = new HashMap<String, Object>();
                        detail.put("infoId", map.get("id"));
                        detail.put("presentDate", hour.get("beginTime"));
                        detail.put("beginTime", hour.get("beginTime"));
                        detail.put("endTime", hour.get("endTime"));
//                            detail.put("dateType", hour.get("dateType")); // 记录节假日类型
                        detail.put("createUserId", user.get("userId"));
                        detail.put("actBeginTime", hour.get("actBeginTime"));
                        detail.put("actEndTime", hour.get("actEndTime"));
                        detail.put("hours", hour.get("hours"));
                        detail.put("actualHours", hour.get("actualHours"));
                        if(hour.get("hours") != null){
                            totalHour = BigDecimal.valueOf((Double) hour.get("hours")).add(totalHour);
                        }
                        if(hour.get("actualHours") != null){
                            actTotalHour = BigDecimal.valueOf((Double) hour.get("actualHours")).add(actTotalHour);
                        }
                        overTimeDetailDao.add(detail);
                    }
                }
//                map.put("hours", totalHour);
//                map.put("hours", changeTimeToHours((String) map.get("duration")));
                map.put("actualHours", actTotalHour);
                overtimeDao.updateById(map);
            }
        }
        return true;
    }
    /**
     * 根据考勤规则和日期生成对应用户的考勤数据
     * @param date 考勤日期
     * @param userConfig 考勤规则
     */
    private Map<String, Object> addAttendance(Date date, UTMap<String, Object> userConfig) {
        String userId = userConfig.get("userId").toString();
        //查询外包对应外包人员用户信息
//		UTMap<String, Object> user = outSourcePersonService.getOutEmpByUserId(userId);
        UTMap<String, Object> user = supplierEmpService.getSupplierEmpDetailedByUserId(userId);
        String dateStr = UTDate.dateToDateString(date);
        UTMap<String, Object> att = attendanceDao.queryUserAttendance(dateStr, userId);
        //如果当前用户指定日期存在考勤记录，则不重新生成
        if(user == null){//用户被删除，不在同步
            return null;
        }
        if(att != null){
            logger.info("用户(" + user.get("name") + "/" + user.get("code") + ")已存在考勤记录");
            return null;
        }
        //获取当天打卡所属的项目
        Map<String,Object> map = projectResDao.getResByUserId(dateStr, userId);
        Map po = new HashMap();
        po.put("projectId", map != null ? map.get("projectId") : null);
        po.put("date", dateStr);
        po.put("userId", userId);
        po.put("supplierId", userConfig.get("supplierId"));
        //默认初始化考勤数据未签到和未签退
        po.put("dateinStyle", -1);
        po.put("dateoutStyle", -1);
        if(userConfig.get("coalitionId") != null){
            po.put("coalitionId", userConfig.get("coalitionId"));
            po.put("departId", userConfig.get("departId"));//联合考勤用户取联合考勤配置的部门，统计也按联合考勤配置的部门进行统计
        }else{
            po.put("departId", user.get("departId"));//绑定组织机构
        }
        po.put("attType", 0);//属于固定考勤用户，如果考勤记录在考勤规则范围之外，attType=1,否则为0
        po.put("attendanceDateType", getAttendanceDateType(userConfig));//考勤方式:(1.确定时间，2.不确定时间统计考勤次数,3.不确定时间统计考勤时间)
        po.put("attHours", 0);
        po.put("attHoursSecond", 0);
        logger.info("生成用户(" + user.get("name") + "/" + user.get("code") + ")的考勤初始化记录");
        return po;
    }

    /**
     * 获取夏令时和冬令时列表
     * @return
     */
   public List<UTMap<String, Object>> getSeason(){
        List<UTMap<String, Object>> list = attendanceSeasonConfigDao.getAll("year", AbstractBaseSqlDao.ORDERTYPE.ASC, null);
        if(list == null || list.size() <= 0){
            return list;
        }
        for(UTMap<String, Object> map : list){
            map.put("summerTimeSec", (LocalDateUtil.getLocalDatestamp((String) map.get("summerBeginTime"))));
            map.put("winterTimeSec", map.get("winterBeginTime") != null? LocalDateUtil.getLocalDatestamp((String) map.get("winterBeginTime")) : null);
        }
        return list;
   }

   private String getStatus(OapiProcessinstanceGetResponse.ProcessInstanceTopVo map){
       if("refuse".equals(map.getResult())){//被拒绝，状态为被终止
            return "TERMINATED";
       }
       return map.getStatus();
   }

    /**
     * 获取跳板服务器
     * @return
     */
   private String getProxyIp(){
       try {
           Map<String, Object> params = new HashMap<>();
           params.put("paramType", "proxyip");
           List<UTMap<String, Object>> paramsList = sysParamDao.getListMaps(params);
           UTMap<String, Object> p = paramsList.get(0);
           return (String) p.get("value");
       } catch (Exception e) {
           return "https://oapi.dingtalk.com";
       }
   }

    /**
     * 修改开始时间和结束时间 yyyy-MM-dd
     * 钉钉返回数据的坑，如果 返回数据是年月日的类型，那么开始时间加上 00:00:00 结束时间加上 23:59:59
     * @param startTime
     * @param endTime
     */
   private void changeStartTimeAndEnd(Map<String, Object> map, String startTime, String endTime){
       if(startTime.length() == 10 && endTime.length() == 10 ){
            map.put("startTime", startTime+" 00:00:00");
            map.put("endTime", endTime+" 23:59:59");
       }
   }

    /**
     * 钉钉状态
     * @param map
     * @return
     */
   private String mergeDingStatus(Map<String, Object> map){
       String result = (String) map.get("result");
       String status = (String) map.get("status");
//       if(!"agree".equals(result)){
//           return "CANCELED";
//       }
       return status;
   }

    /**
     * merge状态
     * @param status
     * @return
     */
   private String mergeStatus(String status, String state){
       switch(status){
           case "NEW":
               return "2";
           case "RUNNING":
               return "3";
           case "COMPLETED":
               return "5";
           case "CANCELED":
           case "TERMINATED":
               return "6";
       }

       return null;
   }

   private Map<String, String> getUseInfo(String value){
       Map<String, String> result = new HashMap<>();
       List<Map<String, Object>> list = JSONObject.parseObject(value, List.class);
       try {
           if(list != null){
               for(Map<String, Object> map : list){
                   Object object = map.get("props");
                   Map<String, Object> lMap = JSON.parseObject(object.toString());
                   if("startTime".equals((String) lMap.get("bizAlias"))){
                       result.put("startTime",changeTime((String) map.get("value")));
                   }else if("finishTime".equals((String) lMap.get("bizAlias"))){
                       result.put("finishTime",changeTimeEndTime((String) map.get("value")));
                   }
                   else if("duration".equals((String) lMap.get("bizAlias"))){
                       result.put("duration", (String) map.get("value")+"小时");
                   }
               }
           }
       } catch (Exception e) {
           List<String> list1 = JSONObject.parseObject(value, List.class);
           result.put("startTime", list1.get(0));
           result.put("finishTime",list1.get(1));
       }

       return result;
   }


   private String changeTime(String time){
       if(season.equals(FunctionEnum.SeasonType.summer.getCode())){
           time = time.replaceAll("下午",  attendanceDefaultService.getValue("attendance", "pmBegin"));
           time = time.replaceAll("上午", attendanceDefaultService.getValue("attendance", "amBegin"));
       }else{
           time = time.replaceAll("下午", attendanceDefaultService.getValue("attendance", "winterPmBegin"));
           time = time.replaceAll("上午", attendanceDefaultService.getValue("attendance", "winterAmBegin"));
       }
       return time;
   }

   private String changeTimeEndTime(String time){
       if(season.equals(FunctionEnum.SeasonType.summer.getCode())){
           time = time.replaceAll("下午", attendanceDefaultService.getValue("attendance", "pmEnd"));
           time = time.replaceAll("上午", attendanceDefaultService.getValue("attendance", "amEnd"));
       }else{
           time = time.replaceAll("下午", attendanceDefaultService.getValue("attendance", "winterPmEnd"));
           time = time.replaceAll("上午", attendanceDefaultService.getValue("attendance", "winterAmEnd"));
       }

       return time;
   }

    /**
     * 时间转化
     * @param time
     * @return
     */
   private double changeTimeToHours(String time){
       BigDecimal hours = new BigDecimal(0);
       if(time == null){
            return hours.doubleValue();
       }
       if(time.indexOf("天") >= 0){//存在天
            String[] timeArr = time.split("天");
            time = timeArr[1];
            hours = hours.add(new BigDecimal(timeArr[0]).multiply(new BigDecimal(24)));
       }
       if(time.indexOf("小时") >= 0){//存在小时
           String[] timeArr = time.split("小时");
           hours = hours.add(new BigDecimal(timeArr[0]));
       }
       return hours.doubleValue();
   }

    /**
     * 判断下班是是不是次日打卡
     * @param date
     * @param endTime
     * @return
     */
   private String mergeEndTime(String date, String endTime){
       if(endTime.indexOf("次日") >= 0){
           endTime = endTime.replaceAll("次日", "").trim();
           LocalDate localDate = LocalDateUtil.toLocalDate(date);
           localDate = localDate.plusDays(1);//加一天
           return LocalDateUtil.localDateToStr(localDate)+" "+endTime;
       }
       return date+" "+endTime;
   }

    /**
     * 根据请假情况修改签到签退状态
     * @param vacation
     * @param userConfig
     * @param date
     * @param seasonType
     */
   private UTMap<String, Object> changeAttendanceStatus(Map<String, Object> vacation,Map<String, Object> userConfig, String date,String seasonType){
       //根据时间获取考勤数据
       UTMap<String, Object> attMap = attendanceService.getCurUserAttendance(date,(String) vacation.get("createUserId"));
       if(attMap == null){
           return attMap;
       }
       //判断请假时间是什么时候，
       String beginTime = (String) vacation.get("beginTime");
       String endTime = (String) vacation.get("endTime");
       String amBeginStr = null ;
       String amEndStr = null;
       String pmBeginStr = null ;
       String pmEndStr =null;
       String attendanceDateType = (String) userConfig.get("attendanceDateType");
       if("1".equals(attendanceDateType) || "2".equals(attendanceDateType) && "1".equals(userConfig.get("attendanceType"))){//有配置
           //具体时间的配置
           if(seasonType.equals(FunctionEnum.SeasonType.summer.getCode())){
               amBeginStr = (String) userConfig.get("amBegin");
               amEndStr = (String) userConfig.get("amEnd");
               pmBeginStr = (String) userConfig.get("pmBegin");
               pmEndStr = (String) userConfig.get("pmEnd");
           }else{
               amBeginStr = (String) userConfig.get("winterAmBegin");
               amEndStr = (String) userConfig.get("winterAmEnd");
               pmBeginStr = (String) userConfig.get("winterPmBegin");
               pmEndStr = (String) userConfig.get("winterPmEnd");
           }

       }else{//没有配置，则去默认中的值
           if(seasonType.equals(FunctionEnum.SeasonType.summer.getCode())){
               amBeginStr = attendanceDefaultService.getValue("attendance", "amBegin");
               amEndStr = attendanceDefaultService.getValue("attendance", "amEnd");
               pmBeginStr = attendanceDefaultService.getValue("attendance", "pmBegin");
               pmEndStr = attendanceDefaultService.getValue("attendance", "pmEnd");
           }else{
               amBeginStr = attendanceDefaultService.getValue("attendance", "winterAmBegin");
               amEndStr = attendanceDefaultService.getValue("attendance", "winterAmEnd");
               pmBeginStr = attendanceDefaultService.getValue("attendance", "winterPmBegin");
               pmEndStr = attendanceDefaultService.getValue("attendance", "winterPmEnd");
           }
       }
       amBeginStr = date+" "+amBeginStr+":00";
       amEndStr = date+" "+amEndStr+":00";
       pmBeginStr = date+" "+pmBeginStr+":00";
       pmEndStr = date+" "+pmEndStr+":00";
       //如果开始时间在上午，则上午的考勤为正常
       if(UTDate.dateCompare(beginTime, amEndStr,"yyyy-MM-dd HH:mm:ss")){
           attMap.put("dateinStyle", 0);
       }else if(UTDate.dateCompare(amEndStr, beginTime,"yyyy-MM-dd HH:mm:ss") || beginTime.equals(amEndStr)){//在下午开始请假
           attMap.put("dateoutStyle", 0);
       }
       if(UTDate.dateCompare(endTime, pmBeginStr,"yyyy-MM-dd HH:mm:ss")){//上午
           attMap.put("dateinStyle", 0);
       }else if(UTDate.dateCompare(pmBeginStr, endTime,"yyyy-MM-dd HH:mm:ss")){//包含下午
           attMap.put("dateoutStyle", 0);
       }
       //如果vacation为调休，判断调休的时常，如果时长大于4小时（0.5天），则说明是一天的请假，工时为0，
       //如果调休<=4,则说明是调休半天，再判断有无打卡记录，是否正常，
       if(attMap.get("startTime") != null && attMap.get("endTime") != null
               && (Double) vacation.get("hours") <=4 && "0".equals(attMap.get("dateoutStyle").toString())
               && "0".equals(attMap.get("dateinStyle").toString())){
            attMap.put("attHours", 4f);
            attMap.put("attHoursSecond", 4*60*60f);
       }

       return attMap;
   }

    /**
     * 获取申请时长
     * @param arr
     * @return
     */
   public String getDuration(String[] arr){
       StringBuilder sb = new StringBuilder();
       sb.append(arr[2]);
       if("hour".equals(arr[3])){//以小时算
           sb.append("小时");
       }else if("halfDay".equals(arr[3]) || "day".equals(arr[3])){
           sb.append("天");
       }
       return sb.toString();
   }
}
