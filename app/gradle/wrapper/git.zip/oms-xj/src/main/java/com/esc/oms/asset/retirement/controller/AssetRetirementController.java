package com.esc.oms.asset.retirement.controller;


import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.asset.retirement.dao.IAssetRetirementDao;
import com.esc.oms.asset.retirement.service.IAssetRetirementService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ExcelUtil;

import net.sf.json.JSONObject;
@Controller
@RequestMapping("assetRetirement")
public class AssetRetirementController extends BaseOptionController {


	@Resource
	private IAssetRetirementService assetRetirementService;
	
	@Resource
	private ISysParamService sysParamService;
	
	
	@Override
	public IBaseOptionService optionService() {
		return assetRetirementService;
	}
	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			assetRetirementService.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	private boolean compareDate(String allocationDate) throws Exception{
		   Date nowDate = new Date();
		   SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		   Date allocDate = sdf.parse(allocationDate);
		   boolean flag = allocDate.before(nowDate);
		   return flag;
	 }
	
	@RequestMapping(value="save", method=RequestMethod.POST)  
    @ResponseBody
    public Map<String, Object> save(@RequestBody Map<String,Object> map) {
		Map<String,Object> cloneMap = CommonUtils.clone(map);
		try {
			assetRetirementService.save(cloneMap);
			cloneMap.put("success", true);
			cloneMap.put("msg", "操作成功！");
		}
		catch (Exception e) {
			logger.error("Exception", e);
			cloneMap.put("success", false);
			cloneMap.put("msg", "操作失败！");
		}
		
		return cloneMap;
	}
	
//	/**
//	 * 提交审批
//	 * @param map
//	 * @return
//	 */
//	@RequestMapping(value="submit", method=RequestMethod.POST)  
//    @ResponseBody
//    public Map<String, Object> submit(@RequestBody Map<String,Object> map) {
//		try{
//			assetRetirementService.submit(map);
//			map.put("success", true);
//			map.put("msg", "操作成功！");
//    	}catch(Exception e){
//    		logger.error("Exception", e);
//    		map.put("success", false);
//    		map.put("msg", "操作失败！");
//    	}
//       return map;
//	}
    
    /**
	 * 根据id查询
	 * @param param
	 * @return
	 */
	@RequestMapping(value="getById")
	@ResponseBody
	public UTMap<String, Object> defgetById(@RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = null;
    	try{
    		map = optionService().getById(param.get("id").toString());
    		if(null != map && map.size() > 0){
    			List<UTMap<String, Object>> assetsList = assetRetirementService.getAssetsById((String)map.get("id"));
    			map.put("assetsList", assetsList);
    		}
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return map;
	}

	
	
	@RequestMapping(value = "leadingout")
	public void leadingout(@RequestParam Map<String, Object> param,
			HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = null;
			if(info != null) {
				jsonBean = JSONObject.fromObject(info);
			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = assetRetirementService.getAssetsList(UTMap.mapObjToString(jsonBean));
			} else {
			// 根据条件 导出当前
			//if (UTExcel.EXCELOUTTYPE_NOW == outType) {
				// getpage
				assetRetirementService.getPageInfo(utPageBean, UTMap.mapObjToString(jsonBean));
				data = utPageBean.getRows();
			}
			if(null != data && data.size() > 0 ){
				//替换下拉的值
				Map<String, String> fieldAndParamType = new HashMap<String, String>();
				fieldAndParamType.put(IAssetRetirementDao.FIELD_STATUS, "assetRetirementStatus");
				fieldAndParamType.put(IAssetRetirementDao.FIELD_HANDLE, "handleType");
				sysParamService.changeParamData(data, fieldAndParamType);
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			assetRetirementService.leadingout(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	/**
	 * 领用确认导出
	 * @param param
	 * @return
	 */
	@RequestMapping(value="exportByData")
	@ResponseBody
	public void exportByData(HttpServletRequest request, HttpServletResponse response, @RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = new UTMap<String, Object>();
		//List<UTMap<String,Object>> assetIssueList = new ArrayList<UTMap<String, Object>>();
		List<UTMap<String,Object>> list = new ArrayList<UTMap<String, Object>>();
		
    	try{
    		if(null != param.get("assetId")){
    			map = optionService().getById(param.get("assetId").toString());
    			list.add(map);
        		//if(null != map && map.size() > 0){
        		List<UTMap<String,Object>> assetsList = assetRetirementService.getAssetsById((String)map.get("id"));
        	
        		//替换下拉的值
    			Map<String, String> fieldAndParamType = new HashMap<String, String>();
    			fieldAndParamType.put(IAssetRetirementDao.FIELD_STATUS, "assetRetirementStatus");
    			fieldAndParamType.put(IAssetRetirementDao.FIELD_HANDLE, "handleType");
    			sysParamService.changeParamData(list, fieldAndParamType);
    			
    			//创建一个表格
    			HSSFWorkbook wb = new HSSFWorkbook();
    			
    			exportAssetApply(wb, list.get(0),assetsList);
    			
//    			String applyId = param.get("appId").toString();
//    			String workflowCode = "physical_asset_apply";
    			response.setCharacterEncoding("UTF-8");
        		response.setContentType("application/vnd.ms-excel");
    			String fileName = "资产报废申请记录.xls";
    			fileName = URLEncoder.encode(fileName, "UTF-8");
    			response.addHeader("Content-Disposition", "attachment;filename=" + fileName);
    			
    	     //   ExcelUtil excelUtil = new ExcelUtil();
    	       // excelUtil.exportProcessImageAndInfo(workflowEngine, processInstanceDiagramCmd, workflowCode, applyId, wb);
    	//		exportAssetGrant(wb, assetIssueList);
    			
//    			list = assetApplicationService.getAssetIssuePageInfo(param);
//    			if(null != list && list.size() > 0 ){
//    				for (Map<String, Object> item : list) {
//    					if((Integer)item.get("status") == 7){
//    						item.put("status", "已确认");
//    					}else{
//    						item.put("status", "未确认");
//    					}
//    				}
//    			}
    		//	exportAssetReceive(wb, list);
    		
    			try {
					OutputStream out = response.getOutputStream();
	    			wb.write(out);
	    			out.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

    		}
    		
    		
		}catch(Exception e){
			logger.error("Exception", e);
    	}
	}
	
	private void exportAssetApply(HSSFWorkbook wb, UTMap<String, Object> map, List<UTMap<String,Object>> assetIssueList) 
	{
        String sheetName = "资产报废申请单";
        //定义表的内容
        List<Object[]> dataList = new ArrayList<Object[]>();
        Object[] objs = new Object[5];
        objs[0] = map.get("name")==null? "" : map.get("name").toString();
        objs[1] = map.get("reason")==null? "" : map.get("reason").toString();
        objs[2] = map.get("scrapDate")==null? "" : map.get("scrapDate").toString();
        objs[3] = map.get("handle")==null? "" : map.get("handle").toString();
        objs[4] = map.get("remark")==null? "" : map.get("remark").toString();
        dataList.add(objs);
        
        String[] rowsName1 = new String[] { "序号", "资产", "资产类别", "资产级别" };
        //定义表的内容
        List<Object[]> dataList1 = new ArrayList<Object[]>();
        for(UTMap<String, Object> item : assetIssueList)
        {
	        Object[] objs1 = new Object[3];
	        objs1[0] = item.get("assetsNameCode")==null? "" : item.get("assetsNameCode").toString();
	        objs1[1] = item.get("categoryName")==null? "" : item.get("categoryName").toString();
	        objs1[2] = item.get("subCategoryName")==null? "" : item.get("subCategoryName").toString();
	        dataList1.add(objs1);
        }
        // 创建ExportExcel对象
        ExcelUtil excelUtil = new ExcelUtil();
        try{
            excelUtil.exportAssetRetirement(sheetName, "资产报废申请单", dataList, wb);
            excelUtil.export(sheetName, "资产列表", rowsName1, dataList1, wb, 7, false);
        }catch(Exception e){
            e.printStackTrace();
        }
	}
	
	
	
}