package com.esc.oms.outsource.attendance.dao;


import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

import java.util.List;
import java.util.Map;

/**
 * 考勤工时填报dao接口
 * @author owner
 *
 */
public interface IManHourEditDao extends IBaseOptionDao {
	
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_YEARMONTH = "yearMonth";//年月
	public static final String  FIELD_PROJECTNAME = "projectName";//项目
	public static final String  FIELD_SUPPLIERNAME = "supplierName";//供应商
	public static final String  FIELD_PROJECTLEADERID = "projectLeaderId";//项目负责人id
	public static final String  FIELD_PROJECTLEADER = "projectLeader";//项目负责人
	public static final String  FIELD_USERID = "userId";//姓名id
	public static final String  FIELD_USERNAME = "userName";//姓名
	public static final String  FIELD_LEVEL = "level";//等级
	public static final String  FIELD_STATUS = "status";//状态
	
	public static final String  FIELD_D1 = "d1";
	public static final String  FIELD_D2 = "d2";
	public static final String  FIELD_D3 = "d3";
	public static final String  FIELD_D4 = "d4";
	public static final String  FIELD_D5 = "d5";
	public static final String  FIELD_D6 = "d6";
	public static final String  FIELD_D7 = "d7";
	public static final String  FIELD_D8 = "d8";
	public static final String  FIELD_D9 = "d9";
	public static final String  FIELD_D10 = "d10";
	public static final String  FIELD_D11 = "d11";
	public static final String  FIELD_D12 = "d12";
	public static final String  FIELD_D13 = "d13";
	public static final String  FIELD_D14 = "d14";
	public static final String  FIELD_D15 = "d15";
	public static final String  FIELD_D16 = "d16";
	public static final String  FIELD_D17 = "d17";
	public static final String  FIELD_D18 = "d18";
	public static final String  FIELD_D19 = "d19";
	public static final String  FIELD_D20 = "d20";
	public static final String  FIELD_D21 = "d21";
	public static final String  FIELD_D22 = "d22";
	public static final String  FIELD_D23 = "d23";
	public static final String  FIELD_D24 = "d24";
	public static final String  FIELD_D25 = "d25";
	public static final String  FIELD_D26 = "d26";
	public static final String  FIELD_D27 = "d27";
	public static final String  FIELD_D28 = "d28";
	public static final String  FIELD_D29 = "d29";
	public static final String  FIELD_D30 = "d30";
	public static final String  FIELD_D31 = "d31";
	
	public static final String  FIELD_OVERTIMEWEEKDAY = "overtimeWeekday";//工作日加班工时
	public static final String  FIELD_OVERTIMEWEEKEND = "overtimeWeekend";//周末加班工时
	public static final String  FIELD_OVERTIMEHOLIDAY = "overtimeHoliday";//节假日加班工时
	public static final String  FIELD_TOTAL = "total";//总数
	
//	public static final String[] inFileds = new String[] {
//		FIELD_EVALUATE_TITLE,
//		FIELD_BEGIN_DATE,
//		FIELD_END_DATE,
//		FIELD_EVALUATOR,
//		FIELD_OUTSIDE_SPECIALISTS,
//		FIELD_ACCESS_RESULT,
//		FIELD_RESULT_REMARK
//	};
	
	public static final String[] outFileds = new String[] {
		FIELD_YEARMONTH,
		FIELD_PROJECTLEADER,
		FIELD_SUPPLIERNAME,
		FIELD_USERNAME,
		FIELD_LEVEL,
		FIELD_PROJECTNAME,
		FIELD_STATUS,
		FIELD_D1,
		FIELD_D2,
		FIELD_D3,
		FIELD_D4,
		FIELD_D5,
		FIELD_D6,
		FIELD_D7,
		FIELD_D8,
		FIELD_D9,
		FIELD_D10,
		FIELD_D11,
		FIELD_D12,
		FIELD_D13,
		FIELD_D14,
		FIELD_D15,
		FIELD_D16,
		FIELD_D17,
		FIELD_D18,
		FIELD_D19,
		FIELD_D20,
		FIELD_D21,
		FIELD_D22,
		FIELD_D23,
		FIELD_D24,
		FIELD_D25,
		FIELD_D26,
		FIELD_D27,
		FIELD_D28,
		FIELD_D29,
		FIELD_D30,
		FIELD_D31,
//		FIELD_OVERTIMEWEEKDAY,
//		FIELD_OVERTIMEWEEKEND,
//		FIELD_OVERTIMEHOLIDAY,
		FIELD_TOTAL
	};

	/**
	 * 待填报：1，已填报：2，已确认：3
	 */
	public static final String STATUS_NOT_FILL = "1";
	/**
	 * 待填报：1，已填报：2，已确认：3
	 */
	public static final String STATUS_FILLED = "2";
	/**
	 * 待填报：1，已填报：2，已确认：3
	 */
	public static final String STATUS_CONFIRMED = "3";

	/**
	 * 根据日期判断是否是节假日
	 * @param date
	 */
//	public boolean isFestivalByDate(String date);
	
	/**
	 * 获取外包人员和相应项目的数据
	 * @return
	 */
	public List<UTMap<String, Object>> getProjectPerson() ;
	
	public List<UTMap<String, Object>> getListUserDate(Map param);

	/**
	 * 根据时间获取本月的
	 * @param date
	 * @return
	 */
	public List<UTMap<String, Object>> getProjectByTime(String minDate, String maxDate);

	/**
	 * 判断今天有哪些项目
	 * @param today
	 * @return
	 */
	public List<UTMap<String, Object>> getProjectByToday(String today);
}
