package com.esc.oms.asset.software.dao.impl;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Repository;

import com.esc.oms.asset.software.dao.ISoftHistoryDao;


@Repository
public class SoftHistoryDaoImpl extends BaseOptionDao implements
		ISoftHistoryDao {

	@Override
	public String getTableName() {
		return "assets_software_history";
	}

	@Override
	public List<UTMap<String, Object>> getHistoryListBySoftId(Map param) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT ash.id,ash.version,ash.website,CONCAT(su.name,'/',su.code) as chargeName, ash.chargeNumber,ash.status,ash.introducation,ash.operation,ash.disableDate");
		sql.append(" FROM assets_software_history ash");
		sql.append(" LEFT JOIN sys_user su ON su.id = ash.chargeId ");
		sql.append(" WHERE ash.softwareId='"+param.get("softwareId").toString().trim()+"'");
		sql.append(" order by ash.createTime desc,ash.disableDate desc");
		return super.getListBySql(sql.toString());
	}
	
	@Override
	public List<UTMap<String, Object>> getHistoryListByDisableDate(Map param) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT ash.id,ash.version,ash.website, ash.chargeNumber,ash.status,ash.introducation,ash.operation,ash.disableDate");
		sql.append(" FROM assets_software_history ash");
		sql.append(" WHERE ash.disableDate='"+param.get("disableDate").toString().trim()+"' "
				+ " and ash.status!='4'");
		sql.append(" order by ash.createTime desc,ash.disableDate desc");
		return super.getListBySql(sql.toString());
	}

}
