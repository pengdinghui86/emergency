package com.esc.oms.outsource.manhour.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

/**
 * 工时账单
 * @author lenovo
 *
 */
public interface IManHourBillDao extends IBaseOptionDao {

	public void billPage(Map<String, Object> param, UTPageBean pageBean);
	
	public List<UTMap<String, Object>> billList(Map<String, Object> param);
	
	/**
	 * 为工时账单查找考核数据
	 * @param param
	 * @return
	 */
	public List<UTMap<String, Object>> evaluateDetailList(Map<String, String> param);
	

	public boolean saveBill(Map<String, Object> param);
}
