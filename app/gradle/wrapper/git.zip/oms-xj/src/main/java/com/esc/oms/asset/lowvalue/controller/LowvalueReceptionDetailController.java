package com.esc.oms.asset.lowvalue.controller;

import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.asset.lowvalue.service.ILowvalueReceptionDetailService;
import com.esc.oms.util.CommonUtils;
@Controller
@RequestMapping("lowvalueReceptionDetail")
public class LowvalueReceptionDetailController extends BaseOptionController {

	@Resource
	private ILowvalueReceptionDetailService service;
	
	@Override
	public IBaseOptionService optionService() {
		return service;
	}
	
	/**
	 * 确认
	 * @param info
	 * @return
	 */
	@RequestMapping(value="confirm",method =RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> confirm(@RequestBody  Map<String, Object> info){
		try{ 
    		boolean result = service.confirm(info);
    		if(result){
    			info.put("success", true);
        		info.put("msg", "确认成功！");
    		}else{
    			info.put("success", false);
        		info.put("msg", "确认失败！");
    		}   		
    	}catch(EscServiceException e){
			info.put("success", false);
			info.put("msg", e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		info.put("success", false);
    		info.put("msg", "确认失败！");
    	}
       return info;
	}
	
	/**
	 * 确认
	 * @param info
	 * @return
	 */
	@RequestMapping(value="reject",method =RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> reject(@RequestBody  Map<String, Object> info){
		try{ 
    		boolean result = service.reject(info);
    		if(result){
    			info.put("success", true);
        		info.put("msg", "驳回成功！");
    		}else{
    			info.put("success", false);
        		info.put("msg", "驳回失败！");
    		}   		
    	}catch(EscServiceException e){
			info.put("success", false);
			info.put("msg", e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		info.put("success", false);
    		info.put("msg", "驳回失败！");
    	}
       return info;
	}
	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			service.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
}