package com.esc.oms.asset.collar.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.asset.collar.dao.IAssetCollarDao;
import com.esc.oms.asset.collar.service.IAssetCollarService;
import com.esc.oms.asset.physical.service.IAssetPhysicalService;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;

@Service
@Transactional
public class AssetCollarServiceImpl extends BaseOptionService implements IAssetCollarService{

	@Resource
	private IAssetCollarDao assetCollarDao;
	
	@Resource
	private IAssetPhysicalService assetPhysicalService;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return assetCollarDao;
	}
	
	@Resource
	private IUserTaskService userTaskService;

	@Override
	@EscOptionLog(module=SystemModule.assetCollar, opType=ESCLogOpType.INSERT, table="assets_material_recept",option="新增名称为{name}的资产领用信息。")
	public boolean add(Map info){
		info.put("createUserId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
		return	getOptionDao().add(info);
	}
	
	@Override
	@EscOptionLog(module=SystemModule.assetCollar, opType=ESCLogOpType.DELETE, table="assets_material_recept",option="删除名称为{name}的资产领用信息。")
	public boolean delete(Map info){
		return	getOptionDao().delete(info);
	}
	
	@Override
	@EscOptionLog(module=SystemModule.assetCollar, opType=ESCLogOpType.UPDATE, table="assets_material_recept",option="修改名称为{name}的资产领用信息。")
	public boolean updateById(Map info){
		boolean flag = false;
		flag = getOptionDao().updateById(info);
		userTaskService.finishTask((String) info.get("id"), "实物资产领用确认");
		return flag;
	}
	
	@Override
	public UTMap<String, Object> getAssetByAssetId(String assetId) {
		return assetCollarDao.getAssetByAssetId(assetId);
	}

	@Override
	public UTMap<String, Object> getCollarById(String id) {
		return assetCollarDao.getCollarById(id);
	}

	@Override
	public boolean leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String[] fileds = new String[] { 
				IAssetCollarDao.FIELD_TITLE,
				IAssetCollarDao.FIELD_RECEPTTYPE,
				IAssetCollarDao.FIELD_RECEPTUSERID,
				IAssetCollarDao.FIELD_RECEPTTIME,
				IAssetCollarDao.FIELD_STATUS
		};
		String tamlate="excelOutTamplate.assetCollar";	
		return	UTExcel.leadingout( fileds, data, tamlate, request,response);
	}

	@Override
	public List<UTMap<String, Object>> getCollarList(Map param) {
		return assetCollarDao.getCollarList(param);
	}

	@Override
	public UTMap<String, Object> getCollarByStatusList(String assetId) {
		return assetCollarDao.getCollarByStatusList(assetId);
	}

	@Override
	public List<UTMap<String, Object>> getAssetsList(Map<String, Object> param) {
		// TODO Auto-generated method stub
		return assetCollarDao.getAssetsList(param);
	}

	@Override
	public void getAssetCollarPage(Map<String, Object> param, UTPageBean pageBean) {
		// TODO Auto-generated method stub
		assetCollarDao.getAssetCollarPage(param, pageBean);
	}

	@Override
	public List<UTMap<String, Object>> getAssetCollarByApplyId(Map<String, Object> param) {
		// TODO Auto-generated method stub
		return assetCollarDao.getAssetCollarByApplyId(param);
	}

	@Override
	public boolean addAssetCollar(Map<String, Object> newInfo) {
		// TODO Auto-generated method stub
		return assetCollarDao.addAssetCollar(newInfo);
	}

	@Override
	public boolean deleteAssetCollarByApplyId(String applyId) {
		// TODO Auto-generated method stub
		return assetCollarDao.deleteAssetCollarByApplyId(applyId);
	}
	
	@Override
	public boolean deleteById(String id) {
		boolean flag = assetCollarDao.deleteByIds(id);
		if (flag) {
			userTaskService.finishTask(id, "实物资产领用确认");
			this.deleteAssetCollarByApplyId(id);
		}
		return flag;
	}
}