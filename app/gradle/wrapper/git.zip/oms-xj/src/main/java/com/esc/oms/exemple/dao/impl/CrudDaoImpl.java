package com.esc.oms.exemple.dao.impl;

import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.exemple.dao.ICrudDao;
@Repository
public class CrudDaoImpl extends BaseOptionDao implements ICrudDao{

	@Override
	public String getTableName() {
		return "upload_test";
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params), pageBean, null);
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append("select * from " );
		sql.append(getTableName());
		sql.append(" tb where 1=1 ");
		if(params!=null && params.size()>0){
			
			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
				sql.append(" and tb.name like '%"+params.get("name").toString().trim()+"%' ");
			}
			if(params.get("age")!=null && StringUtils.isNotEmpty(params.get("age").toString())){
				sql.append(" and   tb.age = "+params.get("age").toString().trim()+" ");
			}
		}
		sql.append(" order by createTime desc");
		return  sql.toString();
	}

}
