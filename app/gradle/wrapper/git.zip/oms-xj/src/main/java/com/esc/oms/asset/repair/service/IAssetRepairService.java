package com.esc.oms.asset.repair.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;


public interface IAssetRepairService extends IBaseOptionService{
	
	public boolean addRepairResult(Map info);
	
	public void finishRejectTask(String id);
	
	public boolean updateRepairResultById(Map info);
	
	public UTMap<String, Object> getResultByRepairId(String repairId);
	
	public UTMap<String, Object> getOrgLongNameById(String id);
	
	public boolean deleteResultByRepairId(String repairId);
	
	/**
	 * 保存数据
	 * @param map
	 */
	public void save(Map<String, Object> map);
	
	/**
	 * 保存数据并提交
	 * @param map
	 */
	public void submit(Map<String,Object> map);
	
	/**
	 * 完成审核
	 * @param recordId 记录ID
	 */
	public void finishAudit(String id);
	
	/**
	 * 驳回审核
	 * @param recordId 记录ID
	 */
	public void rejectAudit(String id);
	
	public void getAssetsRepairRateCount(UTPageBean pageBean, Map params);
	
	public boolean leadingout(List data, HttpServletRequest request,HttpServletResponse response) throws Exception;
	
	public List<UTMap<String, Object>> getAssetsList(Map param);
	
}


