package com.esc.oms.outsource.attendance.service;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;

/**
 * 用户考勤规则配置Service接口
 * @author owner
 *
 */
public interface IUserConfigService extends IBaseOptionService {
	
	/**
	 * 根据用户编号查询考勤规则
	 * @param userId
	 * @return
	 */
	public UTMap<String, Object> getUserConfigByUserId(String userId);
	
	/**
	 * 根据用户id逻辑删除
	 * @param userId
	 * @return
	 */
	public boolean deleteByUserId(String userId);
	
	/**
	 * 根据联合考勤id删除用户考勤规则
	 * @param coalitionId
	 */
	public void deleteByCoalitionId(String coalitionId);
}
