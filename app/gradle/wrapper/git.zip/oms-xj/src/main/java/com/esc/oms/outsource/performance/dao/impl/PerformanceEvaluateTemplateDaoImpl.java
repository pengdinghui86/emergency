package com.esc.oms.outsource.performance.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.performance.dao.IPerformanceEvaluateTemplateDao;

/**
 * 外包绩效考核配置模板Dao
 * @author owner
 *
 */
@Repository
public class PerformanceEvaluateTemplateDaoImpl extends BaseOptionDao implements IPerformanceEvaluateTemplateDao{

	@Override
	public String getTableName() {
		return "outsourc_performance_evaluate_template";
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params), pageBean, null);
	}
	
 	@Override
	public List<UTMap<String, Object>> getListMaps(Map param) {
		return super.getListBySql(getSearchSql(param), null);
	}
 	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append("select tb.*, CONCAT(tb.templateConfigurationName , ' ' , tb.templateConfigurationVersions) as 'templateConfiguration' from " );
		sql.append(getTableName());
		sql.append(" tb where 1=1 ");
		if(params!=null && params.size()>0){
			
//			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
//				sql.append(" and tb.supplierId like '%"+params.get("name").toString().trim()+"%' ");
//			}
			if(params.get("performanceEvaluateConfigId")!=null && StringUtils.isNotEmpty(params.get("performanceEvaluateConfigId").toString())){
				sql.append(" and tb.performanceEvaluateConfigId = '"+params.get("performanceEvaluateConfigId").toString().trim()+"' ");
			}
			if(params.get("supplierId")!=null && StringUtils.isNotEmpty(params.get("supplierId").toString())){
				sql.append(" and tb.supplierId = '"+params.get("supplierId").toString().trim()+"' ");
			}
//			if(params.get("subType")!=null && StringUtils.isNotEmpty(params.get("subType").toString())){
//				sql.append(" and tb.subType = "+params.get("subType").toString().trim()+" ");
//			}
		}
		sql.append(" order by createTime desc");
		return  sql.toString();
	}

}
