package com.esc.oms.asset.borrow.dao.impl;

import com.esc.oms.asset.borrow.dao.IAssetBorrowDao;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.RoleUtils;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
@Repository
public class AssetBorrowDaoImpl extends BaseOptionDao implements IAssetBorrowDao{
	
	private String borrowDetailTableName = "assets_material_recept_detail";
	

	@Override
	public String getTableName() {
		return "assets_material_borrow";
	}
	

	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params), pageBean, null);
	}
	
	@Override
	public UTMap<String, Object> getById(String id){
		return super.getOneBySql(getSearchByIdSql(id));
	}
	
	private String getSearchByIdSql(String id){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT amb.id,amb.beginDate,amb.borrowType,amb.borrowUnit,amb.`code`,amb.ipAddress, " );
		sql.append(" amb.createTime,amb.createUser,amb.createUserId,amb.earlyWaryNum, ");
		sql.append(" amb.endDate,amb.isEarlyWarn,amb.reason,amb.remark,amb.`status`,amb.title,so.`name` borrowUnitName ");
		sql.append(" FROM assets_material_borrow amb ");
		sql.append(" LEFT JOIN sys_org so ON so.id = amb.borrowUnit ");
		sql.append(" WHERE amb.id = '"+id+"'");
		return  sql.toString();
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT amb.id,amb.`code`, amb.title,amb.borrowType,so.`longName` borrowUnit,amb.ipAddress, " );
		sql.append(" amb.createUser,amb.createTime,amb.remark,amb.status,amb.createUserId ");
		sql.append(" FROM assets_material_borrow amb ");
		sql.append(" LEFT JOIN sys_org so ON so.id = amb.borrowUnit ");
		sql.append(" WHERE 1=1 ");
		if(params!=null && params.size()>0){
			if(params.get("code")!=null &&  StringUtils.isNotEmpty(params.get("code").toString())){
				sql.append(" AND amb.`code` LIKE '%"+params.get("code").toString().trim()+"%' ");
			}
			if(params.get("title")!=null && StringUtils.isNotEmpty(params.get("title").toString())){
				sql.append(" AND amb.title LIKE '%"+params.get("title").toString().trim()+"%'");
			}
			if(params.get("applyUserId")!=null && StringUtils.isNotEmpty(params.get("applyUserId").toString())){
				sql.append(" AND amb.createUser LIKE '%"+params.get("applyUserId").toString().trim()+"%'");
			}
			if(params.get("startTime")!=null && StringUtils.isNotEmpty(params.get("startTime").toString())){
				sql.append(" AND amb.createTime >='"+params.get("startTime").toString().trim()+"'");
			}
			if(params.get("endTime")!=null && StringUtils.isNotEmpty(params.get("endTime").toString())){
				sql.append(" AND amb.createTime <='"+params.get("endTime").toString().trim()+"'");
			}
		}
		if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR,RoleUtils.ASSET_MANAGER)){
			sql.append(" AND amb.createUserId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' ");//非研发用户只能查询自己的数据，研发用户查询所有数据方便调试
		}
		sql.append(" ORDER BY amb.createTime desc");
		return  sql.toString();
	}
	
	private String getAssetAllocationListMapsSql(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT amrd.id,concat(ami.`name`,IF(ami.`codeNum` is null or ami.`codeNum`='','', concat('/',ami.`codeNum`))) `name`,concat(ami.`name`,IF(ami.`serialNum` is null or ami.`serialNum`='','', concat('/',ami.`serialNum`))) `assetsName`,ami.`code`,amc.`name` category,amc.`name` assetsType,amsc.`name` subCategory,amsc.`name` assetsSubType, amb.createUserId,amrd.assetsId,ami.resUserId," );
		sql.append(" concat(su3.`name`, '/', su3.`code`) resUserName,so.`name` resDepartName,ap.`name` location,ami.model,ami.brand,ami.assetsLevel,  ");
		sql.append(" amrd.grantAmount,amrd.grantUserId,concat(su2.`name`, '/', su2.`code`) grantUserName,amb.ipAddress,amrd.grantTime,amrd.`status` detailStatus,amrd.returnTime,amb.`status`,amb.endDate,DATEDIFF(amb.endDate,NOW()) returnDay ");
		sql.append(" FROM assets_material_recept_detail amrd ");
		sql.append(" LEFT JOIN assets_material_borrow amb ON amb.id = amrd.applyId ");
		sql.append(" LEFT JOIN assets_material_info ami ON ami.id = amrd.assetsId ");
		sql.append(" LEFT JOIN assets_material_category amc ON amc.id = ami.category ");
		sql.append(" LEFT JOIN assets_material_category amsc ON amsc.id = ami.subCategory ");
		sql.append(" LEFT JOIN sys_user su ON su.id = amb.createUserId  ");
		sql.append(" LEFT JOIN sys_user su2 ON su2.id = amrd.grantUserId  ");
		sql.append(" LEFT JOIN sys_user su3 ON su3.id=ami.resUserId ");
		sql.append(" LEFT JOIN sys_org so ON so.id = ami.resDepartId ");
		sql.append(" LEFT JOIN assets_place ap ON ap.id = ami.location ");
		sql.append(" WHERE 1=1 ");
		if(params!=null && params.size()>0){
			if(params.get("borrowId")!=null &&  StringUtils.isNotEmpty(params.get("borrowId").toString())){
				sql.append(" AND amrd.applyId = '"+params.get("borrowId").toString().trim()+"' ");
			}
			if(params.get("detailStatus")!=null &&  StringUtils.isNotEmpty(params.get("detailStatus").toString())){
				sql.append(" AND amrd.status is not null  ");
			}
		}
		sql.append(" ORDER BY amrd.createTime ");
		return  sql.toString();
	}


	@Override
	public boolean addAssetAllocation(Map info) {
		return	super.saveBySql(borrowDetailTableName, info);
	}


	@Override
	public boolean deleteAssetAllocationById(String id) {
		return super.deleteByIds(borrowDetailTableName, id);
	}


	@Override
	public List<UTMap<String, Object>> getAssetAllocationListMaps(Map param) {
		return super.getListBySql(getAssetAllocationListMapsSql(param));
	}


	@Override
	public boolean updateAllocationStatusById(String id, String status) {
		StringBuilder sql=new StringBuilder();
		if("2".equals(status)){
			sql.append(" update assets_material_recept_detail amrd SET amrd.`status` = '"+status+"' , amrd.returnTime =now() WHERE amrd.id = '" +id+"'");
		}else{
			sql.append(" update assets_material_recept_detail amrd SET amrd.`status` = '"+status+"'  WHERE amrd.id = '" +id+"'");
		}
		return super.executeUpdate(sql.toString());
	}


	@Override
	public void getAssetAllocationPageInfo(UTPageBean pageBean, Map param) {
		super.getPageListMapBySql(getAssetAllocationListMapsSql(param), pageBean, null);
		
	}


	@Override
	public boolean deleteAssetAllocationByBorrowId(String id) {
		StringBuilder sql=new StringBuilder();
		sql.append("DELETE FROM assets_material_recept_detail  WHERE applyId = '"+id+"'");
		return super.executeUpdate(sql.toString());
	}


	@Override
	public UTMap<String, Object> getAssetBorrowById(String id) {
		return super.getMapById(borrowDetailTableName, null, id);
	}

	
	private String getRemindBorrowsListSql(){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT amb.id,amb.title,amb.ipAddress,amb.`code`,amb.createUser,amb.createUserId,to_days(amb.endDate) - to_days(now()) remainDay,ifnull(amb.earlyWaryNum,0) " );
		sql.append(" FROM assets_material_borrow amb  ");
		sql.append(" WHERE (to_days(amb.endDate)-to_days(now()) = ifnull(amb.earlyWaryNum,0)) AND amb.isEarlyWarn = '1' ");
		return  sql.toString();
	}
	
	private String getBorrowsReturnListSql(){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT amb.id,amb.title,amb.ipAddress,amb.`code`,amb.createUser,amb.createUserId,to_days(amb.endDate) - to_days(now()) ,ifnull(amb.earlyWaryNum,0) " );
		sql.append(" FROM assets_material_borrow amb  ");
		sql.append(" WHERE to_days(amb.endDate)-to_days(now()) = 0 ");
		return  sql.toString();
	}

	@Override
	public List<UTMap<String, Object>> getRemindBorrowsList() {
		return super.getListBySql(getRemindBorrowsListSql());
	}


	@Override
	public boolean updateAllocationStatusByBorrowId(String borrowId,
			String status) {
		StringBuilder sql=new StringBuilder();
		if("3".equals(status)){
			sql.append(" update assets_material_recept_detail amrd SET amrd.`status` = '"+status+"' WHERE amrd.applyId = '" +borrowId+"'");
		}else{
			sql.append(" update assets_material_recept_detail amrd SET amrd.`status` = '"+status+"', amrd.returnTime =now() WHERE amrd.applyId = '" +borrowId+"'");
		}
		return super.executeUpdate(sql.toString());
	}


	@Override
	public List<UTMap<String, Object>> getBorrowDetailByIdAndStatus(
			String borrowId) {
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT * FROM assets_material_recept_detail amd WHERE (amd.`status` IN ('1', '2') OR amd.`status` IS NULL) AND amd.applyId = '"+borrowId+"'");
		return super.getListBySql(sql.toString());
	}


	@Override
	public List<UTMap<String, Object>> getBorrowDetailByIds(String ids) {
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT * FROM assets_material_recept_detail amd WHERE amd.`status` IN ('1') AND amd.id in ("+ids+")");
		return super.getListBySql(sql.toString());
	}


	@Override
	public List<UTMap<String, Object>> getBorrowsReturnList() {
		return super.getListBySql(getBorrowsReturnListSql());
	}


	@Override
	public List<UTMap<String, Object>> getBorrowByStatusList(String assetId) {
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT amrd.* FROM assets_material_recept_detail amrd left join assets_material_borrow amb on amrd.applyId=amb.id "
				 + " WHERE amrd.assetsId = '"+assetId+"' AND amb.status in ('1', '2', '3', '4')  and (amrd.status is null or amrd.status in ('1', '2'))");
		return super.getListBySql(sql.toString(), null);
	}


	@Override
	public boolean updateAssetAllocation(Map<String, Object> param) {
		// TODO Auto-generated method stub
		return super.updateById(borrowDetailTableName, param);
	}


	@Override
	public void getAssetsList(Map<String, Object> params, UTPageBean pageBean) {
		super.getPageListMapBySql(getAssetsListSql(params), pageBean, null);
	}

	private String getAssetsListSql(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT ami.id,ami.sn,ami.`name`,ami.`code`,ami.codeNum,amc.`name` categoryName,amsc.`name` subCategoryName,so.`longName` resDepartId,");
		sql.append(" IF(ami.auxiliaryAsset='1',concat(concat('(主)','',ami.`name`), IF ( ami.serialNum IS NULL OR ami.serialNum = '', '', concat('/', ami.serialNum)))," );
		sql.append("concat( concat('(辅)', '', ami.`name`), IF ( ami.codeNum IS NULL OR ami.codeNum = '', '', concat('/', ami.codeNum)))) assetsNameCode," );
		sql.append(" ami.status,ami.assetPrice,ami.registStatus, ami.serialNum,ami.userId,ami.brand,ami.model,ami.assetsLevel," );
		sql.append(" ami.salvage,ami.useYears,ami.inboundDate,ami.confidentiality, ");
		sql.append(" ami.maintAssetStartDate,ami.maintAssetsEndDate,ami.remark,ami.systemClass,");
		sql.append(" ami.assetStartDate,ami.assetEndDate,aai.supplierName assetSupplierName,ami.controllable,ami.otherMaint,");
		sql.append(" ami.auxiliaryAsset,ami.ownSystem,ami.producer,ami.integrity,ami.availability,ami.hasBackup,ami.totalAssets,ami.outdate, ");
		sql.append(" ami.assetsUse, ami.assetStatus, ami.assetsCosts, ami.preAssetsClass, ");
		sql.append(" ami.ip, ami.EquipmentUse, ami.isPositive, ami.assetAttributes, ami.systemName, ami.MaintenanceAmount,");
		sql.append(" ami.CabinetStartU, ami.CabinetEndU, ami.businessSystemLeader, ami.EquipmentLeader,ami.assetsType,");
		sql.append(" aai.agreementName buyContract,aai2.agreementName maintainContract,concat(su.`name`, '/', su.`code`) resUserName,");
		sql.append(" ap.`name` location,ami.resUserId resUser,ifnull(ami.isScrap,'0') isScrap,");
		sql.append(" so.`name` resDepartName,aai.agreementName buyContractName,");
		sql.append(" aai2.agreementName maintainContractName,(to_days(ami.maintAssetsEndDate)-to_days(now())) maintAssetsLeftNum,");
		sql.append( " aai2.supplierName maintSupplierName,(to_days(ami.assetEndDate)-to_days(now())) assetsLeftTime,");
		sql.append(" su2.name businessSystemLeaderName,su3.name  EquipmentLeaderName ");
		sql.append(" FROM assets_material_info ami ");
		sql.append(" LEFT JOIN assets_material_category amc ON amc.id = ami.category ");
		sql.append(" LEFT JOIN assets_material_category amsc ON amsc.id = ami.subCategory ");
		sql.append(" LEFT JOIN sys_user su ON su.id = ami.resUserId ");
		sql.append(" LEFT JOIN sys_user su2 on su2.id = ami.businessSystemLeader ");
		sql.append(" LEFT JOIN sys_user su3 on su3.id = ami.EquipmentLeader ");
		sql.append(" LEFT JOIN sys_org so ON so.id = ami.resDepartId ");
		sql.append(" LEFT JOIN assets_place ap ON ap.id = ami.location ");
		sql.append(" LEFT JOIN assets_agreement_info aai ON ami.buyContract = aai.id ");
		sql.append(" LEFT JOIN assets_agreement_info aai2 ON aai2.id = ami.maintainContract ");
		sql.append(" WHERE 1=1 ");
		sql.append(" AND (ami.deleteFlag != 1 OR ami.deleteFlag IS NULL) ");
		sql.append(" AND not EXISTS ( select amrd.assetsId, amrd.status from assets_material_recept_detail amrd left join assets_material_borrow amb on amrd.applyId=amb.id where amrd.assetsId=ami.id and amb.status in ('1', '2', '3', '4') and (amrd.status is null or amrd.status in ('1', '2'))) ");//数据过滤
		if(params!=null && params.size()>0){
			if(params.get("category")!=null && CommonUtils.notNullStrOrEmpty(params.get("category").toString())){
				sql.append(" AND amc.id = '"+params.get("category").toString().trim()+"'");
			}
			if(params.get("subCategory")!=null && CommonUtils.notNullStrOrEmpty(params.get("subCategory").toString())){
				sql.append(" AND amsc.id = '"+params.get("subCategory").toString().trim()+"'");
			}
			if(params.get("agreementId")!=null && CommonUtils.notNullStrOrEmpty(params.get("agreementId").toString())){ //资产合同--资产视图
				sql.append(" AND (ami.buyContract = '"+params.get("agreementId").toString().trim()+"' "
						+ "or ami.maintainContract = '"+params.get("agreementId").toString().trim()+"')");
			}
			if(params.get("name")!=null && CommonUtils.notNullStrOrEmpty(params.get("name").toString())){ //资产合同--资产视图
				sql.append(" AND ami.name like '%"+params.get("name").toString().trim()+"%'");
			}
			if(params.get("code")!=null && CommonUtils.notNullStrOrEmpty(params.get("code").toString())){
				sql.append(" AND (ami.code like '%"+params.get("code").toString().trim()+"%' OR ami.serialNum like '%"+params.get("code").toString().trim()+"%')");
			}
			if(params.get("codeNum")!=null && CommonUtils.notNullStrOrEmpty(params.get("codeNum").toString())){
				sql.append(" AND (ami.codeNum like '%"+params.get("codeNum").toString().trim()+"%' OR ami.serialNum like '%"+params.get("codeNum").toString().trim()+"%')");
			}
			if(params.get("resUserId")!=null && CommonUtils.notNullStrOrEmpty(params.get("resUserId").toString())){
				sql.append(" and CONCAT(su.name,'/',su.code) like '%"+params.get("resUserId").toString().trim()+"%' ");
			}
			if(params.get("resDepartId")!=null && CommonUtils.notNullStrOrEmpty(params.get("resDepartId").toString())){
				sql.append(" AND ami.resDepartId = '"+params.get("resDepartId").toString().trim()+"'");
			}
			if(params.get("resDepartLongName")!=null && CommonUtils.notNullStrOrEmpty(params.get("resDepartLongName").toString())){
				sql.append(" AND so.`longName` like '%"+params.get("resDepartLongName").toString().trim()+"%'");
			}
			if(params.get("isScrap")!=null && CommonUtils.notNullStrOrEmpty(params.get("isScrap").toString())){
				sql.append(" AND ifnull(ami.isScrap,'0') = '"+params.get("isScrap").toString().trim()+"'");
			}else{
			}
			if(params.get("ids")!=null && CommonUtils.notNullStrOrEmpty(params.get("ids").toString())){
				sql.append(" AND ami.id in ("+params.get("ids").toString().trim()+")");
			}
			if(params.get("userStatus")!=null && CommonUtils.notNullStrOrEmpty(params.get("userStatus").toString())){
				//sql.append(" AND (ami.resUserId is NULL OR ami.resUserId = '') ");
				
				//资产申请、借用、领用功能中，选择资产时判断条件改为当资产状态为“已入库待领用”或“闲置”才能申请、借用、领用  modified by hy 2018/11/26
				sql.append(" and ami.assetStatus in('1','3')");
			}
			if(params.get("auxiliaryAsset")!=null && CommonUtils.notNullStrOrEmpty(params.get("auxiliaryAsset").toString())){
				sql.append(" AND ami.auxiliaryAsset = "+params.get("auxiliaryAsset").toString().trim()+" and (ami.parentId IS NULL OR ami.parentId = '' ) ");
			}
			if(params.get("parentId")!=null && CommonUtils.notNullStrOrEmpty(params.get("parentId").toString())){
				sql.append(" AND ami.parentId = '"+params.get("parentId").toString().trim()+"'");
			}
			if(params.get("locationName")!=null && CommonUtils.notNullStrOrEmpty(params.get("locationName").toString())){
				sql.append(" AND ap.name like '%"+params.get("locationName").toString().trim()+"%'");
			}
			if(params.get("resUserName")!=null && CommonUtils.notNullStrOrEmpty(params.get("resUserName").toString())){
				sql.append(" AND su.name like '%"+params.get("resUserName").toString().trim()+"%'");
			}
			if(params.get("registStatus")!=null && CommonUtils.notNullStrOrEmpty(params.get("registStatus").toString())){
				sql.append(" AND ami.registStatus = '"+params.get("registStatus").toString().trim()+"'");
			}else{
				if(params.get("registAssets")!=null && CommonUtils.notNullStrOrEmpty(params.get("registAssets").toString())){}else{
					sql.append(" AND (ami.registStatus is NULL OR ami.registStatus = '2') ");
				}
			}
		}else{
			sql.append(" AND ifnull(ami.isScrap,'0') <> '1'");
		}
		if(params!=null && params.size()>0 && null != params.get("overviewWarn")){
			if("0".equals(String.valueOf(params.get("overviewWarn")))){
				sql.append(" order by assetsLeftTime asc");
			}else{
				sql.append(" order by maintAssetsLeftNum asc");
			}
		}else{
			sql.append(" order by ami.createTime desc,ami.sortCode ");
		}
		return  sql.toString();
	}


	@Override
	public void getAssetAllocationPage(Map<String, Object> param, UTPageBean pageBean) {
		// TODO Auto-generated method stub
		super.getPageListMapBySql(getAssetAllocationListMapsSql(param), pageBean, null);
	}
	
}
