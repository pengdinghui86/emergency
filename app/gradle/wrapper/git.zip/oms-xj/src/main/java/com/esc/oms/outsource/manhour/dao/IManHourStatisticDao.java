package com.esc.oms.outsource.manhour.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

public interface IManHourStatisticDao extends IBaseOptionDao {

	public void baseOnSupplier(Map<String, Object> param, UTPageBean pageBean);

	public List<UTMap<String, Object>> baseOnSupplierList(Map<String, Object> param);

	public void baseOnOrg(Map<String, Object> param, UTPageBean pageBean);

	public List<UTMap<String, Object>> baseOnOrgList(Map<String, Object> param);
	
}
