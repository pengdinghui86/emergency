package com.esc.oms.outsource.outperson.dao;

import org.esc.framework.persistence.dao.IBaseOptionDao;

/**
 * 简历基本信息
 * @author djj
 * @date   2016-07-18
 */
public interface IOutSourcePersonResumeProjectDao extends IBaseOptionDao {
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_CODE= "code";
	public static final String  FIELD_NAME = "name";
	public static final String  FIELD_SUPPLIERID = "supplierId";
	
	
}
