package com.esc.oms.outsource.outperson.service;

import java.util.Map;

import org.esc.framework.utils.UTMap;

public interface IOutSourceGenerateAccountService {
	public UTMap<String, Object> generateAccount(Map<String, Object> param);
}
