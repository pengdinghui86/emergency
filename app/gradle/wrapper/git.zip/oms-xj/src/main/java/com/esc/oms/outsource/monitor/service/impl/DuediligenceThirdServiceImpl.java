package com.esc.oms.outsource.monitor.service.impl;

import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.utils.UTMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.monitor.dao.IDuediligenceThirdDao;
import com.esc.oms.outsource.monitor.service.IDuediligenceThirdService;

/**
 * 第三方机构检查
 * @author owner
 *
 */
@Service
@Transactional
public class DuediligenceThirdServiceImpl extends BaseOptionService implements IDuediligenceThirdService{
	
	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private IDuediligenceThirdDao dao;
	
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return dao;
	}

	/**
	 * 添加
	 * @param info
	 * @return
	 */
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean add(Map info){
		return super.add(info);
	}
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		UTMap<String, Object> result = super.getById(id);
		return result;
	}
	
	/**
	 * 修改
	 * @param info
	 * @return
	 */
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean updateById(Map info){
		return super.updateById(info);
	}
	
	/**
	 * 根据模板配置查询对应的第三方机构数据
	 * @param duediligenceEvaluateConfigId
	 * @return
	 */
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getByDuediligenceEvaluateConfigId(String duediligenceEvaluateConfigId){
		return dao.getByDuediligenceEvaluateConfigId(duediligenceEvaluateConfigId);
	}

}
