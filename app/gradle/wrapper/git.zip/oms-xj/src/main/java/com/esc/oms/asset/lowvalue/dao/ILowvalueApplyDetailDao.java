package com.esc.oms.asset.lowvalue.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

public interface ILowvalueApplyDetailDao extends IBaseOptionDao{
	
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_CODE = "code";
	public static final String  FIELD_NAME = "name";
	public static final String  FIELD_BRAND = "brand";
	public static final String  FIELD_MODEL = "model";
	public static final String  FIELD_MEASURE = "measure";
	public static final String  FIELD_UNIT_PRICE = "unitPrice";
	public static final String  FIELD_APPLY_NUM = "applyNum";
	public static final String  FIELD_GRANT_NUM = "grantNum";
	public static final String  FIELD_CONFIRM_STATUS = "confirmStatus";
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params);

	/**
	 * 根据领用记录的条件查询领用详单	
	 * @param params
	 * @return
	 */
	public List<UTMap<String, Object>> getListAllByParentParam(Map parentParams);
	
}
