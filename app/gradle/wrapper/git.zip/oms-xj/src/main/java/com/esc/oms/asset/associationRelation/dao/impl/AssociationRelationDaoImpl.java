package com.esc.oms.asset.associationRelation.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.asset.associationRelation.dao.IAssociationRelationDao;
@Repository
public class AssociationRelationDaoImpl extends BaseOptionDao implements IAssociationRelationDao{
	
	private String physicalAssetRelation = "physical_asset_relation";
	private String softwareAssetRelation = "software_asset_relation";

	@Override
	public String getTableName() {
		return "assets_assoc_relation";
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params), pageBean, null);
	}
	
	
	@Override
	public List<UTMap<String, Object>> getListMaps(Map param) {
		return this.getListBySql(getSearchSql(param));
	}
	
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params){
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT aar.id,concat(ami.`code`,'/',ami.`name`) assetsName,amc.`name` categoryName,amsc.name subCategoryName, ap.`name` location,concat(su.`name`,'/',su.code) resUserName,so.longName as resDepartLongName,ami.model,ami.brand,aar.mainAssetId  "
				 + " ,(select COUNT(1) from physical_asset_relation par WHERE par.mainAssetId = aar.mainAssetId) physicalAssetNum,(select COUNT(1) from software_asset_relation sar where sar.relationId = aar.mainAssetId)sarNum ");
		sql.append(" FROM assets_assoc_relation aar  ");
		sql.append(" LEFT JOIN assets_material_info ami ON ami.id = aar.mainAssetId  ");
		sql.append(" LEFT JOIN assets_material_category amc ON ami.category = amc.id  ");
		sql.append(" LEFT JOIN assets_material_category amsc ON amsc.id = ami.subCategory  ");
		sql.append(" LEFT JOIN assets_place ap ON ami.location = ap.id  ");
		sql.append(" LEFT JOIN sys_user su ON ami.resUserId = su.id ");
		sql.append(" LEFT JOIN sys_org so ON so.id = ami.resDepartId ");
		sql.append(" where 1=1 ");
		if(params!=null && params.size()>0){
			if(params.get("category")!=null && StringUtils.isNotEmpty(params.get("category").toString())){
				sql.append(" AND amc.id = '"+params.get("category").toString().trim()+"'");
			}
			if(params.get("subCategory")!=null && StringUtils.isNotEmpty(params.get("subCategory").toString())){
				sql.append(" AND amsc.id = '"+params.get("subCategory").toString().trim()+"'");
			}
			if(params.get("name")!=null && StringUtils.isNotEmpty(params.get("name").toString())){ 
				sql.append(" AND ami.name like '%"+params.get("name").toString().trim()+"%'");
			}
			if(params.get("resUserId")!=null && StringUtils.isNotEmpty(params.get("resUserId").toString())){ 
//				sql.append(" and (su.name like '%"+params.get("resUserId").toString().trim()+"%' or su.code like '%"+params.get("resUserId").toString().trim()+"%')");
				sql.append(" and CONCAT(su.name,'/',su.code) like '%"+params.get("resUserId").toString().trim()+"%' ");
			}
			if(params.get("resDepartId")!=null && StringUtils.isNotEmpty(params.get("resDepartId").toString())){
//				sql.append(" AND ami.resDepartId = '"+params.get("resDepartId").toString().trim()+"'");
				sql.append(" and so.longName like '%"+params.get("resDepartId").toString().trim()+"%'");
			}
		}
//		if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR,RoleUtils.ASSET_MANAGER)){
//			sql.append(" and (amr.receptUserId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' or amr.createUserId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' )");//非研发用户只能查询自己的数据，研发用户查询所有数据方便调试
//		}
		sql.append(" order by aar.createTime desc ");
		return  sql.toString();
	}

	@Override
	public boolean deletePhysicalAssetsById(String mainAssetId) {
		StringBuilder sql = new StringBuilder();
		sql.append(" DELETE FROM physical_asset_relation ");
		sql.append(" WHERE mainAssetId = '"+mainAssetId+"'");
		return super.executeUpdate(sql.toString());
	}

	@Override
	public boolean deleteSoftwareAssetsById(String mainAssetId) {
		StringBuilder sql = new StringBuilder();
		sql.append(" DELETE FROM software_asset_relation ");
		sql.append(" WHERE relationId = '"+mainAssetId+"'");
		return super.executeUpdate(sql.toString());
	}

	@Override
	public List<UTMap<String, Object>> getPhysicalAssetsById(String mainAssetId) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT concat(ami.`code`,'/',ami.`name`) assetsName,amc.`name` categoryName,amsc.`name` subCategoryName, ");
		sql.append(" ami.brand,ami.model,concat(su.`name`,'/',su.`code`) resUserId,so.`name` resDepartId,par.associationRelation,par.relationDesc,ami.id assetsId ");
		sql.append(" FROM physical_asset_relation par ");
		sql.append(" LEFT JOIN assets_material_info ami ON ami.id = par.physicalAssetId ");
		sql.append(" LEFT JOIN assets_material_category amc ON amc.id = ami.category ");
		sql.append(" LEFT JOIN assets_material_category amsc ON amsc.id = ami.subCategory ");
		sql.append(" LEFT JOIN sys_user su ON su.id = ami.resUserId ");
		sql.append(" LEFT JOIN sys_org so ON so.id = ami.resDepartId ");
		sql.append(" WHERE par.mainAssetId = '"+mainAssetId+"'");
		return super.getListBySql(sql.toString());
	}

	@Override
	public List<UTMap<String, Object>> getSoftwareAssetsById(String mainAssetId) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT asl.`name` softAssetsName,sc.`name` softCategoryName,ssc.`name` softwareSubCategoryName, ");
		sql.append(" asl.version,asl.beginDate,asl.endDate,concat(su.`name`,'/',su.`code`) chargeId,sar.associationRelation,sar.relationDesc,asl.id softwareAssetId ");
		sql.append(" FROM software_asset_relation sar  ");
		sql.append(" LEFT JOIN assets_software_library asl ON sar.softwareAssetId = asl.id  ");
		sql.append(" LEFT JOIN software_category sc ON sc.id = asl.category  ");
		sql.append(" LEFT JOIN software_category ssc ON ssc.id = asl.subCategory  ");
		sql.append(" LEFT JOIN sys_user su ON su.id = asl.chargeId  ");
		sql.append(" WHERE sar.relationId = '"+mainAssetId+"'");
		return super.getListBySql(sql.toString());
	}

	@Override
	public boolean addPhysicalAssets(Map info) {
		return	super.saveBySql(physicalAssetRelation, info);
		
	}

	@Override
	public boolean addSoftwareAssets(Map info) {
		return	super.saveBySql(softwareAssetRelation, info);
		
	}

	@Override
	public UTMap<String, Object> getById(String id){
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT aar.id,aar.createTime,aar.createUserId,aar.mainAssetId,aar.mainCategoryId,aar.mainSubCategoryId,aar.updateTime,aar.updateUserId,aar.mainAssetId mainId,amc.`name` categoryName,amsc.`name` subCategoryName,ami.`name` assetsName ");
		sql.append(" FROM assets_assoc_relation aar ");
		sql.append(" LEFT JOIN assets_material_info ami ON ami.id = aar.mainAssetId ");
		sql.append(" LEFT JOIN assets_material_category amc ON amc.id = ami.category ");
		sql.append(" LEFT JOIN assets_material_category amsc ON amsc.id = ami.subCategory ");
		sql.append(" WHERE aar.id = '"+id+"'");
		return super.getOneBySql(sql.toString());
	}

	@Override
	public List<UTMap<String, Object>> getAssets() {
		String sql = "select distinct v.id,v.name from "
				+ "(select par.mainAssetId as id, concat(ami.name,'/',ami.code) as name  from physical_asset_relation par left join assets_material_info ami on par.mainAssetId = ami.id "
				+ "	union all "
				+ "select par.physicalAssetId as id ,concat(ami.name,'/',ami.code) as name from  physical_asset_relation par left join assets_material_info ami on par.physicalAssetId = ami.id) v";
		return this.getListBySql(sql);
	}

	
	@Override
	public List<UTMap<String, Object>> getPhyRelByAssetsId(String id) {
		String sql ="select par.physicalAssetId as id ,concat(ami.name,'/',ami.code) as name from  physical_asset_relation par left join assets_material_info ami on par.physicalAssetId = ami.id where par.mainAssetId='"+id+"'";
		return this.getListBySql(sql);
	}

	@Override
	public UTMap<String, Object> getAssetsByCode(String code) {
		String sql = "select tb.id from  assets_material_info tb where tb.code = '"+code+"'";
		return getOneBySql(sql);
	}

	@Override
	public List<UTMap<String, Object>> getAssetsById(String assetsId) {
		StringBuilder sql = new StringBuilder();
		sql.append("select distinct v.id,v.name from( ");
		sql.append("	select  par.mainAssetId as id, concat(ami.name,'/',ami.code) as name  from physical_asset_relation par left join assets_material_info ami on par.mainAssetId = ami.id where par.mainAssetId='"+assetsId+"'");
		sql.append("	union all");
		sql.append("	select  par.physicalAssetId AS id, concat(ami.name,'/',ami.code) as name  from physical_asset_relation par left join assets_material_info ami on par.physicalAssetId = ami.id where par.physicalAssetId='"+assetsId+"'");
		sql.append("	union all");
		sql.append("	select  par.mainAssetId as id, concat(ami.name,'/',ami.code) as name  from physical_asset_relation par left join assets_material_info ami on par.mainAssetId = ami.id where par.physicalAssetId='"+assetsId+"'");
		sql.append("	union all");
		sql.append("	select par.physicalAssetId as id ,concat(ami.name,'/',ami.code) as name from  physical_asset_relation par left join assets_material_info ami on par.physicalAssetId = ami.id where par.mainAssetId='"+assetsId+"'");
		sql.append("	) v");
		return super.getListBySql(sql.toString());
	}
}
