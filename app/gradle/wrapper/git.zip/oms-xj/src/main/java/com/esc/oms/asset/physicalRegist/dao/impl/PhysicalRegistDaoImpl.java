package com.esc.oms.asset.physicalRegist.dao.impl;

import com.esc.oms.asset.physicalRegist.dao.IPhysicalRegistDao;
import com.esc.oms.util.CommonUtils;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
@Repository
public class PhysicalRegistDaoImpl extends BaseOptionDao implements IPhysicalRegistDao{
	
	@Override
	public String getTableName() {
		return "assets_material_info";
	}

	@Override
	public List<UTMap<String, Object>> getListMaps(Map param) {
		return this.getListBySql(getSearchSql(param));
	}
	
	@Override
	public UTMap<String, Object> getById(String id){
		return super.getOneBySql(getSearchByIdSql(id));
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT ami.id,ami.`name`,ami.`codeNum`,ami.code,ami.serialNum,amc.`name` categoryName,amsc.`name` subCategoryName, " );
		sql.append(" ami.registStatus,ami.producer,ap.`name` location,ami.brand,ami.model ,ami.assetPrice,ami.totalAssets,");
		sql.append(" ami.preAssetsClass, ami.preBorrowAssetsStartDate,ami.preBorrowAssetsEndDate,ami.partA_name, ");
		sql.append(" ami.partA_telephone,ami.partB_name,ami.partB_telephone,ami.assetsUse,ami.assetsCosts, ami.category,ami.subCategory ,ami.assetsLevel ");
		sql.append(" FROM assets_material_info ami ");
		sql.append(" LEFT JOIN assets_material_category amc ON amc.id = ami.category ");
		sql.append(" LEFT JOIN assets_material_category amsc ON amsc.id = ami.subCategory ");
		sql.append(" LEFT JOIN assets_place ap ON ap.id = ami.location ");
		sql.append(" WHERE 1=1 AND ami.registStatus IS NOT NULL");
		sql.append(" AND (ami.deleteFlag != 1 OR ami.deleteFlag IS NULL) ");
		if(params!=null && params.size()>0){
			if(params.get("category")!=null && CommonUtils.notNullStrOrEmpty(params.get("category").toString())){
				sql.append(" AND amc.id = '"+params.get("category").toString().trim()+"'");
			}
			if(params.get("subCategory")!=null && CommonUtils.notNullStrOrEmpty(params.get("subCategory").toString())){
				sql.append(" AND amsc.id = '"+params.get("subCategory").toString().trim()+"'");
			}
			if(params.get("name")!=null && CommonUtils.notNullStrOrEmpty(params.get("name").toString())){ //资产合同--资产视图
				sql.append(" AND ami.name like '%"+params.get("name").toString().trim()+"%'");
			}
			if(params.get("codeNum")!=null && CommonUtils.notNullStrOrEmpty(params.get("codeNum").toString())){
//				sql.append(" AND ami.codeNum like '%"+params.get("codeNum").toString().trim()+"%'");
				sql.append(" AND (ami.codeNum like '%"+params.get("codeNum").toString().trim()+"%' OR ami.serialNum like '%"+params.get("codeNum").toString().trim()+"%')");
			}
			if(params.get("auxiliaryAsset")!=null && CommonUtils.notNullStrOrEmpty(params.get("auxiliaryAsset").toString())){
				sql.append(" AND ami.auxiliaryAsset = "+params.get("auxiliaryAsset").toString().trim()+" and (ami.parentId IS NULL OR ami.parentId = '' )");
			}
//			if(params.get("auxiliaryAsset")!=null && StringUtils.isNotEmpty(params.get("auxiliaryAsset").toString())){
//				sql.append(" AND ami.auxiliaryAsset = "+params.get("auxiliaryAsset").toString().trim()+" ");
//			}
			if(params.get("parentId")!=null && CommonUtils.notNullStrOrEmpty(params.get("parentId").toString())){
				sql.append(" AND ami.parentId = '"+params.get("parentId").toString().trim()+"'");
			}
		}
		sql.append(" order by ami.createTime desc,ami.sortCode");
		return  sql.toString();
	}
	
	
	private String getSearchByIdSql(String id){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT ami.id,ami.code,ami.`codeNum`,ami.amount,ami.availability,ami.brand,ami.parentId, " );
		sql.append(" ami.category,ami.controllable,ami.createTime,ami.createUserId, ");
		sql.append(" ami.location,ami.assetClass,ami.status,ami.assetPrice,ami.totalAssets, ");
		sql.append(" ami.model,ami.`name`,ami.producer,ami.remark, ");
		sql.append(" ami.salvage,ami.serialNum,ami.subCategory,ami.userId,ap.`name` locationName, ");
		sql.append(" amc.`name` categoryName,amsc.`name` subCategoryName,ami.registStatus,ami.auxiliaryAsset, ");
		sql.append(" ami.preAssetsClass, ami.preBorrowAssetsStartDate,ami.preBorrowAssetsEndDate,ami.partA_name, ");
		sql.append(" ami.partA_telephone,ami.partB_name,ami.partB_telephone,ami.assetsUse,ami.assetsCosts,ami.workflowInstanceId,ami.assetsLevel ");
		sql.append(" FROM assets_material_info ami ");
		sql.append(" LEFT JOIN assets_place ap ON ap.id = ami.location ");
//		sql.append(" LEFT JOIN sys_user su ON su.id = ami.resUserId ");
//		sql.append(" LEFT JOIN sys_org so ON so.id = ami.resDepartId  ");
//		sql.append(" LEFT JOIN assets_agreement_info aai ON ami.buyContract = aai.id ");
//		sql.append(" LEFT JOIN assets_agreement_info aai2 ON aai2.id = ami.maintainContract ");
		sql.append(" LEFT JOIN assets_material_category amc ON amc.id = ami.category ");
		sql.append(" LEFT JOIN assets_material_category amsc ON amsc.id = ami.subCategory ");
		sql.append(" WHERE ami.id = '"+id+"' ");
		return  sql.toString();
	}


	@Override
	public List<UTMap<String, Object>> getAssetBycodeAndId(String codeNum,
			String id) {
		String sql = "SELECT * FROM  assets_material_info ami WHERE ami.codeNum = '"+codeNum+"' AND ami.id != '"+id+"'";
		return super.getListBySql(sql);
	}


	@Override
	public void getPendPageList(Map<String, Object> params, UTPageBean pageBean) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT ami.id,ami.`name`,ami.codeNum,ami.`code`,ami.serialNum,amc.`name` categoryName,amsc.`name` subCategoryName, " );
		sql.append(" ami.registStatus,ami.producer,ap.`name` location,ami.brand,ami.model,ami.status,ami.workflowInstanceId, ");
		sql.append(" t4.currentExecutor as auditors,t4.currentStepName, ami.category,ami.subCategory ,ami.assetsLevel  ");
		sql.append(" from assets_material_info ami ");
		sql.append(" LEFT JOIN assets_material_category amc ON amc.id = ami.category ");
		sql.append(" LEFT JOIN assets_material_category amsc ON amsc.id = ami.subCategory ");
		sql.append(" LEFT JOIN assets_place ap ON ap.id = ami.location ");
		sql.append(" left join sys_workflow_instance t4 on ami.workflowInstanceId=t4.id ");
		sql.append(" where FIND_IN_SET('"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"',t4.currentExecutor) ");
		sql.append(" and ami.registStatus IS NOT NULL ");
		if(params!=null && params.size()>0){		
			if(params.get("category")!=null && StringUtils.isNotEmpty(params.get("category").toString())){
				sql.append(" AND amc.id = '"+params.get("category").toString().trim()+"'");
			}
			if(params.get("subCategory")!=null && StringUtils.isNotEmpty(params.get("subCategory").toString())){
				sql.append(" AND amsc.id = '"+params.get("subCategory").toString().trim()+"'");
			}
			if(params.get("name")!=null && StringUtils.isNotEmpty(params.get("name").toString())){ //资产合同--资产视图
				sql.append(" AND ami.name like '%"+params.get("name").toString().trim()+"%'");
			}
			if(params.get("codeNum")!=null && StringUtils.isNotEmpty(params.get("codeNum").toString())){
//				sql.append(" AND ami.codeNum like '%"+params.get("codeNum").toString().trim()+"%'");
				sql.append(" AND (ami.codeNum like '%"+params.get("codeNum").toString().trim()+"%' OR ami.serialNum like '%"+params.get("codeNum").toString().trim()+"%')");
			}
			if(params.get("auxiliaryAsset")!=null && StringUtils.isNotEmpty(params.get("auxiliaryAsset").toString())){
				sql.append(" AND ami.auxiliaryAsset = "+params.get("auxiliaryAsset").toString().trim()+" and (ami.parentId IS NULL OR ami.parentId = '' )");
			}
			if(params.get("parentId")!=null && StringUtils.isNotEmpty(params.get("parentId").toString())){
				sql.append(" AND ami.parentId = '"+params.get("parentId").toString().trim()+"'");
			}
			if( CommonUtils.notNullStrOrEmpty((String) params.get("assetsLevel"))){
				sql.append(" AND ami.assetsLevel ='"+params.get("assetsLevel")+"'");
			}
		}
		sql.append(" order by ami.createTime desc");
		super.getPageListMapBySql(sql.toString(), pageBean, null);	
	}


	@Override
	public void getAlreadyApprovalPageList(Map<String, Object> params, UTPageBean pageBean) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT DISTINCT ami.id,ami.`name`,ami.codeNum,ami.`code`,ami.serialNum,amc.`name` categoryName,amsc.`name` subCategoryName, " );
		sql.append(" ami.registStatus,ami.producer,ap.`name` location,ami.brand,ami.model,ami.status,ami.category,ami.subCategory ,ami.assetsLevel ");
		sql.append(" from assets_material_info ami ");
		sql.append(" LEFT JOIN assets_material_category amc ON amc.id = ami.category ");
		sql.append(" LEFT JOIN assets_material_category amsc ON amsc.id = ami.subCategory ");
		sql.append(" LEFT JOIN assets_place ap ON ap.id = ami.location ");
		sql.append(" left join sys_workflow_audit_history t4 on ami.workflowInstanceId = t4.instanceId ");
		sql.append(" where FIND_IN_SET('"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"',t4.optionUserId) " );
		sql.append(" and t4.nodeName <> '开始' and  ami.registStatus IS NOT NULL ");
		if(params!=null && params.size()>0){		
			if(params.get("category")!=null && StringUtils.isNotEmpty(params.get("category").toString())){
				sql.append(" AND amc.id = '"+params.get("category").toString().trim()+"'");
			}
			if(params.get("subCategory")!=null && StringUtils.isNotEmpty(params.get("subCategory").toString())){
				sql.append(" AND amsc.id = '"+params.get("subCategory").toString().trim()+"'");
			}
			if(params.get("name")!=null && StringUtils.isNotEmpty(params.get("name").toString())){ //资产合同--资产视图
				sql.append(" AND ami.name like '%"+params.get("name").toString().trim()+"%'");
			}
			if(params.get("codeNum")!=null && StringUtils.isNotEmpty(params.get("codeNum").toString())){
				sql.append(" AND (ami.codeNum like '%"+params.get("codeNum").toString().trim()+"%' OR ami.serialNum like '%"+params.get("codeNum").toString().trim()+"%')");
			}
			if(params.get("auxiliaryAsset")!=null && StringUtils.isNotEmpty(params.get("auxiliaryAsset").toString())){
				sql.append(" AND ami.auxiliaryAsset = "+params.get("auxiliaryAsset").toString().trim()+" and (ami.parentId IS NULL OR ami.parentId = '' )");
			}
			if(params.get("parentId")!=null && StringUtils.isNotEmpty(params.get("parentId").toString())){
				sql.append(" AND ami.parentId = '"+params.get("parentId").toString().trim()+"'");
			}
			if( CommonUtils.notNullStrOrEmpty((String) params.get("assetsLevel"))){
				sql.append(" AND ami.assetsLevel ='"+params.get("assetsLevel")+"'");
			}
		}
		sql.append(" order by ami.createTime desc");
		super.getPageListMapBySql(sql.toString(), pageBean, null);
	}


	@Override
	public void getPageInfo(Map params, UTPageBean pageBean) throws Exception {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT DISTINCT ami.id,ami.`name`,ami.`code`,ami.codeNum,ami.serialNum,amc.`name` categoryName,amsc.`name` subCategoryName, " );
		sql.append(" ami.registStatus,ami.producer,ap.`name` location,ami.brand,ami.model,ami.`status`,ami.workflowInstanceId,ami.preAssetsClass, ");
		sql.append(" t4.currentExecutor as auditors,t4.currentStepName,ami.assetPrice,ami.totalAssets,ami.category,ami.subCategory ,ami.assetsLevel ");
		sql.append(" from assets_material_info ami ");
		sql.append(" LEFT JOIN assets_material_category amc ON amc.id = ami.category ");
		sql.append(" LEFT JOIN assets_material_category amsc ON amsc.id = ami.subCategory ");
		sql.append(" LEFT JOIN assets_place ap ON ap.id = ami.location ");
		sql.append(" left join sys_workflow_instance t4 on ami.workflowInstanceId=t4.id ");
		sql.append(" where  ami.registStatus IS NOT NULL and (ami.deleteFlag is null or ami.deleteFlag = 0)  ");
		if(params!=null && params.size()>0){		
			if(params.get("category")!=null && CommonUtils.notNullStrOrEmpty(params.get("category").toString())){
				sql.append(" AND amc.id = '"+params.get("category").toString().trim()+"'");
			}
			if(params.get("subCategory")!=null && CommonUtils.notNullStrOrEmpty(params.get("subCategory").toString())){
				sql.append(" AND amsc.id = '"+params.get("subCategory").toString().trim()+"'");
			}
			if(params.get("name")!=null && CommonUtils.notNullStrOrEmpty(params.get("name").toString())){ //资产合同--资产视图
				sql.append(" AND ami.name like '%"+params.get("name").toString().trim()+"%'");
			}
			if(params.get("codeNum")!=null && CommonUtils.notNullStrOrEmpty(params.get("codeNum").toString())){
//				sql.append(" AND ami.codeNum like '%"+params.get("codeNum").toString().trim()+"%'");
				sql.append(" AND (ami.codeNum like '%"+params.get("codeNum").toString().trim()+"%' OR ami.serialNum like '%"+params.get("codeNum").toString().trim()+"%')");
			}
			if(params.get("auxiliaryAsset")!=null && CommonUtils.notNullStrOrEmpty(params.get("auxiliaryAsset").toString())){
				sql.append(" AND ami.auxiliaryAsset = "+params.get("auxiliaryAsset").toString().trim()+" and (ami.parentId IS NULL OR ami.parentId = '' )");
			}
			if(params.get("parentId")!=null && CommonUtils.notNullStrOrEmpty(params.get("parentId").toString())){
				sql.append(" AND ami.parentId = '"+params.get("parentId").toString().trim()+"'");
			}
			if( CommonUtils.notNullStrOrEmpty((String) params.get("assetsLevel"))){
				sql.append(" AND ami.assetsLevel ='"+params.get("assetsLevel")+"'");
			}
			//如果是查询辅助资产
			if(params.get("isAuxiliaryAsset")!=null && CommonUtils.notNullStrOrEmpty(params.get("isAuxiliaryAsset").toString())) {
				String preAssetsClass = (String)params.get("preAssetsClass");//只有1和2两个值
				if("1".equals(preAssetsClass)){//预登记
					sql.append(" AND(ami.preAssetsClass = '1' and ami.status = '4') ");
				}else{//借用预登记
					sql.append(" and ami.preAssetsClass = '2' ");
				}
			}
			//查辅助资产不查本身
			if(params.get("exId")!=null && CommonUtils.notNullStrOrEmpty(params.get("exId").toString())) {
				sql.append(" AND ami.id <> '"+params.get("exId").toString().trim()+"' ");
			}
		}
		sql.append(" order by ami.createTime desc");
		super.getPageListMapBySql(sql.toString(), pageBean, null);	
		
	}

	
}
