package com.esc.oms.outsource.monitor.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.monitor.dao.IMonitorEvaluateDao;
import com.esc.oms.util.RoleUtils;

/**
 * 服务监控评估Dao
 * @author owner
 *
 */
@Repository
public class MonitorEvaluateDaoImpl extends BaseOptionDao implements IMonitorEvaluateDao{

	@Override
	public String getTableName() {
		return "outsourc_monitor_evaluate";
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params,false), pageBean, null);
	}
	
	@Override
	public List<UTMap<String, Object>> getListMaps(Map param) {
		return super.getListBySql(getSearchSql(param,false), null);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params) {
		return super.getListBySql(getSearchSql(params,false), null);
	}
	
	@Override
	public UTMap<String, Object> getById(String id) {
		String sql = this.getSearchSql(null,true);
		List<UTMap<String, Object>> list = super.getListBySql(sql, id);
		if(list != null && list.size() > 0){
			return list.get(0);
		}
		return null;
	}
	
	/**
	 * 单一数据评估后，需要删除同一批时间点生成的其它数据
	 * @param id 不用删除的数据id
	 * @param monitorEvaluateConfigId 服务监控配置id
	 * @param createTime 标识同一批时间点生成的监控数据
	 */
	@Override
	public void deleteBySingle(String id, String monitorEvaluateConfigId, String createTime ) {
		StringBuilder sql = new StringBuilder();
		sql.append(" delete from  ");
		sql.append(getTableName());
		sql.append(" where id != ? and  monitorEvaluateConfigId = ? and DATEDIFF(?,createTime) = 0 ");
		this.executeUpdate(sql.toString(), id, monitorEvaluateConfigId, createTime);
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params,boolean isGetById){
		StringBuilder sql = new StringBuilder();
		sql.append(" select sae.*,concat(su.name,'/',su.code) as 'evaluatorName',concat(su2.name,'/',su2.code) as 'submitterName',sbi.name as 'supplierName' ");
		sql.append(" from outsourc_monitor_evaluate sae ");
//		sql.append(" left join outsourc_riskoverall_evaluate_template saet on sae.riskOverallEvaluateTemplateId = saet.id ");
//		sql.append(" left join outsourc_monitor_evaluate_configuration sae on sae.monitorEvaluateConfigId = sae.id ");
		sql.append(" left join supplier_base_info sbi on sae.supplierId = sbi.id ");
		sql.append(" left join sys_user su on sae.evaluator = su.id ");
		sql.append(" left join sys_user su2 on sae.submitter = su2.id" );
		sql.append(" where 1=1 ");
		//供应商管理员不做数据过滤，监控人员只查看本人的监控数据
		if(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId() != null && !EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR,RoleUtils.SUPPLIER_ADMINISTRATOR)){
			sql.append(" and sae.monitorEvaluator like '%"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"%' ");//非研发用户只能查询自己的数据，研发用户查询所有数据方便调试
		}
		if(isGetById){
			sql.append(" and sae.id = ? ");
		}
		if(params!=null && params.size()>0){
			
			if(params.get("evaluateTitle")!=null &&  StringUtils.isNotEmpty(params.get("evaluateTitle").toString())){
				sql.append(" and sae.evaluateTitle like '%"+params.get("evaluateTitle").toString().trim()+"%' ");
			}
			if(params.get("monitorEvaluateConfigId")!=null && StringUtils.isNotEmpty(params.get("monitorEvaluateConfigId").toString())){
				sql.append(" and sae.monitorEvaluateConfigId = '"+params.get("monitorEvaluateConfigId").toString().trim()+"' ");
			}
			//查询同一批时间点自动生成生成的数据
			if(params.get("createTime")!=null && StringUtils.isNotEmpty(params.get("createTime").toString())){
				sql.append(" and DATEDIFF('"+params.get("createTime").toString().trim()+"',createTime) = 0 ");
			}
			if(params.get("supplierName")!=null &&  StringUtils.isNotEmpty(params.get("supplierName").toString())){
				sql.append(" and sbi.name like '%"+params.get("supplierName").toString().trim()+"%' ");
			}
			if(params.get("type")!=null && StringUtils.isNotEmpty(params.get("type").toString())){
				sql.append(" and sae.type = "+params.get("type").toString().trim()+" ");
			}
			if(params.get("status")!=null && StringUtils.isNotEmpty(params.get("status").toString())){
				sql.append(" and sae.status = "+params.get("status").toString().trim()+" ");
			}
			if(params.get("dataType")!=null && StringUtils.isNotEmpty(params.get("dataType").toString())){
				sql.append(" and sae.dataType = '"+params.get("dataType").toString().trim()+"' ");
			}
//			if(params.get("subType")!=null && StringUtils.isNotEmpty(params.get("subType").toString())){
//				sql.append(" and tb.subType = "+params.get("subType").toString().trim()+" ");
//			}
		}
		sql.append(" order by sae.createTime desc,importSort");
		return  sql.toString();
	}

}
