package com.esc.oms.outsource.manhour.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.outsource.manhour.service.IManHourStatisticService;
import com.esc.oms.util.CommonUtils;

@Controller
@RequestMapping("outsource/manhourstatistic")
public class ManHourStatisticController {
	
	private static final Logger logger = Logger.getLogger(ManHourStatisticController.class);
	
	@Resource
	private IManHourStatisticService manHourStatisticService;

	/**
	 * 工时统计（供应商）
	 * 
	 * @param param
	 * @return
	 */
	@RequestMapping(value = "baseOnSupplier")
	@ResponseBody
	public UTPageBean baseOnSupplier(@RequestParam Map<String, Object> param) {
		UTPageBean pageBean = CommonUtils.getPageBean(param);
		try {
			manHourStatisticService.baseOnSupplier(param, pageBean);
		} catch (Exception e) {
			logger.error("Exception", e);
		}
		return pageBean;
	}
	
	/**
	 * 工时统计（部门）
	 * 
	 * @param param
	 * @return
	 */
	@RequestMapping(value = "baseOnOrg")
	@ResponseBody
	public UTPageBean baseOnOrg(@RequestParam Map<String, Object> param) {
		UTPageBean pageBean = CommonUtils.getPageBean(param);
		try {
			manHourStatisticService.baseOnOrg(param, pageBean);
		} catch (Exception e) {
			logger.error("Exception", e);
		}
		return pageBean;
	}
	
	@RequestMapping(value = "reportForMainPage/{baseOn}/{type}")
	@ResponseBody
	public List<UTMap<String, Object>> reportForMainPage(@ModelAttribute(value="baseOn") String baseOn, @ModelAttribute(value="type") String type, @RequestParam Map<String, Object> param) {
		List<UTMap<String, Object>> list = null;
		try {
			list = manHourStatisticService.reportForMainPage(baseOn, type, param);
		} catch (Exception e) {
			logger.error("Exception", e);
			list = new ArrayList<UTMap<String,Object>>();
		}
		return list;
	}
	
	/**
	 * 工时统计详细
	 * 
	 * @param param
	 * @return
	 */
	@RequestMapping(value = "getDetail/{type}")
	@ResponseBody
	public UTPageBean getDetail(@ModelAttribute("type") String type, @RequestParam Map<String, Object> param) {
		UTPageBean pageBean = CommonUtils.getPageBean(param);
		try {
			manHourStatisticService.getDetailPage(type, param, pageBean);
		} catch (Exception e) {
			logger.error("Exception", e);
		}
		return pageBean;
	}
	
	

	@RequestMapping(value = "leadingout/{type}")
	public void leadingout(@ModelAttribute("type") String type, @RequestParam Map<String, Object> map1, HttpServletRequest request,
			HttpServletResponse response) {
		Map<String,Object> cloneMap = CommonUtils.clone(map1);
		UTPageBean clonePageBean = CommonUtils.getPageBean(cloneMap);
		
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) cloneMap.get("outType"));
			Object info = cloneMap.get("params");
			JSONObject jsonBean = JSONObject.fromObject(info);
			Map queryParam = UTMap.mapObjToString(jsonBean);
			// 开始时间、结束时间判断：有开始和结束，需要判断开始时间是否在结束时间之前，其他没所谓
			boolean timeOk = false;
			String beginTime = (String) queryParam.get("beginTime");
			String endTime = (String) queryParam.get("endTime");
			if(StringUtils.isNotEmpty(beginTime) && StringUtils.isNotEmpty(endTime)) {
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				Calendar beginCalendar = Calendar.getInstance();
				Calendar endCalendar = Calendar.getInstance();
				beginCalendar.setTime(dateFormat.parse(beginTime));
				endCalendar.setTime(dateFormat.parse(endTime));
				if(beginCalendar.equals(endCalendar) || beginCalendar.before(endCalendar)) {
					timeOk = true;
				}
			} else {
				timeOk = true;
			}
			if(timeOk) {
				// 根据条件 导出全部
				if (UTExcel.EXCELOUTTYPE_ALL == outType) {
					// getAll
					if("baseOnSupplier".equals(type)) {
						data = manHourStatisticService.baseOnSupplierList(queryParam);
					} else if("baseOnOrg".equals(type)) {
						data = manHourStatisticService.baseOnOrgList(queryParam);
					}
				} else {
					// 根据条件 导出当前
					if("baseOnSupplier".equals(type)) {
						manHourStatisticService.baseOnSupplier(queryParam, clonePageBean);
					} else if("baseOnOrg".equals(type)) {
						manHourStatisticService.baseOnOrg(queryParam, clonePageBean);
					}
					data = clonePageBean.getRows();
				}
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			manHourStatisticService.leadingout(type, queryParam, data, request, response);
		}catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	
	@RequestMapping(value = "leadingoutDetail/{type}")
	public void leadingoutDetail(@ModelAttribute("type") String type, @RequestParam Map<String, Object> param,  HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean pageBean = CommonUtils.getPageBean(param);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = JSONObject.fromObject(info);
			Map queryParam = UTMap.mapObjToString(jsonBean);
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = manHourStatisticService.getDetailList(type, queryParam);
			} else {
				// 根据条件 导出当前
				manHourStatisticService.getDetailPage(type, queryParam, pageBean);
				data = pageBean.getRows();
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			manHourStatisticService.leadingoutDetail(type, data, request, response);
		}catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
}
