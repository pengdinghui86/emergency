package com.esc.oms.outsource.monitor.dao;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

/**
 * 第三方机构检查
 * @author owner
 *
 */
public interface IDuediligenceThirdDao extends IBaseOptionDao{
	public static final String  FIELD_ID= "id";
	
	/**
	 * 根据模板配置查询对应的第三方机构数据
	 * @param duediligenceEvaluateConfigId
	 * @return
	 */
	public UTMap<String, Object> getByDuediligenceEvaluateConfigId(String duediligenceEvaluateConfigId);
}
