package com.esc.oms.outsource.manhour.service.impl;

import com.esc.oms.outsource.agreementManpower.service.IAgreementManpowerInfoService;
import com.esc.oms.outsource.attendance.dao.IFestivalDao;
import com.esc.oms.outsource.attendance.service.IAttendanceDefaultService;
import com.esc.oms.outsource.attendance.service.IAttendanceService;
import com.esc.oms.outsource.attendance.service.IDingDingAttendanceService;
import com.esc.oms.outsource.manhour.dao.*;
import com.esc.oms.outsource.manhour.service.IManHourStatisticService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.FunctionEnum;
import com.esc.oms.util.LocalDateUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
@Transactional
public class ManHourStatisticServiceImpl implements IManHourStatisticService {

	private static final Logger logger = Logger.getLogger(ManHourStatisticServiceImpl.class);

	@Resource
	private IManHourStatisticDao manHourStatisticDao;

	@Resource
	private IFestivalDao festivalDao;

	@Resource
	private IOvertimeDao overtimeDao;

	@Resource
	private IVacationDetailDao vacationDetailDao;

	@Resource
	private ITravelDetailDao travelDetailDao;

	@Resource
	private IAgreementManpowerInfoService agreementManpowerInfoService;

	@Resource
	private ISysParamService sysParamService;
	@Resource
	private IDingDingAttendanceService dingDingAttendanceService;

	@Resource
	private IAttendanceDefaultService attendanceDefaultService;

	@Resource
	private IAttendanceService attendanceService;

	@Override
	public List<Map<String, Object>> calculateSeconds(String beginTime, String endTime, UTMap<String, Object> userConfig) {
		return calculateSeconds(beginTime, endTime, userConfig, false);
	}

	@Override
	public List<Map<String, Object>> calculateVacationSeconds(String beginTime, String endTime, UTMap<String, Object> userConfig) {
		List<Map<String, Object>> secondsList = new ArrayList<Map<String, Object>>(); // 保存每天的详细
		String formatString = "yyyy-MM-dd HH:mm:ss"; // 前台时间格式
		String format2String = "yyyy-MM-dd";//年月日格式
		// 获取开始结束的时分秒，转换以秒为单位
		Calendar beginDate = Calendar.getInstance();
		Calendar endDate = Calendar.getInstance();
		Calendar thisDate = Calendar.getInstance(); // 当前日期，在循环中确认当前的日期
		SimpleDateFormat format = null;
		SimpleDateFormat format2 = null;
		final long days = UTDate.getDays(beginTime, endTime); // 开始到结束时间的天数
		List<UTMap<String, Object>> seasonList = dingDingAttendanceService.getSeason();
		try {
			format = new SimpleDateFormat(formatString);
			format2 = new SimpleDateFormat(format2String);
			beginDate.setTime(format.parse(beginTime));
			endDate.setTime(format.parse(endTime));
			thisDate.set(beginDate.get(Calendar.YEAR), beginDate.get(Calendar.MONTH), beginDate.get(Calendar.DAY_OF_MONTH), 0,0,0); // 记录计算的当前日期
		} catch (Exception e) {
			logger.error("Exception",e);
		}


		long timeBegin = beginDate.get(Calendar.HOUR_OF_DAY) * 3600 + beginDate.get(Calendar.MINUTE) * 60; // 开始的时分秒
		long timeEnd = endDate.get(Calendar.HOUR_OF_DAY) * 3600 + endDate.get(Calendar.MINUTE) * 60; // 结束的时分秒

		// 获取个人的考勤配置、
		// =======================假定的数据====都以秒为单位============================
		long amBegin = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "amBegin")); // 上午开始时间
		long amEnd = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "amEnd")); // 上午结束时间
		long pmBegin = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "pmBegin")); // 下午开始时间
		long pmEnd = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "pmEnd")); // 下午结束时间
		// 转换以秒为单位
		long dailyHoursAM = amEnd - amBegin; // 每天上午固定的工时
		long dailyHoursPM = pmEnd - pmBegin; // 每天下午固定的工时
		long dailyHours = dailyHoursAM + dailyHoursPM; // 每天固定的工时
		String attendanceDateType = null;
		if(userConfig != null) {
			attendanceDateType = (String) userConfig.get("attendanceDateType"); // 考勤方式:(1.确定时间，2.不确定时间)
		}
		String today = "";

		if(days == 1){//如果只有一天
			today = format2.format(thisDate.getTime());
			String seasonType = dingDingAttendanceService.checkSeason(LocalDateUtil.getLocalDatestamp(today), seasonList);
			if(userConfig != null && ("1".equals(attendanceDateType) || "2".equals(attendanceDateType) && "1".equals(userConfig.get("attendanceType")))){//有配置
				//具体时间的配置
				if(seasonType.equals(FunctionEnum.SeasonType.summer.getCode())){
					amBegin = UTDate.transformTimeToSecond((String) userConfig.get("amBegin"));
					amEnd = UTDate.transformTimeToSecond((String) userConfig.get("amEnd"));
					pmBegin = UTDate.transformTimeToSecond((String) userConfig.get("pmBegin"));
					pmEnd = UTDate.transformTimeToSecond((String) userConfig.get("pmEnd"));
				}else{
					amBegin = UTDate.transformTimeToSecond((String) userConfig.get("winterAmBegin"));
					amEnd = UTDate.transformTimeToSecond((String) userConfig.get("winterAmEnd"));
					pmBegin = UTDate.transformTimeToSecond((String) userConfig.get("winterPmBegin"));
					pmEnd = UTDate.transformTimeToSecond((String) userConfig.get("winterPmEnd"));
				}

			}else{//没有配置，则去默认中的值
				if(seasonType.equals(FunctionEnum.SeasonType.summer.getCode())){
					amBegin = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "amBegin")); // 上午开始时间
					amEnd = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "amEnd")); // 上午结束时间
					pmBegin = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "pmBegin")); // 下午开始时间
					pmEnd = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "pmEnd")); // 下午结束时间
				}else{
					amBegin = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "winterAmBegin")); // 上午开始时间
					amEnd = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "winterAmEnd")); // 上午结束时间
					pmBegin = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "winterPmBegin")); // 下午开始时间
					pmEnd = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "winterPmEnd")); // 下午结束时间
				}
			}
			dailyHoursAM =  amEnd - amBegin ; // 每天上午固定的工时
			dailyHoursPM =  pmEnd - pmBegin ; // 每天下午固定的工时
			dailyHours =  dailyHoursAM + dailyHoursPM ; // 每天固定的工时
			Map<String, Object> hourMap = new HashMap<String, Object>();
			hourMap.put("beginTime", beginTime); // 保存当天的开始时间
			hourMap.put("endTime", endTime); // 保存当天的结束时间
			long thisDayTime = 0; // 计算开始到结束的工时，以秒为单位
			// 1、判断节假日
			String isWorkDay = isWorkDay(thisDate, userConfig); // 1是正常上班
			if("1".equals(isWorkDay)){//工作日才算上班
				if(timeBegin <= amEnd && timeEnd <= pmBegin && timeEnd >= amBegin || timeBegin >= amEnd && timeEnd >= pmBegin){
					//同一侧，则算4个小时
					hourMap.put("seconds", 4*60*60l);//4个小时
					secondsList.add(hourMap);
				}else if(timeBegin <= amEnd && timeEnd>= pmBegin){
					hourMap.put("seconds", dailyHours);//一天
					secondsList.add(hourMap);
				}
			}
		}else {
			for (int i = 1; i <= days; i++) {
				today = format2.format(thisDate.getTime());
				String seasonType = dingDingAttendanceService.checkSeason(LocalDateUtil.getLocalDatestamp(today), seasonList);
				if(userConfig != null && ("1".equals(attendanceDateType) || "2".equals(attendanceDateType) && "1".equals(userConfig.get("attendanceType")))){//有配置
					//具体时间的配置
					if(seasonType.equals(FunctionEnum.SeasonType.summer.getCode())){
						amBegin = UTDate.transformTimeToSecond((String) userConfig.get("amBegin"));
						amEnd = UTDate.transformTimeToSecond((String) userConfig.get("amEnd"));
						pmBegin = UTDate.transformTimeToSecond((String) userConfig.get("pmBegin"));
						pmEnd = UTDate.transformTimeToSecond((String) userConfig.get("pmEnd"));
					}else{
						amBegin = UTDate.transformTimeToSecond((String) userConfig.get("winterAmBegin"));
						amEnd = UTDate.transformTimeToSecond((String) userConfig.get("winterAmEnd"));
						pmBegin = UTDate.transformTimeToSecond((String) userConfig.get("winterPmBegin"));
						pmEnd = UTDate.transformTimeToSecond((String) userConfig.get("winterPmEnd"));
					}

				}else{//没有配置，则去默认中的值
					if(seasonType.equals(FunctionEnum.SeasonType.summer.getCode())){
						amBegin = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "amBegin")); // 上午开始时间
						amEnd = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "amEnd")); // 上午结束时间
						pmBegin = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "pmBegin")); // 下午开始时间
						pmEnd = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "pmEnd")); // 下午结束时间
					}else{
						amBegin = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "winterAmBegin")); // 上午开始时间
						amEnd = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "winterAmEnd")); // 上午结束时间
						pmBegin = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "winterPmBegin")); // 下午开始时间
						pmEnd = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "winterPmEnd")); // 下午结束时间
					}
				}
				dailyHoursAM =amEnd - amBegin ; // 每天上午固定的工时
				dailyHoursPM =  pmEnd - pmBegin ; // 每天下午固定的工时
				dailyHours =  dailyHoursAM + dailyHoursPM ; // 每天固定的工时
				// 1、判断节假日
				String isWorkDay = isWorkDay(thisDate, userConfig); // 1是正常上班
				if(!"1".equals(isWorkDay)) {//工作日
					thisDate.add(Calendar.DAY_OF_MONTH, 1); // 自动换到下一天
					continue;
				}
				// 1、确定时间考勤，2、不确定时间的考勤：不确定时间的考勤统计方式：（1.统计考勤次数；2.统计考勤时间（单位是小时））
				if (("1".equals(attendanceDateType) || "2".equals(attendanceDateType) && "1".equals(userConfig.get("attendanceType")))) {//冬令时
					if(seasonType.equals(FunctionEnum.SeasonType.winter.getCode())){
						amBegin = UTDate.transformTimeToSecond((String) userConfig.get("winterAmBegin"));
						amEnd = UTDate.transformTimeToSecond((String) userConfig.get("winterAmEnd"));
						pmBegin = UTDate.transformTimeToSecond((String) userConfig.get("winterPmBegin"));
						pmEnd = UTDate.transformTimeToSecond((String) userConfig.get("winterPmEnd"));
						dailyHoursAM = userConfig.get("winterDailyHoursAM") == null ? amEnd - amBegin : (Integer) userConfig.get("winterDailyHoursAM"); // 每天上午固定的工时
						dailyHoursPM = userConfig.get("winterDailyHoursPM") == null ? pmEnd - pmBegin : (Integer) userConfig.get("winterDailyHoursPM"); // 每天下午固定的工时
						dailyHours = userConfig.get("winterDailyHours") == null ? dailyHoursAM + dailyHoursPM : (Integer) userConfig.get("winterDailyHours"); // 每天固定的工时
					}else{
						amBegin = UTDate.transformTimeToSecond((String) userConfig.get("amBegin"));
						amEnd = UTDate.transformTimeToSecond((String) userConfig.get("amEnd"));
						pmBegin = UTDate.transformTimeToSecond((String) userConfig.get("pmBegin"));
						pmEnd = UTDate.transformTimeToSecond((String) userConfig.get("pmEnd"));
						dailyHoursAM = userConfig.get("dailyHoursAM") == null ? amEnd - amBegin : (Integer) userConfig.get("dailyHoursAM"); // 每天上午固定的工时
						dailyHoursPM = userConfig.get("dailyHoursPM") == null ? pmEnd - pmBegin : (Integer) userConfig.get("dailyHoursPM"); // 每天下午固定的工时
						dailyHours = userConfig.get("dailyHours") == null ? dailyHoursAM + dailyHoursPM : (Integer) userConfig.get("dailyHours"); // 每天固定的工时
					}

				}

				Map<String, Object> hourMap = new HashMap<String, Object>();
				if(1==i){//第一天需要考虑上午下午
					if(userConfig != null && ("1".equals(attendanceDateType) || "2".equals(attendanceDateType) && "1".equals(userConfig.get("attendanceType")))){//有配置
						//具体时间的配置
						if(seasonType.equals(FunctionEnum.SeasonType.summer.getCode())){
							amBegin = UTDate.transformTimeToSecond((String) userConfig.get("amBegin"));
							amEnd = UTDate.transformTimeToSecond((String) userConfig.get("amEnd"));
							pmBegin = UTDate.transformTimeToSecond((String) userConfig.get("pmBegin"));
							pmEnd = UTDate.transformTimeToSecond((String) userConfig.get("pmEnd"));
						}else{
							amBegin = UTDate.transformTimeToSecond((String) userConfig.get("winterAmBegin"));
							amEnd = UTDate.transformTimeToSecond((String) userConfig.get("winterAmEnd"));
							pmBegin = UTDate.transformTimeToSecond((String) userConfig.get("winterPmBegin"));
							pmEnd = UTDate.transformTimeToSecond((String) userConfig.get("winterPmEnd"));
						}

					}else{//没有配置，则去默认中的值
						if(seasonType.equals(FunctionEnum.SeasonType.summer.getCode())){
							amBegin = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "amBegin")); // 上午开始时间
							amEnd = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "amEnd")); // 上午结束时间
							pmBegin = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "pmBegin")); // 下午开始时间
							pmEnd = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "pmEnd")); // 下午结束时间
						}else{
							amBegin = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "winterAmBegin")); // 上午开始时间
							amEnd = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "winterAmEnd")); // 上午结束时间
							pmBegin = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "winterPmBegin")); // 下午开始时间
							pmEnd = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "winterPmEnd")); // 下午结束时间
						}
					}
					dailyHoursAM = amEnd - amBegin ; // 每天上午固定的工时
					dailyHoursPM = pmEnd - pmBegin ; // 每天下午固定的工时
					dailyHours =  dailyHoursAM + dailyHoursPM ; // 每天固定的工时
					Calendar thisDateEnd = Calendar.getInstance();
					thisDateEnd.setTimeInMillis(thisDate.getTimeInMillis() + pmEnd * 1000);
					hourMap.put("beginTime", beginTime);
					hourMap.put("endTime", format.format(thisDateEnd.getTime())); // 保存当天的结束时间
					if(timeBegin <= amEnd){//全天
						hourMap.put("seconds", dailyHours);//一天
						secondsList.add(hourMap);
					}else if(timeBegin >= amEnd && timeBegin <= pmEnd){//半天
						hourMap.put("seconds", 4*60*60l);//4个小时
						secondsList.add(hourMap);
					}
				}else if(i == days){//最后一天
					if(userConfig != null && ("1".equals(attendanceDateType) || "2".equals(attendanceDateType) && "1".equals(userConfig.get("attendanceType")))){//有配置
						//具体时间的配置
						if(seasonType.equals(FunctionEnum.SeasonType.summer.getCode())){
							amBegin = UTDate.transformTimeToSecond((String) userConfig.get("amBegin"));
							amEnd = UTDate.transformTimeToSecond((String) userConfig.get("amEnd"));
							pmBegin = UTDate.transformTimeToSecond((String) userConfig.get("pmBegin"));
							pmEnd = UTDate.transformTimeToSecond((String) userConfig.get("pmEnd"));
						}else{
							amBegin = UTDate.transformTimeToSecond((String) userConfig.get("winterAmBegin"));
							amEnd = UTDate.transformTimeToSecond((String) userConfig.get("winterAmEnd"));
							pmBegin = UTDate.transformTimeToSecond((String) userConfig.get("winterPmBegin"));
							pmEnd = UTDate.transformTimeToSecond((String) userConfig.get("winterPmEnd"));
						}

					}else{//没有配置，则去默认中的值
						if(seasonType.equals(FunctionEnum.SeasonType.summer.getCode())){
							amBegin = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "amBegin")); // 上午开始时间
							amEnd = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "amEnd")); // 上午结束时间
							pmBegin = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "pmBegin")); // 下午开始时间
							pmEnd = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "pmEnd")); // 下午结束时间
						}else{
							amBegin = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "winterAmBegin")); // 上午开始时间
							amEnd = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "winterAmEnd")); // 上午结束时间
							pmBegin = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "winterPmBegin")); // 下午开始时间
							pmEnd = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "winterPmEnd")); // 下午结束时间
						}
					}
					dailyHoursAM =  amEnd - amBegin ; // 每天上午固定的工时
					dailyHoursPM =  pmEnd - pmBegin ; // 每天下午固定的工时
					dailyHours = dailyHoursAM + dailyHoursPM ; // 每天固定的工时
					Calendar thisDateBegin = Calendar.getInstance();
					thisDateBegin.setTimeInMillis(thisDate.getTimeInMillis() + amBegin * 1000);
					hourMap.put("endTime", endTime);
					hourMap.put("beginTime", format.format(thisDateBegin.getTime())); // 保存当天的结束时间
					if(timeEnd >= pmBegin){//全天
							hourMap.put("seconds", dailyHours);//一天
							secondsList.add(hourMap);
						}else if(timeEnd <= pmBegin && timeEnd >= amBegin){//半天
							hourMap.put("seconds", 4*60*60l);//4个小时
							secondsList.add(hourMap);
						}
				}else{//算全天
					hourMap.put("seconds", dailyHours);//一天
					Calendar thisDateBegin = Calendar.getInstance();
					thisDateBegin.setTimeInMillis(thisDate.getTimeInMillis() + amBegin * 1000);
					Calendar thisDateEnd = Calendar.getInstance();
					thisDateEnd.setTimeInMillis(thisDate.getTimeInMillis() + pmEnd * 1000);
					hourMap.put("beginTime", format.format(thisDateBegin.getTime())); // 保存当天的结束时间
					hourMap.put("endTime", format.format(thisDateEnd.getTime())); // 保存当天的结束时间
					secondsList.add(hourMap);
				}
				thisDate.add(Calendar.DAY_OF_MONTH, 1); // 自动换到下一天
			}
		}

		return secondsList;
	}

	@Override
	public Map<String, Object> calculateSecondsNew(String beginTime, String endTime, UTMap<String, Object> userConfig, String seasonType) {
		Map<String, Object> secondsMap = new HashMap<>(); // 保存每天的详细
		String formatString = "yyyy-MM-dd HH:mm"; // 前台时间格式
		// 获取开始结束的时分秒，转换以秒为单位
		Calendar beginDate = Calendar.getInstance();
		Calendar endDate = Calendar.getInstance();
		Calendar thisDate = Calendar.getInstance(); // 当前日期，在循环中确认当前的日期
		SimpleDateFormat format = null;
		try {
			format = new SimpleDateFormat(formatString);
			beginDate.setTime(format.parse(beginTime));
			endDate.setTime(format.parse(endTime));
			thisDate.set(beginDate.get(Calendar.YEAR), beginDate.get(Calendar.MONTH), beginDate.get(Calendar.DAY_OF_MONTH), 0,0,0); // 记录计算的当前日期
		} catch (Exception e) {
			logger.error("Exception",e);
		}


		long timeBegin = beginDate.get(Calendar.HOUR_OF_DAY) * 3600 + beginDate.get(Calendar.MINUTE) * 60; // 开始的时分秒
		long timeEnd = endDate.get(Calendar.HOUR_OF_DAY) * 3600 + endDate.get(Calendar.MINUTE) * 60; // 结束的时分秒

		// 获取个人的考勤配置、
		// =======================假定的数据====都以秒为单位============================
		long amBegin = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "amBegin")); // 上午开始时间
		long amEnd = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "amEnd")); // 上午结束时间
		long pmBegin = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "pmBegin")); // 下午开始时间
		long pmEnd = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "pmEnd")); // 下午结束时间
		// 转换以秒为单位
		long dailyHoursAM = amEnd - amBegin; // 每天上午固定的工时
		long dailyHoursPM = pmEnd - pmBegin; // 每天下午固定的工时
		long breakTime = pmBegin - amEnd; // 中午休息时间
		long dailyHours = dailyHoursAM + dailyHoursPM; // 每天固定的工时
		String attendanceDateType = null;
		if(userConfig != null) {
			attendanceDateType = (String) userConfig.get("attendanceDateType"); // 考勤方式:(1.确定时间，2.不确定时间)
			// 考勤模块：不确定时间考勤的按工时：整天都算是工作时间
			if("2".equals(attendanceDateType) && "2".equals(userConfig.get("attendanceType"))) { // 不确定时间的考勤：不确定时间的考勤统计方式：（1.统计考勤次数；2.统计考勤时间（单位是小时））
				amBegin = 0;
				pmEnd = 86400;
			}

			if(pmEnd == 0){
				pmEnd = 86400;//00:00转换为24:00的秒数
			}
			// 转换以秒为单位
			dailyHoursAM = userConfig.get("dailyHoursAM") == null ? amEnd - amBegin : (Integer) userConfig.get("dailyHoursAM"); // 每天上午固定的工时
			dailyHoursPM = userConfig.get("dailyHoursPM") == null ? pmEnd - pmBegin : (Integer) userConfig.get("dailyHoursPM"); // 每天下午固定的工时
			breakTime = userConfig.get("breakTime") == null ? pmBegin - amEnd : (Integer) userConfig.get("breakTime"); // 中午休息时间
			dailyHours = userConfig.get("dailyHours") == null ? dailyHoursAM + dailyHoursPM : (Integer) userConfig.get("dailyHours"); // 每天固定的工时
			// 1、确定时间考勤，2、不确定时间的考勤：不确定时间的考勤统计方式：（1.统计考勤次数；2.统计考勤时间（单位是小时））
			if(("1".equals(attendanceDateType) || "2".equals(attendanceDateType) && "1".equals(userConfig.get("attendanceType")))){//冬令时
				if(seasonType.equals(FunctionEnum.SeasonType.winter.getCode())){
					amBegin = UTDate.transformTimeToSecond((String) userConfig.get("winterAmBegin"));
					amEnd = UTDate.transformTimeToSecond((String) userConfig.get("winterAmEnd"));
					pmBegin = UTDate.transformTimeToSecond((String) userConfig.get("winterPmBegin"));
					pmEnd = UTDate.transformTimeToSecond((String) userConfig.get("winterPmEnd"));
					dailyHoursAM = userConfig.get("winterDailyHoursAM") == null ? amEnd - amBegin : (Integer) userConfig.get("winterDailyHoursAM"); // 每天上午固定的工时
					dailyHoursPM = userConfig.get("winterDailyHoursPM") == null ? pmEnd - pmBegin : (Integer) userConfig.get("winterDailyHoursPM"); // 每天下午固定的工时
					breakTime = userConfig.get("winterBreakTime") == null ? pmBegin - amEnd : (Integer) userConfig.get("winterBreakTime"); // 中午休息时间
					dailyHours = userConfig.get("winterDailyHours") == null ? dailyHoursAM + dailyHoursPM : (Integer) userConfig.get("winterDailyHours"); // 每天固定的工时
				}else{
					amBegin = UTDate.transformTimeToSecond((String) userConfig.get("amBegin"));
					amEnd = UTDate.transformTimeToSecond((String) userConfig.get("amEnd"));
					pmBegin = UTDate.transformTimeToSecond((String) userConfig.get("pmBegin"));
					pmEnd = UTDate.transformTimeToSecond((String) userConfig.get("pmEnd"));
					dailyHoursAM = userConfig.get("dailyHoursAM") == null ? amEnd - amBegin : (Integer) userConfig.get("dailyHoursAM"); // 每天上午固定的工时
					dailyHoursPM = userConfig.get("dailyHoursPM") == null ? pmEnd - pmBegin : (Integer) userConfig.get("dailyHoursPM"); // 每天下午固定的工时
					breakTime = userConfig.get("breakTime") == null ? pmBegin - amEnd : (Integer) userConfig.get("breakTime"); // 中午休息时间
					dailyHours = userConfig.get("dailyHours") == null ? dailyHoursAM + dailyHoursPM : (Integer) userConfig.get("dailyHours"); // 每天固定的工时
				}

			}

			//计算上下班的工时，迟到和早退是不算工时的
			secondsMap.put("seconds",dailyHours);
			//确定时间的考勤需要判断，如果迟到了15分钟或者早退，全扣工时，如果没有迟到和早退，全加工时
			if("1".equals(attendanceDateType) || "2".equals(attendanceDateType) && "1".equals(userConfig.get("attendanceType"))){
				if(timeBegin > (amBegin+900l) || (timeEnd < pmEnd && timeEnd > amBegin)){//如果迟到或者早退
					secondsMap.put("seconds", 0l);
				}
			}else{//不确定工时考勤，考时长，
				long thisDayTime = 0;
				long start = 0;
				long end = 0;
				boolean startSide = true; // true 是上午，false是下午
				boolean endSide = true; // true 是上午，false是下午
				if(timeBegin <= amBegin) {// 如果开始的时间早于等于考勤上午的开始时间
					start = amBegin;
					startSide = true;
				} else if(timeBegin <= amEnd) {// 如果开始的时间早于等于考勤上午的结束时间
					start = timeBegin;
					startSide = true;
				} else if(timeBegin <= pmBegin) {// 如果开始的时间早于等于考勤下午的开始时间，晚于上午的结束时间
					start = pmBegin;
					startSide = false;
				} else if(timeBegin <= pmEnd) {// 如果开始的时间早于等于考勤下午的开始时间，晚于上午的结束时间
					start = timeBegin;
					startSide = false;
				} else {// 如果开始的时间晚于考勤下午的结束时间： 计算到下午
					start = pmEnd;
					startSide = false;
				}
				if(timeEnd <= amBegin) {// 如果结束的时间早于等于考勤上午的结束时间：计算上午
					end = amBegin;
					endSide = true;
				} else if(timeEnd <= amEnd) {// 如果结束的时间早于等于考勤上午的结束时间：计算上午
					end = timeEnd;
					endSide = true;
				} else if(timeEnd <= pmBegin) {// 如果结束的时间早于等于考勤下午的开始时间，晚于上午的结束时间：计算早上
					end = amEnd;
					endSide = true;
				} else if(timeEnd <= pmEnd) {// 如果结束的时间早于等于考勤下午的结束时间，晚于上午的结束时间： 计算下午时间
					end = timeEnd;
					endSide = false;
				} else {// 如果结束的时间晚于考勤下午的结束时间： 计算到下午
					end = pmEnd;
					endSide = false;
				}
				if(startSide == endSide) { // 同一侧
					thisDayTime = end - start;
				} else {
					thisDayTime = end - start - breakTime; // 不同侧减去中间的休息时间
				}
				secondsMap.put("seconds",thisDayTime);
			}
		}

		return secondsMap;
	}

	@Override
	public List<Map<String, Object>> calculateSeconds(String beginTime, String endTime, UTMap<String, Object> userConfig, boolean isAtt) {
		List<Map<String, Object>> secondsList = new ArrayList<Map<String, Object>>(); // 保存每天的详细

		String formatString = "yyyy-MM-dd HH:mm"; // 前台时间格式
		final long days = UTDate.getDays(beginTime, endTime); // 开始到结束时间的天数

		// 获取开始结束的时分秒，转换以秒为单位
		Calendar beginDate = Calendar.getInstance();
		Calendar endDate = Calendar.getInstance();
		Calendar thisDate = Calendar.getInstance(); // 当前日期，在循环中确认当前的日期
		SimpleDateFormat format = null;
		try {
			format = new SimpleDateFormat(formatString);
			beginDate.setTime(format.parse(beginTime));
			endDate.setTime(format.parse(endTime));
			thisDate.set(beginDate.get(Calendar.YEAR), beginDate.get(Calendar.MONTH), beginDate.get(Calendar.DAY_OF_MONTH), 0,0,0); // 记录计算的当前日期
		} catch (Exception e) {
			logger.error("Exception",e);
		}

		long timeBegin = beginDate.get(Calendar.HOUR_OF_DAY) * 3600 + beginDate.get(Calendar.MINUTE) * 60; // 开始的时分秒
		long timeEnd = endDate.get(Calendar.HOUR_OF_DAY) * 3600 + endDate.get(Calendar.MINUTE) * 60; // 结束的时分秒

		// 获取个人的考勤配置、 没有考勤配置怎么办
		// =======================假定的数据====都以秒为单位============================
		long amBegin = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "amBegin")); // 上午开始时间
		long amEnd = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "amEnd")); // 上午结束时间
		long pmBegin = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "pmBegin")); // 下午开始时间
		long pmEnd = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "pmEnd")); // 下午结束时间

		// 转换以秒为单位
		long dailyHoursAM = amEnd - amBegin; // 每天上午固定的工时
		long dailyHoursPM = pmEnd - pmBegin; // 每天下午固定的工时
		long breakTime = pmBegin - amEnd; // 中午休息时间
		long dailyHours = dailyHoursAM + dailyHoursPM; // 每天固定的工时
		// ======================================================================
		String attendanceDateType = null;
		if(userConfig != null) {
			attendanceDateType = (String) userConfig.get("attendanceDateType"); // 考勤方式:(1.确定时间，2.不确定时间)
			if("1".equals(attendanceDateType) || ("2".equals(attendanceDateType) && "1".equals(userConfig.get("attendanceType")))) { // 1、确定时间考勤，2、不确定时间的考勤：不确定时间的考勤统计方式：（1.统计考勤次数；2.统计考勤时间（单位是小时））
				amBegin = UTDate.transformTimeToSecond((String) userConfig.get("amBegin"));
				amEnd = UTDate.transformTimeToSecond((String) userConfig.get("amEnd"));
				pmBegin = UTDate.transformTimeToSecond((String) userConfig.get("pmBegin"));
				pmEnd = UTDate.transformTimeToSecond((String) userConfig.get("pmEnd"));
			}
			// 考勤模块：不确定时间考勤的按工时：整天都算是工作时间
			if(isAtt && "2".equals(attendanceDateType) && "2".equals(userConfig.get("attendanceType"))) { // 不确定时间的考勤：不确定时间的考勤统计方式：（1.统计考勤次数；2.统计考勤时间（单位是小时））
				amBegin = 0;
				pmEnd = 86400;
			}

			if(pmEnd == 0){
				pmEnd = 86400;//00:00转换为24:00的秒数
			}
			// 转换以秒为单位
			dailyHoursAM = userConfig.get("dailyHoursAM") == null ? amEnd - amBegin : (Integer) userConfig.get("dailyHoursAM"); // 每天上午固定的工时
			dailyHoursPM = userConfig.get("dailyHoursPM") == null ? pmEnd - pmBegin : (Integer) userConfig.get("dailyHoursPM"); // 每天下午固定的工时
			breakTime = userConfig.get("breakTime") == null ? pmBegin - amEnd : (Integer) userConfig.get("breakTime"); // 中午休息时间
			dailyHours = userConfig.get("dailyHours") == null ? dailyHoursAM + dailyHoursPM : (Integer) userConfig.get("dailyHours"); // 每天固定的工时
		}


		// 开始计算：1、只有一天，2、多天
		if(days == 1) { // 如果只有一天
			Map<String, Object> hourMap = new HashMap<String, Object>();
//			hourMap.put("beginTime", beginTime); // 保存当天的开始时间
//			hourMap.put("endTime", endTime); // 保存当天的结束时间

			long thisDayTime = 0; // 计算开始到结束的工时，以秒为单位
			// 1、判断节假日
			String isWorkDay = isWorkDay(thisDate, userConfig); // 1是正常上班
			hourMap.put("dateType", isWorkDay);
			hourMap.put("coalitionId", userConfig == null ? "" : userConfig.get("coalitionId"));

			// 3、有上午下午
			// 20160901 考勤模块工作日也需要计算
			if("1".equals(isWorkDay) || isAtt) {
				long start = 0;
				long end = 0;
				boolean startSide = true; // true 是上午，false是下午
				boolean endSide = true; // true 是上午，false是下午
				// 3.1 确定开始时间
				if(timeBegin <= amBegin) {// 如果开始的时间早于等于考勤上午的开始时间
					start = amBegin;
					startSide = true;
				} else if(timeBegin <= amEnd) {// 如果开始的时间早于等于考勤上午的结束时间
					start = timeBegin;
					startSide = true;
				} else if(timeBegin <= pmBegin) {// 如果开始的时间早于等于考勤下午的开始时间，晚于上午的结束时间
					start = pmBegin;
					startSide = false;
				} else if(timeBegin <= pmEnd) {// 如果开始的时间早于等于考勤下午的开始时间，晚于上午的结束时间
					start = timeBegin;
					startSide = false;
				} else {// 如果开始的时间晚于考勤下午的结束时间： 计算到下午
					start = pmEnd;
					startSide = false;
				}
				if(timeEnd <= amBegin) {// 如果结束的时间早于等于考勤上午的结束时间：计算上午
					end = amBegin;
					endSide = true;
				} else if(timeEnd <= amEnd) {// 如果结束的时间早于等于考勤上午的结束时间：计算上午
					end = timeEnd;
					endSide = true;
				} else if(timeEnd <= pmBegin) {// 如果结束的时间早于等于考勤下午的开始时间，晚于上午的结束时间：计算早上
					end = amEnd;
					endSide = true;
				} else if(timeEnd <= pmEnd) {// 如果结束的时间早于等于考勤下午的结束时间，晚于上午的结束时间： 计算下午时间
					end = timeEnd;
					endSide = false;
				} else {// 如果结束的时间晚于考勤下午的结束时间： 计算到下午
					end = pmEnd;
					endSide = false;
				}

				if(startSide == endSide) { // 同一侧
					thisDayTime = end - start;
				} else {
					thisDayTime = end - start - breakTime; // 不同侧减去中间的休息时间
				}


//				hourMap.put("beginTime", beginTime); // 保存当天的开始时间
//				hourMap.put("endTime", endTime); // 保存当天的结束时间

				Calendar thisDateBegin = Calendar.getInstance();
				Calendar thisDateEnd = Calendar.getInstance();
				thisDateBegin.setTimeInMillis(thisDate.getTimeInMillis() + start * 1000);
				thisDateEnd.setTimeInMillis(thisDate.getTimeInMillis() + end * 1000);

				hourMap.put("beginTime", format.format(thisDateBegin.getTime())); // 保存当天的开始时间
				hourMap.put("endTime", format.format(thisDateEnd.getTime())); // 保存当天的结束时间
			}

			// 4、添加到结果中
			hourMap.put("seconds", thisDayTime);
			secondsList.add(hourMap);
		} else {
			for(int i = 1; i <= days; i++) {
				Map<String, Object> hourMap = new HashMap<String, Object>();

				long thisDayTime = 0; // 计算开始到结束的工时，以秒为单位

				// 1、判断节假日
				String isWorkDay = isWorkDay(thisDate, userConfig); // 1是正常上班

				hourMap.put("dateType", isWorkDay);
				hourMap.put("coalitionId", userConfig == null ? "" : userConfig.get("coalitionId"));

				// 3、有上午下午
				// 20160901 考勤模块工作日也需要计算
				if("1".equals(isWorkDay) || isAtt) {
					if (i == 1) { // 第一天需要考虑上午、下午
//						Calendar thisDateEnd = Calendar.getInstance();
//						thisDateEnd.setTimeInMillis(thisDate.getTimeInMillis() + pmEnd * 1000);
//						hourMap.put("beginTime", beginTime); // 保存当天的开始时间
//						hourMap.put("endTime", format.format(thisDateEnd.getTime())); // 保存当天的结束时间
						long start = 0;
						long end = pmEnd;
						if(timeBegin <= amBegin) {// 如果开始的时间早于等于考勤上午的开始时间：计算一整天
							thisDayTime += dailyHoursAM + dailyHoursPM;
							start = amBegin;
						} else if(timeBegin <= amEnd) {// 如果开始的时间早于等于考勤上午的结束时间：计算上午时间和下午
							thisDayTime += amEnd - timeBegin;
							thisDayTime += dailyHoursPM;
							start = timeBegin;
						} else if(timeBegin <= pmBegin) {// 如果开始的时间早于等于考勤下午的开始时间，晚于上午的结束时间：计算下午
							thisDayTime += dailyHoursPM;
							start = pmBegin;
						} else if(timeBegin <= pmEnd) {// 如果开始的时间早于等于考勤下午的开始时间，晚于下午的开始时间： 计算下午时间
							thisDayTime += (pmEnd - timeBegin);
							start = timeBegin;
						} else {
							thisDayTime = 0;
							start = pmEnd;
						}


						Calendar thisDateBegin = Calendar.getInstance();
						Calendar thisDateEnd = Calendar.getInstance();
						thisDateBegin.setTimeInMillis(thisDate.getTimeInMillis() + start * 1000);
						thisDateEnd.setTimeInMillis(thisDate.getTimeInMillis() + end * 1000);

						hourMap.put("beginTime", format.format(thisDateBegin.getTime())); // 保存当天的开始时间
						hourMap.put("endTime", format.format(thisDateEnd.getTime())); // 保存当天的结束时间

					} else if(i == days){ // 最后一天需要考虑上午、下午，开始时间是考勤的开始时间
//						Calendar thisDateBegin = Calendar.getInstance();
//						thisDateBegin.setTimeInMillis(thisDate.getTimeInMillis() + amBegin * 1000);
//						hourMap.put("beginTime", format.format(thisDateBegin.getTime())); // 保存当天的开始时间
//						hourMap.put("endTime", endTime); // 保存当天的结束时间
						long start = amBegin;
						long end = 0;

						if(timeEnd <= amBegin) {// 如果结束的时间早于等于考勤上午的开始时间：不计算
							thisDayTime = 0;
							end = amBegin;
						} else if(timeEnd <= amEnd) {// 如果结束的时间早于等于考勤上午的结束时间：计算上午时间
							thisDayTime += (timeEnd - amBegin);
							end = timeEnd;
						} else if(timeEnd <= pmBegin) {// 如果结束的时间早于等于考勤下午的开始时间，晚于上午的结束时间：计算早上的工时
							thisDayTime += dailyHoursAM;
							end = amEnd;
						} else if(timeEnd <= pmEnd) {// 如果结束的时间早于等于考勤下午的结束时间：计算早上和下午的时间
							thisDayTime += dailyHoursAM;
							end = timeEnd;
							thisDayTime += (timeEnd - pmBegin);
						} else { // 其他晚于下午时间：计算一整天
							thisDayTime += dailyHours;
							end = pmEnd;
						}

						Calendar thisDateBegin = Calendar.getInstance();
						Calendar thisDateEnd = Calendar.getInstance();
						thisDateBegin.setTimeInMillis(thisDate.getTimeInMillis() + start * 1000);
						thisDateEnd.setTimeInMillis(thisDate.getTimeInMillis() + end * 1000);

						hourMap.put("beginTime", format.format(thisDateBegin.getTime())); // 保存当天的开始时间
						hourMap.put("endTime", format.format(thisDateEnd.getTime())); // 保存当天的结束时间

					} else { // 中间的天数计算整天：计算一整天
						Calendar thisDateBegin = Calendar.getInstance();
						Calendar thisDateEnd = Calendar.getInstance();
						thisDateBegin.setTimeInMillis(thisDate.getTimeInMillis() + amBegin * 1000);
						thisDateEnd.setTimeInMillis(thisDate.getTimeInMillis() + pmEnd * 1000);
						hourMap.put("beginTime", format.format(thisDateBegin.getTime())); // 保存当天的开始时间
						hourMap.put("endTime", format.format(thisDateEnd.getTime())); // 保存当天的结束时间
						thisDayTime += dailyHours;
					}
				}

				if(thisDayTime > 0) { // 不记录小于0的，当天没有记录
					// 4、添加到结果中
					hourMap.put("seconds", thisDayTime);
					secondsList.add(hourMap);
				}
				thisDate.add(Calendar.DAY_OF_MONTH, 1); // 自动换到下一天
			}
		}

		return secondsList;
	}

	@Override
	public List<Map<String, Object>> calculateVocationSeconds(String beginTime, String endTime, UTMap<String, Object> userConfig) {
		List<Map<String, Object>> secondsList = new ArrayList<Map<String, Object>>(); // 保存每天的详细

		String formatString = "yyyy-MM-dd HH:mm"; // 前台时间格式
		final long days = UTDate.getDays(beginTime, endTime); // 开始到结束时间的天数

		// 获取开始结束的时分秒，转换以秒为单位
		Calendar beginDate = Calendar.getInstance();
		Calendar endDate = Calendar.getInstance();
		Calendar thisDate = Calendar.getInstance(); // 当前日期，在循环中确认当前的日期
		SimpleDateFormat format = null;
		try {
			format = new SimpleDateFormat(formatString);
			beginDate.setTime(format.parse(beginTime));
			endDate.setTime(format.parse(endTime));
			thisDate.set(beginDate.get(Calendar.YEAR), beginDate.get(Calendar.MONTH), beginDate.get(Calendar.DAY_OF_MONTH), 0,0,0); // 记录计算的当前日期
		} catch (Exception e) {
			logger.error("Exception",e);
		}

		long timeBegin = beginDate.get(Calendar.HOUR_OF_DAY) * 3600 + beginDate.get(Calendar.MINUTE) * 60; // 开始的时分秒
		long timeEnd = endDate.get(Calendar.HOUR_OF_DAY) * 3600 + endDate.get(Calendar.MINUTE) * 60; // 结束的时分秒

		// 获取个人的考勤配置、 没有考勤配置怎么办
		// =======================假定的数据====都以秒为单位============================
		long amBegin = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "amBegin")); // 上午开始时间
		long amEnd = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "amEnd")); // 上午结束时间
		long pmBegin = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "pmBegin")); // 下午开始时间
		long pmEnd = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "pmEnd")); // 下午结束时间

		// 转换以秒为单位
		long dailyHoursAM = amEnd - amBegin; // 每天上午固定的工时
		long dailyHoursPM = pmEnd - pmBegin; // 每天下午固定的工时
		long breakTime = pmBegin - amEnd; // 中午休息时间
		long dailyHours = dailyHoursAM + dailyHoursPM; // 每天固定的工时
		// ======================================================================
		String attendanceDateType = null;
		if(userConfig != null) {
			attendanceDateType = (String) userConfig.get("attendanceDateType"); // 考勤方式:(1.确定时间，2.不确定时间)
			if("1".equals(attendanceDateType) || ("2".equals(attendanceDateType) && "1".equals(userConfig.get("attendanceType")))) { // 1、确定时间考勤，2、不确定时间的考勤：不确定时间的考勤统计方式：（1.统计考勤次数；2.统计考勤时间（单位是小时））
				amBegin = UTDate.transformTimeToSecond((String) userConfig.get("amBegin"));
				amEnd = UTDate.transformTimeToSecond((String) userConfig.get("amEnd"));
				pmBegin = UTDate.transformTimeToSecond((String) userConfig.get("pmBegin"));
				pmEnd = UTDate.transformTimeToSecond((String) userConfig.get("pmEnd"));
			}
			// 考勤模块：不确定时间考勤的按工时：整天都算是工作时间
			if("2".equals(attendanceDateType) && "2".equals(userConfig.get("attendanceType"))) { // 不确定时间的考勤：不确定时间的考勤统计方式：（1.统计考勤次数；2.统计考勤时间（单位是小时））
				amBegin = 0;
				pmEnd = 86400;
			}

			if(pmEnd == 0){
				pmEnd = 86400;//00:00转换为24:00的秒数
			}
			// 转换以秒为单位
			dailyHoursAM = userConfig.get("dailyHoursAM") == null ? amEnd - amBegin : (Integer) userConfig.get("dailyHoursAM"); // 每天上午固定的工时
			dailyHoursPM = userConfig.get("dailyHoursPM") == null ? pmEnd - pmBegin : (Integer) userConfig.get("dailyHoursPM"); // 每天下午固定的工时
			breakTime = userConfig.get("breakTime") == null ? pmBegin - amEnd : (Integer) userConfig.get("breakTime"); // 中午休息时间
			dailyHours = userConfig.get("dailyHours") == null ? dailyHoursAM + dailyHoursPM : (Integer) userConfig.get("dailyHours"); // 每天固定的工时
		}


		// 开始计算：1、只有一天，2、多天
		if(days == 1) { // 如果只有一天
			Map<String, Object> hourMap = new HashMap<String, Object>();
//			hourMap.put("beginTime", beginTime); // 保存当天的开始时间
//			hourMap.put("endTime", endTime); // 保存当天的结束时间

			long thisDayTime = 0; // 计算开始到结束的工时，以秒为单位
			// 1、判断节假日
			String isWorkDay = isWorkDay(thisDate, userConfig); // 1是正常上班
			hourMap.put("dateType", isWorkDay);
			hourMap.put("coalitionId", userConfig == null ? "" : userConfig.get("coalitionId"));

			// 3、有上午下午
			// 20160901 考勤模块工作日也需要计算
			if("1".equals(isWorkDay) ) {
				long start = 0;
				long end = 0;
				if(timeBegin > amEnd  && timeEnd <= pmBegin){//在上午请的假 ，则请假工时为
					start = amBegin;
					end = amEnd;
					thisDayTime = dailyHoursAM;
				} else if (timeBegin >= pmBegin && timeBegin < pmEnd ){//下午请的假
					start = pmBegin;
					end = pmEnd;
					thisDayTime = dailyHoursPM;
				}else if(timeBegin > amEnd && timeEnd < pmBegin){//全天假
					start = amBegin;
					end = pmEnd;
					thisDayTime = dailyHours;
				}else{//其他时间的请假都不作数
				}
				Calendar thisDateBegin = Calendar.getInstance();
				Calendar thisDateEnd = Calendar.getInstance();
				thisDateBegin.setTimeInMillis(thisDate.getTimeInMillis() + start * 1000);
				thisDateEnd.setTimeInMillis(thisDate.getTimeInMillis() + end * 1000);

				hourMap.put("beginTime", format.format(thisDateBegin.getTime())); // 保存当天的开始时间
				hourMap.put("endTime", format.format(thisDateEnd.getTime())); // 保存当天的结束时间
			}

			// 4、添加到结果中
			hourMap.put("seconds", thisDayTime);
			secondsList.add(hourMap);
		} else {
			for(int i = 1; i <= days; i++) {
				Map<String, Object> hourMap = new HashMap<String, Object>();

				long thisDayTime = 0; // 计算开始到结束的工时，以秒为单位

				// 1、判断节假日
				String isWorkDay = isWorkDay(thisDate, userConfig); // 1是正常上班

				hourMap.put("dateType", isWorkDay);
				hourMap.put("coalitionId", userConfig == null ? "" : userConfig.get("coalitionId"));

				// 3、有上午下午
				// 20160901 考勤模块工作日也需要计算
				if("1".equals(isWorkDay)) {
					if (i == 1) { // 第一天需要考虑上午、下午
						long start = 0;
						long end = 0;
						if(timeBegin > amEnd  && timeEnd <= pmBegin){//在上午请的假 ，则请假工时为
							start = amBegin;
							end = amEnd;
							thisDayTime = dailyHoursAM;
						} else if (timeBegin >= pmBegin && timeBegin < pmEnd ){//下午请的假
							start = pmBegin;
							end = pmEnd;
							thisDayTime = dailyHoursPM;
						}else if(timeBegin > amEnd && timeEnd < pmBegin){//全天假
							start = amBegin;
							end = pmEnd;
							thisDayTime = dailyHours;
						}else{//其他时间的请假都不作数
						}

						Calendar thisDateBegin = Calendar.getInstance();
						Calendar thisDateEnd = Calendar.getInstance();
						thisDateBegin.setTimeInMillis(thisDate.getTimeInMillis() + start * 1000);
						thisDateEnd.setTimeInMillis(thisDate.getTimeInMillis() + end * 1000);

						hourMap.put("beginTime", format.format(thisDateBegin.getTime())); // 保存当天的开始时间
						hourMap.put("endTime", format.format(thisDateEnd.getTime())); // 保存当天的结束时间

					} else if(i == days){ // 最后一天需要考虑上午、下午，开始时间是考勤的开始时间
						long start = 0;
						long end = 0;
						if(timeBegin > amEnd  && timeEnd <= pmBegin){//在上午请的假 ，则请假工时为
							start = amBegin;
							end = amEnd;
							thisDayTime = dailyHoursAM;
						} else if (timeBegin >= pmBegin && timeBegin < pmEnd ){//下午请的假
							start = pmBegin;
							end = pmEnd;
							thisDayTime = dailyHoursPM;
						}else if(timeBegin > amEnd && timeEnd < pmBegin){//全天假
							start = amBegin;
							end = pmEnd;
							thisDayTime = dailyHours;
						}else{//其他时间的请假都不作数
						}

						Calendar thisDateBegin = Calendar.getInstance();
						Calendar thisDateEnd = Calendar.getInstance();
						thisDateBegin.setTimeInMillis(thisDate.getTimeInMillis() + start * 1000);
						thisDateEnd.setTimeInMillis(thisDate.getTimeInMillis() + end * 1000);

						hourMap.put("beginTime", format.format(thisDateBegin.getTime())); // 保存当天的开始时间
						hourMap.put("endTime", format.format(thisDateEnd.getTime())); // 保存当天的结束时间

					} else { // 中间的天数计算整天：计算一整天
						Calendar thisDateBegin = Calendar.getInstance();
						Calendar thisDateEnd = Calendar.getInstance();
						thisDateBegin.setTimeInMillis(thisDate.getTimeInMillis() + amBegin * 1000);
						thisDateEnd.setTimeInMillis(thisDate.getTimeInMillis() + pmEnd * 1000);
						hourMap.put("beginTime", format.format(thisDateBegin.getTime())); // 保存当天的开始时间
						hourMap.put("endTime", format.format(thisDateEnd.getTime())); // 保存当天的结束时间
						thisDayTime += dailyHours;
					}
				}

				if(thisDayTime > 0) { // 不记录小于0的，当天没有记录
					// 4、添加到结果中
					hourMap.put("seconds", thisDayTime);
					secondsList.add(hourMap);
				}
				thisDate.add(Calendar.DAY_OF_MONTH, 1); // 自动换到下一天
			}
		}

		return secondsList;
	}

	@Override
	public Map<String, Object> calculateOvertimeHours(String beginTime, String endTime, UTMap<String, Object> userConfig) {

		Map<String, Object> result = new HashMap<String, Object>();
		String formatString = "yyyy-MM-dd HH:mm"; // 前台时间格式

		Calendar beginDate = Calendar.getInstance();
		Calendar endDate = Calendar.getInstance();
		long timeBegin = 0;
		long timeEnd = 0;
		try {
			SimpleDateFormat format = new SimpleDateFormat(formatString);
			beginDate.setTime(format.parse(beginTime));
			endDate.setTime(format.parse(endTime));
			// 如果结束时间是第二天的00:00这种，就在结束时间减去1分钟，计算的时候加上60秒
			if(beginDate.get(Calendar.DAY_OF_MONTH) != endDate.get(Calendar.DAY_OF_MONTH)) {
				endDate.add(Calendar.MINUTE, -1);
				timeEnd += 60;
			}
		} catch (Exception e) {
			logger.error("Exception",e);
		}

		timeBegin += beginDate.get(Calendar.HOUR_OF_DAY) * 3600 + beginDate.get(Calendar.MINUTE) * 60; // 开始的时分秒
		timeEnd += endDate.get(Calendar.HOUR_OF_DAY) * 3600 + endDate.get(Calendar.MINUTE) * 60; // 结束的时分秒

		// 获取个人的考勤配置、 没有考勤配置怎么办
		// =======================假定的数据====都以秒为单位============================
		long amBegin = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "amBegin")); // 上午开始时间
		long amEnd = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "amEnd")); // 上午结束时间
		long pmBegin = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "pmBegin")); // 下午开始时间
		long pmEnd = UTDate.transformTimeToSecond(attendanceDefaultService.getValue("attendance", "pmEnd")); // 下午结束时间
		String userId = EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId();
		// ======================================================================

		String attendanceDateType = null; // 考勤方式:(1.确定时间，2.不确定时间)
		if(userConfig != null) {
			userId = (String) userConfig.get("userId");
			attendanceDateType = (String) userConfig.get("attendanceDateType");
			if("1".equals(attendanceDateType) || ("2".equals(attendanceDateType) && "1".equals(userConfig.get("attendanceType")))) { // 1、确定时间考勤，2、不确定时间的考勤：不确定时间的考勤统计方式：（1.统计考勤次数；2.统计考勤时间（单位是小时））
				amBegin = UTDate.transformTimeToSecond((String) userConfig.get("amBegin"));
				amEnd = UTDate.transformTimeToSecond((String) userConfig.get("amEnd"));
				pmBegin = UTDate.transformTimeToSecond((String) userConfig.get("pmBegin"));
				pmEnd = UTDate.transformTimeToSecond((String) userConfig.get("pmEnd"));
				if(pmEnd == 0){
					pmEnd = 86400;//00:00转换为24:00的秒数
				}
			}
		}

		// 1、判断节假日
		String isWorkDay = isWorkDay(beginDate, userConfig); // 1 是正常上班
		result.put("dateType", isWorkDay);
		result.put("coalitionId", userConfig == null ? "" : userConfig.get("coalitionId"));

		// 1.1 工作日要减去工作日的工时
		long blockTimeBegin = amEnd; // 不计算时间的开始：中间休息时间
		long blockTimeEnd = pmBegin; // 不计算时间的结束：中间休息时间

		if("1".equals(isWorkDay)) { // 工作日的不计算时间包括工作时间
			blockTimeBegin = amBegin; // 不计算时间的开始
			blockTimeEnd = pmEnd; // 不计算时间的结束
		}
		long thisDaySeconds = calculateBlockHours(timeBegin, timeEnd, blockTimeBegin, blockTimeEnd);
		double hours = UTDate.transformSecondToHour(thisDaySeconds, false);
		result.put("hours", hours);

//		// 换算成合同设置的系数的工作日
//		Double overtimeFactory = Double.valueOf(1);
//		UTMap<String, Object> agreementManpower = agreementManpowerInfoService.getByUserId(userId);
//		if(agreementManpower != null) {
//			overtimeFactory = (Double) agreementManpower.get("1".endsWith(isWorkDay) ? "overtimeWeekday" : ("2".endsWith(isWorkDay)? "overtimeWeekend" : "overtimeHoliday"));//1
//			if(overtimeFactory == null || overtimeFactory <= 0) {
//				overtimeFactory = Double.valueOf(1);
//			}
//		}
//		result.put("actualHours", thisDaySeconds * overtimeFactory);

		result.put("actualHours", thisDaySeconds );
		return result;
	}

	@Override
	public Map<String, Object> calculateOvertimeHoursNew(String beginTime, String endTime, UTMap<String, Object> userConfig, String userId) {
		Map<String, Object> result = new HashMap<String, Object>();
		String formatString = "yyyy-MM-dd HH:mm"; // 前台时间格式
		String format2String = "yyyy-MM-dd";//年月日格式
		List<UTMap<String, Object>> seasonList = dingDingAttendanceService.getSeason();
		Calendar beginDate = Calendar.getInstance();
		Calendar endDate = Calendar.getInstance();
		long timeBegin = 0;
		long timeEnd = 0;
		String today = null;
		try {
			SimpleDateFormat format = new SimpleDateFormat(formatString);
			SimpleDateFormat format2 = new SimpleDateFormat(format2String);
			beginDate.setTime(format.parse(beginTime));
			endDate.setTime(format.parse(endTime));
			today = format2.format(beginDate.getTime());
			// 如果结束时间是第二天的00:00这种，就在结束时间减去1分钟，计算的时候加上60秒
			if(beginDate.get(Calendar.DAY_OF_MONTH) != endDate.get(Calendar.DAY_OF_MONTH)) {
				endDate.add(Calendar.MINUTE, -1);
				timeEnd += 60;
			}

		} catch (Exception e) {
			logger.error("Exception",e);
		}

		//判断时令
		String seasonType = dingDingAttendanceService.checkSeason(LocalDateUtil.getLocalDatestamp(today), seasonList);
		timeBegin += beginDate.get(Calendar.HOUR_OF_DAY) * 3600 + beginDate.get(Calendar.MINUTE) * 60; // 开始的时分秒
		timeEnd += endDate.get(Calendar.HOUR_OF_DAY) * 3600 + endDate.get(Calendar.MINUTE) * 60; // 结束的时分秒
		// 获取个人的考勤配置、 没有考勤配置怎么办
		// =======================假定的数据====都以秒为单位============================
		String amBeginStr = null ;
		String amEndStr = null;
		String pmBeginStr = null ;
		String pmEndStr =null;
		String attendanceDateType = null; // 考勤方式:(1.确定时间，2.不确定时间)
		if(userConfig != null) {
			attendanceDateType = (String) userConfig.get("attendanceDateType");
		}
		if(userConfig != null && ("1".equals(attendanceDateType) || "2".equals(attendanceDateType) && "1".equals(userConfig.get("attendanceType")))){//有配置
			//具体时间的配置
			if(seasonType.equals(FunctionEnum.SeasonType.summer.getCode())){
				amBeginStr = (String) userConfig.get("amBegin");
				amEndStr = (String) userConfig.get("amEnd");
				pmBeginStr = (String) userConfig.get("pmBegin");
				pmEndStr = (String) userConfig.get("pmEnd");
			}else{
				amBeginStr = (String) userConfig.get("winterAmBegin");
				amEndStr = (String) userConfig.get("winterAmEnd");
				pmBeginStr = (String) userConfig.get("winterPmBegin");
				pmEndStr = (String) userConfig.get("winterPmEnd");
			}

		}else{//没有配置，则去默认中的值
			if(seasonType.equals(FunctionEnum.SeasonType.summer.getCode())){
				amBeginStr = attendanceDefaultService.getValue("attendance", "amBegin");
				amEndStr = attendanceDefaultService.getValue("attendance", "amEnd");
				pmBeginStr = attendanceDefaultService.getValue("attendance", "pmBegin");
				pmEndStr = attendanceDefaultService.getValue("attendance", "pmEnd");
			}else{
				amBeginStr = attendanceDefaultService.getValue("attendance", "winterAmBegin");
				amEndStr = attendanceDefaultService.getValue("attendance", "winterAmEnd");
				pmBeginStr = attendanceDefaultService.getValue("attendance", "winterPmBegin");
				pmEndStr = attendanceDefaultService.getValue("attendance", "winterPmEnd");
			}
		}
		amBeginStr = today+" "+amBeginStr+":00";
		amEndStr = today+" "+amEndStr+":00";
		pmBeginStr = today+" "+pmBeginStr+":00";
		pmEndStr = today+" "+pmEndStr+":00";
		// 1、判断节假日
		String isWorkDay = isWorkDay(beginDate, userConfig); // 1 是正常上班
		result.put("dateType", isWorkDay);
		long thisDaySeconds = 0;
		//工作日的时间
		//在工作时间之开始,需要加班结束时间>下班时间才计算加班时间
		if((UTDate.dateCompare(beginTime, pmEndStr,"yyyy-MM-dd HH:mm:ss") || beginTime.equals(pmEndStr)) &&
				(UTDate.dateCompare(pmEndStr, endTime,"yyyy-MM-dd HH:mm:ss") || pmEndStr.equals(endTime))){
			thisDaySeconds = 60*UTDate.getTimeMinLength(pmEndStr, endTime);
			result.put("actBeginTime", pmEndStr);
		}else if((UTDate.dateCompare(pmEndStr, beginTime,"yyyy-MM-dd HH:mm:ss") || pmEndStr.equals(beginTime)) ||
				(UTDate.dateCompare(endTime, amBeginStr,"yyyy-MM-dd HH:mm:ss") || endTime.equals(amBeginStr))){
			//如果开始时间或者结束时间在工作时间之外，则直接相减计算
			thisDaySeconds = 60*UTDate.getTimeMinLength(beginTime, endTime);
			result.put("actBeginTime",beginTime);
		}
		result.put("beginTime", beginTime);
		result.put("endTime", endTime);
		//每天去取实际打卡时间，计算加班
		UTMap<String, Object> attMap = attendanceService.getCurUserAttendance(today,userId);
		if(attMap != null &&attMap.get("startTime") != null  && attMap.get("endTime") != null){//存在打卡,签到时间和签退时间
			result.put("actEndTime", endTime);
			if(UTDate.dateCompare((String) attMap.get("endTime"), endTime, "yyyy-MM-dd HH:mm:ss")){
				//实际结束时间小于预订时间，取实际结束时间
				result.put("actEndTime", attMap.get("endTime"));
			}
		}
		//如果跨天，则我们的加班就直接相减
		double hours = UTDate.transformSecondToHour(thisDaySeconds, false);
		result.put("hours", hours);
		if(result.get("actEndTime") != null && result.get("actBeginTime") != null){//时间开始和结束时间存在
			result.put("actualHours", UTDate.transformSecondToHour(60*UTDate.getTimeMinLength((String) result.get("actBeginTime"), (String)result.get("actEndTime")), false));
		}
		return result;
	}

	@Override
	public List<Map<String, Object>> calculateOvertimeHoursDays(String beginTime, String endTime, UTMap<String, Object> userConfig, String userId) {
		List<Map<String, Object>> secondsList = new ArrayList<Map<String, Object>>(); // 保存每天的详细

		String formatString = "yyyy-MM-dd HH:mm"; // 前台时间格式

		long days = UTDate.getDays(beginTime, endTime); // 开始到结束时间的天数
		// 获取开始结束的时分秒，转换以秒为单位
		Calendar beginDate = Calendar.getInstance();
		Calendar endDate = Calendar.getInstance();
		Calendar thisDate = Calendar.getInstance(); // 当前日期，在循环中确认当前的日期
		SimpleDateFormat format = null;
		long timeBegin = 0l;
		long timeEnd = 0l;
		try {
			format = new SimpleDateFormat(formatString);
			beginDate.setTime(format.parse(beginTime));
			endDate.setTime(format.parse(endTime));
			thisDate.set(beginDate.get(Calendar.YEAR), beginDate.get(Calendar.MONTH), beginDate.get(Calendar.DAY_OF_MONTH), 0,0,0); // 记录计算的当前日期
		} catch (Exception e) {
			logger.error("Exception",e);
		}

		//days == 2 并且第二天的时间小于12点，则我们判断他为1天
		if(days == 2 && endDate.get(Calendar.HOUR_OF_DAY) <= 12){
				days = 1l;
		}
		timeBegin += beginDate.get(Calendar.HOUR_OF_DAY) * 3600 + beginDate.get(Calendar.MINUTE) * 60; // 开始的时分秒
		timeEnd += endDate.get(Calendar.HOUR_OF_DAY) * 3600 + endDate.get(Calendar.MINUTE) * 60; // 结束的时分秒
		//判断开始时间是否为工作日，如果开始时间为工作日，则只有一条数据
		// 1、判断节假日
		String isWorkDay = isWorkDay(thisDate, userConfig); // 1是正常上班
		if("1".equals(isWorkDay)){//表示是工作日，则只有一条数据
			Map<String, Object> result = calculateOvertimeHoursNew(beginTime, endTime, userConfig, userId);
			secondsList.add(result);
		}else{
			for(int i = 1; i <= days; i++) {
				Double hours = 0d;
				Map<String, Object> result = new HashMap<>();
				Calendar thisDateBegin = Calendar.getInstance();
				//每天去取实际打卡时间，计算加班
				UTMap<String, Object> attMap = attendanceService.getCurUserAttendance(UTDate.dateToString(thisDate.getTime(), "yyyy-MM-dd"),userId);
				if(i == 1){
					result.put("beginTime", beginTime);
					thisDateBegin.setTimeInMillis(thisDate.getTimeInMillis());
					result.put("endTime", format.format(thisDateBegin.getTime()));
					hours = UTDate.transformSecondToHour((24*60*60l-timeBegin), false);
					result.put("hours",  hours);
				}else if(i == days){
					hours = UTDate.transformSecondToHour(timeEnd, false);
					result.put("hours",  hours);
					thisDateBegin.setTimeInMillis(thisDate.getTimeInMillis());
					result.put("beginTime", format.format(thisDateBegin.getTime()));
					thisDateBegin.setTimeInMillis(thisDate.getTimeInMillis()+24*60*60*1000-1L);
					result.put("endTime", format.format(thisDateBegin.getTime()));
				}else{
					hours = UTDate.transformSecondToHour(24*60*60*60l, false);
					result.put("hours", hours);
					thisDateBegin.setTimeInMillis(thisDate.getTimeInMillis());
					result.put("beginTime", format.format(thisDateBegin.getTime()));
					result.put("endTime", endTime);
				}

				if(days == 1){//只有一填的时候直接相减
					result.put("beginTime", beginTime);
					result.put("endTime", endTime);
					hours = UTDate.transformSecondToHour(60l*UTDate.getTimeMinLength(beginTime, endTime), false);
					result.put("hours", hours);
				}

				if(attMap != null){//存在打卡,签到时间和签退时间
					result.put("actBeginTime", attMap.get("startTime"));
					result.put("actEndTime", attMap.get("endTime"));
					if(attMap.get("startTime") != null  && attMap.get("endTime") != null){
						//获取时间长度
//						String startTimeAct = UTDate.dateCompare((String) attMap.get("startTime"), (String) result.get("beginTime"),"yyyy-MM-dd HH:mm:ss")
//								?  (String) result.get("beginTime") : (String) attMap.get("startTime");
//						String endTimeAct = UTDate.dateCompare((String) attMap.get("endTime"), (String) result.get("endTime"),"yyyy-MM-dd HH:mm:ss")
//								?  (String) attMap.get("endTime"):(String) result.get("endTime") ;
						long time = 60*UTDate.getTimeMinLength((String) attMap.get("startTime"), (String) attMap.get("endTime"));
						double actualHours = UTDate.transformSecondToHour(time, false);
						result.put("actualHours", actualHours);
					}

				}
				thisDate.add(Calendar.DAY_OF_MONTH, 1); // 自动换到下一天
				secondsList.add(result);
			}
		}
		return secondsList;
	}


	/**
	 * 计算两个时间之间的工时，需要处理中间的间隔时间
	 * @param timeBegin
	 * @param timeEnd
	 * @param blockTimeBegin
	 * @param blockTimeEnd
	 * @return
	 */
	private long calculateBlockHours(long timeBegin, long timeEnd, long blockTimeBegin, long blockTimeEnd) {
		long thisDayTime = 0; // 计算开始到结束的工时，以秒为单位，最后换算到小时
		long start = timeBegin;
		long end = timeEnd;
		
		String startSide = "1"; // 1,2,3 是不计算时间段的上中下
		String endSide = "1"; // 同上
		// 确定时间位置
		if(timeBegin <= blockTimeBegin) { // 早于中间时间的开始
			start = timeBegin;
			startSide = "1";
		} else if(timeBegin <= blockTimeEnd) { // 早于中间时间的开始
			start = blockTimeEnd;
			startSide = "2";
		} else {
			startSide = "3";
		}
		
		if(timeEnd <= blockTimeBegin) { // 早于中间时间的开始
			end = timeEnd;
			endSide = "1";
		} else if(timeEnd <= blockTimeEnd) { // 早于中间时间的开始
			end = blockTimeEnd;
			endSide = "2";
		} else {
			endSide = "3";
		}
		
		//  如果不在同一侧，减去中午的休息时间
		if(startSide.equals(endSide)) { // 同一侧
			thisDayTime = end - start;
		} else if("2".equals(startSide)) { // 开始时间在中间
			thisDayTime = end - start;
		} else if("2".equals(endSide)) { // 结束时间在中间
			thisDayTime = end - start - (blockTimeEnd - blockTimeBegin);
		} else {
			thisDayTime = end - start - (blockTimeEnd - blockTimeBegin); // 不同侧减去中间的休息时间
		}
		
		// 3、thisDayTime换算到小时
		return thisDayTime;
	}
	
	/**
	 * 返回跟节假日一样：1.工作日  2.周末  3.法定节假日  4.调休  5.其他.
	 * <p>不确定时间考勤的都是工作日</p>
	 * @param thisDate
	 * @param userConfig
	 * @return
	 */
	public String isWorkDay(Calendar thisDate, UTMap<String, Object> userConfig) {
		String result = "1"; // 1 是工作日
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String dateString = format.format(thisDate.getTime());
		
		// 考勤配置
		String attendanceDate = null;
		String attendanceDateType = null;
		if(userConfig != null) {
			attendanceDateType = (String) userConfig.get("attendanceDateType"); // 考勤方式:(1.确定时间，2.不确定时间)
			if("1".equals(attendanceDateType)) { // 确定时间的考勤
				attendanceDate = (String) userConfig.get("attendanceDate"); // 考勤时间点：周日、周一、周二、周三、周四、周五、周六：1,2,3,4,5,6,7
			}
		}

		// 节假日配置
		UTMap<String, Object> festivalConfig = festivalDao.getByDate(dateString);
		 //节假日类型：1.工作日  2.周末  3.法定节假日  4.调休  5.其他. 工作日为1，周末为2，法定节假日为3 已经写入代码中，不可更改
		String festivalType = festivalConfig != null ? (String) festivalConfig.get("festivalType") : "";
		if(attendanceDate != null && attendanceDate.length() == 13) { // 全年无休
			// 1、判断全年无休
			result = "1";
		} else if(festivalType != null && StringUtils.isNotEmpty(festivalType) && "3,4,5".contains(festivalType)) {
			// 2、节假日：3.法定节假日  4.调休  5.其他，不需要上班
			result = festivalType;
		} else if ("1".equals(festivalType)) { 
			// 3、节假日配置是工作日
			result = "1";
		} else {
			if("1".equals(attendanceDateType) && attendanceDate != null) { // 确定时间考勤的
				if(attendanceDate.contains(String.valueOf(thisDate.get(Calendar.DAY_OF_WEEK)))) {
					 //4、考勤配置了当天需要上班
					result = "1";
				} else {
					result = "2"; // 他的周末，不需要上班
				}
			} else { // 不确定时间考勤
				if("2".equals(festivalType)) { // 如果是周末
					result = "2";
				} else {
					result = "1"; // 工作日
				}
			}
		}
		return result;
	}
	
	/**
	 * 判断日期是否在开始和结束时间的范围内、暂时没用
	 * @param thisDate
	 * @param userConfig
	 * @return
	 */
	public static boolean inDateRange(Calendar thisDate, UTMap<String, Object> userConfig) {
		boolean result = false;
		if(userConfig == null) {
			return true;
		}
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String dateString = format.format(thisDate.getTime());
		String beginDateStr = (String) userConfig.get("beginDate");
		String endDateStr = (String) userConfig.get("endDate");
		try {
			Calendar checkDate = Calendar.getInstance();
			checkDate.setTime(format.parse(dateString)); // 只保留日期
			
			if(beginDateStr != null) { // 开始时间不为空
				Calendar beginDate = Calendar.getInstance();
				Calendar endDate = Calendar.getInstance();
				beginDate.setTime(format.parse(beginDateStr)); // 考勤开始时间
				if(beginDate.compareTo(checkDate) <= 0) { // 在考勤开始时间之后，判断有没有超过结束时间
					if(endDate != null) {
						endDate.setTime(format.parse(endDateStr)); // 考勤结束时间
						if (endDate.compareTo(checkDate) >= 0) { 
							result = true; // 如果在考勤结束时间之前，在考勤范围内
						} else {
							result = false; // 如果在考勤结束时间之后
						}
						
					} else {
						result = true; // 没有配置结束时间，就在考勤范围内
					}
				} else {
					result = false; // 在考勤配置的开始时间之前
				}
			} else {
				result = false; // 没有配置开始时间
			}
		} catch (ParseException e) {
			logger.error("ParseException",e);
		}
		return result;
	}

	@Override
	public void baseOnSupplier(Map<String, Object> param, UTPageBean pageBean) {
		manHourStatisticDao.baseOnSupplier(param, pageBean);
	}
	
	@Override
	public List<UTMap<String, Object>> baseOnSupplierList(Map<String, Object> param) {
		return manHourStatisticDao.baseOnSupplierList(param);
	}

	@Override
	public void baseOnOrg(Map<String, Object> param, UTPageBean pageBean) {
		manHourStatisticDao.baseOnOrg(param, pageBean);
	}
	
	@Override
	public List<UTMap<String, Object>> baseOnOrgList(Map<String, Object> param) {
		return manHourStatisticDao.baseOnOrgList(param);
	}
	
	public void getDetailPage(String type, Map<String, Object> param, UTPageBean pageBean) {
		if("overtime".equals(type)) {
			overtimeDao.getStatisticDetailPage(pageBean, param);
		} else if("vacation".equals(type)) {
			param.put("type", "3");
			vacationDetailDao.getVacationDetailPage(pageBean, param);
		} else if("leaveInLieu".equals(type)) {
			param.put("type", "8");
			vacationDetailDao.getVacationDetailPage(pageBean, param);
		}
	}

	@Override
	public List<UTMap<String, Object>> getDetailList(String type, Map<String, Object> param) {
		List<UTMap<String, Object>> list = null;
		if("overtime".equals(type)) {
			list = overtimeDao.getStatisticDetailList(param);
		} else if("vacation".equals(type)) {
			param.put("type", "3");
			list = vacationDetailDao.getVacationDetailList(param);
		} else if("leaveInLieu".equals(type)) {
			param.put("type", "8");
			list = vacationDetailDao.getVacationDetailList(param);
		}
		return list;
	}
	
	@Override
	public boolean leadingout(String type, Map param, List<UTMap<String, Object>> data, HttpServletRequest request, HttpServletResponse response) throws Exception {
		//工时统计（开始日期-结束日期）												
		//所属供应商	开始日期	结束日期	人数	加班工时（H）				请假工时（H）				出差工时（H）		
		//								申请工时	批准工时	待审批工时	申请工时	批准工时	待审批工时	申请工时	批准工时	待审批工时
		for (UTMap<String, Object> utMap : data) {
			utMap.put("overtime", (Double) utMap.get("overtimeApproved") + (Double) utMap.get("overtimePendingApproved"));
			utMap.put("vacation", (Double) utMap.get("vacationApproved") + (Double) utMap.get("vacationPendingApproved"));
			utMap.put("leaveInLieu", (Double) utMap.get("leaveInLieuApproved") + (Double) utMap.get("leaveInLieuPendingApproved"));
		}
		String[] fileds = null;
		String title = "工时统计";
		String tamlate = null;
		if("baseOnSupplier".equals(type)) {
			tamlate = "excelOutTamplate.outsourceManhourStatisticOfSupplier";
			title = "供应商工时统计";
			fileds = new String[] { 
					"supplierName",
					"beginTime",
					"endTime",
					"memberNum",
					"overtime",
					"overtimeApproved",
					"overtimePendingApproved",
					"vacation",
					"vacationApproved",
					"vacationPendingApproved",
					"leaveInLieu",
					"leaveInLieuApproved",
					"leaveInLieuPendingApproved" };
		} else if("baseOnOrg".equals(type)) {
			tamlate = "excelOutTamplate.outsourceManhourStatisticOfOrg";
			title = "部门工时统计";
			fileds = new String[] { 
				"orgName",
				"beginTime",
				"endTime",
				"memberNum",
				"overtime",
				"overtimeApproved",
				"overtimePendingApproved",
				"vacation",
				"vacationApproved",
				"vacationPendingApproved",
				"leaveInLieu",
				"leaveInLieuApproved",
				"leaveInLieuPendingApproved" };
		}

		String beginTime = (String) param.get("beginTime");
		String endTime = (String) param.get("endTime");
		if(StringUtils.isEmpty(beginTime) && StringUtils.isEmpty(endTime)) {
			// 不添加时间
		} else if(StringUtils.isEmpty(beginTime)) {
			title = title + "（截止" + endTime + "）";
		} else if(StringUtils.isEmpty(endTime)) {
			title = title + "（" + beginTime + "至今）";
		} else {
			title = title + "（" + beginTime + "至" + endTime + "）";
		}
		if (null != data && !data.isEmpty()) {
			for(int i=0;i<data.size();i++){
				Map<String,Object> item = (Map<String, Object>) data.get(i);
				item.put("beginTime", CommonUtils.replaceAll((String)item.get("beginTime"), "-", "/"));
				item.put("endTime", CommonUtils.replaceAll((String)item.get("endTime"), "-", "/"));
			}
		}
		return UTExcel.leadingout(fileds, data, tamlate, title , request, response);
	}
	
	@Override
	public boolean leadingoutDetail(String type, List<UTMap<String, Object>> data, HttpServletRequest request, HttpServletResponse response) throws Exception {
		// 所属供应商	所属部门	姓名	加班日期	开始时间	结束时间	工时（H）	状态	加班原因
		// 所属供应商	所属部门	姓名	请假日期	开始时间	结束时间	工时（H）	状态	请假原因
		// 所属供应商	所属部门	姓名	出差日期	开始时间	结束时间	工时（H）	状态	出差地点
		String[] fileds = null;
		String tamlate = null;
		if("overtime".equals(type)) {
			fileds = new String[] { 
					IOvertimeDao.FIELD_SUPPLIERNAME,
					IOvertimeDao.FIELD_ORGNAME,
					IOvertimeDao.FIELD_SUBMITUSER,
					IOvertimeDao.FIELD_PRESENTDATE,
					IOvertimeDao.FIELD_BEGINTIME,
					IOvertimeDao.FIELD_ENDTIME,
					IOvertimeDao.FIELD_HOURS,
					IOvertimeDao.FIELD_STATUS,
					IOvertimeDao.FIELD_REASON };
			tamlate = "excelOutTamplate.outsourceManhourStatisticOvertime";
		} else if("vacation".equals(type)) {
			fileds = new String[]{
					IVacationDao.FIELD_SUPPLIERNAME,
					IVacationDao.FIELD_ORGNAME,
					IVacationDao.FIELD_SUBMITUSER,
					IVacationDetailDao.FIELD_PRESENTDATE,
					IOvertimeDao.FIELD_BEGINTIME,
					IOvertimeDao.FIELD_ENDTIME,
					IVacationDetailDao.FIELD_HOURS,
					IVacationDao.FIELD_STATUS,
					IVacationDao.FIELD_REASON};
			tamlate = "excelOutTamplate.outsourceManhourStatisticVacation";
		}else if("leaveInLieu".equals(type)){
			type = "vacation";//公用属性
			fileds = new String[]{
					IVacationDao.FIELD_SUPPLIERNAME,
					IVacationDao.FIELD_ORGNAME,
					IVacationDao.FIELD_SUBMITUSER,
					IVacationDetailDao.FIELD_PRESENTDATE,
					IOvertimeDao.FIELD_BEGINTIME,
					IOvertimeDao.FIELD_ENDTIME,
					IVacationDetailDao.FIELD_HOURS,
					IVacationDao.FIELD_STATUS,
					IVacationDao.FIELD_REASON};
			tamlate = "excelOutTamplate.outsourceManhourStatisticLeaveInLieu";
		} else if("travel".equals(type)) {
			fileds = new String[] { 
					ITravelDao.FIELD_SUPPLIERNAME,
					ITravelDao.FIELD_ORGNAME,
					ITravelDao.FIELD_CREATEUSER,
					ITravelDetailDao.FIELD_PRESENTDATE,
					IOvertimeDao.FIELD_BEGINTIME,
					IOvertimeDao.FIELD_ENDTIME,
					ITravelDetailDao.FIELD_HOURS,
					ITravelDao.FIELD_STATUS,
					ITravelDao.FIELD_PLACE };
			tamlate = "excelOutTamplate.outsourceManhourStatisticTravel";
		}
		
		// 替换下拉的值
		Map<String, String> fieldAndParamType = new HashMap<String, String>();
		fieldAndParamType.put(IOvertimeDao.FIELD_STATUS, type + "Status");
		sysParamService.changeParamData(data, fieldAndParamType);
		
		if (null != data && !data.isEmpty()) {
			for (int i=0;i<data.size();i++) {
				UTMap<String, Object> item = data.get(i);
				Object beginTime = item.get(IOvertimeDao.FIELD_BEGINTIME);
				Object endTime = item.get(IOvertimeDao.FIELD_ENDTIME);
				Object presenTime = item.get(IOvertimeDao.FIELD_PRESENTDATE);
				
				if (null != beginTime) {
					item.put(IOvertimeDao.FIELD_BEGINTIME, CommonUtils.replaceAll(beginTime.toString(), "-", "/"));
				}
				if (null != endTime) {
					item.put(IOvertimeDao.FIELD_ENDTIME, CommonUtils.replaceAll(endTime.toString(), "-", "/"));
				}
				
				if (null != presenTime) {
					item.put(IOvertimeDao.FIELD_PRESENTDATE, CommonUtils.replaceAll(presenTime.toString(), "-", "/"));
				}
			}
		}
		return UTExcel.leadingout(fileds, data, tamlate, request, response);
	}

	public List<UTMap<String, Object>> reportForMainPage(String baseOn, String type, Map<String, Object> param) {
		List<UTMap<String, Object>> resultList = null;
		param.put("forMainPage", "forMainPage");
		if("overtime".equalsIgnoreCase(type)) { // ignoreType是统计的sql忽略的语句：1、加班，2、请假，3、出差
			param.put("ignoreType", "2,3");
		} else if("vacation".equalsIgnoreCase(type)) {
			param.put("ignoreType", "1,3");
		} else if("travel".equalsIgnoreCase(type)) {
			param.put("ignoreType", "1,2");
		}
		if("org".equalsIgnoreCase(baseOn)) {
			resultList = manHourStatisticDao.baseOnOrgList(param);
		} else if("supplier".equalsIgnoreCase(baseOn)) {
			resultList = manHourStatisticDao.baseOnSupplierList(param);
		}
		return resultList;
	}
}
