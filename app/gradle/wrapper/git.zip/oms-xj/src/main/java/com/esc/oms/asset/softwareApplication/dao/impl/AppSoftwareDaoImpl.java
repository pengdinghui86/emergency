package com.esc.oms.asset.softwareApplication.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.asset.softwareApplication.dao.IAppSoftwareDao;
import com.esc.oms.util.RoleUtils;

@Repository
public class AppSoftwareDaoImpl extends BaseOptionDao implements IAppSoftwareDao {

	private static final String  TABLE_NAME="software_application_library";

	@Override
	public String getTableName() {
		return TABLE_NAME;
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params), pageBean, null);
	}
	
	@Override
	public List<UTMap<String, Object>> getListMaps(Map param) {
		return super.getListBySql(getSearchSql(param), null);
	}
	
	public String getSearchSql(Map params){
		StringBuilder sb = new StringBuilder();
		sb.append(" select ");
		
		sb.append(" tb.id,tb.code,tb.name,tb.softwareType,tb.exploitType,tb.shortName,");
		sb.append(" tb.status,tb.supplierId,tb.supplierContact,tb.supplierContactWay,tb.agreementId,");
		sb.append(" tb.version,tb.versionAddress,tb.scCodeAddress,tb.documentAddress,tb.chargeId,tb.chargeNumber,tb.useDepartIds,");
		sb.append(" tb.userNum,tb.maintenance,tb.startDate,tb.endDate,tb.maintainId,tb.maintainNumber,");
		sb.append(" tb.isSteerable,tb.isExpire,tb.intellProperty,tb.introducation,");
		sb.append(" tb.createUserId,tb.createTime,tb.createUser,tb.upataeTime,tb.updateUser,tb.category,");
		sb.append(" tb.maintainContractId ,");
		sb.append(" ai.agreementName ,aig.agreementName maintainContractName,");
		sb.append(" su.name chargeName,");
		sb.append(" ssc.name categoryName,");
		sb.append(" sbi.name supplierName ");
		sb.append(" FROM "+TABLE_NAME+" tb");
		sb.append(" LEFT JOIN supplier_base_info sbi ON sbi.id = tb.supplierId ");
		sb.append(" left join assets_agreement_info ai on tb.agreementId = ai.id ");
		sb.append(" left join assets_agreement_info aig on tb.maintainContractId = aig.id ");
		sb.append(" LEFT JOIN sys_user su ON su.id = tb.chargeId ");
		//sb.append(" LEFT JOIN software_category sc ON sc.id = tb.category ");
		sb.append(" LEFT JOIN software_sub_category ssc ON ssc.id = tb.category ");
		sb.append("	WHERE 1=1");
		
		if(params!=null && params.size()>0){		
			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
				sb.append(" AND tb.name like '%"+params.get("name").toString().trim()+"%' ");
			}
			if(params.get("supplierId")!=null && StringUtils.isNotEmpty(params.get("supplierId").toString())){
				sb.append(" AND tb.supplierId = '"+params.get("supplierId").toString().trim()+"' ");
			}
			if(params.get("category")!=null && StringUtils.isNotEmpty(params.get("category").toString())){
				sb.append(" AND tb.category = '"+params.get("category").toString().trim()+"' ");
			}
		
			if(params.get("isFilter")!=null && StringUtils.isNotEmpty(params.get("isFilter").toString())){
				//数据权限过滤
				if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR,RoleUtils.ASSET_MANAGER)){
					sb.append("  and tb.createUserId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' ");
				}
			}
			if(params.get("status")!=null && StringUtils.isNotEmpty(params.get("status").toString())){
				sb.append(" AND tb.status in ("+params.get("status").toString().trim()+")");
			}
			//还有一个月到期的就查出来。
			if(params.get("isExpire")!=null && StringUtils.isNotEmpty(params.get("isExpire").toString())){
				sb.append(" AND DATE_ADD(CURDATE(),INTERVAL 1 MONTH) > tb.endDate AND tb.status <> 3");
			}
		}
			
		sb.append(" order by tb.createTime desc ");
		return sb.toString();
	}

	
	@Override
	public UTMap<String, Object> getById(String id) {
		StringBuilder sql = new StringBuilder();
		//sql.append(" select  tb.*,s.name as supplierName,ai.agreementName,ai2.agreementName as maintainContractName,concat(su.name,'/',su.code) AS chargeUser");
		
		
		sql.append(" select ");
		sql.append(" tb.id,tb.code,tb.name,tb.softwareType,tb.exploitType,tb.shortName,");
		sql.append(" tb.status,tb.supplierId,tb.supplierContact,tb.supplierContactWay,tb.agreementId,");
		sql.append(" tb.version,tb.versionAddress,tb.scCodeAddress,tb.documentAddress,tb.chargeId,tb.chargeNumber,tb.useDepartIds,");
		sql.append(" tb.userNum,tb.maintenance,tb.startDate,tb.endDate,tb.maintainId,tb.maintainNumber,");
		sql.append(" tb.isSteerable,tb.isExpire,tb.intellProperty,tb.introducation,");
		sql.append(" tb.createUserId,tb.createTime,tb.createUser,tb.upataeTime,tb.updateUser,tb.category,");
		sql.append(" tb.maintainContractId,");
		sql.append(" ai.agreementName,aig.agreementName maintainContractName,");
		sql.append(" sbi.name supplierName ");
		sql.append(" from "+TABLE_NAME+"  tb");
		sql.append(" left join supplier_base_info sbi on tb.supplierId = sbi.id");
		sql.append(" left join assets_agreement_info ai on tb.agreementId = ai.id ");
		sql.append(" left join assets_agreement_info aig on tb.maintainContractId = aig.id ");
		sql.append(" where 1 = 1");
		sql.append(" and  tb.id = '").append(id).append("'");
		return super.getOneBySql(sql.toString(), null);
	}

	@Override
	public List<UTMap<String, Object>> getSoftwareList(Map param) {
		return super.getListBySql(getSearchSql(param));
	}


}
