package com.esc.oms.outsource.attendance.dao.impl;

import com.esc.oms.outsource.attendance.dao.IDingDingInfoDao;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class DingDingInfoDaoImpl extends BaseOptionDao implements IDingDingInfoDao {
    @Override
    public String getTableName() {
        return "dingding_info";
    }

    @Override
    public List<UTMap<String, Object>> getListMaps(Map param) {
        String sql=getSearchSql(param);
        return super.getListBySql(sql, null);
    }

    private String getSearchSql(Map<String, Object> param){
        StringBuilder sql = new StringBuilder();
        sql.append("select di.*,opl.userId from "+getTableName()+" di left join outsource_person_list opl on di.dingDingId = opl.dingDingId where 1=1 ");
        if(param != null){
            Integer isSynchronized = (Integer) param.get("isSynchronized");//是否已经同步
            String isLegal = (String)param.get("isLegal");//是否合法
            String locationResult = (String)param.get("locationResult");//是否在范围内
            if(isSynchronized != null){
                sql.append(" and isSynchronized = "+isSynchronized );
            }
            if(StringUtils.isNotEmpty(isLegal)){
                sql.append(" and isLegal = '"+isLegal+"'");
            }
            if(StringUtils.isNotEmpty((locationResult))){
                sql.append(" and locationResult='"+locationResult+"'");
            }
        }
        sql.append(" order by gmtCreate asc");
        return sql.toString();
    }
}
