package com.esc.oms.outsource.attendance.dao;


import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

/**
 * 不确定时间考勤考勤统计-按次数dao接口
 * @author owner
 *
 */
public interface IAttendanceStatisticsCountDao extends IBaseOptionDao {
	
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_USERID = "userId";//姓名id
	public static final String  FIELD_USERNAME = "userName";//姓名
	public static final String  FIELD_SUPPLIERID = "supplierId";//供应商id
	public static final String  FIELD_SUPPLIERNAME = "supplierName";//供应商
	public static final String  FIELD_COALITIONNAME = "coalitionName";//联合考勤名称
	public static final String  FIELD_ORGID= "orgId";//部门id
	public static final String  FIELD_ORGNAME = "orgName";//部门
	public static final String  FIELD_YEAR = "year";
	public static final String  FIELD_MONTH = "month";
	public static final String  FIELD_YEARMONTH = "yearMonth";
	public static final String  FIELD_QUARTER = "quarter";
	public static final String  FIELD_BEGINDATE = "beginDate";
	public static final String  FIELD_ENDDATE = "endDate";
	public static final String  FIELD_ATTNEEDDAYS = "attNeedDays";
	public static final String  FIELD_ATTDAYS = "attDays";
	public static final String  FIELD_ATTNORMALDAYS = "attNormalDays";
	public static final String  FIELD_ATTEXDAYS = "attExDays";
	public static final String  FIELD_EXDAYS = "exDays";
	public static final String  FIELD_PERCENTAGE = "percentage";
	public static final String  FIELD_MEMBERNUM = "memberNum";
	public static final String  FIELD_EXMEMBERNUM = "exMemberNum";
	public static final String  FIELD_NAME = "name";//名称
	
	
	//个人
	public static final String[] outFileds = new String[] {
		FIELD_USERNAME,
		FIELD_SUPPLIERNAME,
		FIELD_ORGNAME,
		FIELD_BEGINDATE,
		FIELD_ENDDATE,
		FIELD_ATTNEEDDAYS,
		FIELD_ATTDAYS,
		FIELD_ATTNORMALDAYS,
		FIELD_ATTEXDAYS,
		FIELD_EXDAYS,
		FIELD_PERCENTAGE
	};
	
	//个人+联合考勤字段
	public static final String[] outFiledsCoalition = new String[] {
		FIELD_USERNAME,
		FIELD_SUPPLIERNAME,
		FIELD_ORGNAME,
		FIELD_COALITIONNAME,
		FIELD_BEGINDATE,
		FIELD_ENDDATE,
		FIELD_ATTNEEDDAYS,
		FIELD_ATTDAYS,
		FIELD_ATTNORMALDAYS,
		FIELD_ATTEXDAYS,
		FIELD_EXDAYS,
		FIELD_PERCENTAGE
	};
	
	//联合
	public static final String[] outAttCoalitionOperationsCountFileds = new String[] {
		FIELD_COALITIONNAME,
		FIELD_SUPPLIERNAME,
		FIELD_ORGNAME,
		FIELD_BEGINDATE,
		FIELD_ENDDATE,
		FIELD_ATTNEEDDAYS,
		FIELD_ATTDAYS,
		FIELD_ATTNORMALDAYS,
		FIELD_ATTEXDAYS,
		FIELD_EXDAYS,
		FIELD_PERCENTAGE
	};
	
	//供应商
	public static final String[] outAttSupplierOperationsCountFileds = new String[] {
		FIELD_SUPPLIERNAME,
		FIELD_YEARMONTH,
		FIELD_MEMBERNUM,
		FIELD_EXMEMBERNUM,
		FIELD_PERCENTAGE
	};
	
	//部门
	public static final String[] outAttOrgOperationsCountFileds = new String[] {
		FIELD_ORGNAME,
		FIELD_YEARMONTH,
		FIELD_MEMBERNUM,
		FIELD_EXMEMBERNUM,
		FIELD_PERCENTAGE
	};
	
	//统计详情
	public static final String[] outAttOperationsCountDetailFileds = new String[] {
		FIELD_NAME,
		FIELD_SUPPLIERNAME,
		FIELD_ORGNAME,
		FIELD_YEARMONTH,
		FIELD_ATTNEEDDAYS,
		FIELD_ATTDAYS,
		FIELD_ATTNORMALDAYS,
		FIELD_ATTEXDAYS,
		FIELD_EXDAYS,
		FIELD_PERCENTAGE
	};

	/**
	 * 删除指定年月的统计数据
	 * @param yearMonth
	 */
	public void deleteByDate(String yearMonth);
	
	/**
	 * 初始化指定日期范围内的不确定考勤，按考勤次数的考勤统计数据
	 * @param beginDate
	 * @param endDate
	 */
	public void initDate(String beginDate, String endDate,int year,int month,int quarter,String yearMonth);
	
	/**
	 * 运维联合考勤统计
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllCoalitionOperations(Map param);
	
	/**
	 * 运维联合考勤统计
	 * @param pageBean
	 * @param param
	 */
	public void getCoalitionOperations(UTPageBean pageBean,Map param);

	/**
	 * 运维考勤统计（供应商）
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllSupplierOperations(Map param);
	
	/**
	 * 运维考勤统计（供应商）
	 * @param pageBean
	 * @param param
	 */
	public void getSupplierOperations(UTPageBean pageBean,Map param);
	
	/**
	 * 运维考勤统计（部门）
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllOrgOperations(Map param);
	
	/**
	 * 运维考勤统计（部门）
	 * @param pageBean
	 * @param param
	 */
	public void getOrgOperations(UTPageBean pageBean,Map param);
	
	/**
	 * 点击异常率查询详情数据接口
	 * @param param
	 * @return
	 */
	public void getDetail(UTPageBean pageBean,Map param);
	
	/**
	 * 点击异常率查询详情数据接口
	 * @param param
	 * @return
	 */
	public List<UTMap<String, Object>> getDetail(Map param);
}
