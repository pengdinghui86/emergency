package com.esc.oms.asset.associationRelation.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import net.sf.json.JSONArray;

import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.asset.associationRelation.service.IAllocationlRelationService;
import com.esc.oms.asset.physical.service.IAssetPhysicalService;
import com.esc.oms.util.CommonUtils;
@Controller
@RequestMapping("allocationlRelation")
public class AllocationRelationController extends BaseOptionController {


	@Resource
	private IAllocationlRelationService allocationlRelationService;
	
	@Resource
	private IAssetPhysicalService assetPhysicalService;
	
	@Override
	public IBaseOptionService optionService() {
		return allocationlRelationService;
	}
	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			allocationlRelationService.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	
    @RequestMapping(value="/saveOrUpdate",method=RequestMethod.POST)  
    @ResponseBody
    public String saveorupdate(@RequestBody Map<String,Object> map1){
    	Map<String, Object> cloneInfo = CommonUtils.clone(map1);
    	try{
	    	if(cloneInfo.get("id") == null){
	    		 optionService().add(cloneInfo);
	    	}else{
	    		 optionService().updateById(cloneInfo);
	    	}
    	}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "操作成功");
    }
    
    /**
	 * 根据id查询
	 * @param param
	 * @return
	 */
	@RequestMapping(value="getById")
	@ResponseBody
	public UTMap<String, Object> defgetById(@RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = null;
    	try{
    		map = allocationlRelationService.getById(param.get("id").toString());
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return map;
	}
	
	@RequestMapping(value = "delete", method = RequestMethod.POST)
	@ResponseBody
	public String delete(@RequestBody Map<String, Object> param) {
		try {
			allocationlRelationService.delete(param);
		} catch (Exception e) {
			logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
		}
		 return UTJsonUtils.getJsonMsg(true, "操作成功");
	}
	
	
	@RequestMapping(value="getAssetList")
	@ResponseBody
	public List<UTMap<String, Object>> getAssetList(@RequestParam  Map<String, Object> param){		
		List<UTMap<String,Object>> assetList = null;
		List<UTMap<String,Object>> assetRelationList = null;
//		List<UTMap<String,Object>> list = new ArrayList<UTMap<String,Object>>();
		List<UTMap<String,Object>> list = assetPhysicalService.getAssetsList(param);
    	try{
    		assetList = assetPhysicalService.getAssetsList(param);
    		assetRelationList = allocationlRelationService.getListMaps(param);
    		for (UTMap<String, Object> ut : assetList) {
				for (UTMap<String, Object> map : assetRelationList) {
					if(String.valueOf(ut.get("id")).equals(String.valueOf(map.get("mainAssetId")))){
						list.remove(ut);
					}
				}
//				list.add(ut);
			}
//    		list2.removeAll(list);
		}catch(Exception e){
			logger.error("Exception", e);
			return new ArrayList<UTMap<String, Object>>();
    	}
       return list;
	}
	
	
	
	/**
	 * @param params
	 * @return 
	 * 全部关系展示
	 */
	@RequestMapping(value = "getJson")
	@ResponseBody
	public JSONArray getJson(@RequestParam Map<String, Object> params) {
		JSONArray json = null;
		try {
			json = allocationlRelationService.getJson();
		} catch (Exception e) {
			logger.error("Exception", e);
		}
		return json;
	}
	
	
	/**
	 * @param params
	 * @return
	 * 用于展示局部视图
	 */
	@RequestMapping(value = "getJsonById")
	@ResponseBody
	public JSONArray getJsonById(@RequestParam Map<String, Object> params) {
		JSONArray json = null;
		try {
			json = allocationlRelationService.getJsonById(params.get("id").toString());
		} catch (Exception e) {
			logger.error("Exception", e);
		}
		return json;
	}
	
	
	
	/**
	 * @param param
	 * @return
	 * 根据资产ID找到关联的实物资产与软件资产列表
	 */
	@RequestMapping(value = "getRelList")
	@ResponseBody
	public UTMap<String, Object> getRelListByAssetsId(@RequestParam Map<String, Object> param) {
		UTMap<String, Object> map = null;
		try {
			map = allocationlRelationService.getRelList(param.get("assetsId").toString());
		} catch (Exception e) {
			logger.error("Exception", e);
			return new UTMap<String, Object>();
		}
		return map;
	}
	
	
	
	/**
	 * @param param
	 * @return
	 * 根据资产编号找到资产ID
	 */
	@RequestMapping(value = "getAssetsByCode")
	@ResponseBody
	public UTMap<String, Object> getAssetsByCode(@RequestParam Map<String, Object> param) {
		UTMap<String, Object> map = null;
		try {
			map = allocationlRelationService.getAssetsByCode(param.get("code").toString());
			if (map == null) {
				map = new UTMap<String, Object>();
			}
		} catch (Exception e) {
			logger.error("Exception", e);
			return new UTMap<String, Object>();
		}
		return map;
	}
}