package com.esc.oms.outsource.external.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.external.dao.IExternalEvaluateDao;
import com.esc.oms.util.RoleUtils;

/**
 * 非驻场外包评估Dao
 * @author owner
 *
 */
@Repository
public class ExternalEvaluateDaoImpl extends BaseOptionDao implements IExternalEvaluateDao{

	@Override
	public String getTableName() {
		return "outsourc_external_evaluate";
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params,false), pageBean, null);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params) {
		return super.getListBySql(getSearchSql(params,false), null);
	}
	
	@Override
	public UTMap<String, Object> getById(String id) {
		String sql = this.getSearchSql(null,true);
		List<UTMap<String, Object>> list = super.getListBySql(sql, id);
		if(list != null && list.size() > 0){
			return list.get(0);
		}
		return null;
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params,boolean isGetById){
		StringBuilder sql = new StringBuilder();
		sql.append(" select (saet.evaluateBeginDate <= '"+UTDate.getCurDate()+"') as 'dateStatus',sae.*,concat(su.name,'/',su.code) as 'evaluatorName',concat(su2.name,'/',su2.code) as 'submitterName',saet.evaluateBeginDate, saet.evaluateEndDate, sbi.name as 'supplierName' ");
		sql.append(" ,saet.evaluateName,saet.templateConfigurationId,saet.templateConfigurationName,saet.templateConfigurationVersions,saet.createTime as 'templateConfigurationCreateTime' ");
		sql.append(" ,saec.evaluateTitle,saec.beginDate,saec.endDate,saec.status as 'accessEvaluateConfigurationStatus',oere.status as 'accessEvaluateResultStatus' ");
		sql.append(" from outsourc_external_evaluate sae ");
		sql.append(" left join outsourc_external_evaluate_template saet on sae.externalEvaluateTemplateId = saet.id ");
		sql.append(" left join outsourc_external_evaluate_configuration saec on saet.externalEvaluateConfigId = saec.id ");
		sql.append(" left join outsourc_external_result_evaluate oere on oere.id = sae.externalResultEvaluateId ");
		sql.append(" left join supplier_base_info sbi on sae.supplierId = sbi.id ");
		sql.append(" left join sys_user su on sae.evaluator = su.id ");
		sql.append(" left join sys_user su2 on sae.submitter = su2.id" );
		sql.append(" where 1=1 ");//根据评估配置的开始时间来判断是否可以进行评估
//		if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR,RoleUtils.SUPPLIER_ADMINISTRATOR)){
//			sql.append(" and sae.evaluator = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' ");//非研发用户只能查询自己的数据，研发用户查询所有数据方便调试
//		}
		if(isGetById){
			sql.append(" and sae.id = ? ");
		}
		if(params!=null && params.size()>0){
			//存在参数isAccessEvaluateList表示是从评估结果页面查询数据,评估结果页面可以查看还未开始的评估数据，而评估页面不可以
			if(params.get("isAccessEvaluateList") != null ){
			}else{
				sql.append(" and saet.evaluateBeginDate <= '"+UTDate.getCurDate()+"' ");//根据评估配置的开始时间来判断是否可以进行评估
			}
			//评估页面只能看自己的数据
			if(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId() != null && params.get("isEvaluate") != null && !EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR)){
				sql.append(" and sae.evaluator like '%"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"%' ");//非研发用户只能查询自己的数据，研发用户查询所有数据方便调试
			}
			if(params.get("status")!=null && StringUtils.isNotEmpty(params.get("status").toString())){
				sql.append(" and sae.status = "+params.get("status").toString().trim()+" ");
			}
			if(params.get("accessEvaluateResultStatus")!=null && StringUtils.isNotEmpty(params.get("accessEvaluateResultStatus").toString())){
				sql.append(" and oere.status = "+params.get("accessEvaluateResultStatus").toString().trim()+" ");
			}
			if(params.get("evaluateName")!=null &&  StringUtils.isNotEmpty(params.get("evaluateName").toString())){
				sql.append(" and saet.evaluateName like '%"+params.get("evaluateName").toString().trim()+"%' ");
			}
			if(params.get("evaluateTitle")!=null &&  StringUtils.isNotEmpty(params.get("evaluateTitle").toString())){
				sql.append(" and saec.evaluateTitle like '%"+params.get("evaluateTitle").toString().trim()+"%' ");
			}
			if(params.get("externalEvaluateConfigId")!=null && StringUtils.isNotEmpty(params.get("externalEvaluateConfigId").toString())){
				sql.append(" and sae.externalEvaluateConfigId = '"+params.get("externalEvaluateConfigId").toString().trim()+"' ");
			}
			if(params.get("externalResultEvaluateId")!=null && StringUtils.isNotEmpty(params.get("externalResultEvaluateId").toString())){
				sql.append(" and sae.externalResultEvaluateId = '"+params.get("externalResultEvaluateId").toString().trim()+"' ");
			}
			if(params.get("generateTime")!=null && StringUtils.isNotEmpty(params.get("generateTime").toString())){
				sql.append(" and sae.generateTime = '"+params.get("generateTime").toString().trim()+"' ");
			}
			if(params.get("supplierId")!=null && StringUtils.isNotEmpty(params.get("supplierId").toString())){
				sql.append(" and sae.supplierId = '"+params.get("supplierId").toString().trim()+"' ");
			}
			if(params.get("supplierName")!=null && StringUtils.isNotEmpty(params.get("supplierName").toString())){
				sql.append(" and sbi.name like '%"+params.get("supplierName").toString().trim()+"%' ");
			}
			if(params.get("isSendMessageDate")!=null){//如果是查询当天需要发送消息的数据
				sql.append(" and saet.evaluateBeginDate = '"+UTDate.getCurDate()+"' and sae.status != 2 ");//
			}
//			if(params.get("subType")!=null && StringUtils.isNotEmpty(params.get("subType").toString())){
//				sql.append(" and tb.subType = "+params.get("subType").toString().trim()+" ");
//			}
		}
		if(params!=null && params.get("isAccessEvaluateList")!=null ){
			sql.append(" order by saet.evaluateName");
		}else{
			sql.append(" order by sae.createTime desc");
		}
//		sql.append(" order by sae.status asc,saec.evaluateTitle , sae.createTime desc");
		return  sql.toString();
	}

}
