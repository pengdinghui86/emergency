package com.esc.oms.asset.lowvalue.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;


public interface ILowvalueInfoService extends IBaseOptionService{
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params);
	/**
	 * 导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public boolean leadingout(List data, HttpServletRequest request,HttpServletResponse response) throws Exception;
	
}


