package com.esc.oms.outsource.monitor.controller;

import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.outsource.monitor.service.IMonitorEvaluateConfigurationService;
import com.esc.oms.util.CommonUtils;

/**
 * 服务监控评估配置Controller
 * @author owner
 *
 */
@Controller
@RequestMapping("monitorEvaluateConfiguration")
public class MonitorEvaluateConfigurationController extends BaseOptionController {

	@Resource
	private IMonitorEvaluateConfigurationService service;
	
	@Override
	public IBaseOptionService optionService() {
		return service;
	}
	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean  = CommonUtils.getPageBean(params);
		try{
			service.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	/**
	 * 根据id查询
	 * @param param
	 * @return
	 */
//	@RequestMapping(value="getByIdToAccessResult")
//	@ResponseBody
//	public UTMap<String, Object> getByIdToAccessResult(@RequestParam  Map<String, Object> param){		
////		logger.info("执行默认根据Id获取方法");
////		return UTJsonUtils.getResultJson(true, optionService().getById(param.get("id").toString()));
//		UTMap<String, Object> map = null;
//    	try{
//    		map = service.getByIdToAccessResult(param.get("id").toString());
//		}catch(Exception e){
//			logger.error("Exception", e);
//			return new UTMap<String, Object>();
//    	}
//       return map;
//	}
	
	/**
	 * 总评估
	 * @param info
	 * @return
	 */
//	@RequestMapping(value="evaluate")
//	@ResponseBody
//	public String evaluate(@RequestBody  Map<String, Object> info){
//		try{
//			service.evaluate(info);
//    	}catch(EscServiceException e){
//    		logger.error("EscServiceException", e);
//    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
//    	}catch(Exception e){
//    		logger.error("Exception", e);
//    		return UTJsonUtils.getJsonMsg(false, "评估失败");
//    	}
//       return UTJsonUtils.getJsonMsg(true, "评估成功");
//	}
	
	/**
	 * 关闭
	 * @param info
	 * @return
	 */
	@RequestMapping(value="close")
	@ResponseBody
	public String close(@RequestBody  Map<String, Object> info){
		try{
			service.close(info);
    	}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "关闭失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "关闭成功");
	}
	
	/**
	 * 暂停
	 * @param info
	 * @return
	 */
	@RequestMapping(value="pause")
	@ResponseBody
	public String pause(@RequestBody Map<String, Object> info){
		try{
			service.pause(info);
    	}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "暂停操作失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "暂停操作成功");
	}
	
	/**
	 * 启用
	 * @param info
	 * @return
	 */
	@RequestMapping(value="enabled")
	@ResponseBody
	public String enabled(@RequestBody Map<String, Object> info){
		try{
			service.enabled(info);
    	}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "启用操作失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "启用操作成功");
	}
	
	/**
	 * 手动生成定时数据
	 * @return
	 */
	@RequestMapping(value="generate")  
    @ResponseBody
    public String generate(){  
		try{
			service.generate();
		}catch(Exception e){
    		return UTJsonUtils.getJsonMsg(false,"generate接口调用失败!");
    	}
		return UTJsonUtils.getJsonMsg(true, "generate接口调用成功!");
    }
	

}
