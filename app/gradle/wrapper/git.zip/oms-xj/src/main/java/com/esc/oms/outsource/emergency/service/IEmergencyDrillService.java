package com.esc.oms.outsource.emergency.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;


public interface IEmergencyDrillService extends IBaseOptionService{
	
	public boolean leadingout(List data, HttpServletRequest request,HttpServletResponse response) throws Exception;
	
	public List<UTMap<String, Object>> getDrillByNameAndId(String name,String id);
	
}
