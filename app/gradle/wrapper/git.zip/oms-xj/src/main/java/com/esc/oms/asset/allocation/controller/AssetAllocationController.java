package com.esc.oms.asset.allocation.controller;

import com.esc.oms.asset.allocation.service.IAssetAllocationlService;
import com.esc.oms.asset.assetCategory.service.IAssetCategoryService;
import com.esc.oms.asset.physical.service.IAssetPhysicalService;
import com.esc.oms.util.CommonUtils;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTListResult;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.*;

@Controller
@RequestMapping("assetAllocation")
public class AssetAllocationController extends BaseOptionController {


	@Resource
	private IAssetAllocationlService assetAllocationlService;
	
	@Resource
	private IAssetPhysicalService assetPhysicalService;

	@Resource
	private IAssetCategoryService assetCategoryService;
	
	@Override
	public IBaseOptionService optionService() {
		return assetAllocationlService;
	}
	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			assetAllocationlService.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	@RequestMapping(value="getAllList")
	@ResponseBody
	public UTListResult getAllList(@RequestParam  Map<String, Object> param){
		UTListResult result = new UTListResult();
		try{
			List<UTMap<String, Object>> list = optionService().getListMaps(param);
			//排序。。。前端需求
			list = sortList(list);
			result.setRows(list);
			result.setTotal(list.size());
		}catch(Exception e){
			logger.error("Exception", e);
		}
		return result;
	}
	
    @RequestMapping(value="/saveOrUpdate",method=RequestMethod.POST)  
    @ResponseBody
    public String saveorupdate(@RequestBody Map<String,Object> map1){
    	Map<String, Object> coloneParam = CommonUtils.clone(map1);
    	
    	boolean flag = false;
    	boolean propertyFlag = false;
    	String name = String.valueOf(coloneParam.get("name"));
    	String id = String.valueOf(coloneParam.get("id"));
    	String parentId = String.valueOf(coloneParam.get("parentId"));
    	try{
	    	if(coloneParam.get("id") == null){
	    		Map param = new HashMap();
	    		param.put("name", name);
	    		if(assetAllocationlService.isExist(param)){
	    			throw new EscServiceException("资产类别名称已经存在！");
	    		}
	    		flag = assetAllocationlService.add(coloneParam);
	    		List<Map<String, Object>> propertyList = (List<Map<String, Object>>) coloneParam.get("propertyList");
	    		if(flag && (null != propertyList)){
	    			for (Map<String, Object> utMap : propertyList) {
	    				utMap.put("categoryId", coloneParam.get("id"));
	    				propertyFlag = assetAllocationlService.addProperty(utMap);
	    				if(propertyFlag && (null != utMap)){
	    					List<Map<String, Object>> propertyValueList = (List<Map<String, Object>>) utMap.get("propertyValueList");
	    					if(null != propertyValueList){
	    						for (Map<String, Object> propertyValue : propertyValueList) {
	    							propertyValue.put("categoryId", utMap.get("id"));
	    							assetAllocationlService.addPropertyOption(propertyValue);
	    						}
	    					}
	    				}
					}
	    		}
	    	}else{
	    		if(StringUtils.isNotEmpty(name)){
	    			List<UTMap<String,Object>> names = assetAllocationlService.getCategoryByNameAndId(name, id);
	    			if(null != names && names.size() > 0){
	    				throw new EscServiceException("资产类别名称已经存在！");
	    			}
	    		}
	    		//判断当前如果为大类，且包含小类，则不能转为小类（参数不包含parentId）
				Map<String, Object> param = new HashMap<>();
	    		param.put("parentId", id);
				List<UTMap<String, Object>> childList = assetAllocationlService.getListMaps(param);
				if(childList != null && childList.size() > 0 && CommonUtils.notNullStrOrEmpty(parentId)){
					throw new EscServiceException("该资产大类下包含小类，不能再变更为小类！");
				}
	    		flag = assetAllocationlService.updateById(coloneParam);
	    		List<Map<String, Object>> propertyList = (List<Map<String, Object>>) coloneParam.get("propertyList");
	    		if(flag && (null != propertyList)){
	    			assetAllocationlService.deleteProperty((String)coloneParam.get("id"));
	    			for (Map<String, Object> utMap : propertyList) {
	    				utMap.put("categoryId", coloneParam.get("id"));
	    				propertyFlag = assetAllocationlService.addProperty(utMap);
//	    				if(StringUtils.isNotEmpty(map.get("id").toString())){
//	    					propertyFlag = assetAllocationlService.updatePropertyByCategoryId(utMap);
//	    				}else{
//	    				}
	    				if(propertyFlag && (null != utMap)){
	    					assetAllocationlService.deleteOption((String)(utMap.get("id")));
	    					List<Map<String, Object>> propertyValueList = (List<Map<String, Object>>) utMap.get("propertyValueList");
	    					if(null != propertyValueList){
	    						for (Map<String, Object> propertyValue : propertyValueList) {
	    							propertyValue.put("categoryId", utMap.get("id"));
	    							assetAllocationlService.addPropertyOption(propertyValue);
	    						}
	    					}
	    				}
					}
	    		}
	    	}
    	}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "操作成功");
    }
    
    /**
	 * 根据id查询
	 * @param param
	 * @return
	 */
	@RequestMapping(value="getById")
	@ResponseBody
	public UTMap<String, Object> defgetById(@RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = null;
		List<UTMap<String, Object>> propertyList = null;
		List<UTMap<String, Object>> propertyValueList = null;
    	try{
    		if(null != param.get("id")){
    			map = optionService().getById(param.get("id").toString());
    			if(null != map){
    				propertyList = assetAllocationlService.getPropertyByCategoryId(map.get("id").toString());
    				map.put("propertyList", propertyList);
    				if(null != propertyList && propertyList.size()>0){
    					for (UTMap<String, Object> utMap : propertyList) {
    						propertyValueList = assetAllocationlService.getOptionByPropertyId(utMap.get("id").toString());
    						utMap.put("propertyValueList", propertyValueList);
    					}
    				}
    			}
    		}
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return map;
	}

	
	@RequestMapping(value="/subSaveorupdate",method=RequestMethod.POST)  
	@ResponseBody
	public String subSaveorupdate(@RequestBody Map<String,Object> map1){
		Map<String,Object> cloneMap = CommonUtils.clone(map1);
		
	    boolean flag = false;
	    boolean propertyFlag = false;
	    String name = String.valueOf(cloneMap.get("name"));
	    String id = String.valueOf(cloneMap.get("id"));
	    String parentId = String.valueOf(cloneMap.get("parentId"));
	    try{
		    if(cloneMap.get("id") == null){
	    		UTMap<String,Object> subCategory = assetAllocationlService.getSubCategoryByNameAndCategoryId(name, parentId);
	    		if(null != subCategory){
	    			throw new EscServiceException("资产级别名称已经存在！");
	    		}
		    		flag = assetAllocationlService.addSubCategory(cloneMap);
		    		List<Map<String, Object>> optionList = (List<Map<String, Object>>) cloneMap.get("optionList");
		    		if(flag && (null != optionList)){
		    			for (Map<String, Object> utMap : optionList) {
		    				utMap.put("subCategoryId", cloneMap.get("id"));
		    				propertyFlag = assetAllocationlService.addSubPropertyOption(utMap);
		    				if(propertyFlag && (null != utMap)){
		    					List<Map<String, Object>> optionValueList = (List<Map<String, Object>>) utMap.get("optionValueList");
		    					if(null != optionValueList){
		    						for (Map<String, Object> optionValue : optionValueList) {
		    							optionValue.put("categoryId", utMap.get("id"));
		    							assetAllocationlService.addPropertyOption(optionValue);
		    						}
		    					}
		    				}
						}
		    		}
		    	}else{
		    		List<UTMap<String,Object>> list = assetAllocationlService.getSubCategoryByNameAndCategoryIdAndSubCategoryId(name, id, parentId);
		    		if(null != list && list.size() > 0){
		    			throw new EscServiceException("资产级别名称已经存在！");
		    		}
		    		flag = assetAllocationlService.updateSubCategoryById(cloneMap);
		    		List<Map<String, Object>> optionList = (List<Map<String, Object>>) cloneMap.get("optionList");
		    		if(flag && (null != optionList)){
		    			assetAllocationlService.deleteSubProperty((String)cloneMap.get("id"));
		    			for (Map<String, Object> utMap : optionList) {
		    				utMap.put("subCategoryId", cloneMap.get("id"));
		    				propertyFlag = assetAllocationlService.addSubPropertyOption(utMap);
		    				if(propertyFlag && (null != utMap)){
		    					assetAllocationlService.deleteOption((String)utMap.get("id"));
		    					List<Map<String, Object>> optionValueList = (List<Map<String, Object>>) utMap.get("optionValueList");
		    					if(null != optionValueList){
		    						for (Map<String, Object> optionValue : optionValueList) {
		    							optionValue.put("categoryId", utMap.get("id"));
		    							assetAllocationlService.addPropertyOption(optionValue);
		    						}
		    					}
		    				}
						}
		    		}
		    	}
	    	}catch(EscServiceException e){
	    		logger.error("EscServiceException", e);
	    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
	    	}catch(Exception e){
	    		logger.error("Exception", e);
	    		return UTJsonUtils.getJsonMsg(false, "操作失败");
	    	}
	       return UTJsonUtils.getJsonMsg(true, "操作成功");
	    }
	
	
	/**
	 * 根据id查询
	 * @param param
	 * @return
	 */
	@RequestMapping(value="getSubById")
	@ResponseBody
	public UTMap<String, Object> getSubById(@RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = null;
		List<UTMap<String, Object>> optionList = null;
		List<UTMap<String, Object>> optionValueList = null;
    	try{
    		map = assetAllocationlService.getSubCategoryById(param.get("id").toString());
    		if(null != map){
    			optionList = assetAllocationlService.getSubPropertyById((String)map.get("id"));
    			map.put("optionList", optionList);
    			if(null != optionList && optionList.size()>0){
    				for (UTMap<String, Object> utMap : optionList) {
    					optionValueList = assetAllocationlService.getOptionByPropertyId((String)utMap.get("id"));
    					utMap.put("optionValueList", optionValueList);
					}
    			}
    		}
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return map;
	}
	
	@RequestMapping(value = "delete", method = RequestMethod.POST)
	@ResponseBody
	public String delete(@RequestBody Map<String, Object> param) {
		String id = null;
		if(null != param){
			UTMap<String,Object> ut = new UTMap<String,Object>();
			id = String.valueOf(param.get("id"));
			ut.put("category", id);
			List<UTMap<String,Object>> list = assetPhysicalService.getListMaps(ut);
			if(null != list && list.size() > 0){
				return UTJsonUtils.getJsonMsg(false, "该资产类别已被引用，禁止删除");
			}
			//判断是否存在小类
			ut.clear();
			ut.put("parentId", id);
			List<UTMap<String,Object>> childList = assetAllocationlService.getListMaps(ut);
			if(childList != null && childList.size() > 0){
				return UTJsonUtils.getJsonMsg(false, "该资产类别下面存在小类，禁止删除");
			}
			//判断是否存在额外属性
			ut.clear();
			ut.put("categoryId",id);
			List<UTMap<String,Object>> attrList = assetCategoryService.getAttrList(ut);
			if(attrList != null && attrList.size() > 0){
				return UTJsonUtils.getJsonMsg(false, "该资产类别下面存在额外属性，禁止删除");
			}
		}
		try {
//			UTMap<String,Object> map = new UTMap<String,Object>();
//			map.put("id", param.get("parentId"));
			assetAllocationlService.deleteById(id);
		} catch (Exception e) {
			logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "删除失败");
		}
		 return UTJsonUtils.getJsonMsg(true, "删除成功");
	}
	
	@RequestMapping(value = "deleteSubCategory", method = RequestMethod.POST)
	@ResponseBody
	public String deleteSubCategory(@RequestBody Map<String, Object> param) {
		if(null != param){
			UTMap<String,Object> ut = new UTMap<String,Object>();
			ut.put("subCategory", String.valueOf(param.get("id")));
			List<UTMap<String,Object>> list = assetPhysicalService.getListMaps(ut);
			if(null != list && list.size() > 0){
				return UTJsonUtils.getJsonMsg(false, "该资产级别已被引用，禁止删除");
			}
		}
		try {
			assetAllocationlService.deleteSubCategory(param);
		} catch (Exception e) {
			logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "删除失败");
		}
		 return UTJsonUtils.getJsonMsg(true, "删除成功");
	}
	
	@RequestMapping(value="getSubByParentId")
	@ResponseBody
	public List<UTMap<String, Object>> getSubByParentId(@RequestParam  Map<String, Object> param){		
		List<UTMap<String, Object>> subList = null;
		String parentId = (String)param.get("parentId");
    	try{
    		subList =  assetAllocationlService.getSubCategoryByParentId(parentId);
		}catch(Exception e){
			logger.error("Exception", e);
    	}
       return subList;
	}

	private List<UTMap<String, Object>>  sortList(List<UTMap<String, Object>> list){
		if(list == null || list.size() <= 0){
			return list;
		}
		List<UTMap<String, Object>> resultList = new ArrayList<>();
		List<UTMap<String, Object>> allList = new ArrayList<>();
		Iterator<UTMap<String, Object>> listIt = list.iterator();
		while(listIt.hasNext()){
			UTMap<String, Object> map = listIt.next();
			if(map.get("parentId") == null){
				resultList.add(map);
				listIt.remove();
			}
		}
		if(resultList == null || resultList.size() <= 0){
			return list;
		}
		for(UTMap<String, Object> result : resultList){
			allList.add(result);
			for(UTMap<String, Object> map : list){
				if(result.get("id").toString().equals(map.get("parentId"))){
					allList.add(map);
				}
			}

		}
		//最后剩余的小类
		list.removeAll(allList);
		allList.addAll(list);
		return allList;
	}
}