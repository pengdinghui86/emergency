package com.esc.oms.asset.application.service.impl;


import java.sql.Date;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.idgenerator.IDGenerationManager;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.workflow.annotation.WorkflowRecordQueryMark;
import org.esc.framework.workflow.service.IWorkflowCode;
import org.esc.framework.workflow.service.IWorkflowEngine;
import org.esc.framework.workflow.utils.bpmn.FlowForm;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.asset.application.dao.IAssetApplicationDao;
import com.esc.oms.asset.application.dao.IBusinessNumberDao;
import com.esc.oms.asset.application.service.IAssetApplicationService;
import com.esc.oms.asset.overview.dao.IAssetsTrackInfoDao;
import com.esc.oms.asset.overview.service.IAssetsTrackInfoService;
import com.esc.oms.asset.physical.dao.IAssetPhysicalDao;
import com.esc.oms.asset.physical.service.IAssetPhysicalService;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;
import com.esc.oms.util.RoleUtils;
import com.esc.oms.util.TaskModel;

@Service
@Transactional
public class AssetApplicationServiceImpl extends BaseOptionService implements IAssetApplicationService{
	
	public static final String STATUS_NOT_SUBMIT = "0";	// 未提交
	public static final String STATUS_NOT_AUDITING = "1";	// 待审批
	public static final String STATUS_AUDITING = "2";	// 审批中
	public static final String STATUS_FINISH = "3";	// 流程通过待发放
	public static final String STATUS_ISSUEING = "4";// 发放中
	public static final String STATUS_CONFIRM = "5";// 待确认
	public static final String STATUS_CONFIRMING = "6";// 确认中
	public static final String STATUS_CONFIRMED = "7";// 完成确认
	public static final String STATUS_REJECT = "8";// 驳回
	public static final String STATUS_TERMINATE = "9";	// 被终止

	@Resource
	private IAssetApplicationDao assetApplicationDao;
	@Resource
	private IBusinessNumberDao businessNumberDao;
	@Resource
	private IWorkflowEngine workflowEngine;
	
	@Resource
	private IAssetsTrackInfoService assetsTrackInfoService;
	
	@Resource
	private ISysUserService userService;
	
	@Resource
	private MessageSend messageService;
	
	@Resource
	private IUserTaskService userTaskService;
	
	@Resource
	private IAssetPhysicalService assetPhysicalService;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return assetApplicationDao;
	}
	
	@Override
	@WorkflowRecordQueryMark
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageInfo(pageBean, params);
	}
	
	
	@Override
	@EscOptionLog(module=SystemModule.assetApplication, opType=ESCLogOpType.INSERT, table="assets_material_apply",option="新增名称为{name}的资产申请信息。")
	public boolean add(Map info){
		info.put("createUserId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
		info.put("deleteFlag", 0);
		info.put("code", IDGenerationManager.nextId("assetsApplyCode")); // 自动生成编号
		return	getOptionDao().add(info);
	}
	
	
	@Override
	@EscOptionLog(module=SystemModule.assetApplication, opType=ESCLogOpType.UPDATE, table="assets_material_apply", option="修改名称为{name}的资产申请信息。")
	public boolean updateById(Map info){
		String status = String.valueOf(info.get("status"));
		boolean flag = getOptionDao().updateById(info);
		if(flag && ("5".equals(status))){
			UTMap<String, Object> ut = assetApplicationDao.getById(info.get("id").toString());
			String title = "资产申请【"+ut.get("title")+"/"+ut.get("code")+"】确认提醒";
			String content = "资产申请：【"+ut.get("title")+"/"+ut.get("code")+"】已发放，请在系统进行确认";
			messageService.sendMessage((String)ut.get("createUserId"),title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
						
			
			Map<String,Object> dataParam = new HashMap<String,Object>();
			//点击待办事项，打开申请列表tab
			dataParam.put("dataType", "0");
			//生成待办任务
			userTaskService.addTaskByUserId("资产申请【"+ut.get("title")+"/"+ut.get("code")+"】已发放，待您确认",(String) ut.get("id"), "实物资产发放确认", TaskModel.PhysicalAssetApply,(String)ut.get("createUserId"),dataParam);		
		}
		return flag;
	}
	
	private String saveOrUpdate(Map<String,Object> map){  
		if(map.get("id") == null){
			map.put("applyUserId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectName());
			map.put("applyTime", new Date(System.currentTimeMillis()));
//			Calendar cal = Calendar.getInstance();
//			int year = cal.get(Calendar.YEAR);
//			String planNum = businessNumberDao.saveOrUpdate("SWZC", String.valueOf(year), "%04d");
//			map.put("code", planNum);
    		add(map);
    	}else{
    		updateById(map);
    		finishRejectTask(map.get("id").toString());
    	}
		return (String)map.get("id");
    }
	
	@Override
	public void finishRejectTask(String id) {
		userTaskService.finishTask(id, "实物资产申请被驳回");
	}

	@Override
	public boolean addAssetIssue(Map<String,Object> info) {
		boolean flag = assetApplicationDao.addAssetIssue(info);
		return flag;
	}

	@Override
	public boolean updateAssetIssueById(Map<String,Object> info) {
		boolean flag = assetApplicationDao.updateAssetIssueById(info);
		return flag;
	}
	
	@Override
	public boolean checkAssetIssueConfirm(String appId, String status){
		return assetApplicationDao.checkAssetIssueConfirm(appId, status);
	}
	
	@Override
	public boolean startAssetIssue(String appId) {
		boolean flag = updateApplication(appId, STATUS_ISSUEING);
		return flag;
	}
	
	@Override
	public boolean completeAssetIssue(String appId) {
		boolean flag = updateApplication(appId, STATUS_CONFIRM);
		userTaskService.finishTask(appId, "实物资产发放");
		return flag;
	}
	
	@Override
	public boolean completeAssetIssueConfirm(String appId) {
		boolean flag = updateApplication(appId,STATUS_CONFIRMED);
		userTaskService.finishTask(appId, "实物资产发放确认");
		return flag;
	}
	
	@Override
	public boolean deleteAssetIssueById(String id) {
		return assetApplicationDao.deleteAssetIssueById(id);
	}
	
	@Override
	public boolean deleteAssetIssueByAssetId(String id) {
		return assetApplicationDao.deleteAssetIssueByAssetId(id);
	}

	@Override
	public boolean deleteAssetIssueByAppId(String id) {
		return assetApplicationDao.deleteAssetIssueByAppId(id);
	}
	
	@Override
	public List<UTMap<String, Object>> getAssetIssueListMaps(Map param) {
		return assetApplicationDao.getAssetIssueListMaps(param);
	}

	@Override
	public List<UTMap<String, Object>> getAssetListByAppId(Map param) {
		return assetApplicationDao.getAssetListByAppId(param);
	}
	
	@Override
	public boolean updateIssueStatusById(String ids,String appId){
		boolean flag = false;
		if(ids.indexOf(",") > 0 ){//批量确认
			String[] issueIds = ids.split(",");
			for (String issueId : issueIds) {
				flag = assetApplicationDao.updateIssueStatusById(issueId,"7");
				if(flag){
					addAssetsTrack(issueId);
				}
			}
		}else{
			flag = assetApplicationDao.updateIssueStatusById(ids,"7");
			if(flag){
				addAssetsTrack(ids);
			}
		}
		return flag;
	}

	@Override
	public List<UTMap<String, Object>> getAssetIssuePageInfo(Map param) {
		return assetApplicationDao.getAssetIssuePageInfo(param);
	}
	
	
	@EscOptionLog(module=SystemModule.assetApplication, opType=ESCLogOpType.DELETE, table="assets_material_apply",option="删除名称为{name}的资产申请信息。")
	public boolean deleteById(String id){
		boolean flag = false;
		flag = getOptionDao().deleteByIds(id);
		if(flag){
			flag = assetApplicationDao.deleteAssetIssueByAppId(id);
		}
		return	flag;
	}
	
	/**
	 * 根据ids删除
	 */
	@EscOptionLog(module=SystemModule.ASSET, opType=ESCLogOpType.DELETES, table="assets_material_apply",option="删除名称为{name}的资产申请信息。")	
	public boolean deleteByIds(String ids){
		boolean flag = false;
		flag = getOptionDao().deleteByIds(ids);
		if(flag && StringUtils.isNotEmpty(ids)){
			String[] appIds = ids.split(",");
			for (String appId : appIds) {
				flag = assetApplicationDao.deleteAssetIssueByAppId(appId);
			}
		}
		return flag;
	}

	@Override
	public String save(Map<String, Object> map) {
		//map.put("status", STATUS_NOT_SUBMIT);
		return saveOrUpdate(map);
	}
	
	@Override
	public String submit(Map<String,Object> map) {
		map.put("status", STATUS_NOT_AUDITING);
		String id = saveOrUpdate(map);
		//获取申请部门
		String orgId = map.get("applyUnit").toString();
		//从页面表单中提取 流程表单配置
		Map<String, Object> formMap=new HashMap<String, Object>();
		formMap.put(FlowForm.FormItemValue.SQDW, orgId);
		String workflowInstanceId = workflowEngine.runInstance(IWorkflowCode.PHYSICAL_ASSET_APPLY,  id, formMap);
		setInstanceId(id, workflowInstanceId);
		return id;
	}
	
	
	/**
	 * 设置 workflowInstanceId 
	 * @param recordId
	 * @param workflowInstanceId
	 */
	private void setInstanceId(String recordId,String workflowInstanceId){
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("workflowInstanceId", workflowInstanceId);
		updateById(map);
	}
	
	@Override
	public void finishAudit(String id) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", id);
		map.put("status", STATUS_FINISH);
		saveOrUpdate(map);
		
		userTaskService.finishTask(id, "审核");
		
		Map<String,Object> info = getById(id);
		
		//发送消息
		Map<String,Object> param = new HashMap<String,Object>();				
		param.put("signature", RoleUtils.ASSET_MANAGER);
		String taskUserIds = userService.getUserIds(param);	
		String title = "资产申请【"+info.get("title")+"/"+info.get("code")+"】发放提醒";
		String content = "资产申请：【"+info.get("title")+"/"+info.get("code")+"】已审批通过，请进行资产发放";
		messageService.sendMessage(taskUserIds,title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
		
		
		Map<String,Object> dataParam = new HashMap<String,Object>();
		//点击待办事项，打开申请列表tab
		dataParam.put("dataType", "0");
		//生成待办任务
//		UTMap<String,Object> utMap = super.getById(businessRecordId);
		userTaskService.addTaskByRole("资产申请【"+info.get("title")+"】已审批通过，待您发放", id, "实物资产发放", TaskModel.PhysicalAssetApply, RoleUtils.ASSET_MANAGER,dataParam);
	}
	
	@Override
	public void rejectAudit(String id) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", id);
		map.put("status", STATUS_REJECT);
		saveOrUpdate(map);
		
		UTMap<String,Object> appInfo = assetApplicationDao.getById(id);
		if(null != appInfo){
			String title = "资产申请【"+appInfo.get("title")+"/"+appInfo.get("code")+"】驳回提醒";
			String content = "资产申请：【"+appInfo.get("title")+"/"+appInfo.get("code")+"】已被驳回，请知悉！详情请进入系统查看";
			messageService.sendMessage(String.valueOf(appInfo.get("createUserId")),title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
		
			Map<String,Object> dataParam = new HashMap<String,Object>();
			//点击待办事项，打开申请列表tab
			dataParam.put("dataType", "0");
			//生成待办任务
			userTaskService.addTaskByUserId("资产申请【"+appInfo.get("title")+"/"+appInfo.get("code")+"】已被驳回", id, "实物资产申请被驳回", TaskModel.PhysicalAssetApply, String.valueOf(appInfo.get("createUserId")),dataParam);
			
		}
	}
	
	@Override
	public void addAssetsTrack(String appId){
		UTMap<String,Object> ut = new UTMap<String,Object>();
		UTMap<String,Object> track = new UTMap<String,Object>();
		UTMap<String,Object> assets = new UTMap<String,Object>();
		ut = assetApplicationDao.getAssetIssueById(appId);
		if(null != ut){
			//====添加资产轨迹====
			track.put("assetsId", ut.get("assetsId"));
			track.put("userId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
			track.put("departId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserOrgId());
			track.put("changeRemark", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserOrgName()+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectName()+IAssetsTrackInfoDao.FIELD_ASSETSCOLLAR);
			track.put("type", 1);
			track.put("changeType","领用");
			track.put("changeTime", new Date(System.currentTimeMillis()));
			assetsTrackInfoService.add(track);
			
			//====修改资产责任人====
			assets.put("id", ut.get("assetsId"));
			assets.put("resUserId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
			assets.put("resDepartId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserOrgId());
			assetPhysicalService.updateById(assets);
			//修改资产状态为'使用中'
			assetPhysicalService.updateAssetStatusById(ut.get("assetsId").toString(), "2");
			//====如果出库为空则当前时间为出库时间====
			assetPhysicalService.updateOutdateById(String.valueOf(ut.get("assetsId")));
		}
	}
	
	private boolean updateApplication(String id,String status){
		UTMap<String,Object> ut = new UTMap<String,Object>();
		ut.put("id", id);
		ut.put("status", status);
		return assetApplicationDao.updateById(ut);
	}
	
	@Override
	public boolean updateAssetIssueStatusByAppId(String appId,
			String status) {
		return assetApplicationDao.updateAssetIssueStatusByAppId(appId, status);
	}

	@Override
	public List<UTMap<String,Object>> getIssueAssetByStatus(String assetId) {
		return assetApplicationDao.getIssueAssetByStatus(assetId);
	}

	@Override
	public List<UTMap<String, Object>> getAssetsList(Map<String, Object> param) {
		// TODO Auto-generated method stub
		return assetApplicationDao.getAssetsList(param);
	}
}