package com.esc.oms.outsource.outperson.dao.impl;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.outperson.dao.IApplyNoticeDao;
@Repository
public class ApplyNoticeDaoImpl extends BaseOptionDao implements IApplyNoticeDao{
	

	@Override
	public String getTableName() {
		return "outsourc_apply_notice_list";
	}
	
	public List<UTMap<String, Object>> getListMaps(Map param) {
		return	super.getListMaps(param, "role", ORDERTYPE.ASC, null);
	}
}
