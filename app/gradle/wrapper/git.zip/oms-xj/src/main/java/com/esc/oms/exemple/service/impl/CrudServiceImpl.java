package com.esc.oms.exemple.service.impl;

import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.exemple.dao.ICrudDao;
import com.esc.oms.exemple.service.ICrudService;
import com.esc.oms.util.TaskModel;

@Service
@Transactional
public class CrudServiceImpl extends BaseOptionService implements ICrudService{

	@Resource
	private ICrudDao crudDao;
	
	@Resource
	private IUserTaskService userTaskService;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return crudDao;
	}

	/**
	 * 添加
	 * @param info
	 * @return
	 */
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean add(Map info){
		boolean result = super.add(info);
		if(result) {
			String name = (String) info.get("name");
			if("根据功能元素".equals(name)) {
				userTaskService.addTaskByResourceUrl("根据功能元素", (String) info.get("id"), "审核", TaskModel.TestModel, "/role/defdelete");
			} else if("根据角色标识".equals(name)) {
				userTaskService.addTaskByRole("根据角色标识", (String) info.get("id"), "审核", TaskModel.TestModel, "zcgly");
			} else if("根据部门岗位".equals(name)) {
				userTaskService.addTaskByPost("根据部门岗位", (String) info.get("id"), "审核", TaskModel.TestModel, "ywcs", "ba5d67c1-f058-42cc-bd0c-7a75afb396c6");
			} else {
				userTaskService.addTaskByUserId((String) info.get("name"), (String) info.get("id"), "审核", TaskModel.TestModel, EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
			}
		}
		return result; 
	}
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		return super.getById(id);
	}
	
	/**
	 * 修改
	 * @param info
	 * @return
	 */
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean updateById(Map info){
		boolean result = super.updateById(info);
		if(result) {
			String name = (String) info.get("name");
			//先完成代办
			userTaskService.finishTask((String) info.get("id"), "审核");
			//再添加代办
			if("根据功能元素".equals(name)) {
				userTaskService.addTaskByResourceUrl("根据功能元素", (String) info.get("id"), "审核", TaskModel.TestModel, "/role/defdelete");
			} else if("根据角色标识".equals(name)) {
				userTaskService.addTaskByRole("根据角色标识", (String) info.get("id"), "审核", TaskModel.TestModel, "zcgly");
			} else if("根据部门岗位".equals(name)) {
				userTaskService.addTaskByPost("根据部门岗位", (String) info.get("id"), "审核", TaskModel.TestModel, "ywcs", "ba5d67c1-f058-42cc-bd0c-7a75afb396c6");
			} else {
				userTaskService.addTaskByUserId((String) info.get("name"), (String) info.get("id"), "审核", TaskModel.TestModel, EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
			}
		}
		return result;
	}

	/**
	 * 根据id 删除
	 * @param ids
	 * @return
	 */
	public boolean deleteById(String id){
		boolean result = super.deleteById(id);
		if(result) {
			userTaskService.finishTask(id, "审核");
			//userTaskService.finishTaskByUserId(id, "审核", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
//			userTaskService.finishTaskByResourceUrl(id, "审核", "/role/defdelete");
//			userTaskService.finishTaskByRole(id, "审核", "zcgly");
			//userTaskService.finishTaskByPost(id, "审核", "ywcs", "ba5d67c1-f058-42cc-bd0c-7a75afb396c6");
		}
		return result;
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map param) {
		crudDao.getPageInfo(pageBean, param);
	}

}
