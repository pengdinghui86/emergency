package com.esc.oms.outsource.attendance.dao;


import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 用户考勤规则配置dao接口
 * @author owner
 *
 */
public interface IUserConfigDao extends IBaseOptionDao {

	/**
	 * 根据联合考勤id删除用户考勤规则
	 * @param coalitionId
	 */
	public void deleteByCoalitionId(String coalitionId);
	
	/**
	 * 根据用户编号查询考勤规则
	 * @param userId
	 * @return
	 */
	public UTMap<String, Object> getUserConfigByUserId(String userId);

	/**
	 * 获取用户的规则等数据
	 * @param userId
	 * @return
	 */
	public UTMap<String, Object> getUserConfigInfoByUserId(String presentDate,String userId);
	
	/**
	 * 查询指定日期需要考勤的考勤规则
	 * @param date
	 * @return
	 */
	public List<UTMap<String, Object>> getAttUserConfig(Date date);
	
	/**
	 * 查询确认时间，并且考勤时间点为周一到周日的考勤规则数据
	 * @param date
	 * @return
	 */
	public List<UTMap<String, Object>> getAttUserConfigByAttendanceDate(Date date);
	
	/**
	 * 查询确认时间的考勤规则数据
	 * @param date
	 * @return
	 */
	public List<UTMap<String, Object>> getAttUserConfigByAttendanceDateType(Date date);

	/**
	 * 获取考勤规则
	 * @param params
	 * @return
	 */
	public List<UTMap<String, Object>> getUserConfigs(Map<String, Object> params);

}
