package com.esc.oms.outsource.outperson.dao;

import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

public interface IRecruitmentConfirmLevelDao extends IBaseOptionDao{

	public UTMap<String, Object> getInfoById(String id);

	public void getAlreadyPageInfo(UTPageBean pageBean, Map<String, Object> params);

}
