package com.esc.oms.outsource.emergency.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.emergency.dao.IEmergCommunDao;
import com.esc.oms.outsource.emergency.service.IEmergCommunService;
import com.esc.oms.outsource.train.service.IOutTrainService;
import com.esc.oms.supplier.commun.service.ICommunRecordService;

@Service
@Transactional
public class EmergCommunServiceImpl extends BaseOptionService implements IEmergCommunService{

	@Resource
	private IEmergCommunDao emergCommunDao;
	
	@Resource
	private ICommunRecordService communRecordService;
	
	@Resource
	private IOutTrainService outTrainService;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return emergCommunDao;
	}

	/**
	 * 添加
	 * @param info
	 * @return
	 */
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean add(Map info){
		boolean flag = false;
		info.put("createUserId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
		String communicateType = (String)info.get("communicateType");
		flag = super.add(info);
		UTMap<String,Object> ut = new UTMap<String,Object>();
		if("YJPX".equals(communicateType)){
			ut.put("name", info.get("name"));
			ut.put("teacher", info.get("lecturer"));
			ut.put("startTime", info.get("startTime"));
			ut.put("endTime", info.get("endTime"));
			ut.put("trainType", "YJPX");
			ut.put("aim", info.get("aim"));
			ut.put("participants", info.get("supplierObj"));
			ut.put("content", info.get("content"));
			ut.put("emerCommunId", info.get("id"));
			ut.put("fileIds", info.get("fileIds"));
			outTrainService.add(ut);
		}else if("YJHY".equals(communicateType)){
			ut.put("title", info.get("name"));
			ut.put("communType", info.get("HY"));
			ut.put("startTime", info.get("startTime"));
			ut.put("endTime", info.get("endTime"));
			ut.put("internalObj", info.get("internalObj"));
			ut.put("supplierObj", info.get("supplierObj"));
			ut.put("externalObj", info.get("externalObj"));
			ut.put("communContent", info.get("content"));
			ut.put("communResults", info.get("resultText"));
			ut.put("emerCommunId", info.get("id"));
			ut.put("fileIds", info.get("fileIds"));
			ut.put("communType", "HY");
			communRecordService.add(ut);
		}
		return flag;
	}
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		return super.getById(id);
	}
	

	/**
	 * 修改
	 * @param info
	 * @return
	 */
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean updateById(Map info){
		String communicateType = (String)info.get("communicateType");
		UTMap<String,Object> ut = new UTMap<String,Object>();
		UTMap<String,Object> params = new UTMap<String,Object>();
		if("YJPX".equals(communicateType)){
			ut.put("name", info.get("name"));
			ut.put("teacher", info.get("lecturer"));
			ut.put("startTime", info.get("startTime"));
			ut.put("endTime", info.get("endTime"));
			ut.put("trainType", "YJPX");
			ut.put("aim", info.get("aim"));
			ut.put("participants", info.get("internalObj"));
			ut.put("content", info.get("content"));
			ut.put("emerCommunId", info.get("id"));
			params.put("emerCommunId", info.get("id"));
			ut.put("fileIds", info.get("fileIds"));
			UTMap<String,Object> trainId = outTrainService.getIdByEmerCommunId(params);
			if(null != trainId){
				ut.put("id", trainId.get("id"));
			}
			outTrainService.updates(ut, "emerCommunId");
		}else if("YJHY".equals(communicateType)){
			ut.put("title", info.get("name"));
			ut.put("communType", info.get("HY"));
			ut.put("startTime", info.get("startTime"));
			ut.put("endTime", info.get("endTime"));
			ut.put("internalObj", info.get("internalObj"));
			ut.put("supplierObj", info.get("supplierObj"));
			ut.put("externalObj", info.get("externalObj"));
			ut.put("communContent", info.get("content"));
			ut.put("communResults", info.get("resultText"));
			ut.put("emerCommunId", info.get("id"));
			ut.put("fileIds", info.get("fileIds"));
			params.put("emerCommunId", info.get("id"));
			UTMap<String,Object> trainId = communRecordService.getIdByEmerCommunId(params);
			if(null != trainId){
				ut.put("id", trainId.get("id"));
			}
			communRecordService.updates(ut, "emerCommunId");
		}
		return super.updateById(info);
	}

	@Override
	public List<UTMap<String, Object>> getEmergCommunByNameAndId(String name,
			String id) {
		return emergCommunDao.getEmergCommunByNameAndId(name, id);
	}


}