package com.esc.oms.outsource.outperson.service.impl;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.ESCFrameEnum.ESCDataState;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.defval.DefaultValueTool;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.idgenerator.IDGenerationManager;
import org.esc.framework.security.dao.ISysRoleDao;
import org.esc.framework.security.dao.ISysUserDao;
import org.esc.framework.security.dao.ISysUserRoleDao;
import org.esc.framework.security.util.ESCSecurityEnum;
import org.esc.framework.security.util.UTMD5KL;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.attendance.service.IUserConfigService;
import com.esc.oms.outsource.outperson.dao.IApplyEnterDao;
import com.esc.oms.outsource.outperson.dao.IOutSourcePersonBlacklistDao;
import com.esc.oms.outsource.outperson.dao.IOutSourcePersonDao;
import com.esc.oms.outsource.outperson.service.IOutSourceGenerateAccountService;
import com.esc.oms.supplier.supplieremp.dao.ISupplierEmpDao;
import com.esc.oms.util.RoleUtils;

@Service
@Transactional
public class OutSourceGenerateAccountServiceImpl implements IOutSourceGenerateAccountService {
	
	protected Logger logger = LoggerFactory.getLogger(getClass());
	
	@Resource
	private ISysUserDao userDao;
	
	@Resource
	private ISysRoleDao roleDao;
	
	@Resource
	private ISupplierEmpDao empDao;
	
	@Resource
	private IOutSourcePersonDao personDao;
	
	@Resource
	private ISysUserRoleDao userRoleDao;
	
	@Resource
	private IApplyEnterDao applyEnterDao;
	
	@Resource
	private IUserConfigService userConfigService;
	
	public static final String STATUS_NOT_SUBMIT = "1";	// 未提交 待提交
	
	@Resource
	private IOutSourcePersonBlacklistDao outSourcePersonBlacklistDao;
	
	@Override
	public UTMap<String, Object> generateAccount(Map<String, Object> param) {
		// TODO Auto-generated method stub
		param.put("isIn", "1");
		String idCode = (String) param.get("idCode");
		param.put("createUserId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
		if (!param.containsKey("applyNumber")) {
			String enterApplyNumber=	IDGenerationManager.nextId("enterApplyNumber").toString();
			param.put("applyNumber",enterApplyNumber);
		}
		
		if (!param.containsKey("status")) {
			param.put("status",STATUS_NOT_SUBMIT);
		}
		if (StringUtils.isNotEmpty(idCode)) {
			//判断该人员是否已加入黑名单
			Map<String, Object> map=new HashMap<String, Object>();
			map.put("idCode", idCode);
			if(outSourcePersonBlacklistDao.isExist(map)){
				throw new EscServiceException("身份证号码为:"+idCode+"的人员，已加入黑名单，不能入场");
			}
		}
		boolean flag = applyEnterDao.add(param);
		if (!flag) {
			throw new EscServiceException("已存在该联系电话的用户/已存在该身份证号码的用户！");
		}
		String applyId = (String) param.get("id");
		return createSysSupperUser(applyId);
	}
	
	//1.信息与 用户，供应商人，外包人员同步
	private UTMap<String, Object> createSysSupperUser(String applyId){
		
 		UTMap<String, Object> applyInfo = applyEnterDao.getById(applyId);
		//获取申请单中的信息
		Map<String, String> infoMap = UTMap.mapObjToString(applyInfo);

		String code = IDGenerationManager.nextId("userNumber").toString();
		//提取基础用户信息
		String sortcode = userDao.getNewCode(ISysUserDao.FIELD_SORTCODE);
		String userName = infoMap.get("enterUserName");
		String loginName = StringUtils.isEmpty(infoMap.get("loginName")) ? code : infoMap.get("loginName");//如果没有填写登录名，就用code
		String defPwd = UTMD5KL.md5Password(loginName, "123456");
		String phone = infoMap.get("mobilePhone");
		String idCode = infoMap.get("idCode");
		String supplierId = infoMap.get("supplierId");
		String supplierName = infoMap.get("supplierName");
		String userType = ESCSecurityEnum.ESCUesrType.EPIBOLY.getValue().toString();//默认为 外包用户
		String status = ESCDataState.STARTUSING.getValue().toString();
		String roleId = roleDao.getIdBySignature(RoleUtils.COMMON_SUPPLIER_USER);
		String dingDingId = infoMap.get("dingDingId");
		
		//供应商用户信息
		String sortcode2=empDao.getNewCode(ISysUserDao.FIELD_SORTCODE);
		String isValid="1";
		String isOutSource="1";
		String isInfactory=infoMap.get("isIn");//是否入场
		if(StringUtils.equals("true",isInfactory)){
			isInfactory="1";
		}
		if(StringUtils.equals("false",isInfactory)){
			isInfactory="0";
		}
		
		//外包人员属性
		String sortcode3=personDao.getNewCode(ISysUserDao.FIELD_SORTCODE);
		String isAccess="0";
		String isAssess="1";//默认需要考核
		String isHumanRes="0"; 
		String img = infoMap.get("img");
		
		//添加用户信息
		Map<String, Object> userinfo=new HashMap<String, Object>();
		userinfo.put("name",userName);
		userinfo.put("password",defPwd);
		userinfo.put("idCode",idCode);
		userinfo.put("loginName",loginName); 
		userinfo.put("phone",phone);
		userinfo.put("supplierId",supplierId);
		userinfo.put("supplierName",supplierName);
		userinfo.put("userType",userType);
		userinfo.put("state",status);
		userinfo.put("sortCode",sortcode);
		userinfo.put("code",code);
		userinfo.put("img", img);
		userDao.add(userinfo);
		
		String userId=userinfo.get("id").toString();
		Map<String, Object> userRoleinfo =new HashMap<String, Object>();
		userRoleinfo.put(ISysUserRoleDao.FIELD_USERID,userId);
		userRoleinfo.put(ISysUserRoleDao.FIELD_ROLEID,roleId);
		userRoleDao.add(userRoleinfo);
		
		//添加供应商人员信息
		Map<String, Object> empinfo=new HashMap<String, Object>();
		empinfo.put("userId", userId);
		empinfo.put("name", userName);
		empinfo.put("userType",userType);
		empinfo.put("supplierId", supplierId);
		empinfo.put("supplierName", supplierName);
		empinfo.put("sortCode", sortcode2);
		empinfo.put("isOutSource", isOutSource);
		empinfo.put("state",status);
		empinfo.put("isInfactory", StringUtils.isEmpty(isInfactory)?0:isInfactory);
		empinfo.put("isValid", isValid);
		empinfo.put("isProofOfCrime", "0");
		empinfo.put("isSafeTrain", "0");
		empinfo.put("isVsigningAgreement", "0");
		
		empinfo.put("code",code);
		empDao.add(empinfo);
		
		//添加外包人员信息
		Map<String, Object> personinfo=new HashMap<String, Object>();
		personinfo.put("userId", userId);
		personinfo.put("name", userName);
		personinfo.put("userType",userType);
		personinfo.put("supplierId", supplierId);
		personinfo.put("sortCode", sortcode3);
		personinfo.put("isAccess", isAccess);
		personinfo.put("isAssess", isAssess);
		personinfo.put("state",status);
		personinfo.put("isHumanRes", isHumanRes);
		personinfo.put("code",code);
		personinfo.put("dingDingId", dingDingId);
		personDao.add(personinfo);
		
		//绑定用户Id
		Map<String, Object> entermap=new HashMap<String, Object>();
		entermap.put("id",applyId);
		entermap.put("enterUserId",userId);
		entermap.put("loginName", loginName);
		applyEnterDao.updateById(entermap);
		
		//生成考勤规则 attendance_user_config
		if(applyInfo.get("isIn")!=null&&(StringUtils.equals("1", applyInfo.get("isIn").toString())||StringUtils.equals("true", applyInfo.get("isIn").toString()))){
			createAttendanceUser(applyId);
		}
		
		UTMap<String, Object> returnMap = new UTMap<String, Object>();
		returnMap.put("loginName", loginName);
		returnMap.put("code", code);
		returnMap.put("password", "123456");
		return returnMap;
	}
	
	private void createAttendanceUser(String applyId){
		//获取申请单中的信息
		UTMap<String, Object> applyInfo=applyEnterDao.getById(applyId);
		//提取基础用户信息
		int attendanceCycle=1;
		int attendanceDateType=Integer.valueOf(DefaultValueTool.getValue("attendance", "attendanceDateType"));
		String attendanceDate=	DefaultValueTool.getValue("attendance", "attendanceDate");
		String supplierId=applyInfo.get("supplierId").toString();
		String userId=applyInfo.get("enterUserId").toString();
		
		String beginDate=UTDate.getNextDay(UTDate.getDate(UTDate.getCurDate(), UTDate.DATE_FORMAT));//考勤开始时间为为第二天

		String amBegin=	DefaultValueTool.getValue("attendance", "amBegin");
		String amEnd=	DefaultValueTool.getValue("attendance", "amEnd");
		String pmBegin=	DefaultValueTool.getValue("attendance", "pmBegin");
		String pmEnd=	DefaultValueTool.getValue("attendance", "pmEnd");

		//冬令时时间
		String winterAmBegin=	DefaultValueTool.getValue("attendance", "winterAmBegin");
		String winterAmEnd=	DefaultValueTool.getValue("attendance", "winterAmEnd");
		String winterPmBegin=	DefaultValueTool.getValue("attendance", "winterPmBegin");
		String winterPmEnd=	DefaultValueTool.getValue("attendance", "winterPmEnd");

		Map<String, Object> attentMap=new  HashMap<String, Object>();
		attentMap.put("attendanceCycle", attendanceCycle);
		attentMap.put("attendanceDateType", attendanceDateType);
		attentMap.put("attendanceDate", attendanceDate);
		attentMap.put("supplierId", supplierId);
		attentMap.put("userId", userId);
		attentMap.put("beginDate", beginDate);
		attentMap.put("amBegin", amBegin);
		attentMap.put("amEnd", amEnd);
		attentMap.put("pmBegin", pmBegin);
		attentMap.put("pmEnd", pmEnd);

		attentMap.put("winterAmBegin", winterAmBegin);
		attentMap.put("winterAmEnd", winterAmEnd);
		attentMap.put("winterPmBegin", winterPmBegin);
		attentMap.put("winterPmEnd", winterPmEnd);

		userConfigService.add(attentMap);
				
	}

}
