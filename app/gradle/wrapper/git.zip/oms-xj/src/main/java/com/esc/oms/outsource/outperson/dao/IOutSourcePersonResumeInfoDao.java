package com.esc.oms.outsource.outperson.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

/**
 * 简历基本信息
 * @author djj
 * @date   2016-07-18
 */
public interface IOutSourcePersonResumeInfoDao extends IBaseOptionDao {
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_CODE= "code";
	public static final String  FIELD_NAME = "name";
	public static final String  FIELD_SUPPLIER_ID = "supplierId";
	public static final String  FIELD_SUPPLIER_NAME = "supplierName";
	public static final String  FIELD_ID_CODE = "idCode";
	public static final String  FIELD_SEX = "sex";
	public static final String  FIELD_AGE = "age";
	public static final String  FIELD_BIRTHDAY = "birthday";
	public static final String  FIELD_NATION = "nation";
	public static final String  FIELD_NATIVE_PLACE = "nativePlace";
	public static final String  FIELD_ISMARRIAGE = "ismarriage";
	public static final String  FIELD_EDUCATIONAL_BACKGROUND = "educationalBackground";
	public static final String  FIELD_FINISH_SCHOOL_DATE = "finishSchoolDate";
	public static final String  FIELD_SENIORITY = "seniority";
	public static final String  FIELD_PHONE = "phone";
	public static final String  FIELD_FIXED_PHONE = "fixedPhone";
	public static final String  FIELD_EMAIL = "email";
	public static final String  FIELD_QQ = "qq";
	public static final String  FIELD_TECHNICAL_FIELD = "technicalField";
	public static final String  FIELD_SPECIALITY = "speciality";
	
	public List<UTMap<String, Object>> getPageList(UTPageBean pageBean,Map params);
	/**
	 * 待推荐列表
	 * @param param
	 * @return
	 */
	public List<UTMap<String, Object>> getRecommendResumeList(Map<String, Object> param);
}
