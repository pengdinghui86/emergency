package com.esc.oms.outsource.emergency.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;


public interface IEmerGroupDefineService extends IBaseOptionService{
	
	public boolean leadingin(String filePath, Map<String, Object> param) throws Exception;
	
	public boolean leadingout(List data, HttpServletRequest request,HttpServletResponse response) throws Exception;
	
	public List<UTMap<String, Object>> getGroupDefineByNameAndId(String groupName,String id);
}
