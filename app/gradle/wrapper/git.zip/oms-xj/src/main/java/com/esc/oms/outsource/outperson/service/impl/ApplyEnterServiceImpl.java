package com.esc.oms.outsource.outperson.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.ESCFrameEnum.ESCDataState;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.defval.DefaultValueTool;
import org.esc.framework.dict.dao.ISysParamDao;
import org.esc.framework.dict.util.UTParamTransform;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.idgenerator.IDGenerationManager;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.poi.tempfrom.tempoption.IFormModelData;
import org.esc.framework.security.dao.ISysRoleDao;
import org.esc.framework.security.dao.ISysUserDao;
import org.esc.framework.security.dao.ISysUserRoleDao;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.security.util.ESCSecurityEnum.ESCUesrType;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.workflow.service.IWorkflowCode;
import org.esc.framework.workflow.service.IWorkflowEngine;
import org.esc.framework.workflow.utils.bpmn.FlowForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.attendance.service.IUserConfigService;
import com.esc.oms.outsource.outperson.dao.IApplyEnterDao;
import com.esc.oms.outsource.outperson.dao.IApplyQuitDao;
import com.esc.oms.outsource.outperson.dao.IOutSourcePersonBlacklistDao;
import com.esc.oms.outsource.outperson.dao.IOutSourcePersonDao;
import com.esc.oms.outsource.outperson.service.IApplyCommonService;
import com.esc.oms.outsource.outperson.service.IApplyEnterService;
import com.esc.oms.outsource.outperson.service.IApplyNoticeService;
import com.esc.oms.outsource.outperson.service.IOutSourcePersonConfigService;
import com.esc.oms.outsource.outperson.service.IPersonOptionService;
import com.esc.oms.outsource.outperson.service.IRecruitmentResumeService;
import com.esc.oms.supplier.project.dao.IProjectInfoDao;
import com.esc.oms.supplier.project.dao.IProjectResDao;
import com.esc.oms.supplier.supplieremp.dao.ISupplierEmpDao;
import com.esc.oms.supplier.supplieremp.dao.ISupplierEmpWorkrecordDao;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;
import com.esc.oms.util.FunctionEnum.WorkRecordType;
import com.esc.oms.util.RoleUtils;
import com.esc.oms.util.TaskModel;

@Service
@Transactional
public class ApplyEnterServiceImpl extends BaseOptionService implements IApplyEnterService ,IFormModelData{
	
	protected Logger logger = LoggerFactory.getLogger(getClass());
	
	@Resource
	private ISysParamDao paramDao;
	@Resource
	private IApplyEnterDao applyEnterDao;
	@Resource
	private IWorkflowEngine workflowEngine;
	@Resource
	private ISysUserDao userDao;
	@Resource
	private ISupplierEmpDao empDao;
	@Resource
	private IOutSourcePersonDao personDao;
	@Resource
	private ISysRoleDao roleDao;
	@Resource
	private ISysUserRoleDao userRoleDao;

	@Resource
	private IRecruitmentResumeService recruitmentResumeService ;
	
	@Resource
	private IUserConfigService userConfigService;
	@Resource
	private IOutSourcePersonConfigService personConfigService;
	@Resource
	private IApplyNoticeService noticeService;
	@Resource
	private IProjectResDao projectResDao;
	@Resource
	private IUserTaskService userTaskService;
	@Resource
	private ISupplierEmpWorkrecordDao workrecordDao;
	@Resource
	private MessageSend messageSend;
	@Resource
	private IProjectInfoDao projectInfoDao;
	@Resource
	private IPersonOptionService optionService;
	@Resource
	private IOutSourcePersonBlacklistDao outSourcePersonBlacklistDao;
	@Resource
	private ISysUserService userService;
	
	
	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	public static final String STATUS_NOT_SUBMIT = "1";	// 未提交 待提交
	public static final String STATUS_APPROVAL  = "2";	//待审批  
	public static final String STATUS_AUDITING = "3";	// 审批中   
	public static final String STATUS_FINISH = "4";	// 审批完成   待信息配置
	public static final String STATUS_REJECT = "5";	// 驳回
	public static final String STATUS_STOP  = "6";	// 被终止
	//public static final String STATUS_CONFIG  = "7";	// 信息配置
	public static final String STATUS_NOTICE  = "7";	// 入场通知 待通知
	public static final String STATUS_UPDATE  = "8";	// 资料完善 待完善
	public static final String STATUS_OVER  = "9";	// 完成
	
	public IBaseOptionDao getOptionDao() {
		return applyEnterDao;
	}
	public String workflowCode() {
		return IWorkflowCode.OUTSOURCE_PERSON_ENTER;
	}
	public String tempCode() {
		return "formTemp.enterApplyTemp";
	}
	//新增
	@EscOptionLog(module=SystemModule.outsourcePersonEnter, opType=ESCLogOpType.INSERT, table="outsourc_apply_enter_info",
	primaryKey="id={1.id}",option="新增外包人员入场信息：{1.enterUserName}的入场申请记录")
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean add(Map info){
		String idCode=info.get("idCode").toString();
		info.put("createUserId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
		if (!info.containsKey("applyNumber")) {
			String enterApplyNumber=	IDGenerationManager.nextId("enterApplyNumber").toString();
			info.put("applyNumber",enterApplyNumber);
		}
		
		if (!info.containsKey("status")) {
			info.put("status",STATUS_NOT_SUBMIT);
		}
		//判断该人员是否已加入黑名单
		Map<String, Object> map=new HashMap<String, Object>();
		map.put("idCode", idCode);
		if(outSourcePersonBlacklistDao.isExist(map)){
			throw new EscServiceException("身份证号码为:"+idCode+"的人员，已加入黑名单，不能入场");
		}
		//判断该人员是否已加入黑名单
		boolean flag = super.add(info);
		if (flag) {
			savePersonConfig(info);
		}
		return flag;
	}
	
	//根据id 修改
	@EscOptionLog(module=SystemModule.outsourcePersonEnter, opType=ESCLogOpType.UPDATE, table="outsourc_apply_enter_info", 
	primaryKey="id={1.id}",	option="修改外包人员入场信息：{1.enterUserName}的入场申请记录")
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean updateById(Map info) {
		String status = info.get("status") == null ? "" : info.get("status").toString();
		if (StringUtils.equals(status, STATUS_REJECT)) {
			info.put("status", STATUS_NOT_SUBMIT);
		}
		boolean flag = super.updateById(info);
		if (flag) {
			savePersonConfig(info);
		}
		return flag;
	}

	@EscOptionLog(module=SystemModule.outsourcePersonEnter, opType=ESCLogOpType.DELETE, table="outsourc_apply_enter_info", 
	primaryKey="id={1}",	option="删除外包人员入场入场申请记录")
	public boolean deleteById(String id){
		UTMap<String, Object> info = this.getById(id);
		boolean flag = applyEnterDao.deleteByIds(id);
		if (flag) {
			if (null != info && !info.isEmpty()) {
				this.deleteRelationData(info);
			}
		}
		return flag;
	}
	
	@EscOptionLog(module=SystemModule.outsourcePersonEnter, opType=ESCLogOpType.DELETES, table="outsourc_apply_enter_info", 
	primaryKey="id={1}",	option="删除外包人员入场申请记录")
	public boolean deleteByIds(String ids){
		List<UTMap<String, Object>> infos = new ArrayList<UTMap<String, Object>>();
		if (StringUtils.isNotEmpty(ids)) {
			for (String id : ids.split(",")) {
				infos.add(this.getById(id));
			}
		}
		boolean flag = applyEnterDao.deleteByIds(ids);
		if (flag && StringUtils.isNotEmpty(ids)) {
			for (UTMap<String, Object> info : infos) {
				if (null != info && !info.isEmpty()) {
					this.deleteRelationData(info);
				}
			}
		}
		return flag;
	}

	//提交
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public void submit(Map<String,Object> map) {
		map.put("status", STATUS_APPROVAL);
		boolean flog=true;
		if(map.get("id") == null){
			flog=add(map);
    	}
		else{
			flog=updateById(map);
    	}
		String recordId =map.get("id").toString();
		if (flog) {//保存成功
			//启动流程
			runInstanceId(recordId);
		}
		
	}
	
	private void savePersonConfig(Map<String, Object> map) {
		String recordId =map.get("id").toString();
		UTMap<String, Object> info = applyEnterDao.getById(recordId);
		String userId = (String) info.get("enterUserId");
		//先删除后添加
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("userId", userId);
		personConfigService.delete(param);
		
		List<Map<String, Object>> configs = (List<Map<String, Object>>) map.get("configs");
		for (int i=0;i<configs.size();i++) {
			Map<String, Object> config = configs.get(i);			
			String checkValue = config.get("select") == null ? "false" : config.get("select").toString();
			String paramValue = config.get("paramValue") == null ? "0" : config.get("paramValue").toString();
			if (StringUtils.equals("true", checkValue) || StringUtils.equals("1", paramValue)) {
				Map<String, Object> cMap = new HashMap<String, Object>();
				cMap.put("id", UUID.randomUUID().toString());
				cMap.put("userId", userId);
				cMap.put("itemName", config.get("itemName"));
				cMap.put("itemType", config.get("itemType"));
				cMap.put("openPerson", config.get("openPerson"));
				cMap.put("openDate", config.get("openDate"));
				cMap.put("paramValue", config.get("paramValue"));
				cMap.put("remark", config.get("remark"));
				cMap.put("applyRemark", config.get("applyRemark"));
				cMap.put("cancelDate", config.get("cancelDate"));
				if (StringUtils.equals("1", paramValue)) {
					cMap.put("isConfig", "1");
				}
				personConfigService.add(cMap);
			}
			
		}
	}
	
	
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		UTMap<String, Object> result = super.getById(id);
		return result;
	}
	
	// 启动流程实例设置
	private void runInstanceId(String recordId){
		//通过 指定特定供应商Id 启动流程
		UTMap<String, Object> apply = applyEnterDao.getById(recordId);
		String projectId=apply.get("projectId").toString();
		String departmentId = apply.get("departmentId").toString();
		String supplierId = apply.get("supplierId").toString();
		Map<String, Object> formMap = new HashMap<String, Object>();
		formMap.put(FlowForm.FormItemValue.TDXM, projectId);
		formMap.put(FlowForm.FormItemValue.SQDW, departmentId);
		formMap.put(FlowForm.FormItemValue.TDGYS, supplierId);
		String curUserSupplierId = EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId();
		if (StringUtils.isEmpty(curUserSupplierId)) {
			curUserSupplierId = supplierId;
		}
		formMap.put(FlowForm.FormItemValue.DFGYS, curUserSupplierId);
		String curUserDepartmentId = EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserOrgId();
		if (StringUtils.isEmpty(curUserDepartmentId)) {
			curUserDepartmentId = departmentId;
		}
		formMap.put(FlowForm.FormItemValue.SQRSZBM, curUserDepartmentId);
		String workflowInstanceId = workflowEngine.runInstance(IWorkflowCode.OUTSOURCE_PERSON_ENTER, recordId, formMap);//如果没有配置流程，则直接调用onFinish接口

		//如果配置了流程，则更新流程ID
		if(StringUtils.isNotEmpty(workflowInstanceId)){
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("id", recordId);
			map.put("processId", workflowInstanceId);
			applyEnterDao.updateById(map);
		}	
	}
	
	//审批流程驳回
	public void onReject(String recordId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("status", STATUS_REJECT);
		applyEnterDao.updateById(map);
		Map<String, Object> info = applyEnterDao.getById(recordId, "enterUserId","enterUserName");
		if(info==null||info.get("enterUserId")==null){
			return;
		}
		String userName=info.get("enterUserName").toString();
		messageSend.sendMessage(info.get("enterUserId").toString(), 
				"外包人员【"+userName+"】入场申请驳回提醒", 
				"外包人员【"+userName+"】的入场申请已被驳回，请知悉！详情请进入系统查看", MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
	
	}

	//审批流程结束
	public void onFinish(String recordId) {
		try {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("id", recordId);
			map.put("status", STATUS_FINISH);
			//绑定用户Id
			applyEnterDao.updateById(map);
			//修改申请状态
			//创建供应商用户，外包人员信息
			createSysSupperUser(recordId);

			UTMap<String, Object> applyInfo=applyEnterDao.getById(recordId);
			Map<String, String> infoMap=	UTMap.mapObjToString(applyInfo);
		
			String enterUserName = infoMap.get("enterUserName");
			String enterUserId = infoMap.get("enterUserId");
			
			Map<String, Object> cMap = new HashMap<String, Object>();
			cMap.put("userId", enterUserId);
			List<UTMap<String, Object>> configs = personConfigService.getListMaps(cMap);
			for (UTMap<String, Object> config : configs) {
				String paramValue = config.get("paramValue") == null ? "0" : config.get("paramValue").toString();
				if (StringUtils.equals(paramValue, "3")) {//虚拟桌面
					Map<String,Object> param = new HashMap<String,Object>();				
					param.put("signature", RoleUtils.VIRTUAL_DESKTOP_MANAGER);
					String taskUserIds = userService.getUserIds(param);	
					userTaskService.addTaskByUserId("人员【"+enterUserName+"】的虚拟桌面开通申请待您确认",enterUserId, "虚拟桌面资源开通确认", TaskModel.outSourcePersonEnter,taskUserIds);
					messageSend.sendMessage(taskUserIds,"虚拟桌面资源开通确认", "人员【"+enterUserName+"】的虚拟桌面开通申请待您确认，请及时进入系统进行确认！" , MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
				}else if (StringUtils.equals(paramValue, "4")) {//内网网络
					Map<String,Object> param = new HashMap<String,Object>();				
					param.put("signature", RoleUtils.NETWORK_MANAGER);
					String taskUserIds = userService.getUserIds(param);	
					userTaskService.addTaskByUserId("人员【"+enterUserName+"】的内网网络开通申请待您确认",enterUserId, "内网网络资源开通确认", TaskModel.outSourcePersonEnter,taskUserIds);
					messageSend.sendMessage(taskUserIds,"内网网络资源开通确认", "人员【"+enterUserName+"】的内网网络开通申请待您确认，请及时进入系统进行确认！" , MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
				}else if (StringUtils.equals(paramValue, "2")) {//门禁
					Map<String,Object> param = new HashMap<String,Object>();				
					param.put("signature", RoleUtils.ACCESS_CONTROL_MANAGER);
					String taskUserIds = userService.getUserIds(param);	
					userTaskService.addTaskByUserId("人员【"+enterUserName+"】的门禁开通申请待您确认",enterUserId, "门禁资源开通确认", TaskModel.outSourcePersonEnter,taskUserIds);
					messageSend.sendMessage(taskUserIds,"门禁资源开通确认", "人员【"+enterUserName+"】的门禁开通申请待您确认，请及时进入系统进行确认！" , MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
				}else if (StringUtils.equals(paramValue, "5")) {//外网网络
					Map<String,Object> param = new HashMap<String,Object>();				
					param.put("signature", RoleUtils.NETWORK_MANAGER);
					String taskUserIds = userService.getUserIds(param);	
					userTaskService.addTaskByUserId("人员【"+enterUserName+"】的外网网络开通申请待您确认",enterUserId, "外网网络源开通确认", TaskModel.outSourcePersonEnter,taskUserIds);
					messageSend.sendMessage(taskUserIds,"外网网络资源开通确认", "人员【"+enterUserName+"】的外网网络开通申请待您确认，请及时进入系统进行确认！" , MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
				}
			}
			//如果只配置了考勤规则，就直接完成申请发送通知
			if (null != configs && configs.size() == 1) {
				UTMap<String, Object> config = configs.get(0);
				String paramValue = config.get("paramValue") == null ? "0" : config.get("paramValue").toString();
				if (StringUtils.equals("1", paramValue)) {//只有考勤
					Map<String,Object> newApplyInfo=new HashMap<String, Object>();
					newApplyInfo.put("id", recordId);
					newApplyInfo.put("isDataPerfect", "1");
					newApplyInfo.put("status", ApplyEnterServiceImpl.STATUS_OVER);//完成
					super.updateById(newApplyInfo);
					
					sendNodice(recordId);
					Map<String , Object> arrivaInfo=new HashMap<String, Object>();
					arrivaInfo.put("supplierId", infoMap.get("supplierId"));
					arrivaInfo.put("idCode",  infoMap.get("idCode"));
					arrivaInfo.put("arrivalDate",  infoMap.get("enterDate"));
					arrivaInfo.put("projectId", infoMap.get("projectId"));
					recruitmentResumeService.updateArrival(arrivaInfo);
				}
			}
		} catch (Exception e) {
			logger.error("Exception",e);
		}
	}

	//流程终止不进行 外包人员入场信息退出状态的修改
	public void onTerminate(String recordId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("status", STATUS_STOP);
		applyEnterDao.updateById(map);
		
		Map<String, Object> info=	applyEnterDao.getById(recordId);
		if(info==null||info.get("createUserId")==null){
			return;
		}
		deleteRelationData(info);
		
		String userName=info.get("enterUserName").toString();
		messageSend.sendMessage(info.get("createUserId").toString(), 
				"外包人员【"+userName+"】入场申请终止提醒", 
				"外包人员【"+userName+"】的入场申请已被终止，请知悉！详情请进入系统查看", MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
	
	}

	private void deleteRelationData(Map<String, Object> info) {
		//清理在生成账号时生成的数据
		//删除用户数据
		Map<String, String> infoMap = UTMap.mapObjToString(info);
		String userId = infoMap.get("enterUserId");
		userService.deleteByIds(userId);
		//删除供应商用户信息
		Map<String, Object> empMap = new HashMap<String, Object>();
		empMap.put("userId", userId);
		empDao.delete(empMap);
		//删除外包人员信息
		Map<String, Object> personMap = new HashMap<String, Object>();
		personMap.put("userId", userId);
		personDao.delete(personMap);
		
		//删除考勤数据
		userConfigService.deleteByUserId(userId);
	}
	
	//审批流程 操作到某一个节点
	public void optionNode(String workflowCode, String recordId,
			String nodeName, String linkName) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("status", STATUS_AUDITING);
		applyEnterDao.updateById(map);
	}

	public void sendTask(String workflowName, String recordId,
			String nodeName, String userId) {
		Map<String, Object> map=applyEnterDao.getById(recordId, IApplyEnterDao.FIELD_ENTERUSERNAME);
		String userName=map.get( IApplyEnterDao.FIELD_ENTERUSERNAME).toString();
		//获取供应商名称
		userTaskService.addTaskByUserId("人员【"+userName+"】入场申请待您审批", recordId, nodeName, TaskModel.outSourcePersonEnter, userId);
	
	}
	


	//查询外包人员入场信息列表
	public List<UTMap<String, Object>> searchInfo(Map<String, Object> params) {
		return applyEnterDao.searchInfo(params);
	}
	
	//查询外包人员入场信息列表
	public void searchInfoPage( UTPageBean pageBean,Map<String, Object> params) {
		 applyEnterDao.searchInfoPage(pageBean, params);
	}
	
	//查询外包人员入场信息 待审列表
	public void getPendApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) {
		applyEnterDao.getPendApprovalPageInfo(pageBean, params);
	}

	//查询外包人员入场信息 已审列表
	public void getAlreadyApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) {
		applyEnterDao.getAlreadyApprovalPageInfo(pageBean, params);
	}
	
	//导出
	public void exportData(List<UTMap<String, Object>> recordList, HttpServletRequest request, HttpServletResponse response)
		throws Exception {

		UTParamTransform statusTransform = new UTParamTransform(paramDao,"personEnterStatus");
			String[] fileds = new String[] {
					IApplyEnterDao.FIELD_ENTERUSERNAME,
					IApplyEnterDao.FIELD_CREATETIME,
					IApplyEnterDao.FIELD_DEPARTMENTNAME,
					IApplyEnterDao.FIELD_SUPPLIERNAME,
					IApplyEnterDao.FIELD_PROJECTNAME,
					IApplyEnterDao.FIELD_MOBILEPHONE,
					IApplyEnterDao.FIELD_EMAIL,
					IApplyEnterDao.FIELD_ENTERDATE,
					IApplyEnterDao.FIELD_EXITDATE,
					IApplyEnterDao.FIELD_ISKEYPERSON,
					IApplyEnterDao.FIELD_ISIN,
					IApplyEnterDao.FIELD_REMARK,
					IApplyEnterDao.FIELD_STATUS
				 };
			String tamlate="excelOutTamplate.outSourcePersonEnterLeadOut";

			Map<String, Object> p=new HashMap<String, Object>();
			for (Object info : recordList) {
				Map<String, Object> map=(Map<String, Object>) info;
				//时间转换
				Object userName	=	map.get(IApplyEnterDao.FIELD_ENTERUSERNAME).toString();
				Object orgName=map.get(IApplyEnterDao.FIELD_DEPARTMENTNAME);
				
				Object ISIN=map.get(IApplyEnterDao.FIELD_ISIN);
				Object ISKEYPERSON=map.get(IApplyEnterDao.FIELD_ISKEYPERSON);
				Object ENTERDATE=map.get(IApplyEnterDao.FIELD_ENTERDATE);
				Object EXITDATE=map.get(IApplyEnterDao.FIELD_EXITDATE);
				String ENTERDATESTR=ENTERDATE!=null?UTDate.getDateStr(ENTERDATE.toString(), UTDate.DATE_FORMAT):"";
				String EXITDATESTR=EXITDATE!=null?UTDate.getDateStr(EXITDATE.toString(), UTDate.DATE_FORMAT):"";
				
				map.put(IApplyEnterDao.FIELD_ISIN, ISIN==null?"否":Integer.valueOf(ISIN.toString())==1?"是":"否");
				map.put(IApplyEnterDao.FIELD_ISKEYPERSON, ISKEYPERSON==null?'否':Integer.valueOf(ISKEYPERSON.toString())==1?"是":"否");
				String oString=orgName!=null?orgName.toString().replaceAll("!","/"):null;
				map.put(IApplyEnterDao.FIELD_ENTERDATE,CommonUtils.replaceAll(ENTERDATESTR, "-", "/"));
				map.put(IApplyEnterDao.FIELD_EXITDATE, CommonUtils.replaceAll(EXITDATESTR, "-", "/"));
				map.put(IApplyEnterDao.FIELD_DEPARTMENTNAME,oString );
				map.put(IApplyEnterDao.FIELD_ENTERUSERNAME,userName );
				map.put("createTime", CommonUtils.replaceAll((String)map.get("createTime"), "-", "/"));

				String status=map.get(IApplyQuitDao.FIELD_STATUS)!=null?map.get(IApplyQuitDao.FIELD_STATUS).toString():"1";
				String statusStr=statusTransform.value2Name(status);
				map.put("status",statusStr );
				
			}
			
			UTExcel.leadingout( fileds, recordList, tamlate, request,response);
			
	}

	//======================入场信息审核通过后 

	//1.信息与 用户，供应商人，外包人员同步
	private void createSysSupperUser(String applyId){
		//获取申请单中的信息
		UTMap<String, Object> applyInfo = applyEnterDao.getById(applyId);
		Map<String, String> infoMap = UTMap.mapObjToString(applyInfo);

		//String code = IDGenerationManager.nextId("userNumber").toString();
		//提取基础用户信息
		//String sortcode=userDao.getNewCode(ISysUserDao.FIELD_SORTCODE);
		String userName=infoMap.get("enterUserName");
		String loginName=infoMap.get("loginName");
		//String defPwd=UTMD5KL.md5Password(loginName, "1");
		String email=infoMap.get("email");
		String phone=infoMap.get("mobilePhone");
		String orgId=infoMap.get("departmentId");
		//String isMarriage="0";
		String orgName=infoMap.get("departmentName");
		String idCode=infoMap.get("idCode");
		String supplierId=infoMap.get("supplierId");
		String supplierName=infoMap.get("supplierName");
		//String userType=ESCSecurityEnum.ESCUesrType.EPIBOLY.getValue().toString();//默认为 外包用户
		String status=ESCDataState.STARTUSING.getValue().toString();
		//String roleId=roleDao.getIdBySignature(RoleUtils.COMMON_SUPPLIER_USER);
		String projectId=infoMap.get("projectId");
		String remark=infoMap.get("remark");
		//String reason=infoMap.get("reason");
		String ismarriage=infoMap.get("ismarriage");
		String sex=infoMap.get("sex");
		String dingDingId=infoMap.get("dingDingId");

		//供应商用户信息
		String sortcode2=empDao.getNewCode(ISysUserDao.FIELD_SORTCODE);
		String isValid="1";
		String inFactoryDate=infoMap.get("enterDate");
		String exitFactoryDate=infoMap.get("exitDate")==null||StringUtils.isEmpty(infoMap.get("exitDate").toString())?null:infoMap.get("exitDate").toString();
		String isInfactory=infoMap.get("isIn");//是否入场
		if(StringUtils.equals("true",isInfactory)){
			isInfactory="1";
		}
		if(StringUtils.equals("false",isInfactory)){
			isInfactory="0";
		}
		
		//外包人员属性
		String sortcode3=personDao.getNewCode(ISysUserDao.FIELD_SORTCODE);
		String isKeyPerson=infoMap.get("isKeyPerson");
		if(StringUtils.equals(isKeyPerson, "true")){
			isKeyPerson="1";
		}
		if(StringUtils.equals(isKeyPerson, "false")){
			isKeyPerson="0";
		}
		String isAccess="0";
		String isAssess="1";//默认需要考核
		String departId=orgId;
		String isHumanRes= infoMap.get("isOutSource"); 
		String img = infoMap.get("img");
		//添加用户信息
		Map<String, Object> userinfo=new HashMap<String, Object>();
		userinfo.put("name",userName);
		//userinfo.put("password",defPwd);
		userinfo.put("idCode",idCode);
		userinfo.put("loginName",loginName); 
		userinfo.put("email",email);
		userinfo.put("phone",phone);
		userinfo.put("orgId",orgId);
		userinfo.put("orgName",orgName);
		userinfo.put("supplierId",supplierId);
		userinfo.put("supplierName",supplierName);
		//userinfo.put("userType",userType);
		userinfo.put("state",status);
		//userinfo.put("sortCode",sortcode);
		//userinfo.put("code",code);
		userinfo.put("sex",sex);
		userinfo.put("ismarriage",ismarriage);
		userinfo.put("img", img);
		userinfo.put("id", infoMap.get("enterUserId"));
		userinfo.put("age", infoMap.get("age"));
		userinfo.put("nation", infoMap.get("nation"));
		userinfo.put("brithday", infoMap.get("brithday"));
		userinfo.put("educationalBackground", infoMap.get("educationalBackground"));
		userinfo.put("finishSchoolDate", infoMap.get("finishSchoolDate"));
		userinfo.put("seniority", infoMap.get("seniority"));
		userinfo.put("qq", infoMap.get("qq"));
		userinfo.put("fixedPhone", infoMap.get("fixedPhone"));
		userinfo.put("speciality", infoMap.get("speciality"));
		userinfo.put("technicalField", infoMap.get("technicalField"));
		userinfo.put("nativePlace", infoMap.get("nativePlace"));
		userDao.updateById(userinfo);

		//添加供应商人员信息
		Map<String, Object> empinfo=new HashMap<String, Object>();
		empinfo.put("userId", infoMap.get("enterUserId"));
		empinfo.put("name", userName);
		empinfo.put("supplierId", supplierId);
		empinfo.put("supplierName", supplierName);
		empinfo.put("sortCode", sortcode2);
		empinfo.put("isOutSource", infoMap.get("isOutSource"));
		empinfo.put("inFactoryDate", inFactoryDate);
		empinfo.put("exitFactoryDate", exitFactoryDate);
		empinfo.put("state",status);
		empinfo.put("isInfactory", StringUtils.isEmpty(isInfactory)?0:isInfactory);
		empinfo.put("isValid", isValid);
		empinfo.put("isProofOfCrime", infoMap.get("isProofOfCrime"));
		empinfo.put("isSafeTrain", infoMap.get("isSafeTrain"));
		empinfo.put("isVsigningAgreement", infoMap.get("isVsigningAgreement"));
		empinfo.put("startDate", inFactoryDate);
		empinfo.put("age", infoMap.get("age"));
		empinfo.put("nation", infoMap.get("nation"));
		empinfo.put("nativePlace", infoMap.get("nativePlace"));
		empinfo.put("brithday", infoMap.get("brithday"));
		empinfo.put("educationalBackground", infoMap.get("educationalBackground"));
		empinfo.put("finishSchoolDate", infoMap.get("finishSchoolDate"));
		empinfo.put("seniority", infoMap.get("seniority"));
		empinfo.put("qq", infoMap.get("qq"));
		empinfo.put("fixedPhone", infoMap.get("fixedPhone"));
		empinfo.put("speciality", infoMap.get("speciality"));
		empinfo.put("technicalField", infoMap.get("technicalField"));
		empinfo.put("weixin", infoMap.get("weixin"));
		empinfo.put("postalAddress", infoMap.get("postalAddress"));
		empinfo.put("fax", infoMap.get("fax"));
		empDao.updateBy(empinfo, "userId");
		
		//添加外包人员信息
		Map<String, Object> personinfo=new HashMap<String, Object>();
		personinfo.put("userId", infoMap.get("enterUserId"));
		personinfo.put("name", userName);
		personinfo.put("supplierId", supplierId);
		personinfo.put("sortCode", sortcode3);
		personinfo.put("isKeyPerson", isKeyPerson);
		personinfo.put("isAccess", isAccess);
		personinfo.put("isAssess", isAssess);
		personinfo.put("departId", departId);
		personinfo.put("state",status);
		personinfo.put("mainProjectId",projectId);
		personinfo.put("isHumanRes", isHumanRes);
		personinfo.put("dingDingId", dingDingId);
		personinfo.put("agreementId", infoMap.get("agreementId"));
		personinfo.put("category", infoMap.get("category"));
		personinfo.put("level", infoMap.get("level"));
		personinfo.put("monthlyFee", infoMap.get("monthlyFee"));
		personDao.updateBy(personinfo, "userId");
		
		//添加 项目人力资源
		Map<String, Object> projectPersonInfo=new HashMap<String, Object>();
		projectPersonInfo.put("projectId", projectId);
		projectPersonInfo.put("memberId", infoMap.get("enterUserId"));
		UTMap<String, Object> user = userDao.getById(infoMap.get("enterUserId"));
		projectPersonInfo.put("memberName", userName+"/"+user.get("code"));
		projectPersonInfo.put("memberPhone",phone);
		projectPersonInfo.put("memberEmail", email);
		projectPersonInfo.put("memberType", ESCUesrType.SUPPLIER.getValue());
		projectPersonInfo.put("memberOrgName", orgName.replaceAll("!", "/"));
		projectPersonInfo.put("role", "other");// 系统参数  projectRole
		projectPersonInfo.put("isKeyPosition", isKeyPerson);
		projectPersonInfo.put("beginDate", inFactoryDate);
		projectPersonInfo.put("endDate", exitFactoryDate);
		projectPersonInfo.put("status","1" );
		projectResDao.add(projectPersonInfo);
		
		String userId = infoMap.get("enterUserId");
		
		Object projectName=projectInfoDao.getById(projectId, "name").get("name");
		//添加轨迹
		String  desc="所属部门："+orgName+"，所属项目："+(projectName!=null?projectName:"");
		workrecordDao.add(userId, "外包人员入场", inFactoryDate, exitFactoryDate,  desc, remark,WorkRecordType.INFACTORY);
		Map<String, Object> up=new HashMap<String, Object>();
		up.put("id", userId);
		up.put("supplierEmpId", empinfo.get("id"));
		userDao.updateById(up);

		//审批通过后 记录 退场当天的流动率
		optionService.addPersonFlowTimingQuit(inFactoryDate, orgId, supplierId);
	}
	

	//2.为指定用户添加基础配置项
	public boolean saveConfigByUserId(Map<String, Object> param) {
		String isConfig=param.get("isConfig") == null ? "0" : param.get("isConfig").toString();
		
		if(StringUtils.isEmpty(isConfig)||StringUtils.equals(isConfig,"false")){
			param.put("isConfig",0);
		}
		else if(StringUtils.equals(isConfig,"true")){
			param.put("isConfig",1);
		}
		else{
			param.put("isConfig",isConfig);
		}
		boolean flag = personConfigService.updateById(param);
		if (flag) {
			String paramValue = param.get("paramValue").toString();
			if (StringUtils.equals("2", paramValue)) {//门禁管理员待办
				userTaskService.finishTask(param.get("userId").toString(), "门禁资源开通确认");
			}else if (StringUtils.equals("3", paramValue)) {//虚拟桌面管理员待办
				userTaskService.finishTask(param.get("userId").toString(), "虚拟桌面资源开通确认");
			}else if (StringUtils.equals("4", paramValue)) {//内网
				userTaskService.finishTask(param.get("userId").toString(), "内网网络资源开通确认");
			}else if (StringUtils.equals("5", paramValue)) {//外网
				userTaskService.finishTask(param.get("userId").toString(), "外网网络源开通确认");
			}
			
			//遍历入场申请用户的所有的资源配置是否都已经确认完毕
			boolean isComplete = true;
			Map<String, Object> cMap =new HashMap<String, Object>();
			cMap.put("userId", param.get("userId"));
			List<UTMap<String, Object>> userConfigs = personConfigService.getListMaps(param);
			if (null != userConfigs && !userConfigs.isEmpty()) {
				for (UTMap<String, Object> config : userConfigs) {
					String isConfigNum = config.get("isConfig") == null ? "0" : config.get("isConfig").toString();
					String nowParamValue = config.get("paramValue").toString();
					if (!StringUtils.equals("1", isConfigNum)
							&& !StringUtils.equals("true", isConfigNum)
							&& !StringUtils.equals("1", nowParamValue)) {
						isComplete = false;
						break;
					}
				}
			}
			if (isComplete) {
				//全部确认完毕发送入场通知
				Map<String, Object> aMap = new HashMap<String, Object>();
				aMap.put("enterUserId", param.get("userId"));
				List<UTMap<String, Object>> applys = applyEnterDao.getListMaps(aMap);
				if (null != applys && !applys.isEmpty()) {
					UTMap<String, Object> apply = applys.get(0);
					String applyId = apply.get("id").toString();
					
					Map<String,Object> applyInfo=new HashMap<String, Object>();
					applyInfo.put("id", applyId);
					applyInfo.put("isDataPerfect", "1");
					applyInfo.put("status", ApplyEnterServiceImpl.STATUS_OVER);//完成
					super.updateById(applyInfo);
					
					sendNodice(applyId);
					Map<String , Object> arrivaInfo=new HashMap<String, Object>();
					arrivaInfo.put("supplierId", apply.get("supplierId").toString() );
					arrivaInfo.put("idCode",  apply.get("idCode").toString() );
					arrivaInfo.put("arrivalDate",  apply.get("enterDate").toString() );
					arrivaInfo.put("projectId", apply.get("projectId"));
					recruitmentResumeService.updateArrival(arrivaInfo);
					
				}
			}
		}
		return flag;
	}
	
	//3.信息配置后发通知
	private void sendNodice(String applyId) {
		noticeService.sendApplyNoticeInfo(applyId, IApplyCommonService.APPLY_TYPE_ENTER);
		/*Object isDataPerfect= 	applyEnterDao.getById(applyId, "isDataPerfect").get("isDataPerfect");
		Map<String,Object> applyInfo=new HashMap<String, Object>();
		applyInfo.put("id",applyId);
		if(isDataPerfect!=null&&StringUtils.equals("1", isDataPerfect.toString())){
			applyInfo.put("status",ApplyEnterServiceImpl.STATUS_OVER);//待完善
		}else{
			applyInfo.put("status",ApplyEnterServiceImpl.STATUS_UPDATE);//待完善
		}
		super.updateById(applyInfo);*/
	}

	//3.完善信息
	public void overApply(String userId){
		Map<String,Object> applyInfo=new HashMap<String, Object>();
		applyInfo.put("enterUserId",userId);
		applyInfo.put("status",ApplyEnterServiceImpl.STATUS_OVER);
		super.updateBy(applyInfo, "enterUserId");
	}
	

	/**
	 * 添加默认考勤规则
	 * @param applyId
	 */
	private void createAttendanceUser(String applyId){
		//获取申请单中的信息
		UTMap<String, Object> applyInfo=applyEnterDao.getById(applyId);
		//提取基础用户信息
		int attendanceCycle=1;
		int attendanceDateType=Integer.valueOf(DefaultValueTool.getValue("attendance", "attendanceDateType"));
		String attendanceDate=	DefaultValueTool.getValue("attendance", "attendanceDate");
		String supplierId=applyInfo.get("supplierId").toString();
		String userId=applyInfo.get("enterUserId").toString();
		String beginDate=UTDate.getCurDate();
		String enterDate=applyInfo.get("enterDate").toString();

		 try {
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			  String cDate = format.format(new java.util.Date());
			   Date oldDate = format.parse(enterDate); //这里时间可以自己定
			   Date date = format.parse(cDate); //这里时间可以自己定
			   if(StringUtils.equals(enterDate, beginDate)  || date.after(oldDate)) //判断,如果时间在这时间之前,就执行后面操作
			   {
					beginDate=UTDate.getNextDay(UTDate.getDate(beginDate, UTDate.DATE_FORMAT));
				}else{
					beginDate=enterDate;
				}
		} catch (ParseException e) {
			logger.error("ParseException",e);
		}

//				// 若入场日期在今天之前（包括今天的）开始日期为明天
//				if(StringUtils.equals(enterDate, beginDate) || UTDate.dateCompare(enterDate, UTDate.DATE_FORMAT)){
//					System.out.println();
//					beginDate=UTDate.getNextDay(UTDate.getDate(beginDate, UTDate.DATE_FORMAT));
//				}else{
//					//开始日期为入场日期
//					beginDate=enterDate;
//				}

		String amBegin=	DefaultValueTool.getValue("attendance", "amBegin");
		String amEnd=	DefaultValueTool.getValue("attendance", "amEnd");
		String pmBegin=	DefaultValueTool.getValue("attendance", "pmBegin");
		String pmEnd=	DefaultValueTool.getValue("attendance", "pmEnd");

		//冬令时时间
		String winterAmBegin=	DefaultValueTool.getValue("attendance", "winterAmBegin");
		String winterAmEnd=	DefaultValueTool.getValue("attendance", "winterAmEnd");
		String winterPmBegin=	DefaultValueTool.getValue("attendance", "winterPmBegin");
		String winterPmEnd=	DefaultValueTool.getValue("attendance", "winterPmEnd");

		Map<String, Object> attentMap=new  HashMap<String, Object>();
		attentMap.put("attendanceCycle", attendanceCycle);
		attentMap.put("attendanceDateType", attendanceDateType);
		attentMap.put("attendanceDate", attendanceDate);
		attentMap.put("supplierId", supplierId);
		attentMap.put("userId", userId);
		attentMap.put("beginDate", beginDate);
		attentMap.put("amBegin", amBegin);
		attentMap.put("amEnd", amEnd);
		attentMap.put("pmBegin", pmBegin);
		attentMap.put("pmEnd", pmEnd);

		attentMap.put("winterAmBegin", winterAmBegin);
		attentMap.put("winterAmEnd", winterAmEnd);
		attentMap.put("winterPmBegin", winterPmBegin);
		attentMap.put("winterPmEnd", winterPmEnd);

		userConfigService.add(attentMap);
				
	}
	

	@Override
	public Map<String, Object> setModelData(String recordId) {
		Map<String, String> info=  UTMap.mapObjToString(applyEnterDao.getById(recordId));
		Map<String, Object> model= new HashMap<String, Object>();
		String enterUserName=info.get("enterUserName")!=null?info.get("enterUserName"):"";
		String idCode=info.get("idCode")!=null?info.get("idCode"):"";
		String phone=info.get("mobilePhone")!=null?info.get("mobilePhone"):"";
		String orgName=info.get("departmentName")!=null?info.get("departmentName").replaceAll("!", "/"):"";
		String exitDate=StringUtils.isNotEmpty(info.get("exitDate"))?UTDate.chinaDate(info.get("exitDate")):"";
		String enterDate=StringUtils.isNotEmpty(info.get("enterDate"))?UTDate.chinaDate(info.get("enterDate")):"";
	//	String projectName=info.get("projectName")!=null?info.get("projectName"):"";
		String suppliername=info.get("supplierName")!=null?info.get("supplierName"):""; 
		String applyNumber=info.get("applyNumber")!=null?info.get("applyNumber"):UTDate.getCurDate();
		String userId=info.get("enterUserId")!=null?info.get("enterUserId"):""; 
		String projectName="";
		String projectId=info.get("projectId")!=null?info.get("projectId"):"";
		if(StringUtils.isNotEmpty(projectId)){
			projectName=projectInfoDao.getById(projectId, "name").get("name").toString();
		}
		
		//applyNumber
	//	orgName.replaceAll("!", "/");
		boolean mj=false;
		String mjOpenDate="";
		String mjOpenPerson="";
		String mjCancelDate="";
		
		boolean wl=false;
		String wlOpenPerson="";
		String wlOpenDate="";
		
		List<UTMap<String, Object>> configs= personConfigService.getPersonConfig(userId);
		for (UTMap<String, Object> utMap : configs) {
			String itemName=utMap.get("itemName").toString();
			String openPerson=utMap.get("openPerson")!=null?utMap.get("openPerson").toString():"";
			String openDate=utMap.get("openDate")!=null&&StringUtils.isNotEmpty(utMap.get("openDate").toString())?UTDate.chinaDate(utMap.get("openDate").toString()):"";
			String cancelDate=utMap.get("cancelDate")!=null&&StringUtils.isNotEmpty(utMap.get("cancelDate").toString())?UTDate.chinaDate(utMap.get("cancelDate").toString()):"";
			boolean isConfig=false;
			if(utMap.get("isConfig")!=null&&StringUtils.equals("1",utMap.get("isConfig").toString())){
				isConfig=true;
			}
			if(utMap.get("isConfig")!=null&&StringUtils.equals("true",utMap.get("isConfig").toString())){
				isConfig=true;
			}
		//	boolean isConfig=utMap.get("isConfig")!=null&&StringUtils.equals("1",utMap.get("isConfig").toString())?true:false;
			if(itemName.indexOf("门禁")>-1){
				//获取人员配置属性
				mj=isConfig;
				if(!mj){
					continue;
				}
				mjOpenDate= openDate;
				mjOpenPerson	=openPerson;
				mjCancelDate=cancelDate;
			}
			if(itemName.indexOf("网络")>-1){
				wl=isConfig;
				if(!wl){
					continue;
				}
				wlOpenPerson=openPerson;
				wlOpenDate=openDate;
			}
		}
		//model.put(IFormModelData.TEMP_FILE_NAME, enterUserName+"入场申请单");
		
		model.put("applyNumber", applyNumber);
		model.put("enterUserName", enterUserName);
		model.put("supplierName", suppliername);
		model.put("idCode", idCode);
		model.put("projectName", projectName);
		model.put("phone", phone);
		model.put("orgName", orgName);
		model.put("enterDate", enterDate );
		model.put("exitDate", exitDate);
		//默认为false
		model.put("isIdCodeFile", false);//身份证复印件
		model.put("isVsigningAgreement", false);//签署保密承诺书
		model.put("isResume", false);//是否有个人简历
		
		//获取人员配置属性
		model.put("mj", mj);
		model.put("mjOpenDate", mjOpenDate);
		model.put("mjOpenPerson",mjOpenPerson);
		model.put("mjCancelDate", mjCancelDate);
		model.put("wl", wl);
		model.put("wlOpenPerson", wlOpenPerson);
		model.put("wlOpenDate", wlOpenDate);
		model.put("sq", false);
//  
//		model.put("projectJF", "王二小");
//		model.put("perjectYF", "王二丫");
		return model;
	}
	
	/*@Override
	public String getTDXMExecutor(String projectId, String executorValue) {
		// TODO Auto-generated method stub
		UTMap<String, Object> info = projectInfoDao.getById(projectId);
		if (null != info && !info.isEmpty()) {
			if (StringUtils.equals(executorValue, "1")) {//甲方
				return (String)info.get("aleader");
			}else if(StringUtils.equals(executorValue, "2")) {//乙方
				return (String)info.get("bleader");
			}
		}
		return null;
	}*/
	
//	
//	public Map<String, Object> setModelData(String recordId) {
//		Map<String, String> info=  UTMap.mapObjToString(applyEnterDao.getById(recordId));
//		Map<String, Object> model= new HashMap<String, Object>();
//		
//		String enterUserName=info.get("enterUserName")!=null?info.get("enterUserName"):"";
//		String idCode=info.get("idCode")!=null?info.get("idCode"):"";
//		String phone=info.get("mobilePhone")!=null?info.get("mobilePhone"):"";
//		String orgName=info.get("departmentName")!=null?info.get("departmentName"):"";
//		String exitDate=info.get("exitDate")!=null?info.get("exitDate"):"";
//		String enterDate=info.get("enterDate")!=null?info.get("enterDate"):"";
//		String projectName=info.get("projectName")!=null?info.get("projectName"):"";
//		String suppliername=info.get("suppliername")!=null?info.get("suppliername"):"";
//		
//		orgName.replaceAll("!", "/");
//		model.put("name", enterUserName);
//		model.put("phone", phone);
//		model.put("idCode", idCode);
//		model.put("sex", orgName);
//		model.put("nation", exitDate);
//		model.put("birthday", enterDate);
//		model.put("fixedPhone", projectName);
//		model.put("ismarriage ", suppliername);
//		model.put("qq", "883948928");
//		model.put("email", "skfjwkw@sw66.com");
//		model.put("javaLanguage", true);
//		model.put("userimage", "D:\\\\escoms\\\\files\\\\leading\\\\146397560324520140918110052709.jpg");
//		List<Map<String, String>> edus=new ArrayList<Map<String,String>>();
//		Map<String, String> edu1=new HashMap<String, String>();
//		edu1.put("beginDate", "2016-03-04");
//		edu1.put("endDate", "2016-03-04");
//		edu1.put("education", "你猜你猜");
//		edu1.put("school", "猜猜猜猜猜猜猜猜猜猜猜猜");
//		edu1.put("vocation", "不猜不猜不猜不猜不猜不猜不猜不猜");
//		edus.add(edu1);
//		Map<String, String> edu2=new HashMap<String, String>();
//		edu2.put("beginDate", "2016-03-07");
//		edu2.put("endDate", "2016-03-07");
//		edu2.put("education", "你好你好");
//		edu2.put("school", "好好好好好好");
//		edu2.put("vocation", "不好不好不好不好不好不好");
//		edus.add(edu2);
//		model.put("edu", edus);
//
//		List<Map<String, String>> works=new ArrayList<Map<String,String>>();
//		Map<String, String> work1=new HashMap<String, String>();
//		work1.put("beginDate", "2016-03-07");
//		work1.put("endDate", "2016-03-07");
//		work1.put("name", "你好你好");
//		work1.put("mark", "好好好好好好");
//		works.add(work1);
//		Map<String, String> work2=new HashMap<String, String>();
//		work2.put("beginDate", "2016-03-07");
//		work2.put("endDate", "2016-03-07");
//		work2.put("name", "你好你好");
//		work2.put("mark", "好好好好好好");
//		works.add(work2);
//		model.put("works", works);
//		return model;
//	}
	
//	public static void main(String[] args) {
//		System.out.println(UTDate.chinaDate("2016-10-27 00:00:00"));	
//	}
}