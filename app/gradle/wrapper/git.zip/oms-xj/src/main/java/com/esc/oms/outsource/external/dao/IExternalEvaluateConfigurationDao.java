package com.esc.oms.outsource.external.dao;

import org.esc.framework.persistence.dao.IBaseOptionDao;

/**
 * 非驻场外包评估配置
 * @author owner
 *
 */
public interface IExternalEvaluateConfigurationDao extends IBaseOptionDao{
	public static final String  FIELD_ID= "id";
	
}
