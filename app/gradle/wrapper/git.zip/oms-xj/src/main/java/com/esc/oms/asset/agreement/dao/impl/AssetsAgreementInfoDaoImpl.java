package com.esc.oms.asset.agreement.dao.impl;

import com.esc.oms.asset.agreement.dao.IAssetsAgreementInfoDao;
import com.esc.oms.util.CommonUtils;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
@Repository
public class AssetsAgreementInfoDaoImpl extends BaseOptionDao implements IAssetsAgreementInfoDao{
	
	@Override
	public String getTableName() {
		return "assets_agreement_info";
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params,false), pageBean, null);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params) {
		return super.getListBySql(getSearchSql(params,false), null);
	}

	public List<UTMap<String, Object>> getListMaps(Map param) {
		return super.getListBySql(getSearchSql(param,false), null);
	}
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params,boolean isGetById){
		StringBuilder sql = new StringBuilder();
		sql.append(" select assInfo.*,agreement.status as agreementStatus,"
				+ " agreement.beginTime,agreement.endTime,agreement.category,datediff(agreement.endTime,now()) as leftNum"
				+ " from assets_agreement_info assInfo ");
		sql.append(" left join agreement_info agreement on assInfo.agreementId=agreement.id ");
		sql.append(" where 1=1 ");
		if(params!=null && params.size()>0){		
			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
				sql.append(" and agreement.name like '%"+params.get("name").toString().trim()+"%' ");
			}
			if(params.get("code")!=null &&  StringUtils.isNotEmpty(params.get("code").toString())){
				sql.append(" and agreement.code like '%"+params.get("code").toString().trim()+"%' ");
			}
			if(params.get("type")!=null &&  StringUtils.isNotEmpty(params.get("type").toString())){
				sql.append(" and assInfo.type='"+params.get("type").toString().trim()+"' ");
			}
			if(params.get("agreementStatus") != null && StringUtils.isNotEmpty(params.get("agreementStatus").toString())){
				sql.append(" and agreement.status = '"+params.get("agreementStatus").toString().trim()+"' ");
			}
			if(params.get("actType") != null && StringUtils.isNotEmpty(params.get("actType").toString())){
				//确定类型，采购 维保
				sql.append(" and assInfo.type in("+CommonUtils.getSqlId((String) params.get("actType"))+") ");

			}
		}
		sql.append(" order by assInfo.createTime desc");
		return  sql.toString();
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getAgreementSearchSql(Map params){
		StringBuilder sql = new StringBuilder();
		sql.append(" select * from agreement_info agreement ");
		sql.append(" where agreement.isAssets = '1' ");//资产合同		
		if(params!=null && params.size()>0){		
			if(params.get("notExist")!=null &&  StringUtils.isNotEmpty(params.get("notExist").toString())){
				sql.append(" and agreement.id not in (select agreementId from assets_agreement_info)");
			}	
			
			if(params.get("deleteFlag")!=null &&  StringUtils.isNotEmpty(params.get("deleteFlag").toString())){
				sql.append(" and IFNULL(agreement.deleteFlag,'0') = '0' ");
			}	
			sql.append(" and (agreement.`status`<>5 and agreement.`status`<>6 )");
		}
		return  sql.toString();
	}

	@Override
	public List<UTMap<String, Object>> getAgreementList(
			Map<String, Object> params) {
		return super.getListBySql(getAgreementSearchSql(params), null);
	}

	@Override
	public List<UTMap<String, Object>> getWarnAgreementList() {
		StringBuilder sql = new StringBuilder();
		sql.append(" select assInfo.*,agreement.status as agreementStatus,"
				+ " agreement.beginTime,agreement.endTime,datediff(agreement.endTime,now()) as leftNum"
				+ " from assets_agreement_info assInfo ");
		sql.append(" left join agreement_info agreement on assInfo.agreementId=agreement.id ");
		sql.append(" where assInfo.isWarn = '1' ");
		sql.append(" and agreement.status != '7' "); //合同未关闭
		sql.append(" order by assInfo.createTime desc");
		return super.getListBySql(sql.toString(), null);
	}

	@Override
	public List<UTMap<String, Object>> getListByIds(String ids) {
		String sql = " select * from  assets_agreement_info where id in ("+ CommonUtils.getSqlId(ids) +")";
		return this.getListBySql(sql, null);
	}
}
