package com.esc.oms.outsource.performance.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.dict.dao.ISysParamDao;
import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.upload.annotation.UploadQueryMarks;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.performance.dao.IPerformanceEvaluateUserDao;
import com.esc.oms.outsource.performance.service.IPerformanceEvaluateUserService;
import com.esc.oms.supplier.supplieremp.service.ISupplierEmpService;
import com.esc.oms.system.evaluateMatch.service.IEvaluateMatchService;
import com.esc.oms.system.evaluateSetting.dao.IEvaluateSettingDao;
import com.esc.oms.util.CommonUtils;

/**
 * 外包绩效考核
 * @author owner
 *
 */
@Service
@Transactional
public class PerformanceEvaluateUserServiceImpl extends BaseOptionService implements IPerformanceEvaluateUserService{
	
	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private IPerformanceEvaluateUserDao dao;
	
	@Resource
	private ISysParamDao paramDao;
	//用户
	@Resource
	private ISysUserService sysUserService;
	
	//系统参数
	@Resource
	private ISysParamService sysParamService;
	
	//评估结果配置
	@Resource
	private IEvaluateSettingDao evaluateSettingDao;
	
	@Resource
	private ISupplierEmpService supplierEmpService;
	
	@Resource
	private IEvaluateMatchService evalateMatchService;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return dao;
	}

	
	/**
	 * @param paramType 参数类型
	 * @param data 参数值
	 * @return 参数名称
	 */
	private String vaule2Name(String paramType ,String data){
		if(StringUtils.isEmpty(data)){
			return null;
		}
		Map<String, String> value2NameMap = new HashMap<String, String>();
		List<UTMap<String, Object>> paramList = paramDao.getValuesByType(paramType);
		for (UTMap<String, Object> param : paramList) {
			String name = (String) param.get("name");
			String value = (String) param.get("value");
			value2NameMap.put(value, name);
		}
		return value2NameMap.get(data);
	}
	
	
	/**
	 * @param paramType 参数类型
	 * @param data 参数名称
	 * @return 参数值
	 */
	private String name2Value(String paramType ,String data){
		if(StringUtils.isEmpty(data)){
			return null;
		}
		Map<String, String> name2ValueMap = new HashMap<String, String>();
		List<UTMap<String, Object>> paramList = paramDao.getValuesByType(paramType);
		for (UTMap<String, Object> param : paramList) {
			String name = (String) param.get("name");
			String value = (String) param.get("value");
			name2ValueMap.put(name, value);
		}
		return name2ValueMap.get(data);
	}
	/**
	 * 添加
	 * @param info
	 * @return
	 */
//	@UploadAddMark//aop拦截绑定上传文件的数据关系
//	@EscOptionLog(module = SystemModule.performanceStatistics, opType = ESCLogOpType.UPDATE, table = "outsourc_performance_evaluate_user", option = "新增考核标题为{evaluateTitle}的绩效考核评估记录。")
	public boolean add(Map info){
		String performanceEvaluator = info.get("performanceEvaluator").toString();//供应商
		String year = info.get("year").toString();//年
		String unit = info.get("unit").toString();//考核单位
		String half = info.get("half")==null?"":info.get("half").toString();//半年
		String quarter = info.get("quarter")==null?"":info.get("quarter").toString();//季度
		String month = info.get("month")==null?"":info.get("month").toString();//月
		String projectInfoId = info.get("projectInfoId") == null ? "" : info.get("projectInfoId").toString();
		if(dao.isExit(performanceEvaluator,year,unit,half,quarter,month, projectInfoId)){
			UTMap<String, Object> supplier = sysUserService.getById(performanceEvaluator);
			String msg = null;
			if(StringUtils.equals("year", unit)){ //考核单位是“年”
				msg = supplier.get("name") + "在" + year + "年已经存在考核数据！";
			}
			else if(StringUtils.equals("half", unit)){ //考核单位是“半年”
				msg = supplier.get("name") + "在" + year + "年"+ vaule2Name("half",half) +"已经存在考核数据！";
			}
			else if(StringUtils.equals("quarter", unit)){ //考核单位是“季度”
				msg = supplier.get("name") + "在" + year + "年"+ vaule2Name("quarter",quarter) +"已经存在考核数据！";
			}
			else{ //考核单位是“月”
				msg = supplier.get("name") + "在" + year + "年"+ month +"月份已经存在考核数据！";
			}
			throw new EscServiceException(msg);
		}
		info.put("submitTime", UTDate.getCurDateTime());//提交时间
		info.put("submitter", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());//提交人
		super.add(info);
		return true;
	}
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		UTMap<String, Object> result = super.getById(id);
		Map params = new HashMap();
		params.put("performanceEvaluator", result.get("performanceEvaluator"));
		params.put("type", 2);
		params.put("isProcessUserList", true);//过程考核数据展示排序按考核名称排，列表按时间排
		params.put("performanceEvaluateConfigId", result.get("performanceEvaluateConfigId"));
		params.put("projectInfoId", result.get("projectInfoId"));
		result.put("processUserList", this.getListAll(params));
		return result;
	}
	
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	@UploadQueryMarks
	public List<UTMap<String, Object>> getListAll(Map params){
		return dao.getListAll(params);
	}
	
	/**
	 * 导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	@Override
	public void leadingout(List<UTMap<String, Object>> data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		/*String[] fileds = new String[] { 
				"performanceEvaluatorName",
				"supplierName",
				"evaluateTitle",
				"year",
				"month",
				"evaluateResult"
		};*/
		String[] fileds = new String[] { 
				"performanceEvaluatorName",
				"supplierName",
				"projectInfoName",
				"evaluateTitle",
				"year",
				"unit",
				"cycle",
				"evaluateResult",
				"evaluateNum", 
				"complianceDeduction",
				"totalNum"
		};
		String tamplate = "excelOutTamplate.performanceEvaluateStatistics";
		
		String unit = "";
		for (UTMap<String, Object> map : data) {
			unit = (String)map.get("unit");
			if(StringUtils.equals("year", unit)){ //考核单位是“年”
				map.put("cycle", "");
			}
			else if(StringUtils.equals("half", unit)){ //考核单位是“半年”
				map.put("cycle", vaule2Name("half",map.get("half").toString()));
			}
			else if(StringUtils.equals("quarter", unit)){ //考核单位是“季度”
				map.put("cycle", vaule2Name("quarter",map.get("quarter").toString()));
			}
			else{ //考核单位是“月”
				map.put("cycle", map.get("month")+"月份");
			}
		}
		
		//替换下拉的值
		Map<String, String> fieldAndParamType = new HashMap<String, String>();
//		fieldAndParamType.put("evaluateResult", "performanceResult");
		fieldAndParamType.put("unit", "examUnit");
		sysParamService.changeParamData(data, fieldAndParamType);
		
		UTExcel.leadingout(fileds, data, tamplate, request, response);
	}
	
	/**
	 * 从excel中导入数据
	 * @param filePath
	 * @param param
	 * @return
	 */
	@Override
	public void leadingin(String filePath, Map<String, Object> param) throws Exception {
		List<UTMap<String, Object>> leadinginList = new ArrayList<UTMap<String,Object>>();
		// 根据路径 获取工作薄
		Sheet sheet = UTExcel.getSheets(filePath)[0];
		// 导入顺序
		String[] fileds = new String[] { 
				"performanceEvaluator",
				"year",
				"unit",
				"cycle",
				"evaluateTitle",
				"evaluateResult",
				"projectInfoId",
				"complianceDeduction",
				"deductionDesc"
		};
		String[] cellArray = new String[] { 
				"姓名*", 
				"考核年份*", 
				"考核单位*", 
				"考核周期", 
				"考核标题*（长度：0-20）", 
				"考核得分*（格式：数字0-100，最多俩位小数）",
				"所属项目*",
				"合规扣分*",
				"扣分项说明（长度：0-100）"
		};
		int[] lengthArr = {0, 0, 0, 0, 20, 0, 0, 0, 100};
		int rowNum = sheet.getLastRowNum();
		int cellNum = fileds.length;
		
		if(!UTExcel.excelValidateByCell(sheet, cellArray, fileds)) {
			throw new EscServiceException("导入失败，请选择正确的模板！");
		}		
		
		Map<String,Object> userParam = new HashMap<String,Object>();
		userParam.put("state", "1");
		userParam.put("userType", "2");//查询乙方人员,用户类型（1内部，2供应商，3外包）
		List<UTMap<String,Object>> userMap = sysUserService.getUserBaseInfo(userParam);
		StringBuilder error = new StringBuilder();
		// 从excel第1行开始添加 数据，全部保存
		for (int i = 1; i <= rowNum; i++) {
			// 遍历excel
			Row row = sheet.getRow(i);
			UTMap<String, Object> map = new UTMap<String, Object>();
			for (int j = 0; j < cellNum; j++) {
				String cellvalue = null;
				Cell cell = row.getCell(j);
				if (cell != null) {
					cell.setCellType(Cell.CELL_TYPE_STRING);
					cellvalue = cell.getStringCellValue();
					cellvalue = StringUtils.isEmpty(cellvalue) ? null : cellvalue.trim();
				}
				//检查为空的字段
				if(j == 0 || j == 1 || j == 2 || j == 4 || j == 5 || j == 6 || j == 7) {  //不能为空
					if (StringUtils.isEmpty(cellvalue)) {
						error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "内容为空，请检查！" + "<br>");
					}
				}else{  //可以为空
					cellvalue = StringUtils.isEmpty(cellvalue) ? null : cellvalue;
				}
				if (cellvalue != null) {
					//长度校验
					if (lengthArr[j] != 0 && cellvalue.length() > lengthArr[j]){
						error.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "内容长度超出限制，请检查！" + "<br>");
					}
					//转换姓名
					if(j==0 && cellvalue != null){		
						cellvalue = cellvalue.replaceAll("，", ",");
						try{
							cellvalue = CommonUtils.getIdByUserNameAndCode(userMap, cellvalue, null);
						}catch(EscServiceException ex){
							error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "列，"+ex.getMessage() + "<br>");
						}
						map.put(fileds[j], cellvalue);
					}else if(j==1 && cellvalue != null){ //考核年份
						try {
							Integer.parseInt(cellvalue);
						} catch (NumberFormatException e) {
							error.append("Excel内容错误，行号为" + (i+1) + "的" + cellArray[j] + "列" + "<br>");
						}
						map.put(fileds[j], cellvalue);
					}else if(j==2){ //考核单位
						String unit = name2Value("examUnit",cellvalue);
						if(StringUtils.isEmpty(unit)){
							error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "列，系统不存在参数【"+cellvalue+"】！" + "<br>");
						}
						map.put(fileds[j], unit);
					}else if(j==4){ //考核标题
						map.put(fileds[j], cellvalue);
					}else if (j == 5){ //考核结果
						map.put(fileds[j], cellvalue);
					}else if (j == 6) {//所属项目
						String performanceEvaluator = (String) map.get("performanceEvaluator");
						String projectInfoName = cellvalue;
						if (StringUtils.isNotEmpty(performanceEvaluator)) {
							List<UTMap<String, Object>> projectInfos = supplierEmpService.getProjectInfoByUserId(performanceEvaluator);
							if (null == projectInfos || projectInfos.isEmpty()) {
								error.append("Excel内容错误，行号为" + (i+1) + "的用户不在项目中，请检查！" + "<br>");
							}else {
								boolean isExist = false;
								for (UTMap<String, Object> project : projectInfos) {
									if (StringUtils.equals(cellvalue, (String)project.get("name"))) {
										cellvalue = (String) project.get("id");
										isExist = true;
									}
								}
								if (!isExist) {
									error.append("Excel内容错误，行号为" + (i+1) + "的用户不在项目【"+projectInfoName+"】中，请检查！" + "<br>");
								}
							}
						}
						map.put(fileds[j], cellvalue);
					}else if (j == 7) {
						map.put(fileds[j], cellvalue);
					}
				}
				if(j==3){ //考核周期
					String unit = (String)map.get("unit");
					if(StringUtils.equals("year", unit)){ //考核单位是“年”
					}
					else if(StringUtils.equals("half", unit)){ //考核单位是“半年”
						if (StringUtils.isEmpty(cellvalue)) {
							error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "内容为空，请检查！" + "<br>");
						}
						String half = name2Value("half",cellvalue);
						if(StringUtils.isEmpty(half)){
							error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "列，系统不存在参数【"+cellvalue+"】！" + "<br>");
						}
						map.put("half", half);
					}
					else if(StringUtils.equals("quarter", unit)){ //考核单位是“季度”
						if (StringUtils.isEmpty(cellvalue)) {
							error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "内容为空，请检查！" + "<br>");
						}
						String quarter = name2Value("quarter",cellvalue);
						if(StringUtils.isEmpty(quarter)){
							error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "列，系统不存在参数【"+cellvalue+"】！" + "<br>");
						}
						map.put("quarter", quarter);
					}
					else{ //考核单位是“月”
						if (StringUtils.isEmpty(cellvalue)) {
							error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "内容为空，请检查！" + "<br>");
						}else {
							if (!StringUtils.equals("1", cellvalue)
									&& !StringUtils.equals("2", cellvalue)
									&& !StringUtils.equals("3", cellvalue)
									&& !StringUtils.equals("4", cellvalue)
									&& !StringUtils.equals("5", cellvalue)
									&& !StringUtils.equals("6", cellvalue)
									&& !StringUtils.equals("7", cellvalue)
									&& !StringUtils.equals("8", cellvalue)
									&& !StringUtils.equals("9", cellvalue)
									&& !StringUtils.equals("10", cellvalue)
									&& !StringUtils.equals("11", cellvalue)
									&& !StringUtils.equals("12", cellvalue)) {
								error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "内容格式错误，请检查！" + "<br>");
							}
						}
						map.put("month", cellvalue);
					}
				}
				
				if (j == 8) {
					String complianceDeduction = (String) map.get("complianceDeduction");
					if (StringUtils.isNotEmpty(complianceDeduction) && !StringUtils.equals("0", complianceDeduction) && StringUtils.isEmpty(cellvalue)) {
						error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "内容不能为空，请检查！" + "<br>");
					}
					map.put(fileds[j], cellvalue);
				}
			}			
			map.put("importSort", i);
			leadinginList.add(map);
		}
		/*//替换下拉的值
		UTMap<String, Object> setting = evaluateSettingDao.getById("1");
		//判断评估结果的填报方式是下拉还是文本输入
		List<String> resultList = evaluateMatchService.getResults("person"); //获取结果参数集合
		*/
		//保存到数据库
		for (int i = 0; i < leadinginList.size(); i ++){
			UTMap leadingOne = leadinginList.get(i);
			String evaluateResult = leadingOne.get("evaluateResult") == null ? "0" : leadingOne.get("evaluateResult").toString();
			float score = CommonUtils.convert2Float(evaluateResult.toString()); 
			String evaluateNum = evalateMatchService.getResult(score, "person");
			evaluateNum = evaluateNum == null ? "0" : evaluateNum;
			String complianceDeduction = leadingOne.get("complianceDeduction") == null ? "0" : leadingOne.get("complianceDeduction").toString();
			float totalNum = CommonUtils.convert2Float(evaluateNum) - CommonUtils.convert2Float(complianceDeduction);
			if (totalNum < 0f) {
				totalNum = 0f;
			}
			leadingOne.put("evaluateNum", evaluateNum);
			leadingOne.put("totalNum", totalNum);
			/*//判断评估结果的填报方式是下拉还是文本输入
			if(setting != null && "1".equals(setting.get("humanPerformanceResult").toString())){
				if(!resultList.contains((String) leadingOne.get("evaluateResult"))){
					error.append("Excel内容错误，行号为" + (i + 2) + "的考核结果参数在系统中不存在，请检查！" + "<br>");
				}
			}*/
		}
		if (StringUtils.isNotEmpty(error.toString())) {
			throw new EscServiceException(error.toString());
		}
		for (int i = 0; i < leadinginList.size(); i ++){
			UTMap leadingOne = leadinginList.get(i);
			leadingOne.put("dataType", 2);//数据类型（1：评估配置的数据，2：新增的数据）
			leadingOne.put("type", 1);//评估数据类型。1：结果评估，2：过程评估
			//往数据库插入一条数据
			add(leadingOne);
		}
	}
	
	@Resource
	private IEvaluateMatchService evaluateMatchService;

	@Override
	public List<UTMap<String, Object>> getAvgEvaluateResult(String performanceEvaluateConfigId,
			String performanceEvaluator, String projectInfoId) {
		// TODO Auto-generated method stub
		return dao.getAvgEvaluateResult(performanceEvaluateConfigId, performanceEvaluator, projectInfoId);
	}

}
