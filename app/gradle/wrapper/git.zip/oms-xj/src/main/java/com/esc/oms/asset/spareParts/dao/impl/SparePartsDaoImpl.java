package com.esc.oms.asset.spareParts.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.asset.spareParts.dao.ISparePartsDao;
@Repository
public class SparePartsDaoImpl extends BaseOptionDao implements ISparePartsDao{
	

	@Override
	public String getTableName() {
		return "assets_material_backup_info";
	}
	
	@Override
	public List<UTMap<String, Object>> getListMaps(Map param) {
		return super.getListBySql(getSearchSql(param));
	}
	
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params), pageBean, null);
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT tb.id,tb.beyondRes,tb.beyondResCount,tb.beyondResState,tb.`code`,tb.endDate,tb.localRes,tb.localResCount, " );
		sql.append(" tb.localResState,tb.model,tb.`name`,tb.offTheShelf,tb.readyRequest,sbi.`name` supplier,tb.type,tb.useType from " );
		sql.append(getTableName());
		sql.append(" tb LEFT JOIN supplier_base_info sbi ON sbi.id = tb.supplier ");
		sql.append(" where 1=1 ");
		if(params!=null && params.size()>0){
			//这两个是为了查询到期的备件
			String afterEndDate = (String) params.get("afterEndDate");
			String useType = (String) params.get("useType");
			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
				sql.append(" and tb.name like '%"+params.get("name").toString().trim()+"%' ");
			}
			if(params.get("supplier")!=null && StringUtils.isNotEmpty(params.get("supplier").toString())){
				sql.append(" and sbi.name like '%"+params.get("supplier").toString().trim()+"%' ");
			}
			if(StringUtils.isNotEmpty(afterEndDate)) {
				sql.append(" and tb.endDate <= '").append(afterEndDate).append("' ");
			}
			if(StringUtils.isNotEmpty(useType)) {
				sql.append(" and find_in_set(tb.useType,'").append(useType).append("') ");
			}
		}
		sql.append(" order by tb.createTime desc");
		return  sql.toString();
	}


	@Override
	public List<UTMap<String, Object>> getSparePartsByNameAndId(String name,
			String id) {
		String sql = "SELECT * FROM "+getTableName()+" tb WHERE tb.name = '"+name+"' AND tb.id != '"+id+"'";
		return super.getListBySql(sql);
	}
	
	private String getSparePartsByIdsSql(String ids){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT tb.id,tb.beyondRes,tb.beyondResCount,tb.beyondResState,tb.`code`,tb.endDate,tb.localRes,tb.localResCount, " );
		sql.append(" tb.localResState,tb.model,tb.`name`,tb.offTheShelf,tb.readyRequest,sbi.`name` supplier,tb.type,tb.useType from " );
		sql.append(getTableName());
		sql.append(" tb LEFT JOIN supplier_base_info sbi ON sbi.id = tb.supplier ");
		sql.append(" where tb.id in ('"+ids+"')");
		return  sql.toString();
	}


	@Override
	public List<UTMap<String, Object>> getSparePartsByIds(String ids) {
		return super.getListBySql(getSparePartsByIdsSql(ids));
	}

	@Override
	public List<UTMap<String, Object>> getSparePartByEndDateAndStatus() {
		String sql = "SELECT id FROM "+getTableName()+" tb WHERE tb.endDate <= date_format(now(),'%Y-%m-%d') AND tb.useType in ('WSY','YSY')";
		return super.getListBySql(sql);
	}
}
