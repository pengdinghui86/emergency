package com.esc.oms.outsource.outperson.service;

import java.util.List;
import java.util.Map;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;


public interface IRecruitmentResumeService extends IBaseOptionService{
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params);
	/**
	 * 根据父表的条件查询，即根据领用记录查领用详单
	 * @param params
	 * @return
	 */
	public List<UTMap<String, Object>> getListAllByParentParam(Map params);
	/**
	 * 根据需求详情id删除
	 * @param detailId
	 * @return
	 */
	public boolean deleteByDetailId(String detailId);
	/**
	 * 管理员简历筛选
	 * @param info
	 * @return
	 */
	public boolean managerScreen(Map<String, Object> info);
	/**
	 * 申请人简历筛选
	 * @param info
	 * @return
	 */
	public boolean applyUserScreen(Map<String, Object> info);
	/**
	 * 面试结果
	 * @param info
	 */
	public void interview(Map<String, Object> info);
	/**
	 * 更新到岗信息
	 * @param info
	 */
	public void updateArrival(Map<String, Object> info);
	
	public List<UTMap<String, Object>> getInterviewByInfo(Map<String, Object> info);
	
	public boolean addInterview(Map<String, Object> info);
	
	public boolean removeInterview(String id);
	
	public void getPageInfoForInterview(UTPageBean pageBean, Map<String, Object> params);
	
	public boolean updateGradeResult(Map<String, Object> info);
	
	public UTMap<String, Object> getInterviewById(String id);
	
	public void updateInterview(UTMap<String, Object> item);
	
}


