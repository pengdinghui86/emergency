package com.esc.oms.outsource.outperson.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.outperson.dao.IApplyQuitDao;
import com.esc.oms.util.RoleUtils;
@Repository
public class ApplyQuitDaoImpl extends BaseOptionDao implements IApplyQuitDao{
	

	@Override
	public String getTableName() {
		return "outsourc_apply_quit_info";
	}
	
	public boolean isExist(Map param){
		StringBuilder sqlcount = new StringBuilder();
		sqlcount.append("select tb.*  from outsourc_apply_quit_info  tb  where 1=1   ");
		for (Object key : param.keySet()) {
			sqlcount.append(" and  tb." + key.toString() + "= '" + param.get(key) + "' ");
		}
		sqlcount.append(" and tb.status <>6 ");
		List<UTMap<String, Object>> list = super.getListBySql(sqlcount.toString(), null);
		Integer count = list == null ? 0 : list.size();
		/*SQLQuery sqlQuery = this.getSession().createSQLQuery(
				sqlcount.toString());
		this.setParamsToSql(sqlQuery, param);
		Object object=sqlQuery.uniqueResult();
		Integer count = object!=null?Integer.valueOf(object.toString()):null;*/
		return count>0;
	}

	public UTMap<String, Object> getById(String id){
		StringBuilder sql=new StringBuilder();
		//sql.append(" select sq.*,sbi.name supplierName from outsourc_apply_quit_info sq  join supplier_base_info sbi  on sq.supplierId=sbi.id where sq.id='"+id+"'   ");
		sql.append(" select sq.*,sbi.name supplierName,REPLACE( u.orgName,'!','/') departmentName ,u.code userCode,u.phone,u.idCode  from outsourc_apply_quit_info sq  ");
		sql.append(" join supplier_base_info sbi  on sq.supplierId=sbi.id  ");
		sql.append(" left join sys_user u on u.id=sq.quitUserId where sq.id='"+id+"'  ");
		
		UTMap<String, Object> info= super.getOneBySql( sql.toString(),null);
		Object userIdObject=info.get(FIELD_CONFIMUSERID);
		if(userIdObject!=null && StringUtils.isNotEmpty(userIdObject.toString())){
			Object userName=super.searchOneBySql("select u.name from sys_user u where u.id='"+userIdObject.toString()+"'",null);
			info.put(FIELD_CONFIMUSERNAME, userName);
		}
	
	
		
		return info;
	}
	
	@Override
	public List<UTMap<String, Object>> searchInfo(Map<String, Object> params) {
		return super.getListBySql(toSearchSql(params));
	}
	
	@Override
	public void searchInfoPage( UTPageBean pageBean,Map<String, Object> params) {
		getPageListMapBySql(toSearchSql(params), pageBean, null);
		//return pageBean;
	}
	
	//获取待审列表
	public void getPendApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select DISTINCT(t1.id)  as id, t2.name as supplierName,t1.remark,");
		sql.append("        t1.quitUserId as quitUserId, t1.quitUserName as quitUserName, t1.processId as workflowInstanceId,t1.processStep as processStep, ");
		sql.append("  t1.quitDate as quitDate,  t1.isNotice as isNotice, t1.isConfirm as isConfirm,  ");
		sql.append("        t1.`status` as `status`,t1.createUserId as createUserId, t1.createUser as createUser, t1.createTime as createTime,");
		sql.append(" t4.currentExecutor as auditors,t4.currentStepName, ");
		sql.append("REPLACE(  u.orgName,'!','/') departmentName,u.code userCode");
		sql.append("  from outsourc_apply_quit_info t1 ");
		sql.append("      join supplier_base_info t2 on t1.supplierId=t2.id ");
		sql.append(" left join sys_workflow_instance t4 on t1.processId=t4.id  ");
		sql.append(" left join sys_user u on u.id=t1.quitUserId ");
		//系统管理员和admin可以查看去全部数据
	//	if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR)){
			sql.append(" where  FIND_IN_SET('"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"',t4.currentExecutor)  ");
	//	}
		setSqlParam(sql, params);
		sql.append(" order by t1.createTime desc ");
		super.getPageListMapBySql(sql.toString(), pageBean, null);		
	}

	//获取已审列表
	public void getAlreadyApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select DISTINCT(t1.id)  as id, t2.name as supplierName,t1.remark,");
		sql.append("        t1.quitUserId as quitUserId, t1.quitUserName as quitUserName, t1.processId as workflowInstanceId,t1.processStep as processStep, ");
		sql.append("  t1.quitDate as quitDate,  t1.isNotice as isNotice, t1.isConfirm as isConfirm,  ");
		sql.append("        t1.`status` as `status`,t1.createUserId as createUserId, t1.createUser as createUser, t1.createTime as createTime,");
		sql.append(" t4.optionUserId as optionUserId, ");	
		sql.append("REPLACE(  u.orgName,'!','/') departmentName,u.code userCode");
		sql.append("  from outsourc_apply_quit_info t1 ");
		sql.append("      join supplier_base_info t2 on t1.supplierId=t2.id ");
		sql.append(" left join sys_workflow_audit_history t4 on t1.processId=t4.instanceId ");
		sql.append(" left join sys_user u on u.id=t1.quitUserId ");
		//系统管理员和admin可以查看去全部数据
	//	if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR)){
			sql.append(" where FIND_IN_SET('"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"',t4.optionUserId) and t4.nodeName<>'开始' " );
	//	}
		setSqlParam(sql, params);
		sql.append(" order by t1.createTime desc ");
		super.getPageListMapBySql(sql.toString(), pageBean, null);
	}

	private String toSearchSql(Map<String, Object> params) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select DISTINCT(t1.id)  as id, t2.name as supplierName,t1.remark,");
		sql.append("        t1.quitUserId as quitUserId, t1.quitUserName as quitUserName, t1.processId as workflowInstanceId,t1.processStep as processStep, ");
		sql.append("  t1.quitDate as quitDate,  t1.isNotice as isNotice, t1.isConfirm as isConfirm,  ");
		sql.append("        t1.`status` as `status`,t1.createUserId as createUserId, t1.createUser as createUser, t1.createTime as createTime,");
		sql.append("REPLACE(  u.orgName,'!','/') departmentName,u.code userCode");
		sql.append("  from outsourc_apply_quit_info t1 ");
		sql.append("      join supplier_base_info t2 on t1.supplierId=t2.id ");
		sql.append(" left join sys_user u on u.id=t1.quitUserId ");
		sql.append(" where 1= 1 ");
		setSqlParam(sql, params);
		//系统管理员和admin可以查看去全部数据
		if(EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR) || RoleUtils.isOutsourceManagerPerson()){
			
		}else
		//外包管理员管理所有数据，普通金融机构用户管理本人的申请，供应商用户管理本供应商的申请单
		if(RoleUtils.isSupplierAdministrator() || RoleUtils.isSupplierLeaders()){
			sql.append(" and t1.supplierId='"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId()+"'");
		}
		else{
			sql.append(" and t1.createUserId='"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"'");
		}
		sql.append(" order by t1.createTime desc ");
		
		return sql.toString();
	}
	
	
	private StringBuilder setSqlParam(StringBuilder sql,Map<String,Object> param){

		Map<String, String> p=UTMap.mapObjToString(param);
		String quitUserName =p.get("quitUserName");
		String status = p.get("status");
		String supplierName = p.get("supplierName");
		String nameOrCode = p.get("nameOrCode");

		String id = p.get("id");
		
	//	String applyDate = p.get("applyDate");
		if (StringUtils.isNotBlank(id)) {
			sql.append(" and t1.id = " + id);
		}
		if(StringUtils.isNotEmpty(nameOrCode) ){
			sql.append(" and  CONCAT(u.name,'/',u.code)  LIKE '%"+nameOrCode+"%'  ");
		}	
		if (StringUtils.isNotBlank(quitUserName)) {
			sql.append(" and t1.quitUserName like  '%" + quitUserName.trim()+"%'" );
		}
		
		if (StringUtils.isNotBlank(status)) {
			sql.append(" and t1.status = " + status.trim() );
		}
		
		if (StringUtils.isNotBlank(supplierName)) {
			sql.append(" and t2.name like '%" + supplierName.trim() + "%' ");
		}


		

		return sql;
	}

	@Override
	public List<UTMap<String, Object>> getUserBaseInfo(Map<String, Object> param) {
		// TODO Auto-generated method stub
		return super.getListBySql(this.getUserBaseInfoSql(param), null);
	}
	
	private String getUserBaseInfoSql(Map<String, Object> param) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT o.status, u.id, u.id AS 'userId', u.code, u.name, u.orgId, CONCAT(u.`name`, '/', u.`code`) showName, ");
		sql.append(" u.supplierName, u.supplierId, u.phone, u.fixedPhone, u.email, u.userType, u.idCode, ");
		sql.append(" ifnull(group_concat(DISTINCT r.id),'') roleIds, ");
		sql.append(" ifnull(group_concat(DISTINCT r. NAME),'') roleNames, ");
		sql.append(" ifnull(group_concat(DISTINCT r.signature),'') signature, ");
		sql.append(" REPLACE (org.longName, '!', '/') orgLongName ");
		sql.append(" FROM sys_user u");
		sql.append(" LEFT JOIN outsourc_apply_exit_info o on o.exitUserId = u.id ");
		sql.append(" LEFT JOIN sys_org org ON u.orgId = org.id ");
		sql.append(" LEFT JOIN sys_user_role ur ON ur.userId = u.id ");
		sql.append(" LEFT JOIN sys_role r ON ur.roleId = r.id ");
		sql.append(" WHERE 1=1  ");
		//sql.append(" and u.state <> 0 ");
		sql.append(" and u.supplierId='" + param.get("supplierId") + "' ");
		sql.append(" and u.userType='" + param.get("userType") + "' ");
		
		sql.append(" and o.status=8 ");//退出申请已经审批通过
		sql.append(" and o.isQuit='1' ");//是否离职：1：是，0：否
		String isAdd = (String) param.get("isAdd");
		if (StringUtils.isNotEmpty(isAdd) && StringUtils.equals("1", isAdd)) {
			sql.append(" and not exists ( select id from outsourc_apply_quit_info q where q.quitUserId=u.id) ");
		}else {
			sql.append(" and not exists ( select id from outsourc_apply_quit_info q where q.quitUserId=u.id and q.quitUserId <> '"+param.get("quitUserId")+"') ");
		}
		sql.append(" GROUP BY u.id ");
		sql.append(" ORDER BY (org. CODE + 0) ASC, u. CODE ASC ");
		return sql.toString();
	}
}
