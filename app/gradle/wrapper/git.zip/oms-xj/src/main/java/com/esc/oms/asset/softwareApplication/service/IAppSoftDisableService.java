package com.esc.oms.asset.softwareApplication.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;

public interface IAppSoftDisableService extends IBaseOptionService {

	public List<UTMap<String, Object>> getSoftDisableList(Map param);
	
	public boolean leadingout(List data, HttpServletRequest request,HttpServletResponse response) throws Exception;
}
