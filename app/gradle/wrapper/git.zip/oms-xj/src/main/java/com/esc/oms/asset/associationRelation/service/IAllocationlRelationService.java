package com.esc.oms.asset.associationRelation.service;

import java.util.Map;

import net.sf.json.JSONArray;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;


public interface IAllocationlRelationService extends IBaseOptionService{
	
	public boolean addPhysicalAssets(Map info);
	
	public boolean addSoftwareAssets(Map info);
	
	public JSONArray getJson();
	
	public UTMap<String, Object> getRelList(String assetsId);
	
	public UTMap<String,Object> getAssetsByCode(String name);
	
	public JSONArray getJsonById(String assetsId);
}
