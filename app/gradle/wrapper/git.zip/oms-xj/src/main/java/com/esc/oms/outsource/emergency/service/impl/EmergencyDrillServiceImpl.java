package com.esc.oms.outsource.emergency.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.emergency.dao.IEmergencyDrillDao;
import com.esc.oms.outsource.emergency.service.IEmergencyDrillService;
import com.esc.oms.util.CommonUtils;

@Service
@Transactional
public class EmergencyDrillServiceImpl extends BaseOptionService implements IEmergencyDrillService{

	@Resource
	private IEmergencyDrillDao emergencyDrillDao;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return emergencyDrillDao;
	}

	/**
	 * 添加
	 * @param info
	 * @return
	 */
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean add(Map info){
		info.put("createUserId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
		return super.add(info);
	}
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		return super.getById(id);
	}
	

	/**
	 * 修改
	 * @param info
	 * @return
	 */
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean updateById(Map info){
		return super.updateById(info);
	}

	/**
	 * 导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	@Override
	public boolean leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String[] fileds = new String[] { 
				IEmergencyDrillDao.FIELD_NAME,
				IEmergencyDrillDao.FIELD_STARTTIME,
				IEmergencyDrillDao.FIELD_ENDTIME,
				IEmergencyDrillDao.FIELD_AIM,
				IEmergencyDrillDao.FIELD_INTERNALOBJ,
				IEmergencyDrillDao.FIELD_SUPPLIEROBJ,
				IEmergencyDrillDao.FIELD_DRILLNAME,
				IEmergencyDrillDao.FIELD_RESULTTEXT,
				IEmergencyDrillDao.FIELD_RESULTEXPLAIN
				
		};
		if (null != data && !data.isEmpty()) {
			for (int i=0;i<data.size();i++) {
				UTMap<String, Object> item = (UTMap<String, Object>) data.get(i);
				item.put(IEmergencyDrillDao.FIELD_STARTTIME, CommonUtils.replaceAll((String)item.get(IEmergencyDrillDao.FIELD_STARTTIME), "-", "/"));
				item.put(IEmergencyDrillDao.FIELD_ENDTIME, CommonUtils.replaceAll((String)item.get(IEmergencyDrillDao.FIELD_ENDTIME), "-", "/"));
			}
		}
		String tamlate="excelOutTamplate.emergencyDrill";	
		//替换下拉的值
		return	UTExcel.leadingout( fileds, data, tamlate, request,response);
	}

	@Override
	public List<UTMap<String, Object>> getDrillByNameAndId(String name,
			String id) {
		return emergencyDrillDao.getDrillByNameAndId(name,id);
	}

}