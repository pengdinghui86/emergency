package com.esc.oms.outsource.attendance.controller;

import com.esc.oms.outsource.attendance.service.IAttendanceStatisticsTimeService;
import com.esc.oms.util.CommonUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import net.sf.json.JSONObject;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;



/**
 * 不确定时间考勤考勤统计-按工时Controller
 * @author owner
 *
 */
@Controller
@RequestMapping("attendanceStatisticsTimeController")
public class AttendanceStatisticsTimeController  extends BaseOptionController {
	
	@Resource
	private IAttendanceStatisticsTimeService attendanceStatisticsTimeService;
	
	@Override
	public IBaseOptionService optionService() {
		return attendanceStatisticsTimeService;
	}
	
	@RequestMapping(value="initDate")  
	@ResponseBody
	public String initManHourEdit() {
		try {
			attendanceStatisticsTimeService.initData();
		} catch (EscServiceException e) {
			logger.error("EscServiceException", e);
			return UTJsonUtils.getJsonMsg(false, e.getMessage());
		} catch (Exception e) {
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "生成失败");
		}
		return UTJsonUtils.getJsonMsg(true, "生成成功");
	}
	
	/**
	 * 重新统计生成上一个月的数据
	 */
	@RequestMapping(value="afreshDate")  
	@ResponseBody
	public String afreshDate() {
		try {
			attendanceStatisticsTimeService.afreshDate();
		} catch (EscServiceException e) {
			logger.error("EscServiceException", e);
			return UTJsonUtils.getJsonMsg(false, e.getMessage());
		} catch (Exception e) {
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "重新生成失败");
		}
		return UTJsonUtils.getJsonMsg(true, "重新生成成功");
	}
	
	/**
	 * 运维联合考勤统计
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getCoalitionOperations")  
    @ResponseBody
    public UTPageBean getCoalitionOperations(@RequestParam Map<String, Object> params){  
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			attendanceStatisticsTimeService.getCoalitionOperations(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	/**
	 * 导出运维联合考勤统计
	 * @param param
	 * @param utPageBean
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "leadingoutAttCoalitionOperations")
	public void leadingoutAttCoalitionOperations(@RequestParam Map<String, Object> param,
			HttpServletRequest request,
			HttpServletResponse response) {
		Map<String, Object> copym = CommonUtils.clone(param);
		UTPageBean utPageBean = CommonUtils.getPageBean(copym);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			Integer outType = Integer.parseInt((String) copym.get("outType"));
			ObjectMapper mapper = new ObjectMapper();  
			Map params = mapper.readValue(copym.get("params").toString(),Map.class);//转成map
//			Map params = UTMap.transStringToMap(param.get("params").toString());
//			JSONObject jsonBean = null;
//			if(info != null) {
//				jsonBean = JSONObject.fromObject(info);
//			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = attendanceStatisticsTimeService.getAllCoalitionOperations(params);
			} else {
				attendanceStatisticsTimeService.getCoalitionOperations(utPageBean, params);
				data = utPageBean.getRows();
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			attendanceStatisticsTimeService.leadingoutAttCoalitionOperations(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	/**
	 * 导出
	 * @param param
	 * @param utPageBean
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "leadingout")
	public void leadingout(@RequestParam Map<String, Object> param,
			HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = null;
			if(info != null) {
				jsonBean = JSONObject.fromObject(info);
			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = attendanceStatisticsTimeService.getListMaps(jsonBean);
			} else {
				attendanceStatisticsTimeService.getPageInfo(utPageBean, jsonBean);
				data = utPageBean.getRows();
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			attendanceStatisticsTimeService.leadingout(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	
	/**
	 * 运维考勤统计（供应商）
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getSupplierOperations")  
    @ResponseBody
    public UTPageBean getSupplierOperations(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			attendanceStatisticsTimeService.getSupplierOperations(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	/**
	 * 运维考勤统计（部门）
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getOrgOperations")  
    @ResponseBody
    public UTPageBean getOrgOperations(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			attendanceStatisticsTimeService.getOrgOperations(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	/**
	 * 点击异常率查询详情数据接口
	 * @param param
	 * @return
	 */
	@RequestMapping(value="getDetail")  
    @ResponseBody
    public UTPageBean getDetail(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			attendanceStatisticsTimeService.getDetail(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	/**
	 * 导出运维考勤统计（供应商）
	 * @param param
	 * @param utPageBean
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "leadingoutAttSupplierOperations")
	public void leadingoutAttSupplierOperations(@RequestParam Map<String, Object> param,
			HttpServletRequest request,
			HttpServletResponse response) {
		Map<String, Object> copym = CommonUtils.clone(param);
		UTPageBean utPageBean = CommonUtils.getPageBean(copym);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			Integer outType = Integer.parseInt((String) copym.get("outType"));
			ObjectMapper mapper = new ObjectMapper();  
			Map params = mapper.readValue(copym.get("params").toString(),Map.class);//转成map
//			Map params = UTMap.transStringToMap(param.get("params").toString());
//			JSONObject jsonBean = null;
//			if(info != null) {
//				jsonBean = JSONObject.fromObject(info);
//			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = attendanceStatisticsTimeService.getAllSupplierOperations(params);
			} else {
				attendanceStatisticsTimeService.getSupplierOperations(utPageBean, params);
				data = utPageBean.getRows();
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			attendanceStatisticsTimeService.leadingoutAttSupplierOperations(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	/**
	 * 导出运维考勤统计（部门）
	 * @param param
	 * @param utPageBean
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "leadingoutAttOrgOperations")
	public void leadingoutAttOrgOperations(@RequestParam Map<String, Object> param,
			HttpServletRequest request,
			HttpServletResponse response) {
		Map<String, Object> copym = CommonUtils.clone(param);
		UTPageBean utPageBean = CommonUtils.getPageBean(copym);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			Integer outType = Integer.parseInt((String) copym.get("outType"));
			ObjectMapper mapper = new ObjectMapper();  
			Map params = mapper.readValue(copym.get("params").toString(),Map.class);//转成map
//			Map params = UTMap.transStringToMap(param.get("params").toString());
//			JSONObject jsonBean = null;
//			if(info != null) {
//				jsonBean = JSONObject.fromObject(info);
//			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = attendanceStatisticsTimeService.getAllOrgOperations(params);
			} else {
				attendanceStatisticsTimeService.getOrgOperations(utPageBean, params);
				data = utPageBean.getRows();
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			attendanceStatisticsTimeService.leadingoutAttOrgOperations(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	/**
	 * 导出运维考勤统计详情
	 * @param param
	 * @param utPageBean
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "leadingoutAttOperationsDetail")
	public void leadingoutAttOperationsDetail(@RequestParam Map<String, Object> param, HttpServletRequest request,
			HttpServletResponse response) {
		Map<String, Object> copym = CommonUtils.clone(param);
		UTPageBean utPageBean = CommonUtils.getPageBean(copym);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			Integer outType = Integer.parseInt((String) copym.get("outType"));
			ObjectMapper mapper = new ObjectMapper();  
			Map params = mapper.readValue(copym.get("params").toString(),Map.class);//转成map
//			Map params = UTMap.transStringToMap(param.get("params").toString());
//			JSONObject jsonBean = null;
//			if(info != null) {
//				jsonBean = JSONObject.fromObject(info);
//			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = attendanceStatisticsTimeService.getDetail(params);
			} else {
				attendanceStatisticsTimeService.getDetail(utPageBean, params);
				data = utPageBean.getRows();
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			attendanceStatisticsTimeService.leadingoutAttOperationsDetail(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
}
