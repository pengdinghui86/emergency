package com.esc.oms.asset.lowvalue.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.asset.lowvalue.dao.ILowvalueApplyDao;
import com.esc.oms.asset.lowvalue.dao.ILowvalueReceptionDao;
import com.esc.oms.asset.lowvalue.dao.ILowvalueReceptionDetailDao;
import com.esc.oms.asset.lowvalue.service.ILowvalueInfoService;
import com.esc.oms.asset.lowvalue.service.ILowvalueReceptionDetailService;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;

@Service
@Transactional
public class LowvalueReceptionDetailServiceImpl extends BaseOptionService implements ILowvalueReceptionDetailService{

	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private ILowvalueReceptionDetailDao dao;
	
	@Resource
	private ILowvalueInfoService infoService;
	
	@Resource
	private ILowvalueReceptionDao receptionDao;
	
	@Resource
	private IUserTaskService userTaskService;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return dao;
	}

	/**
	 * 添加
	 * @param info
	 * @return
	 */
	@EscOptionLog(module=SystemModule.ASSETS_LOWVALUE_RECEPTION, opType=ESCLogOpType.INSERT, table="assets_lowvalue_reception_detail", primaryKey="id={1.id}",option="新增领用物品：名称：{1.name}/{1.code}")	
	public boolean add(Map info){
		String infoId = (String) info.get("infoId");
		
		Map infoMap = new HashMap<String,Object>();
		infoMap.put("id", info.get("infoId"));
		infoMap.put("status", "1");
		
		//更新待确认数量
		UTMap<String,Object> oldMap = infoService.getById(infoId);
		double oldNum = Double.parseDouble(oldMap.get("pendConfirmNum")==null?"0":oldMap.get("pendConfirmNum").toString()); //原待确认数量
		double receptNum = Double.parseDouble(info.get("receptNum")==null?"0":info.get("receptNum").toString()); //领用数量
		infoMap.put("pendConfirmNum", oldNum+receptNum);
		
		infoService.updateById(infoMap);
		
		return super.add(info);		
	}
	
	@Override
	@EscOptionLog(module=SystemModule.ASSETS_LOWVALUE_RECEPTION, opType=ESCLogOpType.UPDATE, table="assets_lowvalue_reception_detail", primaryKey="id={1.id}",option="修改领用的物品：{1.name}/{1.code}")		
	public boolean updateById(Map info){
		Map<String,Object> oldRecept = getById((String) info.get("id"));		
		//更新待确认数量			
		int oldConfirmStatus = (Integer) oldRecept.get("confirmStatus");
		if(oldConfirmStatus==-1){//驳回
			Map<String,Object> oldInfo = infoService.getById((String) info.get("infoId"));
			double receptNum = Double.parseDouble(info.get("receptNum")==null?"0":info.get("receptNum").toString()); //领用数量
			double oldNum = Double.parseDouble(oldInfo.get("pendConfirmNum")==null?"0":oldInfo.get("pendConfirmNum").toString()); //原待确认数量
			Map infoMap = new HashMap<String,Object>();	
			infoMap.put("pendConfirmNum", oldNum+receptNum);
			infoMap.put("id", oldInfo.get("id"));
			infoService.updateById(infoMap);
		}else{
			double oldReceptNum = Double.parseDouble(oldRecept.get("receptNum")==null?"0":oldRecept.get("receptNum").toString()); //原领用数量
			double receptNum = Double.parseDouble(info.get("receptNum")==null?"0":info.get("receptNum").toString()); //领用数量
			if(oldReceptNum!=receptNum){
				Map<String,Object> oldInfo = infoService.getById((String) info.get("infoId"));
				double oldNum = Double.parseDouble(oldInfo.get("pendConfirmNum")==null?"0":oldInfo.get("pendConfirmNum").toString()); //原待确认数量
				Map infoMap = new HashMap<String,Object>();	
				infoMap.put("pendConfirmNum", oldNum-oldReceptNum+receptNum);
				infoMap.put("id", oldInfo.get("id"));
				infoService.updateById(infoMap);
			}
		}
		
		return super.updateById(info);			
	}
	
	@Override
	@EscOptionLog(module=SystemModule.ASSETS_LOWVALUE_RECEPTION, opType=ESCLogOpType.DELETE, table="assets_lowvalue_reception_detail",primaryKey="{1}", option="领用物品详单中，删除物品：{name}/{code}")				
	public boolean deleteById(String id){
		Map<String,Object> oldRecept = getById(id);		
		
		int confirmStatus = oldRecept.get("confirmStatus")==null?0:Integer.parseInt(oldRecept.get("confirmStatus").toString());
		if(confirmStatus!=-1){//驳回已扣除了待确认数，不用再更新，其他情况需再更新
			//更新待确认数量			
			double oldReceptNum = Double.parseDouble(oldRecept.get("receptNum")==null?"0":oldRecept.get("receptNum").toString()); //原领用数量
			Map<String,Object> oldInfo = infoService.getById((String) oldRecept.get("infoId"));
			double oldNum = Double.parseDouble(oldInfo.get("pendConfirmNum")==null?"0":oldInfo.get("pendConfirmNum").toString()); //原待确认数量
			Map infoMap = new HashMap<String,Object>();	
			infoMap.put("pendConfirmNum", oldNum-oldReceptNum);
			infoMap.put("id", oldInfo.get("id"));
			infoService.updateById(infoMap);
		}
				
		return super.deleteById(id);			
	}
	
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map param) {
		dao.getPageInfo(pageBean, param);
	}
	
	/**
	 * 确认
	 * @param info
	 * @return
	 */
	@Override
	@EscOptionLog(module=SystemModule.ASSETS_LOWVALUE_RECEPTION, opType=ESCLogOpType.CONFIRM, table="assets_lowvalue_apply_detail", primaryKey="id={1.id}",option="物品领用记录的{name}/{code}物品发放确认")		
	public boolean confirm(Map info){
		info.put("confirmTime", UTDate.getCurDateTime());
		super.updateById(info);	
		String receptId = (String) info.get("receptId");
		
		//更新库存
		String infoId = (String) info.get("infoId");
		double receptNum = Double.parseDouble(info.get("receptNum").toString());
		double receptAmount = Double.parseDouble(info.get("receptAmount").toString());
		updateStock(infoId,receptNum,receptAmount);
		
		Map<String,Object> param = new HashMap<String,Object>();
		param.put("receptId", receptId);
		List<UTMap<String,Object>> list = this.getListMaps(param);
		boolean completeConfirm = true;
		if(list!=null&&list.size()>0){
			for(UTMap<String,Object> ut : list){
				int confirmStatus = (Integer) ut.get("confirmStatus");
				if(confirmStatus==0||confirmStatus==-1){
					completeConfirm = false;
				}
			}
		}
		if(completeConfirm){		
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("id", receptId);
			map.put("status", ILowvalueReceptionDao.STATUS_FINISH_CONFIRM);
			receptionDao.updateById(map);
			
//			//更新库存
//			for(UTMap<String,Object> ut : list){
//				String infoId = (String) ut.get("infoId");
//				double receptNum = Double.parseDouble(ut.get("receptNum").toString());
//				double receptAmount = Double.parseDouble(ut.get("receptAmount").toString());
//				updateStock(infoId,receptNum,receptAmount);
//			}
//			
			//关闭待办任务
			userTaskService.finishTask(receptId, ILowvalueReceptionDao.TASK_RECEPTION_CONFIRM);
			
		}else{
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("id", receptId);
			map.put("status", ILowvalueReceptionDao.STATUS_CONFIRMING);
			receptionDao.updateById(map);
		}
		return true;
	}
	
	/**
	 * 驳回
	 * @param info
	 * @return
	 */
	@Override
	@EscOptionLog(module=SystemModule.ASSETS_LOWVALUE_RECEPTION, opType=ESCLogOpType.REJECT, table="assets_lowvalue_apply_detail", primaryKey="id={1.id}",option="物品领用记录的{name}/{code}物品领用驳回")		
	public boolean reject(Map info){
		info.put("confirmTime", UTDate.getCurDateTime());
		super.updateById(info);	
		String receptId = (String) info.get("receptId");		
		Map<String,Object> param = new HashMap<String,Object>();
		param.put("receptId", receptId);		
	
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("id", receptId);
		map.put("status", ILowvalueReceptionDao.STATUS_CONFIRMING);
		receptionDao.updateById(map);
		
		//更新待确认数
		String infoId = (String) info.get("infoId");
		double receptNum = Double.parseDouble(info.get("receptNum")==null?"0":info.get("receptNum").toString());  //发放数
		double oldPendConfirmNum = Double.parseDouble(info.get("pendConfirmNum")==null?"0":info.get("pendConfirmNum").toString());  //待确认数
		double newPendConfirmNum = oldPendConfirmNum-receptNum;  //待确认数
		Map<String,Object> infoMap = new HashMap<String,Object>();
		infoMap.put("id", infoId);
		infoMap.put("pendConfirmNum", newPendConfirmNum);
		infoService.updateById(infoMap);			
		
		return true;
	}
	
	//更新库存
	private void updateStock(String infoId,double receptNum,double receptAmount){
		Map<String,Object> infoMap = infoService.getById(infoId);
		double oldNum = Double.parseDouble(infoMap.get("totalNum")==null?"0":infoMap.get("totalNum").toString()); //总数量
		double oldAmount = Double.parseDouble(infoMap.get("amount")==null?"0":infoMap.get("amount").toString()); //总价
		double oldStockNum = Double.parseDouble(infoMap.get("stockNum")==null?"0":infoMap.get("stockNum").toString()); //库存数量
		double oldStockAmount = Double.parseDouble(infoMap.get("stockAmount")==null?"0":infoMap.get("stockAmount").toString());  //库存总价
		double oldPendConfirmNum = Double.parseDouble(infoMap.get("pendConfirmNum")==null?"0":infoMap.get("pendConfirmNum").toString());  //库存总价
				
		double totalNum = oldNum;
		double amount = oldAmount;
		double stockNum = oldStockNum-receptNum;
		double stockAmount = oldStockAmount-receptAmount;
		double consumeNum = totalNum-stockNum;
		double consumeAmount = amount-stockAmount;
		double pendConfirmNum = oldPendConfirmNum-receptNum;
		
		infoMap.put("totalNum", totalNum);
		infoMap.put("amount", amount);
		infoMap.put("stockNum", stockNum);
		infoMap.put("stockAmount", stockAmount);
		infoMap.put("consumeNum", consumeNum);
		infoMap.put("consumeAmount", consumeAmount);
		infoMap.put("pendConfirmNum", pendConfirmNum);
		
		infoService.updateById(infoMap);
	}
	
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params){
		return dao.getListAll(params);
	}
	
	/**
	 * 根据领用记录的条件查询领用详单
	 * @param params
	 */
	@Override
	public List<UTMap<String, Object>> getListAllByParentParam(Map params){
		return dao.getListAllByParentParam(params);
	}
	
	/**
	 * 根据领用记录id（receptId）删除
	 * @param infoId
	 * @return
	 */
	@Override
	public boolean deleteByReceptId(String receptId){
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("receptId", receptId);
		
		//不能批量删除，因为要更新待确认数量
		List<UTMap<String, Object>> detailList = dao.getListMaps(map);
		if(detailList!=null){
			for(UTMap<String, Object> detailMap:detailList){
				String id = detailMap.get("id").toString();
				deleteById(id);
			}
		}
//		return dao.deletes(map);
		return true;
	}
	

}