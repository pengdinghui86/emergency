package com.esc.oms.outsource.attendance.dao;

import org.esc.framework.persistence.dao.IBaseOptionDao;

import java.util.Map;

public interface IAttendanceSeasonConfigDao extends IBaseOptionDao {

    /**
     * 是否存在月份
     * @param year
     * @return
     */
    public boolean isExistYear(Map<String, Object> params);
}
