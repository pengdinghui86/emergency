package com.esc.oms.asset.spareParts.service;

import java.util.List;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;


public interface ISparePartsService extends IBaseOptionService{
	
	public List<UTMap<String, Object>> getSparePartsByNameAndId(String name,String id);
	
	public List<UTMap<String, Object>> getSparePartsByIds(String ids);
	
	public void monitorSparePartsOverTime();
}
