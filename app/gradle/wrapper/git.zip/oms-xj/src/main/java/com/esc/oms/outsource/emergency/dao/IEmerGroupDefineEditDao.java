package com.esc.oms.outsource.emergency.dao;

import java.util.List;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

public interface IEmerGroupDefineEditDao extends IBaseOptionDao{
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_GROUPNAME = "groupName";
	public static final String  FIELD_RESPONSDEFINE = "responsDefine";
	
	public List<UTMap<String, Object>> getListByName(String groupName);
	
	public List<UTMap<String, Object>> getGroupDefineByNameAndId(String groupName,String id);
}
