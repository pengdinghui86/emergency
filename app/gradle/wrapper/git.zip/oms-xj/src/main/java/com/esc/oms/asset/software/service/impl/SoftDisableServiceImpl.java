package com.esc.oms.asset.software.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.asset.software.dao.ISoftDisableDao;
import com.esc.oms.asset.software.dao.ISoftUpgradeDao;
import com.esc.oms.asset.software.service.ISoftDisableService;
import com.esc.oms.util.CommonUtils;

@Service
@Transactional
public class SoftDisableServiceImpl extends BaseOptionService implements
		ISoftDisableService {
	
	@Resource
	private ISoftDisableDao softDisableDao;

	@Override
	public List<UTMap<String, Object>> getSoftDisableList(Map param) {
		return softDisableDao.getSoftDisableList(param);
	}

	@Override
	public boolean leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		String[] fileds = new String[] { 
				ISoftDisableDao.FIELD_SOFTWAREID,  
				ISoftDisableDao.FIELD_DISABLEDATE,   
				ISoftDisableDao.FIELD_REASON,
				ISoftDisableDao.FIELD_SPARE
		};
		if (null != data && !data.isEmpty()) {
			for (int i=0;i<data.size();i++) {
				UTMap<String, Object> item = (UTMap<String, Object>) data.get(i);
				item.put(ISoftDisableDao.FIELD_DISABLEDATE, 
						CommonUtils.replaceAll((String) item.get(ISoftDisableDao.FIELD_DISABLEDATE), "-", "/"));
			}
		}
		String tamlate="excelOutTamplate.assetSoftDisable";	
		return	UTExcel.leadingout( fileds, data, tamlate, request,response);
	}

	@Override
	public IBaseOptionDao getOptionDao() {
		return softDisableDao;
	}

}
