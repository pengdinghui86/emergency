package com.esc.oms.asset.repair.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.asset.repair.dao.IAssetRepairContactDao;
import com.esc.oms.asset.repair.service.IAssetRepairContactService;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;

@Service
@Transactional
public class AssetRepairContactServiceImpl extends BaseOptionService implements
		IAssetRepairContactService {

	@Resource
	private IAssetRepairContactDao assetRepairDao;
	
//	@EscOptionLog(module=SystemModule.assetRepairContact, opType=ESCLogOpType.INSERT, table="assets_material_repair_contact", option="新增id为{id}的维修联系信息。")
	public boolean add(Map info){
		return super.add(info);
	}
	
//	@EscOptionLog(module=SystemModule.assetRepairContact, opType=ESCLogOpType.UPDATE, table="assets_material_repair_contact", option="更新id为{id}的维修联系信息。")
	public boolean updateById(Map info){
		return super.updateById(info);
	}
	
//	@EscOptionLog(module=SystemModule.assetRepairContact, opType=ESCLogOpType.DELETE, table="assets_material_repair_contact", primaryKey="{1}", option="删除id为{id}的维修联系信息。")
	public boolean deleteById(String id){
		return super.deleteById(id);
	}
	
//	@EscOptionLog(module=SystemModule.assetRepairContact, opType=ESCLogOpType.DELETES, table="assets_material_repair_contact", option="删除id为{id}的维修联系信息。")
	public boolean deleteByIds(String ids){
		return super.deleteByIds(ids);
	}
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return assetRepairDao;
	}
	
	@Override
	public UTMap<String, Object> getRepairById(String id) {
		return assetRepairDao.getRepairById(id);
	}

	@Override
	public List<UTMap<String, Object>> getRepairList(Map param) {
		return assetRepairDao.getRepairList(param);
	}

	@Override
	public boolean leadingout(List data, HttpServletRequest request, 
			HttpServletResponse response) throws Exception {
		String[] fields = { "agreementName", "supplierName", "contactUser",
				"contactPhone", "backupUser", "backupPhone", "rangee" };

		String template = "excelOutTamplate.repairContact";
		return UTExcel.leadingout(fields, data, template, request, response);
	}

}
