package com.esc.oms.outsource.external.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.external.dao.IExternalEvaluateConfigurationDao;
import com.esc.oms.util.RoleUtils;

/**
 * 非驻场外包评估配置Dao
 * @author owner
 *
 */
@Repository
public class ExternalEvaluateConfigurationDaoImpl extends BaseOptionDao implements IExternalEvaluateConfigurationDao{

	@Override
	public String getTableName() {
		return "outsourc_external_evaluate_configuration";
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params,false), pageBean, null);
	}
	
	@Override
	public List<UTMap<String, Object>> getListMaps(Map param) {
		return super.getListBySql(getSearchSql(param,false), null);
	}
	
	@Override
	public UTMap<String, Object> getById(String id) {
		String sql = this.getSearchSql(null,true);
		List<UTMap<String, Object>> list = super.getListBySql(sql, id);
		if(list != null && list.size() > 0){
			return list.get(0);
		}
		return null;
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params,boolean isGetById){
		StringBuilder sql=new StringBuilder();
		sql.append("select tb.*,su.name as 'submitterName',sbi.name as 'supplierName',oere.status as 'accessEvaluateResultStatus',CONCAT(tb.templateConfigurationName , ' ' , tb.templateConfigurationVersions) as 'templateConfiguration',tb.beginDate > '"+UTDate.getCurDate()+"' as isEdit from " );
		sql.append(getTableName());
		sql.append(" tb left join supplier_base_info sbi on tb.supplierId = sbi.id ");
		sql.append(" left join sys_user su on tb.submitter = su.id");
		sql.append(" left join outsourc_external_result_evaluate oere on oere.externalEvaluateConfigId = tb.id  where 1=1 ");
		if(isGetById){
			sql.append(" and tb.id = ? ");
		}
		String userType = EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserType();
		//金融机构用户不做数据过滤，供应商人员看本供应商的数据
		if(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId() != null && !EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR,RoleUtils.SUPPLIER_ADMINISTRATOR) && !"1".equals(userType)){
			sql.append(" and tb.supplierId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId()+"' ");
		}
		
		if(params!=null && params.size()>0){
			
			if(params.get("evaluateTitle")!=null &&  StringUtils.isNotEmpty(params.get("evaluateTitle").toString())){
				sql.append(" and tb.evaluateTitle like '%"+params.get("evaluateTitle").toString().trim()+"%' ");
			}
			if(params.get("isResult")!=null){//如果是结果评估页面的查询请求，只查询开始时间小于等于当前时间的数据
				sql.append(" and tb.beginDate <= '"+UTDate.getCurDate()+"' ");
			}
			if(params.get("supplierId")!=null && StringUtils.isNotEmpty(params.get("supplierId").toString())){
				sql.append(" and tb.supplierId = '"+params.get("supplierId").toString().trim()+"' ");
			}
			if(params.get("supplierName")!=null && StringUtils.isNotEmpty(params.get("supplierName").toString())){
				sql.append(" and sbi.name like '%"+params.get("supplierName").toString().trim()+"%' ");
			}
			if(params.get("isSendMessageDate")!=null){//如果是查询当天需要发送消息的数据
				sql.append(" and tb.beginDate = '"+UTDate.getCurDate()+"' and tb.status = 0 ");//
			}
//			if(params.get("evaluateTitle")!=null && StringUtils.isNotEmpty(params.get("evaluateTitle").toString())){
//				sql.append(" and sbi.name = '"+params.get("evaluateTitle").toString().trim()+"' ");
//			}
//			if(params.get("subType")!=null && StringUtils.isNotEmpty(params.get("subType").toString())){
//				sql.append(" and tb.subType = "+params.get("subType").toString().trim()+" ");
//			}
		}
		sql.append(" order by tb.createTime desc");
		return  sql.toString();
	}

}
