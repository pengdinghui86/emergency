package com.esc.oms.asset.lowvalue.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.asset.lowvalue.dao.ILowvalueReceptionDao;
import com.esc.oms.util.RoleUtils;
@Repository
public class LowvalueReceptionDaoImpl extends BaseOptionDao implements ILowvalueReceptionDao{
	
	@Override
	public String getTableName() {
		return "assets_lowvalue_reception";
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params,false), pageBean, null);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params) {
		return super.getListBySql(getSearchSql(params,false), null);
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params,boolean isGetById){
		StringBuilder sql = new StringBuilder();
		sql.append(" select reception.*,CONCAT(receptUser.name,'/',receptUser.`code`) as receptUserName,CONCAT(grantUser.name,'/',grantUser.`code`) as grantUserName,org.longName as unitName"
				+ " from assets_lowvalue_reception reception ");
		sql.append(" left join sys_user receptUser on reception.receptUserId=receptUser.id ");
		sql.append(" left join sys_user grantUser on reception.grantUserId=grantUser.id ");
		sql.append(" left join sys_org org on reception.unit=org.id ");
		sql.append(" where 1=1 ");
		if(params!=null && params.size()>0){		
			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
				sql.append(" and reception.name like '%"+params.get("name").toString().trim()+"%' ");
			}
			if(params.get("startDate")!=null && StringUtils.isNotEmpty(params.get("startDate").toString())){
				sql.append(" and DATE_FORMAT(reception.receptDate,'%Y-%m-%d')>='"+params.get("startDate").toString().trim()+"' ");
			}
			if(params.get("endDate")!=null && StringUtils.isNotEmpty(params.get("endDate").toString())){
				sql.append(" and DATE_FORMAT(reception.receptDate,'%Y-%m-%d')<='"+params.get("endDate").toString().trim()+"' ");
			}
		}
		//数据权限控制
		if(!RoleUtils.isAssetManager()&&!RoleUtils.isSystemAdministrator()){
			String userId = EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId();
			String userType = EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserType();
			if("1".equals(userType)){//普通金融机构用户，只查看自己领用的记录
				sql.append(" and reception.receptUserId='"+userId+"' ");
			}				
		}
		sql.append(" order by reception.updateTime desc, reception.createTime desc, reception.receptDate desc ");
		return  sql.toString();
	}
}
