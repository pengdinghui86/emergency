package com.esc.oms.asset.lowvalue.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

public interface ILowvalueApplyDao extends IBaseOptionDao{
	
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_NAME = "name";
	public static final String  FIELD_CODE = "code";
	public static final String  FIELD_TYPE = "type";
	public static final String  FIELD_CREATE_USER = "createUser";
	public static final String  FIELD_UNIT_NAME = "unitName";
	public static final String  FIELD_APPLY_TIME = "applyTime";
	public static final String  FIELD_REMARK = "remark";
	public static final String  FIELD_STATUS = "status";
		
	//状态：-2.发放驳回 -1.驳回 0.待提交   1.待审批  2.审批中  3.待发放  4.发放中 5.待确认  6.确认中 7.完成  8.被终止
	public static final String STATUS_PEND_SUBMIT = "0";	// 待提交
	public static final String STATUS_PEND_AUDIT = "1";	// 待审批
	public static final String STATUS_AUDITING = "2";	// 审批中
	public static final String STATUS_AUDIT_FINISH = "3";	// 审批完成，待发放
	public static final String STATUS_GRANTING = "4";	// 审批完成，待发放
	public static final String STATUS_PEND_CONFIRM = "5";	// 审批完成，待发放
	public static final String STATUS_CONFIRMING = "6";	// 审批完成，待发放
	public static final String STATUS_FINISH = "7";	// 审批完成，待发放
	public static final String STATUS_REJECT = "-1";	// 驳回
	public static final String STATUS_GRANT_REJECT = "-2";	// 驳回
	public static final String STATUS_TERMINATE = "8";	// 被终止
	
	
	//待办   跟前台待办跳转关联，若改动需同步更改
	public static final String TASK_LOWVALUE_GRANT = "低值易耗品发放";	
	public static final String TASK_LOWVALUE_CONFIRM = "低值易耗品发放确认";	
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params);
	/**
	 * 待审批列表--分页查询
	 * @param pageBean
	 * @param params
	 */
	public void getPendApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params);
	/**
	 * 已审批列表--分页查询
	 * @param pageBean
	 * @param params
	 */
	public void getAlreadyApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params);
	
}
