package com.esc.oms.asset.retirement.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

public interface IAssetRetirementDao extends IBaseOptionDao{
	
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_NAME = "name";
	public static final String  FIELD_CODE = "code";
	public static final String  FIELD_REASON = "reason";
	public static final String  FIELD_SCRAPDATE = "scrapDate";
	public static final String  FIELD_REMARK = "remark";
	public static final String  FIELD_HANDLE = "handle";
	public static final String  FIELD_CREATEUSER = "createUser";
	public static final String  FIELD_CREATETIME = "createTime";
	public static final String  FIELD_STATUS = "status";
	

	public static final String STATUS_NOT_SUBMIT = "0";	// 未提交
	public static final String STATUS_NOT_AUDITING = "1";	// 待审批
	public static final String STATUS_AUDITING = "2";	// 审批中
	public static final String STATUS_FINISH = "3";	// 已审批  
	public static final String STATUS_REJECT = "4";// 驳回
	public static final String STATUS_TERMINATE = "5";	// 被终止
	
	public boolean addRelation(Map info);
	
	/**
	 * 查询备件
	 * */
	public List<UTMap<String, Object>> getAssetsById(String id) ;
	
	/**
	 * 根据资产id删除备件联系
	 * @param id
	 * @return
	 */
	public boolean deleteAssetsById(String id);
	
	public List<UTMap<String, Object>> getAssetsList(Map param);
	
}
