package com.esc.oms.outsource.attendance.service.impl;

import com.esc.oms.outsource.attendance.service.IAttendanceDefaultService;
import org.esc.framework.defval.DefaultValueTool;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class AttendanceDefaultServiceImpl implements IAttendanceDefaultService {



    @Override
    @Cacheable({"defaultValueCache"})
    public String getValue(String configType, String code) {
        return DefaultValueTool.getValue(configType, code);
    }

    @Override
    @CacheEvict(value={"defaultValueCache"},allEntries=true)
    public void clearCache() {

    }
}
