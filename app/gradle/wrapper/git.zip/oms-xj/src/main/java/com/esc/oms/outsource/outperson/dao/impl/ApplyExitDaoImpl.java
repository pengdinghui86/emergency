package com.esc.oms.outsource.outperson.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.security.dao.ISysRoleDao;
import org.esc.framework.security.dao.ISysUserDao;
import org.esc.framework.security.util.ESCSecurityEnum.ESCUesrType;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.outperson.dao.IApplyExitDao;
import com.esc.oms.util.RoleUtils;
@Repository
public class ApplyExitDaoImpl extends BaseOptionDao implements IApplyExitDao{
	

	@Override
	public String getTableName() {
		return "outsourc_apply_exit_info";
	}
	public boolean isExist(Map param){
		StringBuilder sqlcount = new StringBuilder();
		sqlcount.append("select tb.*  from outsourc_apply_exit_info  tb  where 1=1   ");
		for (Object key : param.keySet()) {
			sqlcount.append(" and  tb." + key.toString() + "= '" + param.get(key) + "' ");
		}
		sqlcount.append(" and tb.status <>6 ");
		List<UTMap<String, Object>> list = super.getListBySql(sqlcount.toString(), null);
		Integer count = list == null ? 0 : list.size();
		/*SQLQuery sqlQuery = this.getSession().createSQLQuery(
				sqlcount.toString());
		this.setParamsToSql(sqlQuery, param);
		Object object=sqlQuery.uniqueResult();
		Integer count = object!=null?Integer.valueOf(object.toString()):null;*/
		return count>0;
	}

	public UTMap<String, Object> getById(String id){
		StringBuilder sql=new StringBuilder();
		sql.append(" select sq.*,sbi.name supplierName,REPLACE( u.orgName,'!','/') departmentName ,u.code userCode,u.phone,u.age,u.idCode from outsourc_apply_exit_info sq  ");
		sql.append(" join supplier_base_info sbi  on sq.supplierId=sbi.id  ");
		sql.append(" left join sys_user u on u.id=sq.exitUserId where sq.id='"+id+"'  ");
		UTMap<String, Object> info= super.getOneBySql( sql.toString(),null);
		Object userIdObject=info.get(FIELD_CONFIMUSERID);
		if(userIdObject!=null && StringUtils.isNotEmpty(userIdObject.toString())){
			Object userName=super.searchOneBySql("select u.name from sys_user u where u.id='"+userIdObject.toString()+"'",null);
			info.put(FIELD_CONFIMUSERNAME, userName);
		}
		return info;
	}
	
	@Override
	public List<UTMap<String, Object>> searchInfo(Map<String, Object> params) {
		return super.getListBySql(toSearchSql(params));
	}
	
	@Override
	public void searchInfoPage( UTPageBean pageBean,Map<String, Object> params) {
		getPageListMapBySql(toSearchSql(params), pageBean, null);
		//return pageBean;
	}
	
	//获取待审列表
	public void getPendApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select DISTINCT(t1.id)  as id, t2.name as supplierName,t1.exitReason,t1.remark,t1.isQuit, ");
		sql.append("        t1.exitUserId as exitUserId, t1.exitUserName as exitUserName, t1.processId as workflowInstanceId,t1.processStep as processStep, ");
		sql.append("  t1.exitDate as exitDate,  t1.isNotice as isNotice, t1.isConfirm as isConfirm,  ");
		sql.append("        t1.`status` as `status`,t1.createUserId as createUserId, t1.createUser as createUser, t1.createTime as createTime,");
		sql.append(" t4.currentExecutor as auditors,t4.currentStepName, ");
		sql.append(" REPLACE( u.orgName,'!','/') departmentName,u.code userCode");
		sql.append("  from outsourc_apply_exit_info t1 ");
		sql.append("      join supplier_base_info t2 on t1.supplierId=t2.id ");
		sql.append(" left join sys_workflow_instance t4 on t1.processId=t4.id  ");
		sql.append(" left join sys_user u on u.id=t1.exitUserId ");
		//系统管理员和admin可以查看去全部数据
		//if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR)){
			sql.append(" where  FIND_IN_SET('"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"',t4.currentExecutor)  ");
	//	}
		setSqlParam(sql, params);
		sql.append(" order by t1.createTime desc ");
		super.getPageListMapBySql(sql.toString(), pageBean, null);		
	}

	//获取已审列表
	public void getAlreadyApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select DISTINCT(t1.id)  as id, t2.name as supplierName,t1.exitReason,t1.remark,t1.isQuit, ");
		sql.append("        t1.exitUserId as exitUserId, t1.exitUserName as exitUserName, t1.processId as workflowInstanceId,t1.processStep as processStep, ");
		sql.append("  t1.exitDate as exitDate,  t1.isNotice as isNotice, t1.isConfirm as isConfirm,  ");
		sql.append("        t1.`status` as `status`,t1.createUserId as createUserId, t1.createUser as createUser, t1.createTime as createTime,");
		sql.append(" t4.optionUserId as optionUserId, ");
		sql.append(" REPLACE( u.orgName,'!','/') departmentName,u.code userCode");
		sql.append("  from outsourc_apply_exit_info t1 ");
		sql.append("      join supplier_base_info t2 on t1.supplierId=t2.id ");
		sql.append(" left join sys_workflow_audit_history t4 on t1.processId=t4.instanceId ");
		sql.append(" left join sys_user u on u.id=t1.exitUserId ");
		//系统管理员和admin可以查看去全部数据
	//	if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR)){
			sql.append(" where FIND_IN_SET('"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"',t4.optionUserId) and t4.nodeName<>'开始' " );
	//	}
		setSqlParam(sql, params);
		sql.append(" order by t1.createTime desc ");
		super.getPageListMapBySql(sql.toString(), pageBean, null);
	}

	private String toSearchSql(Map<String, Object> params) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select DISTINCT(t1.id)  as id, t2.name as supplierName,t1.exitReason,t1.remark,t1.isQuit, ");
		sql.append("        t1.exitUserId as exitUserId, t1.exitUserName as exitUserName, t1.processId as workflowInstanceId,t1.processStep as processStep, ");
		sql.append("  t1.exitDate as exitDate,  t1.isNotice as isNotice, t1.isConfirm as isConfirm,  ");
		sql.append("        t1.`status` as `status`,t1.createUserId as createUserId, t1.createUser as createUser, t1.createTime as createTime,");

		sql.append("  REPLACE( u.orgName,'!','/') departmentName,u.code userCode");
		sql.append("  from outsourc_apply_exit_info t1 ");
		sql.append("      join supplier_base_info t2 on t1.supplierId=t2.id ");
		sql.append(" left join sys_user u on u.id=t1.exitUserId ");
		sql.append(" where 1= 1 ");
		setSqlParam(sql, params);
		//系统管理员和admin可以查看去全部数据
		if(EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR) || RoleUtils.isOutsourceManagerPerson()){
			
		}else
		//外包管理员管理所有数据，普通金融机构用户管理本人的申请，供应商用户管理本供应商的申请单
		if(RoleUtils.isSupplierAdministrator() || RoleUtils.isSupplierLeaders()){
			sql.append(" and t1.supplierId='"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId()+"'");
		}
		else{
			sql.append(" and t1.createUserId='"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"'");
		}
		sql.append(" order by t1.createTime desc ");
		
		return sql.toString();
	}
	
	
	private StringBuilder setSqlParam(StringBuilder sql,Map<String,Object> param){

		Map<String, String> p=UTMap.mapObjToString(param);
		String exitUserName =p.get("exitUserName");
		String status = p.get("status");
		String supplierName = p.get("supplierName");
		String exitReason = p.get("exitReason");
		String nameOrCode = p.get("nameOrCode");

		String id = p.get("id");
		
	//	String applyDate = p.get("applyDate");
		if (StringUtils.isNotBlank(id)) {
			sql.append(" and t1.id = " + id);
		}
		if(StringUtils.isNotEmpty(nameOrCode)){
			sql.append(" and  CONCAT(u.name,'/',u.code)  LIKE '%"+nameOrCode+"%'  ");
		}	
		if (StringUtils.isNotBlank(exitUserName)) {
			sql.append(" and t1.exitUserName like '%" + exitUserName.trim()+"%'" );
		}
		
		if (StringUtils.isNotBlank(status)) {
			sql.append(" and t1.status = " + status.trim() );
		}
		if (StringUtils.isNotBlank(exitReason)) {
			sql.append(" and t1.exitReason = " + exitReason.trim() );
		}
		
		if (StringUtils.isNotBlank(supplierName)) {
			sql.append(" and t2.name like '%" + supplierName.trim() + "%' ");
		}

		return sql;
	}
	
	@Override
	public List<UTMap<String, Object>> getUserBaseInfo(Map<String, Object> param){
		StringBuilder sql=new StringBuilder();
		sql.append("select u.id,u.id as 'userId', u.code, u.name, u.orgId,CONCAT(u.`name`,'/',u.`code`)  showName,");
		sql.append("   u.supplierName, u.supplierId,");
		sql.append(" u.phone,u.fixedPhone,u.email,u.userType,u.idCode,");
		sql.append(" 	ifnull(group_concat(distinct r.id),'') roleIds, "); //系统角色
		sql.append(" 	ifnull(group_concat(distinct r.name),'')  roleNames,  ");//系统角色名称
		sql.append(" 	ifnull(group_concat(distinct r.signature),'')  signature,  ");//系统角色名称
		sql.append(" replace(org.longName,'!','/' ) orgLongName  ");//用户所属组织
		sql.append(" from sys_user u ");
		sql.append("  left join sys_org org on u.orgId=org.id ");
		sql.append( " LEFT JOIN sys_user_role ur on ur.userId = u.id ");
		sql.append("  left join sys_role r on ur.roleId=r.id ");
		
		sql.append(" where 1=1 ");
		Map<String, String> p=UTMap.mapObjToString(param);
		String isAdd = p.get("isAdd");
		String id=p.get(ISysUserDao.FIELD_ID); 
		String name=p.get(ISysUserDao.FIELD_NAME);
		String code=p.get(ISysUserDao.FIELD_CODE);
		String orgIds=p.get(ISysUserDao.FIELD_ORGIDS);
		String orgNames=p.get(ISysUserDao.FIELD_ORGNAME);
		String orgLongName=p.get(ISysUserDao.FIELD_ORGLONGNAME);
		String userType=p.get(ISysUserDao.FIELD_USERTYPE);
		String supplierName=p.get(ISysUserDao.FIELD_SUPPLIERNAME);
		String supplierId=p.get(ISysUserDao.FIELD_SUPPLIERID);
		String supplierIds=p.get("supplierIds");
		String roleName =p.get(ISysUserDao.FIELD_ROLENAME);
		String roleIds =p.get(ISysUserDao.FIELD_ROLEIDS);
		String signature =p.get(ISysRoleDao.FIELD_SIGNATURE);
		String isQuerAll =p.get("isQuerAll");
		
		String ids =p.get("ids");
		
		if (StringUtils.isNotEmpty(isAdd) && StringUtils.equals(isAdd, "1")) {
			sql.append(" and not exists ( select id from outsourc_apply_exit_info o where o.exitUserId = u.id)");
		}else {
			sql.append(" and not exists ( select id from outsourc_apply_exit_info o where o.exitUserId = u.id and o.exitUserId <> '"+param.get("exitUserId")+"')");
		}
		
		if(!StringUtils.equals("true",isQuerAll)){
			sql.append("  and u.state<>0  ");
		}
	//	String state =p.get("state");
		if (StringUtils.isNotEmpty(ids)) {
			sql.append(" and find_in_set( u.id,'"+ids+"') ");
		}
		
		if (StringUtils.isNotEmpty(id)) {
			sql.append(" and u.id='"+id+"'");
		}
		
		if (StringUtils.isNotEmpty(supplierId)) {
			sql.append(" and  u.supplierId='"+supplierId+"'");
		}
		
		if (StringUtils.isNotEmpty(supplierIds)) {
			sql.append(" and find_in_set( u.supplierId ,'"+supplierIds+"') ");
		}
		
		if (StringUtils.isNotEmpty(code)) {
			sql.append(" and  u.code='"+code+"'");
		}
		

		if (StringUtils.isNotEmpty(roleName)) {
			sql.append(" and r.name like '%"+roleName+"%'");
		}
		
		if (StringUtils.isNotEmpty(roleIds)) {
			sql.append(" and find_in_set(r.id, '"+roleIds+"') ");
		}
		
		if ( supplierName!=null&&StringUtils.isNotEmpty( supplierName)) {
			sql.append(" and  u. supplierName like '%"+ supplierName.toString()+"%'");
		}
	
		if (userType!=null&&StringUtils.isNotEmpty(userType.toString())&&StringUtils.equals(ESCUesrType.INSIDE.getValue().toString(), userType)) {
			sql.append(" and  u.userType = '"+userType.toString()+"'");
		}
		if (userType!=null&&StringUtils.isNotEmpty(userType.toString())&&StringUtils.equals(ESCUesrType.SUPPLIER.getValue().toString(), userType)) {
			sql.append(" and  u.userType >= '"+userType.toString()+"'");
		}
		if (userType!=null&&StringUtils.isNotEmpty(userType.toString())&&StringUtils.equals(ESCUesrType.EPIBOLY.getValue().toString(), userType)) {
			sql.append(" and  u.userType = '"+userType.toString()+"'");
		}
		
		if (name!=null&&StringUtils.isNotEmpty(name)) {
			sql.append(" and  u.name like '%"+name+"%'");
		}
	
		
		if (orgIds!=null&&StringUtils.isNotEmpty(orgIds)) {
			sql.append(" and org.id ='"+orgIds+"'");
		}
		
		if (orgNames!=null&&StringUtils.isNotEmpty(orgNames)) {
		//	orgLongName=orgLongName.replace("/","!");
			sql.append(" and org.longName like'%"+orgNames+"%'");
		}
		
		if (orgLongName!=null&&StringUtils.isNotEmpty(orgLongName)) {
		//	orgLongName=orgLongName.replace("/","!");
			sql.append(" and (org.longName like '" + orgLongName + "%'  or org.longName='"+orgLongName+"')");
		}
		
		if (signature!=null&&StringUtils.isNotEmpty(signature.toString())) {
			sql.append(" and r.signature ='"+signature+"'");
		}
		
		
		sql.append("    GROUP BY u.id  order by (org.code+0) asc, u.code asc ");
		
		return super.getListBySql(sql.toString(),null);
	}

	
}
