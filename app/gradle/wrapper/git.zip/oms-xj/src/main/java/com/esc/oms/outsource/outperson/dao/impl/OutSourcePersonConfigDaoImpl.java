package com.esc.oms.outsource.outperson.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.outperson.dao.IOutSourcePersonConfigDao;
import com.esc.oms.util.RoleUtils;
@Repository
public class OutSourcePersonConfigDaoImpl extends BaseOptionDao implements IOutSourcePersonConfigDao{
	

	@Override
	public String getTableName() {
		return "outsource_person_config";
	}
	
	@Override
	public List<UTMap<String, Object>> getListMaps(Map param) {
		/*return	super.getListMaps(param, "paramValue", ORDERTYPE.ASC, null);*/
		return super.getListBySql(this.searchSql(param), null);
	}
	
	private String searchSql (Map param) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select * from " + getTableName() );
		sql.append(" where 1=1 ");
		String userId = (String) param.get("userId");
		if (StringUtils.isNotEmpty(userId)) {
			sql.append(" and userId='" + userId + "' ");
		}
		String auth = (String) param.get("auth");
		if (StringUtils.isNotEmpty(auth)) {
			if (EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR)) {

			}else if (EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.ACCESS_CONTROL_MANAGER)
					&& EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.NETWORK_MANAGER)
					&& EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.VIRTUAL_DESKTOP_MANAGER)) {
				sql.append(" and paramValue in ('2', '3', '4', '5')");
			} else if (EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.ACCESS_CONTROL_MANAGER)
					&& EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.NETWORK_MANAGER)) {
				sql.append(" and paramValue in('2', '4', '5') ");
			}else if (EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.ACCESS_CONTROL_MANAGER)
					&& EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.VIRTUAL_DESKTOP_MANAGER)) {
				sql.append(" and paramValue in('2', '3') ");
			}else if (EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.NETWORK_MANAGER)
					&& EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.VIRTUAL_DESKTOP_MANAGER)) {
				sql.append(" and paramValue in('3', '4', '5') ");
			}else if (EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.NETWORK_MANAGER)) {
				sql.append(" and paramValue in ('4', '5' ) ");
			}else if (EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.VIRTUAL_DESKTOP_MANAGER)) {
				sql.append(" and paramValue='3' ");
			}else if (EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.ACCESS_CONTROL_MANAGER)) {
				sql.append(" and paramValue='2' ");
			} 
		}
		sql.append(" order by paramValue ");
		return sql.toString();
	}
}
