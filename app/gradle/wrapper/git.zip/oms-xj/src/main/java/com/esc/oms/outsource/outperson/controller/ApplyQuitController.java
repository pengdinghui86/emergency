package com.esc.oms.outsource.outperson.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.exception.EscServiceException;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.outsource.outperson.service.IApplyCommonService;
import com.esc.oms.outsource.outperson.service.IApplyQuitService;
import com.esc.oms.util.CommonUtils;
/**
 * 离职申请控制器
 * @author smq
 * @date   2016-7-9 上午10:38:21
 */
@Controller
@RequestMapping("outsource/person/quit")
public class ApplyQuitController extends AbstractApplyController {

	@Resource
	private IApplyQuitService applyQuitService;
	
	@Override
	public IApplyCommonService applyService() {
		return applyQuitService;
	}
	
	@RequestMapping(value="cancelConfig",method=RequestMethod.POST)  
    @ResponseBody
	public String cancelConfigByUserId(@RequestBody Map<String,Object> map1){
		Map<String,Object> cloneMap = CommonUtils.clone(map1);
	   	try{
			boolean flog= applyQuitService.cancelConfigByUserId(cloneMap);
		    		return UTJsonUtils.getJsonMsg(flog, flog?"操作成功":"操作失败");
	    	}catch(EscServiceException e){
	    		logger.error("EscServiceException", e);
	    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
	    	}catch(Exception e){
	    		logger.error("Exception", e);
	    		return UTJsonUtils.getJsonMsg(false, "操作失败");
	    	}

	}
	
	@RequestMapping(value="getUserBaseInfo", method=RequestMethod.POST)
	@ResponseBody
	public List<UTMap<String, Object>> getUserBaseInfo(@RequestBody Map<String,Object> param){
		return applyQuitService.getUserBaseInfo(param);
	}
}