package com.esc.oms.outsource.agreementManpower.dao.impl;

import org.esc.framework.persistence.dao.BaseOptionDao;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.agreementManpower.dao.IAgreementManpowerVacationConfigDao;

/**
 * 人力外包合同请假折算配置
 * @author smq
 * @date   2016-2-24 上午10:55:48
 */
@Repository
public class AgreementManpowerVacationConfigDaoImpl extends BaseOptionDao implements   IAgreementManpowerVacationConfigDao {

	@Override
	public String getTableName() {
		return "agreement_manpower_vacation_config";
	}
	
}
