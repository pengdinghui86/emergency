package com.esc.oms.outsource.outperson.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.outsource.outperson.service.IOutSourcePersonBlacklistService;
import com.esc.oms.util.CommonUtils;

@Controller
@RequestMapping("/personBlacklist")
public class OutSourcePersonBlacklistController extends BaseOptionController {

	@Resource
	private IOutSourcePersonBlacklistService outSourcePersonBlacklistService;
	
	@Override
	public IBaseOptionService optionService() {
		return outSourcePersonBlacklistService;
	}
	
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			outSourcePersonBlacklistService.getPageInfo(pageBean, params);
			List<Map<String, Object>> list = pageBean.getRows();
			if(null != list && list.size() > 0 ){
				for (Map<String, Object> map : list) {
					Integer blackListType = (Integer) map.get("blackListType");
					if(blackListType != null){
						if (1 == blackListType) {
							map.put("blackListType", "暂不录用");
						} else{
							map.put("blackListType", "永不录用");
						} 
					}
				}
			}
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	
	/**
	 * 从excel导入
	 * 
	 * @param params
	 * @param filePath
	 * @return
	 */
	@RequestMapping(value = "leadingin")
	@ResponseBody
	public UTMap<String, Object> leadingin(@RequestParam Map<String, Object> param, String filePath) {
		UTMap<String, Object> utMap = new UTMap<String, Object>();
		try {
			utMap.put("success", outSourcePersonBlacklistService.leadingin(filePath, param));
			utMap.put("msg", "导入成功！");
		} catch (EscServiceException e) {
			logger.error("EscServiceException",e);
			utMap.put("success", false);
			utMap.put("msg", e.getMessage());
		} catch (Exception e) {
			logger.error("EscServiceException",e);
			utMap.put("success", false);
			utMap.put("msg", "导入失败");
		}
		return utMap;
	}
	
	
	@RequestMapping(value = "leadingout")
	public void leadingout(@RequestParam Map<String, Object> map1,
			HttpServletRequest request,
			HttpServletResponse response) {
		Map<String, Object> param = CommonUtils.clone(map1);
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();

			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = null;
			if (info != null) {
				jsonBean = JSONObject.fromObject(info);
			}

			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = outSourcePersonBlacklistService.getListMaps(jsonBean);
			} else {
				// 根据条件 导出当前
				outSourcePersonBlacklistService.getPageInfo(utPageBean, jsonBean);
				data = utPageBean.getRows();
			}
			if (null != data && data.size() > 0) {
				for (Map<String, Object> map : data) {
					int blackListType = (Integer) map.get("blackListType");
					if (1 == blackListType) {
						map.put("blackListType", "暂不录用");
					} else{
						map.put("blackListType", "永不录用");
					} 
					map.put("beginDate", CommonUtils.replaceAll((String) map.get("beginDate"), "-", "/"));
					map.put("endDate", CommonUtils.replaceAll((String) map.get("endDate"), "-", "/"));
				}
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			outSourcePersonBlacklistService.leadingout(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	/**
	 * @return
	 * 解除外包人员黑名单
	 */
	@RequestMapping(value = "clear")
	@ResponseBody
	public String clear(@RequestBody Map<String, Object> info){
		try {
			UTMap<String,Object> utMap = new UTMap<String, Object>();
			utMap.put("id", info.get("id"));
			utMap.put("isClear","1");
			outSourcePersonBlacklistService.updateBy(utMap, "id");
		} catch (Exception e) {
			logger.error(e.getMessage());
			return UTJsonUtils.getJsonMsg(false, "操作失败");
		}
		return UTJsonUtils.getJsonMsg(true, "操作成功");
	}

}
