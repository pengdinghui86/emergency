package com.esc.oms.outsource.performance.controller;

import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.exception.EscServiceException;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTListResult;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.outsource.performance.service.IPerformanceEvaluateConfigurationService;
import com.esc.oms.util.CommonUtils;

/**
 * 外包绩效考核配置Controller
 * @author owner
 *
 */
@Controller
@RequestMapping("performanceEvaluateConfiguration")
public class PerformanceEvaluateConfigurationController extends BaseOptionController {

	@Resource
	private IPerformanceEvaluateConfigurationService service;
	
	@Resource 
	private ISysUserService userService;
	
	@Override
	public IBaseOptionService optionService() {
		return service;
	}
	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			service.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	/**
	 * 根据id查询
	 * @param param
	 * @return 只查询结果考核列表
	 */
	@RequestMapping(value="getByIdToAccessResult")
	@ResponseBody
	public UTMap<String, Object> getByIdToAccessResult(@RequestParam  Map<String, Object> param){		
//		logger.info("执行默认根据Id获取方法");
//		return UTJsonUtils.getResultJson(true, optionService().getById(param.get("id").toString()));
		UTMap<String, Object> map = null;
    	try{
    		map = service.getByIdToAccessResult(param.get("id").toString());
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return map;
	}
	
	
	/**
	 * @param param
	 * @return 过程考核列表
	 */
	@RequestMapping(value="getByIdToAccessResult2")
	@ResponseBody
	public UTMap<String, Object> getByIdToAccessResult2(@RequestParam  Map<String, Object> param){		
//		logger.info("执行默认根据Id获取方法");
//		return UTJsonUtils.getResultJson(true, optionService().getById(param.get("id").toString()));
		UTMap<String, Object> map = null;
    	try{
    		map = service.getByIdToAccessResult2(param.get("id").toString());
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return map;
	}
	
	/**
	 * 总评估
	 * @param info
	 * @return
	 */
	@RequestMapping(value="evaluate")
	@ResponseBody
	public String evaluate(@RequestBody  Map<String, Object> info){
		try{
			service.evaluate(info);
    	}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "操作成功");
	}
	
	/**
	 * 关闭
	 * @param info
	 * @return
	 */
	@RequestMapping(value="close")
	@ResponseBody
	public String close(@RequestBody  Map<String, Object> info){
		try{
			service.close(info);
    	}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "关闭失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "关闭成功");
	}
	
	
	
	@RequestMapping(value="getUserBaseInfo",method=RequestMethod.POST)
	@ResponseBody
	public UTListResult getUserBaseInfo(@RequestBody Map<String, Object>param) {
		return UTListResult.getListResult(userService.getUserBaseInfo(param));
	}
}
