package com.esc.oms.asset.repair.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

public interface IAssetRepairRecordDao extends IBaseOptionDao {
	
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_ASSETSID = "assetsId";
	public static final String  FIELD_ASSETSCODE = "assetsCode";
	public static final String  FIELD_APPLYUSERID = "applyUserId";
	public static final String  FIELD_REPAIRUSER = "repairUser";
	public static final String  FIELD_REPAIRPHONE = "repairPhone";
	public static final String  FIELD_REPAIRSUPPLIER = "repairSupplier";
	public static final String  FIELD_COST = "cost";
	public static final String  FIELD_REASON = "reason";
	public static final String  FIELD_RESULT = "result";
	public static final String  FIELD_RESULTREMARK = "resultRemark";
	public static final String  FIELD_CREATEUSERID = "createUserId";
	public static final String  FIELD_CREATETIME = "createTime";
	
	
	public UTMap<String, Object> getRepairRecordById(String id);
	
	public List<UTMap<String, Object>> getRepairRecordList(Map param);
	
}
