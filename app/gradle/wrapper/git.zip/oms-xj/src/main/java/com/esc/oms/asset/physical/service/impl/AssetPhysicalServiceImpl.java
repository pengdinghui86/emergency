package com.esc.oms.asset.physical.service.impl;

import com.esc.oms.asset.agreement.service.IAssetsAgreementInfoService;
import com.esc.oms.asset.allocation.service.IAssetAllocationlService;
import com.esc.oms.asset.assetCategory.dao.IAssetCategoryDao;
import com.esc.oms.asset.overview.dao.IAssetsTrackInfoDao;
import com.esc.oms.asset.overview.service.IAssetsTrackInfoService;
import com.esc.oms.asset.physical.dao.IAssetPhysicalDao;
import com.esc.oms.asset.physical.service.IAssetPhysicalService;
import com.esc.oms.asset.place.dao.IAssetPlaceDao;
import com.esc.oms.asset.place.service.IAssetPlaceService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ExcelUtil;

import net.sf.json.JSONObject;

import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.esc.framework.dict.dao.ISysParamDao;
import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.dao.ISysOrgDao;
import org.esc.framework.security.service.IOrgMemberService;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.excel.UTExcelValidate;
import org.esc.framework.utils.page.UTPageBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class AssetPhysicalServiceImpl extends BaseOptionService implements IAssetPhysicalService{
	
	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private IAssetPhysicalDao assetPhysicalDao;
	
	@Resource
	private IAssetAllocationlService assetAllocationlService;
	
	@Resource
	private IAssetsAgreementInfoService assetsAgreementInfoService;
	
	@Resource
	private ISysParamService sysParamService;

	@Resource
	private ISysParamDao sysParamDao;
	
	@Resource
	private ISysUserService sysUserService;
	
	@Resource
	private IAssetsTrackInfoService assetsTrackInfoService;
	
	@Resource
	private ISysOrgDao orgDao;
	
	@Resource
	private IAssetPlaceService assetPlaceService;

	@Resource
	private IAssetPlaceDao assetPlaceDao;
	
	@Resource
	private IOrgMemberService orgMemberService;

	@Resource
	private IAssetCategoryDao assetCategoryDao;


	@EscOptionLog(module=SystemModule.assetPhysical, opType=ESCLogOpType.INSERT, table="assets_material_info",option="新增名称为{name}的实物资产登记信息。")
	public boolean add(Map info){
		boolean flag = false;
		info.put("sortCode", assetPhysicalDao.getNewCode(101, "sortCode"));
		info.put("status", "1");
		info.put("inventory_status", "1");//盘点状态默认盘亏
		flag = getOptionDao().add(info);
		if(flag){
			//更改辐设备的parentId
			List<Map> auxiliaryList =  (List<Map>) info.get("auxiliaryList");
	    	if(null != auxiliaryList && auxiliaryList.size() > 0){
	    		for (Map auxiliary : auxiliaryList) {
	    			UTMap<String,Object> map = new UTMap<String,Object>();
	    			map.put("id", auxiliary.get("id"));
	    			map.put("parentId", info.get("id"));
	    			getOptionDao().updateById(map);
				}
	    	}
			
			//资产轨迹---资产入库
			UTMap<String,Object> ut = new UTMap<String,Object>();
			ut.put("assetsId", info.get("id"));
			ut.put("type", 1);//实物资产
			if(StringUtils.isNotEmpty((String)info.get("resDepartId"))){
				ut.put("departId", (String)info.get("resDepartId"));
			}
			if(StringUtils.isNotEmpty((String)info.get("resUserId"))){
				ut.put("userId", (String)info.get("resUserId"));
			}
			ut.put("changeType","入库");
			ut.put("changeTime", new Date(System.currentTimeMillis()));
			ut.put("changeRemark", IAssetsTrackInfoDao.FIELD_ASSETSSTORAGE);
			assetsTrackInfoService.add(ut);
		}
		return	flag;
	}
	
	@Override
	@EscOptionLog(module=SystemModule.assetPhysical, opType=ESCLogOpType.UPDATE, table="assets_material_info",option="修改名称为{name}的实物资产登记信息。")
	public boolean updateById(Map info){
		//更改辐设备的parentId
		List<Map> auxiliaryList =  (List<Map>) info.get("auxiliaryList");
		//先删除之前关联的辅设备
		updateAuxiliaryById(String.valueOf(info.get("id")));
    	if(null != auxiliaryList && auxiliaryList.size() > 0){
    		
    		for (Map auxiliary : auxiliaryList) {
    			UTMap<String,Object> map = new UTMap<String,Object>();
    			map.put("id", auxiliary.get("id"));
    			map.put("parentId", info.get("id"));
    			getOptionDao().updateById(map);
			}
    	}
    	if(null != info.get("assetPrice") && null != info.get("totalAssets") && null != info.get("parentId") && "0".equals(String.valueOf(info.get("auxiliaryAsset")))){
    		assetPhysicalDao.updateTotalPriceById(String.valueOf(info.get("parentId")), String.valueOf(info.get("price")), String.valueOf(info.get("assetPrice")));
    	}
    	
		if(null != info.get("assetsRegistStatus")){
			// 预登记转入库
			info.put("registStatus", "2");

			//预登记转入库添加sn号，添加编码值

			//关于sn号
			info.put("sn",this.getSnNum());
			//从参数中获取sn号，并回去修改sn号，此方法必须同步
			//关于编码值
			info.put("code", info.get("sn"));
			//预登记入库以后添加轨迹
			UTMap<String,Object> ut = new UTMap<String,Object>();
			ut.put("assetsId", info.get("id"));
			ut.put("type", 1);//实物资产
			if(StringUtils.isNotEmpty((String)info.get("resDepartId"))){
				ut.put("departId", (String)info.get("resDepartId"));
			}
			if(StringUtils.isNotEmpty((String)info.get("resUserId"))){
				ut.put("userId", (String)info.get("resUserId"));
			}
			ut.put("changeType","入库");
			ut.put("changeTime", new Date(System.currentTimeMillis()));
			ut.put("changeRemark", IAssetsTrackInfoDao.FIELD_ASSETSSTORAGE);
			assetsTrackInfoService.add(ut);
		}
		if(null != info.get("status") && "5".equals(String.valueOf(info.get("status")))){
			info.put("isScrap", 1);
		}
		return getOptionDao().updateById(info);
	}
	
	
	@Override
	@EscOptionLog(module=SystemModule.assetPhysical, opType=ESCLogOpType.DELETE, table="assets_material_info",option="删除名称为{name}的实物资产登记信息。")
	public boolean delete(Map info){
		return	getOptionDao().delete(info);
	}
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return assetPhysicalDao;
	}

	@Override
	public boolean addRelation(Map info) {
		return assetPhysicalDao.addRelation(info);
	}

	@Override
	public List<UTMap<String, Object>> getSparesById(String id) {
		return assetPhysicalDao.getSparesById(id);
	}

	@Override
	public boolean deleteSparesById(String id) {
		return assetPhysicalDao.deleteSparesById(id);
	}

	@Override
	public boolean leadingin(String filePath, Map<String, Object> param)
			throws Exception {
		List<UTMap<String, Object>> leadinginList = new ArrayList<UTMap<String,Object>>();
		boolean flag = true;
		StringBuilder sb = new StringBuilder();
		// 根据路径 获取工作薄
		Sheet sheet = UTExcel.getSheets(filePath)[0];
		// 导入顺序
		String[] cellArray = new String[] { 
				"资产序列号（长度：0-20）", 
				"资产编号（长度：0-20）", 
				"资产名称*（长度：0-20）", 
				"资产大类*",
				"资产小类*",
				"资产级别*", 
				"采购合同", 
				"维保合同",
				"资产维保开始日期（格式：yyyy/mm/dd）",
        		"资产维保结束日期（格式：yyyy/mm/dd）", 
        		"是否第三方维保（是/否）", 
        		"存放地点*", 
        		"生产商*（长度：0-20）", 
        		"残值率（格式：数字）（长度：0-20）", 
        		"折旧年限（格式：数字）（长度：0-3）", 
        		"出库日期（格式：yyyy/mm/dd）", 
        		"入库日期*（格式：yyyy/mm/dd）", 
        		"品牌（长度：0-20）", 
        		"型号（长度：0-20）", 
        		"保密性", 
        		"完整性", 
        		"可用性", 
        		"设备负责人",
        		//"所属部门（一级部门/二级部门/...）", 
        		"是否正版（是/否）",
        		"是否国产（是/否）", 
        		"是否需要备件（是/否）",
        		"是否主设备（是/否）",
        		"资产单价（格式：数字）（长度：0-9）",
        		"是否自带操作系统（是/否）",
        		"资产状态*","报废日期（格式：yyyy/mm/dd）", 
        		"业务名称（长度：0-20）",
        		"维保金额（格式：数字）（长度：0-9）",
        		"资产属性配置（长度：0-1000）",
        		"备注（长度：0-800）"
        };
		int[] lengthArr = {20, 20, 20, 0, 0, 0, 0, 0, 0,0, 0, 0, 20, 20, 3, 0, 0, 20, 20, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, 0, 0, 20, 9, 1000, 800};
		String[] fileds = new String[] { 
				IAssetPhysicalDao.FIELD_SERIALNUM,
				IAssetPhysicalDao.FIELD_CODE,
				IAssetPhysicalDao.FIELD_NAME,
				IAssetPhysicalDao.FIELD_CATEGORY,
				IAssetPhysicalDao.FIELD_SUBCATEGORY,
				IAssetPhysicalDao.FIELD_ASSETS_LEVEL,
				IAssetPhysicalDao.FIELD_BUYCONTRACT,
				IAssetPhysicalDao.FIELD_MAINTAINCONTRACT,
				IAssetPhysicalDao.FIELD_MAINTASSETSTARTDATE,
				IAssetPhysicalDao.FIELD_MAINTASSETSENDDATE,
				IAssetPhysicalDao.FIELD_OTHERMAINT,
				IAssetPhysicalDao.FIELD_LOCATION,
				IAssetPhysicalDao.FIELD_PRODUCER,
				IAssetPhysicalDao.FIELD_SALVAGE,
				IAssetPhysicalDao.FIELD_USEYEARS,
				IAssetPhysicalDao.FIELD_PURCHASEDATE,
				IAssetPhysicalDao.FIELD_INBOUNDDATE,
				IAssetPhysicalDao.FIELD_BRAND,
				IAssetPhysicalDao.FIELD_MODEL,
				IAssetPhysicalDao.FIELD_CONFIDENTIALITY,
				IAssetPhysicalDao.FIELD_INTEGRITY,
				IAssetPhysicalDao.FIELD_AVAILABILITY,
				IAssetPhysicalDao.FIELD_RESUSERID,
				//IAssetPhysicalDao.FIELD_RESDEPARTID,
				IAssetPhysicalDao.FIELD_ISPOSITIVE,
				IAssetPhysicalDao.FIELD_CONTROLLABLE,
				IAssetPhysicalDao.FIELD_HASBACKUP,
				IAssetPhysicalDao.FIELD_AUXILIARYASSET,
				IAssetPhysicalDao.FIELD_ASSETPRICE,
				IAssetPhysicalDao.FIELD_OWNSYSTEM,
				IAssetPhysicalDao.FIELD_ASSETSTATUS,
				IAssetPhysicalDao.FIELD_SCRAPDATE,
				IAssetPhysicalDao.FIELD_BUSINESS_NAME,
				IAssetPhysicalDao.FIELD_MAINTENANCE_AMOUNT,
				IAssetPhysicalDao.FIELD_ASSET_ATTRIBUTES,
				IAssetPhysicalDao.FIELD_REMARK
		};
		
		int rowNum = sheet.getLastRowNum();
		int cellNum = sheet.getRow(0).getLastCellNum();
		//资产编号导入模板
		if(cellNum == 2)
		{
			String[] cellArray2 = new String[] 
					{ 
						"资产序列号（长度：0-20）", 
						"资产编号（长度：0-20）"
					};
			int[] lengthArr2 = {20, 20};
			String[] fileds2 = new String[] 
					{ 
						IAssetPhysicalDao.FIELD_SERIALNUM,
						IAssetPhysicalDao.FIELD_CODE
					};
			boolean err = check(sheet, cellArray2, fileds2, sb, leadinginList, lengthArr2);
			//更新数据库
			for (int i = 0; i < leadinginList.size(); i ++) {
				UTMap<String, Object> riskgMap = leadinginList.get(i);
				
				try {
					flag = assetPhysicalDao.updateAssetCodeBySerialNum(riskgMap);
				} catch (Exception e) {
					e.printStackTrace();
					flag = false;
				}
				if (!flag) {
					throw new EscServiceException("".equals(sb.toString())?"保存数据失败！":sb.toString() + "<br>保存数据失败！");
				}
			}
			if(err)
				throw new EscServiceException(sb.toString());
			return flag;
		}
		else if(cellNum > cellArray.length)
		{
			//大类和小类名称获取额外属性
			Row rowtitle = sheet.getRow(1);
			String parentName = rowtitle.getCell(3).getStringCellValue();
			String name = rowtitle.getCell(4).getStringCellValue();
			String id = assetCategoryDao.getAssetCategoryIdByNames(parentName, name);
			//资产类别名称
//			String name = rowtitle.getCell(3).getStringCellValue();
//			String id = assetCategoryDao.getAssetCategoryIdByName(name);
			UTPageBean pageBean = new UTPageBean();
			Map<String, Object> tempParam = new UTMap<>();
			tempParam.put("categoryId", id);
			assetCategoryDao.getAttrAll(tempParam, pageBean);
			List<Map<String, Object>> maps = pageBean.getRows();
			List<Map<String, Object>> tempMaps = new ArrayList<>(maps);
			//过滤掉附件属性
			for(Map<String, Object> map : tempMaps)
			{
				if("adjunct".equals(map.get("type").toString()))
				{
					maps.remove(map);
				}
			}
			ExcelUtil excelUtil = new ExcelUtil();
			String[] cellArray1 = excelUtil.createColumnName(maps); 
		    String[] fileds1 = new String[fileds.length + maps.size()];
		    System.arraycopy(fileds, 0, fileds1, 0, fileds.length);
		    int i = 0;
		    for(Map<String, Object> map : maps)
		    {
		    	fileds1[fileds.length + i] = map.get("attId").toString();
		    	i++;
		    }
		    int[] lengthArr1 = {20, 20, 20, 0, 0, 0, 0, 0, 0, 0,0, 0, 20, 20, 3, 0, 0, 20, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0 ,0 ,0 ,50, 9, 1000, 800};
			boolean err = checkfileds(sheet, cellArray1, fileds1, sb, leadinginList, maps, lengthArr1);
			if(err)
				throw new EscServiceException(sb.toString());
		}
		else
		{
			boolean err = checkfileds(sheet, cellArray, fileds, sb, leadinginList, null, lengthArr);
			if(err)
				throw new EscServiceException(sb.toString());
		}
		
		//保存到数据库
		for (int i = 0; i < leadinginList.size(); i ++) {
			UTMap<String, Object> riskgMap = leadinginList.get(i);
			//往数据库插入一条数据
			Map<String, Object> data = new UTMap<String, Object>();
			Map<String, Object> extMap = new UTMap<String, Object>(riskgMap);
			data.put("formData", extMap);
			Map<String, Object> mainMap = new UTMap<String, Object>(riskgMap);
			data.put("formDataMain", mainMap);
			try {
				String result = saveOrUpdate(data);
				JSONObject object=JSONObject.fromObject(result);
				flag = "true".equals(object.getString("success"));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				flag = false;
			}
			if (!flag) {
				throw new EscServiceException("保存数据失败！");
			}
		}
		return flag;
	}
	
	private boolean check(Sheet sheet, String[] cellArray, String[] fileds, StringBuilder sb, 
			List<UTMap<String, Object>> leadinginList, int[] lengthArr)
	{
		int rowNum = sheet.getLastRowNum();
		int cellNum = fileds.length;
		boolean flag = true;
		boolean err = false;
		//检查导入的字段标题
		try {
			List<String> realityCellllist=new ArrayList<String>();
			Row rowtitle=sheet.getRow(0);
			for (int j = 0; j < cellNum;j++) {
				realityCellllist.add(rowtitle.getCell(j).getStringCellValue());
			}
			String[] array =new String[realityCellllist.size()];
			if(!UTExcel.excelValidateByCell(cellArray, realityCellllist.toArray(array))){
				flag = false;
			}
		} catch (Exception e) {
			flag = false;
			sb.append("导入失败，请选择正确的模板！");
			return true;
		}
		
		if(!flag) {
			sb.append("导入失败，请选择正确的模板！");
			return true;
		}
		
		Map<String,Object> userParam = new HashMap<String,Object>();
		userParam.put("state", "1");
		userParam.put("userType", "1");
		//查询甲方人员
		List<UTMap<String,Object>> userMap = sysUserService.getUserBaseInfo(userParam);
		for (int i = 1; i <= rowNum; i++) {
			// 遍历excel
			Row row = sheet.getRow(i);
			UTMap<String, Object> map = new UTMap<String, Object>();
			for (int j = 0; j < cellNum; j++) {
				String cellvalue = null;
				flag = true;
				Cell cell = row.getCell(j);
				if (cell != null) {
					cell.setCellType(Cell.CELL_TYPE_STRING);
					cellvalue = cell.getStringCellValue();
					cellvalue = (cellvalue == null) ? "" : cellvalue.trim();
					if ((cellvalue == null) ? false : (cellvalue.length() > 0)) {
						//长度校验
						if (lengthArr[j] != 0 && cellvalue.length() > lengthArr[j]){
							err = true;
							sb.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "内容长度超出限制，请检查！" + "<br>");
						}
					}
					if (StringUtils.equals(IAssetPhysicalDao.FIELD_SERIALNUM,
							fileds[j]) && ((cellvalue == null) ? false : (cellvalue.length() > 0))) {
						UTMap<String, Object> mapUt = assetPhysicalDao.getAssetBySerialNum(cellvalue);
			    		if(mapUt == null){
			    			err = true;
			    			sb.append("Excel内容错误，行号为" + (i + 1) + "的资产序列号不存在！<br>");
			    		}
					}
					
					if (StringUtils.equals(IAssetPhysicalDao.FIELD_CODE,
							fileds[j]) && ((cellvalue == null) ? false : (cellvalue.length() > 0))) {
						Map mapUt = new HashMap();
						mapUt.put("codeNum", cellvalue);
			    		if(super.isExist(mapUt)){
			    			err = true;
			    			sb.append("Excel内容错误，行号为" + (i + 1)+ "的资产编号已经存在！<br>");
			    		}
					}
				}
				//检查空
				if(j == 0) {
					flag = (cellvalue == null) ? false : (cellvalue.length() > 0);
					if (!flag) {
						err = true;
		    			sb.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "内容为空，请检查！<br>");
					}
				}
				map.put(fileds[j], cellvalue);
			}
			leadinginList.add(map);
		}
		return err;
	}

	private boolean checkfileds(Sheet sheet, String[] cellArray, String[] fileds, StringBuilder sb, 
			List<UTMap<String, Object>> leadinginList, List<Map<String, Object>> maps, int[] lengthArr)
	{
		int rowNum = sheet.getLastRowNum();
		int cellNum = fileds.length;
		boolean flag = true;
		boolean err = false;
		//检查导入的字段标题
		try {
			List<String> realityCellllist=new ArrayList<String>();
			Row rowtitle=sheet.getRow(0);
			for (int j = 0; j < cellNum;j++) {
				realityCellllist.add(rowtitle.getCell(j).getStringCellValue());
			}
			String[] array =new String[realityCellllist.size()];
			if(!UTExcel.excelValidateByCell(cellArray, realityCellllist.toArray(array))){
				flag = false;
			}
		} catch (Exception e) {
			flag = false;
			sb.append("导入失败，请选择正确的模板！");
			return true;
		}
		
		if(!flag) {
			sb.append("导入失败，请选择正确的模板！");
			return true;
		}
		
		Map<String,Object> userParam = new HashMap<String,Object>();
		userParam.put("state", "1");
		userParam.put("userType", "1");
		//查询甲方人员
		List<UTMap<String,Object>> userMap = sysUserService.getUserBaseInfo(userParam);
		for (int i = 1; i <= rowNum; i++) {
			// 遍历excel
			Row row = sheet.getRow(i);
			UTMap<String, Object> map = new UTMap<String, Object>();
			//默认当前行的报废状态为false
			boolean isScrap = false;
			String parentId = null;
			
			for (int j = 0; j < cellNum; j++) {
				String cellvalue = null;
				//所属部门id
				Object orgId = null;
				flag = true;
				Cell cell = row.getCell(j);
				if (cell != null) {
					cell.setCellType(Cell.CELL_TYPE_STRING);
					cellvalue = cell.getStringCellValue();
					cellvalue = ((cellvalue == null) ? true : (cellvalue.length() == 0)) ? null : cellvalue.trim();
				}
				//检查空
				if(j == 2 || j == 3|| j == 4 || j == 5 || j == 11 || j == 12 || j == 16 || j == 29) {
					flag = (cellvalue == null) ? false : (cellvalue.length() > 0);
					if (!flag) {
						err = true;
						sb.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "内容为空，请检查！<br>");
					}
				}
				if (cellvalue != null) {
					//长度校验
					if (lengthArr[j] != 0 && cellvalue.length() > lengthArr[j]){
						err = true;
						sb.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "内容长度超出限制，请检查！" + "<br>");
					}
				}
				if (StringUtils.equals(IAssetPhysicalDao.FIELD_SERIALNUM,
						fileds[j]) && cellvalue != null) {
					UTMap<String, Object> mapUt = assetPhysicalDao.getAssetBySerialNum(cellvalue);
					if(mapUt != null){
						err = true;
						sb.append("Excel内容错误，行号为" +  (i + 1) + "的资产序列号已经存在！<br>");
					}
				}

				if (StringUtils.equals(IAssetPhysicalDao.FIELD_CODE,
						fileds[j]) && cellvalue != null) {
					Map mapUt = new HashMap();
					mapUt.put("codeNum", cellvalue);
					if(super.isExist(mapUt)){
						err = true;
						sb.append("Excel内容错误，行号为" +  (i + 1) + "的资产编号已经存在！<br>");
					}
				}

				if (StringUtils.equals(IAssetPhysicalDao.FIELD_ASSETSTATUS,
						fileds[j]) && cellvalue != null) {
					//判断报废状态
					List<UTMap<String, Object>> mapList = assetCategoryDao.getdictByDictName("资产状态");
					flag = false;
					for(UTMap<String, Object> dictType : mapList)
					{
						if(cellvalue.equals(dictType.get("name").toString()))
						{
							flag = true;
							cellvalue = dictType.get("value").toString();
							break;
						}
					}
					if(!flag)
					{
						err = true;
						sb.append("Excel内容错误，行号为" +  (i + 1) + "的"+ cellArray[j] + "录入类型不存在，请检查！<br>");
					}
					else
					{
						//是否是报废状态
						if("5".equals(cellvalue)){
							isScrap = true;
						}
					}
				}
				//判断报废日期
				if(StringUtils.equals(IAssetPhysicalDao.FIELD_SCRAPDATE, fileds[j])){
					if(isScrap){//判断报废日期
						if(StringUtils.isEmpty(cellvalue)){
							err = true;
							sb.append("Excel内容错误，行号为" +  (i + 1) + "的"+ cellArray[j] + "不能为空，请检查！<br>");
						}else{
							if(cellvalue != null)
							{
								if(!CommonUtils.isValidDate(cellvalue)){
									err = true;
									sb.append("Excel内容错误，行号为" +  (i + 1) + "的" + cellArray[j]+"格式不对，请检查！<br>");
								}
							}
						}
					}else{//否则报废日期为null
						cellvalue = null;
					}
				}
				if (StringUtils.equals(IAssetPhysicalDao.FIELD_CATEGORY,
						fileds[j])) {
					if(cellvalue != null)
					{
						Map<String,Object> category = new HashMap<String,Object>();
						category.put("name", cellvalue);
						cellvalue = assetAllocationlService.getCategoryIdByName(category);
						parentId = cellvalue;
						if(StringUtils.isEmpty(cellvalue)){
							err = true;
							sb.append("Excel内容错误，行号为" +  (i + 1) + "的资产大类在系统中不存在，请检查！<br>");
						}
					}
				}

				//判断资产小类
				if (StringUtils.equals(IAssetPhysicalDao.FIELD_SUBCATEGORY,
						fileds[j])) {
					if(cellvalue != null)
					{
						Map<String,Object> category = new HashMap<String,Object>();
						category.put("name", cellvalue);
						category.put("parentId", parentId);
						cellvalue = assetAllocationlService.getCategoryIdByName(category);
						if(StringUtils.isEmpty(cellvalue)){
							err = true;
							sb.append("Excel内容错误，行号为" +  (i + 1) + "的资产小类在系统中不存在，请检查！<br>");
						}
					}
				}

				if (StringUtils.equals(IAssetPhysicalDao.FIELD_ASSETS_LEVEL,
						fileds[j])) {
					if(cellvalue != null)
					{
						cellvalue = sysParamService.getParamValueByName("assetsLevel", cellvalue);
						if(StringUtils.isEmpty(cellvalue)){
							err = true;
							sb.append("Excel内容错误，行号为" + (i+1) + "的资产级别在系统中不存在，请检查！" + "<br>");
						}
					}
				}

				if (StringUtils.equals(IAssetPhysicalDao.FIELD_BUYCONTRACT,
						fileds[j])) {
					if(StringUtils.isNotEmpty(cellvalue)){
						try {
							cellvalue = getContractId(cellvalue,i,"采购合同");
						}catch(EscServiceException e) {
							err = true;
							sb.append(e.getMessage());
						}
					}
				}

				if (StringUtils.equals(IAssetPhysicalDao.FIELD_MAINTAINCONTRACT,
						fileds[j])) {
					if(StringUtils.isNotEmpty(cellvalue)){
						try {
							cellvalue = getContractId(cellvalue,i,"维保合同");
						}catch(EscServiceException e) {
							err = true;
							sb.append(e.getMessage());
						}
					}
				}

				if (StringUtils.equals(IAssetPhysicalDao.FIELD_LOCATION,
						fileds[j])) {
					if(StringUtils.isNotEmpty(cellvalue)){
						try {
							cellvalue = getPlaceId(cellvalue,i,"存放地点");
						}catch(EscServiceException e) {
							err = true;
							sb.append(e.getMessage());
						}
					}
				}


				//是否国产
				if (StringUtils.equals(IAssetPhysicalDao.FIELD_CONTROLLABLE, fileds[j]) ||
						StringUtils.equals(IAssetPhysicalDao.FIELD_ISPOSITIVE, fileds[j]) ||
						StringUtils.equals(IAssetPhysicalDao.FIELD_AUXILIARYASSET, fileds[j])) {
					if(cellvalue != null){
						if("是".equals(cellvalue)){
							cellvalue = "1";
						}else if("否".equals(cellvalue)){
							cellvalue = "0";
						}else{
							err = true;
							sb.append("Excel内容错误，行号为" +  (i + 1) + "的"+cellArray[j]+"格式不对，请检查！<br>");
						}
					}
					else
						cellvalue = "1";
				}

				if (StringUtils.equals(IAssetPhysicalDao.FIELD_HASBACKUP, fileds[j]) ||
						StringUtils.equals(IAssetPhysicalDao.FIELD_OTHERMAINT, fileds[j])||
						StringUtils.equals(IAssetPhysicalDao.FIELD_OWNSYSTEM, fileds[j])) {
					if(cellvalue != null){
						if("是".equals(cellvalue)){
							cellvalue = "1";
						}else if("否".equals(cellvalue)){
							cellvalue = "0";
						}else{
							err = true;
							sb.append("Excel内容错误，行号为" +  (i + 1) + "的" + cellArray[j] + "格式不对，请检查！<br>");
						}
					}
					else
						cellvalue = "0";
				}


				if (cellvalue != null && (StringUtils.equals(IAssetPhysicalDao.FIELD_MAINTSTARTDATE, fileds[j]) ||
						StringUtils.equals(IAssetPhysicalDao.FIELD_MAINTENDDATE, fileds[j]) ||
						StringUtils.equals(IAssetPhysicalDao.FIELD_ASSETSTARTDATE, fileds[j]) ||
						StringUtils.equals(IAssetPhysicalDao.FIELD_ASSETENDDATE, fileds[j]) ||
						StringUtils.equals(IAssetPhysicalDao.FIELD_MAINTASSETSTARTDATE, fileds[j])||
						StringUtils.equals(IAssetPhysicalDao.FIELD_MAINTASSETSENDDATE, fileds[j]) ||
						StringUtils.equals(IAssetPhysicalDao.FIELD_INBOUNDDATE, fileds[j]) ||
						StringUtils.equals(IAssetPhysicalDao.FIELD_PURCHASEDATE, fileds[j]))) {
					if(StringUtils.isEmpty(cellvalue)){
						cellvalue = null;
					}else if(!CommonUtils.isValidDate(cellvalue)){
						err = true;
						sb.append("Excel内容错误，行号为" +  (i + 1) + "的"+cellArray[j]+"格式不对，请检查！<br>");
					}
				}


				if(StringUtils.equals(IAssetPhysicalDao.FIELD_AMOUNT, fileds[j]) && StringUtils.isNotEmpty(cellvalue)) {
					flag = UTExcelValidate.validateNumber(cellvalue);
					if (!flag) {
						err = true;
						sb.append("Excel内容错误，行号为" +  (i + 1) + "的"+ cellArray[j] + "格式不对，请检查！<br>");
					}
				}

				//保密性
				if(StringUtils.equals(IAssetPhysicalDao.FIELD_CONFIDENTIALITY,
							fileds[j])) {
					if(cellvalue != null){
						List<UTMap<String, Object>> mapList = assetCategoryDao.getdictByDictName("保密性");
						flag = false;
						for(UTMap<String, Object> dictType : mapList)
						{
							if(cellvalue.equals(dictType.get("name").toString()))
							{
								flag = true;
								cellvalue = dictType.get("value").toString();
								break;
							}
						}
						if(!flag)
						{
							err = true;
							sb.append("Excel内容错误，行号为" +  (i + 1) + "的"+ cellArray[j] + "录入类型不存在，请检查！<br>");
						}
					}
				}

				//完整性
				if(StringUtils.equals(IAssetPhysicalDao.FIELD_INTEGRITY,
							fileds[j])) {
					if((cellvalue == null) ? false : (cellvalue.length() > 0)){
						List<UTMap<String, Object>> mapList = assetCategoryDao.getdictByDictName("完整性");
						flag = false;
						for(UTMap<String, Object> dictType : mapList)
						{
							if(dictType.get("name") != null)
							{
								if(dictType.get("name").toString().equals(cellvalue))
								{
									flag = true;
									cellvalue = dictType.get("value").toString();
									break;
								}
							}
						}
						if(!flag)
						{
							err = true;
							sb.append("Excel内容错误，行号为" +  (i + 1) + "的"+ cellArray[j] + "录入类型不存在，请检查！<br>");
						}
					}
				}

				//可用性
				if(StringUtils.equals(IAssetPhysicalDao.FIELD_AVAILABILITY,
							fileds[j])) {
					if(cellvalue != null){
						List<UTMap<String, Object>> mapList = assetCategoryDao.getdictByDictName("可用性");
						flag = false;
						for(UTMap<String, Object> dictType : mapList)
						{
							if(cellvalue.equals(dictType.get("name").toString()))
							{
								flag = true;
								cellvalue = dictType.get("value").toString();
								break;
							}
						}
						if(!flag)
						{
							err = true;
							sb.append("Excel内容错误，行号为" +  (i + 1) + "的"+ cellArray[j] + "录入类型不存在，请检查！<br>");
						}
					}
				}
				if(StringUtils.equals(IAssetPhysicalDao.FIELD_ASSETPRICE, fileds[j]) && cellvalue != null) {
						flag = UTExcelValidate.validateNumber(cellvalue);
						if (!flag) {
							err = true;
							sb.append("Excel内容错误，行号为" +  (i + 1) + "的"+ cellArray[j] + "格式不对，请检查！<br>");
						}
				}
				if(StringUtils.equals(IAssetPhysicalDao.FIELD_MAINTENANCE_AMOUNT, fileds[j]) && cellvalue != null) {
					flag = UTExcelValidate.validateNumber(cellvalue);
					if (!flag) {
						err = true;
						sb.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "格式不对，请检查！<br>");
					}
				}
				
				if (StringUtils.equals(IAssetPhysicalDao.FIELD_RESUSERID,
						fileds[j]) && StringUtils.isNotEmpty(cellvalue)) {
					try{
						cellvalue = CommonUtils.getIdsByUserNameAndCodes(userMap, cellvalue);
						if (StringUtils.isNotEmpty(cellvalue)) {
							UTMap<String, Object> userInfo = sysUserService.getById(cellvalue);
							if (null != userInfo && !userInfo.isEmpty()) {
								orgId = userInfo.get("orgId");
							}
						}
					}catch(EscServiceException ex){
						err = true;
						sb.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "列，"+ex.getMessage() + "<br>");
					}
				}

				/*if (StringUtils.equals(IAssetPhysicalDao.FIELD_RESDEPARTID,
						fileds[j])) {
					if(cellvalue != null){
						if(cellvalue.contains("/")){
							cellvalue=cellvalue.replaceAll("!","/");
							String orgId=orgDao.getIdLongName(cellvalue);
							if (StringUtils.isEmpty(orgId)) {
								err = true;
								sb.append("Excel内容错误，行号为" + (i + 1) + "的所属部门在系统中不存在，请检查！<br>");
							}else {
								cellvalue = orgId;
							}
						}else{
							String orgId=orgDao.getIdLongName(cellvalue);
							if (StringUtils.isEmpty(orgId)) {
								err = true;
								sb.append("Excel内容错误，行号为" + (i + 1) + "的所属部门在系统中不存在，请检查！<br>");
							}else {
								cellvalue = orgId;
							}
						}
					}
				}*/

				if(maps != null)
				{
					//检查附加字段
					for(Map<String, Object> item : maps)
					{
						if(StringUtils.equals(item.get("attId").toString(), fileds[j]))
						{
							flag = StringUtils.isEmpty(cellvalue) ? false : true;
							if (!flag) {
								if("true".equals(item.get("required").toString()))
								{
									err = true;
					    			sb.append("Excel内容错误，行号为" + (i + 1)+ "的"+ cellArray[j] + "内容为空，请检查！<br>");
								}
								else
								{
									if("date".equals(item.get("type").toString()) 
											|| "int".equals(item.get("type").toString()))
									{
										cellvalue = null;
									}
								}
							}
							else {
								if("date".equals(item.get("type").toString()) && cellvalue != null)
								{
									flag = CommonUtils.isValidDate(cellvalue);
					        		if (!flag) {
										err = true;
						    			sb.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "格式不对，请检查！<br>");
									}
								}
								else if("dateTime".equals(item.get("type").toString()) && cellvalue != null)
								{
									flag = CommonUtils.isValidDateTime(cellvalue);
					        		if (!flag) {
										err = true;
						    			sb.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "格式不对，请检查！<br>");
									}
								}
					        	else if("int".equals(item.get("type").toString()) && cellvalue != null)
					        	{
					        		flag = CommonUtils.isValidateInteger(cellvalue);
					        		if (!flag) {
										err = true;
						    			sb.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "格式不对，请检查！<br>");
									}
					        		else
									{
						        		if(item.get("max") != null && cellvalue != null)
						        		{
						        			if(cellvalue.length() > item.get("max").toString().length() || Integer.parseInt(item.get("max").toString()) < Integer.parseInt(cellvalue))
						        			{
						        				err = true;
												sb.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "输入数值超出最大值！<br>");
											
						        			}
						        		}
						        		if(item.get("min") != null && cellvalue != null)
						        		{
						        			if(cellvalue.length() < item.get("min").toString().length() || Integer.parseInt(item.get("min").toString()) > Integer.parseInt(cellvalue))
						        			{
						        				err = true;
												sb.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "输入数值小于最小值！<br>");
											
						        			}
						        		}
									}
					        	}
					        	else if("double".equals(item.get("type").toString()) && cellvalue != null)
					        	{
					        		flag = CommonUtils.isValidateDouble(cellvalue);
					        		if (!flag) {
										err = true;
						    			sb.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "格式不对，请检查！<br>");
									}
					        		else
									{
						        		if(item.get("max") != null)
						        		{
						        			if(Double.parseDouble(item.get("max").toString()) < Double.parseDouble(cellvalue))
						        			{
						        				err = true;
												sb.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "输入数值超出最大值！<br>");
											
						        			}
						        		}
						        		if(item.get("min") != null)
						        		{
						        			if(Double.parseDouble(item.get("min").toString()) > Double.parseDouble(cellvalue))
						        			{
						        				err = true;
												sb.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "输入数值小于最小值！<br>");
											
						        			}
						        		}
									}
					        	}
					        	else if("select".equals(item.get("type").toString()) && cellvalue != null)
					        	{
					        		List<UTMap<String, Object>> mapList = assetCategoryDao.getdictByDictType(item.get("dict").toString());
					        		
					        		for(UTMap<String, Object> dictType : mapList)
					        		{
					        			if(cellvalue.equals(dictType.get("name").toString()))
					        			{
					        				flag = false;
					        				cellvalue = dictType.get("value").toString();
					        				break;
					        			}
					        		}
					        		if(flag)
					        		{
					        			err = true;
						    			sb.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "录入类型不存在，请检查！<br>");
					        		}
					        	}
					        	else if("treeSelect".equals(item.get("type").toString()))
					        	{
					        		try{
										cellvalue = CommonUtils.getIdsByUserNameAndCodes(userMap, cellvalue);
									}catch(EscServiceException ex){
										err = true;
						    			sb.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "列，"+ex.getMessage() + "<br>");
									}
					        	}
					        	else if("multiSelect".equals(item.get("type").toString()) && cellvalue != null)
					        	{
					        		List<UTMap<String, Object>> mapList = assetCategoryDao.getdictByDictType(item.get("dict").toString());
					        		String[] tempValue;
					        		String[] tempValue1 = cellvalue.split("，");//中文逗号
					        		String[] tempValue2 = cellvalue.split(",");//英文逗号
					        		if(tempValue1.length > tempValue2.length)
					        			tempValue = tempValue1;
					        		else
					        			tempValue = tempValue2;
					        		int n = 0;
				        			for(String value : tempValue)
				        			{
				        				boolean ret = false;
				        				for(UTMap<String, Object> dictType : mapList)
						        		{
				        					if(value.equals(dictType.get("name").toString()))
						        			{
				        						if(n == 0)
				        							cellvalue = dictType.get("value").toString();
				        						else
				        							cellvalue += "," + dictType.get("value").toString();
				        						ret = true;
						        				break;
						        			}
						        		}
				        				if(!ret)
				        				{
				        					flag = false;
				        					break;
				        				}
				        				n++;
				        			}
					        		
					        		if(!flag)
					        		{
					        			err = true;
						    			sb.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "录入类型不存在，请检查！<br>");
					        		}
					        	}
							}
							break;
						}
					}
				}
				map.put(fileds[j], cellvalue);
				if (StringUtils.equals(IAssetPhysicalDao.FIELD_RESUSERID, fileds[j]) && null != orgId && StringUtils.isNotEmpty(orgId.toString())) {
					map.put("resDepartId", orgId);
				}
			}
			map.put("sortCode", assetPhysicalDao.getNewCode(101, "sortCode"));
			leadinginList.add(map);
		}
		return err;
	}
	
	@Override
	public boolean leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String[] fileds = new String[] { 
				IAssetPhysicalDao.FIELD_NAME,
				IAssetPhysicalDao.FIELD_CODE,
				IAssetPhysicalDao.FIELD_CATEGORYNAME,
				IAssetPhysicalDao.FIELD_SUBCATEGORYNAME,
				IAssetPhysicalDao.FIELD_ASSETS_LEVEL,
				"buyContractName",
				IAssetPhysicalDao.FIELD_MAINTASSETSTARTDATE,
				IAssetPhysicalDao.FIELD_MAINTASSETSENDDATE,
				IAssetPhysicalDao.FIELD_SERIALNUM,
				"location",
				IAssetPhysicalDao.FIELD_PRODUCER,
				IAssetPhysicalDao.FIELD_INBOUNDDATE,
				IAssetPhysicalDao.FIELD_MODEL,
				IAssetPhysicalDao.FIELD_CONFIDENTIALITY,
				IAssetPhysicalDao.FIELD_INTEGRITY,
				IAssetPhysicalDao.FIELD_AVAILABILITY
		};
		String tamlate="excelOutTamplate.assetPhysical";

		Map<String, String> fieldAndParamType = new HashMap<>();
		fieldAndParamType.put(IAssetPhysicalDao.FIELD_INTEGRITY, "integrity");
		fieldAndParamType.put(IAssetPhysicalDao.FIELD_CONFIDENTIALITY, "confidentiality");
		fieldAndParamType.put(IAssetPhysicalDao.FIELD_AVAILABILITY, "availability");
		fieldAndParamType.put(IAssetPhysicalDao.FIELD_ASSETS_LEVEL, "assetsLevel");
		sysParamService.changeParamData(data, fieldAndParamType, ",", null);
		if (null != data && !data.isEmpty()) {
			for (int i=0;i<data.size();i++) {
				UTMap<String, Object> item = (UTMap<String, Object>) data.get(i);
				item.put(IAssetPhysicalDao.FIELD_MAINTASSETSTARTDATE, 
						CommonUtils.replaceAll((String)item.get(IAssetPhysicalDao.FIELD_MAINTASSETSTARTDATE), "-", "/"));
				item.put(IAssetPhysicalDao.FIELD_MAINTASSETSENDDATE, 
						CommonUtils.replaceAll((String)item.get(IAssetPhysicalDao.FIELD_MAINTASSETSENDDATE), "-", "/"));
				item.put(IAssetPhysicalDao.FIELD_INBOUNDDATE, 
						CommonUtils.replaceAll((String)item.get(IAssetPhysicalDao.FIELD_INBOUNDDATE), "-", "/"));
			}
		}
		
		return	UTExcel.leadingout( fileds, data, tamlate, request,response);
	}

	@Override
	public List<UTMap<String, Object>> getAssetsList(Map param) {
		return assetPhysicalDao.getAssetsList(param);
	}

	@Override
	public boolean updateInfoByIds(String location, String resUserId,
			String resDepartId, String ids) {
		return assetPhysicalDao.updateInfoByIds(location, resUserId, resDepartId, ids);
	}
	
	private String getContractId(String contractNameAndContractCodes, int lineNum, String title) {
		Map<String, Object> param = new HashMap<String, Object>();
		String returnIds = "";
		String tip = "Excel内容错误，行号为" + (lineNum + 1) + "的" + title;
		try {
			if((contractNameAndContractCodes == null) ? false : (contractNameAndContractCodes.length() > 0)) {
				for (String contractNameAndContractCode : StringUtils.split(contractNameAndContractCodes, ",")) {
//					if(StringUtils.indexOf(contractNameAndContractCode, "/") != -1) {
						String[] nameAndCode = contractNameAndContractCode.split("/", 2);
						String name = nameAndCode[0];
						String code = "";
						if(nameAndCode.length == 2) {
							code = nameAndCode[1];
						}
						
						List<UTMap<String, Object>> contracts = null;
						param.clear();
						if(StringUtils.isNotEmpty(name)){
							param.put("agreementName", name);
						}
						if(StringUtils.isNotEmpty(code)){
							param.put("agreementCode", code);
						}
						contracts = assetsAgreementInfoService.getListMaps(param, "id");
						if(contracts == null || contracts.size() == 0) {
							throw new EscServiceException(tip + ":"
									+ contractNameAndContractCode
									+"在系统中不存在，请检查！");
						}
						if(contracts.size() > 1) {
							throw new EscServiceException(tip + ":系统存在重名的合同【"+contractNameAndContractCode+"】，无法匹配，请在合同后面加入合同编号，用/符号隔开！");
						}
						UTMap<String, Object> contract = contracts.get(0);
						
						if((returnIds == null) ? false : (returnIds.length() > 0)) {
							returnIds += ",";
						}
						returnIds += (String) contract.get("id");
				}
			}
		} catch (EscServiceException e) {
			throw e;
		} catch (Exception e) {
			logger.error("Exception",e);
			throw new EscServiceException(tip + "格式不对，请检查！");
		}

		return returnIds;
	}
	
	private String getPlaceId(String placeNameAndplaceCodes, int lineNum, String title) {
		Map<String, Object> param = new HashMap<String, Object>();
		String returnIds = "";
		String tip = "Excel内容错误，行号为" + (lineNum + 1) + "的" + title;
		try {
			if((placeNameAndplaceCodes == null) ? false : (placeNameAndplaceCodes.length() > 0)) {
				for (String placeNameAndplaceCode : StringUtils.split(placeNameAndplaceCodes, ",")) {
//					if(StringUtils.indexOf(placeNameAndplaceCode, "/") != -1) {
						String[] nameAndCode = placeNameAndplaceCode.split("/", 2);
						String name = nameAndCode[0];
						String code = "";
						if(nameAndCode.length == 2) {
							code = nameAndCode[1];
						}
						
						List<UTMap<String, Object>> places = null;
						param.clear();
						if(StringUtils.isNotEmpty(name)){
							param.put("name", name);
						}
						if(StringUtils.isNotEmpty(code)){
							param.put("code", code);
						}
						places = assetPlaceService.getListMaps(param, "id");
						if(places == null || places.size() == 0) {
							throw new EscServiceException(tip + ":"
									+ placeNameAndplaceCode
									+"在系统中不存在，请检查！");
						}
						logger.info("----------输入的存放地点：" + placeNameAndplaceCode);
						String selectPlace = "";
						for (UTMap<String, Object> p : places) {
							selectPlace += p.get("id") + ",";
						}
						logger.info("----------根据入场的存放地点名称查询到的地址id：" + selectPlace);
						if(places.size() > 1) {
							throw new EscServiceException(tip + ":系统存在重名的存放地点【"+placeNameAndplaceCode+"】，无法匹配，请在地点后面加入地点编号，用/符号隔开！");
						}
						UTMap<String, Object> place = places.get(0);
						
						if((returnIds == null) ? false : (returnIds.length() > 0)) {
							returnIds += ",";
						}
						returnIds += (String) place.get("id");
				}
			}
		} catch (EscServiceException e) {
			throw e;
		} catch (Exception e) {
			logger.error("Exception",e);
			throw new EscServiceException(tip + "格式不对，请检查！");
		}

		return returnIds;
	}

	@Override
	public boolean updateByIds(Map param) {
		String ids = (String)param.get("ids");
		Map<String, Object> ut = new HashMap<>();
		if(null != param.get("changeField") && "1".equals(String.valueOf( param.get("changeField")))){
			ut.put("resUserId", param.get("resUserId"));
		}else if(null != param.get("changeField") && "2".equals(String.valueOf( param.get("changeField")))){
			ut.put("resDepartId", param.get("resDepartId"));
		}else if(null != param.get("maintainContract")){
			ut.put("maintainContract",param.get("maintainContract"));
//		}else if(null != param.get("location")){
//			ut.put("location",param.get("location"));
		}else if(null != param.get("deleteFlag")){
			ut.put("deleteFlag",param.get("deleteFlag"));
		}
//		if(param.get("deleteFlag") != null){
//			ut.put("deleteFlag",param.get("deleteFlag"));
//		}
		boolean flag = false;
		String[] updateIds = ids.split(",");
//		param.remove("ids");
		if(updateIds.length > 0){
			for (String id : updateIds) {
				ut.put("id", id);
				flag = getOptionDao().updateById(ut);
				if(param.get("deleteFlag")!= null && "1".equals(param.get("deleteFlag")+"")){//如果是删除操作，需要释放U
					assetPlaceDao.relievePlaceU(id);
				}
			}
		}
	return flag;
	}


	@Override
	public List<UTMap<String, Object>> getAssetBycodeAndId(String code,
			String id) {
		return assetPhysicalDao.getAssetBycodeAndId(code, id);
	}

	@Override
	public UTMap<String, Object> getAssetById(String id) {
		return assetPhysicalDao.getAssetById(id);
	}
	
	@Override
	public boolean updateOutdateById(String id) {
		return assetPhysicalDao.updateOutdateById(id);
	}

	@Override
	public boolean updateAssetStatusById(String id, String status) {
		return assetPhysicalDao.updateAssetStatusById(id, status);
	}
	
	@Override
	public boolean updateTotalPriceById(String id, String beforePrice,
			String nowPrice) {
		return assetPhysicalDao.updateTotalPriceById(id, beforePrice, nowPrice);
	}

	@Override
	public boolean updateAuxiliaryById(String id) {
		return assetPhysicalDao.updateAuxiliaryById(id);
	}

	@Override
	public String saveOrUpdate(Map<String, Object> map) throws Exception{
		//分成两部分保存，一部分是资产的公共属性，一部分是资产的特有属性
		Map<String, Object> mainMap = (Map<String, Object>)map.get("formDataMain");
		Map<String, Object> extMap = (map.get("formData") == null || map.size()<1)?null : (Map<String, Object>)map.get("formData");
		List<Map> sparePartList =  (List<Map>) mainMap.get("sparePartList");
		String codeNum = (String)mainMap.get("codeNum");
		String id = (String)mainMap.get("id");
		String serialNum = (String)mainMap.get("serialNum");
		mainMap.put("deleteFlag", 0);
		//判断报废状态
		String assetStatus = mainMap.get("assetStatus")!= null ? (mainMap.get("assetStatus")+"") : null;
		if("5".equals(assetStatus)){
			mainMap.put("isScrap", 1);
		}else{//不是报废状态，则需要清除报废日期
			mainMap.remove("scrapDate");
			mainMap.put("isScrap", 0);
		}
		boolean flag = false;
		if(id == null){
			Map param = new HashMap();
			if(CommonUtils.notNullStrOrEmpty(codeNum)){
				param.put("codeNum", codeNum);
				if(this.isExist(param)){
					throw new EscServiceException("资产编号已经存在！");
				}
			}
			//判断资产序列号是否为空
			param.clear();
			if(CommonUtils.notNullStrOrEmpty(serialNum)){
				param.put("serialNum", serialNum);
				param.put("deleteFlag", 0);
				if(this.isExist(param)){
					throw new EscServiceException("资产序列号已经存在！");
				}
			}
			//关于sn号
			mainMap.put("sn",this.getSnNum());
			//从参数中获取sn号，并回去修改sn号，此方法必须同步
			//关于编码值
			mainMap.put("code", mainMap.get("sn"));
			flag = this.add(mainMap);
			id = (String) mainMap.get("id");//添加后获取id的值

		}else{
			if(StringUtils.isNotEmpty(codeNum)){
				List<UTMap<String,Object>> names = this.getAssetBycodeAndId(codeNum,id);
				if(null != names && names.size() > 0){
					throw new EscServiceException("资产编号已经存在！");
				}
			}
			if(CommonUtils.notNullStrOrEmpty(serialNum) && assetPhysicalDao.isExitSerialNum(serialNum, id)){
				throw new EscServiceException("资产序列号已经存在！");
			}
			//如果传过来的registStatus存在且为
			flag = this.updateById(mainMap);
		}
		if(flag){
			this.deleteSparesById((String)mainMap.get("id"));//先删除关联再重新添加关联
			if(null != sparePartList && sparePartList.size() > 0){
				for (Map sparePart : sparePartList) {
					UTMap<String, Object> ut = new UTMap<String,Object>();
					ut.put("assetsId", mainMap.get("id"));
					ut.put("backupId", sparePart.get("id"));

					this.addRelation(ut);
				}
			}
		}

		//进行机柜的操作选择
		//如果id不为空，则把和此资产相关的机柜都修改一遍，将关联删除，再添加关联
		if(id != null){
			assetPlaceDao.relievePlaceU(id);
		}
		//对前端过来的机柜数据进行验证，
		String location = (String)mainMap.get("location");//机柜id
		String CabinetStartU = (String)mainMap.get("CabinetStartU");//机柜开始U
		String CabinetEndU = (String)mainMap.get("CabinetEndU");//机柜结束U
		if(((CabinetEndU == null) ? false : (CabinetEndU.length() > 0)) && ((CabinetStartU == null) ? false : (CabinetStartU.length() > 0))){
			//判断开始到结束的机柜是否被占用，如果被占用，则提示
			String occupyPlaceU = assetPlaceDao.getOccupyPlaceU(location, Integer.parseInt(CabinetStartU),
					Integer.parseInt(CabinetEndU));
			if((occupyPlaceU == null) ? false : (occupyPlaceU.length() > 0)){
				throw new EscServiceException("机柜"+occupyPlaceU+"已被占用，请选择其他机柜！");
			}
			//机柜未被占用，则将这些机柜U和资产关联
			assetPlaceDao.bindingsPlaceU(location, id,Integer.parseInt(CabinetStartU),Integer.parseInt(CabinetEndU));
		}
		//这个时候再重新添加额外属性
		String assetsInfoId = (String)mainMap.get("id");
		String categoryId = (String)mainMap.get("category");
		//资产可以获取唯一额外属性
		//先删除后添加
		assetPhysicalDao.deleteAttrValueByInfoId(assetsInfoId);
		if(extMap != null && extMap.size() > 0){//如果额外属性不为空
			List<UTMap<String, Object>> attrvalueMapList = new ArrayList<>();
			int i = 0;
			for(String s :extMap.keySet()){
				UTMap<String, Object> attrValueMap = new UTMap<>();
				attrValueMap.put("attId",s);
				attrValueMap.put("attValue",extMap.get(s));
				attrValueMap.put("assetsInfoId",assetsInfoId);
				attrValueMap.put("sort",++i);
				attrvalueMapList.add(attrValueMap);
			}
			assetCategoryDao.saveAttrValueList(attrvalueMapList);
		}
		return UTJsonUtils.getJsonMsg(true, "操作成功");

	}

	@Override
	public String deletePhysical(Map<String, Object> param) {
		assetPhysicalDao.updateById(param);
		String id = (String)param.get("id");
		//还要解除机柜的占用
		assetPlaceDao.relievePlaceU(id);
		return UTJsonUtils.getJsonMsg(true, "操作成功");
	}

	@Override
	public void transformData(List<UTMap<String, Object>> data) {
		//初始方案，循环获取数据，然后组装数据
		//替换下拉的值
		Map<String, String> fieldAndParamType = new HashMap<>();
		if(data != null && data.size() > 0){
			for(UTMap<String, Object> map : data){
				//根据资产id和资产分类获取所有的额外属性值
				List<UTMap<String, Object>> attrValueList = assetCategoryDao.getAttrValue((String)map.get("id"));
				if(attrValueList != null && attrValueList.size() > 0){
					for(UTMap<String, Object> attrValueMap : attrValueList){
						if("multiSelect".equals(attrValueMap.get("type")) || "select".equals(attrValueMap.get("type"))){
							//类型为单选和多选时表示从参数中获取的值，
							fieldAndParamType.put((String)attrValueMap.get("attId"), (String)attrValueMap.get("dict"));
						}
						if("treeSelect".equals(attrValueMap.get("type"))){//为用户单选树
                            if(CommonUtils.notNullStrOrEmpty((String) attrValueMap.get("attValue"))){
                                UTMap<String, Object> user = sysUserService.getById((String) attrValueMap.get("attValue"));
                                if(user != null){
                                    attrValueMap.put("attValue", user.get("name")+"/"+user.get("code"));
                                }
                            }

						}
						//将所得的额外参数一个个加进原来的data
						map.put((String)attrValueMap.get("attId"), CommonUtils.replaceAll((String)attrValueMap.get("attValue"), "-", "/"));

					}
				}
				map.put("category", map.get("categoryName"));
				map.put("subCategory", map.get("subCategoryName"));
				map.put("supplierId", map.get("assetSupplierName"));
				map.put("businessSystemLeader", map.get("businessSystemLeaderName"));
				map.put("EquipmentLeader", map.get("EquipmentLeaderName"));
				map.put("resUserId",map.get("resUserName"));
				//计算资产总价
//				Map param2 = new HashMap();
//				param2.put("parentId", map.get("id"));
//				List<UTMap<String, Object>> auxiliaryList = getListMaps(param2); //辅资产
//
//				float total = Float.parseFloat(map.get("assetPrice") != null ? map.get("assetPrice").toString() : "0" );
//				for (UTMap<String, Object> aux : auxiliaryList) {
//					total+=Float.parseFloat(aux.get("assetPrice")!= null ? aux.get("assetPrice").toString() : "0");
//				}
//				map.put("totalAssets", total);
			}
		}
		//再组装原来的值
		fieldAndParamType.put(IAssetPhysicalDao.FIELD_ASSETSTATUS, "assetsStatus");
//		fieldAndParamType.put(IAssetPhysicalDao.FIELD_IP, "IP");
//		fieldAndParamType.put(IAssetPhysicalDao.FIELD_EQUIPMENTUSE, "EquipmentUse");
//		fieldAndParamType.put(IAssetPhysicalDao.FIELD_SYSTEMNAME, "systemName");
		fieldAndParamType.put(IAssetPhysicalDao.FIELD_SYSTEMCLASS, "systemClass");
		fieldAndParamType.put(IAssetPhysicalDao.FIELD_ASSETSTYPE, "assetsType");
		fieldAndParamType.put(IAssetPhysicalDao.FIELD_INTEGRITY, "integrity");
		fieldAndParamType.put(IAssetPhysicalDao.FIELD_CONFIDENTIALITY, "confidentiality");
		fieldAndParamType.put(IAssetPhysicalDao.FIELD_AVAILABILITY, "availability");
		fieldAndParamType.put(IAssetPhysicalDao.FIELD_ISPOSITIVE, "YesNo");
		fieldAndParamType.put(IAssetPhysicalDao.FIELD_CONTROLLABLE, "YesNo");
		fieldAndParamType.put(IAssetPhysicalDao.FIELD_OWNSYSTEM, "YesNo");
		fieldAndParamType.put(IAssetPhysicalDao.FIELD_HASBACKUP, "YesNo");
		fieldAndParamType.put(IAssetPhysicalDao.FIELD_AUXILIARYASSET, "YesNo");
		fieldAndParamType.put(IAssetPhysicalDao.FIELD_OTHERMAINT, "YesNo");
		fieldAndParamType.put(IAssetPhysicalDao.FIELD_ISSCRAP, "YesNo");
		fieldAndParamType.put(IAssetPhysicalDao.FIELD_ASSETS_LEVEL, "assetsLevel");
		sysParamService.changeParamData(data, fieldAndParamType, ",", null);
		
		if (null != data && !data.isEmpty()) {
			for (int i=0;i<data.size();i++) {
				UTMap<String, Object> item = data.get(i);
				item.put(IAssetPhysicalDao.FIELD_MAINTASSETSTARTDATE,
						CommonUtils.replaceAll((String)item.get(IAssetPhysicalDao.FIELD_MAINTASSETSTARTDATE), "-", "/"));
				item.put(IAssetPhysicalDao.FIELD_MAINTASSETSENDDATE, 
						CommonUtils.replaceAll((String)item.get(IAssetPhysicalDao.FIELD_MAINTASSETSENDDATE), "-", "/"));
				item.put(IAssetPhysicalDao.FIELD_ASSETSTARTDATE, 
						CommonUtils.replaceAll((String)item.get(IAssetPhysicalDao.FIELD_ASSETSTARTDATE), "-", "/"));
				item.put(IAssetPhysicalDao.FIELD_ASSETENDDATE, 
						CommonUtils.replaceAll((String)item.get(IAssetPhysicalDao.FIELD_ASSETENDDATE), "-", "/"));
				item.put(IAssetPhysicalDao.FIELD_PURCHASEDATE, 
						CommonUtils.replaceAll((String)item.get(IAssetPhysicalDao.FIELD_PURCHASEDATE), "-", "/"));
				item.put(IAssetPhysicalDao.FIELD_INBOUNDDATE, 
						CommonUtils.replaceAll((String)item.get(IAssetPhysicalDao.FIELD_INBOUNDDATE), "-", "/"));
				item.put(IAssetPhysicalDao.FIELD_MAINTSTARTDATE, 
						CommonUtils.replaceAll((String)item.get(IAssetPhysicalDao.FIELD_MAINTSTARTDATE), "-", "/"));
				item.put(IAssetPhysicalDao.FIELD_MAINTENDDATE, 
						CommonUtils.replaceAll((String)item.get(IAssetPhysicalDao.FIELD_MAINTENDDATE), "-", "/"));
				item.put(IAssetPhysicalDao.FIELD_SCRAPDATE, 
						CommonUtils.replaceAll((String)item.get(IAssetPhysicalDao.FIELD_SCRAPDATE), "-", "/"));
				item.put(IAssetPhysicalDao.FIELD_PREBORROWASSETSSTARTDATE, 
						CommonUtils.replaceAll((String)item.get(IAssetPhysicalDao.FIELD_PREBORROWASSETSSTARTDATE), "-", "/"));
				item.put(IAssetPhysicalDao.FIELD_PREBORROWASSETSENDDATE, 
						CommonUtils.replaceAll((String)item.get(IAssetPhysicalDao.FIELD_PREBORROWASSETSENDDATE), "-", "/"));
			}
		}
	}

	@Override
	public synchronized  String getSnNum() {
	    //放到try catch中，脱离事务，不回滚 防止出现重复
	    try{
            Map<String, Object> params = new HashMap<>();
            params.put("paramType", "snNum");
            List<UTMap<String, Object>> paramsList = sysParamDao.getListMaps(params);
            if(paramsList != null && paramsList.size() > 0){
                UTMap<String, Object> pa = paramsList.get(0);
                Integer num =  Integer.valueOf((String) pa.get("value"));
                //修改num
                pa.put("value", (num+1));

                sysParamDao.updateById(pa);
                //return String.format("%08x", num);
                return CommonUtils.toHexStr(num + "");
            }
        }catch (Exception e){

        }

		return "";
	}

	@Override
	public boolean isExistParam(Map<String, Object> params) {
		return assetPhysicalDao.isExistParam(params);
	}


}