package com.esc.oms.asset.agreement.dao;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

import java.util.List;
import java.util.Map;

public interface IAssetsAgreementInfoDao extends IBaseOptionDao{
	
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_AGREEMENT_NAME = "agreementName";
	public static final String  FIELD_AGREEMENT_CODE = "agreementCode";
	public static final String  FIELD_TYPE = "type";
	public static final String  FIELD_SUPPLIER_NAME = "supplierName";
	public static final String  FIELD_BEGIN_TIME = "beginTime";
	public static final String  FIELD_END_TIME = "endTime";
	public static final String  FIELD_AGREEMENT_STATUS = "agreementStatus";
	public static final String  FIELD_IS_WARN = "isWarn";
	public static final String  LEFT_NUM = "leftNum";
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params);


	public List<UTMap<String, Object>> getAgreementList(
			Map<String, Object> params);
	
	/**
	 * 获取需要到期提醒的资产合同列表
	 * @return
	 */
	public List<UTMap<String,Object>> getWarnAgreementList();

	/**
	 * 根据ids获取所有的合同
	 * @param ids
	 * @return
	 */
	public List<UTMap<String, Object>> getListByIds(String ids);
}
