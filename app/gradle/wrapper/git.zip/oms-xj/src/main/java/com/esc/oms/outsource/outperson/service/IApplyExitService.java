package com.esc.oms.outsource.outperson.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;


public interface IApplyExitService extends IBaseOptionService,IApplyCommonService{

	public boolean cancelConfigByUserId(Map<String, Object> info);
	public List<UTMap<String, Object>> getUserBaseInfo(Map<String, Object> param);
	
}
