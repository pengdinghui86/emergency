package com.esc.oms.asset.agreement.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.persistence.dao.AbstractBaseSqlDao.ORDERTYPE;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.timetask.anotations.CronTimeTask;
import org.esc.framework.timetask.anotations.TimeTaskMark;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.asset.agreement.dao.IAssetsAgreementInfoDao;
import com.esc.oms.asset.agreement.service.IAssetsAgreementInfoService;
import com.esc.oms.asset.agreement.service.IAssetsAgreementWarnConfigService;
import com.esc.oms.supplier.agreement.dao.IPurchaseAgreementDao;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;


@Service
@Transactional
@TimeTaskMark
public class AssetsAgreementInfoServiceImpl extends BaseOptionService implements IAssetsAgreementInfoService{

	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private IAssetsAgreementInfoDao dao;
	
	@Resource
	private IAssetsAgreementWarnConfigService configService;
	
	@Resource
	private ISysParamService sysParamService;
	
	@Resource
	private MessageSend messageService;
	
	@Resource
	private ISysUserService userService;
	
	@Resource
	private IPurchaseAgreementDao purchaseAgreementDao;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return dao;
	}
	
	/**
	 * 添加
	 * @param info
	 * @return
	 */
	@EscOptionLog(module=SystemModule.ASSETS_AGREEMENT_INFO, opType=ESCLogOpType.INSERT, table="assets_agreement_info", primaryKey="id={1.id}",option="新增资产合同：{1.agreementName}/{1.agreementCode}")
	public boolean add(Map info){	
		boolean addStatus = super.add(info);
		return addStatus;			
	}
	
	/**
	 * 修改
	 * @param info
	 * @return
	 */
	@EscOptionLog(module=SystemModule.ASSETS_AGREEMENT_INFO, opType=ESCLogOpType.UPDATE, table="assets_agreement_info", primaryKey="id={1.id}",option="修改资产合同：{1.agreementName}/{1.agreementCode}")
	public boolean updateById(Map info){
		return super.updateById(info);	
	}
	
	/**
	 * 根据id 删除
	 * @param id
	 * @return
	 */
	@EscOptionLog(module=SystemModule.ASSETS_AGREEMENT_INFO, opType=ESCLogOpType.DELETE, table="assets_agreement_info",primaryKey="{1}",option="删除资产合同：{agreementName}/{agreementCode}")
	public boolean deleteById(String id){
		return super.deleteById(id);
	}
	
	@Override
	public UTMap<String, Object> getById(String id) {
		UTMap<String, Object> rec = super.getById(id);
		Map<String,Object> param = new HashMap<String,Object>();
		param.put("assetsAgreementId", id);
		return rec;
	}
	
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map param) {
		dao.getPageInfo(pageBean, param);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params){
		return dao.getListAll(params);
	}
	
	/**
	 * 包括领用详单
	 * @param pageBean
	 * @param param
	 */
	@Override
	public void getPageInfoDetail(UTPageBean pageBean, Map param) {
		dao.getPageInfo(pageBean, param);
	}

	@CronTimeTask(description="每天上午8点定时发送资产维保合同到期提醒",cron="0 0 8 * * ?") 
	@Override
	public boolean generateWarn() {
		logger.info("开始发送资产合同到期提醒！=========================================================");
//		Map<String, Object> params = new HashMap<String,Object>();
//		params.put("isWarn", "1");//需要提醒
//		params.put("status", "1");//合同未关闭
		List<UTMap<String, Object>> list = dao.getWarnAgreementList();
		List<UTMap<String, Object>> warnList = configService.getListMaps(null, "warnDayNum", ORDERTYPE.ASC, null);
		if(list != null){
			for (UTMap<String, Object> utMap : list) {
				int leftNum = utMap.get("leftNum")==null?0:Integer.parseInt(String.valueOf(utMap.get("leftNum")));
				//上一次预警日期
				String lastWarnDay = utMap.get("lastWarnDate")==null?null:utMap.get("lastWarnDate").toString();
				//下一次预警日期
				String nextWarnDay = utMap.get("nextWarnDate")==null?null:utMap.get("nextWarnDate").toString();
				//上一次提前预警天数
				int lastWarnDayNum = utMap.get("lastWarnDayNum")==null?0:Integer.parseInt(String.valueOf(utMap.get("lastWarnDayNum")));
				boolean hadWarn = false;
				for(UTMap<String, Object> warnMap : warnList){
					int warnDayNum = (Integer) warnMap.get("warnDayNum");
					int warnCycle =  (Integer) warnMap.get("warnCycle");//提醒周期  1。每月 2.每两周  3.每周  4.每天   5.一次	
					String warnRoleIds =  warnMap.get("warnRoleIds")==null?null:warnMap.get("warnRoleIds").toString();//提醒角色
					if(warnDayNum != 0){
						if(leftNum<=warnDayNum && !hadWarn){
							utMap.put("warnRoleIds", warnRoleIds);
							if(warnCycle==1 || warnCycle == 2 || warnCycle ==3){ //提醒周期  1。每月 2.每两周  3.每周 
								if(StringUtils.isEmpty(lastWarnDay)){//没有预警过									
									warn(warnCycle,warnDayNum,utMap);
									hadWarn = true;
								}else{//已经预警
									if(lastWarnDayNum==warnDayNum){
										if(dateEqual(nextWarnDay,UTDate.getCurDate(),"yyyy-MM-dd")){//判断下一个执行日期是否为今天											
											warn(warnCycle,warnDayNum,utMap);
											hadWarn = true;
										}
									}else if(lastWarnDayNum>warnDayNum){//上次预警天数大于本天数，则本天数未开始预警
										warn(warnCycle,warnDayNum,utMap);
										hadWarn = true;
									}									
								}								
							}else if(warnCycle==4){ //每天
								if(StringUtils.isEmpty(lastWarnDay)){
									warn(warnCycle,warnDayNum,utMap);
									hadWarn = true;
								}else{
									if(dateEqual(nextWarnDay,UTDate.getCurDate(),"yyyy-MM-dd")){//判断下一个执行日期是否为今天
										warn(warnCycle,warnDayNum,utMap);
										hadWarn = true;
									}
								}								
							}else if(warnCycle==5){//一次
								if(StringUtils.isEmpty(lastWarnDay)){ //未提醒
									warn(warnCycle,warnDayNum,utMap);
									hadWarn = true;
								}else{
									if(lastWarnDayNum>warnDayNum){ //上次预警天数大于本天数，则本天数未开始预警
										warn(warnCycle,warnDayNum,utMap);
										hadWarn = true;
									}
								}
							}
						}
					}
				}				
			}
		}
		logger.info("成功发送资产合同到期提醒！=========================================================");
		return true;
	}

	@Override
	public List<UTMap<String, Object>> getListByIds(String ids) {
		return dao.getListByIds(ids);
	}

	//预警提醒
	private void warn(int warnCycle,int lastWarnDayNum,Map<String,Object> utMap){
		
		//提醒，邮件+系统		
//		HashMap<String,Object> param = new HashMap<String,Object>();
//		param.put("signature",RoleUtils.ASSET_MANAGER);
//		List<UTMap<String,Object>> list = userService.getUserBaseInfo(param);
		String warnRoleIds = utMap.get("warnRoleIds")==null?null:String.valueOf(utMap.get("warnRoleIds"));
		String userIds = "";
		if(!StringUtils.isEmpty(warnRoleIds)){					
			List<UTMap<String,Object>> list = userService.getUsersByRoleId(warnRoleIds);
			if(list!=null){ 
				for(UTMap<String,Object> user :list){
					userIds = userIds + user.get("id")+",";
				}
				String agreementName = (String) utMap.get("agreementName");
				String agreementCode= (String) utMap.get("agreementCode");
				String title = "维保合同【"+agreementName+"/"+agreementCode+"】到期预警提醒";
				String content = "维保合同【"+agreementName+"/"+agreementCode+"】剩余天数为："+utMap.get("leftNum")+"天，请及时处理！";
				messageService.sendMessage(userIds,title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
				logger.info(CommonUtils.vaildLog("发送维保合同【"+agreementName+"/"+agreementCode+"】到期预警提醒，剩余天数："+utMap.get("leftNum")));
			}					
		}
		
		Calendar calendar=Calendar.getInstance();
		if(warnCycle==1){ //提醒周期  1。每月 2.每两周  3.每周  4.每天
			calendar.add(Calendar.MONTH, 1);
		}else if(warnCycle == 2){
			calendar.add(Calendar.DATE, 14);
		}else if(warnCycle ==3){
			calendar.add(Calendar.DATE, 7);
		}else if(warnCycle ==4){
			calendar.add(Calendar.DATE, 1);
		}		
		utMap.put("lastWarnDate", UTDate.getCurDate());
		utMap.put("nextWarnDate", UTDate.dateToDateString(calendar.getTime(), "yyyy-MM-dd"));
		utMap.put("lastWarnDayNum", lastWarnDayNum);
		updateById(utMap);
	}
	/**
	 * 导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	@Override
	public boolean leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String[] fileds = null;
		String tamlate= null;
		tamlate= "excelOutTamplate.assetsAgreementList";
		fileds = new String[] {				
				IAssetsAgreementInfoDao.FIELD_AGREEMENT_NAME,
				IAssetsAgreementInfoDao.FIELD_AGREEMENT_CODE,
				IAssetsAgreementInfoDao.FIELD_TYPE,
				IAssetsAgreementInfoDao.FIELD_SUPPLIER_NAME,
				IAssetsAgreementInfoDao.FIELD_BEGIN_TIME,
				IAssetsAgreementInfoDao.FIELD_END_TIME,
				IAssetsAgreementInfoDao.FIELD_AGREEMENT_STATUS,
				IAssetsAgreementInfoDao.FIELD_IS_WARN,
				IAssetsAgreementInfoDao.LEFT_NUM};
	
		if (null != data && !data.isEmpty()) {
			for (int i=0;i<data.size();i++) {
				UTMap<String, Object> item = (UTMap<String, Object>) data.get(i);
				item.put(IAssetsAgreementInfoDao.FIELD_BEGIN_TIME, 
						CommonUtils.replaceAll((String)item.get(IAssetsAgreementInfoDao.FIELD_BEGIN_TIME), "-", "/"));
				item.put(IAssetsAgreementInfoDao.FIELD_END_TIME, 
						CommonUtils.replaceAll((String)item.get(IAssetsAgreementInfoDao.FIELD_END_TIME), "-", "/"));
			}
		}
		//替换下拉的值
		Map<String, String> fieldAndParamType = new HashMap<String, String>();
		fieldAndParamType.put(IAssetsAgreementInfoDao.FIELD_TYPE, "assetsAgreementType");
		fieldAndParamType.put(IAssetsAgreementInfoDao.FIELD_AGREEMENT_STATUS, "agreementStatus");
		fieldAndParamType.put(IAssetsAgreementInfoDao.FIELD_IS_WARN, "YesNo");
		sysParamService.changeParamData(data, fieldAndParamType);
		
		return	UTExcel.leadingout( fileds, data, tamlate, request, response);
	}

//	public static String getTypeDesc(String type){
//		if(StringUtils.isEmpty(type)){
//			return "";
//		}else{
//			if("1".equals(type)){
//				return "采购";
//			}else if("2".equals(type)){
//				return "采购+维保";
//			}else if("3".equals(type)){
//				return "维保";
//			}else{
//				return "";
//			}
//		}	
//	}


	@Override
	public List<UTMap<String, Object>> getAgreementList(Map<String, Object> params) {	
		List<UTMap<String, Object>> list = dao.getAgreementList(params);
		String agreementId = (String) params.get("agreementId");
		if (StringUtils.isNotEmpty(agreementId)) {
			if (null == list || list.isEmpty()) {
				list = new ArrayList<UTMap<String, Object>>();
				list.add(purchaseAgreementDao.getById(agreementId));
			}else {
				boolean hasFlag = false;
				for (UTMap<String, Object> item : list) {
					String id = (String) item.get("id");
					if (StringUtils.equals(id, agreementId)) {
						hasFlag = true;
						break;
					}
				}
				if (!hasFlag) {
					list.add(purchaseAgreementDao.getById(agreementId));
				}
			}
		}
		return list;
	}

	 /**
     * 比较指定两日期,如果dateStr1晚于dateStr2则return true;
     * @param dateStr1 指定日期
     * @param dateStr2 指定日期
     * @param pattern 指定日期的格式
     * @return boolean
     */
    public static boolean dateEqual(String dateStr1, String dateStr2, String pattern) {
        boolean bea = false;
        SimpleDateFormat sdf_d = new SimpleDateFormat(pattern);
        java.util.Date date1;
        java.util.Date date0;
        try {
            date1 = sdf_d.parse(dateStr1);
            date0 = sdf_d.parse(dateStr2);
            if (date0.compareTo(date1)==0) {
                bea = true;
            }
        } catch (ParseException e) {
            bea = false;
        }
        return bea;
    }
}