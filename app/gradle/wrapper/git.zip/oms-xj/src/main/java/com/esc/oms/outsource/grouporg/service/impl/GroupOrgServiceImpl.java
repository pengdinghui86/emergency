package com.esc.oms.outsource.grouporg.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Service;

import com.esc.oms.outsource.grouporg.dao.IGroupOrgDao;
import com.esc.oms.outsource.grouporg.dao.impl.GroupOrgDaoImpl;
import com.esc.oms.outsource.grouporg.service.IGroupOrgService;


@Service
public class GroupOrgServiceImpl implements IGroupOrgService{
	
	@Resource
	private IGroupOrgDao groupOrgDao;
	@Override
	public boolean saveGroupOrgAndUser(List<Map<String, Object>> info,int groupOrgType) {
	
		List<Map> groupOrg=new ArrayList<Map>();
		List<Map> groupUser=new ArrayList<Map>();
		List<String> groupOrgId=new ArrayList<String>();
		for (Map<String, Object> item : info) {
			if(item.containsKey("users")){
				groupUser.addAll((Collection<? extends Map>) item.get("users"));
			}
			groupOrgId.add(item.get("groupId").toString());
			item.put("groupOrgType", groupOrgType);
			groupOrg.add(item);
		}

		return groupOrgDao.saveGroupOrg(groupOrg,groupOrgType)&&groupOrgDao.saveGroupUser(groupUser,StringUtils.join(groupOrgId.toArray(),","));
	
	}

	@Override
	public List<UTMap<String, Object>> getGroupOrgAndUser(int groupOrgType) {
		return groupOrgDao.getGroupOrgAndUser(groupOrgType); 
	}
	
	public boolean deleteGroupAfter(String groupIds,int groupOrgType){
		String[] arraystr=groupIds.split(",");
		List<String> goIds=new ArrayList<String>();
		for (String item : arraystr) {
			if(!goIds.contains(item)){
				getGroupChildern(item, groupOrgType,goIds);
			}
			goIds.add(item);
		}

		String [] goIdsArray=goIds.toArray(new String[goIds.size()]);
		
		//删除结构
		Map<String, Object> map=new HashMap<String, Object>();
		map.put(groupOrgDao.FIELD_GROUPORG_GROUP, StringUtils.join(goIdsArray,","));
		map.put("groupOrgType", groupOrgType);
		boolean flog=groupOrgDao.deletes(map);
		
		//删除人员
		groupOrgDao.deleteGroupUserByGroutId(StringUtils.join(goIdsArray,","));
		
		return flog;
	}
	
	public void getGroupChildern(String id,int groupType ,List<String> idList){
		Map<String, Object> map=new HashMap<String, Object>();
		map.put(groupOrgDao.FIELD_GROUPORG_PARENTID, id);
		map.put("groupOrgType", groupType);
		List<UTMap<String, Object>> list=groupOrgDao.getListMaps(map);
		for (UTMap<String, Object> utMap : list) {
			Object groupId=utMap.get(groupOrgDao.FIELD_GROUPORG_GROUP);
			if(groupId!=null&&StringUtils.isNotEmpty(groupId.toString())){
				idList.add(groupId.toString());
				getGroupChildern(groupId.toString(), groupType,idList);
			}
		}
	
	}

}
