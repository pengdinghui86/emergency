package com.esc.oms.asset.assetCategory.service;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

import java.util.List;
import java.util.Map;

public interface IAssetCategoryService extends IBaseOptionService {
  public List<UTMap<String, Object>> getdicts() ;

  /**
   * 获取所有的值
   * @param params
   * @param pageBean
   */
  public void getAttrAll(Map<String, Object> params, UTPageBean pageBean);

  /**
   * 根据资产id查询额外属性
   * @param infoId
   * @return
   */
  public List<UTMap<String, Object>> getAttrValue(String infoId);

  /**
   * 根据资产信息获取所有的属性
   * @param map
   * @return
   */
  public Map<String, Object> getAttrValueMap(Map<String, Object> map);
  
  /**
   * 根据资产分类名称获取资产分类id
   * @param name
   * @return
   */
  public String getAssetCategoryIdByName(String name);

  /**
   * 判断是否存在字段名，不止在配置表中，还在资产信息表中
   * @param map
   * @return
   */
  public boolean isExistColumn(Map<String, Object> map);

  /**
   * 获取额外属性的值
   * @param params
   * @return
   */
  public List<UTMap<String, Object>> getAttrList(Map<String, Object> params);
}
