package com.esc.oms.asset.spareParts.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.timetask.anotations.CronTimeTask;
import org.esc.framework.timetask.anotations.TimeTaskMark;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.asset.spareParts.dao.ISparePartsDao;
import com.esc.oms.asset.spareParts.service.ISparePartsService;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;

@Service
@Transactional
@TimeTaskMark
public class SparePartsServiceImpl extends BaseOptionService implements ISparePartsService{

	private static final Logger logger = Logger.getLogger(SparePartsServiceImpl.class);
	
	@Resource
	private ISparePartsDao sparePartsDao;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return sparePartsDao;
	}


	@Override
	public List<UTMap<String, Object>> getSparePartsByNameAndId(String name,
			String id) {
		return sparePartsDao.getSparePartsByNameAndId(name,id);
	}

	@Override
	public List<UTMap<String, Object>> getSparePartsByIds(String ids) {
		return sparePartsDao.getSparePartsByIds(ids);
	}
	
	@Override
	@EscOptionLog(module=SystemModule.ASSET, opType=ESCLogOpType.INSERT, table="assets_material_backup_info", primaryKey="id={1.id}", option="新增名称为{name}的资产备件信息。")
	public boolean add(Map info){
		return	getOptionDao().add(info);
	}
	
	@Override
	@EscOptionLog(module=SystemModule.ASSET, opType=ESCLogOpType.DELETE, table="assets_material_backup_info",primaryKey="{1}", option="删除名称为{name}的资产备件信息。")
	public boolean delete(Map info){
		return	getOptionDao().delete(info);
	}
	
	@Override
	@EscOptionLog(module=SystemModule.ASSET, opType=ESCLogOpType.UPDATE, table="assets_material_backup_info", primaryKey="id={1.id}", option="修改名称为{name}的资产备件信息。")
	public boolean updateById(Map info){
		return getOptionDao().updateById(info);
	}

	/**
	 * 到期备件修改为已过期的定时任务
	 * 
	 */
	@CronTimeTask(description="到期的备件，修改状态为已过期",cron="0 20 1 * * ?")
	@Override
	public void monitorSparePartsOverTime() {
		logger.info("===start  开始查找到期的备件！=========================================================");
//		Map<String, Object> param = new HashMap<String, Object>();
//		param.put("useType", "WSY,YSY"); // 未使用、使用中
//		param.put("endDate", UTDate.getCurDate());
		List<UTMap<String, Object>> list = sparePartsDao.getSparePartByEndDateAndStatus();
		
		if(list != null && list.size() > 0){
			logger.info("到期的备件共有" + list.size() + "！================================");
			for (UTMap<String, Object> data : list) {
				//更改为已过期
				data.put("useType", "YGQ");
				updateById(data);
			}
		} else {
			logger.info("没有到期的备件！================");
		}
		logger.info("===end  完成将到期的备件状态修改为已过期！=====================");
	}
	
}