package com.esc.oms.outsource.manhour.dao.impl;

import com.esc.oms.outsource.manhour.dao.IManHourStatisticDao;
import com.esc.oms.util.RoleUtils;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class ManHourStatisticDaoImpl extends BaseOptionDao implements IManHourStatisticDao {
	@Override
	public String getTableName() {
		return "workhour_overtime";
	}

	public void baseOnSupplier(Map<String, Object> param, UTPageBean pageBean) {
		String sql = getSupplierSearchSqlString(param);
		super.getPageListMapBySql(sql, pageBean);
	}
	
	public List<UTMap<String, Object>> baseOnSupplierList(Map<String, Object> param) {
		String sql = getSupplierSearchSqlString(param);
		return super.getListBySql(sql);
	}

	public void baseOnOrg(Map<String, Object> param, UTPageBean pageBean) {
		String sql = getOrgSearchSqlString(param);
		super.getPageListMapBySql(sql, pageBean);
	}

	public List<UTMap<String, Object>> baseOnOrgList(Map<String, Object> param) {
		String sql = getOrgSearchSqlString(param);
		return super.getListBySql(sql);
	}

	private String getSupplierSearchSqlString(Map param) {
		String beginTime = (String) param.get("beginTime");
		String endTime = (String) param.get("endTime");
		String ignoreType = (String) param.get("ignoreType"); // 不需要统计的部分：1加班、2请假、3出差
		String forMainPage = (String) param.get("forMainPage"); // 主页报表
		
		String beginTimeSql = StringUtils.isNotEmpty(beginTime) ? "and o.presentDate >= '" + beginTime + "'" : "";
		String endTimeSql = StringUtils.isNotEmpty(endTime) ? "and o.presentDate <= '" + endTime + "'" : "";
		
		StringBuilder sql = new StringBuilder();
		sql.append(" select s.name supplierName,s.shortName,s.id supplierId, s.code supplierCode, ");
		sql.append(" '" + (StringUtils.isNotEmpty(beginTime) ? beginTime : "") + "' beginTime, ");
		sql.append(" '" + (StringUtils.isNotEmpty(endTime) ? endTime : "") + "' endTime, ");
		// 人数：联合考勤算一个人
		sql.append("(select count(1) from ");
		sql.append(" (SELECT IFNULL(c.coalitionId,e.userId) userIdOrCoalitionId,e.supplierId FROM supplier_emp e ");
		sql.append(" left join attendance_user_config c on c.userId = e.userId ");
		sql.append(" where e.userType = '3' ");
		sql.append(StringUtils.isNotEmpty(endTime) ? " and if(e.startDate > '" + endTime + "', 0, 1) = 1 " : ""); // 服务开始日期在结束日期之后入场的不计算
		sql.append(StringUtils.isNotEmpty(beginTime) ? " and if(e.endDate < '" + beginTime + "', 0, 1) = 1 " : ""); // 服务结束日期在开始时间之前的不计算
		sql.append(" group by userIdOrCoalitionId) memberCount WHERE memberCount.supplierId = s.id ) memberNum ");

		// 加班统计：批准、待审批
		if(StringUtils.isEmpty(ignoreType) || !ignoreType.contains("1")) {
			sql.append(", ");
			sql.append("(select ifnull(sum(o.hours),0) from workhour_overtime o where o.supplierId = s.id and FIND_IN_SET(o.status,'5') " + beginTimeSql + " " + endTimeSql + ") overtimeApproved, ");
			sql.append("(select ifnull(sum(o.hours),0) from workhour_overtime o where o.supplierId = s.id and FIND_IN_SET(o.status,'2,3,4') " + beginTimeSql + " " + endTimeSql + ") overtimePendingApproved ");
		}
		// 请假统计：批准、待审批
		if(StringUtils.isEmpty(ignoreType) || !ignoreType.contains("2")) {
			sql.append(", ");
			sql.append("(select ifnull(sum(o.hours),0) from workhour_vacation_detail o, workhour_vacation v where v.supplierId = s.id and o.infoId = v.id and FIND_IN_SET(v.status,'5') " + beginTimeSql + " " + endTimeSql + " and v.type='3') vacationApproved, ");
			sql.append("(select ifnull(sum(o.hours),0) from workhour_vacation_detail o, workhour_vacation v where v.supplierId = s.id and o.infoId = v.id and FIND_IN_SET(v.status,'2,3,4') " + beginTimeSql + " " + endTimeSql + " and v.type='3') vacationPendingApproved ");
		}
		// 调休统计：批准、待审批
		if(StringUtils.isEmpty(ignoreType) || !ignoreType.contains("3")) {
			sql.append(", ");
			sql.append("(select ifnull(sum(o.hours),0) from workhour_vacation_detail o, workhour_vacation v where v.supplierId = s.id and o.infoId = v.id and FIND_IN_SET(v.status,'5') " + beginTimeSql + " " + endTimeSql + " and v.type='8') leaveInLieuApproved, ");
			sql.append("(select ifnull(sum(o.hours),0) from workhour_vacation_detail o, workhour_vacation v where v.supplierId = s.id and o.infoId = v.id and FIND_IN_SET(v.status,'2,3,4') " + beginTimeSql + " " + endTimeSql + " and v.type='8') leaveInLieuPendingApproved ");
		}
//		// 出差统计：批准、待审批
//		if(StringUtils.isEmpty(ignoreType) || !ignoreType.contains("3")) {
//			sql.append(", ");
//			sql.append("(select ifnull(sum(o.hours),0) from workhour_travel_detail o, workhour_travel v where v.supplierId = s.id and o.infoId = v.id and FIND_IN_SET(v.status,'5') " + beginTimeSql + " " + endTimeSql + ") travelApproved, ");
//			sql.append("(select ifnull(sum(o.hours),0) from workhour_travel_detail o, workhour_travel v where v.supplierId = s.id and o.infoId = v.id and FIND_IN_SET(v.status,'2,3,4') " + beginTimeSql + " " + endTimeSql + ") travelPendingApproved ");
//		}
//
		sql.append(" from supplier_base_info s where IFNULL(s.deleteFlag,'0') = '0' ");
		
		String id = (String) param.get("id");
		String supplierName = (String) param.get("supplierName");
		if(StringUtils.isNotEmpty(supplierName)) {
			sql.append(" and name like '%").append(supplierName).append("%' ");
//			sql.append(" or code like '%").append(supplierName).append("%') ");

		}
		if(StringUtils.isNotEmpty(id)) {
			sql.append(" and FIND_IN_SET(id,'").append(id).append("') ");
		}
		
		// 数据权限过滤 lba
		if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.OUTSOURCE_MANAGER, RoleUtils.SYSTEM_ADMINISTRATOR)) {//外包管理员
			// 只能看自己所属供应商的
			sql.append(" and s.id = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId()+"' ");
		}
		if("forMainPage".equals(forMainPage)) { // 主页报表只显示最多工时的10个
			if("2,3".equals(ignoreType)) {
				sql.append(" having (overtimePendingApproved + overtimeApproved) > 0 ");
				sql.append(" order by (overtimePendingApproved + overtimeApproved) desc ");
			} else if("1,3".equals(ignoreType)) {
				sql.append(" having (vacationPendingApproved + vacationApproved) > 0 ");
				sql.append(" order by (vacationPendingApproved + vacationApproved) desc ");
			} else if("1,2".equals(ignoreType)) {
				sql.append(" having (leaveInLieuPendingApproved + leaveInLieuApproved) > 0 ");
				sql.append(" order by (leaveInLieuPendingApproved + leaveInLieuApproved) desc ");
			}
			sql.append(" limit 0,10  ");
		} else {
			sql.append(" having memberNum > 0 ");
			sql.append(" order by s.createTime desc, s.sortCode ");
		}

		return sql.toString();
	}
	
	private String getOrgSearchSqlString(Map param) {
		String beginTime = (String) param.get("beginTime");
		String endTime = (String) param.get("endTime");
		String ignoreType = (String) param.get("ignoreType"); // 不需要统计的部分：1加班、2请假、3出差
		String forMainPage = (String) param.get("forMainPage"); // 主页报表
		
		String beginTimeSql = StringUtils.isNotEmpty(beginTime) ? "and o.presentDate >= '" + beginTime + "'" : "";
		String endTimeSql = StringUtils.isNotEmpty(endTime) ? "and o.presentDate <= '" + endTime + "'" : "";
		
		StringBuilder sql = new StringBuilder();
		sql.append("select REPLACE(s.longName, '!', '/') orgName,s.name shortName,s.id orgId, s.code orgCode, ");
		sql.append(" '" + (StringUtils.isNotEmpty(beginTime) ? beginTime : "") + "' beginTime, ");
		sql.append(" '" + (StringUtils.isNotEmpty(endTime) ? endTime : "") + "' endTime, ");
		// 人数：联合考勤算一个人
		sql.append("(select count(1) from ");
		sql.append(" (SELECT IFNULL(c.coalitionId,e.userId) userIdOrCoalitionId,u.orgId FROM supplier_emp e ");
		sql.append(" left join attendance_user_config c on c.userId = e.userId ");
		sql.append(" left join sys_user u on u.id = e.userId  ");
		sql.append(" where e.userType = '3' and e.state = '1' "); // 外包，有效的
		sql.append(StringUtils.isNotEmpty(endTime) ? " and if(e.startDate > '" + endTime + "', 0, 1) = 1 " : ""); // 服务开始日期在结束日期之后入场的不计算
		sql.append(StringUtils.isNotEmpty(beginTime) ? " and if(e.endDate < '" + beginTime + "', 0, 1) = 1 " : ""); // 服务结束日期在开始时间之前的不计算
		
		sql.append(" group by userIdOrCoalitionId) memberCount WHERE memberCount.orgId = s.id ) memberNum ");
		// 加班统计：批准、待审批
		if(StringUtils.isEmpty(ignoreType) || !ignoreType.contains("1")) {
			sql.append(", ");
			sql.append("(select ifnull(sum(o.hours),0) from workhour_overtime o where o.orgId = s.id and FIND_IN_SET(o.status,'5') " + beginTimeSql + " " + endTimeSql + ") overtimeApproved, ");
			sql.append("(select ifnull(sum(o.hours),0) from workhour_overtime o where o.orgId = s.id and FIND_IN_SET(o.status,'2,3,4') " + beginTimeSql + " " + endTimeSql + ") overtimePendingApproved ");
		}
		// 事假统计：批准、待审批
		if(StringUtils.isEmpty(ignoreType) || !ignoreType.contains("2")) {
			sql.append(", ");
			sql.append("(select ifnull(sum(o.hours),0) from workhour_vacation_detail o, workhour_vacation v where v.orgId = s.id and o.infoId = v.id and FIND_IN_SET(v.status,'5') " + beginTimeSql + " " + endTimeSql + " and v.type=3) vacationApproved, ");
			sql.append("(select ifnull(sum(o.hours),0) from workhour_vacation_detail o, workhour_vacation v where v.orgId = s.id and o.infoId = v.id and FIND_IN_SET(v.status,'2,3,4') " + beginTimeSql + " " + endTimeSql + " and v.type=3) vacationPendingApproved ");
		}


		//调休统计：批准、待审批
		if(StringUtils.isEmpty(ignoreType) || !ignoreType.contains("3")) {
			sql.append(", ");
			sql.append("(select ifnull(sum(o.hours),0) from workhour_vacation_detail o, workhour_vacation v where v.orgId = s.id and o.infoId = v.id and FIND_IN_SET(v.status,'5') " + beginTimeSql + " " + endTimeSql + " and v.type=8) leaveInLieuApproved, ");
			sql.append("(select ifnull(sum(o.hours),0) from workhour_vacation_detail o, workhour_vacation v where v.orgId = s.id and o.infoId = v.id and FIND_IN_SET(v.status,'2,3,4') " + beginTimeSql + " " + endTimeSql + " and v.type=8) leaveInLieuPendingApproved ");
		}
//		// 出差统计：批准、待审批
//		if(StringUtils.isEmpty(ignoreType) || !ignoreType.contains("3")) {
//			sql.append(", ");
//			sql.append("(select ifnull(sum(o.hours),0) from workhour_travel_detail o, workhour_travel v where v.orgId = s.id and o.infoId = v.id and FIND_IN_SET(v.status,'5') " + beginTimeSql + " " + endTimeSql + ") travelApproved, ");
//			sql.append("(select ifnull(sum(o.hours),0) from workhour_travel_detail o, workhour_travel v where v.orgId = s.id and o.infoId = v.id and FIND_IN_SET(v.status,'2,3,4') " + beginTimeSql + " " + endTimeSql + ") travelPendingApproved ");
//		}
		
		sql.append(" from sys_org s where s.state = '1' ");
		
		String id = (String) param.get("id");
		String orgName = (String) param.get("orgName");
		if(StringUtils.isNotEmpty(orgName)) {
			sql.append(" and REPLACE(s.longName, '!', '/') like '%").append(orgName).append("%' ");
			
		}
		if(StringUtils.isNotEmpty(id)) {
			sql.append(" and FIND_IN_SET(id,'").append(id).append("') ");
		}
		
		// 数据权限过滤 lba
		if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.OUTSOURCE_MANAGER, RoleUtils.SYSTEM_ADMINISTRATOR)) {//外包管理员
			// 只能看自己所属部门
			sql.append(" and s.id = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserOrgId()+"' ");
		}
		
		if("forMainPage".equals(forMainPage)) {
			if("2,3".equals(ignoreType)) {
				sql.append(" having (overtimePendingApproved + overtimeApproved) > 0 ");
				sql.append(" order by (overtimePendingApproved + overtimeApproved) desc ");
			} else if("1,3".equals(ignoreType)) {
				sql.append(" having (vacationPendingApproved + vacationApproved) > 0 ");
				sql.append(" order by (vacationPendingApproved + vacationApproved) desc ");
			} else if("1,2".equals(ignoreType)) {
				sql.append(" having (travelPendingApproved + travelApproved) > 0 ");
				sql.append(" order by (travelPendingApproved + travelApproved) desc ");
			}
			sql.append(" limit 0,10  ");
		} else {
			sql.append(" having memberNum > 0 ");
			sql.append(" order by s.longCode ");
		}
		return sql.toString();
	}
	
}
