package com.esc.oms.asset.transfer.controller;


import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.esc.framework.workflow.service.IWorkflowEngine;
import org.esc.framework.workflow.utils.bpmn.Instance;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.asset.overview.service.IAssetsTrackInfoService;
import com.esc.oms.asset.physical.service.IAssetPhysicalService;
import com.esc.oms.asset.transfer.dao.IAssetTransferDao;
import com.esc.oms.asset.transfer.service.IAssetTransferService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ExcelUtil;
@Controller
@RequestMapping("assetTransfer")
public class AssetTransferController extends BaseOptionController {


	@Resource
	private IAssetTransferService assetTransferService;
	
	@Resource
	private IAssetsTrackInfoService assetsTrackInfoService;
	
	@Resource
	private IAssetPhysicalService  assetPhysicalService; 
	
	@Resource
	private IWorkflowEngine workflowEngine;
	
	@Resource
	private ISysParamService sysParamService;
	
	@Override
	public IBaseOptionService optionService() {
		return assetTransferService;
	}
	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			assetTransferService.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	
	/**
	 * 获取带审批列表
	 * */
	@RequestMapping("getPendApprovalPageInfo")
	@ResponseBody
	public UTPageBean getPendApprovalPageInfo(@RequestParam Map<String, Object> params) {
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		assetTransferService.getPendApprovalPageInfo(pageBean, params);
		return pageBean;
	}
	
	/**
	 * 获取已审批列表
	 * */
	@RequestMapping("getAlreadyApprovalPageInfo")
	@ResponseBody
	public UTPageBean getAlreadyApprovalPageInfo(@RequestParam Map<String, Object> params) {
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		assetTransferService.getAlreadyApprovalPageInfo(pageBean, params);
		return pageBean;
	}
	
    @RequestMapping(value="/saveOrUpdate",method=RequestMethod.POST)  
    @ResponseBody
    public String saveorupdate(@RequestBody Map map) throws Exception{  
    	List assetsList =  (List) map.get("assetsList");
    	String allocationDate = map.get("allocationDate").toString();
    	String isAudit = map.get("isAudit").toString();
    	boolean flag = false;
    	if(compareDate(allocationDate) && null != assetsList && assetsList.size() > 0&&!isAudit.equals("1")){
    		map.put(IAssetTransferDao.FIELD_OVERSTATUS,"已转移");
    		flag = assetTransferService.updateAssetsInfo(assetsList, map);
    	}
    	else{
    		map.put(IAssetTransferDao.FIELD_OVERSTATUS,"未转移");
    	}
    	
    	try{
    			if(map.get("id") == null){
    				flag = assetTransferService.add(map);
    			}else{
    				flag = assetTransferService.updateById(map);
    			}
    			if(flag){
    				assetTransferService.deleteAssetsById((String)map.get("id"));//先删除关联再重新添加关联
    				for (Object obj : assetsList) {
    					Map asset = (Map)obj;
    					UTMap<String, Object> ut = new UTMap<String,Object>();
    					ut.put("allocationId", map.get("id"));
    					ut.put("assetsId", asset.get("id"));
    					assetTransferService.addRelation(ut);
    				}
    			}
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "操作成功");
    }
    
    /**
	 * 提交审批
	 * @param map
	 * @return
	 */
	@RequestMapping(value="submit", method=RequestMethod.POST)  
    @ResponseBody
    public String submit(@RequestBody Map<String,Object> map) {
		try {
			List assetsList =  (List) map.get("assetsList");
	  //  	String allocationDate = map.get("allocationDate").toString();
	    	//String isAudit = map.get("isAudit").toString();
	    //	String status = map.get("status").toString();
	    	boolean flag = true;
//	    	if(compareDate(allocationDate) && null != assetsList && assetsList.size() > 0&& !status.equals("3")){
//	    		map.put(IAssetTransferDao.FIELD_OVERSTATUS,"已转移");
//	    		flag = assetTransferService.updateAssetsInfo(assetsList, map);
//	    	}
	    	//else{
	    		map.put(IAssetTransferDao.FIELD_OVERSTATUS,"未转移");
	    	//}

			if(flag){
				assetTransferService.submit(map);
			}
			if(flag){
				assetTransferService.deleteAssetsById((String)map.get("id"));//先删除关联再重新添加关联
				for (Object obj : assetsList) {
					Map asset = (Map)obj;
					UTMap<String, Object> ut = new UTMap<String,Object>();
					ut.put("allocationId", map.get("id"));
					ut.put("assetsId", asset.get("id"));
					assetTransferService.addRelation(ut);
				}
			}
			return UTJsonUtils.getJsonMsg(true, "操作成功");
		}
		catch (Exception e) {
			logger.error("Exception",e);
			return UTJsonUtils.getJsonMsg(false, "操作失败");
		}
	}
    
    /**
	 * 根据id查询
	 * @param param
	 * @return
	 */
	@RequestMapping(value="getById")
	@ResponseBody
	public UTMap<String, Object> defgetById(@RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = null;
    	try{
    		map = optionService().getById(param.get("id").toString());
    		if(null != map && map.size() > 0){
    			List<UTMap<String, Object>> assetsList = assetTransferService.getAssetsById((String)map.get("id"));
    			map.put("assetsList", assetsList);
    		}
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return map;
	}

	/**
	 * 转移单导出
	 */
	@RequestMapping(value="exportByData")
	@ResponseBody
	public void exportByData(HttpServletRequest request, HttpServletResponse response, @RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = new UTMap<String, Object>();
	  
    	try{
    		if(null != param.get("id")){
    			map = optionService().getById((String)param.get("id"));
    			if(null != map && map.size() > 0){
    				List<UTMap<String, Object>> assetsList = assetTransferService.getAssetsById((String)map.get("id"));
        			if(assetsList != null && assetsList.size() > 0)
        			{
        				//替换下拉的值
        				Map<String, String> fieldAndParamType = new HashMap<String, String>();
        				fieldAndParamType.put("assetsLevel", "assetsLevel");
        				sysParamService.changeParamData(assetsList, fieldAndParamType);
        			}
    				map.put("assetsList", assetsList);
    			}
    			
    			//创建一个表格
    			HSSFWorkbook wb = new HSSFWorkbook();
    			List<Object[]> instanceList = new ArrayList<Object[]>();
    			if(map.get("isAudit").toString().equals("1")) {
	    			String id = param.get("id").toString();
	    			String workflowCode = "physical_asset_transfer";
	    			//流程审批信息
	    	        Instance instance = workflowEngine.getInstance(workflowCode, id);
	    	        if (instance != null) {
	    	            instance.setAuditInfoList(workflowEngine.getShowAuditInfoList(instance.getInstanceId()));
	    	            List<UTMap<String, Object>> maps = workflowEngine.getShowAuditInfoList(instance.getInstanceId());
	    	            for(UTMap<String, Object> map2 : maps)
	    	            {
	    	            	Object[] objs = new Object[5];
	    	    	        objs[0] = map2.get("nodeName")==null? "" : map2.get("nodeName").toString();
	    	    	        objs[1] = map2.get("createUser")==null? "" : map2.get("createUser").toString();
	    	    	        objs[2] = map2.get("createTime")==null? "" : map2.get("createTime").toString();
	    	    	        objs[3] = map2.get("auditResult")==null? "" : map2.get("auditResult").toString();
	    	    	        objs[4] = map2.get("auditComment")==null? "" : map2.get("auditComment").toString();
	    	    	        instanceList.add(objs);
	    	            }
	    	        }
    			}
    			response.setCharacterEncoding("UTF-8");
    			response.setContentType("application/vnd.ms-excel");
    			String fileName = "资产转移记录.xls";
    			fileName = URLEncoder.encode(fileName, "UTF-8");
    			response.addHeader("Content-Disposition", "attachment;filename=" + fileName);
    					
    			exportAssetTransfer(wb, map, instanceList);
    			
    			try {
					OutputStream out = response.getOutputStream();
	    			wb.write(out);
	    			out.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

    		}    		    		
		}catch(Exception e){
			logger.error("Exception", e);
    	}
	}
	
	private void exportAssetTransfer(HSSFWorkbook wb, UTMap<String, Object> map, List<Object[]> instanceList) 
	{
        String sheetName = "资产转移";
        Object[] objs = new Object[8];
        objs[0] = map.get("title")==null? "" : map.get("title").toString();
        objs[1] = map.get("newPlaceName")==null? "" : map.get("newPlaceName").toString();
        objs[2] = map.get("newDepartName")==null? "" : map.get("newDepartName").toString();
        objs[3] = map.get("newChargeName")==null? "" : map.get("newChargeName").toString();
        objs[4] = map.get("allocationDate")==null? "" : map.get("allocationDate").toString();
        objs[5] = map.get("reason")==null? "" : map.get("reason").toString();
        objs[6] = map.get("remark")==null? "" : map.get("remark").toString();
        objs[7] = map.get("isAudit")==null? "否" : (map.get("isAudit").toString().equals("1")?"是":"否");
        
        String[] rowsName = new String[] { "序号", "节点", "提交人", "提交时间", "审批结果", "审批意见" };
        List<Object[]> dataList = new ArrayList<Object[]>();
        String[] rowsName2 = new String[] { "资产名称", "资产大类", "资产小类", "资产级别", "品牌" , "型号", "存放地点", "所属部门", "设备负责人"};
        if(map.get("assetsList") != null)
        {
        	List<UTMap<String, Object>> list = (List<UTMap<String, Object>>) map.get("assetsList");
        	if(list != null && list.size() > 0)
        	{
        		for(UTMap<String, Object> item : list)
        		{
        			Object[] obj2 = new Object[9];
        			obj2[0] = item.get("assetsNameCode")==null? "" : item.get("assetsNameCode").toString();
    		        obj2[1] = item.get("categoryName")==null? "" : item.get("categoryName").toString();
    		        obj2[2] = item.get("subCategoryName")==null? "" : item.get("subCategoryName").toString();
    		        obj2[3] = item.get("assetsLevel")==null? "" : item.get("assetsLevel").toString();
    		        obj2[4] = item.get("brand")==null? "" : item.get("brand").toString();
    		        obj2[5] = item.get("model")==null? "" : item.get("model").toString();
   		            obj2[6] = item.get("location")==null? "" : item.get("location").toString();
    		        obj2[7] = item.get("resDepartId")==null? "" : item.get("resDepartId").toString();
    		        obj2[8] = item.get("resUserId")==null? "" : item.get("resUserId").toString();
    		        
    		        dataList.add(obj2);
        		}
        		
        	}
        }
        
        // 创建ExportExcel对象
        ExcelUtil excelUtil = new ExcelUtil();
        try{
            excelUtil.exportAssetTransfer(sheetName, "资产转移单", objs, wb);
            int index = 9;
            if(dataList.size() > 0)
            {
                excelUtil.exportAssetTransferAssetList(sheetName, "转移资产明细", rowsName2, dataList, wb, index, false);
                index = index + 4 + dataList.size();
            }
            if(objs[7].equals("是"))
            	excelUtil.exportAssetApplyInstance(sheetName, "流程详情", rowsName, instanceList, wb, index, false);
        }catch(Exception e){
            e.printStackTrace();
        }
	}
	
	@RequestMapping(value = "leadingout")
	public void leadingout(@RequestParam Map<String, Object> param,
			HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = null;
			if(info != null) {
				jsonBean = JSONObject.fromObject(info);
			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = assetTransferService.getAssetsList(jsonBean);
			} else {
			// 根据条件 导出当前
			//if (UTExcel.EXCELOUTTYPE_NOW == outType) {
				// getpage
				assetTransferService.getPageInfo(utPageBean, jsonBean);
				data = utPageBean.getRows();
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			assetTransferService.leadingout(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	/**
	 * 手动生成定时数据
	 * @return
	 */
	@RequestMapping(value="generate")  
    @ResponseBody
    public String generate(){  
		try{
			assetTransferService.generate();
		}catch(Exception e){
    		return UTJsonUtils.getJsonMsg(false,"generate接口调用失败!");
    	}
		return UTJsonUtils.getJsonMsg(true, "generate接口调用成功!");
    }
	
   private boolean compareDate(String allocationDate) throws Exception{
	   Date nowDate = new Date();
	   SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	   Date allocDate = sdf.parse(allocationDate);
	   boolean flag = allocDate.before(nowDate);
	   return flag;
   }
   
}