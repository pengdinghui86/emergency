package com.esc.oms.outsource.attendance.service.impl;

import com.esc.oms.outsource.attendance.dao.IFestivalDao;
import com.esc.oms.outsource.attendance.dao.IManHourEditDao;
import com.esc.oms.outsource.attendance.dao.IUserConfigDao;
import com.esc.oms.outsource.attendance.service.IAttendanceService;
import com.esc.oms.outsource.attendance.service.IDingDingAttendanceService;
import com.esc.oms.outsource.attendance.service.IManHourEditService;
import com.esc.oms.outsource.manhour.dao.IOvertimeDao;
import com.esc.oms.outsource.manhour.dao.IVacationDetailDao;
import com.esc.oms.outsource.manhour.service.IManHourStatisticService;
import com.esc.oms.util.Arith;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;
import com.esc.oms.util.FunctionEnum;
import com.esc.oms.util.LocalDateUtil;
import org.esc.framework.defval.DefaultValueTool;
import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.timetask.anotations.CronTimeTask;
import org.esc.framework.timetask.anotations.TimeTaskMark;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;


/**
 * 考勤工时填报Service
 * @author owner
 *
 */
@Service
@Transactional
@TimeTaskMark
public class ManHourEditImpl  extends BaseOptionService implements  IManHourEditService {
	private static final Logger logger = LoggerFactory.getLogger(ManHourEditImpl.class);
	
	@Resource
	private IManHourEditDao manHourEditDao;
	
	//系统参数
	@Resource
	private ISysParamService sysParamService;
		
	//用户Service
	@Resource
	private ISysUserService userService;
	
	//节假日
	@Resource
	private IFestivalDao festivalDao;
	
	//考勤模块
	@Resource
	private IAttendanceService attendanceService;
	
	//加班
	@Resource
	private IOvertimeDao overtimeDao;
	
	//用户考勤配置dao
	@Resource
	private IUserConfigDao userConfigDao;
	
	@Resource 
	private IManHourStatisticService manHourStatisticService;

	@Resource
	private IVacationDetailDao vacationDetailDao;

	@Resource
	private IDingDingAttendanceService dingDingAttendanceService;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return manHourEditDao;
	}
	
//	@CronTimeTask(description="test",cron="*/30 * * * * ?",parameters={"null","false"})
//	public void test(Date date,boolean isStatisticsManHour){
//		System.out.println("date:"+date+" , isStatisticsManHour"+"isStatisticsManHour");
//		if(date == null){
//			System.out.println("date == null");
//		}
//		if(isStatisticsManHour){
//			System.out.println(1);
//		}else{
//			System.out.println(2);
//		}
//	}
	
	/**
	 * 每天检查生成工时填报的数据
	 */
	@Override
	@CronTimeTask(description="每天凌晨检查人力外包考勤填报数据",cron="0 12 0 * * ?",parameters={"date,Date,null","isStatisticsManHour,boolean,true"})
	public void initData(Date date,boolean isStatisticsManHour) {
		logger.info("开始检查人力外包考勤填报数据......date="+(date == null)+",isStatisticsManHour="+isStatisticsManHour);
		Calendar c = Calendar.getInstance();
		if(date == null){
			date = new Date();
		}
		c.setTime(date);
		//获取外包人员和相应项目的数据
		Calendar change = Calendar.getInstance();
		change.setTime(date);
		//一号
		change.set(Calendar.DAY_OF_MONTH, 1);
		Date minDay = change.getTime();
		//31号
		int maxCurrentMonthDay=change.getActualMaximum(Calendar.DAY_OF_MONTH);
		change.set(Calendar.DAY_OF_MONTH, maxCurrentMonthDay);
		Date maxDay = change.getTime();
		List<UTMap<String, Object>> list = manHourEditDao.getProjectByToday(UTDate.dateToString(date,"yyyy-MM-dd"));
		if(list == null || list.isEmpty()){
			return;
		}

		// 得到本月的那一天
		int today = c.get(c.DAY_OF_MONTH);
		int year = c.get(c.YEAR);
		int month = c.get(c.MONTH) + 1;
		int quarter = UTDate.getQuarter(month);
		String festival = getFestival(year, month);
		logger.info("year="+year+", month="+month+", today="+today+", quarter="+quarter+", festival="+festival+", date="+date);
		// 如果是本月的第一天,初始化当月的数据,同时需要汇总上一个月的考勤工时
		if(today == 1){
			Map info = null;
			for (UTMap<String, Object> utMap : list) {
				info = new HashMap();
				info.put("year", year);
				info.put("month", month);
				info.put("yearMonth", year+"-"+month);
				info.put("quarter", quarter);
				info.put("projectId", utMap.get("projectId"));
				info.put("userId", utMap.get("userId"));
				info.put("supplierId", utMap.get("supplierId"));
				info.put("status", 1);
				info.put("festival", festival);
				info.put("d1", 0);
				info.put("total", 0);
				manHourEditDao.add(info);
			}
			if(isStatisticsManHour){//是否要统计汇总上一个月的数据
				c.add(Calendar.MONTH, -1);//上一个月
				int statisticsYear = c.get(c.YEAR);
				int statisticsMonth = c.get(c.MONTH) + 1;
				statisticsManHour(statisticsYear,statisticsMonth);
			}
			
		}else{
			int maximumDay = c.getActualMaximum(Calendar.DATE);//当月的天数
			logger.info("maximumDay="+ maximumDay);
			Map param = new HashMap();
			param.put("year", year);
			param.put("month", month);
			Map info = null;
			for (UTMap<String, Object> utMap : list) {
				param.put("userId", utMap.get("userId"));
				param.put("projectId", utMap.get("projectId"));
				List<UTMap<String, Object>> manHourEditlist = manHourEditDao.getListUserDate(param);
				if(manHourEditlist == null || manHourEditlist.isEmpty()){
					info = new HashMap();
					info.put("year", year);
					info.put("month", month);
					info.put("yearMonth", year+"-"+month);
					info.put("quarter", quarter);
					info.put("projectId", utMap.get("projectId"));
					info.put("userId", utMap.get("userId"));
					info.put("supplierId", utMap.get("supplierId"));
					info.put("status", 1);
					info.put("festival", festival);
//					info.put("d1", 0);
					for(int i = today ; i <= maximumDay ; i++){
						info.put("d"+today, 0);
					}
					manHourEditDao.add(info);
				}else{
					UTMap<String, Object> map = manHourEditlist.get(0);
//					logger.info("map="+map);
					map.put("d"+today, 0);
					manHourEditDao.updateById(map);
				}
			}
		}
		logger.info("检查人力外包考勤填报数据已完成");
	}
	
	/**
	 * 统计指定年月的人力外包考勤工时
	 * @param statisticsYear
	 * @param statisticsMonth
	 */
	public void statisticsManHour(int statisticsYear, int statisticsMonth){
		Map param = new HashMap();
		param.put("year", statisticsYear);
		param.put("month", statisticsMonth);
		param.put("status", "1,2");//状态（待填报：1，已填报：2，已确认：3）
		List<UTMap<String, Object>> manHourEditlist = manHourEditDao.getListMaps(param);

		//获取冬夏时令的配置
		List<UTMap<String, Object>> seasonList = dingDingAttendanceService.getSeason();
		LocalDateTime beginDate;
		LocalDateTime endDate;
		double manHour = 0d;
		double sumHour = 0d;
		double sumDays = 0d;//总天数
		double today = 0d;//当天的考勤天数 1或0.5 或0
		String seasonType = FunctionEnum.SeasonType.summer.getCode();//默认夏令时
		long beginTime = 0l;
		long endTime = 0l;
		long amBegin = 0l;
		long amEnd = 0l;
		long pmBegin = 0l;
		long pmEnd = 0l;
		long dailyHoursAM = 0l;
		long dailyHoursPM = 0l;
		long halfDays = 4*60*60;//半天的工时
		int amhours = 0;//上午的工时
		int pmhours = 0;//下午的工时
		BigDecimal resultSec = null;
		if(manHourEditlist != null){
			List<Map<String, Object>> updateList = new ArrayList<>();
			for (UTMap<String, Object> utMap : manHourEditlist) {
				String year = utMap.get("year").toString();
				String month = utMap.get("month").toString();
				String userId = utMap.get("userId").toString();
				String projectId = (String) utMap.get("projectId");
				//获取用户对应的人力外包合同,用户换算节假日加班工时
//				UTMap<String, Object> agreementManpowerInfo = agreementManpowerInfoService.getByUserId(userId);
				UTMap<String, Object> userConfig = userConfigDao.getUserConfigByUserId(userId);
				double dailyseconds = 0d;
				if(userConfig == null){
					dailyseconds = Double.valueOf(DefaultValueTool.getValue("attendance", "dailyHours"));//默认一天的正常工时
				}
				sumHour = 0d;
				sumDays = 0d;
				for(int i = 1 ; i <= 31 ; i++){
					manHour = 0d;
					today = 0;
					//不等于null，表示当天的考勤数据是可以填报的
					if(utMap.get("d"+i) != null){
						dailyseconds = 0;
						String date = year + "-" + month + "-" + i;
						//获取用户指定日期的考勤数据
						UTMap<String, Object> att = attendanceService.getCurUserAttendance(date,userId);
						//加班是不算入工时的，但是如果进行了请假，调休，需要配合考勤异常来消除异常，获取工作日工时
						// 1、判断节假日
						Calendar thisDate = Calendar.getInstance(); // 当前日期，在循环中确认当前的日期
						thisDate.set(Integer.parseInt(year), Integer.parseInt(month)-1, i, 0,0,0); // 记录计算的当前日期
						//获取当天是冬令时还是夏令时
						seasonType = dingDingAttendanceService.checkSeason(thisDate.getTimeInMillis(), seasonList);
						String isWorkDay = manHourStatisticService.isWorkDay(thisDate, userConfig); // 1是正常上班

						if("1".equals(isWorkDay) && att != null && userConfig != null && ("1".equals(userConfig.get("attendanceDateType"))
								|| ("2".equals(userConfig.get("attendanceDateType")) && "1".equals(userConfig.get("attendanceType"))))){//表示工作日,考勤不为空,并且是确定时间的考勤
							amBegin = UTDate.transformTimeToSecond((String)userConfig.get("amBegin"));
							amEnd = UTDate.transformTimeToSecond((String) userConfig.get("amEnd"));
							pmBegin = UTDate.transformTimeToSecond((String) userConfig.get("pmBegin"));
							pmEnd = UTDate.transformTimeToSecond((String) userConfig.get("pmEnd"));
							dailyHoursAM =  (Integer)userConfig.get("dailyHoursAM");
							dailyHoursPM =  (Integer)userConfig.get("dailyHoursPM");
							if(seasonType.equals(FunctionEnum.SeasonType.winter.getCode())){//冬令时，就用冬令时的数据
								amBegin = userConfig.get("winterAmBegin") != null ? UTDate.transformTimeToSecond((String)userConfig.get("winterAmBegin")) : amBegin;
								amEnd = userConfig.get("winterAmEnd") != null ? UTDate.transformTimeToSecond((String) userConfig.get("winterAmEnd")) : amEnd;
								pmBegin = userConfig.get("winterPmBegin") != null ? UTDate.transformTimeToSecond((String) userConfig.get("winterPmBegin")) : pmBegin;
								pmEnd = userConfig.get("winterPmEnd") != null ? UTDate.transformTimeToSecond((String) userConfig.get("winterPmEnd")) : pmEnd;
								dailyHoursAM = userConfig.get("winterDailyHoursAM") != null ? (Integer) userConfig.get("winterDailyHoursAM") : dailyHoursAM;
								dailyHoursPM = userConfig.get("winterDailyHoursPM") != null ? (Integer) userConfig.get("winterDailyHoursPM") : dailyHoursPM;
							}
							//获取当天的请假情况
							param.clear();
							param.put("presentDate", date);
							param.put("createUserId", userId);
							param.put("dingStatus", "COMPLETED");//钉钉状态为完成
							param.put("type", "8");//表示调休，调休是算工时的
							List<UTMap<String, Object>> leaveInLieuList = vacationDetailDao.getVacationList(param);
							param.remove("type");
							param.put("notType", "8");
							//表示请假
							List<UTMap<String, Object>> leaveList = vacationDetailDao.getVacationList(param);
							if(leaveInLieuList != null && leaveInLieuList.size() > 0){//存在调休，需要判断下午或者上午
								//去判断调休
								for(Map<String, Object> map : leaveInLieuList){
									beginDate = LocalDateUtil.toLocalDateTime((String) map.get("beginTime"));
									beginTime = beginDate.getHour()*3600+beginDate.getMinute()*60;//获取那天的时间
									endDate = LocalDateUtil.toLocalDateTime((String)map.get("endTime"));
									endTime = endDate.getHour()*3600+endDate.getMinute()*60;//获取那天的时间
									if(beginTime <= pmBegin && endTime <= pmBegin){//表示上午存在调休,判断下午是不是存在请假
										if(leaveList != null && leaveList.size() > 0){
											if(leaveList.size() == 0) {//表示只有一条数据
												UTMap<String, Object> leaveMap = leaveList.get(0);
												//判断是不是下午存在请假记录
												if(((Date)leaveMap.get("endTime")).getTime() > pmBegin){
													dailyseconds = halfDays;
													today = 0.5;
												}else{//判断下午的签到时间和签退时间是否正常，
													//判断下午的打卡记录是否正常 签到时间 小于下午开始时间加上15分钟 无签退异常
													if(att.get("startTime") == null){//下午没打上班卡
														dailyseconds = halfDays;
														today = 0.5;
													}else{
														beginDate = LocalDateUtil.toLocalDateTime((String) att.get("startTime"));
														beginTime = beginDate.getHour()*3600+beginDate.getMinute()*60;//获取那天的时间
														if(beginTime < (pmBegin+15*60)
																&& !"0".equals((String)att.get("dateoutStyle"))){
															today = 1.0;
															dailyseconds = dailyHoursAM+dailyHoursPM;
														}else{
															dailyseconds = halfDays;
															today = 0.5;
														}
													}

												}
											}else{//否则说明存在两条请假记录，上午和下午，这个时候以调休为准
												today = 0.5;
											}
										}else{
											if(att.get("startTime") == null){//下午
												today = 0.5;
												dailyseconds = halfDays;
											}else{
												//判断下午的打卡记录是否正常 签到时间 小于下午开始时间加上15分钟 无签退异常
												beginDate = LocalDateUtil.toLocalDateTime((String) att.get("startTime"));
												beginTime = beginDate.getHour()*3600+beginDate.getMinute()*60;//获取那天的时间
												if(beginTime < (pmBegin+15*60)
														&& !"0".equals((String)att.get("dateoutStyle"))){
													today = 1.0;
													dailyseconds = dailyHoursAM+dailyHoursPM;
												}else{
													today = 0.5;
													dailyseconds = halfDays;
												}
											}

										}

									}
									if(endTime >= pmBegin && endTime >= pmBegin && today < 1){//下午存在调休
										if(leaveList != null && leaveList.size() > 0){//判断上午是不是存在请假
											if(leaveList.size() == 0) {//表示只有一条数据
												UTMap<String, Object> leaveMap = leaveList.get(0);
												//判断是不是上午存在请假记录
												if(((Date)leaveMap.get("endTime")).getTime() <= pmBegin){
													today = 0.5;
												}else{//判断上午的签到时间是否正常，
													if("0".equals((String)att.get("dateinStyle"))){
														today = 1.0;
														dailyseconds = dailyHoursAM+dailyHoursPM;
													}else{
														today += 0.5;
														dailyseconds += halfDays;
													}
												}
											}else{//否则说明存在两条请假记录，上午和下午，这个时候以调休为准
												today = +0.5;
												dailyseconds += halfDays;
											}
										}else{//不存在请假，判断打卡异常
											if("0".equals((String)att.get("dateinStyle"))){
												today = 1.0;
												dailyseconds = dailyHoursAM+dailyHoursPM;
											}else{
												today += 0.5;
												dailyseconds += halfDays;
											}
										}
									}
									if(beginTime < pmBegin && endTime > pmBegin){//全天存在调休
										today = 1.0;
										dailyseconds = dailyHoursAM+dailyHoursPM;
									}
								}
							}else if(leaveList != null && leaveList.size() > 0){//不存在调休,存在请假
								if(leaveList.size() == 0) {//表示只有一条数据,存在两条不考虑，为0
									UTMap<String, Object> leaveMap = leaveList.get(0);
									beginDate = LocalDateUtil.toLocalDateTime((String)leaveMap.get("beginTime"));
									beginTime = beginDate.getHour()*3600+beginDate.getMinute()*60;//获取那天的时间
									endDate = LocalDateUtil.toLocalDateTime((String)leaveMap.get("endTime"));
									endTime = endDate.getHour()*3600+endDate.getMinute()*60;//获取那天的时间
									if(endTime <= pmBegin && beginTime <= pmBegin){//上午存在请假
										//判断下午
										if(att.get("startTime") != null){
											beginDate = LocalDateUtil.toLocalDateTime((String)att.get("startTime"));
											beginTime = beginDate.getHour()*3600+beginDate.getMinute()*60;//获取那天的时间
											if(beginTime < (pmBegin+15*60)
													&& !"0".equals((String)att.get("dateoutStyle"))){
												today = 0.5;
												dailyseconds = halfDays;
											}
										}

									}else if(endTime >= pmBegin && beginTime >= pmBegin){//下午存在请假
										//判断上午
										if("0".equals((String)att.get("dateinStyle"))){
											today = 0.5;
											dailyseconds = halfDays;
										}
									}//其他情况说明请假了一天
								}
							}else{//调休和请假都没有，
								if("0".equals((String)att.get("dateinStyle")) && "0".equals((String)att.get("dateoutStyle"))){
									today = 1.0;
									dailyseconds = dailyHoursAM+dailyHoursPM;
								}
							}
							//不能超过一天
							dailyseconds = dailyseconds > (dailyHoursAM+dailyHoursPM)? (dailyHoursAM+dailyHoursPM):dailyseconds;
							resultSec = BigDecimal.valueOf(Arith.div(dailyseconds, 3600, 2));
//							utMap.put("d"+i, resultSec.compareTo(BigDecimal.ZERO) == 0 ? "0" : String.valueOf(Arith.div(dailyseconds, 3600, 2)));
							utMap.put("d"+i, today > 0 ? new BigDecimal(today).setScale(1) : 0);
							sumHour = Arith.add(sumHour, dailyseconds);
							sumDays = Arith.add(today, sumDays);
						}
					}
				}
				utMap.put("total", sumDays);//总数为天
				utMap.put("totalDays", sumDays);
//				manHourEditDao.updateById(utMap);
				utMap.remove("projectName");
				utMap.remove("aleader");
				utMap.remove("supplierName");
				utMap.remove("projectLeader");
				utMap.remove("userName");
				utMap.remove("level");
				updateList.add(utMap);
			}

			manHourEditDao.batchUpdate(updateList, new String[]{"id"});
		}
	}
	
	/**
	 * 重新统计生成上一个月的数据
	 */
	public void afreshDate(LocalDateTime dateTime){
		//获取前月的第一天
		//获取当前日期
        ZoneId zone = ZoneId.systemDefault();
        Instant instant = dateTime.atZone(zone).toInstant();
		Calendar cal_1=Calendar.getInstance();
        cal_1.setTime(Date.from(instant));
//		//设置为1号,当前日期既为本月第一天
//		cal_1.set(Calendar.DAY_OF_MONTH,1);
		int year = cal_1.get(Calendar.YEAR);
		int month = cal_1.get(Calendar.MONTH)+1;
		String yearMonth = year + "-" + month;
		int dayCount = cal_1.getActualMaximum(Calendar.DATE);//得到一个月最大的一天就是一个月多少天
		
		//先删除上一个月的数据
		Map param = new HashMap();
		param.put("yearMonth", yearMonth);
		manHourEditDao.delete(param);
		
		for(int i = 1 ; i <= dayCount ; i++){
			//设置日期
			cal_1.set(Calendar.DAY_OF_MONTH,i);
			//初始化每天的数据
			this.initData(cal_1.getTime(), false);
		}
		//统计指定年月的人力外包考勤工时
		statisticsManHour(year,month);
		
	}
	
//	public static void main(String[] args) {
//		Calendar c = Calendar.getInstance();
//		c.setTime(UTDate.getDate("2016-1-29",UTDate.DATE_FORMAT));
//		System.out.println(c.get(c.YEAR));
//		System.out.println(c.get(c.MONTH));
//	}
	
	/**
	 * 获取指定年月的节假日字符串
	 * @param year
	 * @param month
	 * @return
	 */
	private String getFestival(int year, int month){
//		Map param = new HashMap();
//		param.put("year", year);
//		param.put("month", month);
		List<UTMap<String, Object>> list = festivalDao.getByYearAndMonth(year, month);
		String result = "";
		if(list != null){
			Calendar c = Calendar.getInstance();
			for (UTMap<String, Object> utMap : list) {
//				String isFestival = utMap.get("isFestival").toString();//标识是否为节假日（1.为节假日  0.非节假日）
//				if("1".equals(isFestival)){
					String festivalDate = utMap.get("festivalDate").toString();
					Date date = UTDate.getDate(festivalDate,UTDate.DATE_FORMAT);
					
					c.setTime(date);
					result +=  c.get(c.DAY_OF_MONTH) + ",";
//				}
			}
			if(result.length() > 0){
				return result.substring(0,result.length() - 1);
			}
		}
		return result;
	}
	
	
	@Override
	@EscOptionLog(module=SystemModule.manHourEdit, opType=ESCLogOpType.UPDATE, table="attendance_man_hour_edit", option="修改考勤工时")
	public boolean updateById(Map info) {
		return super.updateById(info);
	}
	
	/**
	 * 导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	@Override
	public void leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String[] fileds = IManHourEditDao.outFileds;
		String tamlate = "excelOutTamplate.manHourEdit";
		
		//替换下拉的值
		Map<String, String> fieldAndParamType = new HashMap<String, String>();
		fieldAndParamType.put(IManHourEditDao.FIELD_STATUS, "manHourEditType");
//		fieldAndParamType.put(IManHourEditDao.FIELD_STATUS, "accessEvaluateConfigurationStatus");
		sysParamService.changeParamData(data, fieldAndParamType);
		
//		Map<String,Object> param = new HashMap<String,Object>();
//		param.put("state", "1");
//		param.put("userType", "2");//查询供应商人员
//		List<UTMap<String,Object>> userMap = userService.getUserBaseInfo(param);
		if (null != data && !data.isEmpty()) {
			for (int i=0;i<data.size();i++) {
				UTMap<String, Object> item = (UTMap<String, Object>) data.get(i);
				item.put(IManHourEditDao.FIELD_YEARMONTH, CommonUtils.replaceAll((String)item.get(IManHourEditDao.FIELD_YEARMONTH), "-", "/"));
			}
		}
		//人员
//		for(int i=0;i<data.size();i++){
//			Map<String,Object> item = (Map<String, Object>) data.get(i);
//			String evaluator = (String) item.get(IManHourEditDao.FIELD_PROJECTLEADERID);
//			item.put(IManHourEditDao.FIELD_PROJECTLEADER, CommonUtils.getUserNameAndCodeById(userMap, evaluator));
//			
//			evaluator = (String) item.get(IManHourEditDao.FIELD_USERID);
//			item.put(IManHourEditDao.FIELD_USERNAME, CommonUtils.getUserNameAndCodeById(userMap, evaluator));
//		}
		
		UTExcel.leadingout( fileds, data, tamlate, request, response);
	}



}
