package com.esc.oms.outsource.manhour.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

/**
 * 工时账单
 * @author lenovo
 *
 */
public interface IManHourBillService {

	public void billPage(Map<String, Object> param, UTPageBean pageBean);
	
	public void getApprovedPage(Map<String, Object> param, UTPageBean pageBean);
	
	/**
	 * 审核：将工时数据状态更新为已确认
	 * 根据年份、季度、人员id
	 * @param info
	 * @return
	 */
	public boolean auditBill(Map<String, Object> info);
	
	public List<UTMap<String, Object>> billList(Map<String, Object> param);
	
	public List<UTMap<String, Object>> getApprovedList(Map<String, Object> param);

	/**
	 * 导出工时账单
	 * <p>表头需要根据数据自动更新，其他跟以前的导出excel一样</p>
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public boolean leadingoutBill(List<UTMap<String, Object>> data, HttpServletRequest request, HttpServletResponse response) throws Exception;

	/**
	 * 1、添加过程考核信息，过程考核名称
	 * 2、总考核结果，考核系数
	 * 3、添加季度和开始结束信息
	 * 
	 * @param billList
	 * @return 考核过程名称
	 */
	public List<String> formatBillEvaluateData(List<UTMap<String, Object>> billList);
}
