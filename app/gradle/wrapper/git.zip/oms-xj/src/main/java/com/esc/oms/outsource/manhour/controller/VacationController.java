package com.esc.oms.outsource.manhour.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTListResult;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.outsource.attendance.service.IUserConfigService;
import com.esc.oms.outsource.manhour.service.IManHourStatisticService;
import com.esc.oms.outsource.manhour.service.IVacationService;
import com.esc.oms.util.CommonUtils;

@Controller
@RequestMapping("outsource/vacation")
public class VacationController extends BaseOptionController {

	@Resource
	private IVacationService vacationService;
	
	@Resource
	private IUserConfigService userConfigService;
	
	@Resource
	private IManHourStatisticService manHourStatisticService;

	@Override
	public IBaseOptionService optionService() {
		return vacationService;
	}

	/**
	 * 执行默认的条件查询方法
	 * 
	 * @param param
	 * @return
	 */
	@RequestMapping(value = "getVacationList")
	@ResponseBody
	public UTListResult getVacationList(@RequestParam Map<String, Object> param) {
		UTListResult result = new UTListResult();
		try {
			List<UTMap<String, Object>> list = vacationService.getVacationList(param);
			result.setRows(list);
			result.setTotal(list.size());
		} catch (Exception e) {
			logger.error("Exception", e);
		}
		return result;
	}
	

	/**
	 * 新建或者编辑
	 * @param map
	 * @return
	 */
	@RequestMapping(value="save", method=RequestMethod.POST)  
    @ResponseBody
    public Map<String, Object> save(@RequestBody Map<String,Object> map) {
		try {
			//刚开始
			//驳回后可以修改和删除
			if(!IVacationService.STATUS_SUBMITD.equals(String.valueOf(map.get("status")))) {
				map.put("status", IVacationService.STATUS_NOT_SUBMIT);
			}
			if(StringUtils.isEmpty((String) map.get("id"))) {
				vacationService.add(map);
			} else {
				vacationService.updateById(map);
			}
			map.put("success", true);
			map.put("msg", "操作成功！");
		}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		map.put("success", false);
    		map.put("msg", e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		map.put("success", false);
    		map.put("msg", "操作失败！");
    	}
       return map;
	}
	
	/**
	 * 提交审批
	 * @param map
	 * @return
	 */
	@RequestMapping(value="submit", method=RequestMethod.POST)  
    @ResponseBody
    public Map<String, Object> submit(@RequestBody Map<String,Object> map) {
		try {
			vacationService.submit(map);
			map.put("success", true);
			map.put("msg", "操作成功！");
		}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		map.put("success", false);
    		map.put("msg", e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		map.put("success", false);
    		map.put("msg", "操作失败！");
    	}
       return map;
	}
	
	/**
	 * 删除
	 * @param param
	 * @return
	 */
	@RequestMapping(value="delete")
	@ResponseBody
	public String delete(@RequestBody Map<String, Object> param){
		try{
			vacationService.delete(param);
    	}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "删除失败");
    	}
    	return UTJsonUtils.getJsonMsg(true, "删除成功");
	}
	
	/**
	 * 撤销
	 * @param param
	 * @return
	 */
	@RequestMapping(value="undo")
	@ResponseBody
	public String undo(@RequestBody Map<String, Object> param){
		try{
			vacationService.undo(param);
		}catch(EscServiceException e){
			logger.error("EscServiceException", e);
			return UTJsonUtils.getJsonMsg(false, e.getMessage());
		}catch(Exception e){
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "撤销失败");
		}
		return UTJsonUtils.getJsonMsg(true, "撤销成功");
	}
	
	/**
	 * 根据编号删除
	 * @param param
	 * @return
	 */
//	@RequestMapping(value="deleteByIds")
//	@ResponseBody
//	public String deleteByIds(@RequestBody Map<String, Object> info){
//		try{
//			String ids = (String) info.get("ids");
//			if(StringUtils.isNotEmpty(ids)) {
//				Map<String, Object> param = new HashMap<String, Object>();
//				for (String id : ids.split(",")) {
//					param.put("id", id);
//					vacationService.delete(param);
//				}
//			}
//		}catch(EscServiceException e){
//			logger.error("EscServiceException", e);
//			return UTJsonUtils.getJsonMsg(false, e.getMessage());
//		}catch(Exception e){
//			logger.error("Exception", e);
//			return UTJsonUtils.getJsonMsg(false, "删除失败");
//		}
//		return UTJsonUtils.getJsonMsg(true, "删除成功");
//	}

	/**
	 * 分页查询
	 * 
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value = "getVacationPage")
	@ResponseBody
	public UTPageBean getVacationPage(@RequestParam Map<String, Object> params) {
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try {
			vacationService.getVacationPage(pageBean, params);
		} catch (Exception e) {
			logger.error("Exception", e);
		}
		return pageBean;
	}

	/**
	 * 根据id查询
	 * 
	 * @param param
	 * @return
	 */
	@RequestMapping(value = "getVacationById")
	@ResponseBody
	public UTMap<String, Object> getVacationById(
			@RequestParam Map<String, Object> param) {
		UTMap<String, Object> map = null;
		try {
			map = vacationService.getById(param.get("id").toString());
		} catch (Exception e) {
			logger.error("Exception", e);
			return new UTMap<String, Object>();
		}
		return map;
	}

	@RequestMapping(value = "leadingout")
	public void leadingout(@RequestParam Map<String, Object> param,
			HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = null;
			if(info != null) {
				jsonBean = JSONObject.fromObject(info);
			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = vacationService.getVacationList(UTMap.mapObjToString(jsonBean));
			} else {
				// 根据条件 导出当前
				vacationService.getVacationPage(utPageBean, UTMap.mapObjToString(jsonBean));
				data = utPageBean.getRows();
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			vacationService.leadingout(data, request, response);
		}catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	/**
	 * 计算当前人的工时
	 * 
	 * @param param
	 * @return
	 */
	@RequestMapping(value = "calculateHours")
	@ResponseBody
	public List<Map<String, Object>> calculateHours(@RequestParam String beginTime, @RequestParam String endTime) {
		List<Map<String, Object>> hoursList = null;
		try {
			UTMap<String, Object> userConfig = userConfigService.getUserConfigByUserId(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
			hoursList = manHourStatisticService.calculateSeconds(beginTime, endTime, userConfig);

			for (Map<String, Object> map : hoursList) {
				Long second = (Long) map.get("seconds");
				map.put("hours", UTDate.transformSecondToHour(second, true));
			}
		} catch (EscServiceException e) {
			logger.error("Exception", e);
		} catch (Exception e) {
			logger.error("Exception", e);
		}
		return hoursList;
	}
}
