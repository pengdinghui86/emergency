package com.esc.oms.outsource.manhour.service.impl;

import com.esc.oms.outsource.attendance.dao.IManHourEditDao;
import com.esc.oms.outsource.attendance.service.IManHourEditService;
import com.esc.oms.outsource.manhour.dao.IManHourBillDao;
import com.esc.oms.outsource.manhour.service.IManHourBillService;
import com.esc.oms.util.CommonUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.esc.framework.EscPropertyHolder;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcelTamplate;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedOutputStream;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.util.*;
import java.util.Map.Entry;

/**
 * 工时账单
 * @author lenovo
 *
 */
@Service
@Transactional
public class ManHourBillServiceImpl implements IManHourBillService {
	
	private static final Logger logger = Logger.getLogger(ManHourBillServiceImpl.class);
	
	@Resource
	private IManHourBillDao manHourBillDao;
	
	@Resource
	private IManHourEditService manHourEditService;
	
	@Override
	public void billPage(Map<String, Object> param, UTPageBean pageBean) {
		if(param == null) {
			param = new HashMap<String, Object>();
		}
		param.put("status", "1,2");
		manHourBillDao.billPage(param, pageBean);
	}
	
	@Override
	public List<UTMap<String, Object>> billList(Map<String, Object> param) {
		if(param == null) {
			param = new HashMap<String, Object>();
		}
		param.put("status", "1,2");
		return manHourBillDao.billList(param);
	}
	@Override
	public void getApprovedPage(Map<String, Object> param, UTPageBean pageBean) {
		if(param == null) {
			param = new HashMap<String, Object>();
		}
		param.put("status", "3");
		manHourBillDao.billPage(param, pageBean);
	}
	
	@Override
	public List<UTMap<String, Object>> getApprovedList(Map<String, Object> param) {
		if(param == null) {
			param = new HashMap<String, Object>();
		}
		param.put("status", "3");
		return manHourBillDao.billList(param);
	}
	
	public boolean auditBill(Map<String, Object> param) {
		// 1、修改工时填报为已确认
		Map<String, Object> info = new HashMap<String, Object>();
		info.put("year", param.get("year"));
		info.put("quarter", param.get("quarter"));
		info.put("userId", param.get("userId"));
		info.put("status", IManHourEditDao.STATUS_CONFIRMED); // 状态（待填报：1，已填报：2，已确认：3）
		info.put("projectId", param.get("projectId"));
		manHourEditService.updateBy(info, "year", "quarter", "userId","projectId"); // 修改工时填报为已确认
		
		// 2、生成历史记录
		manHourBillDao.saveBill(param);
		
		return true;
	}
	
	@Override
	public boolean leadingoutBill(List<UTMap<String, Object>> data, HttpServletRequest request, HttpServletResponse response) throws Exception {
        // 周期	开始日期	结束日期	月份	项目负责人	供应商	姓名	等级	月单价（元）	项目	所属部门	当季工作日	
		// evaluateNames：合规考核结果（20%）	技术绩效考核（40%）	业务绩效考核（40%）	
		// 总考核结果	考核系数	总价（元）

		String[] fileds = new String[] { 
					"period",
					"beginTime",
					"endTime",
					"businessOwnerName",
					"technicalOwnerName",
					"projectLeaderName",
					"supplierName",
					"userName",
					"level",
					"monthlyFee",
					"projectName",
					"orgName",
					"quarterManhours",
					"evaluateNum",
					"totalFee"
		};
//		List<String> evaluateNames = formatBillEvaluateData(data); // 添加过程考核数据
//		for (int i = 0; i < evaluateNames.size(); i++) {
//			fileds = ArrayUtils.add(fileds, "subName_" + i);
//		}
//		// 总考核结果	考核系数	总价（元）
//		fileds = ArrayUtils.add(fileds, "totalEvaluate");
//		fileds = ArrayUtils.add(fileds, "evaluateFactor");
//		fileds = ArrayUtils.add(fileds, "totalFee");
//		evaluateNames.add("总考核结果");
//		evaluateNames.add("考核系数");
//		evaluateNames.add("总价（元）");

		String tamlate = "excelOutTamplate.outsourceManhourBill";
		String path=EscPropertyHolder.instance.getProperty(tamlate);
		 
		//获取导出文件名称
		int l=path.lastIndexOf("/");
		int j=path.lastIndexOf("--");
		String fileName="";
		String title="";
		if(j>0){
			fileName=path.substring( j+2);
			title=fileName;
			path=path.substring(0,j);
			fileName=fileName+path.substring(path.lastIndexOf("."));
		}else {
			fileName=path.substring(l+1);
			title=fileName.substring(0,fileName.lastIndexOf("."));
		}
		//创建模板对象
		UTExcelTamplate tamplate=UTExcelTamplate.getInstance();
		//加载模板
		tamplate.readTemplateByClasspath(path);
		
		// ================重新填充表头行===================================================
//		Row titleRow = tamplate.getWb().getSheetAt(0).getRow(1);
//		CellStyle titleCellStyle = titleRow.getCell(12).getCellStyle();
//		for (int i = 0; i < evaluateNames.size(); i++) {
//			int cellIndex = i + 12;
//			Cell titleCell = titleRow.createCell(cellIndex); // 从第12列开始，前面的已经在模板定义
//			titleCell.setCellValue(evaluateNames.get(i));
//			titleCell.setCellStyle(titleCellStyle);
//		}
		// ================重新填充表头行====================================================
		
		//模板常量参数赋值
		Map<String,String> map = new HashMap<String,String>();
		map.put("title", title);
		map.put("time", "日期："+UTDate.getCurDate());
		tamplate.replaceFinalData(map);
		
		//循环填充excel
		for (UTMap< String, Object> info : data) {
			info.put("beginTime", CommonUtils.replaceAll((String)info.get("beginTime"), "-", "/"));
			info.put("endTime", CommonUtils.replaceAll((String)info.get("endTime"), "-", "/"));
			tamplate.createNewRow();
			for (int i = 0; i < fileds.length; i++) {
				String f = fileds[i];
				String v = info.get(f) != null ? info.get(f).toString() : "";
				tamplate.createCell(v);
			}
		}
		tamplate.insertSer();
		tamplate.setSheet(new String[]{title});
		
		fileName = new String(fileName.getBytes("GBK"), "ISO8859-1");
		OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
		response.addHeader("Content-Disposition", "attachment;filename=" + fileName);
		response.setContentType("application/octet-stream");
		tamplate.writeToStream(toClient);
		toClient.close();
		return true;
	}

	/**
	 * 1、添加过程考核信息，过程考核名称
	 * 2、总考核结果，考核系数
	 * 3、添加季度和开始结束信息
	 * 
	 * @param billList
	 * @return 考核过程名称
	 */
	public List<String> formatBillEvaluateData(List<UTMap<String, Object>> billList) {
		List<String> evaluateNames = new ArrayList<String>(); // 保存所有的过程考核名称
		if(billList != null) {
			Set<String> quarterSet = new HashSet<String>();
			for (UTMap<String, Object> bill : billList) {
				String quarter = (String) bill.get("quarter");
				String year = (String) bill.get("year");
				if(StringUtils.isNotEmpty(quarter) && StringUtils.isNotEmpty(year)) {
					
					// 1、添加过程考核信息，过程考核名称
					// 根据每一条记录查找过程数据，另外保存一份过程的数据===========访问数据库多
//					addEvaluateData(bill, evaluateNames);
					addEvaluateDataResult(bill);
					
					// 2、总考核结果，考核系数
					// 计算总价：(data.quarterManhours/22)*data.monthlyFee*考核系数evaluateFactor
					//总价 ：((人员单价*天数)/22)*绩效系数，
					if(bill.get("totalFee") == null) {
						if(bill.get("quarterManhours") == null) {
							bill.put("quarterManhours", Double.valueOf(0));
						}
						if(bill.get("quarterManDays") == null){
							bill.put("quarterManDays", Double.valueOf(0));
						}
						if(bill.get("monthlyFee") == null) {
							bill.put("monthlyFee", Double.valueOf(0));
						}
						Double quarterManhours = (Double) bill.get("quarterManhours");
						Double monthlyFee = (Double) bill.get("monthlyFee");
						Double quarterManDays = (Double) bill.get("quarterManDays");
						// 考核系数
						Double evaluateNum = (Double) bill.get("evaluateNum");
						if(evaluateNum == null ) {
							evaluateNum = new Double(1);
						}
						
						DecimalFormat df = new DecimalFormat("######0.00");
//						bill.put("totalFee", df.format(quarterManhours/22*monthlyFee*evaluateFactor));
						bill.put("totalFee", df.format(evaluateNum*monthlyFee*quarterManDays/22));
					}
					
					// 3、添加季度和开始结束信息，列表只显示一次同一个年度季度
					if("1".equals(quarter) && !quarterSet.contains(year + "年第一季度")) {
						bill.put("period", year + "年第一季度");
						bill.put("beginTime", year + "-01-01");
						bill.put("endTime", year + "-03-31");
						quarterSet.add(year + "年第一季度");
					} else if("2".equals(quarter) && !quarterSet.contains(year + "年第二季度")) {
						bill.put("period", year + "年第二季度");
						bill.put("beginTime", year + "-04-01");
						bill.put("endTime", year + "-06-30");
						quarterSet.add(year + "年第二季度");
					} else if("3".equals(quarter) && !quarterSet.contains(year + "年第三季度")) {
						bill.put("period", year + "年第三季度");
						bill.put("beginTime", year + "-07-01");
						bill.put("endTime", year + "-09-30");
						quarterSet.add(year + "年第三季度");
					} else if("4".equals(quarter) && !quarterSet.contains(year + "年第四季度")) {
						bill.put("period", year + "年第四季度");
						bill.put("beginTime", year + "-10-01");
						bill.put("endTime", year + "-12-31");
						quarterSet.add(year + "年第四季度");
					}
				}
			}
		}
		return evaluateNames;
	}
	
	/**
	 * 添加过程考核信息
	 * 根据每一条记录查找过程数据，另外保存一份过程的数据===========访问数据库次数多
	 * @param bill
	 * @param evaluateNames 用于保存考核过程名称
	 */
	private void addEvaluateData(UTMap<String, Object> bill, List<String> evaluateNames) {
		String quarter = (String) bill.get("quarter");
		String year = (String) bill.get("year");
		String userId = (String) bill.get("userId");

		Map<String, String> param = new HashMap<String, String>();
		param.put("year", year);
		param.put("quarter", quarter);
		param.put("userId", userId);
		param.put("type", "2"); // 只需要查询过程的
		List<UTMap<String, Object>> evaluateDetailList = manHourBillDao.evaluateDetailList(param);
		// 计算分数、和过程名称处理
		if(evaluateDetailList != null && evaluateDetailList.size() > 0) {
			Map<String, Map<String, Object>> resultMaps = new HashMap<String, Map<String,Object>>(); // 保存过程名称和过程考核结果
			
			// 对考核的每条记录处理，1、考核系数，2、计算过程的考核平均，和记录过程考核的名称
			for (UTMap<String, Object> evaluateDetail : evaluateDetailList) {
				String type = (String) evaluateDetail.get("type"); // 考核类型：1是总考核、2是过程考核
				if("1".equals(type)) { // 1是总考核
					String finalResult = (String) evaluateDetail.get("evaluateResult"); // 考核结果：可能是分数，也可能不是数字
					try {
						// 将考核结果转换为数字：1、如果转换出错，考核系数为1，2、可以转换的乘以百分比后相加，最后除以个数，得到最后的结果
						Double evaluateValue = Double.valueOf(finalResult);
						bill.put("evaluateFactor", evaluateValue); // 考核系数
					} catch (Exception e) {
						logger.error(CommonUtils.vaildLog("总考核结果（非数值），全部为1：" + finalResult));
						bill.put("evaluateFactor", Double.valueOf(1)); // 考核系数
					}
				} else { // 2是过程考核
					String evaluateName = (String) evaluateDetail.get("evaluateName"); // 考核名称
					Integer percent = (Integer) evaluateDetail.get("percent"); // 百分比
					String evaluateResult = (String) evaluateDetail.get("evaluateResult"); // 考核结果：可能是分数，也可能不是数字
					
					// 保存过程考核名称：有百分比是有比重的，没有比重的不添加百分比信息
					String evaluatePercentName = (percent == null ? evaluateName : evaluateName + "(" + percent + "%)");
					if(!evaluateNames.contains(evaluatePercentName)) {
						evaluateNames.add(evaluatePercentName);
					}
					
					try {
						// 将考核结果转换为数字：1、如果转换出错，那么就忽略，2、可以转换的乘以百分比后相加，最后除以个数，得到最后的结果
						Double evaluateValue = Double.valueOf(evaluateResult);

						// 需要区分每一个过程考核
						// 20160905 bug3727 不需要乘以百分数
						if(!resultMaps.containsKey(evaluatePercentName)) {
							Map<String, Object> result = new HashMap<String, Object>();
							result.put("result", Double.valueOf(evaluateValue));
							result.put("size", 1);
							result.put("percent", percent);
							resultMaps.put(evaluatePercentName, result);
						} else {
							Map<String, Object> result = resultMaps.get(evaluatePercentName);
							result.put("result", (Double) result.get("result") + (evaluateValue));
							result.put("size", (Integer) result.get("size") + 1);
							result.put("percent", percent);
							resultMaps.put(evaluatePercentName, result);
						}
						
					} catch (Exception e) {
						logger.error(CommonUtils.vaildLog("无效的考核结果（非数值），不统计：" + evaluateResult));
					}
				}
				
			}
			
			double totalEvaluate = 0; // 总考核结果：考核结果的过程评估总分
			// 保存过程考核结果到页面列表中：通过名称位置添加新的变量
			for (Entry<String, Map<String, Object>> result : resultMaps.entrySet()) {
				String resultName = result.getKey();
				int index = evaluateNames.indexOf(resultName);
				Map<String, Object> resultMap = result.getValue();
				double value = (Double) resultMap.get("result") / (Integer) resultMap.get("size");
				totalEvaluate += value * ((Integer) resultMap.get("percent")).doubleValue() / 100;
				bill.put("subName_" + index, value);
			}
			DecimalFormat df = new DecimalFormat("######0.00");
			bill.put("totalEvaluate", df.format(totalEvaluate)); // 总考核结果
		}
	}

	/**
	 * 添加结果考核信息
	 * @param bill
	 * @param evaluateNames
	 */
	private void addEvaluateDataResult(UTMap<String, Object> bill) {
		String quarter = (String) bill.get("quarter");
		String year = (String) bill.get("year");
		String userId = (String) bill.get("userId");
		String projectId = (String) bill.get("projectId");
		Map<String, String> param = new HashMap<String, String>();
		param.put("year", year);
		param.put("quarter", quarter);
		param.put("userId", userId);
		param.put("type", "1"); // 只需要查询结果的
		param.put("projectId", projectId);
		List<UTMap<String, Object>> evaluateDetailList = manHourBillDao.evaluateDetailList(param);
		// 根据结果获取处理值
		if(evaluateDetailList != null && evaluateDetailList.size() > 0) {
			//存在多个时，取第一个
			Map<String, Object> evaluateDetail = evaluateDetailList.get(0);
			//对数据进行处理，根据得到的系数值来
			String finalResult = (String) evaluateDetail.get("totalNum"); // 考核结果：可能是分数，也可能不是数字
			try {
				// 将考核结果转换为数字：1、如果转换出错，考核系数为1，2、可以转换的乘以百分比后相加，最后除以个数，得到最后的结果
				Double evaluateValue = Double.valueOf(finalResult);
				bill.put("evaluateNum", evaluateValue); // 考核系数
			} catch (Exception e) {
				logger.error(CommonUtils.vaildLog("总考核结果（非数值），全部为1：" + finalResult));
				bill.put("evaluateFactor", Double.valueOf(1)); // 考核系数
			}
		}

	}
}
