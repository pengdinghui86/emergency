package com.esc.oms.outsource.performance.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.performance.dao.IPerformanceEvaluateDao;
import com.esc.oms.util.RoleUtils;

/**
 * 外包绩效考核Dao
 * @author owner
 *
 */
@Repository
public class PerformanceEvaluateDaoImpl extends BaseOptionDao implements IPerformanceEvaluateDao{

	@Override
	public String getTableName() {
		return "outsourc_performance_evaluate";
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params,false), pageBean, null);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params) {
		return super.getListBySql(getSearchSql(params,false), null);
	}
	
	@Override
	public UTMap<String, Object> getById(String id) {
		String sql = this.getSearchSql(null,true);
		List<UTMap<String, Object>> list = super.getListBySql(sql, id);
		if(list != null && list.size() > 0){
			return list.get(0);
		}
		return null;
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params,boolean isGetById){
		StringBuilder sql = new StringBuilder();
		sql.append(" select sae.*,concat(su.name,'/',su.code) as 'evaluatorName',concat(su2.name,'/',su2.code) as 'submitterName',saet.evaluateBeginDate, saet.evaluateEndDate ");
		sql.append(" ,saet.evaluateName,saet.templateConfigurationId,saet.templateConfigurationName,saet.templateConfigurationVersions,saet.createTime as 'templateConfigurationCreateTime' ");
		sql.append(" ,saec.evaluateTitle,saec.beginDate,saec.endDate,saec.status as 'accessEvaluateConfigurationStatus',saec.year,saec.month,saec.unit,saec.half,saec.quarter,saec.cycleBeginDate,saec.cycleEndDate,pi.name as 'projectInfoName' ");
		sql.append(" from outsourc_performance_evaluate sae ");
		sql.append(" left join outsourc_performance_evaluate_template saet on sae.performanceEvaluateTemplateId = saet.id ");
		sql.append(" left join outsourc_performance_evaluate_configuration saec on saet.performanceEvaluateConfigId = saec.id ");
//		sql.append(" left join supplier_base_info sbi on saec.supplierId = sbi.id ");
		sql.append(" left join sys_user su on sae.evaluator = su.id ");
		sql.append(" left join sys_user su2 on sae.submitter = su2.id" );
		sql.append(" left join project_info pi on pi.id=sae.projectInfoId ");
		sql.append(" where saet.evaluateBeginDate <= '"+UTDate.getCurDate()+"' ");//根据评估配置的开始时间来判断是否可以进行评估
		if(isGetById){
			sql.append(" and sae.id = ? ");
		}
		if(params!=null && params.size()>0){
			//评估页面只能看自己的数据
			if(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId() != null && params.get("isEvaluate") != null && !EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR)){
				sql.append(" and sae.evaluator like '%"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"%' ");
			}
			if(params.get("evaluateName")!=null &&  StringUtils.isNotEmpty(params.get("evaluateName").toString())){
				sql.append(" and saet.evaluateName like '%"+params.get("evaluateName").toString().trim()+"%' ");
			}
			if(params.get("year")!=null &&  StringUtils.isNotEmpty(params.get("year").toString())){
				sql.append(" and saec.year = '"+params.get("year").toString().trim()+"' ");
			}
			if(params.get("unit")!=null &&  StringUtils.isNotEmpty(params.get("unit").toString())){
				sql.append(" and saec.unit = '"+params.get("unit").toString().trim()+"' ");
			}
			if(params.get("half")!=null &&  StringUtils.isNotEmpty(params.get("half").toString())){
				sql.append(" and saec.half = '"+params.get("half").toString().trim()+"' ");
			}
			if(params.get("quarter")!=null &&  StringUtils.isNotEmpty(params.get("quarter").toString())){
				sql.append(" and saec.quarter = '"+params.get("quarter").toString().trim()+"' ");
			}
			if(params.get("month")!=null &&  StringUtils.isNotEmpty(params.get("month").toString())){
				sql.append(" and saec.month = '"+params.get("month").toString().trim()+"' ");
			}
			if(params.get("status")!=null &&  StringUtils.isNotEmpty(params.get("status").toString())){
				sql.append(" and sae.status = '"+params.get("status").toString().trim()+"' ");
			}
			if(params.get("accessEvaluateConfigurationStatus")!=null && StringUtils.isNotEmpty(params.get("accessEvaluateConfigurationStatus").toString())){
				sql.append(" and saec.status = "+params.get("accessEvaluateConfigurationStatus").toString().trim()+" ");
			}
			if(params.get("evaluateTitle")!=null &&  StringUtils.isNotEmpty(params.get("evaluateTitle").toString())){
				sql.append(" and saec.evaluateTitle like '%"+params.get("evaluateTitle").toString().trim()+"%' ");
			}
			if(params.get("performanceEvaluateConfigId")!=null && StringUtils.isNotEmpty(params.get("performanceEvaluateConfigId").toString())){
				sql.append(" and sae.performanceEvaluateConfigId = '"+params.get("performanceEvaluateConfigId").toString().trim()+"' ");
			}
			if(params.get("isSendMessageDate")!=null){//如果是查询当天需要发送消息的数据
				sql.append(" and saet.evaluateBeginDate = '"+UTDate.getCurDate()+"' and sae.status != 2 ");//
			}
		}
		if(params!=null && params.get("isProcessUserList")!=null){
			sql.append(" order by saec.evaluateTitle");
		}else if (params!=null && params.get("isEvaluate")!=null) {
			sql.append(" order by saec.year desc, saec.evaluateTitle,pi.name,saet.evaluateName  ");
		}else{
			sql.append(" order by sae.createTime desc");
		}
		
		return  sql.toString();
	}

}
