package com.esc.oms.asset.software.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.asset.software.dao.ISoftCategoryDao;
@Repository
public class SoftCategoryDaoImpl extends BaseOptionDao implements ISoftCategoryDao{
	
//	private String propertyTableName = "assets_material_category_property";
//	private String optionTableName = "assets_material_category_option";
	
	private String subCategoryTableName = "software_sub_category";
	
//	private String subPropertyTableName = "assets_material_sub_category_property";

	@Override
	public String getTableName() {
		return "software_category";
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params), pageBean, null);
	}
	
	
	@Override
	public List<UTMap<String, Object>> getListMaps(Map param) {
		return this.getListBySql(getSearchSql(param));
	}
	
	
	public List<UTMap<String, Object>> getListCategory(Map params) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT amc.name ,amc.id ,amc.remark parentRemark,amc.type");
		sql.append(" FROM software_category amc where 1=1 ");
		if(params != null) {
			String type = (String) params.get("type");
			if(StringUtils.isNotEmpty(type)) {
				sql.append(" and amc.type = '" + type + "' ");
			}
		}
		sql.append(" ORDER BY CONVERT(amc.`name` USING gbk) ");
		return  this.getListBySql(sql.toString());   
	}
	
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params){
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT amc.name ,amc.id parentId,amc.remark parentRemark,amsc.id,amsc.name subName,amsc.remark subRemark,amsc.value,amc.type");
		sql.append(" FROM software_category amc  ");
		sql.append(" LEFT JOIN software_sub_category amsc ON amsc.parentId = amc.id  ");
		
		sql.append(" where 1=1 ");
		if(params != null) {
			String name = (String) params.get("name");
			String type = (String) params.get("type");
			if(StringUtils.isNotEmpty(name)) {
				sql.append(" and amc.name like '%" + name + "%' ");
			}
			if(StringUtils.isNotEmpty(type)) {
				sql.append(" and amc.type = '" + type + "' ");
			}
			String subCategoryName = (String) params.get("subCategoryName");
			if(StringUtils.isNotEmpty(subCategoryName)) {
				sql.append(" and amsc.name like '%" + subCategoryName + "%' ");
			}
		}
//		if(params != null) {
//			String name = (String) params.get("name");
//			if(StringUtils.isNotEmpty(name)) {
//				sql.append(" and amc.name like '%" + name + "%' ");
//			}
//			String subCategoryName = (String) params.get("subCategoryName");
//			if(StringUtils.isNotEmpty(subCategoryName)) {
//				sql.append(" and amsc.name like '%" + subCategoryName + "%' ");
//			}
//		}
		sql.append(" ORDER BY CONVERT(amc.`name` USING gbk) ");
		return  sql.toString();
	}

	
	/*public boolean addProperty(Map info) {
		return super.saveBySql(propertyTableName, info);
	}
*/
	/*@Override
	public boolean addPropertyOption(Map info) {
		return super.saveBySql(optionTableName, info);
	}*/
	
	/*private String getPropertyByCategoryIdSql(String categoryId){
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT amcp.categoryId,amcp.`name`,amcp.remark,amcp.type,amcp.id,amcp.value ");
		sql.append(" FROM assets_material_category_property amcp ");
		sql.append(" LEFT JOIN assets_material_info ami ON ami.id = amcp.categoryId ");
		sql.append(" WHERE amcp.categoryId = '"+categoryId+"'");
		sql.append(" ORDER BY amcp.createTime ");
		return  sql.toString();
	}*/
	
	/*private String getOptionByPropertyIdSql(String propertyId){
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT amco.id,amco.categoryId,amco.`name`,amco.`value`,amco.remark ");
		sql.append(" FROM assets_material_category_option amco ");
		sql.append(" LEFT JOIN assets_material_category_property amcp ON amcp.id = amco.categoryId ");
		sql.append(" WHERE amco.categoryId = '"+propertyId+"'");
		sql.append(" ORDER BY amco.createTime ");
		return  sql.toString();
	}*/

	/*@Override
	public List<UTMap<String, Object>> getPropertyByCategoryId(String categoryId) {
		return super.getListBySql(getPropertyByCategoryIdSql(categoryId));
	}

	@Override
	public List<UTMap<String, Object>> getOptionByPropertyId(String propertyId) {
		return super.getListBySql(getOptionByPropertyIdSql(propertyId));
	}

	@Override
	public boolean updatePropertyByCategoryId(Map info) {
		return super.updateById(propertyTableName, info);
	}

	@Override
	public boolean updateOptionByPropertyId(Map info) {
		return super.updateById(optionTableName, info);
	}
*/
	@Override
	public boolean addSubCategory(Map info) {
		return super.saveBySql(subCategoryTableName, info);
	}
	
	/**
	 * 检查资产小类是否已经存在name
	 * @param info
	 * @return
	 */
	public boolean checkSubCategory(Map info) {
		String sql = " select * from  " + subCategoryTableName + " where parentId = ? and name = ?";
		return this.getCount(sql, info.get("parentId"), info.get("name")) > 0;
	}

	/*@Override
	public boolean addSubPropertyOption(Map info) {
		return super.saveBySql(subPropertyTableName, info);
	}*/

	@Override
	public boolean updateSubCategoryById(Map info) {
		return super.updateById(subCategoryTableName, info);
	}

/*	@Override
	public boolean updateSubPropertyById(Map info) {
		return super.updateById(subPropertyTableName, info);
	}*/

	private String getSubPropertyByIdSql(String subCategoryId){
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT amscp.id,amscp.`name`,amscp.remark,amscp.type ");
		sql.append(" FROM assets_material_sub_category_property amscp ");
		sql.append(" LEFT JOIN assets_material_sub_category amsc ON amsc.id = amscp.subCategoryId ");
		sql.append(" WHERE amscp.subCategoryId = '"+subCategoryId+"'");
		sql.append(" ORDER BY amscp.createTime ");
		return  sql.toString();
	}
	
	private String getSubOptionByIdSql(String propertyId){
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT amco.id,amco.categoryId,amco.`name`,amco.`value`,amco.remark ");
		sql.append(" FROM assets_material_sub_category_property amscp ");
		sql.append(" LEFT JOIN assets_material_category_option amco ON amco.categoryId = amscp.id ");
		sql.append(" WHERE amco.categoryId = '"+propertyId+"'");
		sql.append(" ORDER BY amscp.createTime ");
		return  sql.toString();
	}
	
	@Override
	public UTMap<String, Object> getSubCategoryById(String id) {
		return super.getMapById(subCategoryTableName, null, id);
	}

	@Override
	public List<UTMap<String, Object>> getSubPropertyById(String id) {
		return super.getListBySql(getSubPropertyByIdSql(id));
	}

	@Override
	public List<UTMap<String, Object>> getSubOptionById(String id) {
		return super.getListBySql(getSubOptionByIdSql(id));
	}
	
	private String deletePropertySql(String categoryId){
		StringBuilder sql = new StringBuilder();
		sql.append(" DELETE FROM assets_material_category_property ");
		sql.append(" WHERE categoryId = '"+categoryId+"'");
		return  sql.toString();
	}
	
	private String deleteOptionSql(String categoryId){
		StringBuilder sql = new StringBuilder();
		sql.append(" DELETE FROM assets_material_category_option ");
		sql.append(" WHERE categoryId = '"+categoryId+"'");
		return  sql.toString();
	}
	
	private String deleteSubPropertySql(String categoryId){
		StringBuilder sql = new StringBuilder();
		sql.append(" DELETE FROM assets_material_sub_category_property ");
		sql.append(" WHERE subCategoryId = '"+categoryId+"'");
		return  sql.toString();
	}
	
	private String deleteSubCategorySql(String id){
		StringBuilder sql = new StringBuilder();
		sql.append(" DELETE FROM software_sub_category ");
		sql.append(" WHERE id = '"+id+"'");
		return  sql.toString();
	}
	
	private String getSubCategoryByParentIdSql(String parentId){
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT amsc.id,amsc.`name`,amsc.parentId,amsc.`value`,amsc.remark ");
		sql.append(" FROM software_sub_category amsc");
		sql.append(" WHERE amsc.parentId ='"+parentId+"'");
		sql.append(" ORDER BY amsc.createTime ");
		return  sql.toString();
	}

	/*@Override
	public boolean deleteProperty(String categoryId) {
		return super.executeUpdate(deletePropertySql(categoryId));
	}

	@Override
	public boolean deleteOption(String categoryId) {
		return super.executeUpdate(deleteOptionSql(categoryId));
	}*/

	@Override
	public boolean deleteSubProperty(String categoryId) {
		return super.executeUpdate(deleteSubPropertySql(categoryId));
	}

	@Override
	public boolean deleteSubCategory(String id) {
		return super.executeUpdate(deleteSubCategorySql(id));
	}

	@Override
	public List<UTMap<String, Object>> getSubCategoryByParentId(String parentId) {
		return super.getListBySql(getSubCategoryByParentIdSql(parentId));
	}

	@Override
	public String getCategoryIdByName(Map<String, Object> params) {
		String id = "";
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT amc.id ");
		sql.append(" FROM software_category amc  ");
		sql.append(" where 1=1 ");
		if(params != null) {
			String name = (String) params.get("name");
			if(StringUtils.isNotEmpty(name)) {
				sql.append(" and amc.name = '" + name + "' ");
			}
		}
		UTMap<String,Object> ut = super.getOneBySql(sql.toString(), null);
		if(null != ut){
			id = ut.get("id").toString();
		}
		return id;
	}

	@Override
	public String getSubCategoryIdByName(Map<String, Object> params) {
		String id = "";
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT amsc.id ");
		sql.append(" FROM software_sub_category amsc  ");
		sql.append(" LEFT JOIN software_category amc ON amc.id = amsc.parentId  ");
		sql.append(" where 1=1 ");
		if(params != null) {
			String name = (String) params.get("name");
			String parentId = (String)params.get("parentId");
			if(StringUtils.isNotEmpty(name)) {
				sql.append(" and amsc.name = '" + name + "' ");
			}
			if(StringUtils.isNotEmpty(parentId)) {
				sql.append(" and amc.id = '" + parentId + "' ");
			}
		}
		UTMap<String,Object> ut = super.getOneBySql(sql.toString(), null);
		if(null != ut){
			id = ut.get("id").toString();
		}
		return id;
	}
	
	private String deleteSubCategoryByParentIdSql(String parentId){
		StringBuilder sql = new StringBuilder();
		sql.append(" DELETE FROM software_sub_category ");
		sql.append(" WHERE parentId = '"+parentId+"'");
		return  sql.toString();
	}

	@Override
	public boolean deleteSubCategoryByParentId(String parentId) {
		return super.executeUpdate(deleteSubCategoryByParentIdSql(parentId));
	}

	@Override
	public List<UTMap<String, Object>> getCategoryByNameAndId(String name,
			String id) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT * ");
		sql.append(" FROM software_category amc where 1=1");
//		sql.append(" and amc.id ='"+id+"'");
		sql.append(" and amc.name ='"+name+"'");
		return super.getListBySql(sql.toString());
	}
	
	@Override
	public List<UTMap<String, Object>> getCategoryByType(String type) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT ssc.id,ssc.name,ssc.parentId ");
		sql.append(" FROM software_sub_category ssc  ");
		sql.append(" LEFT JOIN software_category sc on ssc.parentId=sc.id where 1=1");
		sql.append(" and sc.type ='"+type+"'");
		sql.append(" order by ssc.createTime ");
		return super.getListBySql(sql.toString());
	}

	@Override
	public UTMap<String, Object> getSubCategoryByNameAndCategoryId(
			String name, String parentId) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT * ");
		sql.append(" FROM software_sub_category amsc  ");
		sql.append(" WHERE amsc.parentId ='"+parentId+"'");
		sql.append(" AND amsc.name ='"+name+"'");
		return super.getOneBySql(sql.toString(), null);
	}

	@Override
	public List<UTMap<String, Object>> getSubCategoryByNameAndCategoryIdAndSubCategoryId(String name,String id,String parentId) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT * ");
		sql.append(" FROM software_sub_category amsc WHERE 1=1");
//		sql.append(" WHERE amsc.id ='"+id+"'");
		sql.append(" AND amsc.parentId ='"+parentId+"'");
		sql.append(" AND amsc.name ='"+name+"'");
		return super.getListBySql(sql.toString());
	}

//	@Override
//	public UTMap<String, Object> getIdBySubCategoryNameAndCategoryName(
//			String categoryName, String subCategoryName) {
//		StringBuilder sql = new StringBuilder();
//		sql.append(" SELECT * ");
//		sql.append(" FROM assets_material_sub_category amsc  ");
//		sql.append(" LEFT JOIN assets_material_category amc ON amc.id = amsc.parentId  ");
//		sql.append(" WHERE amsc.`name` = '"+subCategoryName+"'");
//		sql.append(" AND amc.`name` = '"+categoryName+"'");
//		return super.getOneBySql(sql.toString(), null);
//	}
}
