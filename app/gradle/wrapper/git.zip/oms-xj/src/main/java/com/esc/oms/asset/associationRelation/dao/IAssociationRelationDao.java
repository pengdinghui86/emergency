package com.esc.oms.asset.associationRelation.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

public interface IAssociationRelationDao extends IBaseOptionDao{
	
	public boolean deletePhysicalAssetsById(String id);
	
	public boolean deleteSoftwareAssetsById(String id);
	
	public List<UTMap<String,Object>> getPhysicalAssetsById(String id);
	
	public List<UTMap<String,Object>> getSoftwareAssetsById(String id);
	
	public boolean addPhysicalAssets(Map info);
	
	public boolean addSoftwareAssets(Map info);
	
	public List<UTMap<String,Object>> getAssets();
	
	public List<UTMap<String,Object>> getPhyRelByAssetsId(String id);
	
	public UTMap<String,Object> getAssetsByCode(String code);
	
	public List<UTMap<String,Object>> getAssetsById(String assetsId);
	
}
