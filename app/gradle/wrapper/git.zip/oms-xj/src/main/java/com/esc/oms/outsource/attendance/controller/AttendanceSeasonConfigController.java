package com.esc.oms.outsource.attendance.controller;

import com.esc.oms.outsource.attendance.service.IAttendanceSeasonConfigService;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.Map;
@Controller
@RequestMapping("attendanceSeasonConfig")
public class AttendanceSeasonConfigController extends BaseOptionController {

    @Resource
    private IAttendanceSeasonConfigService attendanceSeasonConfigService;
    @Override
    public IBaseOptionService optionService() {
        return attendanceSeasonConfigService;
    }


    /**
     * 判断年份是否存在
     * @param map
     * @return
     */
    @RequestMapping(value="isExitItem")
    @ResponseBody
    public String isExitItem(@RequestParam Map<String, Object> map){
        if(attendanceSeasonConfigService.isExistYear(map)){
            return UTJsonUtils.getJsonMsg(false, "已存在的年份");
        }
        return UTJsonUtils.getJsonMsg(true, "");
    }
}
