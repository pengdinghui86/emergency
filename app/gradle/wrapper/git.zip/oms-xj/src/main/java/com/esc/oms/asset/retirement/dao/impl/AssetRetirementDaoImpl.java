package com.esc.oms.asset.retirement.dao.impl;

import com.esc.oms.asset.retirement.dao.IAssetRetirementDao;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
@Repository
public class AssetRetirementDaoImpl extends BaseOptionDao implements IAssetRetirementDao{
	
	private String relationTableName = "assets_material_scrap_detail";

	@Override
	public String getTableName() {
		return "assets_material_repair_scrap";
	}

	@Override 
	public boolean addRelation(Map info) {
		return	super.saveBySql(relationTableName, info);
	}

	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params), pageBean, null);
	}
	
	@Override
	public List<UTMap<String, Object>> getListMaps(Map param) {
		return super.getListBySql(getSearchSql(param));
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT DISTINCT amrs.id,amrs.name,amrs.`code`,amrs.reason,amrs.scrapDate,amrs.status, " );
		sql.append(" amrs.createUser,DATE_FORMAT(amrs.createTime,'%Y-%m-%d') createTime,amrs.remark,amrs.createUserId ");
		
		sql.append(" FROM "+getTableName()+" amrs ");
	    sql.append(" WHERE 1=1 ");
		
		if(params!=null && params.size()>0){
			if(params.get("beginTime")!=null && StringUtils.isNotEmpty((String) params.get("beginTime"))){
				sql.append(" AND DATE_FORMAT(amrs.createTime,'%Y-%m-%d') >= '"+params.get("beginTime").toString().trim()+"'");
			}
			if(params.get("endTime")!=null && StringUtils.isNotEmpty((String) params.get("endTime"))){
				sql.append(" AND DATE_FORMAT(amrs.createTime,'%Y-%m-%d') <= '"+params.get("endTime").toString().trim()+"'");
			}
			if(params.get("reason")!=null && StringUtils.isNotEmpty((String) params.get("reason"))){
				sql.append(" AND amrs.reason = '"+params.get("reason").toString().trim()+"'");
			}
		}
	
		sql.append(" order by amrs.createTime desc");
		return  sql.toString();
	}
	
	private String getAssetsByIdSql(String id){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT ami.id,ami.`name`,ami.`code`,amc.`name` categoryName,amsc.`name` subCategoryName,concat(ami.`name`,IF ( ami.serialNum IS NULL OR ami.serialNum = '', '', concat('/', ami.serialNum))) assetsNameCode, " );
		sql.append(" so.`name` resDepartId,ami.buyContract,ami.maintainContract,concat(su.`name`, '/', su.`code`) resUserId,ami.brand,ami.model,ap.`name` location ");
		sql.append(" ,amsd.isDestroy,if(amsd.isDestroy=1,'是','否') isDestroyStr, ami.assetsLevel");
		sql.append(" FROM assets_material_info ami ");
		sql.append(" LEFT JOIN assets_material_scrap_detail amsd ON amsd.assetsId = ami.id ");
		sql.append(" LEFT JOIN assets_material_category amc ON amc.id = ami.category ");
		sql.append(" LEFT JOIN assets_material_category amsc ON amsc.id = ami.subCategory ");
		sql.append(" LEFT JOIN sys_user su ON su.id = ami.resUserId ");
		sql.append(" LEFT JOIN sys_org so ON so.id = ami.resDepartId ");
		sql.append(" LEFT JOIN assets_place ap ON ap.id = ami.location ");
		sql.append(" WHERE 1=1 AND amsd.applyId = '"+id+"'");
		return  sql.toString();
	}
	

	@Override
	public List<UTMap<String, Object>> getAssetsList(Map param) {
		return super.getListBySql(getSearchSql(param));
	}

	@Override
	public List<UTMap<String, Object>> getAssetsById(String id) {
		return super.getListBySql(getAssetsByIdSql(id));
	}

	@Override
	public boolean deleteAssetsById(String id) {
		StringBuilder sql=new StringBuilder();
		sql.append(" DELETE  FROM "
				 + relationTableName
				 + " WHERE applyId = '" +id+"'");
		return super.executeUpdate(sql.toString());
	}
	
	
}
