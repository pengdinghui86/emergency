package com.esc.oms.outsource.grouporg.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.AbstractBaseSqlDao;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.grouporg.dao.IGroupOrgDao;


@Repository
public class GroupOrgDaoImpl extends BaseOptionDao  implements IGroupOrgDao {

	@Override
	public String getTableName() {
		return "group_emergency_org";
	}
	
	@Override
	public boolean saveGroupOrg(List<Map> info,int groupOrgType) {
		StringBuilder sql=new StringBuilder();
		sql.append("delete from group_emergency_org where groupOrgType='"+groupOrgType+"'");
		super.executeUpdate(sql.toString(),null);
		return super.batchSave("group_emergency_org", info);
	}

	@Override
	public boolean saveGroupUser(List<Map> info,String groupOrgIds) {
		StringBuilder sql=new StringBuilder();
		sql.append("delete from group_emergency_user where find_in_set(groupId,'"+groupOrgIds+"')");
		super.executeUpdate(sql.toString(),null);
		if(info.size() == 0) {
			return true;
		}
		return super.batchSave("group_emergency_user", info);
	}

	@Override
	public List<UTMap<String, Object>> getGroupOrgAndUser(int groupOrgType) {
		StringBuilder sql=new StringBuilder();
		sql.append(" select ogd.id ,ogd.groupName as name ,eorg.parentId pId from");
		sql.append(" group_emergency_org eorg ");
		if(groupOrgType==1){
			sql.append(" left join outsource_group_define ogd on eorg.groupId=ogd.id");
		}else{
			sql.append(" left join outsource_emergroup_define ogd on eorg.groupId=ogd.id");
		}
	sql.append(" where groupOrgType='"+groupOrgType+"' and ogd.id IS NOT NULL order by eorg.sort asc");
		List<UTMap<String, Object>>groupList =super.getListBySql(sql.toString(), null);
		 sql=new StringBuilder();
		 //查询 外包管理组织结构成员
		if(groupOrgType==1){
			sql.append(" select u.id,egu.groupPost role,egu.groupId groupId,u.orgId pId  ,u.code, CONCAT(u.name,'/',u.code)  name ,ogd.groupName pName ,");
			sql.append(" u.phone,u.email ,  replace(u.orgName,'!','/') orgName ");
			sql.append(" from group_emergency_user egu");
			sql.append(" left join sys_user u on egu.userId=u.id");
			sql.append(" left join outsource_group_define ogd on ogd.id=egu.groupId");
			sql.append(" WHERE u.id is not NULL");
			sql.append(" order by u.code asc");
		}
		 //查询 外包应急组织结构成员
		else{
			sql.append(" select u.id,egu.groupPost role,egu.groupId groupId,u.orgId pId  , u.code, CONCAT(u.name,'/',u.code)  name ,ogd.groupName pName ,");
			sql.append(" u.phone,u.email ,  replace(u.orgName,'!','/') orgName ");
			sql.append(" from group_emergency_user egu");
			sql.append(" left join sys_user u on egu.userId=u.id");
			sql.append(" left join outsource_emergroup_define ogd on ogd.id=egu.groupId");
			sql.append(" WHERE u.id is not NULL");
			sql.append(" order by u.code asc");
		}
		List<UTMap<String, Object>>userList =super.getListBySql(sql.toString(), null);
		Map<String, List<UTMap<String, Object>>> userMap=new HashMap<String, List<UTMap<String,Object>>>();
		for (UTMap<String, Object> utMap : userList) {
			String groupId=utMap.get("groupId").toString();
			if(userMap.containsKey(groupId)){
				userMap.get(groupId).add(utMap);
			}else{
				List<UTMap<String, Object>>l=new ArrayList<UTMap<String,Object>>();
				l.add(utMap);
				userMap.put(groupId, l);
			}
		}
	
		for (UTMap<String, Object> utMap : groupList) {
			String groupId=utMap.get("id").toString();
			if(userMap.containsKey(groupId)){
				utMap.put("users",userMap.get(groupId));
			}
		}
		return groupList;
	}


	//根据小组Id 删除 结构
	
	//根据小组Id 删除 小组成员
	public boolean deleteGroupUserByGroutId(String groupIds){
		StringBuilder sql=new StringBuilder();
		sql.append(" delete from group_emergency_user where find_in_set( groupId,'"+groupIds+"') ");
		return super.executeUpdate(sql.toString(), null);
	}
	
	
}
