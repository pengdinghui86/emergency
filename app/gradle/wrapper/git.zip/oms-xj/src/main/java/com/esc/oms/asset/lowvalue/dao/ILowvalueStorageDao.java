package com.esc.oms.asset.lowvalue.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

public interface ILowvalueStorageDao extends IBaseOptionDao{
	
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_CATEGORY = "category";
	public static final String  FIELD_CODE = "code";
	public static final String  FIELD_NAME = "name";
	public static final String  FIELD_IS_NEW = "isNew";
	public static final String  FIELD_INFO_ID = "infoId";
	public static final String  FIELD_BRAND = "brand";
	public static final String  FIELD_MODEL = "model";
	public static final String  FIELD_MEASURE = "measure";
	public static final String  FIELD_UNIT_PRICE = "unitPrice";	
	public static final String  FIELD_STORAGE_NUM = "storageNum";
	public static final String  FIELD_STORAGE_AMOUNT = "storageAmount";
	public static final String  FIELD_STORAGE_TIME= "storageTime";
	public static final String  FIELD_ACCEPT_USER_ID = "acceptUserId";
	public static final String  FIELD_ACCEPT_USER_NAME = "acceptUserName";
	public static final String  FIELD_CREATE_USER = "createUser";
	public static final String  FIELD_CREATE_TIME= "createTime";
	
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params);
	
}
