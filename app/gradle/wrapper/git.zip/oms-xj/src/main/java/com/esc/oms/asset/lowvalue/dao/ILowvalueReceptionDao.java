package com.esc.oms.asset.lowvalue.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

public interface ILowvalueReceptionDao extends IBaseOptionDao{
	
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_NAME = "name";
	public static final String  FIELD_TYPE = "type";
	public static final String  FIELD_RECEPT_USER_NAME = "receptUserName";
	public static final String  FIELD_UNIT_NAME = "unitName";
	public static final String  FIELD_RECEPT_DATE = "receptDate";
	public static final String  FIELD_REMARK = "remark";
	public static final String  FIELD_STATUS = "status";
		
	//待办
	public static final String  TASK_RECEPTION_CONFIRM = "低值易耗品领用确认";
	
	//领用记录状态  0.待提交  1.待确认  2.确认中  3.已确认
	public static final String  STATUS_NOT_SUBMIT = "0";
	public static final String  STATUS_NOT_CONFIRM = "1";
	public static final String  STATUS_CONFIRMING = "2";
	public static final String  STATUS_FINISH_CONFIRM = "3";
	
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params);
	
}
