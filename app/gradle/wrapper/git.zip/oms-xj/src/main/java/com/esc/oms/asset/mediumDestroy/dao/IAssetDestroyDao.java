package com.esc.oms.asset.mediumDestroy.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

public interface IAssetDestroyDao extends IBaseOptionDao{
	
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_NAME = "name";
	public static final String  FIELD_SOURCE = "source";
	public static final String  FIELD_CODE = "code";
	public static final String  FIELD_DEPARTID = "departId";
	public static final String  FIELD_MEDIUMTYPE = "mediumType";
	public static final String  FIELD_CLASSIFICATION = "classification";
	public static final String  FIELD_CLASSIFICATION_CODE = "classificationCode";
	public static final String  FIELD_DESTROY_TIME = "destroyTime";
	public static final String  FIELD_DESTROY_MODE = "destroyMode";
	public static final String  FIELD_DESTROY_REASON = "destroyReason";
	public static final String  FIELD_CREATE_TIME = "createTime";
	public static final String  FIELD_CREATE_USER = "createUser";
	public static final String  FIELD_UPDATE_TIME = "updateTime";
	public static final String  FIELD_UPDATE_USER = "updateUser";
	public static final String  FIELD_STATUS = "status";
	public static final String  FIELD_WORKFLOW_INSTANCEID = "workflowInstanceId";
	public static final String  FIELD_CREATE_USERID = "createUserId";
	public static final String  FIELD_ASSETID = "assetId";
	
	

	public List<UTMap<String, Object>> getAssetsList(Map param);
	

	/**
	 * 获取待审列表
	 * @param pageBean
	 * @param params
	 */
	public void getPendApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) ;

	/**
	 * 获取已审列表
	 * @param pageBean
	 * @param params
	 */
	public void getAlreadyApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) ;
	

	/** 
	 * 根据Id 获取 tittle
	* @Title: getTittle 
	* @Description: TODO 
	* @param id
	* @return String
	* @author smq
	* @date 2018年9月4日上午9:48:27
	*/ 
	public String getName(String id) ;
	
	/** 
	 * 获取最大销毁单号
	*/
	public int getMaxDestroyId();


	public List<UTMap<String, Object>> getAssetsList();
}
