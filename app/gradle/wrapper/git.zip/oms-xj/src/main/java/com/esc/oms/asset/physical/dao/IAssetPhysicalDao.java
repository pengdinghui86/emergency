package com.esc.oms.asset.physical.dao;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

import java.util.List;
import java.util.Map;

public interface IAssetPhysicalDao extends IBaseOptionDao{
	
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_CODE = "codeNum";
	public static final String  FIELD_NAME = "name";
	public static final String  FIELD_CATEGORY = "category";
	public static final String  FIELD_SUBCATEGORY = "subCategory";
	public static final String  FIELD_CATEGORYNAME = "categoryName";
	public static final String  FIELD_SUBCATEGORYNAME = "subCategoryName";
	public static final String  FIELD_BUYCONTRACT = "buyContract";
	public static final String  FIELD_MAINTAINCONTRACT = "maintainContract";
	public static final String  FIELD_RESUSERID = "resUserId";
	public static final String  FIELD_RESUSERNAME = "resUserName";
	public static final String  FIELD_RESDEPARTID = "resDepartId";
	public static final String  FIELD_MAINTASSETSTARTDATE = "maintAssetStartDate";
	public static final String  FIELD_MAINTASSETSENDDATE = "maintAssetsEndDate";
	public static final String  FIELD_ASSETSTARTDATE = "assetStartDate";
	public static final String  FIELD_ASSETENDDATE = "assetEndDate";
	public static final String  FIELD_OTHERMAINT = "otherMaint";
	public static final String  FIELD_SERIALNUM = "serialNum";
	public static final String  FIELD_SUPPLIERID = "supplierId";
	public static final String  FIELD_STATUS = "status";
	public static final String  FIELD_ASSETSTATUS = "assetStatus";
	public static final String  FIELD_LOCATION = "location";
	public static final String  FIELD_PRODUCER = "producer";
	public static final String  FIELD_SALVAGE = "salvage";
	public static final String  FIELD_USEYEARS = "useYears";
	public static final String  FIELD_PURCHASEDATE = "outdate";
	public static final String  FIELD_INBOUNDDATE = "inboundDate";
	public static final String  FIELD_AMOUNT = "amount";
	public static final String  FIELD_BRAND = "brand";
	public static final String  FIELD_MODEL = "model";
	public static final String  FIELD_CONFIDENTIALITY = "confidentiality";
	public static final String  FIELD_INTEGRITY = "integrity";
	public static final String  FIELD_AVAILABILITY = "availability";
	public static final String  FIELD_MAINTSTARTDATE = "maintStartDate";
	public static final String  FIELD_MAINTENDDATE = "maintEndDate";
	public static final String  FIELD_USERID = "userId";
	public static final String  FIELD_CONTROLLABLE = "controllable";
	public static final String  FIELD_REMARK = "remark";
	public static final String  FIELD_HASBACKUP = "hasBackup";
	public static final String  FIELD_AUXILIARYASSET = "auxiliaryAsset";
	public static final String  FIELD_ASSETPRICE = "assetPrice";
	public static final String  FIELD_OWNSYSTEM = "ownSystem";
	public static final String  FIELD_SCRAPDATE = "scrapDate";
	public static final String  FIELD_REGISTSTATUS = "registStatus";
	public static final String  FIELD_PREASSETSCLASS = "preAssetsClass";
	public static final String  FIELD_PREBORROWASSETSSTARTDATE = "preBorrowAssetsStartDate";
	public static final String  FIELD_PREBORROWASSETSENDDATE = "preBorrowAssetsEndDate";
	public static final String  FIELD_PARTA_NAME = "partA_name";
	public static final String  FIELD_PARTA_TELEPHONE = "partA_telephone";
	public static final String  FIELD_PARTB_NAME = "partB_name";
	public static final String  FIELD_PARTB_TELEPHONE = "partB_telephone";
	public static final String  FIELD_ASSETSUSE = "assetsUse";
	public static final String  FIELD_ASSETSCOSTS = "assetsCosts";
	public static final String  FIELD_IP = "ip";
	public static final String  FIELD_EQUIPMENTUSE = "EquipmentUse";
	public static final String  FIELD_ISPOSITIVE ="isPositive";
	public static final String  FIELD_ASSETATTRIBUTES = "assetAttributes";
	public static final String  FIELD_SYSTEMNAME = "systemName";
	public static final String  FIELD_SYSTEMCLASS = "systemClass";
	public static final String  FIELD_MAINTENANCEAMOUNT = "MaintenanceAmount";
	public static final String  FIELD_ASSETSTYPE = "assetsType";
	public static final String  FIELD_CABINETSTARTU = "CabinetStartU";
	public static final String  FIELD_CABINETENDU = "CabinetEndU";
	public static final String  FIELD_BUSINESSSYSTEMLEADER = "businessSystemLeader";
	public static final String  FIELD_EQUIPMENTLEADER = "EquipmentLeader";
	public static final String  FIELD_ISSCRAP = "isScrap";
	public static final String  FIELD_BUSINESS_NAME = "businessName";
	public static final String  FIELD_MAINTENANCE_AMOUNT = "MaintenanceAmount";
	public static final String  FIELD_ASSET_ATTRIBUTES = "assetAttributes";
	public static final String FIELD_ASSETS_LEVEL = "assetsLevel";

	public boolean addRelation(Map info);
	
	/**
	 * 查询备件
	 * */
	public List<UTMap<String, Object>> getSparesById(String id) ;
	
	/**
	 * 根据资产id删除备件联系
	 * @param id
	 * @return
	 */
	
	public boolean updateAssetCodeBySerialNum(UTMap<String, Object> map);
	
	public boolean deleteSparesById(String id);
	
	public List<UTMap<String, Object>> getAssetsList(Map param);
	
	public boolean updateInfoByIds(String location,String resUserId,String resDepartId,String ids);
	
	public List<UTMap<String, Object>> getAssetBycodeAndId(String code,String id);
	
	public UTMap<String, Object> getAssetById(String id);
	
	public UTMap<String, Object> getAssetBySerialNum(String serialNum);
	
	public boolean updateOutdateById(String id);
	
	public boolean updateAssetStatusById(String id, String status);
	
	public boolean updateTotalPriceById(String id,String beforePrice,String nowPrice);
	
	public boolean updateAuxiliaryById(String id);

	public UTMap<String, Object> getAssetInfoByCode(String codeNum);
	
	public UTMap<String, Object> getAssetInfoByAssetCode(String code);

	/**
	 * 根据资产id删除额外属性值
	 * @param id
	 * @return
	 */
	public boolean deleteAttrValueByInfoId(String id);

	public boolean isExitSerialNum(String serialNum, String id);

	/**
	 * 判断是否存在
	 * @param params
	 * @return
	 */
	public boolean isExistParam(Map<String, Object> params);

}
