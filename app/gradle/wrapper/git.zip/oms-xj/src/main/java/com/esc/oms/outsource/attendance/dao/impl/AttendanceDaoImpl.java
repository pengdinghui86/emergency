package com.esc.oms.outsource.attendance.dao.impl;

import com.esc.oms.outsource.attendance.dao.IAttendanceDao;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.RoleUtils;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * 考勤dao
 * @author owner
 *
 */
@Repository
public class AttendanceDaoImpl extends BaseOptionDao implements IAttendanceDao{

	@Override
	public String getTableName() {
		return "attendance";
	}
	
	public List<UTMap<String, Object>> getListMaps(Map param) {
		String sql=getSearchSql(param);
		return super.getListBySql(sql, null);
	}

	public void getPageInfo(UTPageBean pageBean,Map param){
		String sql=getSearchSql(param);
		 super.getPageListMapBySql(sql,pageBean, null);
	}
	
	/**
	 * 退厂申请删除相应的考勤数据
	 * @param userId
	 * @param date
	 */
	public void deleteByPersonExit(String userId, String date){
		String sql= " delete from attendance where userId = ? and date >= ?";
		this.executeUpdate(sql, userId, date);
	}

	@Override
	public List<UTMap<String, Object>>  getAllAttendanceList(Map<String, Object> param) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select at.*,opl.dingDingId, su.code from attendance at,outsource_person_list opl,sys_user su where opl.userId = at.userId and su.id = opl.userId ");
		if(param != null){
			String currentDate = (String) param.get("currentDate");//当前时间
			String dingDingIds = (String) param.get("dingDingIds");//所有的钉钉ID，逗号分隔
			String userIds = (String) param.get("userIds");//所有的用户id，逗号分隔
			String startTime = (String) param.get("startTime");//开始时间, date字段
			String endTime = (String) param.get("endTime");//结束时间，date字段
			if(StringUtils.isNotEmpty(currentDate)){
				sql.append(" and at.date ='"+ currentDate +"'");
			}
			if(StringUtils.isNotEmpty(dingDingIds)){
				sql.append(" and opl.dingDingId in("+dingDingIds+")");
			}
			if(StringUtils.isNotEmpty(startTime)){
				sql.append(" and at.date >= '"+startTime+"'");
			}
			if(StringUtils.isNotEmpty(endTime)){
				sql.append(" and at.date <= '"+endTime+"'");
			}
			if(StringUtils.isNotEmpty(userIds)){
				sql.append(" and opl.userId in("+userIds+")");
			}
		}
		return this.getListBySql(sql.toString());
	}

	@Override
	public boolean deleteByTime(String startTime, String endTime, String userIds ) {
		StringBuilder sql = new StringBuilder();
		sql.append("delete from attendance  where `date` >= '").append(startTime).append("'");
		sql.append(" and `date` <='").append(endTime).append("'");
		sql.append(" and userId in ("+userIds+")");
		return this.executeUpdate(sql.toString());
	}

	@Override
	public Map<String, Object> getAttendance(String presentDate, String dingDingId) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select s.* from attendance s, outsource_person_list opl where s.userId = opl.userId ");
		sql.append(" and s.date = '"+presentDate+"' and opl.dingDingId='"+dingDingId+"'");
		List<UTMap<String, Object>> list = this.getListBySql(sql.toString());
		if(list.size() > 0){
			return list.get(0);
		}
		return null;
	}

	/**
	 * 获取个人考勤工时统计数据
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllAttHours(Map param){
		return this.getListBySql(getAttHoursSql(param), null);
	}
	
	/**
	 * 获取个人考勤工时统计数据
	 * @param pageBean
	 * @param param
	 */
	public void getAttHours(UTPageBean pageBean,Map param){
		 super.getPageListMapBySql(getAttHoursSql(param),pageBean, null);
	}
	
	/**
	 * 考勤天数：考勤的天数，签到了就算一天，不包括周末及节假日
	 * 考勤工时：按照考勤规则统计，若签到签退异常则按照异常的签到签退时间统计，例如考勤规则配置为8:00-12:00 14:00-18:00，
	 * 若签到时间为9:00，签退时间为18:00以后，则考勤工时为7小时；若签到时间为9:00，签退时间为16:00，则为5小时
	 * @param param
	 * @return
	 */
	private String getAttHoursSql(Map param){
		Map<String, String> p=UTMap.mapObjToString(param);
		StringBuilder sql = new StringBuilder();
		String beginDate = "" ;//查询开始日期
		String dateSql = "" ;//日期查询标题sql
		if(p.get("beginDate") == null){
			beginDate = "";
			dateSql = "";
		}else{
			 beginDate = p.get("beginDate") ;//查询开始日期
			 dateSql = ",'"+ beginDate + "' as beginDate";
		}
		String endDate = "" ;//查询结束日期
//		String endDateSql  ;
		if(p.get("endDate") == null){
			endDate = "";
		}else{
			endDate = p.get("endDate") ;//查询开始日期
			dateSql += ",'"+ endDate + "' as endDate";
		}
		String id=p.get("id"); 
		String supplierName = p.get("supplierName");//供应商
		String userName = p.get("userName");//用户名
		String orgName = p.get("orgName");//组织机构
		String attendanceDateType = p.get("attendanceDateType");//考勤方式:(1.确定时间，2.不确定时间统计考勤次数,3.不确定时间统计考勤时间)
		
		sql.append(" select tb.*, ifnull(wotb1.overtimeHours,0) as overtimeHours,ifnull(wotb2.overtimeHourApplys,0) as overtimeHourApplys,ifnull(wvdtb1.vacationHours,0) as vacationHours,ifnull(wvdtb2.vacationHourApplys,0) as vacationHourApplys ,ifnull(wvdtb3.vacationHours,0) as leaveInLieuHours,ifnull(wvdtb4.vacationHourApplys,0) as leaveInLieuHoursApplys from ( ");
		sql.append(" select att.userId,count(att.userId) as attDays,sum(if(att.dateinStyle!=0 or att.dateoutStyle!=0,1,0)) as attExDays,SUM(att.attHours) as attHours ,sbi.name as supplierName, CONCAT(su.name,'/',su.code) as userName ,so1.longName orgName "+dateSql+" from attendance att ");
		sql.append(" left join supplier_base_info sbi on att.supplierId = sbi.id ");
		sql.append(" left join sys_user su on att.userId = su.id ");
		sql.append(" left join sys_org so1 on att.departId = so1.id ");
		sql.append(" where att.attType = 0 ");// 固定考勤的数据,非周末加班时手动生成的数据
		sql.append(CommonUtils.getDateSql(beginDate, endDate, "att.date")); // 考勤时间范围
		sql.append(" and att.attendanceDateType = "+attendanceDateType+" ");//考勤方式:(1.确定时间，2.不确定时间统计考勤次数,3.不确定时间统计考勤时间)
		if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR,RoleUtils.SUPPLIER_ADMINISTRATOR)){
			if(EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SUPPLIER_LEADERS)){//供应商负责人查看本供应商下用户的考勤配置
				sql.append(" and att.supplierId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId()+"' ");
			}else{
				sql.append(" and att.userId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' ");//外包用户只能查询自己的数据
			}
		}
		if (StringUtils.isNotEmpty(id)) {
			sql.append(" and att.id='"+id+"'");
		}
		if (StringUtils.isNotEmpty(supplierName)) {
			sql.append(" and sbi.name like '%"+supplierName+"%'");
		}
		if (StringUtils.isNotEmpty(userName)) {
//			sql.append(" and (su.name like '%"+userName+"%' or su.code like '%"+userName+"%' )");
			sql.append(" and CONCAT(su.name,'/',su.code) like '%"+userName+"%' ");
		}
		if (StringUtils.isNotEmpty(orgName)) {
			sql.append(" and so1.longName like '%"+orgName+"%'");
		}
		sql.append(" group by att.userId ");
//		sql.append(" ORDER BY sbi.id asc,count(att.userId) desc ");
		sql.append(" ) tb ");
		sql.append(" left join ( ");
		//加班工时
		sql.append(" select wo1.createUserId,sum(wo1.hours) as overtimeHours from workhour_overtime wo1 where wo1.status = 5 "+CommonUtils.getDateSql(beginDate, endDate, "wo1.presentDate")+"  group by wo1.createUserId ");
		sql.append(" ) wotb1 on tb.userId = wotb1.createUserId ");
		sql.append(" left join ( ");
		//申请的加班工时
		sql.append(" select wo2.createUserId,sum(wo2.hours) as overtimeHourApplys from workhour_overtime wo2 where wo2.status != 1 and wo2.status != 6  "+CommonUtils.getDateSql(beginDate, endDate, "wo2.presentDate")+" group by wo2.createUserId ");
		sql.append(" ) wotb2 on tb.userId = wotb2.createUserId ");
		sql.append(" left join ( ");
		//请假工时
		sql.append(" select wvd1.createUserId,sum(wvd1.hours) as vacationHours from workhour_vacation wv1, workhour_vacation_detail wvd1 where wv1.type='3' and wv1.id = wvd1.infoId and wv1.status = 5  "+CommonUtils.getDateSql(beginDate, endDate, "wvd1.presentDate")+" group by wvd1.createUserId ");
		sql.append(" ) wvdtb1 on tb.userId = wvdtb1.createUserId ");
		sql.append(" left join ( ");
		//申请的请假工时
		sql.append(" select wvd2.createUserId,sum(wvd2.hours) as vacationHourApplys from workhour_vacation wv2, workhour_vacation_detail wvd2 where wv2.type='3' and wv2.id = wvd2.infoId and wv2.status != 1 and wv2.status != 6 "+CommonUtils.getDateSql(beginDate, endDate, "wvd2.presentDate")+" group by wvd2.createUserId ");
		sql.append(" ) wvdtb2 on tb.userId = wvdtb2.createUserId ");
		sql.append(" left join ( ");
		//调休工时
        sql.append(" select wvd3.createUserId,sum(wvd3.hours) as vacationHours from workhour_vacation wv3, workhour_vacation_detail wvd3 where wv3.type='8' and wv3.id = wvd3.infoId and wv3.status = 5  "+CommonUtils.getDateSql(beginDate, endDate, "wvd3.presentDate")+" group by wvd3.createUserId ");
        sql.append(" ) wvdtb3 on tb.userId = wvdtb3.createUserId ");
        sql.append(" left join ( ");
        //申请的调休工时
        sql.append(" select wvd4.createUserId,sum(wvd4.hours) as vacationHourApplys from workhour_vacation wv4, workhour_vacation_detail wvd4 where wv4.type='8' and wv4.id = wvd4.infoId and wv4.status != 1 and wv4.status != 6 "+CommonUtils.getDateSql(beginDate, endDate, "wvd4.presentDate")+" group by wvd4.createUserId ");
        sql.append(" ) wvdtb4 on tb.userId = wvdtb4.createUserId ");
        sql.append(" left join ( ");
		//出差工时
		sql.append(" select wtd1.createUserId,sum(wtd1.hours) as travelHours from workhour_travel_detail wtd1 where wtd1.status = 5 "+CommonUtils.getDateSql(beginDate, endDate, "wtd1.presentDate")+" group by wtd1.createUserId ");
		sql.append(" ) wtdtb1 on tb.userId = wtdtb1.createUserId ");
		sql.append(" left join ( ");
		//申请的出差工时
		sql.append(" select wtd2.createUserId,sum(wtd2.hours) as travelHourApplys from workhour_travel_detail wtd2 where wtd2.status != 1 and wtd2.status != 6 "+CommonUtils.getDateSql(beginDate, endDate, "wtd2.presentDate")+" group by wtd2.createUserId ");
		sql.append(" ) wtdtb2 on tb.userId = wtdtb2.createUserId ");
		sql.append(" ORDER BY tb.supplierName,tb.attDays desc,tb.userId ");
		return sql.toString();
	}
	
	/**
	 * 获取联合考勤工时统计数据
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllCoalitionAttHours(Map param){
		return this.getListBySql(getCoalitionAttHoursSql(param), null);
	}
	
	/**
	 * 获取联合考勤工时统计数据
	 * @param pageBean
	 * @param param
	 */
	public void getCoalitionAttHours(UTPageBean pageBean,Map param){
		 super.getPageListMapBySql(getCoalitionAttHoursSql(param),pageBean, null);
	}
	
	/**
	 * 联合考勤工时统计sql
	 * @param param
	 * @return
	 */
	private String getCoalitionAttHoursSql(Map param){
		Map<String, String> p=UTMap.mapObjToString(param);
		StringBuilder sql = new StringBuilder();
		String beginDate = "" ;//查询开始日期
		String dateSql = "" ;//日期查询标题sql
		if(p.get("beginDate") == null){
			beginDate = "";
			dateSql = "";
		}else{
			 beginDate = p.get("beginDate") ;//查询开始日期
			 dateSql = ",'"+ beginDate + "' as beginDate";
		}
		String endDate = "" ;//查询结束日期
//		String endDateSql  ;
		if(p.get("endDate") == null){
			endDate = "";
		}else{
			endDate = p.get("endDate") ;//查询开始日期
			dateSql += ",'"+ endDate + "' as endDate";
		}
		String id=p.get("id"); 
		String supplierName = p.get("supplierName");//供应商
		String coalitionName = p.get("coalitionName");//联合考勤名称
		String orgName = p.get("orgName");//组织机构
		String attendanceDateType = p.get("attendanceDateType");//考勤方式:(1.确定时间，2.不确定时间统计考勤次数,3.不确定时间统计考勤时间)
		
		
		sql.append(" SELECT tb.*, ifnull(wotb1.overtimeHours, 0) AS overtimeHours, ");
		sql.append(" ifnull(wotb2.overtimeHourApplys, 0) AS overtimeHourApplys, ");
		sql.append(" ifnull(wvdtb1.vacationHours, 0) AS vacationHours, ");
		sql.append(" ifnull(wvdtb2.vacationHourApplys,0) AS vacationHourApplys, ");
		sql.append(" ifnull(wtdtb1.travelHours, 0) AS travelHours, ");
		sql.append(" ifnull(wtdtb2.travelHourApplys, 0) AS travelHourApplys ");
		sql.append(" FROM ");
		sql.append(" ( ");
		
		sql.append(" select ctb.coalitionId,ctb.date,ctb.supplierName,ctb.coalitionName,ctb.orgName,ctb.beginDate,ctb.endDate,count(ctb.coalitionId) AS attDays,sum(ctb.attExDays) as attExDays,sum(ctb.attHours) as attHours  from ( ");
		sql.append(" SELECT att.coalitionId,att.date,  ");
		sql.append(" IF ( att.dateinStyle != 0 OR att.dateoutStyle != 0, 1, 0 ) AS attExDays, ");
		sql.append(" att.attHours, ");
		sql.append(" sbi. NAME AS supplierName, ");
		sql.append(" auc.name as coalitionName, ");
		sql.append(" so1.longName as orgName"+dateSql+" ");
		sql.append(" FROM attendance att ");
		sql.append(" LEFT JOIN supplier_base_info sbi ON att.supplierId = sbi.id ");
		sql.append(" LEFT JOIN sys_org so1 ON att.departId = so1.id ");
		sql.append(" LEFT JOIN attendance_coalition_config auc ON att.coalitionId = auc.id ");
		sql.append(" WHERE att.attType = 0 and att.coalitionId is not null ");
		sql.append(CommonUtils.getDateSql(beginDate, endDate, "att.date")); // 考勤时间范围
		sql.append(" and att.attendanceDateType = "+attendanceDateType+" ");//考勤方式:(1.确定时间，2.不确定时间统计考勤次数,3.不确定时间统计考勤时间)
		sql.append(" and auc.id is not null ");
		
		if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR,RoleUtils.SUPPLIER_ADMINISTRATOR)){
			if(EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SUPPLIER_LEADERS)){//供应商负责人查看本供应商下用户的考勤配置
				sql.append(" and att.supplierId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId()+"' ");
			}else{
				sql.append(" and att.userId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' ");//外包用户只能查询自己的数据
			}
		}
		if (StringUtils.isNotEmpty(id)) {
			sql.append(" and att.id='"+id+"' ");
		}
		if (StringUtils.isNotEmpty(supplierName)) {
			sql.append(" and sbi.name like '%"+supplierName+"%' ");
		}
		if (StringUtils.isNotEmpty(coalitionName)) {
			sql.append(" and auc.name like '%"+coalitionName+"%' ");
		}
		if (StringUtils.isNotEmpty(orgName)) {
			sql.append(" and su.orgName like '%"+orgName+"%' ");
		}
		
		sql.append(" GROUP BY att.date,att.coalitionId ");
		sql.append(" ) ctb GROUP BY ctb.coalitionId ");
		
		
		sql.append(" ) tb ");
		sql.append(" LEFT JOIN ( ");
		//加班工时
		sql.append(" SELECT wo1.coalitionId, sum(wo1.hours) AS overtimeHours ");
		sql.append(" FROM workhour_overtime wo1 ");
		sql.append(" WHERE wo1.STATUS = 5 ");
		sql.append(CommonUtils.getDateSql(beginDate, endDate, "wo1.presentDate"));
		sql.append(" GROUP BY wo1.coalitionId ");
		sql.append(" ) wotb1 ON tb.coalitionId = wotb1.coalitionId ");
		sql.append(" LEFT JOIN ( ");
		//申请的加班工时
		sql.append(" SELECT wo2.coalitionId, sum(wo2.hours) AS overtimeHourApplys ");
		sql.append(" FROM workhour_overtime wo2 ");
		sql.append(" WHERE wo2. STATUS != 1 ");
		sql.append(" AND wo2. STATUS != 6 ");
		sql.append(CommonUtils.getDateSql(beginDate, endDate, "wo2.presentDate"));
		sql.append(" GROUP BY wo2.coalitionId ");
		sql.append(" ) wotb2 ON tb.coalitionId = wotb2.coalitionId ");
		sql.append(" LEFT JOIN ( ");
		//请假工时
		sql.append(" SELECT wvd1.coalitionId, sum(wvd1.hours) AS vacationHours ");
		sql.append(" FROM workhour_vacation_detail wvd1 ");
		sql.append(" WHERE wvd1. STATUS = 5 ");
		sql.append(CommonUtils.getDateSql(beginDate, endDate, "wvd1.presentDate"));
		sql.append(" GROUP BY wvd1.coalitionId ");
		sql.append(" ) wvdtb1 ON tb.coalitionId = wvdtb1.coalitionId ");
		sql.append(" LEFT JOIN ( ");
		//申请的请假工时
		sql.append(" SELECT wvd2.coalitionId, sum(wvd2.hours) AS vacationHourApplys ");
		sql.append(" FROM workhour_vacation_detail wvd2 ");
		sql.append(" WHERE wvd2. STATUS != 1 ");
		sql.append(" AND wvd2. STATUS != 6 ");
		sql.append(CommonUtils.getDateSql(beginDate, endDate, "wvd2.presentDate"));
		sql.append(" GROUP BY wvd2.coalitionId ");
		sql.append(" ) wvdtb2 ON tb.coalitionId = wvdtb2.coalitionId ");
		sql.append(" LEFT JOIN ( ");
		//出差工时
		sql.append(" SELECT wtd1.coalitionId, sum(wtd1.hours) AS travelHours ");
		sql.append(" FROM workhour_travel_detail wtd1 ");
		sql.append(" WHERE wtd1. STATUS = 5 ");
		sql.append(CommonUtils.getDateSql(beginDate, endDate, "wtd1.presentDate"));
		sql.append(" GROUP BY wtd1.coalitionId ");
		sql.append(" ) wtdtb1 ON tb.coalitionId = wtdtb1.coalitionId ");
		sql.append(" LEFT JOIN ( ");
		//申请的出差工时
		sql.append(" SELECT wtd2.coalitionId, sum(wtd2.hours) AS travelHourApplys ");
		sql.append(" FROM workhour_travel_detail wtd2 ");
		sql.append(" WHERE wtd2. STATUS != 1 ");
		sql.append(" AND wtd2. STATUS != 6 ");
		sql.append(CommonUtils.getDateSql(beginDate, endDate, "wtd2.presentDate"));
		sql.append(" GROUP BY wtd2.coalitionId ");
		sql.append(" ) wtdtb2 ON tb.coalitionId = wtdtb2.coalitionId ");
		sql.append(" ORDER BY tb.supplierName, tb.attDays DESC,tb.coalitionId ");
		
		return sql.toString();
	}
	
	/**
	 * 常规考勤统计（部门）
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllOrgConventional(Map param){
		return this.getListBySql(getOrgConventionalSql(param), null);
	}
	
	/**
	 * 常规考勤统计（部门）
	 * @param pageBean
	 * @param param
	 */
	public void getOrgConventional(UTPageBean pageBean,Map param){
		 super.getPageListMapBySql(getOrgConventionalSql(param),pageBean, null);
	}
	
	/**
	 * 常规考勤统计（部门）维度sql
	 * @param param
	 * @return
	 */
	private String getOrgConventionalSql(Map param){
		Map<String, String> p=UTMap.mapObjToString(param);
		StringBuilder sql = new StringBuilder();
		String beginDate = "" ;//查询开始日期
		if(p.get("beginDate") != null){
			 beginDate = p.get("beginDate") ;//查询开始日期
		}
		String endDate = "" ;//查询结束日期
		if(p.get("endDate") != null){
			endDate = p.get("endDate") ;//查询结束日期
		}
		String  orgName = p.get("orgName");//组织机构
		
		sql.append(" select tb.*, (coalitionSum + notCoalitionSum) attSum, (coalitionExceptionSum + notCoalitionExceptionSum) attException, ((coalitionSum + notCoalitionSum) - (coalitionExceptionSum + notCoalitionExceptionSum)) as attNormal, ROUND(((coalitionExceptionSum + notCoalitionExceptionSum)/(coalitionSum + notCoalitionSum)*100)) percentageInt,  CONCAT(ROUND(((coalitionExceptionSum + notCoalitionExceptionSum)/(coalitionSum + notCoalitionSum)*100)),'%') as percentage from ( ");
		sql.append(" SELECT s.longName orgName,s.name shortOrgName, s.id orgId,");
		if (StringUtils.isNotEmpty(beginDate)) {
			sql.append(" '"+beginDate+"' beginDate, ");
		}
		if (StringUtils.isNotEmpty(endDate)) {
			sql.append(" '"+endDate+"' endDate, ");
		}
		sql.append(" (SELECT count(1) FROM( ");
//		sql.append(" SELECT IFNULL(c.coalitionId, su.id) userIdOrCoalitionId,su.orgId FROM sys_user su ");
//		sql.append(" LEFT JOIN attendance_user_config c ON c.userId = su.id ");
//		sql.append(" where  c.id is not null ");// -- 只统计有考勤规则的用户
//		if (StringUtils.isNotEmpty(endDate)) {
//			sql.append(" and su.createTime < '"+endDate+"' ");// -- 某段时间内入场的用户，比如张三是08.01号入场的，我在08.02日查询7月份的数据，这个时候人数不需要把张三也统计进来
//		}
//		sql.append(" and c.attendanceDateType = 1  ");//-- 确定时间考勤
//		//考勤人数还需要根据考勤规则的时间范围来进行判断
//		// 时间查询范围开始时间和结束时间都不为空
//		if (StringUtils.isNotEmpty(beginDate) && StringUtils.isNotEmpty(endDate)) {
//			sql.append(" and ( ");
//			sql.append(" (c.endDate is null and c.beginDate <= '"+endDate+"' ) OR ");
//			sql.append(" (c.endDate is not null and c.endDate >= '"+beginDate+"' and c.beginDate <= '"+endDate+"'  ) ");
//			sql.append(" ) ");
//		}else if (StringUtils.isNotEmpty(beginDate)) {//时间查询范围开始时间不为空，结束时间为空
//			sql.append(" and c.beginDate <= '"+beginDate+"' ");
//		}else if (StringUtils.isNotEmpty(endDate)){//时间查询范围开始时间为空，结束时间不为空
//			sql.append(" and c.beginDate <= '"+endDate+"'  ");
//		}
//		sql.append(" GROUP BY userIdOrCoalitionId ");
		
		sql.append(" SELECT IFNULL(att.coalitionId, att.userId) userIdOrCoalitionId,att.departId as orgId FROM attendance att ");
		sql.append(" where att.attendanceDateType = 1   ");//-- 确定时间考勤
		sql.append(" "+CommonUtils.getDateSql(beginDate, endDate, "att.date")+" ");
		sql.append(" and att.attType = 0  ");//-- 不统计周末手动考勤生成的数据
		sql.append(" GROUP BY userIdOrCoalitionId ");
		
		sql.append(" ) memberCount ");
		sql.append(" 	WHERE memberCount.orgId = s.id ");
		sql.append(" ) memberNum, ");// -- 考勤人数
		sql.append(" ifnull(( ");
		sql.append(" select count(1) from( ");
		sql.append(" 	select att.date,att.departId from attendance att ");
		sql.append(" where 1=1  ");
		sql.append(" "+CommonUtils.getDateSql(beginDate, endDate, "att.date")+" ");
		sql.append(" and att.coalitionId is not null ");
		sql.append(" 	and att.attendanceDateType = 1 ");// -- 确定时间考勤
		sql.append(" 	and att.attType = 0 ");// -- 不统计周末手动考勤生成的数据
		sql.append(" group by att.date,att.coalitionId ");
		sql.append(" ) tb1 ");
		sql.append(" where tb1.departId = s.id ");
		sql.append(" ),0) coalitionSum, ");// -- 联合考勤总天数
		sql.append(" ifnull(( ");
		sql.append(" select count(1) from attendance att ");
		sql.append(" where att.departId = s.id ");
		sql.append(" "+CommonUtils.getDateSql(beginDate, endDate, "att.date")+" ");
		sql.append(" 	and att.coalitionId is null ");
		sql.append(" and att.attendanceDateType = 1  ");//-- 确定时间考勤
		sql.append(" and att.attType = 0  ");//-- 不统计周末手动考勤生成的数据
		sql.append(" ),0) notCoalitionSum,  ");//-- 非联合考勤总天数
		sql.append(" ifnull(( ");
		sql.append(" 	select count(1) from( ");
		sql.append(" select att.date,att.departId from attendance att ");
		sql.append(" where 1=1  ");
		sql.append(" "+CommonUtils.getDateSql(beginDate, endDate, "att.date")+" ");
		sql.append(" and att.coalitionId is not null ");
		sql.append(" and att.attendanceDateType = 1  ");//-- 确定时间考勤
		sql.append(" and att.attType = 0 ");// -- 不统计周末手动考勤生成的数据
		sql.append(" and (att.dateinStyle != 0 or att.dateoutStyle != 0) ");
		sql.append(" group by att.date,att.coalitionId ");
		sql.append(" ) tb1 ");
		sql.append(" 	where tb1.departId = s.id ");
		sql.append(" ),0) coalitionExceptionSum, ");// -- 联合考勤异常总天数
		sql.append(" ifnull(( ");
		sql.append(" 	select count(1) from attendance att ");
		sql.append(" 	where att.departId = s.id ");
		sql.append(" "+CommonUtils.getDateSql(beginDate, endDate, "att.date")+" ");
		sql.append(" and att.coalitionId is null ");
		sql.append(" 	and att.attendanceDateType = 1 ");// -- 确定时间考勤
		sql.append(" 	and att.attType = 0 ");// -- 不统计周末手动考勤生成的数据
		sql.append(" 	and (att.dateinStyle != 0 or att.dateoutStyle != 0) ");
		sql.append(" 	),0) notCoalitionExceptionSum ");// -- 非联合考勤异常总天数
		sql.append(" FROM sys_org s ");
		sql.append(" WHERE s.state = 1 ");
		sql.append(" ) tb ");
		sql.append(" where tb.memberNum > 0 ");
		
		
		if (StringUtils.isNotEmpty(orgName)) {
			sql.append(" and tb.orgName like '%"+orgName+"%' ");
		}
		sql.append(" ORDER BY percentage*1 desc,tb.orgId ");
		
		
		return sql.toString();
	}
	
	/**
	 * 常规考勤统计（部门）维度sql
	 * @param param
	 * @return
	 */
//	private String getOrgConventionalSql(Map param){
//		Map<String, String> p=UTMap.mapObjToString(param);
//		StringBuilder sql = new StringBuilder();
//		String beginDate = "" ;//查询开始日期
//		if(p.get("beginDate") != null){
//			 beginDate = p.get("beginDate") ;//查询开始日期
//		}
//		String endDate = "" ;//查询结束日期
//		if(p.get("endDate") != null){
//			endDate = p.get("endDate") ;//查询开始日期
//		}
//		String id=p.get("id"); 
////		String supplierName = p.get("supplierName");//供应商
//		String orgName = p.get("orgName");//组织机构
//		
//		sql.append(" select tb.*, (tb.attSum - tb.attException) as attNormal,  CONCAT(ROUND((tb.attException/tb.attSum*100)),'%') as percentage from ( ");
//		sql.append(" SELECT s.NAME orgName, s.id orgId, '"+beginDate+"' beginDate, '"+endDate+"' endDate, ");
//		sql.append(" (SELECT count(1) FROM( ");
//		sql.append(" SELECT IFNULL(c.coalitionId, su.id) userIdOrCoalitionId,su.supplierId FROM sys_user su ");
//		sql.append(" LEFT JOIN attendance_user_config c ON c.userId = su.id ");
//		sql.append(" where  c.id is not null ");// -- 只统计有考勤规则的用户
//		if (StringUtils.isNotEmpty(endDate)) {// -- 某段时间内入场的用户，比如张三是08.01号入场的，我在08.02日查询7月份的数据，这个时候人数不需要把张三也统计进来
//			sql.append("  and su.createTime < '"+endDate+"' ");
//		}
//		sql.append(" and c.attendanceDateType = 1 ");// -- 确定时间考勤
//		sql.append(" GROUP BY userIdOrCoalitionId ");
//		sql.append(" ) memberCount ");
//		sql.append(" WHERE memberCount.orgId = s.id ");
//		sql.append(" ) memberNum, ");
//		sql.append(" ifnull(( ");
//		sql.append(" select count(1)  from attendance att  ");
//		sql.append(" where att.departId = s.id  ");
//		sql.append(" and att.attendanceDateType = 1 ");// -- 确定时间考勤
//		sql.append(" and att.attType = 0  ");//-- 不统计周末手动考勤生成的数据
//		sql.append(" "+CommonUtils.getDateSql(beginDate, endDate, "att.date")+" ");
//		sql.append(" group by att.departId ");
//		sql.append(" ),0) attSum, ");
//		sql.append(" ifnull(( ");
//		sql.append(" select count(1)  from attendance att  ");
//		sql.append(" where att.departId = s.id  ");
//		sql.append(" and att.attendanceDateType = 1  ");//-- 确定时间考勤 
//		sql.append(" and att.attType = 0  ");//-- 不统计周末手动考勤生成的数据 
//		sql.append(" and (att.dateinStyle != 0 or att.dateoutStyle != 0) ");
//		sql.append(" "+CommonUtils.getDateSql(beginDate, endDate, "att.date")+" ");
//		sql.append(" group by att.departId ");
//		sql.append(" ),0) attException ");
//		sql.append(" FROM sys_org s ");
//		sql.append(" WHERE s.state = 1 ");
//		sql.append(" ) tb ");
//		sql.append(" where tb.memberNum > 0 ");
//		
//		if (StringUtils.isNotEmpty(orgName)) {
//			sql.append(" and tb.orgName like '%"+orgName+"%' ");
//		}
//		sql.append(" ORDER BY percentage ");
//		
//		
//		return sql.toString();
//	}
	
	/**
	 * 常规考勤统计（供应商）
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllSupplierConventional(Map param){
		return this.getListBySql(getSupplierConventionalSql(param), null);
	}
	
	/**
	 * 常规考勤统计（供应商）
	 * @param pageBean
	 * @param param
	 */
	public void getSupplierConventional(UTPageBean pageBean,Map param){
		 super.getPageListMapBySql(getSupplierConventionalSql(param),pageBean, null);
	}
	
	/**
	 * 常规考勤统计（供应商）维度sql
	 * @param param
	 * @return
	 */
	private String getSupplierConventionalSql(Map param){
		Map<String, String> p=UTMap.mapObjToString(param);
		StringBuilder sql = new StringBuilder();
		String beginDate = "" ;//查询开始日期
		if(p.get("beginDate") != null){
			 beginDate = p.get("beginDate") ;//查询开始日期
		}
		String endDate = "" ;//查询结束日期
		if(p.get("endDate") != null){
			endDate = p.get("endDate") ;//查询结束日期
		}
		String supplierName = p.get("supplierName");//供应商
		
		sql.append(" select tb.*, (coalitionSum + notCoalitionSum) attSum, (coalitionExceptionSum + notCoalitionExceptionSum) attException, ((coalitionSum + notCoalitionSum) - (coalitionExceptionSum + notCoalitionExceptionSum)) as attNormal,  ROUND(((coalitionExceptionSum + notCoalitionExceptionSum)/(coalitionSum + notCoalitionSum)*100)) as percentageInt,CONCAT(ROUND(((coalitionExceptionSum + notCoalitionExceptionSum)/(coalitionSum + notCoalitionSum)*100)),'%') as percentage from ( ");
		sql.append(" SELECT s. NAME supplierName,s.shortName shortSupplierName, s.id supplierId,");
		if (StringUtils.isNotEmpty(beginDate)) {
			sql.append(" '"+beginDate+"' beginDate, ");
		}
		if (StringUtils.isNotEmpty(endDate)) {
			sql.append(" '"+endDate+"' endDate, ");
		}
		
		sql.append(" (SELECT count(1) FROM( ");
//		sql.append(" SELECT IFNULL(c.coalitionId, su.id) userIdOrCoalitionId,su.supplierId FROM sys_user su ");
//		sql.append(" LEFT JOIN attendance_user_config c ON c.userId = su.id ");
//		sql.append(" where  c.id is not null ");// -- 只统计有考勤规则的用户
//		if (StringUtils.isNotEmpty(endDate)) {
//			sql.append(" and su.createTime < '"+endDate+"' ");// -- 某段时间内入场的用户，比如张三是08.01号入场的，我在08.02日查询7月份的数据，这个时候人数不需要把张三也统计进来
//		}
//		sql.append(" and c.attendanceDateType = 1  ");//-- 确定时间考勤
//		//考勤人数还需要根据考勤规则的时间范围来进行判断
//		// 时间查询范围开始时间和结束时间都不为空
//		if (StringUtils.isNotEmpty(beginDate) && StringUtils.isNotEmpty(endDate)) {
//			sql.append(" and ( ");
//			sql.append(" (c.endDate is null and c.beginDate <= '"+endDate+"' ) OR ");
//			sql.append(" (c.endDate is not null and c.endDate >= '"+beginDate+"' and c.beginDate <= '"+endDate+"'  ) ");
//			sql.append(" ) ");
//		}else if (StringUtils.isNotEmpty(beginDate)) {//时间查询范围开始时间不为空，结束时间为空
//			sql.append(" and c.beginDate <= '"+beginDate+"' ");
//		}else if (StringUtils.isNotEmpty(endDate)){//时间查询范围开始时间为空，结束时间不为空
//			sql.append(" and c.beginDate <= '"+endDate+"'  ");
//		}
//		
//		sql.append(" GROUP BY userIdOrCoalitionId ");
		
		sql.append(" SELECT IFNULL(att.coalitionId, att.userId) userIdOrCoalitionId,att.supplierId FROM attendance att ");
		sql.append(" where att.attendanceDateType = 1   ");//-- 确定时间考勤
		sql.append(" "+CommonUtils.getDateSql(beginDate, endDate, "att.date")+" ");
		sql.append(" and att.attType = 0  ");//-- 不统计周末手动考勤生成的数据
		sql.append(" GROUP BY userIdOrCoalitionId ");
		
		
		
		sql.append(" ) memberCount ");
		sql.append(" 	WHERE memberCount.supplierId = s.id ");
		sql.append(" ) memberNum, ");// -- 考勤人数
		sql.append(" ifnull(( ");
		sql.append(" select count(1) from( ");
		sql.append(" 	select att.date,att.supplierId from attendance att ");
		sql.append(" where 1=1  ");
		sql.append(" "+CommonUtils.getDateSql(beginDate, endDate, "att.date")+" ");
		sql.append(" and att.coalitionId is not null ");
		sql.append(" 	and att.attendanceDateType = 1 ");// -- 确定时间考勤
		sql.append(" 	and att.attType = 0 ");// -- 不统计周末手动考勤生成的数据
		sql.append(" group by att.date,att.coalitionId ");
		sql.append(" ) tb1 ");
		sql.append(" where tb1.supplierId = s.id ");
		sql.append(" ),0) coalitionSum, ");// -- 联合考勤总天数
		sql.append(" ifnull(( ");
		sql.append(" select count(1) from attendance att ");
		sql.append(" where att.supplierId = s.id ");
		sql.append(" "+CommonUtils.getDateSql(beginDate, endDate, "att.date")+" ");
		sql.append(" 	and att.coalitionId is null ");
		sql.append(" and att.attendanceDateType = 1  ");//-- 确定时间考勤
		sql.append(" and att.attType = 0  ");//-- 不统计周末手动考勤生成的数据
		sql.append(" ),0) notCoalitionSum,  ");//-- 非联合考勤总天数
		sql.append(" ifnull(( ");
		sql.append(" 	select count(1) from( ");
		sql.append(" select att.date,att.supplierId from attendance att ");
		sql.append(" where 1=1  ");
		sql.append(" "+CommonUtils.getDateSql(beginDate, endDate, "att.date")+" ");
		sql.append(" and att.coalitionId is not null ");
		sql.append(" and att.attendanceDateType = 1  ");//-- 确定时间考勤
		sql.append(" and att.attType = 0 ");// -- 不统计周末手动考勤生成的数据
		sql.append(" and (att.dateinStyle != 0 or att.dateoutStyle != 0) ");
		sql.append(" group by att.date,att.coalitionId ");
		sql.append(" ) tb1 ");
		sql.append(" 	where tb1.supplierId = s.id ");
		sql.append(" ),0) coalitionExceptionSum, ");// -- 联合考勤异常总天数
		sql.append(" ifnull(( ");
		sql.append(" 	select count(1) from attendance att ");
		sql.append(" 	where att.supplierId = s.id ");
		sql.append(" "+CommonUtils.getDateSql(beginDate, endDate, "att.date")+" ");
		sql.append(" and att.coalitionId is null ");
		sql.append(" 	and att.attendanceDateType = 1 ");// -- 确定时间考勤
		sql.append(" 	and att.attType = 0 ");// -- 不统计周末手动考勤生成的数据
		sql.append(" 	and (att.dateinStyle != 0 or att.dateoutStyle != 0) ");
		sql.append(" 	),0) notCoalitionExceptionSum ");// -- 非联合考勤异常总天数
		sql.append(" FROM supplier_base_info s ");
		sql.append(" WHERE IFNULL(s.deleteFlag, '0') = '0' ");
		sql.append(" ) tb ");
		sql.append(" where tb.memberNum > 0 ");
		
		
		if (StringUtils.isNotEmpty(supplierName)) {
			sql.append(" and tb.supplierName like '%"+supplierName+"%' ");
		}
		sql.append(" ORDER BY percentage*1 desc ");
		
		
		return sql.toString();
	}
	
	/**
	 * 常规考勤统计（供应商）维度sql
	 * @param param
	 * @return
	 */
//	private String getSupplierConventionalSql(Map param){
//		Map<String, String> p=UTMap.mapObjToString(param);
//		StringBuilder sql = new StringBuilder();
//		String beginDate = "" ;//查询开始日期
//		if(p.get("beginDate") != null){
//			 beginDate = p.get("beginDate") ;//查询开始日期
//		}
//		String endDate = "" ;//查询结束日期
//		if(p.get("endDate") != null){
//			endDate = p.get("endDate") ;//查询开始日期
//		}
//		String id=p.get("id"); 
//		String supplierName = p.get("supplierName");//供应商
//		String orgName = p.get("orgName");//组织机构
//		
//		sql.append(" select tb.*, (tb.attSum - tb.attException) as attNormal,  CONCAT(ROUND((tb.attException/tb.attSum*100)),'%') as percentage from ( ");
//		sql.append(" SELECT s.NAME supplierName, s.id supplierId, '"+beginDate+"' beginDate, '"+endDate+"' endDate, ");
//		sql.append(" (SELECT count(1) FROM( ");
//		sql.append(" SELECT IFNULL(c.coalitionId, su.id) userIdOrCoalitionId,su.supplierId FROM sys_user su ");
//		sql.append(" LEFT JOIN attendance_user_config c ON c.userId = su.id ");
//		sql.append(" where  c.id is not null ");// -- 只统计有考勤规则的用户
//		if (StringUtils.isNotEmpty(endDate)) {// -- 某段时间内入场的用户，比如张三是08.01号入场的，我在08.02日查询7月份的数据，这个时候人数不需要把张三也统计进来
//			sql.append("  and su.createTime < '"+endDate+"' ");
//		}
//		sql.append(" and c.attendanceDateType = 1 ");// -- 确定时间考勤
//		sql.append(" GROUP BY userIdOrCoalitionId ");
//		sql.append(" ) memberCount ");
//		sql.append(" WHERE memberCount.supplierId = s.id ");
//		sql.append(" ) memberNum, ");
//		sql.append(" ifnull(( ");
//		sql.append(" select count(1)  from attendance att  ");
//		sql.append(" where att.supplierId = s.id  ");
//		sql.append(" and att.attendanceDateType = 1 ");// -- 确定时间考勤
//		sql.append(" and att.attType = 0  ");//-- 不统计周末手动考勤生成的数据
//		sql.append(" "+CommonUtils.getDateSql(beginDate, endDate, "att.date")+" ");
//		sql.append(" group by att.supplierId ");
//		sql.append(" ),0) attSum, ");
//		sql.append(" ifnull(( ");
//		sql.append(" select count(1)  from attendance att  ");
//		sql.append(" where att.supplierId = s.id  ");
//		sql.append(" and att.attendanceDateType = 1  ");//-- 确定时间考勤 
//		sql.append(" and att.attType = 0  ");//-- 不统计周末手动考勤生成的数据 
//		sql.append(" and (att.dateinStyle != 0 or att.dateoutStyle != 0) ");
//		sql.append(" "+CommonUtils.getDateSql(beginDate, endDate, "att.date")+" ");
//		sql.append(" group by att.supplierId ");
//		sql.append(" ),0) attException ");
//		sql.append(" FROM supplier_base_info s ");
//		sql.append(" WHERE IFNULL(s.deleteFlag, '0') = '0' ");
//		sql.append(" ) tb ");
//		sql.append(" where tb.memberNum > 0 ");
//		
//		if (StringUtils.isNotEmpty(supplierName)) {
//			sql.append(" and tb.supplierName like '%"+supplierName+"%' ");
//		}
//		sql.append(" ORDER BY percentage ");
//		
//		
//		return sql.toString();
//	}
	
	/**
	 * 查询考勤日历的数据
	 * @param param
	 * @return
	 */
	public List<UTMap<String, Object>> getAttendanceCalendarDate(Map param) {
		String beginDate = param.get("beginDate").toString();//开始时间范围
		String endDate = param.get("endDate").toString();//结束时间范围
		String userId = EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId();//当前登录用户
		StringBuilder sql=new StringBuilder();
		//签到数据查询
		sql.append(" select attendance_parse(att.id, att.date,att.startTime, att.dateinStyle, 1) as result from attendance att ");
		sql.append(" where att.date BETWEEN '"+beginDate+"' AND '"+endDate+"'  ");
		sql.append(" and att.userId = '"+userId+"' ");
		sql.append(" union all ");
		
		//签退数据查询
		sql.append(" select attendance_parse(att.id, att.date,att.endTime, att.dateoutStyle, 2) as result from attendance att ");
		sql.append(" where att.date BETWEEN '"+beginDate+"' AND '"+endDate+"'  ");
		sql.append(" and att.userId = '"+userId+"' ");
		sql.append(" union all ");
		
		// 加班
		sql.append(" select manhour_parse(wo.id, wo.presentDate,wo.status, wo.hours, 1) as result from workhour_overtime wo   ");
		sql.append(" where wo.presentDate BETWEEN '"+beginDate+"' AND '"+endDate+"'  ");
		sql.append(" and wo.createUserId = '"+userId+"'  ");
		sql.append(" union all ");
				
		// 请假
		sql.append(" select manhour_parse(wo.infoId, wo.presentDate,wv.status, wo.hours, 2) as result from workhour_vacation wv, workhour_vacation_detail wo   ");
		sql.append(" where wv.id = wo.InfoId and wv.type='3' and wo.presentDate BETWEEN '"+beginDate+"' AND '"+endDate+"'  ");
		sql.append(" and wv.createUserId = '"+userId+"' ");
		sql.append(" union all ");

        // 调休
        sql.append(" select manhour_parse(wvd2.infoId, wvd2.presentDate,wv2.status, wvd2.hours, 3) as result from workhour_vacation wv2, workhour_vacation_detail wvd2   ");
        sql.append(" where wv2.id = wvd2.InfoId and wv2.type='8' and wvd2.presentDate BETWEEN '"+beginDate+"' AND '"+endDate+"' ");
        sql.append(" and wv2.createUserId = '"+userId+"'  ");
//		// 出差
//		sql.append(" select manhour_parse(wo.infoId, wo.presentDate,wo.status, wo.hours, 3) as result from workhour_travel_detail wo   ");
//		sql.append(" where wo.presentDate BETWEEN '"+beginDate+"' AND '"+endDate+"'  ");
//		sql.append(" and wo.createUserId = '"+userId+"'  ");
		return super.getListBySql(sql.toString(), null);
	}
	
	/**
	 * 查询加班、请假、出差数据
	 * @param param
	 * @return
	 */
	public List<UTMap<String, Object>> getManhourDate(Map param) {
		String presentDate = param.get("presentDate").toString();
		String createUserId = param.get("createUserId").toString();
		String status = param.get("status").toString();
		StringBuilder sql=new StringBuilder();
		
		//加班
//		sql.append(" select wo.id as infoId,wo.presentDate,wo.hours,wo.status,wo.createUserId,wo.beginTime,wo.endTime, 1 as 'manhourType' from workhour_overtime wo ");
//		sql.append(" where wo.presentDate = '"+presentDate+"' ");
//		sql.append(" and wo.createUserId = '"+createUserId+"' ");
////		sql.append(" and wo.status = '"+status+"' ");
//		sql.append(" union all ");
		
		//请假
		sql.append(" select wvd.infoId,wvd.presentDate,wvd.hours,wvd.status,wvd.createUserId,wvd.beginTime,wvd.endTime, 2 as 'manhourType' from workhour_vacation_detail wvd ");
		sql.append(" where wvd.presentDate = '"+presentDate+"' ");
//		sql.append(" and wvd.createUserId = '"+createUserId+"' ");
		sql.append(" and find_in_set(wvd.createUserId, '").append(createUserId).append("') ");
		sql.append(" and wvd.status = '"+status+"' ");
		sql.append(" union all ");
		
		//出差
		sql.append(" select wtd.infoId,wtd.presentDate,wtd.hours,wtd.status,wtd.createUserId,wtd.beginTime,wtd.endTime, 3 as 'manhourType' from workhour_travel_detail wtd ");
		sql.append(" where wtd.presentDate = '"+presentDate+"' ");
//		sql.append(" and wtd.createUserId = '"+createUserId+"' ");
		sql.append(" and find_in_set(wtd.createUserId, '").append(createUserId).append("') ");
		sql.append(" and wtd.status = '"+status+"' ");
		return super.getListBySql(sql.toString(), null);
	}
	
	/**
	 * 查询用户指定日期的考勤数据
	 * @param date
	 * @param userId
	 * @return
	 */
	public UTMap<String, Object> queryUserAttendance(String date, String userId){
		String sql = " SELECT * from attendance where date = ? and userId = ? ";
		List<UTMap<String, Object>> list = this.getListBySql(sql, date, userId);
		if(list != null && !list.isEmpty()){
			return list.get(0);
		}
		return null;
	}

	@Override
	public UTMap<String, Object> queryUserAttendanceByProjectId(String date, String userId, String projectId) {
		String sql = " SELECT * from attendance where date = ? and userId = ? and projectId= ?";
		List<UTMap<String, Object>> list = this.getListBySql(sql, date, userId,projectId);
		if(list != null && !list.isEmpty()){
			return list.get(0);
		}
		return null;
	}


	private String getSearchSql(Map<String, Object> param){
		Map<String, String> p=UTMap.mapObjToString(param);
		StringBuilder sql = new StringBuilder();
		sql.append(" select tb.*," );
		sql.append(" ifnull(wodtb1.overtimeHours,0) as overtimeHours,ifnull(wodtb2.overtimeHourApplys,0) as overtimeHourApplys, ");
		sql.append(" ifnull(wvdtb1.vacationHours,0) as casualLeaveHours,ifnull(wvdtb2.vacationHourApplys,0) as casualLeaveHoursApplys ,");
		sql.append(" ifnull(wvdtb3.vacationHours,0) as annualLeaveHours,ifnull(wvdtb4.vacationHourApplys,0) as annualLeaveHoursApplys , ");
		sql.append(" ifnull(wvdtb5.vacationHours,0) as leaveInLieuHours,ifnull(wvdtb6.vacationHourApplys,0) as leaveInLieuHoursApplys  ");
		sql.append(" from (select sbi.name as supplierName, CONCAT(su.name,'/',su.code) as userName ,so1.longName orgName, acc.name as coalitionName, att.* from attendance att ");
		sql.append(" left join supplier_base_info sbi on att.supplierId = sbi.id ");
		sql.append(" left join sys_user su on att.userId = su.id ");
		sql.append(" left join sys_org so1 on att.departId = so1.id ");
//		sql.append(" left join sys_org so on su.orgId = so.id ");
		sql.append(" left join attendance_coalition_config acc on att.coalitionId = acc.id ");
		sql.append(" WHERE 1=1 ");
		
		String id=p.get("id"); 
		String beginDate = p.get("beginDate");//查询开始日期
		String endDate = p.get("endDate");//查询结束日期
		String dateinStyle = p.get("dateinStyle");//是否迟到 1:迟到;0:正常,-1:未签到
		String dateoutStyle = p.get("dateoutStyle");//是否早退1：早退;0:正常;-1:未签退
		String supplierId = p.get("supplierId");//供应商编号
		String supplierName = p.get("supplierName");//供应商
		String userName = p.get("userName");//用户名
		String userId = p.get("userId");//用户ID
		String orgName = p.get("orgName");//组织机构
		String orgId = p.get("orgId");//组织机构id
		String date = p.get("date");//考勤日期
		String yearMonth = p.get("yearMonth");//考勤日期
		String attType = p.get("attType");//属于固定考勤用户，如果考勤记录在考勤规则范围之外，比如周末过来加班考勤了，attType=1,否则为0
		String attException = p.get("attException");//查询考勤异常的数据
		String attendanceDateType = p.get("attendanceDateType");//考勤方式:(1.确定时间，2.不确定时间)
		String coalitionId = p.get("coalitionId");//联合考勤编号
		
		if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR,RoleUtils.SUPPLIER_ADMINISTRATOR)){
			if(EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SUPPLIER_LEADERS)){//供应商负责人查看本供应商下用户的考勤配置
				sql.append(" and att.supplierId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId()+"' ");
			}else{
				sql.append(" and att.userId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' ");//外包用户只能查询自己的数据
			}
		}
		
		if (StringUtils.isNotEmpty(id)) {
			sql.append(" and att.id='"+id+"'");
		}
		
		if (StringUtils.isNotEmpty(date)) {
			sql.append(" and att.date = '"+date+"'");
		}
		
		if (StringUtils.isNotEmpty(yearMonth)) {
			sql.append(" and str_to_date(att.date, '%Y-%m') = str_to_date('"+yearMonth+"', '%Y-%m')");
		}
		
		if (StringUtils.isNotEmpty(attType)) {
			sql.append(" and att.attType = '"+attType+"'");
		}
		
		if (StringUtils.isNotEmpty(attendanceDateType)) {
			sql.append(" and att.attendanceDateType = '"+attendanceDateType+"'");
		}
		
		if (StringUtils.isNotEmpty(beginDate) && StringUtils.isNotEmpty(endDate)) {
			sql.append(" and att.date BETWEEN '"+beginDate+"' AND '"+endDate+"'  ");
		}else if (StringUtils.isNotEmpty(beginDate) ) {
			sql.append(" and att.date >= '"+beginDate+"' ");
		}else if (StringUtils.isNotEmpty(endDate)) {
			sql.append(" and att.date <='"+endDate+"'  ");
		}
		
		if (StringUtils.isNotEmpty(attException)) {
			sql.append(" and (att.dateinStyle != 0 or att.dateoutStyle != 0) ");
		}
		
		
		if (StringUtils.isNotEmpty(dateinStyle)) {
//			sql.append(" and att.dateinStyle='"+dateinStyle+"'");
			sql.append(" and find_in_set(att.dateinStyle, '").append(dateinStyle).append("') ");
		}
		
		if (StringUtils.isNotEmpty(dateoutStyle)) {
//			sql.append(" and att.dateoutStyle='"+dateoutStyle+"'");
			sql.append(" and find_in_set(att.dateoutStyle, '").append(dateoutStyle).append("') ");
		}
		
		if (StringUtils.isNotEmpty(supplierName)) {
			sql.append(" and sbi.name like '%"+supplierName+"%'");
		}
		
		if (StringUtils.isNotEmpty(supplierId)) {
			sql.append(" and att.supplierId = '"+supplierId+"'");
		}
		
		if (StringUtils.isNotEmpty(userName)) {
//			sql.append(" and (su.name like '%"+userName+"%' or su.code like '%"+userName+"%' )");
			sql.append(" and CONCAT(su.name,'/',su.code) like '%"+userName+"%' ");
		}
		
		if (StringUtils.isNotEmpty(userId)) {
			sql.append(" and att.userId='"+userId+"'");
		}
		
		if (StringUtils.isNotEmpty(orgId)) {
			sql.append(" and att.departId = '"+orgId+"'");
		}
		
		if (StringUtils.isNotEmpty(coalitionId)) {
			sql.append(" and att.coalitionId='"+coalitionId+"'");
		}
		
		if (StringUtils.isNotEmpty(orgName)) {
			sql.append(" and so1.longName like '%"+orgName+"%'");
		}

		sql.append(" ) tb ");
		sql.append(" left join ( ");
		//加班工时

		//sql.append(" select wo1.createUserId,wo1.presentDate,sum(wo1.hours) as overtimeHours from workhour_overtime wo1 where wo1.status = 5 "+CommonUtils.getDateSql(beginDate, endDate, "wo1.presentDate")+" group by wo1.createUserId,wo1.presentDate ");
//		sql.append(" select wo1.createUserId,wo1.presentDate,sum(wo1.hours) as overtimeHours from workhour_overtime wo1 where wo1.dingStatus = 'COMPLETED' "+CommonUtils.getDateSql(beginDate, endDate, "wo1.presentDate")+" group by wo1.createUserId,wo1.presentDate ");
//		sql.append(" ) wotb1 on tb.userId = wotb1.createUserId and wotb1.presentDate = tb.date ");
//		sql.append(" left join ( ");
        sql.append(" select wo1.createUserId,wod1.presentDate,sum(wod1.actualHours) as overtimeHours from workhour_overtime_detail wod1,workhour_overtime wo1 where wo1.id = wod1.infoId and wo1.dingStatus = 'COMPLETED'  "+CommonUtils.getDateSql(beginDate, endDate, "wod1.presentDate")+" group by wo1.createUserId,wod1.presentDate ");
        sql.append(" ) wodtb1 on tb.userId = wodtb1.createUserId and wodtb1.presentDate = tb.date ");
        sql.append(" left join ( ");

		//申请的加班工时
		//sql.append(" select wo2.createUserId,wo2.presentDate,sum(wo2.hours) as overtimeHourApplys from workhour_overtime wo2 where wo2.status != 1 and wo2.status != 6  "+CommonUtils.getDateSql(beginDate, endDate, "wo2.presentDate")+" group by wo2.createUserId,wo2.presentDate ");
//		sql.append(" select wo2.createUserId,wo2.presentDate,sum(wo2.hours) as overtimeHourApplys from workhour_overtime wo2 where wo2.dingStatus in('NEW','RUNNING')  "+CommonUtils.getDateSql(beginDate, endDate, "wo2.presentDate")+" group by wo2.createUserId,wo2.presentDate ");
//		sql.append(" ) wotb2 on tb.userId = wotb2.createUserId and wotb2.presentDate = tb.date  ");
//		sql.append(" left join ( ");

        sql.append(" select wo2.createUserId,wod2.presentDate,sum(wod2.hours) as overtimeHourApplys from workhour_overtime_detail wod2,workhour_overtime wo2 where wo2.id = wod2.infoId and wo2.dingStatus in('NEW','RUNNING')  "+CommonUtils.getDateSql(beginDate, endDate, "wod2.presentDate")+" group by wo2.createUserId,wod2.presentDate ");
        sql.append(" ) wodtb2 on tb.userId = wodtb2.createUserId and wodtb2.presentDate = tb.date  ");
        sql.append(" left join ( ");

		//(事假)请假工时
		//sql.append(" select wvd1.createUserId,wvd1.presentDate,sum(wvd1.hours) as vacationHours from workhour_vacation_detail wvd1 where wvd1.status = 5  "+CommonUtils.getDateSql(beginDate, endDate, "wvd1.presentDate")+" group by wvd1.createUserId,wvd1.presentDate ");
		sql.append(" select wvd1.createUserId,wvd1.presentDate,sum(wvd1.hours) as vacationHours from workhour_vacation_detail wvd1,workhour_vacation wv1 where wv1.id = wvd1.infoId and wv1.dingStatus = 'COMPLETED' and wv1.type in (1,3) "+CommonUtils.getDateSql(beginDate, endDate, "wvd1.presentDate")+" group by wvd1.createUserId,wvd1.presentDate ");
		sql.append(" ) wvdtb1 on tb.userId = wvdtb1.createUserId and wvdtb1.presentDate = tb.date ");
		sql.append(" left join ( ");
		//（事假）申请的请假工时
		//sql.append(" select wvd2.createUserId,wvd2.presentDate,sum(wvd2.hours) as vacationHourApplys from workhour_vacation_detail wvd2 where wvd2.status != 1 and wvd2.status != 6 "+CommonUtils.getDateSql(beginDate, endDate, "wvd2.presentDate")+" group by wvd2.createUserId,wvd2.presentDate ");
		sql.append(" select wvd2.createUserId,wvd2.presentDate,sum(wvd2.hours) as vacationHourApplys from workhour_vacation_detail wvd2,workhour_vacation wv2 where wv2.id = wvd2.infoId and wv2.dingStatus in('NEW','RUNNING') and wv2.type in (1,3)  "+CommonUtils.getDateSql(beginDate, endDate, "wvd2.presentDate")+" group by wvd2.createUserId,wvd2.presentDate ");
		sql.append(" ) wvdtb2 on tb.userId = wvdtb2.createUserId and wvdtb2.presentDate = tb.date  ");
		sql.append(" left join ( ");
		//（年假）请假工时
		sql.append(" select wvd3.createUserId,wvd3.presentDate,sum(wvd3.hours) as vacationHours from workhour_vacation_detail wvd3,workhour_vacation wv3 where wv3.id = wvd3.infoId and wv3.dingStatus = 'COMPLETED' and wv3.type = 1 "+CommonUtils.getDateSql(beginDate, endDate, "wvd3.presentDate")+" group by wvd3.createUserId,wvd3.presentDate ");
		sql.append(" ) wvdtb3 on tb.userId = wvdtb3.createUserId and wvdtb3.presentDate = tb.date ");
		sql.append(" left join ( ");
		//（年假）申请的请假工时
		sql.append(" select wvd4.createUserId,wvd4.presentDate,sum(wvd4.hours) as vacationHourApplys from workhour_vacation_detail wvd4,workhour_vacation wv4 where wv4.id = wvd4.infoId and wv4.dingStatus in('NEW','RUNNING') and wv4.type=3  "+CommonUtils.getDateSql(beginDate, endDate, "wvd4.presentDate")+" group by wvd4.createUserId,wvd4.presentDate ");
		sql.append(" ) wvdtb4 on tb.userId = wvdtb4.createUserId and wvdtb4.presentDate = tb.date  ");
		sql.append(" left join ( ");
		//(调休)请假工时
		sql.append(" select wvd5.createUserId,wvd5.presentDate,sum(wvd5.hours) as vacationHours from workhour_vacation_detail wvd5,workhour_vacation wv5 where wv5.id = wvd5.infoId and wv5.dingStatus = 'COMPLETED' and wv5.type = 8 "+CommonUtils.getDateSql(beginDate, endDate, "wvd5.presentDate")+" group by wvd5.createUserId,wvd5.presentDate ");
		sql.append(" ) wvdtb5 on tb.userId = wvdtb5.createUserId and wvdtb5.presentDate = tb.date ");
		sql.append(" left join ( ");
		//(调休)申请的请假工时
		sql.append(" select wvd6.createUserId,wvd6.presentDate,sum(wvd6.hours) as vacationHourApplys from workhour_vacation_detail wvd6,workhour_vacation wv6 where wv6.id = wvd6.infoId and wv6.dingStatus in('NEW','RUNNING') and wv6.type=8  "+CommonUtils.getDateSql(beginDate, endDate, "wvd6.presentDate")+" group by wvd6.createUserId,wvd6.presentDate ");
		sql.append(" ) wvdtb6 on tb.userId = wvdtb6.createUserId and wvdtb6.presentDate = tb.date  ");
//		//出差工时
//		sql.append(" select wtd1.createUserId,wtd1.presentDate,sum(wtd1.hours) as travelHours from workhour_travel_detail wtd1 where wtd1.status = 5 "+CommonUtils.getDateSql(beginDate, endDate, "wtd1.presentDate")+" group by wtd1.createUserId,wtd1.presentDate ");
//		sql.append(" ) wtdtb1 on tb.userId = wtdtb1.createUserId and wtdtb1.presentDate = tb.date ");
//		sql.append(" left join ( ");
//		//申请的出差工时
//		sql.append(" select wtd2.createUserId,wtd2.presentDate,sum(wtd2.hours) as travelHourApplys from workhour_travel_detail wtd2 where wtd2.status != 1 and wtd2.status != 6 "+CommonUtils.getDateSql(beginDate, endDate, "wtd2.presentDate")+" group by wtd2.createUserId,wtd2.presentDate ");
//		sql.append(" ) wtdtb2 on tb.userId = wtdtb2.createUserId and wtdtb2.presentDate = tb.date  ");
		sql.append(" ORDER BY tb.date desc, tb.supplierName, tb.coalitionName,tb.userName");
		return sql.toString();
	}	
	

	
}
