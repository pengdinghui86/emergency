package com.esc.oms.asset.agreement.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTListResult;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.asset.agreement.service.IAssetsAgreementInfoService;
import com.esc.oms.supplier.agreement.service.IPurchaseAgreementService;
import com.esc.oms.util.CommonUtils;
@Controller
@RequestMapping("assetsAgreement")
public class AssetsAgreementInfoController extends BaseOptionController {

	@Resource
	private IAssetsAgreementInfoService service;
	
	@Resource
	private IPurchaseAgreementService agreementService;
	
	@Override
	public IBaseOptionService optionService() {
		return service;
	}
	
	/**
	 * 新增，需要返回一个id给前台的其他标签
	 * @param info
	 * @return
	 */
	@RequestMapping(value="generateWarn",method =RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> generateWarn(@RequestBody  Map<String, Object> info){
		try{ 
    		service.generateWarn();	
    		info.put("success", true);
			info.put("msg", "发布成功！");
    	}catch(EscServiceException e){
			info.put("success", false);
			info.put("msg", e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		info.put("success", false);
    		info.put("msg", "发布失败！");
    	}		
		return info;
	}
	
	
	/**
	 * 新增，需要返回一个id给前台的其他标签
	 * @param info
	 * @return
	 */
	@RequestMapping(value="add",method =RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> add(@RequestBody  Map<String, Object> map1){
		Map<String, Object> info = CommonUtils.clone(map1);
		try{ 
    		boolean result = optionService().add(info);
    		if(result){
    			info.put("success", true);
        		info.put("msg", "操作成功！");
    		}else{
    			info.put("success", false);
//        		info.put("msg", "操作失败！");
    		}   		
    	}catch(EscServiceException e){
			info.put("success", false);
			info.put("msg", e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		info.put("success", false);
    		info.put("msg", "操作失败！");
    	}
       return info;
	}
	
	/**
	 * 新增或修改，需要返回一个id给前台的其他标签
	 * @param info
	 * @return
	 */
	@RequestMapping(value="saveOrUpdate",method =RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> saveOrUpdate(@RequestBody  Map<String, Object> map1){
		Map<String,Object> cloneMap = CommonUtils.clone(map1);
		try{
	    	if(cloneMap.get("id") == null){
	    		boolean result = optionService().add(cloneMap);
	    		if(result){
	    			cloneMap.put("success", true);
	    			cloneMap.put("msg", "操作成功！");
	    		}else{
	    			cloneMap.put("success", false);
	    		} 
	    	}else{
	    		optionService().updateById(cloneMap);
	    		cloneMap.put("success", true);
	    		cloneMap.put("msg", "操作成功！");
	    	}		
    	}catch(EscServiceException e){
    		cloneMap.put("success", false);
    		cloneMap.put("msg", e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		cloneMap.put("success", false);
    		cloneMap.put("msg", "操作失败！");
    	}
       return cloneMap;
	}
	
	/**
	 * 资产合同列表，排除已存在的资产合同
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAgreementList")  
    @ResponseBody
    public UTListResult getAllAssetsAgreement(@RequestParam Map<String, Object> params){  
		UTListResult result = new UTListResult();
		try{
			List<UTMap<String, Object>> list = service.getAgreementList(params);
			result.setRows(list);
			result.setTotal(null == list ? 0 : list.size());
		}catch(Exception e){
			logger.error("Exception", e);
		}
		return result;
    }
	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			service.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }

	/**
	 * 根据ids查询所有
	 * @param params
	 * @return
	 */
	@RequestMapping(value="getListByIds")
	@ResponseBody
    public UTListResult getListByIds(@RequestParam Map<String, Object> params){
		UTListResult result = new UTListResult();
		try{
			String ids = (String) params.get("ids");
			if(StringUtils.isNotEmpty(ids)){
				result.setRows(service.getListByIds(ids));
			}
		}catch (Exception e){
			logger.error("Exception", e);
		}
		return result;
	}
	/**
	 * 导出
	 * @param param
	 * @param utPageBean
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "leadingout")
	public void leadingout(@RequestParam Map<String, Object> param,
			HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = null;
			if(info != null) {
				jsonBean = JSONObject.fromObject(info);
			}
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = service.getListAll(jsonBean);
			} else {
				service.getPageInfo(utPageBean, jsonBean);
				data = utPageBean.getRows();
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			service.leadingout(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
}