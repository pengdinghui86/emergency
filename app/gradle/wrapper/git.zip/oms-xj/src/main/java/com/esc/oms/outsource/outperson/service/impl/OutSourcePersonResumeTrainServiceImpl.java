package com.esc.oms.outsource.outperson.service.impl;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.outperson.dao.IOutSourcePersonResumeTrainDao;
import com.esc.oms.outsource.outperson.service.IOutSourcePersonResumeTrainService;
/**
 * 简历-培训经历
 * @author djj
 * @date   2016-07-18
 */
@Service
@Transactional 
public class OutSourcePersonResumeTrainServiceImpl extends BaseOptionService implements IOutSourcePersonResumeTrainService {
	
	@Resource
	private IOutSourcePersonResumeTrainDao resumeTrainDao;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return resumeTrainDao;
	}
	

	@Override
	public boolean add(Map info){
		return super.add(info);
	}
	

	@Override
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		UTMap<String, Object> result = super.getById(id);
		return result;
	}
	
//	@EscOptionLog(module=SystemModule.outsourcePersonList, opType=ESCLogOpType.UPDATE, table="outsource_person_list", 
//	primaryKey="id={1.id}",	option="修改外包人员{1.name}/{1.code}的信息")
	@Override
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean updateById(Map info){
		return super.updateById(info);
	}


	@Override
	public void deleteByResumeId(String resumeId) {
		Map info = new HashMap<String,Object>();
		info.put("infoId", resumeId);
		this.delete(info);
	}


	@Override
	public void deleteByResumeIds(String resumeIds) {
		Map info = new HashMap<String,Object>();
		info.put("infoId", resumeIds);
		this.deletes(info);
	}
	
	
}
