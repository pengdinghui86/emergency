package com.esc.oms.asset.lowvalue.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.asset.lowvalue.dao.ILowvalueStorageDao;
@Repository
public class LowvalueStorageDaoImpl extends BaseOptionDao implements ILowvalueStorageDao{
	
	@Override
	public String getTableName() {
		return "assets_lowvalue_storage";
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params,false), pageBean, null);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params) {
		return super.getListBySql(getSearchSql(params,false), null);
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params,boolean isGetById){
		StringBuilder sql = new StringBuilder();
		sql.append(" select storage.*,CONCAT(user.name,'/',user.`code`) as acceptUserName from assets_lowvalue_storage storage ");
		sql.append(" left join sys_user user on storage.acceptUserId=user.id ");
		sql.append(" where 1=1 ");
		if(params!=null && params.size()>0){		
			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
				sql.append(" and storage.name like '%"+params.get("name").toString().trim()+"%' ");
			}
			if(params.get("code")!=null && StringUtils.isNotEmpty(params.get("code").toString())){
				sql.append(" and storage.code like '%"+params.get("code").toString().trim()+"%' ");
			}
			if(params.get("infoId")!=null && StringUtils.isNotEmpty(params.get("infoId").toString())){
				sql.append(" and storage.infoId='"+params.get("infoId").toString().trim()+"' ");
			}
			if(params.get("startDate")!=null &&  StringUtils.isNotEmpty(params.get("startDate").toString())){
				sql.append(" and DATE_FORMAT(storage.storageTime,'%Y-%m-%d')>='"+params.get("startDate").toString().trim()+"' ");
			}
			if(params.get("endDate")!=null && StringUtils.isNotEmpty(params.get("endDate").toString())){
				sql.append(" and DATE_FORMAT(storage.storageTime,'%Y-%m-%d')<='"+params.get("endDate").toString().trim()+"' ");
			}
		}
		sql.append(" order by storage.createTime desc, storage.storageTime desc, storage.sortCode ");
		return  sql.toString();
	}
}
