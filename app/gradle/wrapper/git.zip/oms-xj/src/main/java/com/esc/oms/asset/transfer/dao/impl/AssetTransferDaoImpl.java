package com.esc.oms.asset.transfer.dao.impl;

import com.esc.oms.asset.transfer.dao.IAssetTransferDao;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
@Repository
public class AssetTransferDaoImpl extends BaseOptionDao implements IAssetTransferDao{
	
	private String relationTableName = "assets_material_allocation_detail";

	@Override
	public String getTableName() {
		return "assets_material_allocation";
	}

	@Override
	public boolean addRelation(Map info) {
		return	super.saveBySql(relationTableName, info);
	}

	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params), pageBean, null);
	}
	
	public List<UTMap<String, Object>> getListMaps(Map param) {
		return super.getListBySql(getSearchSql(param));
	}
	
	@Override
	public UTMap<String, Object> getById(String id){
		return super.getOneBySql(getSearchByIdSql(id));
	}
	
	public String getTittle(String id) {
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT ama.title ");
		sql.append(" FROM assets_material_allocation ama ");
		sql.append(" WHERE ama.id = '"+id+"'");
		return (String) super.searchOneBySql(sql.toString(), null);
	}


	@Override
	public List<UTMap<String, Object>> getAssetsList(Map param) {
		return super.getListBySql(getSearchSql(param));
	}

	@Override
	public List<UTMap<String, Object>> getAssetsById(String id) {
		return super.getListBySql(getAssetsByIdSql(id));
	}

	@Override
	public boolean deleteAssetsById(String id) {
		StringBuilder sql=new StringBuilder();
		sql.append(" DELETE  FROM "
				 + relationTableName
				 + " WHERE allocationId = '" +id+"'");
		return super.executeUpdate(sql.toString());
	}
	
	
	private String getSearchByIdSql(String id){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT ama.id,ama.allocationDate,ama.createTime,ama.createUserId,ama.newChargeId, ama.workflowInstanceId," );
		sql.append(" ama.newDepartId,ama.newPlace,ama.reason,ama.remark,ama.`status`,ama.title,concat(su.`name`,'/',su.`code`)newChargeName, ");
		sql.append(" so.`name` newDepartName,ap.`name` newPlaceName,ama.isAudit,IF(ama.isAudit=1,'是','否') isAuditstr ,ama.overStatus ");
		sql.append(" FROM assets_material_allocation ama ");
		sql.append(" LEFT JOIN sys_user su ON su.id = ama.newChargeId ");
		sql.append(" LEFT JOIN sys_org so ON so.id = ama.newDepartId ");
		sql.append(" LEFT JOIN assets_place ap ON ap.id = ama.newPlace ");
		sql.append(" WHERE ama.id = '"+id+"'");
		return  sql.toString();
	}
	
	
	//获取待审列表
	public void getPendApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT DISTINCT ama.id,ama.title,ama.allocationDate,so.`longName`  newDepart,concat(su.`name`,'/',su.`code`) newCharge,ap.`name`  newPlaceId, " );
			sql.append(" ama.reason,IFNULL(concat(su2.`name`,'/',su2.`code`),'admin') createUserName,ama.createUserId,ama.createTime,ama.`status`,ama.newChargeId,ama.newDepartId ,ama.newPlace ,ama.isAudit ,IF(ama.isAudit=1,'是','否') isAuditstr ,ama.overStatus, ");
			sql.append(" t4.currentExecutor as auditors,t4.currentStepName,ama.workflowInstanceId ");
			sql.append(" FROM assets_material_allocation ama  ");
			sql.append(" LEFT JOIN assets_material_allocation_detail amad ON amad.allocationId = ama.id ");
			sql.append(" LEFT JOIN assets_place ap ON ap.id = ama.newPlace ");
			sql.append(" LEFT JOIN sys_user su ON su.id = ama.newChargeId ");
			sql.append(" LEFT JOIN sys_org so ON so.id = ama.newDepartId ");
			sql.append(" LEFT JOIN sys_user su2 ON su2.id = ama.createUserId ");
			sql.append(" left join sys_workflow_instance t4 on ama.workflowInstanceId=t4.id  ");
			sql.append(" where  FIND_IN_SET('"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"',t4.currentExecutor)  ");
			setSqlParam(sql, params);
			sql.append(" order by ama.createTime desc ");
			super.getPageListMapBySql(sql.toString(), pageBean, null);		
	}

	//获取已审列表
	@Override
	public void getAlreadyApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT DISTINCT ama.id,ama.title,ama.allocationDate,so.`longName`  newDepart,concat(su.`name`,'/',su.`code`) newCharge,ap.`name`  newPlaceId, " );
			sql.append(" ama.reason,IFNULL(concat(su2.`name`,'/',su2.`code`),'admin') createUserName,ama.createUserId,ama.createTime,ama.`status`,ama.newChargeId,ama.newDepartId ,ama.newPlace ,ama.isAudit,IF(ama.isAudit=1,'是','否') isAuditstr ,ama.overStatus,  ");
			sql.append(" t4.optionUserId as optionUserId,ama.workflowInstanceId");
			sql.append(" FROM assets_material_allocation ama  ");
			sql.append(" LEFT JOIN assets_material_allocation_detail amad ON amad.allocationId = ama.id ");
			sql.append(" LEFT JOIN assets_place ap ON ap.id = ama.newPlace ");
			sql.append(" LEFT JOIN sys_user su ON su.id = ama.newChargeId ");
			sql.append(" LEFT JOIN sys_org so ON so.id = ama.newDepartId ");
			sql.append(" LEFT JOIN sys_user su2 ON su2.id = ama.createUserId ");
			sql.append(" left join sys_workflow_audit_history t4 on ama.workflowInstanceId=t4.instanceId ");
			sql.append(" where FIND_IN_SET('"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"',t4.optionUserId) and t4.nodeName<>'开始' " );
			setSqlParam(sql, params);
			sql.append(" order by ama.createTime desc ");
			super.getPageListMapBySql(sql.toString(), pageBean, null);
	}

	
	
	private String getSearchSql(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT DISTINCT ama.id,ama.workflowInstanceId,ama.title,ama.allocationDate,so.`longName`  newDepart,concat(su.`name`,'/',su.`code`) newCharge,ap.`name`  newPlaceId, " );
		sql.append(" ama.reason,IFNULL(concat(su2.`name`,'/',su2.`code`),'admin') createUserName,ama.createUserId,ama.createTime,ama.`status`,ama.newChargeId,ama.newDepartId ,ama.newPlace ,ama.isAudit ,IF(ama.isAudit=1,'是','否') isAuditstr ,ama.overStatus");
		sql.append(" FROM assets_material_allocation ama  ");
		sql.append(" LEFT JOIN assets_material_allocation_detail amad ON amad.allocationId = ama.id ");
		sql.append(" LEFT JOIN assets_place ap ON ap.id = ama.newPlace ");
		sql.append(" LEFT JOIN sys_user su ON su.id = ama.newChargeId ");
		sql.append(" LEFT JOIN sys_org so ON so.id = ama.newDepartId ");
		sql.append(" LEFT JOIN sys_user su2 ON su2.id = ama.createUserId ");
		sql.append(" WHERE 1=1 ");
		setSqlParam(sql,params);
		sql.append(" order by ama.createTime desc");
		return  sql.toString();
	}
	
	private void setSqlParam(StringBuilder sql,Map<String, Object> params) {
		if(params!=null && params.size()>0){
			if(params.get("startTime")!=null && StringUtils.isNotEmpty(params.get("startTime").toString())){
				sql.append(" AND ama.createTime >= '"+params.get("startTime").toString().trim()+"'");
			}
			if(params.get("endTime")!=null && StringUtils.isNotEmpty(params.get("endTime").toString())){
				sql.append(" AND ama.createTime <= '"+params.get("endTime").toString().trim()+"'");
			}
			if(params.get("allocationDate")!=null && StringUtils.isNotEmpty(params.get("allocationDate").toString())){
				sql.append(" AND ama.allocationDate = date_format(NOW(),'%Y-%m-%d') ");
			}
			if(params.get("status")!=null && StringUtils.isNotEmpty(params.get("status").toString())){
				sql.append(" AND ama.status = '"+params.get("status").toString().trim()+"' ");
			}
			if(params.get("overStatus")!=null && StringUtils.isNotEmpty(params.get("overStatus").toString())){
				sql.append(" AND ama.overStatus = '"+params.get("overStatus").toString().trim()+"' ");
			}
			if(params.get("statusStr")!=null && StringUtils.isNotEmpty(params.get("statusStr").toString())){
				sql.append(" AND find_in_set( ama.status , '"+params.get("statusStr").toString().trim()+"') ");
			}
		}
	}
	
	
	private String getAssetsByIdSql(String id){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT ami.id,ami.`name`,ami.`code`,amc.`name` categoryName,amsc.`name` subCategoryName,concat(ami.`name`,IF ( ami.serialNum IS NULL OR ami.serialNum = '', '', concat('/', ami.serialNum))) assetsNameCode," );
		sql.append(" so.`name` resDepartId,ami.buyContract,ami.maintainContract,concat(su.`name`, '/', su.`code`) resUserId,ami.brand,ami.model,ap.`name` location,ami.assetsLevel ");
		sql.append(" FROM assets_material_info ami ");
		sql.append(" LEFT JOIN assets_material_allocation_detail amad ON amad.assetsId = ami.id ");
		sql.append(" LEFT JOIN assets_material_category amc ON amc.id = ami.category ");
		sql.append(" LEFT JOIN assets_material_category amsc ON amsc.id = ami.subCategory ");
		sql.append(" LEFT JOIN sys_user su ON su.id = ami.resUserId ");
		sql.append(" LEFT JOIN sys_org so ON so.id = ami.resDepartId ");
		sql.append(" LEFT JOIN assets_place ap ON ap.id = ami.location ");
		sql.append(" WHERE 1=1 AND amad.allocationId = '"+id+"'");
		return  sql.toString();
	}
	
	
}
