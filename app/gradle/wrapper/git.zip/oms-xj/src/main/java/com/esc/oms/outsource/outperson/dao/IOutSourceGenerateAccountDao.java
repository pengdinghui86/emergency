package com.esc.oms.outsource.outperson.dao;

public interface IOutSourceGenerateAccountDao {

}
