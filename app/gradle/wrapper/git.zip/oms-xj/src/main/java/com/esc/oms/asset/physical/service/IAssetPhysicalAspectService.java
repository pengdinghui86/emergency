package com.esc.oms.asset.physical.service;

import java.util.Map;

/**
 * 切面，为了使注解生效
 */
public interface IAssetPhysicalAspectService {

    public String saveOrUpdate(Map<String, Object> map);
}
