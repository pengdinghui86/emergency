package com.esc.oms.outsource.manhour.service.impl;

import com.esc.oms.outsource.attendance.service.IAttendanceService;
import com.esc.oms.outsource.manhour.dao.ITravelDao;
import com.esc.oms.outsource.manhour.dao.IVacationDao;
import com.esc.oms.outsource.manhour.dao.IVacationDetailDao;
import com.esc.oms.outsource.manhour.service.IManHourStatisticService;
import com.esc.oms.outsource.manhour.service.IVacationService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.idgenerator.IDGenerationManager;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.workflow.annotation.WorkflowRecordQueryMark;
import org.esc.framework.workflow.dao.IWorkflowInstanceDao;
import org.esc.framework.workflow.service.IWorkflowCode;
import org.esc.framework.workflow.service.IWorkflowEngine;
import org.esc.framework.workflow.utils.bpmn.FlowForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class VacationServiceImpl extends BaseOptionService implements IVacationService {

	protected Logger logger = LoggerFactory.getLogger(getClass());
	
	@Resource
	private IVacationDao vacationDao;
	
	@Resource
	private IAttendanceService attendanceService;
	
	@Resource
	private ITravelDao travelDao;
	
	@Resource
	private IVacationDetailDao detailDao;

	@Resource
	private ISysParamService sysParamService;
	
	@Resource
	private ISysUserService sysUserService;
	
	@Resource
	private MessageSend messageService;

	@Resource
	private IWorkflowEngine workflowEngine;
	
	@Resource
	private IWorkflowInstanceDao workflowInstanceDao;
	
	@Resource
	private IUserTaskService userTaskService;

	@Resource
	private IManHourStatisticService manHourStatisticService;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return vacationDao;
	}

	@Override
	@UploadAddMark
	@EscOptionLog(module = SystemModule.vacation, opType = ESCLogOpType.SUBMIT, table = "workhour_vacation", option = "提交{submitUser}请假申请。")
	public void submit(Map<String, Object> map) {
		map.put("status", STATUS_SUBMITD);
		map.put("submitUser", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectName() + "/" + EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectCode());
		map.put("submitTime", UTDate.getCurDateTime());

		String recordId = saveOrUpdate(map);

//		String workflowInstanceId = workflowEngine.runInstance(
//				IWorkflowCode.OUTSOURCE_MANHOUR_LEAVE, recordId);
//		setInstanceId(recordId, workflowInstanceId);
		String supplierId = EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId();
		String workflowInstanceId = null;
		if(StringUtils.isNotEmpty(supplierId)) {
			Map<String, Object> formMap = new HashMap<String, Object>();
			formMap.put(FlowForm.FormItemValue.TDGYS ,supplierId);
			
			workflowInstanceId = workflowEngine.runInstance(IWorkflowCode.OUTSOURCE_MANHOUR_LEAVE, recordId, formMap);
		} else {
			workflowInstanceId = workflowEngine.runInstance(IWorkflowCode.OUTSOURCE_MANHOUR_LEAVE, recordId);
		}
		setInstanceId(recordId, workflowInstanceId);
	}

	private void setInstanceId(String recordId, String workflowInstanceId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("workflowInstanceId", workflowInstanceId);
		updateById(map);
	}

	private String saveOrUpdate(Map<String, Object> map) {
		if (map.get("id") == null) {
			add(map);
		} else {
			updateById(map);
		}
		return (String) map.get("id");
	}

	@Override
	public void auditing(String recordId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("status", STATUS_AUDITING);
		super.updateById(map);
	}

	@Override
	public void finishAudit(String recordId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("status", STATUS_FINISH);
		updateById(map);
		
		// 完成审核后，加入考勤
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("infoId", recordId);
		List<UTMap<String, Object>> detailList = detailDao.getListMaps(param);
		for (UTMap<String, Object> detail : detailList) {
			try {
				attendanceService.updateAttTime((String) detail.get("createUserId"), (String) detail.get("presentDate"));
			} catch (Exception e) {
				logger.error("Exception",e);
			}
		}
	}
	
	/**
	 * @param workflowInstanceId 流程ID
	 * @return 申请人对象
	 */
	private UTMap<String, Object> getApplyUser(String workflowInstanceId){
		List<UTMap<String,Object>> workflowHistorys = workflowInstanceDao.getWorkflowHistorys(workflowInstanceId, "开始");
		if(workflowHistorys != null && workflowHistorys.size() > 0) {
			// 按照创建时间倒叙排序的，如果多次提及，会有多个开始，第一个就是最晚提交的人，name/code
			UTMap<String, Object> beginStep = workflowHistorys.get(0);
			String createUser = (String) beginStep.get("createUser");
			if(StringUtils.isNotEmpty(createUser) && createUser.contains("/")) {
				int regexIndex = createUser.indexOf("/");
				UTMap<String, Object> user = sysUserService.getUserBaseByNameOrCode(createUser.substring(regexIndex+1, createUser.length()), createUser.substring(0, regexIndex));
				if(user != null) {
					return user;
				}
			}
		}
		return  null;
	}
	

	@Override
	@EscOptionLog(module = SystemModule.vacation, opType = ESCLogOpType.REJECT, table = "workhour_vacation", primaryKey = "id={1}", option = "驳回{submitUser}请假申请。")
	public void rejectAudit(String recordId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("status", STATUS_REJECT);
		updateById(map);
		
		UTMap<String, Object> data = this.getById(recordId);
		
		String beginTime = (String) data.get("beginTime");
		String endTime = (String) data.get("endTime");
		
		UTMap<String, Object> user = this.getApplyUser(data.get("workflowInstanceId").toString());
		if(user != null){
			String applyUserId = (String)user.get("id");
			String title = "请假申请驳回提醒";
			String content = "您的【" + beginTime + "-" + endTime + "】的请假申请已被驳回，请知悉！详情请进入系统查看";
			messageService.sendMessage(applyUserId, title, content, MessageSend.Type.MAIL, MessageSend.Type.SYSTEM);
		}
	}

	@Override
	public void terminateAudit(String recordId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("status", STATUS_TERMINATE);
		updateById(map);
		
		UTMap<String, Object> data = this.getById(recordId);
		
		String beginTime = (String) data.get("beginTime");
		String endTime = (String) data.get("endTime");
		
		UTMap<String, Object> user = this.getApplyUser(data.get("workflowInstanceId").toString());
		if(user != null){
			String applyUserId = (String)user.get("id");
			String title = "请假申请终止提醒";
			String content = "您的【" + beginTime + "-" + endTime + "】的请假申请已被终止，请知悉！详情请进入系统查看";
			messageService.sendMessage(applyUserId, title, content, MessageSend.Type.MAIL, MessageSend.Type.SYSTEM);
		}
	}

	@UploadAddMark
	@EscOptionLog(module = SystemModule.vacation, opType = ESCLogOpType.INSERT, table = "workhour_vacation", option = "新增{submitUser}请假申请。")
	public boolean add(Map info) {
		info.put("createUserId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
		info.put("supplierId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId());
		info.put("supplierName", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierName());
		info.put("orgId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserOrgId());
		info.put("orgName", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserOrgName());
		info.put("code", IDGenerationManager.nextId("vacation")); // 自动生成编号
		
		checkExists(info);
		boolean flag = vacationDao.add(info);
		
		addDetail(info); // 更新详细信息
		
		return flag;
	}

	@UploadAddMark
	@EscOptionLog(module = SystemModule.vacation, opType = ESCLogOpType.UPDATE, table = "workhour_vacation", option = "更新{submitUser}请假申请。")
	public boolean updateById(Map info) {
		checkExists(info);
		boolean flag = vacationDao.updateById(info);
		addDetail(info); // 更新详细信息
		return flag;
	}
	
	private void checkExists(Map info) {
		if(info.containsKey("beginTime") && info.containsKey("endTime")) {
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("beginTime", info.get("beginTime"));
			param.put("endTime", info.get("endTime"));
			param.put("id", info.containsKey("id") ? info.get("id") : "");
			if(vacationDao.isExistRecord(param)) {
				throw new EscServiceException("当前时间段已经存在有请假信息！");
			} else {
				param.remove("id");
				if(travelDao.isExistRecord(param)) {
					throw new EscServiceException("当前时间段已经存在有出差信息！");
				}
			}
		}
	}

	@EscOptionLog(module = SystemModule.vacation, opType = ESCLogOpType.DELETE, table = "workhour_vacation", option = "删除{submitUser}请假申请。")
	public boolean delete(Map info) {
		detailDao.deleteByInfoId((String) info.get("id")); // 删除已经存在的数据
		userTaskService.finishTaskById(info); // 完成可能存在的代办
		return vacationDao.delete(info);
	}
	
	@EscOptionLog(module = SystemModule.vacation, opType = ESCLogOpType.DELETE, table = "workhour_vacation", option = "撤销{submitUser}请假申请。")
	public boolean undo(Map info) {
		
		// 更新考核数据  20160830
		Map<String, Object> param = new HashMap<String, Object>();
		String infoId = (String) info.get("id");
		param.put("infoId", infoId);
		List<UTMap<String, Object>> detailList = detailDao.getListMaps(param);
		
		detailDao.deleteByInfoId((String) info.get("id")); // 删除已经存在的详细数据
		
		// 再更新考勤
		for (UTMap<String, Object> detail : detailList) {
			attendanceService.updateAttTime((String) detail.get("createUserId"), (String) detail.get("presentDate"));
		}
		
		// 删除请假记录
		userTaskService.finishTaskById(info); // 完成可能存在的代办
		return vacationDao.delete(info);
	}

	@Override
	@UploadQueryMark
	public UTMap<String, Object> getById(String id) {
		return vacationDao.getById(id);
	}

	@Override
	@WorkflowRecordQueryMark
	public List<UTMap<String, Object>> getVacationList(Map param) {
		return vacationDao.getVacationList(param);
	}

	@Override
	@WorkflowRecordQueryMark
	public UTPageBean getVacationPage(UTPageBean pageBean, Map param) {
		vacationDao.getVacationPage(pageBean, param);
		return pageBean;
	}

	/**
	 * 导出
	 * 
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	@Override
	public boolean leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// 编号	申请人	所属部门	所属供应商	申请时间	请假开始时间	请假结束时间	工时（H）	请假类型	类型	申请原因	状态
		String[] fileds = new String[] { 
				IVacationDao.FIELD_CODE,
				IVacationDao.FIELD_ORGNAME,
				IVacationDao.FIELD_SUPPLIERNAME,
				IVacationDao.FIELD_SUBMITUSER,
				IVacationDao.FIELD_SUBMITTIME,
				"beginTimeShow",
				"endTimeShow",
				"duration",
//				IVacationDao.FIELD_HOURS,
				IVacationDao.FIELD_TYPE,
				IVacationDao.FIELD_REASON,
				IVacationDao.FIELD_STATUS };
		String tamlate = "excelOutTamplate.outsourceVacation";
		if (null != data && !data.isEmpty()) {
			for (int i=0;i<data.size();i++) {
				UTMap<String, Object> item = (UTMap<String, Object>) data.get(i);
				item.put(IVacationDao.FIELD_SUBMITTIME, CommonUtils.replaceAll((String)item.get(IVacationDao.FIELD_SUBMITTIME), "-", "/"));
				item.put("beginTimeShow", CommonUtils.replaceAll((String)item.get("beginTimeShow"), "-", "/"));
				item.put("endTimeShow", CommonUtils.replaceAll((String)item.get("endTimeShow"), "-", "/"));
			}
		}
		// 替换下拉的值
		Map<String, String> fieldAndParamType = new HashMap<String, String>();
		fieldAndParamType.put(IVacationDao.FIELD_TYPE, "vacationType");
		fieldAndParamType.put(IVacationDao.FIELD_STATUS, "vacationStatus");
		sysParamService.changeParamData(data, fieldAndParamType);

		return UTExcel.leadingout(fileds, data, tamlate, request, response);
	}

	/**
	 * 20160902 presentDate 错误，不应该是开始时间加1，以前是所有数据，后来是把0的过滤了
	 */
	@Override
	public boolean addDetail(Map info) {
		String id = (String) info.get("id");
		UTMap<String, Object> parentData = vacationDao.getById(id);
//		String beginTime = (String) parentData.get("beginTime");
		Object createUserId = parentData.get("createUserId");
		Object status = parentData.get("status");
		
//		Calendar beginDate = Calendar.getInstance();
//		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
//		try {
//			beginDate.setTime(format.parse(beginTime));
//		} catch (Exception e) {
//		}

		if(info.containsKey("hoursList")) { // 需要更新整个详细的list
			List<Map> hoursList =  (List<Map>) info.get("hoursList");
			detailDao.deleteByInfoId(id); // 删除已经存在的数据
			
			for (Map hourMap : hoursList) {
				Map<String, Object> detail = new HashMap<String, Object>();
				detail.put("infoId", id);
//				detail.put("presentDate", format.format(beginDate.getTime()));
				detail.put("presentDate", hourMap.get("beginTime"));
				detail.put("hours", hourMap.get("hours"));
				detail.put("beginTime", hourMap.get("beginTime"));
				detail.put("endTime", hourMap.get("endTime"));
				detail.put("dateType", hourMap.get("dateType")); // 记录节假日类型
				detail.put("coalitionId", hourMap.get("coalitionId")); // 记录节假日类型
				detail.put("createUserId", createUserId);
				detail.put("status", status);
				detailDao.add(detail);
				
//				beginDate.add(Calendar.DAY_OF_YEAR, 1); // 当前时间加1天
			}
		} else if(info.containsKey("status")) { // 需要更新详细的状态
			Map<String, Object> detail = new HashMap<String, Object>();
			detail.put("infoId", id);
			detail.put("status", status);
			detailDao.updateBy(detail, "infoId");
		}
		return true;
	}
	
}
