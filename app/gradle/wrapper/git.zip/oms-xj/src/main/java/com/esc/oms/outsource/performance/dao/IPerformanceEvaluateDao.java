package com.esc.oms.outsource.performance.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

/**
 * 外包绩效考核Dao-被考核对象dao
 * @author owner
 *
 */
public interface IPerformanceEvaluateDao extends IBaseOptionDao{
	public static final String  FIELD_ID= "id";
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params);
	
}
