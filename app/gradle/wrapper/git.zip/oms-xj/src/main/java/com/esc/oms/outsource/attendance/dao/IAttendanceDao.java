package com.esc.oms.outsource.attendance.dao;


import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

import java.util.List;
import java.util.Map;

/**
 * 考勤dao接口
 * @author owner
 *
 */
public interface IAttendanceDao extends IBaseOptionDao {
	
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_SUPPLIERNAME = "supplierName";//所属供应商
	public static final String  FIELD_USERNAME = "userName";//人员
	public static final String  FIELD_USERID = "userId";//人员id
	public static final String  FIELD_ORGNAME = "orgName";//所属组织
	public static final String  FIELD_DATE = "date";//考勤时间
	public static final String  FIELD_STARTTIME = "startTime";//签到时间
	public static final String  FIELD_DATEINSTYLE = "dateinStyle";//签到状态
	public static final String  FIELD_ENDTIME = "endTime";//签退时间
	public static final String  FIELD_DATEOUTSTYLE = "dateoutStyle";//签退状态
	public static final String  FIELD_DATEINIP = "dateinIp";//签到ip 
	public static final String  FIELD_STARTTYPE = "startType";//签到异常类型
	public static final String  FIELD_STARTREASON = "startReason";//签到异常原因
	public static final String  FIELD_DATEOUTIP = "dateoutIp";//签退ip
	public static final String  FIELD_ENDTYPE = "endType";//签退异常类型
	public static final String  FIELD_ENDREASON = "endReason";//签退异常原因
//	public static final String  FIELD_OVERTIMEHOUR= "overtimeHour";//加班工时
//	public static final String  FIELD_VACATIONHOUR = "vacationHour";//请假工时
//	public static final String  FIELD_TRAVELHOUR = "travelHour";//出差工时
	public static final String  FIELD_COALITIONNAME = "coalitionName";//联合而考勤名称
	
	public static final String  FIELD_BEGINDATE = "beginDate";//开始日期
	public static final String  FIELD_ENDDATE = "endDate";//结束日期
	public static final String  FIELD_ATTDAYS = "attDays";//考勤天数
	public static final String  FIELD_ATTEXDAYS = "attExDays";//异常天数
	public static final String  FIELD_ATTHOURS = "attHours";//考勤工时
	public static final String  FIELD_VACATIONHOURAPPLYS = "vacationHourApplys";//申请加班工时
	public static final String  FIELD_VACATIONHOURS = "vacationHours";//加班工时
	public static final String  FIELD_OVERTIMEHOURAPPLYS = "overtimeHourApplys";//申请请假工时
	public static final String  FIELD_OVERTIMEHOURS = "overtimeHours";//请假工时
	public static final String  FIELD_TRAVELHOURAPPLYS = "travelHourApplys";//申请出差工时
	public static final String  FIELD_TRAVELHOURS = "travelHours";//出差工时
	
	public static final String  FIELD_MEMBERNUM = "memberNum";//考勤人数
	public static final String  FIELD_ATTSUM = "attSum";//需考勤总天数
	public static final String  FIELD_ATTNORMAL = "attNormal";//正常考勤总天数
	public static final String  FIELD_ATTEXCEPTION = "attException";//异常总天数
	public static final String  FIELD_PERCENTAGE = "percentage";//异常率
	
//	public static final String[] inFileds = new String[] {
//		FIELD_EVALUATE_TITLE,
//		FIELD_BEGIN_DATE,
//		FIELD_END_DATE,
//		FIELD_EVALUATOR,
//		FIELD_OUTSIDE_SPECIALISTS,
//		FIELD_ACCESS_RESULT,
//		FIELD_RESULT_REMARK
//	};
	
	public static final String[] outFileds = new String[] {
		FIELD_SUPPLIERNAME,
		FIELD_ORGNAME,
		FIELD_USERNAME,
		FIELD_DATE,
		FIELD_STARTTIME,
		FIELD_DATEINSTYLE,
		FIELD_ENDTIME,
		FIELD_DATEOUTSTYLE,
		FIELD_ATTHOURS,
		"dateinAddress",
		"dateoutAddress",
		FIELD_OVERTIMEHOURS,
		"casualLeaveHours",
		"leaveInLieuHours"
	};
	
	//考勤工时
	public static final String[] outAttHoursFileds = new String[] {
		FIELD_USERNAME,
		FIELD_SUPPLIERNAME,
		FIELD_ORGNAME,
		FIELD_BEGINDATE,
		FIELD_ENDDATE,
		FIELD_ATTDAYS,
		FIELD_ATTEXDAYS,
		FIELD_ATTHOURS,
		FIELD_VACATIONHOURAPPLYS,
		FIELD_VACATIONHOURS,
		FIELD_OVERTIMEHOURAPPLYS,
		FIELD_OVERTIMEHOURS,
		"leaveInLieuHoursApplys",
		"leaveInLieuHours"
	};
	
	//联合考勤工时
	public static final String[] outCoalitionAttHoursFileds = new String[] {
		FIELD_COALITIONNAME,
		FIELD_SUPPLIERNAME,
		FIELD_ORGNAME,
		FIELD_BEGINDATE,
		FIELD_ENDDATE,
		FIELD_ATTDAYS,
		FIELD_ATTEXDAYS,
		FIELD_ATTHOURS,
		FIELD_VACATIONHOURAPPLYS,
		FIELD_VACATIONHOURS,
		FIELD_OVERTIMEHOURAPPLYS,
		FIELD_OVERTIMEHOURS,
		FIELD_TRAVELHOURAPPLYS,
		FIELD_TRAVELHOURS
	};
	
	//常规供应商维度考勤统计
	public static final String[] outAttSupplierConventionalFileds = new String[] {
		FIELD_SUPPLIERNAME,
		FIELD_BEGINDATE,
		FIELD_ENDDATE,
		FIELD_MEMBERNUM,
		FIELD_ATTSUM,
		FIELD_ATTNORMAL,
		FIELD_ATTEXCEPTION,
		FIELD_PERCENTAGE
	};
	
	//常规组织机构维度考勤统计
	public static final String[] outAttOrgConventionalFileds = new String[] {
		FIELD_ORGNAME,
		FIELD_BEGINDATE,
		FIELD_ENDDATE,
		FIELD_MEMBERNUM,
		FIELD_ATTSUM,
		FIELD_ATTNORMAL,
		FIELD_ATTEXCEPTION,
		FIELD_PERCENTAGE
	};
	
	/**
	 * 查询用户指定日期的考勤数据
	 * @param date
	 * @param userId
	 * @return
	 */
	public UTMap<String, Object> queryUserAttendance(String date, String userId);
	/**
	 * 查询用户指定日期的考勤数据
	 * @param date
	 * @param userId
	 * @return
	 */
	public UTMap<String, Object> queryUserAttendanceByProjectId(String date, String userId, String projectId);
	
	/**
	 * 查询考勤日历的数据
	 * @param param
	 * @return
	 */
	public List<UTMap<String, Object>> getAttendanceCalendarDate(Map param) ;
	
	/**
	 * 查询加班、请假、出差数据
	 * @param param
	 * @return
	 */
	public List<UTMap<String, Object>> getManhourDate(Map param);
	
	/**
	 * 获取个人考勤工时统计数据
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllAttHours(Map param);
	
	/**
	 * 获取个人考勤工时统计数据
	 * @param pageBean
	 * @param param
	 */
	public void getAttHours(UTPageBean pageBean,Map param);
	
	/**
	 * 常规考勤统计（供应商）
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllSupplierConventional(Map param);
	
	/**
	 * 常规考勤统计（供应商）
	 * @param pageBean
	 * @param param
	 */
	public void getSupplierConventional(UTPageBean pageBean,Map param);

	
	/**
	 * 常规考勤统计（部门）
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllOrgConventional(Map param);
	
	/**
	 * 常规考勤统计（部门）
	 * @param pageBean
	 * @param param
	 */
	public void getOrgConventional(UTPageBean pageBean,Map param);
	
	/**
	 * 获取联合考勤工时统计数据
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllCoalitionAttHours(Map param);
	
	/**
	 * 获取联合考勤工时统计数据
	 * @param pageBean
	 * @param param
	 */
	public void getCoalitionAttHours(UTPageBean pageBean,Map param);
	
	/**
	 * 退厂申请删除相应的考勤数据
	 * @param userId
	 * @param date
	 */
	public void deleteByPersonExit(String userId, String date);

	/**
	 * 根据条件获取所有的考勤记录
	 * @param param
	 */
	public List<UTMap<String, Object>>  getAllAttendanceList(Map<String, Object> param);

    /**
     * 删除时间段内的考勤
     * @param startTime
     * @param endTime
     * @return
     */
	public boolean deleteByTime(String startTime, String endTime, String userIds);

	/**
	 * 根据钉钉id和当前时间获取打卡数据
	 * @param presentDate
	 * @param dingDingId
	 * @return
	 */
	public Map<String, Object> getAttendance(String presentDate, String dingDingId);
}
