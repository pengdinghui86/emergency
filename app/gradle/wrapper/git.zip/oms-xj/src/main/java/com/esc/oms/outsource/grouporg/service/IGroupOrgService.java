package com.esc.oms.outsource.grouporg.service;

import java.util.List;
import java.util.Map;

import org.esc.framework.utils.UTMap;

public interface IGroupOrgService {
	
	public boolean saveGroupOrgAndUser(List<Map<String, Object>> info,int groupOrgType);
	
	public List<UTMap<String, Object>> getGroupOrgAndUser(int groupOrgType);

	public boolean deleteGroupAfter(String groupIds,int groupOrgType);
	
}
