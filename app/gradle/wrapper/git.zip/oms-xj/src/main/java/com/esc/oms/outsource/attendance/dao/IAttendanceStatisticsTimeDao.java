package com.esc.oms.outsource.attendance.dao;


import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

/**
 * 不确定时间考勤考勤统计-按工时dao接口
 * @author owner
 *
 */
public interface IAttendanceStatisticsTimeDao extends IBaseOptionDao {
	
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_USERID = "userId";//姓名id
	public static final String  FIELD_USERNAME = "userName";//姓名
	public static final String  FIELD_SUPPLIERID = "supplierId";//供应商id
	public static final String  FIELD_SUPPLIERNAME = "supplierName";//供应商
	public static final String  FIELD_COALITIONNAME = "coalitionName";//联合考勤名称
	public static final String  FIELD_ORGID= "orgId";//部门id
	public static final String  FIELD_ORGNAME = "orgName";//部门
	public static final String  FIELD_YEAR = "year";
	public static final String  FIELD_MONTH = "month";
	public static final String  FIELD_YEARMONTH = "yearMonth";
	public static final String  FIELD_QUARTER = "quarter";
	public static final String  FIELD_BEGINDATE = "beginDate";
	public static final String  FIELD_ENDDATE = "endDate";
	public static final String  FIELD_ATTNEEDTIME = "attNeedTime";
	public static final String  FIELD_ATTTIME= "attTime";
	public static final String  FIELD_SUMATTTIME= "sumAttTime";
	public static final String  FIELD_ATTEXTIME= "attExTime";
	public static final String  FIELD_PERCENTAGE = "percentage";
	public static final String  FIELD_SUMPERCENTAGE = "sumPercentage";
	public static final String  FIELD_MEMBERNUM = "memberNum";
	public static final String  FIELD_EXMEMBERNUM = "exMemberNum";
	public static final String  FIELD_NAME = "name";
	
	
//	public static final String[] inFileds = new String[] {
//		FIELD_EVALUATE_TITLE,
//		FIELD_BEGIN_DATE,
//		FIELD_END_DATE,
//		FIELD_EVALUATOR,
//		FIELD_OUTSIDE_SPECIALISTS,
//		FIELD_ACCESS_RESULT,
//		FIELD_RESULT_REMARK
//	};
	
	//个人
	public static final String[] outFileds = new String[] {
		FIELD_USERNAME,
		FIELD_SUPPLIERNAME,
		FIELD_ORGNAME,
		FIELD_BEGINDATE,
		FIELD_ENDDATE,
		FIELD_ATTNEEDTIME,
		FIELD_ATTTIME,
		FIELD_ATTEXTIME,
		FIELD_PERCENTAGE
	};
	
	//联合
	public static final String[] outAttCoalitionOperationsTimeFileds = new String[] {
		FIELD_COALITIONNAME,
		FIELD_SUPPLIERNAME,
		FIELD_ORGNAME,
		FIELD_BEGINDATE,
		FIELD_ENDDATE,
		FIELD_ATTNEEDTIME,
		FIELD_ATTTIME,
		FIELD_ATTEXTIME,
		FIELD_PERCENTAGE
	};
	
	//供应商
	public static final String[] outAttSupplierOperationsTimeFileds = new String[] {
		FIELD_SUPPLIERNAME,
		FIELD_YEARMONTH,
		FIELD_MEMBERNUM,
		FIELD_EXMEMBERNUM,
//		FIELD_ATTNEEDTIME,
//		FIELD_ATTTIME,
//		FIELD_ATTEXTIME,
		FIELD_PERCENTAGE
	};
	
	//部门
	public static final String[] outAttOrgOperationsTimeFileds = new String[] {
		FIELD_ORGNAME,
		FIELD_YEARMONTH,
		FIELD_MEMBERNUM,
		FIELD_EXMEMBERNUM,
//		FIELD_ATTNEEDTIME,
//		FIELD_ATTTIME,
//		FIELD_ATTEXTIME,
		FIELD_PERCENTAGE
	};
	
	//统计详情
	public static final String[] outAttOperationsTimeDetailFileds = new String[] {
		FIELD_NAME,
		FIELD_SUPPLIERNAME,
		FIELD_ORGNAME,
		FIELD_YEARMONTH,
		FIELD_ATTNEEDTIME,
		FIELD_SUMATTTIME,
		FIELD_ATTEXTIME,
		FIELD_SUMPERCENTAGE
	};

	/**
	 * 删除指定年月的统计数据
	 * @param yearMonth
	 */
	public void deleteByDate(String yearMonth);
	
	/**
	 * 初始化指定日期范围内的不确定考勤，按考勤次数的考勤统计数据
	 * @param beginDate
	 * @param endDate
	 */
	public void initDate(String beginDate, String endDate,int year,int month,int quarter,String yearMonth);
	
	/**
	 * 运维联合考勤统计
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllCoalitionOperations(Map param);
	
	/**
	 * 运维联合考勤统计
	 * @param pageBean
	 * @param param
	 */
	public void getCoalitionOperations(UTPageBean pageBean,Map param);

	/**
	 * 运维考勤统计（供应商）
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllSupplierOperations(Map param);
	
	/**
	 * 运维考勤统计（供应商）
	 * @param pageBean
	 * @param param
	 */
	public void getSupplierOperations(UTPageBean pageBean,Map param);
	
	/**
	 * 运维考勤统计（部门）
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllOrgOperations(Map param);
	
	/**
	 * 运维考勤统计（部门）
	 * @param pageBean
	 * @param param
	 */
	public void getOrgOperations(UTPageBean pageBean,Map param);
	
	/**
	 * 点击异常率查询详情数据接口
	 * @param param
	 * @return
	 */
	public void getDetail(UTPageBean pageBean,Map param);
	
	/**
	 * 点击异常率查询详情数据接口
	 * @param param
	 * @return
	 */
	public List<UTMap<String, Object>> getDetail(Map param);

}
