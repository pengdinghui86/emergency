package com.esc.oms.outsource.outperson.service;


import java.util.Map;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

public interface IRecruitmentConfirmLevelService  extends IBaseOptionService{

	public UTMap<String, Object> getInfoById(String id);

	public boolean confirmLevel(Map<String, Object> param);

	public void getAlreadyPageInfo(UTPageBean pageBean, Map<String, Object> params);

}
