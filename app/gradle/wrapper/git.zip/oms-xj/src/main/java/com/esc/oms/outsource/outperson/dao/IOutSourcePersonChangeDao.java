package com.esc.oms.outsource.outperson.dao;

import java.util.List;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

/**
 * 外包人员更改记录
 * @author jane
 *
 */
public interface IOutSourcePersonChangeDao extends IBaseOptionDao {
	
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_SUPPLIERID = "supplierId";
	public static final String  FIELD_SUPPLIERNAME = "supplierName";
	public static final String  FIELD_CHANGEUSERID = "changeUserId";
	public static final String  FIELD_CHANGEUSERNAME = "changeUserName";
	public static final String  FIELD_CHANGETYPE = "changeType";
	public static final String  FIELD_BEGINDATE = "beginDate";
	public static final String  FIELD_CHANGEBEFORE = "changeBefore";
	public static final String  FIELD_CHANGEAFTER = "changeAfter";
	public static final String  FIELD_REMARK = "remark";
	
	public List<UTMap<String,Object>> getLevelsByUserId(String userId);
	
}
