package com.esc.oms.asset.overview.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTListResult;
import org.esc.framework.utils.page.UTPageBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.asset.overview.service.IAssetsOverviewService;
import com.esc.oms.asset.physical.service.IAssetPhysicalService;
import com.esc.oms.supplier.agreement.service.IPurchaseAgreementService;
import com.esc.oms.util.CommonUtils;
@Controller
@RequestMapping("assetsOverview")
public class AssetsOverviewController{

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Resource
	private IAssetsOverviewService service;
	
	@Resource
	private IPurchaseAgreementService agreementService;
	
	@Resource
	private IAssetPhysicalService assetPhysicalService;
	
	
	/**
	 * 资产列表
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAssetsList")  
    @ResponseBody
    public UTListResult getAssetsList(@RequestParam Map<String, Object> params){  
		UTListResult result = new UTListResult();
		try{
			List<UTMap<String, Object>> list = service.getAssetsList(params);
			result.setRows(list);
			result.setTotal(list.size());
		}catch(Exception e){
			logger.error("Exception", e);
		}
		return result;
    }
	
	/**
	 *  资产列表，分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAssetsPageList")  
    @ResponseBody
    public UTPageBean getAssetsPageList(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			service.getAssetsPageList(pageBean, params);
			List<Map<String, Object>> list = pageBean.getRows();
			if(null != list && list.size() > 0 ){
				for (Map<String, Object> map : list) {
					if(null != map.get("isScrap")){
						if(1 == Integer.parseInt(String.valueOf(map.get("isScrap")))){
							map.put("isScrap", "是");
						}else{
							map.put("isScrap", "否");
						}
					}else{
						map.put("isScrap", "否");
					}
					
				}
			}
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	/**
	 * 到预警期资产合同列表
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getWarnAgreementList")  
    @ResponseBody
    public UTListResult getWarnAgreementList(@RequestParam Map<String, Object> params){  
		UTListResult result = new UTListResult();
		try{
			List<UTMap<String, Object>> list = service.getWarnAgreementList(params);
			result.setRows(list);
			result.setTotal(list.size());
		}catch(Exception e){
			logger.error("Exception", e);
		}
		return result;
    }
	
	/**
	 *  到预警期资产合同列表，分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getWarnAgreementPageList")  
    @ResponseBody
    public UTPageBean getWarnAgreementPageList(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			service.getWarnAgreementPageList(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	/**
	 * 资产统计--类别维度统计
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getOverviewReportCategoy")  
    @ResponseBody
    public Map<String,Object> getOverviewReportCategoy(@RequestParam Map<String, Object> params){  
		Map<String,Object> map = new HashMap<String,Object>();
		try{
			map = service.getOverviewReportCategoy(params);
		}catch(Exception e){
			logger.error("Exception", e);
		}
		return map;
    }
	
	/**
	 * 资产统计--月维度统计
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getOverviewReportMonth")  
    @ResponseBody
    public Map<String,Object> getOverviewReportMonth(@RequestParam Map<String, Object> params){  
		Map<String,Object> map = new HashMap<String,Object>();
		try{
			map = service.getOverviewReportMonth(params);
		}catch(Exception e){
			logger.error("Exception", e);
		}
		return map;
    }
	
	@RequestMapping(value="getMaintAgreementPageList")  
    @ResponseBody
    public UTPageBean getMaintAgreementPageList(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			assetPhysicalService.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	@RequestMapping(value="getAssetsAgreementPageList")  
    @ResponseBody
    public UTPageBean getAssetsAgreementPageList(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			assetPhysicalService.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
}