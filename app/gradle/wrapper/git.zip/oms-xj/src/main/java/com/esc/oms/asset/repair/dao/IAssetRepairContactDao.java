package com.esc.oms.asset.repair.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

public interface IAssetRepairContactDao extends IBaseOptionDao {
	
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_AGREEMENTID = "agreementId";
	public static final String  FIELD_AGREEMENTNAME = "agreementName";
	public static final String  FIELD_SUPPLIERID = "supplierId";
	public static final String  FIELD_SUPPLIERNAME = "supplierName";
	public static final String  FIELD_CONTACTUSER = "contactUser";
	public static final String  FIELD_CONTACTPHONE = "contactPhone";
	public static final String  FIELD_BACKUPUSER = "backupUser";
	public static final String  FIELD_BACKUPPHONE = "backupPhone";
	public static final String  FIELD_RANGEE = "rangee";
	public static final String  FIELD_CREATEUSERID = "createUserId";
	public static final String  FIELD_CREATETIME = "createTime";
	
	
	public UTMap<String, Object> getRepairById(String id);
	
	public List<UTMap<String, Object>> getRepairList(Map param);
	
}
