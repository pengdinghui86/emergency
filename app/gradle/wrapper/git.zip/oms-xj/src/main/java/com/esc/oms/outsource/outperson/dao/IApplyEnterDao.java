package com.esc.oms.outsource.outperson.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

/**
 * 入场申请 dao 接口
 * @author smq
 * @date   2016-7-9 上午10:39:06
 */
public interface IApplyEnterDao extends IBaseOptionDao{

	public static final String  FIELD_ID = "id";
	public static final String  FIELD_ENTERUSERID = "enterUserId";
	public static final String  FIELD_ENTERUSERNAME= "enterUserName";
	public static final String  FIELD_ENTERUSERLOGINNAME = "enterUserLoginName";
	public static final String  FIELD_DEPARTMENTID = "departmentId";
	public static final String  FIELD_DEPARTMENTNAME = "departmentName";
	public static final String  FIELD_SUPPLIERID= "supplierId";
	public static final String  FIELD_SUPPLIERNAME= "supplierName";
	public static final String  FIELD_PROCESSID = "processId";
	public static final String  FIELD_PROJECTID = "projectId";
	public static final String  FIELD_PROJECTNAME = "projectName";
	public static final String  FIELD_REASON = "reason";
	public static final String  FIELD_PROCESSSTEP = "processStep";
	public static final String  FIELD_ENTERDATE = "enterDate";
	public static final String  FIELD_EXITDATE = "exitDate";
	public static final String  FIELD_MOBILEPHONE = "mobilePhone";
	public static final String  FIELD_EMAIL = "email";
	public static final String  FIELD_ISIN = "isIn";
	public static final String  FIELD_ISKEYPERSON = "isKeyPerson";
	public static final String  FIELD_ISNOTICE = "isNotice";
	public static final String  FIELD_ISDATAPERFECT = "isDataPerfect";
	public static final String  FIELD_STATUS = "status";
	public static final String  FIELD_CONFIMUSERID = "confimUserId";
	public static final String  FIELD_CONFIMDATE = "confimDate";
	
	public static final String  FIELD_CONFIMUSERNAME = "confimUserName";
	public static final String  FIELD_CREATETIME = "createTime";
	public static final String  FIELD_REMARK = "remark";

	public List<UTMap<String, Object>> searchInfo(Map<String, Object> params) ;
	
	public void searchInfoPage(UTPageBean pageBean,Map<String, Object> params) ;
	
	public void getPendApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) ;

	public void getAlreadyApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) ;
	
}
