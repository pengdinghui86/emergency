package com.esc.oms.outsource.outperson.service.impl;

import com.esc.oms.outsource.attendance.dao.IUserConfigDao;
import com.esc.oms.outsource.attendance.service.IAttendanceService;
import com.esc.oms.outsource.attendance.service.IUserConfigService;
import com.esc.oms.outsource.outperson.dao.IApplyExitDao;
import com.esc.oms.outsource.outperson.dao.IApplyQuitDao;
import com.esc.oms.outsource.outperson.dao.IOutSourcePersonDao;
import com.esc.oms.outsource.outperson.service.IOutSourcePersonConfigService;
import com.esc.oms.outsource.outperson.service.IPersonOptionService;
import com.esc.oms.outsource.report.dao.IPersonStatisticsDao;
import com.esc.oms.supplier.agreement.service.IAgreementTeamService;
import com.esc.oms.supplier.info.dao.ISupplierBaseInfoDao;
import com.esc.oms.supplier.project.service.IProjectResService;
import com.esc.oms.supplier.supplieremp.dao.ISupplierEmpDao;
import com.esc.oms.supplier.supplieremp.dao.ISupplierEmpWorkrecordDao;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.FunctionEnum.WorkRecordType;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.ESCFrameEnum.ESCDataState;
import org.esc.framework.dict.dao.ISysParamDao;
import org.esc.framework.dict.util.UTParamTransform;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.security.dao.ISysUserDao;
import org.esc.framework.timetask.anotations.CronTimeTask;
import org.esc.framework.timetask.anotations.TimeTaskMark;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 人员业务操作类
 * ①删除人员 ：正常流程删除人员包括 退场，离职时 ，执行相关业务清除操作
 * ②添加人员 ： 正常流程添加人员包括 入场 导入，执行相关业务操作
 * @author smq
 * @date   2016-9-2 上午10:33:15
 */
@Service
@Transactional
@TimeTaskMark
public class PersonOptionService implements IPersonOptionService{
	@Resource
	private ISysUserDao userDao;
	@Resource
	private ISupplierEmpDao empDao;
	@Resource
	private IOutSourcePersonDao  personDao;
	@Resource
	private IAgreementTeamService agreementTeamService;
	@Resource
	private IProjectResService projectResService;
	@Resource
	private IOutSourcePersonConfigService personConfigService;
	@Resource
	private ISupplierEmpWorkrecordDao workrecordDao;
	@Resource
	private IUserConfigService userConfigService;
	@Resource
	private IAttendanceService attendanceService;
	@Resource
	private IApplyExitDao exitDao;
	@Resource
	private ISysParamDao paramDao;
	@Resource
	private MessageSend messageSend;
	@Resource
	private IUserConfigDao userConfigDao;
	@Resource
	private IApplyQuitDao quitDao;
	@Resource
	private IPersonStatisticsDao personStatisticsDao;
	@Resource
	private ISupplierBaseInfoDao supplierBaseInfoDao;

	protected Logger logger = LoggerFactory.getLogger(getClass());
/*************************补充业务（重其他业务块中抽离） ***************************	

	//删除用户，供应商人，外包人 及关联业务数据处理

	//生成考勤数据
	
	//人员配置添加
	
	//人员配置取消
****************************************************	/	
	/**
	 *审批通过后 删除时处理用户关联业务
	 * @param userId
	 * @param deleteDate
	 * @param reason
	 * @param remark
	 * @param recordType
	 */
	public void deletePersonService(String userId,String deleteDate,String reason,String remark , WorkRecordType recordType){
		String curDate=UTDate.getCurDate();

		// 若退场日期在（包括今天的）
		 if(StringUtils.equals(deleteDate, curDate) || UTDate.dateCompare(deleteDate, UTDate.DATE_FORMAT)){
			deleteUserInfo(userId, deleteDate, reason, remark, recordType,false);
			//审批通过后 记录 退场当天的流动率
			personFlowTimingQuit(deleteDate);
		}
		// 若退场日期在今天之后 修改考勤结束时间 为退场日期前一天
		else{
			Map<String, Object> info=new HashMap<String, Object>();
			deleteDate=UTDate.getBeforDay(UTDate.getDate(deleteDate, UTDate.DATE_FORMAT));
			info.put("userId", userId);
			info.put("endDate", deleteDate);
			userConfigDao.updateBy(info, "userId");
		}
	}
	
	//退场
	//定时删除 定时时间(每天凌晨3点，退场第二天)
	@CronTimeTask(description="外包人员退出提醒定时任务",cron="0 0 3 * * ?" )
	public void deleteUserInfoTimingExit(){
		//获取所有退场或离职流程结束的 ，并且 退场时间等于当天的 数据 ,
		Map<String, Object> param=new HashMap<String, Object>();
	//	param.put("status", 8);
		param.put("exitDate", UTDate.getCurDate());
	//	System.out.println("进入外包人员退出提醒定时任务");
		List<UTMap<String, Object>> list = exitDao.getListMaps(param);

		logger.info("进入外包人员退出提醒定时任务---将发送"+list.size()+"条通知1");
		if(list==null||list.size()<1){
			return;
		}
		UTParamTransform statusTransform2 = new UTParamTransform(paramDao,"exitReasonList");
		for (UTMap<String, Object> item : list) {
			if(item.get("status")==null){
				continue;
			}
			Integer status=Integer.valueOf(item.get("status").toString());
			if(status<4 || status==5 ||  status==6  ){
				continue;
			}
			String userId=item.get("exitUserId").toString();
			String exitUserName=item.get("exitUserName").toString();
			String deleteDate=item.get("exitDate").toString();
			String reason=item.get("exitReason").toString();
			String reasonName=statusTransform2.value2Name(reason);
			String remark=item.get("remark").toString();
			String supplierId=item.get("supplierId").toString();
			String isQuit = item.get("isQuit") == null ? "0" : item.get("isQuit").toString();
			String supplierName=	supplierBaseInfoDao.getById(supplierId, "name").get("name").toString();
			//人员删除业务处理
			deleteUserInfo(userId, deleteDate, reasonName, remark, WorkRecordType.EXITFACTORY,true);
		  	  //发送提醒给供应商管理员
			String title = "外包人员【"+exitUserName +"】退场到期提醒";
			String content = "供应商【" + supplierName + "】 的人员【"+ exitUserName+"】已成功退场！";
			logger.info(content);
			//System.out.println(content);
			messageSend.sendMessage(userId, title, content, "email","system");
		}
	}
	
	public void timing(){
		deleteUserInfoTimingExit();
		deleteUserInfoTimingQuit();
		 personFlowTimingQuit(null);
	}
	
	//离职
	//定时删除 定时时间(每天凌晨3点，退场第二天)
	@CronTimeTask(description="外包人员离职提醒定时任务",cron="0 0 3 * * ?" )
	public void deleteUserInfoTimingQuit(){
		//获取所有退场或离职流程结束的 ，并且 退场时间等于当天的 数据 ,
		Map<String, Object> param=new HashMap<String, Object>();
		//param.put("status", 9);
		param.put("quitDate", UTDate.getCurDate());
		
		List<UTMap<String, Object>> list = quitDao.getListMaps(param);

		logger.info("进入外包人员离职提醒定时任务---将发送"+list.size()+"条通知1");
		if(list==null||list.size()<1){
			return;
		}
		for (UTMap<String, Object> item : list) {
			if(item.get("status")==null){
				continue;
			}
			Integer status=Integer.valueOf(item.get("status").toString());
			if(status<4 || status==5 ||  status==6  ){
				continue;
			}
			String userId=item.get("quitUserId").toString();
			String exitUserName=item.get("quitUserName").toString();
			String deleteDate=item.get("quitDate").toString();
			String reasonName="离职";
			String remark=item.get("remark").toString();
		//	String supplierName=item.get("supplierName").toString();
			String supplierId=item.get("supplierId").toString();
			String supplierName=	supplierBaseInfoDao.getById(supplierId, "name").get("name").toString();
			//人员删除业务处理
			deleteUserInfo(userId, deleteDate, reasonName, remark, WorkRecordType.EXITFACTORY,true);
		  	  //发送提醒给供应商管理员
			String title = "外包人员【"+exitUserName +"】离职提醒";
			String content = "供应商【" + supplierName + "】 的人员【"+ exitUserName+"】已成功退场！";
			logger.info(content);
			//System.out.println(content);
			 messageSend.sendMessage(userId, title, content, "email","system");
		}
	}
	
////////////////////////////////////////////////////////////////////////////////////////////////
	//删除(逻辑删除)
	//1.信息与 用户，供应商人，外包人员同步 
	private void deleteUserInfo(String userId,String deleteDate,String reason,String remark , WorkRecordType recordType ,boolean isTiming){
		//获取参与的项目
		//删除用户(逻辑删除)
		if (StringUtils.equals(WorkRecordType.EXITFACTORY.getValue().toString(), recordType.getValue().toString())) {//退场的时候才进行数据的逻辑删除
			Map<String, String> userInfo=new HashMap<String, String>();
			userInfo.put("id", userId);
			userInfo.put("state",ESCDataState.CANCEL.getValue().toString());
			userDao.updateById(userInfo);
			
			Map<String, String> empInfo=new HashMap<String, String>();
			empInfo.put("userId", userId);
			empInfo.put("state",ESCDataState.CANCEL.getValue().toString());
			empInfo.put("endDate", deleteDate);
			empInfo.put(ISupplierEmpDao.FIELD_ISVALID,ESCDataState.CANCEL.getValue().toString());
			empDao.updateBy(empInfo, "userId");
			
			Map<String, String> person=	new HashMap<String, String>();
			person.put("userId", userId);
			person.put("state",ESCDataState.CANCEL.getValue().toString());
			personDao.updateBy(person, "userId");
	
			//注销系统用默认权限
			personConfigService.cancelConfigByUserId(userId);
			//释放项目人力资源
			projectResService.releaseByProjectAndUser(null,userId);
			//删除用户考勤规则接口：
			userConfigService.deleteByUserId( userId);
			//合同服务团队释放
			agreementTeamService.release(userId);
		
			//不是定时  则删除考勤记录（  若退场/离职日期在今天或之前的）
			if(!isTiming){
				attendanceService.deleteByPersonExit(userId, deleteDate);
			}
		}
		logger.info(CommonUtils.vaildLog("进入外包人员关联业务删除"+userId));
		//添加轨迹
		if(StringUtils.equals(WorkRecordType.EXITFACTORY.getValue().toString(), recordType.getValue().toString())){
			workrecordDao.add(userId, "外包人员退出", deleteDate,null, remark, reason, WorkRecordType.EXITFACTORY);
		}
		else if (StringUtils.equals(WorkRecordType.LEAVEOFFER.getValue().toString(), recordType.getValue().toString())) {
			workrecordDao.add(userId, "外包人员离职", deleteDate,null, remark, reason, WorkRecordType.LEAVEOFFER);
		}else{
			
		}
		
	}
	
	//外包人员流动情况统计 定时时间(每天凌晨3点)
	@CronTimeTask(description="外包人员流动情况统计定时任务",cron="0 0 4 * * ?" ,parameters={"currectDate,String,null"})
	public void personFlowTimingQuit(String currectDate){

		logger.info(CommonUtils.vaildLog("外包人员流动情况统记,currectDate="+currectDate));
		String currect=StringUtils.isNotEmpty(currectDate)&&!StringUtils.equals("null", currectDate)?currectDate: UTDate.getCurDate() ;
		logger.info(CommonUtils.vaildLog("currect="+currect));
		//统计每天 部门，供应商中 当前人数， 入场人数  退场人数+离职人数
		List<Map> infos=new ArrayList<Map>();
		List<UTMap<String, Object>> currOrg= 	personStatisticsDao.getCurrectPersonByOrg(currect);
		List<UTMap<String, Object>> currSupplier= 	personStatisticsDao.getCurrectPersonBySupplier(currect);
		if(currSupplier!=null && currSupplier.size()>1){
			currOrg.addAll(currSupplier);
		}
		for (UTMap<String, Object> utMap : currOrg) {
			utMap.put("optionDate", currect);
			infos.add(utMap);
		}
		
		if(infos!=null && infos.size()>1){
			//删除当天的记录
			Map<String, Object> param=new HashMap<String, Object>();
			param.put("optionDate", currect);
			personStatisticsDao.delete(param);
			//重新添加
			personStatisticsDao.adds(infos);
		}
	}
	public void addPersonFlowTimingQuit(String currectDate,String orgId,String supplierId){

		logger.info(CommonUtils.vaildLog("外包人员流动情况统记,currectDate="+currectDate));
		String currect=StringUtils.isNotEmpty(currectDate)&&!StringUtils.equals("null", currectDate)?currectDate: UTDate.getCurDate() ;
		logger.info(CommonUtils.vaildLog("currect="+currect));
		//统计每天 部门，供应商中 当前人数， 入场人数  退场人数+离职人数
		List<Map> infos=new ArrayList<Map>();
		List<UTMap<String, Object>> currOrg= 	personStatisticsDao.getCurrectPersonByOrg(currect);
		List<UTMap<String, Object>> currSupplier= 	personStatisticsDao.getCurrectPersonBySupplier(currect);

		if(currSupplier!=null && currSupplier.size()>1){
			currOrg.addAll(currSupplier);
		}
		for (UTMap<String, Object> utMap : currOrg) {
			String itemId=utMap.get("itemId").toString();
			if(StringUtils.equals(itemId,orgId)||
				StringUtils.equals(itemId, supplierId)){
				utMap.put("enterCount",Integer.valueOf(utMap.get("enterCount").toString())+1);
			}
			utMap.put("optionDate", currect);
			infos.add(utMap);
		}
		
		if(infos!=null && infos.size()>1){
			//删除当天的记录
			Map<String, Object> param=new HashMap<String, Object>();
			param.put("optionDate", currect);
			personStatisticsDao.delete(param);
			//重新添加
			personStatisticsDao.adds(infos);
		}
	}
	//获取时间区间类的每一天
	public void personFlowEveryDayResetting(String currectDate) {   
		personStatisticsDao.delete(null);
		try {
			SimpleDateFormat sdf_d = new SimpleDateFormat("yyyy-MM-dd");
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			String endDate=currectDate;
			Calendar c2 = Calendar.getInstance();
			c2.setTime(sdf_d.parse(endDate));
//			 System.out.println(c2.get(Calendar.DATE));  
			 
			String startDate="2016-06-1";
			Calendar c3 = Calendar.getInstance();
			c3.setTime(sdf_d.parse(startDate));
//			 System.out.println(c3.get(Calendar.DATE));  
			while(true){
				 if (c2.compareTo(c3)!=1) {
					break;
				}
				else{
					personFlowTimingQuit(sdf_d.format(c3.getTime()));
//					System.out.println(df.format(c3.getTime()));
					c3.set(Calendar.DATE,c3.get(Calendar.DATE)+1);
				}
			}
		} catch (ParseException e) {
			logger.error("Exception",e);
		}
	}
	
//	
//	public static void main(String[] args) {
//		String string=UTDate.getBeforDay(UTDate.getDate(UTDate.getCurDate(),UTDate.DATE_FORMAT));
//		System.out.println(string);
//	}
}
