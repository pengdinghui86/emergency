package com.esc.oms.outsource.attendance.dao.impl;

import com.esc.oms.outsource.attendance.dao.IUserConfigDao;
import com.esc.oms.util.RoleUtils;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 用户考勤规则配置dao
 * @author owner
 *
 */
@Repository
public class UserConfigDaoImpl extends BaseOptionDao implements IUserConfigDao{

	@Override
	public String getTableName() {
		return "attendance_user_config";
	}
	
	public List<UTMap<String, Object>> getListMaps(Map param) {
		String sql=getSearchSql(param);
		return super.getListBySql(sql, null);
	}

	public void getPageInfo(UTPageBean pageBean,Map param){
		String sql=getSearchSql(param);
		 super.getPageListMapBySql(sql,pageBean, null);
	}
	
	/**
	 * 查询指定日期需要考勤的考勤规则
	 * @param date
	 * @return
	 */
	public List<UTMap<String, Object>> getAttUserConfig(Date date) {
		Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int w = cal.get(Calendar.DAY_OF_WEEK);
        String dateStr = UTDate.dateToDateString(date);
		StringBuilder sql = new StringBuilder();
		sql.append(" select * from attendance_user_config where 1 = 1 ");
		sql.append(" and attendanceDateType = 1 ");//考勤方式:(1.确定时间，2.不确定时间)
//		sql.append(" and date = '"+UTDate.dateToDateString(date)+"' ");//考勤日期
		sql.append(" and attendanceDate like '%"+w+"%' ");//周几（2,3,4,5,6）
		sql.append(" and beginDate <= '"+dateStr+"' ");
		sql.append(" and ( endDate is null || (endDate is not null and endDate  >= '"+dateStr+"') ) ");
		return super.getListBySql(sql.toString(), null);
	}
	
	/**
	 * 查询确认时间的考勤规则数据
	 * @param date
	 * @return
	 */
	public List<UTMap<String, Object>> getAttUserConfigByAttendanceDateType(Date date) {
//		Calendar cal = Calendar.getInstance();
//        cal.setTime(date);
//        int w = cal.get(Calendar.DAY_OF_WEEK);
        String dateStr = UTDate.dateToDateString(date);
		StringBuilder sql = new StringBuilder();
		sql.append(" select * from attendance_user_config where 1 = 1 ");
		sql.append(" and attendanceDateType = 1 ");//考勤方式:(1.确定时间，2.不确定时间)
//		sql.append(" and date = '"+UTDate.dateToDateString(date)+"' ");//考勤日期
//		sql.append(" and LENGTH(attendanceDate) = 13 ");//周一到周日都要考勤，根据长度来判断（5,6,2,3,4,7,1）
		sql.append(" and beginDate <= '"+dateStr+"' ");
		sql.append(" and ( endDate is null || (endDate is not null and endDate  >= '"+dateStr+"') )");
		return super.getListBySql(sql.toString(), null);
	}

	@Override
	public List<UTMap<String, Object>> getUserConfigs(Map<String, Object> params) {
		StringBuilder sql = new StringBuilder();
		sql.append("select * from attendance_user_config where 1=1 ");
		if(params != null){
			String userIds = (String) params.get("userIds");
			if(StringUtils.isNotEmpty(userIds)){
				sql.append(" and userId in("+userIds+")");

			}
		}
		return this.getListBySql(sql.toString());
	}

	/**
	 * 查询确认时间，并且考勤时间点为周一到周日的考勤规则数据
	 * @param date
	 * @return
	 */
	public List<UTMap<String, Object>> getAttUserConfigByAttendanceDate(Date date) {
//		Calendar cal = Calendar.getInstance();
//        cal.setTime(date);
//        int w = cal.get(Calendar.DAY_OF_WEEK);
        String dateStr = UTDate.dateToDateString(date);
		StringBuilder sql = new StringBuilder();
		sql.append(" select * from attendance_user_config where 1 = 1 ");
		sql.append(" and attendanceDateType = 1 ");//考勤方式:(1.确定时间，2.不确定时间)
//		sql.append(" and date = '"+UTDate.dateToDateString(date)+"' ");//考勤日期
		sql.append(" and LENGTH(attendanceDate) = 13 ");//周一到周日都要考勤，根据长度来判断（5,6,2,3,4,7,1）
		sql.append(" and beginDate <= '"+dateStr+"' ");
		sql.append(" and ( endDate is null || (endDate is not null and endDate  >= '"+dateStr+"') )");
		return super.getListBySql(sql.toString(), null);
	}
	
	/**
	 * 根据用户编号查询考勤规则
	 * @param userId
	 * @return
	 */
	public UTMap<String, Object> getUserConfigByUserId(String userId){
		String sql = " select * from attendance_user_config where userId = ? ";
		List<UTMap<String, Object>>  list = this.getListBySql(sql, userId);
		if(list != null && list.size() > 0){
			return list.get(0);
		}
		return null;
	}

	@Override
	public UTMap<String, Object> getUserConfigInfoByUserId(String presentDate,String userId) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select auc.*,pr.projectId,se.supplierId,opl.departIdTwo from attendance_user_config auc ");
		sql.append(" LEFT JOIN supplier_emp se ON se.userId = auc.userId ");
		sql.append(" LEFT JOIN outsource_person_list opl on auc.userId = opl.userId ");
		sql.append(" LEFT JOIN project_res pr ON pr.memberId = opl.userId and '");
		sql.append(presentDate).append("'>= pr.beginDate and '").append(presentDate).append("'<=pr.endDate ");
		sql.append("where auc.userId = '"+userId+"'");
		List<UTMap<String, Object>>  list = this.getListBySql(sql.toString());
		if(list != null && list.size() > 0){
			return list.get(0);
		}
		return null;
	}

	/**
	 * 根据联合考勤id删除用户考勤规则
	 * @param CoalitionId
	 */
	public void deleteByCoalitionId(String coalitionId){
		if(StringUtils.isEmpty(coalitionId)){
			return;
		}
		String sql = " delete from attendance_user_config where coalitionId = ? ";
		this.executeUpdate(sql, coalitionId);
	}

	private String getSearchSql(Map<String, Object> param){
		Map<String, String> p=UTMap.mapObjToString(param);
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT auc.*, sbi.name as supplierName, CONCAT(su.name,'/',su.code) as userName, acc.name as coalitionName from attendance_user_config auc ");
		sql.append(" left join supplier_base_info sbi on auc.supplierId = sbi.id ");
		sql.append(" left join sys_user su on auc.userId = su.id ");
		sql.append(" left join attendance_coalition_config acc on auc.coalitionId = acc.id ");
		sql.append(" WHERE 1=1 ");
				
		String id=p.get("id"); 
		String userName = p.get("userName");//结束日期
		String supplierName = p.get("supplierName");//供应商名称
		String attendanceDateType = p.get("attendanceDateType");//考勤方式
		
		if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR,RoleUtils.SUPPLIER_ADMINISTRATOR)){
			if(EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SUPPLIER_LEADERS)){//供应商负责人查看本供应商下用户的考勤配置
				sql.append(" and auc.supplierId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId()+"' ");
			}else{
				sql.append(" and auc.userId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' ");//外包用户只能查询自己的数据
			}
		}
		if (StringUtils.isNotEmpty(id)) {
			sql.append(" and auc.id='"+id+"'");
		}
		
		if (StringUtils.isNotEmpty(userName)) {
//			sql.append(" and su.name like '%"+userName+"%'");
//			sql.append(" and (su.name like '%"+userName+"%' or su.code like '%"+userName+"%' )");
			sql.append(" and CONCAT(su.name,'/',su.code) like '%"+userName+"%' ");
		}
		
		if (StringUtils.isNotEmpty(supplierName)) {
			sql.append(" and sbi.name like '%"+supplierName+"%'");
		}
		
		if (StringUtils.isNotEmpty(attendanceDateType)) {
			sql.append(" and auc.attendanceDateType='"+attendanceDateType+"'");
		}
//		if (StringUtils.isNotEmpty(beginDate) && StringUtils.isNotEmpty(endDate)) {
//			sql.append(" and festivalDate BETWEEN '"+beginDate+"' AND '"+endDate+"'  ");
//		}

		sql.append(" ORDER BY createTime desc ");
		
		return sql.toString();
	}

	

	
}
