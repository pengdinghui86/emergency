package com.esc.oms.outsource.attendance.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.attendance.dao.IAttendanceStatisticsTimeDao;
import com.esc.oms.util.CommonUtils;

/**
 * 不确定时间考勤考勤统计-按工时dao
 * @author owner
 *
 */
@Repository
public class AttendanceStatisticsTimeDaoImpl extends BaseOptionDao implements IAttendanceStatisticsTimeDao{

	@Override
	public String getTableName() {
		return "attendance_statistics_time";
	}
	
	public List<UTMap<String, Object>> getListMaps(Map param) {
		String sql=getSearchSql(param);
		return super.getListBySql(sql, null);
	}
	
	/**
	 * 点击异常率查询详情数据接口
	 * @param param
	 * @return
	 */
	public void getDetail(UTPageBean pageBean,Map param) {
		String sql=getDetailSql(param);
		super.getPageListMapBySql(sql,pageBean, null);
	}
	
	/**
	 * 点击异常率查询详情数据接口
	 * @param param
	 * @return
	 */
	public List<UTMap<String, Object>> getDetail(Map param){
		String sql=getDetailSql(param);
		return super.getListBySql(sql, null);
	}

	public void getPageInfo(UTPageBean pageBean,Map param){
		String sql=getSearchSql(param);
		 super.getPageListMapBySql(sql,pageBean, null);
	}
	
	/**
	 * 删除指定年月的统计数据
	 * @param yearMonth
	 */
	public void deleteByDate(String yearMonth){
		String sql=" delete from attendance_statistics_time where yearMonth = ? ";
		this.executeUpdate(sql, yearMonth);
	}

	private String getSearchSql(Map<String, Object> param){
		Map<String, String> p=UTMap.mapObjToString(param);
		StringBuilder sql = new StringBuilder();
		
		sql.append(" select CONCAT(su1.name,'/',su1.code) as userName,sbi.name as supplierName, so1.longName as orgName ,attsc.* from attendance_statistics_time attsc ");
		sql.append(" left join sys_user su1 on attsc.userId = su1.id ");
		sql.append(" left join supplier_base_info sbi on attsc.supplierId = sbi.id ");
		sql.append(" left join sys_org so1 on attsc.departId = so1.id ");
		sql.append(" where attsc.coalitionId is null ");//不查询联合考勤的数据
				
		String id=p.get("id"); 
		String year = p.get("year");//年
		String month = p.get("month");//月
		String orgName = p.get("orgName");//部门
		String supplierName = p.get("supplierName");//供应商
		String userName = p.get("userName");//姓名
		String userId = p.get("userId");//用户id
		String beginDate = p.get("beginDate");//查询开始日期
		String endDate = p.get("endDate");//查询结束日期
		
		if (StringUtils.isNotEmpty(id)) {
			sql.append(" and attsc.id='"+id+"'");
		}
		
		if (StringUtils.isNotEmpty(year)) {
			sql.append(" and attsc.year='"+year+"'");
		}
		
		if (StringUtils.isNotEmpty(month)) {
			sql.append(" and attsc.month='"+month+"'");
		}
		
		
		if (StringUtils.isNotEmpty(userId)) {
			sql.append(" and attsc.userId='"+userId+"'");
		}
		
		if (StringUtils.isNotEmpty(orgName)) {
			sql.append(" and so1.longName like '%"+orgName+"%'");
		}
		
		if (StringUtils.isNotEmpty(supplierName)) {
			sql.append(" and sbi.name like '%"+supplierName+"%'");
		}
		
		if (StringUtils.isNotEmpty(beginDate) && StringUtils.isNotEmpty(endDate)) {
			sql.append(" and str_to_date(attsc.yearMonth, '%Y-%m') BETWEEN str_to_date('"+beginDate+"', '%Y-%m')  AND str_to_date('"+endDate+"', '%Y-%m')  ");
		}else if (StringUtils.isNotEmpty(beginDate) ) {
			sql.append(" and str_to_date(attsc.yearMonth, '%Y-%m') >= str_to_date('"+beginDate+"', '%Y-%m')  ");
		}else if (StringUtils.isNotEmpty(endDate)) {
			sql.append(" and str_to_date(attsc.yearMonth, '%Y-%m') <= str_to_date('"+endDate+"', '%Y-%m')  ");
		}
		
//		if (StringUtils.isNotEmpty(userName)) {
//			sql.append(" and su1.name like '%"+userName+"%'");
//		}
		if (StringUtils.isNotEmpty(userName)) {
//			sql.append(" and (su1.name like '%"+userName+"%' or su1.code like '%"+userName+"%' )");
			sql.append(" and CONCAT(su1.name,'/',su1.code) like '%"+userName+"%' ");
		}
		
		
		sql.append(" ORDER BY percentage*1 desc,attsc.userId ");
		
		return sql.toString();
	}
	

	private String getDetailSql(Map<String, Object> param){
		Map<String, String> p=UTMap.mapObjToString(param);
		StringBuilder sql = new StringBuilder();
		String id=p.get("id"); 
		String year = p.get("year");//年
		String month = p.get("month");//月
		String orgName = p.get("orgName");//部门
		String orgId = p.get("orgId");//部门id
		String supplierName = p.get("supplierName");//供应商
		String supplierId = p.get("supplierId");//供应商Id
		String userName = p.get("userName");//姓名
		String userId = p.get("userId");//用户id
		String yearMonth = p.get("yearMonth");//考勤日期
//		String endDate = p.get("endDate");//查询结束日期
		String name = p.get("name");//姓名
		
		sql.append(" select so1.longName orgName,sbi.name supplierName,IFNULL(acc.name, CONCAT(su1.name,'/',su1.code)) as name, ");
		sql.append(" tb.attNeedTime,tb.sumAttTime,if((tb.attNeedTime - tb.sumAttTime) > 0,tb.attNeedTime - tb.sumAttTime,0) attExTime, ");
		sql.append(" if((tb.attNeedTime - tb.sumAttTime) > 0,CONCAT(ROUND(((tb.attNeedTime - tb.sumAttTime)/tb.attNeedTime*100)),'%'),'0%') sumPercentage, ");
//		if (StringUtils.isNotEmpty(beginDate)) {
//			sql.append(" '"+beginDate+"' beginDate, ");
//		}
//		if (StringUtils.isNotEmpty(endDate)) {
//			sql.append(" '"+endDate+"' endDate, ");
//		}
		sql.append(" tb.userIdOrCoalitionId,tb.yearMonth from ( ");
		sql.append(" select attsc.*,sum(attsc.attTime) sumAttTime,IFNULL(attsc.coalitionId, attsc.userId) userIdOrCoalitionId from attendance_statistics_time attsc ");
		sql.append(" where attsc.yearMonth = '"+yearMonth+"' ");
//		if (StringUtils.isNotEmpty(beginDate) && StringUtils.isNotEmpty(endDate)) {
//			sql.append(" and str_to_date(attsc.yearMonth, '%Y-%m') BETWEEN str_to_date('"+beginDate+"', '%Y-%m') AND str_to_date('"+endDate+"', '%Y-%m')  ");
//		}else if (StringUtils.isNotEmpty(beginDate) ) {
//			sql.append(" and str_to_date(attsc.yearMonth, '%Y-%m') >= str_to_date('"+beginDate+"', '%Y-%m') ");
//		}else if (StringUtils.isNotEmpty(endDate)) {
//			sql.append(" and str_to_date(attsc.yearMonth, '%Y-%m') <= str_to_date('"+endDate+"', '%Y-%m')  ");
//		}
		sql.append(" group by userIdOrCoalitionId ");
		sql.append(" ) tb ");
		sql.append(" left join sys_user su1 on tb.userId = su1.id ");
		sql.append(" left join sys_org so1 on tb.departId = so1.id ");
		sql.append(" left join supplier_base_info sbi on tb.supplierId = sbi.id ");
		sql.append(" left join attendance_coalition_config acc on tb.coalitionId = acc.id ");
		sql.append(" where 1=1 ");
		
		if (StringUtils.isNotEmpty(id)) {
			sql.append(" and tb.id='"+id+"'");
		}
		
		if (StringUtils.isNotEmpty(name)) {
//			sql.append(" and CONCAT(su1.name,'/',su1.code) like '%"+name+"%' or acc.name like '%"+name+"%'");
			sql.append(" and IFNULL(acc.name, CONCAT(su1.name,'/',su1.code)) like '%"+name+"%'");
		}
		
		if (StringUtils.isNotEmpty(year)) {
			sql.append(" and tb.year='"+year+"'");
		}
		
		if (StringUtils.isNotEmpty(month)) {
			sql.append(" and tb.month='"+month+"'");
		}
		
		
		if (StringUtils.isNotEmpty(userId)) {
			sql.append(" and tb.userId='"+userId+"'");
		}
		
		if (StringUtils.isNotEmpty(orgId)) {
			sql.append(" and so1.id = '"+orgId+"'");
		}
		
		if (StringUtils.isNotEmpty(orgName)) {
			sql.append(" and so1.longName like '%"+orgName+"%'");
		}
		
		if (StringUtils.isNotEmpty(supplierId)) {
			sql.append(" and sbi.id = '"+supplierId+"'");
		}
		
		if (StringUtils.isNotEmpty(supplierName)) {
			sql.append(" and sbi.name like '%"+supplierName+"%'");
		}
		
//		if (StringUtils.isNotEmpty(beginDate) && StringUtils.isNotEmpty(endDate)) {
//			sql.append(" and tb.yearMonth BETWEEN '"+beginDate+"' AND '"+endDate+"'  ");
//		}else if (StringUtils.isNotEmpty(beginDate) ) {
//			sql.append(" and tb.yearMonth >= '"+beginDate+"' ");
//		}else if (StringUtils.isNotEmpty(endDate)) {
//			sql.append(" and tb.yearMonth <='"+endDate+"'  ");
//		}
//		
//		if (StringUtils.isNotEmpty(userName)) {
//			sql.append(" and su1.name like '%"+userName+"%'");
//		}
		if (StringUtils.isNotEmpty(userName)) {
//			sql.append(" and (su1.name like '%"+userName+"%' or su1.code like '%"+userName+"%' )");
			sql.append(" and CONCAT(su1.name,'/',su1.code) like '%"+userName+"%' ");
		}
		
		
		sql.append(" order by  sumPercentage*1 desc,tb.userIdOrCoalitionId ");
		
		return sql.toString();
	}
	
	/**
	 * 运维联合考勤统计
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllCoalitionOperations(Map param){
		return this.getListBySql(getCoalitionOperationsSql(param), null);
	}
	
	/**
	 * 运维联合考勤统计
	 * @param pageBean
	 * @param param
	 */
	public void getCoalitionOperations(UTPageBean pageBean,Map param){
		 super.getPageListMapBySql(getCoalitionOperationsSql(param),pageBean, null);
	}
	
	/**
	 * 运维联合考勤统计sql
	 * @param param
	 * @return
	 */
	private String getCoalitionOperationsSql(Map param){
		Map<String, String> p=UTMap.mapObjToString(param);
		StringBuilder sql = new StringBuilder();
		
//		sql.append(" select attsc.coalitionId ,acc1.name as coalitionName,sbi.NAME AS supplierName,so1. NAME AS orgName ,attsc.beginDate,attsc.endDate,max(attsc.attDays) attDays ,attsc.attNeedDays ,max(attsc.attNormalDays) attNormalDays,max(attsc.attExDays) attExDays,attsc.percentage  from attendance_statistics_count attsc ");
//		sql.append(" LEFT JOIN attendance_coalition_config acc1 ON attsc.coalitionid = acc1.id ");
//		sql.append(" LEFT JOIN supplier_base_info sbi ON attsc.supplierId = sbi.id ");
//		sql.append(" LEFT JOIN sys_org so1 ON attsc.departId = so1.id ");
//		sql.append(" where attsc.coalitionId is not null ");//只查询联合考勤的数据
		
		sql.append(" select attsc.coalitionId ,acc1.name as coalitionName,sbi. NAME AS supplierName,so1.longName AS orgName ,attsc.beginDate,attsc.endDate ,attsc.attNeedTime ,sum(attsc.attTime) attTime, ");
		sql.append(" if((attsc.attNeedTime - sum(attsc.attTime)) > 0,attsc.attNeedTime - sum(attsc.attTime),'0') as attExTime, ");
		sql.append(" if((attsc.attNeedTime - sum(attsc.attTime)) > 0,CONCAT(ROUND(((attsc.attNeedTime - sum(attsc.attTime))/attsc.attNeedTime*100)),'%'),'0%') as percentage ");
		sql.append(" from attendance_statistics_time attsc ");
		sql.append(" LEFT JOIN attendance_coalition_config acc1 ON attsc.coalitionid = acc1.id ");
		sql.append(" LEFT JOIN supplier_base_info sbi ON attsc.supplierId = sbi.id ");
		sql.append(" LEFT JOIN sys_org so1 ON attsc.departId = so1.id ");
		sql.append(" where attsc.coalitionId is not null and acc1.id is not null");//只查询联合考勤的数据
//		sql.append(" group by attsc.coalitionId ");
		
		
		String id=p.get("id"); 
		String year = p.get("year");//年
		String month = p.get("month");//月
		String orgName = p.get("orgName");//部门
		String supplierName = p.get("supplierName");//供应商
		String coalitionName = p.get("coalitionName");//联合考勤名称
		String userId = p.get("userId");//用户id
		String beginDate = p.get("beginDate");//查询开始日期
		String endDate = p.get("endDate");//查询结束日期
		
		if (StringUtils.isNotEmpty(id)) {
			sql.append(" and attsc.id='"+id+"'");
		}
		
		if (StringUtils.isNotEmpty(year)) {
			sql.append(" and attsc.year='"+year+"'");
		}
		
		if (StringUtils.isNotEmpty(month)) {
			sql.append(" and attsc.month='"+month+"'");
		}
		
		if (StringUtils.isNotEmpty(userId)) {
			sql.append(" and attsc.userId='"+userId+"'");
		}
		
		if (StringUtils.isNotEmpty(coalitionName)) {
			sql.append(" and acc1.name like '%"+coalitionName+"%'");
		}
		
		if (StringUtils.isNotEmpty(orgName)) {
			sql.append(" and so1.longName like '%"+orgName+"%'");
		}
		
		if (StringUtils.isNotEmpty(supplierName)) {
			sql.append(" and sbi.name like '%"+supplierName+"%'");
		}
		
		if (StringUtils.isNotEmpty(beginDate) && StringUtils.isNotEmpty(endDate)) {
			sql.append(" and str_to_date(attsc.yearMonth, '%Y-%m') BETWEEN str_to_date('"+beginDate+"', '%Y-%m') AND str_to_date('"+endDate+"', '%Y-%m')  ");
		}else if (StringUtils.isNotEmpty(beginDate) ) {
			sql.append(" and str_to_date(attsc.yearMonth, '%Y-%m') >= str_to_date('"+beginDate+"', '%Y-%m') ");
		}else if (StringUtils.isNotEmpty(endDate)) {
			sql.append(" and str_to_date(attsc.yearMonth, '%Y-%m') <= str_to_date('"+endDate+"', '%Y-%m')  ");
		}
		
//		if (StringUtils.isNotEmpty(userName)) {
//			sql.append(" and su1.name like '%"+userName+"%'");
//		}
//		if (StringUtils.isNotEmpty(userName)) {
//			sql.append(" and (su1.name like '%"+userName+"%' or su1.code like '%"+userName+"%' )");
//		}
		
		sql.append(" group by attsc.coalitionId ");
		sql.append(" ORDER BY percentage*1 desc  ");
		
		return sql.toString();
	}

	/**
	 * 初始化指定日期范围内的不确定考勤，按考勤次数的考勤统计数据
	 * @param beginDate
	 * @param endDate
	 */
	public void initDate(String beginDate, String endDate,int year,int month,int quarter,String yearMonth){
		StringBuilder sql = new StringBuilder();
		sql.append(" insert into attendance_statistics_time  ");
		sql.append(" select tb.*, ");
		sql.append(" if((tb.attNeedTime - tb.attTime) > 0,(tb.attNeedTime - tb.attTime),0) as attExTime, ");
		sql.append(" if((tb.attNeedTime - tb.attTime) > 0,CONCAT(ROUND(((tb.attNeedTime - tb.attTime)/tb.attNeedTime*100)),'%'),'0%') as percentage  ");
		sql.append(" from ( ");
		sql.append(" select att.id,att.userId,att.supplierId,att.departId,att.coalitionId,'"+year+"' as 'year','"+month+"' as 'month','"+yearMonth+"' as 'yearMonth','"+quarter+"' as 'quarter','"+beginDate+"' as 'beginDate','"+endDate+"' as 'endDate' , ");
		sql.append(" auc.attendancSum as 'attNeedTime', ");
		sql.append(" ifnull(( ");
		sql.append(" select sum(att1.attHours) from attendance att1 ");
		sql.append(" where att1.date BETWEEN '"+beginDate+"' and '"+endDate+"'  ");
		sql.append(" and att1.userId = att.userId  ");
		sql.append(" and att1.attendanceDateType = 3  ");//-- 不确定时间，按工时统计
		sql.append(" and att1.dateinStyle = 0  ");
		sql.append(" and att1.dateoutStyle = 0 ");
		sql.append(" group by att1.userId ");
		sql.append(" ),0) attTime ");
		sql.append(" from attendance att ");
		sql.append(" left join attendance_user_config auc on att.userId = auc.userId ");
		sql.append(" where att.attendanceDateType = 3 ");
		sql.append(" and att.date BETWEEN '"+beginDate+"' and '"+endDate+"'  ");
		sql.append(" group by att.userId ");
		sql.append(" ) tb ");
		this.executeUpdate(sql.toString(), null);
	}

	/**
	 * 运维考勤统计（供应商）
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllSupplierOperations(Map param){
		return this.getListBySql(getSupplierOperationsSql(param), null);
	}
	
	/**
	 * 运维考勤统计（供应商）
	 * @param pageBean
	 * @param param
	 */
	public void getSupplierOperations(UTPageBean pageBean,Map param){
		 super.getPageListMapBySql(getSupplierOperationsSql(param),pageBean, null);
	}
	
	/**
	 * 运维考勤统计（供应商）维度sql
	 * @param param
	 * @return
	 */
	private String getSupplierOperationsSql(Map param){
		Map<String, String> p=UTMap.mapObjToString(param);
		StringBuilder sql = new StringBuilder();
		String yearMonth = "" ;//查询日期
		if(p.get("yearMonth") != null){
			yearMonth = p.get("yearMonth") ;//查询日期
		}
//		String endDate = "" ;//查询结束日期
//		if(p.get("endDate") != null){
//			endDate = p.get("endDate") ;//查询结束日期
//		}
		String supplierName = p.get("supplierName");//供应商
		
		sql.append(" select tb.*, ROUND(tb.exMemberNum/tb.memberNum*100) percentageInt, CONCAT(ROUND(tb.exMemberNum/tb.memberNum*100),'%') as percentage from ( ");
		sql.append(" SELECT s.NAME supplierName,s.shortName shortSupplierName, s.id supplierId, ");
		if (StringUtils.isNotEmpty(yearMonth)) {
			sql.append(" '"+yearMonth+"' yearMonth, ");
		}
//		if (StringUtils.isNotEmpty(endDate)) {
//			sql.append(" '"+endDate+"' endDate, ");
//		}
		sql.append(" (SELECT count(1) FROM( ");
		sql.append(" SELECT IFNULL(attsc.coalitionId, attsc.userId) userIdOrCoalitionId,attsc.supplierId FROM attendance_statistics_time attsc ");
		sql.append(" where 1=1 "); 
		sql.append(" and attsc.yearMonth = '"+yearMonth+"' ");
		sql.append(" GROUP BY userIdOrCoalitionId ");
		sql.append(" ) memberCount ");
		sql.append(" WHERE memberCount.supplierId = s.id ");
		sql.append(" ) memberNum,  ");//-- 考勤人数
		sql.append(" (SELECT count(1) FROM( ");
		sql.append(" SELECT IFNULL(attsc.coalitionId, attsc.userId) userIdOrCoalitionId,attsc.supplierId,attsc.attNeedTime,sum(attsc.attTime) sumAttTime FROM attendance_statistics_time attsc ");
		sql.append(" where 1=1 ");
		sql.append(" and attsc.yearMonth = '"+yearMonth+"' ");
		sql.append(" GROUP BY userIdOrCoalitionId,attsc.supplierId ");
		sql.append(" having (attNeedTime - sumAttTime) > 0 ");
		sql.append(" ) memberCount ");
		sql.append(" WHERE memberCount.supplierId = s.id ");
		sql.append(" ) exMemberNum  ");//-- 异常考勤人数
//		sql.append(" (SELECT sum(memberCount.attNeedTime) FROM( ");
//		sql.append(" SELECT attsc.attNeedTime,attsc.supplierId,IFNULL(attsc.coalitionId, attsc.userId) userIdOrCoalitionId FROM attendance_statistics_time attsc ");
//		sql.append(" where 1=1 "); 
//		sql.append(" "+CommonUtils.getDateSql(beginDate, endDate, "attsc.yearMonth")+" ");
//		sql.append(" GROUP BY userIdOrCoalitionId ");
//		sql.append(" ) memberCount ");
//		sql.append(" WHERE memberCount.supplierId = s.id ");
//		sql.append(" ) attNeedTime,  ");//-- 需考勤工时
//		sql.append(" (SELECT sum(memberCount.attTime) FROM( ");
//		sql.append(" SELECT attsc.attTime,attsc.supplierId FROM attendance_statistics_time attsc ");
//		sql.append(" where 1=1 "); 
//		sql.append(" "+CommonUtils.getDateSql(beginDate, endDate, "attsc.yearMonth")+" ");
//		sql.append(" GROUP BY attsc.userId ");
//		sql.append(" ) memberCount ");
//		sql.append(" WHERE memberCount.supplierId = s.id ");
//		sql.append(" ) attTime ");// -- 考勤工时
//		sql.append(" (SELECT sum(memberCount.attExTime) FROM( ");
//		sql.append(" SELECT attsc.attExTime,attsc.supplierId FROM attendance_statistics_time attsc ");
//		sql.append(" where 1=1 "); 
//		sql.append(" "+CommonUtils.getDateSql(beginDate, endDate, "attsc.yearMonth")+" ");
//		sql.append(" GROUP BY attsc.userId ");
//		sql.append(" ) memberCount ");
//		sql.append(" WHERE memberCount.supplierId = s.id ");
//		sql.append(" ) attExTime  ");//-- 异常工时
		sql.append(" FROM supplier_base_info s ");
		sql.append(" WHERE IFNULL(s.deleteFlag, '0') = '0' ");
		sql.append(" ) tb ");
		sql.append(" where tb.memberNum > 0 ");
		if (StringUtils.isNotEmpty(supplierName)) {
			sql.append(" and tb.supplierName like '%"+supplierName+"%' ");
		}
		sql.append(" order by percentage*1 desc,tb.supplierId ");
		
		
		return sql.toString();
	}
	
	
	/**
	 * 运维考勤统计（部门）
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllOrgOperations(Map param){
		return this.getListBySql(getOrgOperationsSql(param), null);
	}
	
	/**
	 * 运维考勤统计（部门）
	 * @param pageBean
	 * @param param
	 */
	public void getOrgOperations(UTPageBean pageBean,Map param){
		 super.getPageListMapBySql(getOrgOperationsSql(param),pageBean, null);
	}
	
	/**
	 * 运维考勤统计（部门）维度sql
	 * @param param
	 * @return
	 */
	private String getOrgOperationsSql(Map param){
		Map<String, String> p=UTMap.mapObjToString(param);
		StringBuilder sql = new StringBuilder();
		String yearMonth = "" ;//查询日期
		if(p.get("yearMonth") != null){
			yearMonth = p.get("yearMonth") ;//查询日期
		}
//		String endDate = "" ;//查询结束日期
//		if(p.get("endDate") != null){
//			endDate = p.get("endDate") ;//查询结束日期
//		}
		String orgName = p.get("orgName");//部门
		
		sql.append(" select tb.*,ROUND(tb.exMemberNum/tb.memberNum*100) percentageInt, CONCAT(ROUND(tb.exMemberNum/tb.memberNum*100),'%') as percentage from ( ");
		sql.append(" SELECT s.longName orgName,s.name shortOrgName, s.id orgId, ");
		if (StringUtils.isNotEmpty(yearMonth)) {
			sql.append(" '"+yearMonth+"' yearMonth, ");
		}
//		if (StringUtils.isNotEmpty(endDate)) {
//			sql.append(" '"+endDate+"' endDate, ");
//		}
		sql.append(" (SELECT count(1) FROM( ");
		sql.append(" SELECT IFNULL(attsc.coalitionId, attsc.userId) userIdOrCoalitionId,attsc.departId FROM attendance_statistics_time attsc ");
		sql.append(" where 1=1 "); 
		sql.append(" and attsc.yearMonth = '"+yearMonth+"' ");
		sql.append(" GROUP BY userIdOrCoalitionId ");
		sql.append(" ) memberCount ");
		sql.append(" WHERE memberCount.departId = s.id ");
		sql.append(" ) memberNum,  ");//-- 考勤人数
		sql.append(" (SELECT count(1) FROM( ");
		sql.append(" SELECT IFNULL(attsc.coalitionId, attsc.userId) userIdOrCoalitionId,attsc.departId,attsc.attNeedTime,sum(attsc.attTime) sumAttTime FROM attendance_statistics_time attsc ");
		sql.append(" where  1=1 ");
		sql.append(" and attsc.yearMonth = '"+yearMonth+"' ");
		sql.append(" GROUP BY userIdOrCoalitionId,attsc.departId ");
		sql.append(" having (attNeedTime - sumAttTime) > 0 ");
		sql.append(" ) memberCount ");
		sql.append(" WHERE memberCount.departId = s.id ");
		sql.append(" ) exMemberNum  ");//-- 异常考勤人数
		
//		sql.append(" (SELECT sum(memberCount.attNeedTime) FROM( ");
//		sql.append(" SELECT attsc.attNeedTime,attsc.departId,IFNULL(attsc.coalitionId, attsc.userId) userIdOrCoalitionId FROM attendance_statistics_time attsc ");
//		sql.append(" where 1=1 "); 
//		sql.append(" "+CommonUtils.getDateSql(beginDate, endDate, "attsc.yearMonth")+" ");
//		sql.append(" GROUP BY userIdOrCoalitionId ");
//		sql.append(" ) memberCount ");
//		sql.append(" WHERE memberCount.departId = s.id ");
//		sql.append(" ) attNeedTime,  ");//-- 需考勤工时
//		sql.append(" (SELECT sum(memberCount.attTime) FROM( ");
//		sql.append(" SELECT attsc.attTime,attsc.departId FROM attendance_statistics_time attsc ");
//		sql.append(" where 1=1 "); 
//		sql.append(" "+CommonUtils.getDateSql(beginDate, endDate, "attsc.yearMonth")+" ");
//		sql.append(" GROUP BY attsc.userId ");
//		sql.append(" ) memberCount ");
//		sql.append(" WHERE memberCount.departId = s.id ");
//		sql.append(" ) attTime ");// -- 考勤工时
//		sql.append(" (SELECT sum(memberCount.attExTime) FROM( ");
//		sql.append(" SELECT attsc.attExTime,attsc.departId,IFNULL(attsc.coalitionId, attsc.userId) userIdOrCoalitionId FROM attendance_statistics_time attsc ");
//		sql.append(" where 1=1 "); 
//		sql.append(" "+CommonUtils.getDateSql(beginDate, endDate, "attsc.yearMonth")+" ");
//		sql.append(" GROUP BY userIdOrCoalitionId ");
//		sql.append(" ) memberCount ");
//		sql.append(" WHERE memberCount.departId = s.id ");
//		sql.append(" ) attExTime  ");//-- 异常工时
		sql.append(" FROM sys_org s ");
		sql.append(" WHERE s.state = 1 ");
		sql.append(" ) tb ");
		sql.append(" where tb.memberNum > 0 ");
		if (StringUtils.isNotEmpty(orgName)) {
			sql.append(" and tb.orgName like '%"+orgName+"%' ");
		}
		sql.append(" order by percentage*1 desc,tb.orgId ");
		
		
		return sql.toString();
	}
	
	
	

	
}
