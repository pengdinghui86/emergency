package com.esc.oms.asset.software.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTListResult;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.asset.software.service.IAssetSoftwareService;
import com.esc.oms.asset.software.service.ISoftCategoryService;
import com.esc.oms.util.CommonUtils;
@Controller
@RequestMapping("softCategory")
public class SoftCategoryController extends BaseOptionController {


	@Resource
	private ISoftCategoryService softCategoryService; 
	
//	@Resource
//	private IAssetPhysicalService assetPhysicalService;
	
	@Override
	public IBaseOptionService optionService() {
		return softCategoryService;
	}
	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			softCategoryService.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	@RequestMapping(value="getAllList")
	@ResponseBody
	public UTListResult getAllList(@RequestParam  Map<String, Object> param){
		UTListResult result = new UTListResult();
		try{
			List<UTMap<String, Object>> list = softCategoryService.getListMaps(param);
			result.setRows(list);
			result.setTotal(list.size());
		}catch(Exception e){
			logger.error("Exception", e);
		}
		return result;
	}
	
	@RequestMapping(value="getListCategory")
	@ResponseBody
	public UTListResult getListCategory(@RequestParam  Map<String, Object> params) {
		UTListResult result = new UTListResult();
		try{
			List<UTMap<String, Object>> list = softCategoryService.getListCategory(params);
			result.setRows(list);
			result.setTotal(list.size());
		}catch(Exception e){
			logger.error("Exception", e);
		}
		return result;
	}
	

	@RequestMapping(value="getCategoryByType")
	@ResponseBody
	public UTListResult getCategoryByType(@RequestParam  Map<String, Object> params) {
		UTListResult result = new UTListResult();
		try{
			String type=(String)params.get("type");
			List<UTMap<String, Object>> list = softCategoryService.getCategoryByType(type);
			result.setRows(list);
			result.setTotal(list.size());
		}catch(Exception e){
			logger.error("Exception", e);
		}
		return result;
	}
	
	
    @RequestMapping(value="/saveOrUpdate",method=RequestMethod.POST)  
    @ResponseBody
    public String saveorupdate(@RequestBody Map<String,Object> map){
    	boolean flag = false;
    	boolean propertyFlag = false;
    	String name = String.valueOf(map.get("name"));
    	String id = String.valueOf(map.get("id"));
    	try{
	    	if(map.get("id") == null){
	    		Map param = new HashMap();
	    		param.put("name", name);
	    		if(softCategoryService.isExist(param)){
	    			throw new EscServiceException("软件类别名称已经存在！");
	    		}
	    		flag = softCategoryService.add(map);
	    		/*List<Map<String, Object>> propertyList = (List<Map<String, Object>>) map.get("propertyList");
	    		if(flag && (null != propertyList)){
	    			for (Map<String, Object> utMap : propertyList) {
	    				utMap.put("categoryId", map.get("id"));
	    				propertyFlag = softCategoryService.addProperty(utMap);
	    				if(propertyFlag && (null != utMap)){
	    					List<Map<String, Object>> propertyValueList = (List<Map<String, Object>>) utMap.get("propertyValueList");
	    					if(null != propertyValueList){
	    						for (Map<String, Object> propertyValue : propertyValueList) {
	    							propertyValue.put("categoryId", utMap.get("id"));
	    							softCategoryService.addPropertyOption(propertyValue);
	    						}
	    					}
	    				}
					}
	    		}*/
	    	}else{
	    		if(StringUtils.isNotEmpty(name)){
	    			List<UTMap<String,Object>> list = softCategoryService.getCategoryByNameAndId(name, id);
	    			if(list !=null && list.size() > 0){
	    				if(list.size() > 1){
		    				throw new EscServiceException("软件类别名称已经存在！");
		    			}else{
		    				String oldId = (String) list.get(0).get("id");
							if(!StringUtils.equals(id, oldId)) {
								throw new EscServiceException("软件类别名称已经存在！");
							}
		    			}
	    			}
	    		}
	    		flag = softCategoryService.updateById(map);
	    		/*List<Map<String, Object>> propertyList = (List<Map<String, Object>>) map.get("propertyList");
	    		if(flag && (null != propertyList)){
	    			softCategoryService.deleteProperty((String)map.get("id"));
	    			for (Map<String, Object> utMap : propertyList) {
	    				utMap.put("categoryId", map.get("id"));
	    				propertyFlag = softCategoryService.addProperty(utMap);
//	    				if(StringUtils.isNotEmpty(map.get("id").toString())){
//	    					propertyFlag = softCategoryService.updatePropertyByCategoryId(utMap);
//	    				}else{
//	    				}
	    				if(propertyFlag && (null != utMap)){
	    					softCategoryService.deleteOption((String)(utMap.get("id")));
	    					List<Map<String, Object>> propertyValueList = (List<Map<String, Object>>) utMap.get("propertyValueList");
	    					if(null != propertyValueList){
	    						for (Map<String, Object> propertyValue : propertyValueList) {
	    							propertyValue.put("categoryId", utMap.get("id"));
	    							softCategoryService.addPropertyOption(propertyValue);
	    						}
	    					}
	    				}
					}
	    		}*/
	    	}
    	}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "操作成功");
    }
    
    /**
	 * 根据id查询
	 * @param param
	 * @return
	 */
	@RequestMapping(value="getById")
	@ResponseBody
	public UTMap<String, Object> defgetById(@RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = null;
		List<UTMap<String, Object>> propertyList = null;
		List<UTMap<String, Object>> propertyValueList = null;
    	try{
    		map = optionService().getById(param.get("id").toString());
    		/*if(null != map){
    			propertyList = softCategoryService.getPropertyByCategoryId(map.get("id").toString());
    			map.put("propertyList", propertyList);
    			if(null != propertyList && propertyList.size()>0){
    				for (UTMap<String, Object> utMap : propertyList) {
    					propertyValueList = softCategoryService.getOptionByPropertyId(utMap.get("id").toString());
    					utMap.put("propertyValueList", propertyValueList);
					}
    			}
    		}*/
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return map;
	}

	
	@RequestMapping(value="/subSaveorupdate",method=RequestMethod.POST)  
	@ResponseBody
	public String subSaveorupdate(@RequestBody Map<String,Object> map){
	    boolean flag = false;
	    boolean propertyFlag = false;
	    String name = String.valueOf(map.get("name"));
	    String id = String.valueOf(map.get("id"));
	    String parentId = String.valueOf(map.get("parentId"));
	    try{
		    if(map.get("id") == null){
	    		UTMap<String,Object> subCategory = softCategoryService.getSubCategoryByNameAndCategoryId(name, parentId);
	    		if(null != subCategory){
	    			throw new EscServiceException("软件子类别名称已经存在！");
	    		}
		    		flag = softCategoryService.addSubCategory(map);
		    		/*List<Map<String, Object>> optionList = (List<Map<String, Object>>) map.get("optionList");
		    		if(flag && (null != optionList)){
		    			for (Map<String, Object> utMap : optionList) {
		    				utMap.put("subCategoryId", map.get("id"));
		    				propertyFlag = softCategoryService.addSubPropertyOption(utMap);
		    				if(propertyFlag && (null != utMap)){
		    					List<Map<String, Object>> optionValueList = (List<Map<String, Object>>) utMap.get("optionValueList");
		    					if(null != optionValueList){
		    						for (Map<String, Object> optionValue : optionValueList) {
		    							optionValue.put("categoryId", utMap.get("id"));
		    							softCategoryService.addPropertyOption(optionValue);
		    						}
		    					}
		    				}
						}
		    		}*/
		    	}else{
		    		List<UTMap<String,Object>> list = softCategoryService.getSubCategoryByNameAndCategoryIdAndSubCategoryId(name, id, parentId);
	    			if(list !=null && list.size() > 0){
	    				if(list.size() > 1){
		    				throw new EscServiceException("软件子类别名称已经存在！");
		    			}else{
		    				String oldId = (String) list.get(0).get("id");
							if(!StringUtils.equals(id, oldId)) {
								throw new EscServiceException("软件子类别名称已经存在！");
							}
		    			}
	    			}
		    		flag = softCategoryService.updateSubCategoryById(map);
		    		/*List<Map<String, Object>> optionList = (List<Map<String, Object>>) map.get("optionList");
		    		if(flag && (null != optionList)){
		    			softCategoryService.deleteSubProperty((String)map.get("id"));
		    			for (Map<String, Object> utMap : optionList) {
		    				utMap.put("subCategoryId", map.get("id"));
		    				propertyFlag = softCategoryService.addSubPropertyOption(utMap);
		    				if(propertyFlag && (null != utMap)){
		    					softCategoryService.deleteOption((String)utMap.get("id"));
		    					List<Map<String, Object>> optionValueList = (List<Map<String, Object>>) utMap.get("optionValueList");
		    					if(null != optionValueList){
		    						for (Map<String, Object> optionValue : optionValueList) {
		    							optionValue.put("categoryId", utMap.get("id"));
		    							softCategoryService.addPropertyOption(optionValue);
		    						}
		    					}
		    				}
						}
		    		}*/
		    	}
	    	}catch(EscServiceException e){
	    		logger.error("EscServiceException", e);
	    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
	    	}catch(Exception e){
	    		logger.error("Exception", e);
	    		return UTJsonUtils.getJsonMsg(false, "操作失败");
	    	}
	       return UTJsonUtils.getJsonMsg(true, "操作成功");
	    }
	
	
	/**
	 * 根据id查询
	 * @param param
	 * @return
	 */
	@RequestMapping(value="getSubById")
	@ResponseBody
	public UTMap<String, Object> getSubById(@RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = null;
		List<UTMap<String, Object>> optionList = null;
		List<UTMap<String, Object>> optionValueList = null;
    	try{
    		map = softCategoryService.getSubCategoryById(param.get("id").toString());
    		/*if(null != map){
    			optionList = softCategoryService.getSubPropertyById((String)map.get("id"));
    			map.put("optionList", optionList);
    			if(null != optionList && optionList.size()>0){
    				for (UTMap<String, Object> utMap : optionList) {
    					optionValueList = softCategoryService.getOptionByPropertyId((String)utMap.get("id"));
    					utMap.put("optionValueList", optionValueList);
					}
    			}
    		}*/
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return map;
	}
	
	@RequestMapping(value = "delete", method = RequestMethod.POST)
	@ResponseBody
	public String delete(@RequestBody Map<String, Object> param) {
		if(null != param){
			UTMap<String,Object> ut = new UTMap<String,Object>();
			ut.put("category", String.valueOf(param.get("parentId")));
			List<UTMap<String,Object>> list = assetSoftwareService.getListMaps(ut,"id");
			if(null != list && list.size() > 0){
				return UTJsonUtils.getJsonMsg(false, "该软件类别已被引用，禁止删除");
			}
		}
		try {
			softCategoryService.delete(param);
		} catch (Exception e) {
			logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "删除失败");
		}
		 return UTJsonUtils.getJsonMsg(true, "删除成功");
	}
	
	@RequestMapping(value = "deleteSubCategory", method = RequestMethod.POST)
	@ResponseBody
	public String deleteSubCategory(@RequestBody Map<String, Object> param) {
		if(null != param){
			UTMap<String,Object> ut = new UTMap<String,Object>();
			ut.put("subCategory", String.valueOf(param.get("id")));
			List<UTMap<String,Object>> list = assetSoftwareService.getListMaps(ut,"id");
			if(null != list && list.size() > 0){
				return UTJsonUtils.getJsonMsg(false, "该软件子类别已被引用，禁止删除");
			}
		}
		try {
			softCategoryService.deleteSubCategory(param);
		} catch (Exception e) {
			logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "删除失败");
		}
		 return UTJsonUtils.getJsonMsg(true, "删除成功");
	}
	
	@RequestMapping(value="getSubByParentId")
	@ResponseBody
	public List<UTMap<String, Object>> getSubByParentId(@RequestParam  Map<String, Object> param){		
		List<UTMap<String, Object>> subList = null;
		String parentId = (String)param.get("parentId");
    	try{
    		subList =  softCategoryService.getSubCategoryByParentId(parentId);
		}catch(Exception e){
			logger.error("Exception", e);
    	}
       return subList;
	}
	
	@Resource
	private IAssetSoftwareService assetSoftwareService;
}