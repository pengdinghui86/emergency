package com.esc.oms.outsource.monitor.dao;

import org.esc.framework.persistence.dao.IBaseOptionDao;

/**
 * 尽职调查评估配置模板
 * @author owner
 *
 */
public interface IDuediligenceEvaluateTemplateDao extends IBaseOptionDao{
	public static final String  FIELD_ID= "id";
	
}
