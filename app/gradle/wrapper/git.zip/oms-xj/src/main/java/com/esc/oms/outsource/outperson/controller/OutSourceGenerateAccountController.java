package com.esc.oms.outsource.outperson.controller;

import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.outsource.outperson.service.IOutSourceGenerateAccountService;

@Controller
@RequestMapping("outsource/generateAccount")
public class OutSourceGenerateAccountController {
	
	@Resource
	private IOutSourceGenerateAccountService service;
	
	@RequestMapping(value = "generateAccount", method=RequestMethod.POST)
	@ResponseBody
	public UTMap<String, Object> generateAccount(@RequestBody Map<String, Object> param){
		UTMap<String, Object> map = new UTMap<String, Object>();
		
		if (param.isEmpty()) {
			map.put("success", false);
			map.put("msg", "已存在该联系电话的用户/已存在该身份证号码的用户！");
			return map;
		}
		try {
			map = service.generateAccount(param);
		}catch(Exception e) {
			map.put("success", false);
			map.put("msg", e.getMessage());
			return map;
		}
		map.put("success", true);
		return map;
	}
}
