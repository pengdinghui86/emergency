package com.esc.oms.outsource.outperson.service.impl;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.util.CellRangeAddress;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.EscPropertyHolder;
import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.idgenerator.IDGenerationManager;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.upload.annotation.UploadQueryMarks;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.excel.UTExcelTamplate;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.workflow.service.IWorkflowEngine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.outperson.dao.IRecruitmentApplicationDao;
import com.esc.oms.outsource.outperson.dao.IRecruitmentApplicationDetailDao;
import com.esc.oms.outsource.outperson.service.IRecruitmentApplicationDetailService;
import com.esc.oms.outsource.outperson.service.IRecruitmentApplicationService;
import com.esc.oms.supplier.project.service.IProjectResService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;
import com.esc.oms.util.RoleUtils;
import com.esc.oms.util.TaskModel;
/**
 * 人力资源申请
 * @author djj
 * @date   2016-07-18
 */
@Service
@Transactional 
public class RecruitmentApplicationServiceImpl extends BaseOptionService implements IRecruitmentApplicationService {
	
	protected Logger logger = LoggerFactory.getLogger(getClass());
	
	@Resource
	private IRecruitmentApplicationDao recruitmentApplicationDao;
	@Resource
	private IRecruitmentApplicationDetailService detailService;
	@Resource
	private ISysParamService sysParamService;
	@Resource
	private IWorkflowEngine workflowEngine;
	@Resource
	private ISysUserService userService;
	@Resource
	private MessageSend messageService;
	@Resource
	private IUserTaskService userTaskService;
		
	@Resource
	private IProjectResService projectResService;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return recruitmentApplicationDao;
	}
	
	@Override
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	@EscOptionLog(module=SystemModule.outsourcePersonRecruitment, opType=ESCLogOpType.INSERT, table="recruitment_application", primaryKey="id={1.id}",option="新增名称为{1.name}的人力资源申请信息。")	
	public boolean add(Map info){	
		String status = (String) info.get("status");
		info.put("status", IRecruitmentApplicationDao.STATUS_PEND_SUBMIT);
		boolean addStatus = false;
		info.put("applyUserId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());		
		info.put("code", IDGenerationManager.nextId("recruitmentApplication"));
		addStatus = super.add(info);
		String isSubmit = info.get("isSubmit")==null?"":String.valueOf(info.get("isSubmit"));
		
		if(addStatus){
			String applyId = (String) info.get("id");
			//已有的
			List projectMembers = (List) info.get("projectMembers");
			if (null !=projectMembers && !projectMembers.isEmpty()) {
				for (int i=0;i<projectMembers.size();i++) {
					Map map = (Map)projectMembers.get(i);
					map.put("applyId", applyId);
					map.put("id", UUID.randomUUID().toString());
					recruitmentApplicationDao.addProjectRes(map);
				}
			}
			
			//新增加的
			List detailList = (List) info.get("detailList");
			if(detailList!=null&&detailList.size()>0){
				for(int i=0;i<detailList.size();i++){
					Map map = (Map) detailList.get(i);
					map.put("applyId", applyId);
					detailService.add(map);					
				}
			}
		}
		
		//保存并提交
		if(addStatus && !StringUtils.isEmpty(isSubmit)){		
			status = IRecruitmentApplicationDao.STATUS_PEND_AUDIT;
			info.put("status", status);
			info.put("applyDate", UTDate.getCurDateTime());
			super.updateById(info);
			//如果提交了申请，添加一个审批数据，便于存放审批的上传文件
			Map<String, Object> reviewFile = new HashMap<String, Object>();
			reviewFile.put("applyId", info.get("id"));
			reviewFile.put("id", UUID.randomUUID().toString());
			recruitmentApplicationDao.addReviewFile(reviewFile);
			
			UTMap<String, Object> rMap = this.getById(info.get("id").toString());
			//发送消息,通知外包管理员进行审批
			Map<String,Object> param = new HashMap<String,Object>();				
			param.put("signature", RoleUtils.OUTSOURCE_MANAGER);
			String taskUserIds = userService.getUserIds(param);	
			String title = "人力资源申请【"+info.get("name")+"/"+rMap.get("code")+"】审批提醒";
			String content = "人力资源申请【"+info.get("name")+"/"+rMap.get("code")+"】已经提交，请进入系统查看并处理！";
			messageService.sendMessage(taskUserIds,title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
			
			userTaskService.addTaskByRole("人力资源申请：【"+info.get("name")+"/"+rMap.get("code")+"】已经提交，待您审批！ ",info.get("id").toString(), "人力资源申请审批", TaskModel.recruitmentApplication, RoleUtils.OUTSOURCE_MANAGER);
		}				
			
		return addStatus;
	}
	

	@Override
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		UTMap<String, Object> rec = super.getById(id);
		Map<String,Object> param = new HashMap<String,Object>();
		param.put("applyId", id);
		List<UTMap<String, Object>> detailList = detailService.getListAll(param);
		rec.put("detailList", detailList);
		return rec;
	}
	
	@Override
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public void getPageInfo(UTPageBean pageBean,Map param){
		super.getPageInfo(pageBean, param);
	}
	
	@Override
	public void getPendApprovalPageInfo(UTPageBean pageBean,
			Map<String, Object> params) {
		recruitmentApplicationDao.getPendApprovalPageInfo(pageBean, params);
	}

	@Override
	public void getAlreadyApprovalPageInfo(UTPageBean pageBean,
			Map<String, Object> params) {
		recruitmentApplicationDao.getAlreadyApprovalPageInfo(pageBean, params);
	}
		
	/**
	 * 根据条件查询
	 * @param params
	 */
	@Override
	@UploadQueryMarks
	public List<UTMap<String, Object>> getPageList(UTPageBean pageBean,Map params){
		return recruitmentApplicationDao.getPageList(pageBean, params);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	@Override
	@UploadQueryMarks
	public List<UTMap<String, Object>> getListMaps(Map params){
		return super.getListMaps(params);
	}
	
		
	@Override
	@EscOptionLog(module=SystemModule.outsourcePersonRecruitment, opType=ESCLogOpType.UPDATE, table="recruitment_application", primaryKey="id={1.id}",option="修改名称为{1.name}的人力资源申请信息")
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean updateById(Map info){
		String status = String.valueOf(info.get("status"));
		String isSubmit = info.get("isSubmit")==null?"":String.valueOf(info.get("isSubmit"));
		//保存并提交
		if(!StringUtils.isEmpty(isSubmit)){		
			info.remove("isSubmit");
			status = IRecruitmentApplicationDao.STATUS_PEND_AUDIT;
			info.put("status", status);
			info.put("applyDate", UTDate.getCurDateTime());
				
			//如果提交了申请，添加一个审批数据，便于存放审批的上传文件
			Map<String, Object> reviewFile = new HashMap<String, Object>();
			reviewFile.put("applyId", info.get("id"));
			reviewFile.put("id", UUID.randomUUID().toString());
			recruitmentApplicationDao.addReviewFile(reviewFile);
			Map<String, Object> rMap = this.getById((String) info.get("id"));
			//发送消息,通知外包管理员进行审批
			Map<String,Object> param = new HashMap<String,Object>();				
			param.put("signature", RoleUtils.OUTSOURCE_MANAGER);
			String taskUserIds = userService.getUserIds(param);	
			String title = "人力资源申请【"+info.get("name")+"/"+rMap.get("code")+"】审批提醒";
			String content = "人力资源申请【"+info.get("name")+"/"+rMap.get("code")+"】已经提交，请进入系统查看并处理！";
			messageService.sendMessage(taskUserIds,title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
			
			userTaskService.addTaskByRole("人力资源申请：【"+info.get("name")+"/"+rMap.get("code")+"】已经提交，待您审批！ ",
					info.get("id").toString(), "人力资源申请审批", TaskModel.recruitmentApplication, RoleUtils.OUTSOURCE_MANAGER);
		}
		List removeDetailList = (List) info.get("removeDetailList");
		if(removeDetailList!=null&&removeDetailList.size()>0){
			for(int i=0;i<removeDetailList.size();i++){
				Map map = (Map) removeDetailList.get(i);
				String id = (String) map.get("id");
				detailService.deleteById(id);
			}
		}
		String applyId = (String) info.get("id");
		List detailList = (List) info.get("detailList");
		if(detailList!=null&&detailList.size()>0){
			for(int i=0;i<detailList.size();i++){
				Map map = (Map) detailList.get(i);
				if(map.containsKey("id")){ //修改
					detailService.updateById(map);
				}else{ //新增
					map.put("applyId", applyId);
					detailService.add(map);
				}				
			}
		}
		
		List projectMembers = (List) info.get("projectMembers");
		recruitmentApplicationDao.deleteProjectResByApplyId(applyId);
		if (null !=projectMembers && !projectMembers.isEmpty()) {
			for (int i=0;i<projectMembers.size();i++) {
				Map map = (Map)projectMembers.get(i);
				map.put("applyId", applyId);
				map.put("id", UUID.randomUUID().toString());
				recruitmentApplicationDao.addProjectRes(map);
			}
		}
		
		return super.updateById(info);
	}
	
	@Override
	public void distribute(Map<String, Object> info) {
		String status = IRecruitmentApplicationDao.STATUS_PEND_RECOMMEND;
		String applyId = (String) info.get("id");
		info.put("status", status);
		super.updateById(info);
		
		//发送消息,通知供应商助理进行简历推荐
		Map<String,Object> param = new HashMap<String,Object>();				
		param.put("signature", RoleUtils.SUPPLIER_ASSISTANT);
		param.put("supplierIds", info.get("distributeSuppliers"));
		String taskUserIds = userService.getUserIds(param);	
		String title = "人力资源申请【"+info.get("name")+"/"+info.get("code")+"】简历推荐提醒";
		String content = "人力资源申请【"+info.get("name")+"/"+info.get("code")+"】已分发至您所属供应商，现可进行简历推荐，详情请进入系统查看！";
		messageService.sendMessage(taskUserIds,title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
		
		//关闭待办任务
		userTaskService.finishTask(applyId, IRecruitmentApplicationDao.TASK_APPLICATION_DISTRIBUTE);
	}

	@Override
	@EscOptionLog(module=SystemModule.outsourcePersonRecruitment, opType=ESCLogOpType.UPDATE, table="recruitment_application", primaryKey="id={1.id}",option="关闭名称为{1.name}的人力资源申请信息")	
	public void close(Map<String, Object> info) {
		String id = info.get("id").toString();
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("id", id);
		map.put("status", IRecruitmentApplicationDao.STATUS_FINISH);
		super.updateById(map);
		
		//申请详单也进行关闭
		detailService.closeByApplyId(id);
	}
	
	@Override
	public List<UTMap<String, Object>> getManpowerSuppliers(
			Map<String, Object> param) {	
		return recruitmentApplicationDao.getManpowerSuppliers(param);
	}


	@Override
	public List<UTMap<String, Object>> getManpowerCategorys(
			Map<String, Object> param) {
		return recruitmentApplicationDao.getManpowerCategorys(param);
	}

	
	/**
	 * 包括领用详单
	 * @param pageBean
	 * @param param
	 */
	@Override
	public void getPageInfoDetail(UTPageBean pageBean, Map param) {
		recruitmentApplicationDao.getPageInfo(pageBean, param);
		List list = pageBean.getRows();
		if(list!=null&&list.size()>0){
			Map<String,Object> detailMap = this.getDetailMap(param);
			for(int i=0;i<list.size();i++){
				Map<String,Object> map = (Map<String, Object>) list.get(i);
				String applyId = (String) map.get("id");
				List<UTMap<String,Object>> detailList = (List<UTMap<String, Object>>) detailMap.get(applyId);
				map.put("detailList", detailList);
			}
		}
	}
	
	private Map<String,Object> getDetailMap(Map param){
		List<UTMap<String,Object>> list = detailService.getListAllByParentParam(param);
		Map<String,Object> detailMap = new HashMap<String,Object>();
		if(list!=null){
			for(UTMap<String,Object> map:list){
				String applyId = (String) map.get("applyId");
				List<UTMap<String,Object>> detailList = (List<UTMap<String, Object>>) detailMap.get(applyId);
				if(detailList==null){
					detailList = new ArrayList<UTMap<String,Object>>();
				}
				detailList.add(map);
				detailMap.put(applyId, detailList);
			}
		}
		return detailMap;
	}
	
	/**
	 * 根据条件查询，包括领用详单
	 * @param params
	 */
	@Override
	public List<UTMap<String, Object>> getListAllDetail(Map params){
		List<UTMap<String, Object>> list = recruitmentApplicationDao.getListMaps(params);
		if(list!=null&&list.size()>0){
			Map<String,Object> detailMap = this.getDetailMap(params);
			for(int i=0;i<list.size();i++){
				Map<String,Object> map = (Map<String, Object>) list.get(i);
				String applyId = (String) map.get("id");
				List<UTMap<String,Object>> detailList = (List<UTMap<String, Object>>) detailMap.get(applyId);
				map.put("detailList", detailList);
			}
		}
		return list;
	}
	
	
	/**
	 * 根据ids删除
	 */
	@Override
	@EscOptionLog(module=SystemModule.outsourcePersonRecruitment, opType=ESCLogOpType.DELETES, table="recruitment_application",option="删除名称为{name}的人力资源申请记录。")	
	public boolean deleteByIds(String ids){
		//删除申请详单
		if(ids!=null&&ids.length()>0){
			String receptIds[] = ids.split(",");
			for(String receptId:receptIds){
				detailService.deleteByApplyId(receptId);	
			}	
		}		
		return super.deleteByIds(ids);
	}
	
	/**
	 * 根据id 删除
	 * @param ids
	 * @return
	 */
	@Override
	@EscOptionLog(module=SystemModule.outsourcePersonRecruitment, opType=ESCLogOpType.DELETE, table="recruitment_application",primaryKey="{1}",option="删除名称为{name}的人力资源申请记录。")	
	public boolean deleteById(String id){
		//删除申请详单
		detailService.deleteByApplyId(id);
		recruitmentApplicationDao.deleteProjectResByApplyId(id);
		return super.deleteById(id);
	}
	
	public void finishAudit(String businessRecordId, String auditStatus) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("status", IRecruitmentApplicationDao.STATUS_PEND_DISTRIBUTE);
		map.put("id", businessRecordId);
		map.put("auditStatus", auditStatus);
		super.updateById(map);
		userTaskService.finishTask(businessRecordId, "人力资源申请审批");
		Map<String,Object> info = getById(businessRecordId);
		
		//如果审批通过，回填已有项目人员信息到项目资源表中
		Map<String, Object> resParam = new HashMap<String, Object>();
		resParam.put("applyId", businessRecordId);
		List<UTMap<String, Object>> resList = recruitmentApplicationDao.getProjectRes(resParam);
		if (null != resList && !resList.isEmpty()) {
			for (UTMap<String, Object> item : resList) {
				Map<String, Object> resInfo = new HashMap<String, Object>();
				resInfo.put("projectId", item.get("projectId"));
				resInfo.put("memberId", item.get("memberId"));
				resInfo.put("endDate", item.get("endDate"));
				projectResService.updateBy(resInfo, "projectId", "memberId");
			}
		}
		
		//发送消息
		Map<String,Object> param = new HashMap<String,Object>();				
		param.put("signature", RoleUtils.OUTSOURCE_MANAGER);
		String taskUserIds = userService.getUserIds(param);	
		String title = "人力资源申请【"+info.get("name")+"/"+info.get("code")+"】分发提醒";
		String content = "人力资源申请：【"+info.get("name")+"/"+info.get("code")+"】已审批通过，请进行分发！";
		messageService.sendMessage(taskUserIds,title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
		
		//生成待办任务
		UTMap<String,Object> utMap = super.getById(businessRecordId);
		Map<String,Object> dataParam = new HashMap<String,Object>();
		//点击待办事项，打开申请列表tab
		dataParam.put("dataType", "0");
		userTaskService.addTaskByRole("人力资源申请【"+utMap.get("name")+"】已审批通过，待您分发", businessRecordId, IRecruitmentApplicationDao.TASK_APPLICATION_DISTRIBUTE, TaskModel.recruitmentApplication, RoleUtils.OUTSOURCE_MANAGER,dataParam);
	}

/*	public void rejectAudit(String businessRecordId) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("status", IRecruitmentApplicationDao.STATUS_REJECT);
		map.put("id", businessRecordId);
		super.updateById(map);	
		
		//发送消息及邮件
		UTMap<String,Object> info = super.getById(businessRecordId);			
		String taskUserIds = info.get("applyUserId")==null?null:(String)info.get("applyUserId");	
		String title = "人力资源申请【"+info.get("name")+"/"+info.get("code")+"】驳回提醒";
		String content = "人力资源申请：【"+info.get("name")+"/"+info.get("code")+"】已被驳回，请知悉！详情请进入系统查看";
		messageService.sendMessage(taskUserIds,title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
	}*/
	

	/**
	 * 回调方法。
	 * 流程中止，或非正常结束，业务上需要进行的相应操作。
	 * @param businessRecordId
	 */
	public void rejectAudit(String businessRecordId, String auditStatus) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("status", IRecruitmentApplicationDao.STATUS_TERMINATE);
		map.put("id", businessRecordId);
		map.put("auditStatus", auditStatus);
		super.updateById(map);
		//完成待办
		userTaskService.finishTask(businessRecordId, "人力资源申请审批");
		
		//发送消息及邮件
		UTMap<String,Object> info = super.getById(businessRecordId);			
		String taskUserIds = info.get("applyUserId")==null?null:(String)info.get("applyUserId");	
		String title = "人力资源申请【"+info.get("name")+"/"+info.get("code")+"】终止提醒";
		String content = "人力资源申请：【"+info.get("name")+"/"+info.get("code")+"】已被终止，请知悉！详情请进入系统查看";
		messageService.sendMessage(taskUserIds,title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
		
	}
	
/*	*//**
	 * 	回调方法 
	 * 到达某一节点时执行 对应的业务方法
	 * @param businessRecordId
	 *//*
	@Override
	public void optionNode(String workflowCode, String businessRecordId,String nodeName, String linkName) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("status", IRecruitmentApplicationDao.STATUS_AUDITING);
		map.put("id", businessRecordId);
		super.updateById(map);	
	}*/
	
/*	*//**
	 * 发送任务
	 * *//*
	@Override
	public void sendTask(String workflowName,String businessRecordId,String nodeName,String userId){
		UTMap<String,Object> utMap = super.getById(businessRecordId);
		Map<String,Object> dataParam = new HashMap<String,Object>();
		//点击待办事项，打开待审批列表tab
		dataParam.put("dataType", "1");
		userTaskService.addTaskByUserId("人力资源申请【"+utMap.get("name")+"/"+utMap.get("code")+"】待您审批", businessRecordId, nodeName, TaskModel.recruitmentApplication, userId,dataParam);
	}*/

	@Override
	public boolean leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String tamlate="excelOutTamplate.recruitmentApplicationLeadOut";
		String[] fileds = new String[] {
				IRecruitmentApplicationDao.FIELD_NAME,											
				IRecruitmentApplicationDao.FIELD_CODE,
				IRecruitmentApplicationDao.FIELD_CREATE_USER,
				IRecruitmentApplicationDao.FIELD_APPLY_DEPART_LONG_NAME,
				"projectInfoName",
				IRecruitmentApplicationDao.FIELD_APPLY_DATE,
				IRecruitmentApplicationDao.FIELD_STATUS,
				//IRecruitmentApplicationDao.FIELD_APPLY_REASON,
				IRecruitmentApplicationDao.FIELD_APPLY_REASON_REMARK,
				IRecruitmentApplicationDao.FIELD_IS_LIMIT_SUPPLIER,
				IRecruitmentApplicationDao.FIELD_LIMIT_SUPPLIER_NAMES,
				IRecruitmentApplicationDao.FIELD_LIMIT_REASON				
			 };
		
		//替换下拉的值
		Map<String, String> fieldAndParamType = new HashMap<String, String>();
		fieldAndParamType.put(IRecruitmentApplicationDao.FIELD_APPLY_REASON, "recruitmentApplicationReason");
		fieldAndParamType.put(IRecruitmentApplicationDao.FIELD_IS_LIMIT_SUPPLIER, "YesNo");
		fieldAndParamType.put(IRecruitmentApplicationDao.FIELD_STATUS, "recruitmentApplicationStatus");		
		sysParamService.changeParamData(data, fieldAndParamType);
		
//		//转换婚姻状况		
//		for(int i=0;i<data.size();i++){
//			Map<String,Object> item = (Map<String, Object>) data.get(i);
//			//转换完成率
//			Object obj = item.get(IOutSourcePersonResumeInfoDao.FIELD_ISMARRIAGE);
//			if(obj!=null&&"1".equals(obj.toString())){				
//				item.put(IOutSourcePersonResumeInfoDao.FIELD_ISMARRIAGE,"已婚");
//			}else{
//				item.put(IOutSourcePersonResumeInfoDao.FIELD_ISMARRIAGE,"未婚");
//			}
//		}		
		return	UTExcel.leadingout( fileds, data, tamlate, request,response);
	}
	
	/**
	 * 导出详情
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	@Override
	public boolean leadingoutDetail(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String path = EscPropertyHolder.instance.getProperty("excelOutTamplate.recruitmentApplicationDetailLeadOut");
		String[] fields = new String[] { 
				"row_num",
				IRecruitmentApplicationDao.FIELD_NAME,											
				IRecruitmentApplicationDao.FIELD_CODE,
				IRecruitmentApplicationDao.FIELD_CREATE_USER,
				IRecruitmentApplicationDao.FIELD_APPLY_DEPART_LONG_NAME,
				"projectInfoName",
				IRecruitmentApplicationDao.FIELD_APPLY_DATE,
				IRecruitmentApplicationDao.FIELD_STATUS,
				//IRecruitmentApplicationDao.FIELD_APPLY_REASON,
				IRecruitmentApplicationDao.FIELD_APPLY_REASON_REMARK,
				IRecruitmentApplicationDetailDao.FIELD_CATEGORY,
				IRecruitmentApplicationDetailDao.FIELD_LEVEL,
				IRecruitmentApplicationDetailDao.FIELD_NUM,
				"departmentName",
				"responsibility",
				IRecruitmentApplicationDetailDao.FIELD_HILLOCK_DATE,
				IRecruitmentApplicationDetailDao.FIELD_FREED_DATE,
				IRecruitmentApplicationDetailDao.FIELD_STATUS
		};
		// 获取导出文件名称
		int l = path.lastIndexOf("/");
		int j = path.lastIndexOf("--");
		String fileName = "";
		String title = "";
		if (j > 0) {
			fileName = path.substring(j + 2);
			title = fileName;
			path = path.substring(0, j);
			fileName = fileName + path.substring(path.lastIndexOf("."));
		} else {
			fileName = path.substring(l + 1);
			title = fileName.substring(0, fileName.lastIndexOf("."));
		}
		// 创建模板对象
		UTExcelTamplate tamplate = UTExcelTamplate.getInstance();
		// 加载模板
		tamplate.readTemplateByClasspath(path);
		// 模板常量参数赋值
		Map<String, String> map = new HashMap<String, String>();
		map.put("title", title);
		map.put("time", "日期：" + UTDate.getCurDate());
		tamplate.replaceFinalData(map);
		
		//替换下拉的值
		Map<String, String> fieldAndParamType = new HashMap<String, String>();
		fieldAndParamType.put(IRecruitmentApplicationDao.FIELD_APPLY_REASON, "recruitmentApplicationReason");
		fieldAndParamType.put(IRecruitmentApplicationDao.FIELD_IS_LIMIT_SUPPLIER, "YesNo");
		fieldAndParamType.put(IRecruitmentApplicationDao.FIELD_STATUS, "recruitmentApplicationStatus");	
		sysParamService.changeParamData(data, fieldAndParamType);	
		
		Map<String, String> detailParamType = new HashMap<String, String>();
		detailParamType.put(IRecruitmentApplicationDetailDao.FIELD_STATUS, "recruitmentApplicationDetailStatus");
		
		int startDataRow = 2;
		// 循环填充excel
		for(int num=0;num<data.size();num++){
			UTMap<String, Object>  utmap = (UTMap<String, Object>) data.get(num);				
			List<UTMap<String, Object>> classifys = (List<UTMap<String, Object>>) utmap.get("detailList");
			if(classifys==null){
				classifys = new ArrayList<UTMap<String, Object>>();
			}
			fieldAndParamType.put(IRecruitmentApplicationDetailDao.FIELD_LEVEL, "personLevel");	
			sysParamService.changeParamData(classifys, detailParamType);
			for (UTMap<String, Object> info : classifys) {
				info.put("hillockDate", CommonUtils.replaceAll((String)info.get("hillockDate"), "-", "/"));
				info.put("freedDate", CommonUtils.replaceAll((String)info.get("freedDate"), "-", "/"));
				tamplate.createNewRow();
				tamplate.createCell(num + 1); // 第一列是序号
				
				for (int ci = 1; ci <= 8; ci++){
					String f = fields[ci];
					String v = utmap.get(f) != null ? utmap.get(f).toString() : "";
//					//类别转换
//					if(f.equals(ILowvalueApplyDao.FIELD_TYPE)){
//						v = getTypeDesc(v);
//					}						
//					//状态转换	
//					if(f.equals(ILowvalueApplyDao.FIELD_STATUS)){
//						v = getStatusDesc(v);
//					}
					tamplate.createCell(v);					
				}
				//分类和级别
				for (int i = 9; i < fields.length; i++) {
					String f = fields[i];
					String v = info.get(f) != null ? info.get(f).toString() : "";
//					//确认状态转换	
//					if(f.equals(ILowvalueApplyDetailDao.FIELD_CONFIRM_STATUS)){
//						v = getConfirmStatusDesc(v);
//					}
					tamplate.createCell(v);
				}
			}
			//合并单元格，开始行到结束行，开始单元格到结束单元格
			int endDataRow = startDataRow + classifys.size() - 1;
			for (int ci = 0; ci <= 8; ci++){
				tamplate.addMergedRegion(new CellRangeAddress(
						startDataRow, //first row (0-based)  from 行     
						endDataRow, //last row  (0-based)  to 行     
						ci, //first column (0-based) from 列     
						ci //last column  (0-based)  to 列     
	        	));
			}	
			startDataRow = endDataRow + 1;
		}	
		tamplate.setSheet(new String[]{title});
		
		try {
			fileName = new String( fileName.getBytes("GBK"), "ISO8859-1" ) ;
		} catch (UnsupportedEncodingException e) {
			logger.error("UnsupportedEncodingException",e);
		}
		try {
			OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
			response.addHeader("Content-Disposition", "attachment;filename=" + fileName);
			response.setContentType("application/octet-stream");
			tamplate.writeToStream(toClient);
		} catch (IOException e) {
			logger.error("IOException",e);
		}
		return true;
	}

	@Override
	public Map<String, Object> getOrgReport(Map<String, Object> params) {
		List<UTMap<String, Object>> list = recruitmentApplicationDao.getOrgReport(params);
		String[] titleData = new String[list.size()];
		int[] appData = new int[list.size()];
		int[] arrivalData = new int[list.size()];
		Map<String,Object> resultMap = new HashMap<String,Object>();
		for(int i=0;i<list.size();i++){
			UTMap<String, Object> map = list.get(i);					
			String orgName = (String) map.get("orgName");
			titleData[i]=orgName;
			int appNum = map.get("appNum")==null?0:Integer.parseInt(String.valueOf(map.get("appNum")));
			appData[i]=appNum;
			int arrivalNum = map.get("arrivalNum")==null?0:Integer.parseInt(String.valueOf(map.get("arrivalNum")));
			arrivalData[i]=arrivalNum;
		}
		resultMap.put("titleData", titleData);
		resultMap.put("appData", appData);
		resultMap.put("arrivalData", arrivalData);
		return resultMap;
	}
	
	@Override
	public UTMap<String, Object> getReviewFile(String applyId){
		return recruitmentApplicationDao.getReviewFile(applyId);
	}
	
	@Override
	@UploadQueryMark
	public UTMap<String, Object> getReviewFileById(String id){
		return recruitmentApplicationDao.getReviewFileById(id);
	}

	@Override
	@UploadAddMark
	public boolean submitViewForm(Map<String, Object> param) {
		// TODO Auto-generated method stub
		String applyId = (String) param.get("applyId");
		String auditStatus = (String) param.get("auditStatus");
		if (StringUtils.equals("1", auditStatus)) {
			finishAudit(applyId, auditStatus);
		}else {
			rejectAudit(applyId, auditStatus);
		}
		return true;
	}

	@Override
	public List<UTMap<String, Object>> getProjectRes(Map<String, Object> param) {
		// TODO Auto-generated method stub
		return recruitmentApplicationDao.getProjectRes(param);
	}

}
