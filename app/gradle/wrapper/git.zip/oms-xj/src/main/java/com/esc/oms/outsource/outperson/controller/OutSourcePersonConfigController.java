package com.esc.oms.outsource.outperson.controller;


import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.page.UTListResult;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.outsource.outperson.service.IApplyEnterService;
import com.esc.oms.outsource.outperson.service.IOutSourcePersonConfigService;
import com.esc.oms.util.CommonUtils;

@Controller
@RequestMapping("outsource/person/config")
public class OutSourcePersonConfigController  extends BaseOptionController{
	
	@Resource
	private IOutSourcePersonConfigService personConfigService;
	@Resource
	private IApplyEnterService enterService;
	
	@Resource
	private ISysParamService sysParamService;
	
	@Override
	public IBaseOptionService optionService() {
		return personConfigService;
	}

	
	//根据系统参数 拼接用户 配置项
//	@RequestMapping(value="getPersonConfig")  
//    @ResponseBody
//	public UTListResult getPersonConfig(@RequestParam Map<String, Object> param){
//		String userId=param.get("userId").toString();
//		return UTListResult.getListResult( personConfigService.getPersonConfig(userId));
//	}
	
	@RequestMapping(value="getPersonConfig")
	@ResponseBody
	public UTListResult getPersonConfig(@RequestParam  Map<String, Object> param){
		String userId=param.get("userId").toString();
		return UTListResult.getListResult( personConfigService.getPersonConfig(userId));
	}
	
	@RequestMapping(value="getInitPersonConfig")
	@ResponseBody
	public UTListResult getInitPersonConfig(@RequestParam  Map<String, Object> param){
		String userId=param.get("userId").toString();
		return UTListResult.getListResult(personConfigService.InitgetPersonConfig(userId));
	}
	
	@RequestMapping("getConfig")
	@ResponseBody
	public UTListResult getConfig(@RequestParam  Map<String, Object> param) {
		return UTListResult.getListResult(personConfigService.getListMaps(param));
	}
	
	//为人员添加配置
	@RequestMapping(value="saveConfigByUserId",method=RequestMethod.POST)  
    @ResponseBody
	public String saveConfigByUserId(@RequestBody Map<String,Object> info){
		Map<String,Object> cloneMap = CommonUtils.clone(info);
	   	try{
			List configsInfo =(List) (cloneMap.containsKey("configInfo")? cloneMap.get("configInfo"):null);
	   		boolean flog=personConfigService.saveConfigByUserId2(configsInfo);
    		return UTJsonUtils.getJsonMsg(flog, flog?"操作成功":"操作失败");
    	}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
	}
}
