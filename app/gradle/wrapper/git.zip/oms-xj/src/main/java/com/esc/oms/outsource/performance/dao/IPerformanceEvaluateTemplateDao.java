package com.esc.oms.outsource.performance.dao;

import org.esc.framework.persistence.dao.IBaseOptionDao;

/**
 * 外包绩效考核配置模板
 * @author owner
 *
 */
public interface IPerformanceEvaluateTemplateDao extends IBaseOptionDao{
	public static final String  FIELD_ID= "id";
	
}
