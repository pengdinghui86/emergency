package com.esc.oms.asset.inventory.service;

import java.util.List;
import java.util.Map;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

import com.alibaba.fastjson.JSONArray;


public interface IAssetInventoryService extends IBaseOptionService{
	
	public boolean addAssetInventory(Map info);
	
	public boolean deleteAssetInventoryById(String id);
	
	public List<UTMap<String, Object>> getAssetInventoryListMaps(Map param) ;
	
	public boolean updateInventoryStatusById(String ids,String status,String borrowId);
	
	public void getAssetInventoryPageInfo(UTPageBean pageBean,Map param);
	
	public boolean deleteAssetInventoryByInventoryId(String id);
	
	public boolean updateInventoryStatusByInventoryId(String inventoryId,String status);
	
	public void generate();

	public boolean leadingin(String filePath, Map<String, Object> param);

	public boolean leadinginForRest(List<Map<String, Object>> datas);

	public UTMap<String, Object> getByCode(String code);

	public boolean updateInventoryStatus(Map<String, Object> param);
	
}


