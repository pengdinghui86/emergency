package com.esc.oms.outsource.outperson.service.impl;

import com.esc.oms.outsource.agreementManpower.dao.IAgreementManpowerInfoDao;
import com.esc.oms.outsource.agreementManpower.service.IAgreementManpowerInfoService;
import com.esc.oms.outsource.outperson.dao.IOutSourcePersonDao;
import com.esc.oms.outsource.outperson.service.IOutSourcePersonConfigService;
import com.esc.oms.outsource.outperson.service.IOutSourcePersonService;
import com.esc.oms.supplier.supplieremp.dao.ISupplierEmpDao;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.idgenerator.IDGenerationManager;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.dao.IPeople;
import org.esc.framework.security.dao.ISysOrgDao;
import org.esc.framework.security.dao.ISysUserDao;
import org.esc.framework.security.util.ESCSecurityEnum.ESCUesrType;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Timestamp;
import java.util.*;
/**
 * 外包人员列表
 * @author smq
 * @date   2016-2-24 上午10:39:04
 */
@Service
@Transactional 
public class OutSourcePersonServiceImpl extends BaseOptionService implements IOutSourcePersonService {
	
	@Resource
	private IOutSourcePersonDao outSourcePersonDao;
	@Resource
	private ISupplierEmpDao supplierEmpDao;
	@Resource
	private ISysUserDao userDao;
	@Resource
	private ISysOrgDao orgDao;
	@Resource
	private IAgreementManpowerInfoDao agreementManpowerInfoDao;
	@Resource
	private IAgreementManpowerInfoService agreementManpowerInfoService;
	
	@Resource
	private IOutSourcePersonConfigService personConfigService;
	@Override
	public IBaseOptionDao getOptionDao() {
		return outSourcePersonDao;
	}
	

	@Override
	public boolean add(Map info){
		String userId=info.get(IOutSourcePersonDao.FIELD_USERID).toString();
		String departId=info.get(IOutSourcePersonDao.FIELD_DEPARTID)!=null?info.get(IOutSourcePersonDao.FIELD_DEPARTID).toString():null;
		String userCode= userDao.getById(userId,"code").get("code").toString();
		Map<String, Object> param1=new HashMap<String, Object>();
		param1.put("userId", userId);
		//param1.put(outSourcePersonDao.FIELD_STATE, 1);
		//判断是否存在 被逻辑删除的 外包人员
		if(outSourcePersonDao.isExist(param1)){
			info.remove(IOutSourcePersonDao.FIELD_ISHUMANRES);
			if(info.containsKey("departId") && StringUtils.isEmpty(departId)){
				info.remove("departId");
			}
			info.put(IOutSourcePersonDao.FIELD_STATE,1);
			return	updateBy(info, IOutSourcePersonDao.FIELD_USERID);
		}
	//	String departId=info.containsKey(outSourcePersonDao.FIELD_DEPARTID)?info.get(outSourcePersonDao.FIELD_DEPARTID).toString():null;

		if(!info.containsKey(IPeople.FIELD_SORTCODE)){
			String sortcode=userDao.getNewCode(IPeople.FIELD_SORTCODE);
			info.put(IPeople.FIELD_SORTCODE, sortcode);
		}
		
		if(!info.containsKey(IPeople.FIELD_CODE)){
			info.put(IPeople.FIELD_CODE,  IDGenerationManager.nextId("userNumber"));
		}
		info.put("code",userCode);
		boolean flog=	outSourcePersonDao.add(info);
		if(flog&&((departId == null) ? false : (departId.length() > 0))){
			Map<String, Object> param=new HashMap<String, Object>();
			param.put(IPeople.FIELD_ID, userId);
			param.put(IPeople.FIELD_ORGIDS, departId);
			param.put(IPeople.FIELD_USERTYPE, ESCUesrType.EPIBOLY.getValue());
			//获取部门longName 替换 字符串中的！
			Map<String, Object> map=new HashMap<String, Object>();
				map.put(IPeople.FIELD_ORGIDS, departId);
				String orgName=	orgDao.getById(departId.toString(), ISysOrgDao.FIELD_LONGNAME).get(ISysOrgDao.FIELD_LONGNAME).toString().replaceAll("!", "/");
				param.put(ISysUserDao.FIELD_ORGNAME,orgName);
				userDao.updateById(param);
		}
		//添加默认配置项
		personConfigService.createConfigByUserId2(userId);
		return flog;
	}
	

	@Override
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		UTMap<String, Object> result = super.getById(id);
		return result;
	}
	
	@Override
	@EscOptionLog(module=SystemModule.outsourcePersonList, opType=ESCLogOpType.UPDATE, table="outsource_person_list", 
	primaryKey="id={1.id}",	option="修改外包人员{1.name}/{1.code}的信息")
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean updateById(Map info){
		String dingDingId = (String) info.get("dingDingId");
		if((dingDingId == null) ? false : (dingDingId.length() > 0)){//如果钉钉ID不为空，先删除其他的引用，保证唯一
			outSourcePersonDao.deleteDingDingId("'"+dingDingId+"'");
		}
		boolean flog=	outSourcePersonDao.updateById(info);
		String userId=info.get(IOutSourcePersonDao.FIELD_USERID).toString();
		String departId=info.get(IOutSourcePersonDao.FIELD_DEPARTID).toString();
		String phone=info.get(IPeople.FIELD_PHONE).toString();
		String email=info.get(IPeople.FIELD_EMAIL).toString();
		Object img=info.get(IPeople.FIELD_IMG);
		Object sex = info.get(IPeople.FIELD_SEX);
		
		if(flog){
			Map<String, Object> param=new HashMap<String, Object>();
			param.put(IPeople.FIELD_ID, userId);
			param.put(IPeople.FIELD_ORGIDS, departId);
			param.put(IPeople.FIELD_IMG, img);
			param.put(IPeople.FIELD_PHONE, phone);
			param.put(IPeople.FIELD_EMAIL, email);
			param.put(IPeople.FIELD_IMG, img);
			param.put(IPeople.FIELD_USERTYPE, ESCUesrType.EPIBOLY.getValue());
			param.put(IPeople.FIELD_SEX, sex);
			
			//获取部门longName 替换 字符串中的！
			Map<String, Object> map=new HashMap<String, Object>();
			map.put(IPeople.FIELD_ORGIDS, departId);
			String orgName=	orgDao.getById(departId.toString(), ISysOrgDao.FIELD_LONGNAME).get(ISysOrgDao.FIELD_LONGNAME).toString().replaceAll("!", "/");
			param.put(ISysUserDao.FIELD_ORGNAME,orgName);
			
			userDao.updateById(param);
		}
		return flog;
	}
	
	

	//通过 供应商详细添加 外包人员信息
	@Override
	public boolean addOutSouceBySupplierEmp(Map<String, Object> empInfo){
	
			Map<String, Object> outPerson= new HashMap<String, Object>();
			outPerson.put(IOutSourcePersonDao.FIELD_ISACCESS,empInfo.containsKey(IOutSourcePersonDao.FIELD_ISACCESS)?empInfo.get(IOutSourcePersonDao.FIELD_ISACCESS):0);
			outPerson.put(IOutSourcePersonDao.FIELD_ISASSESS,empInfo.containsKey(IOutSourcePersonDao.FIELD_ISASSESS)?empInfo.get(IOutSourcePersonDao.FIELD_ISASSESS):0);
			outPerson.put(IOutSourcePersonDao.FIELD_ISKEYPERSON,empInfo.containsKey(IOutSourcePersonDao.FIELD_ISKEYPERSON)?empInfo.get(IOutSourcePersonDao.FIELD_ISKEYPERSON):0);
			outPerson.put(IOutSourcePersonDao.FIELD_DEPARTID,empInfo.get(IOutSourcePersonDao.FIELD_DEPARTID));
			outPerson.put(IOutSourcePersonDao.FIELD_SUPPLIERID,empInfo.get(IOutSourcePersonDao.FIELD_SUPPLIERID));
			outPerson.put(IOutSourcePersonDao.FIELD_NAME,empInfo.get(IOutSourcePersonDao.FIELD_NAME));
			outPerson.put(IOutSourcePersonDao.FIELD_USERID,empInfo.get(IOutSourcePersonDao.FIELD_USERID));
			outPerson.put(IOutSourcePersonDao.FIELD_CODE,empInfo.get(IOutSourcePersonDao.FIELD_CODE));
			outPerson.put(IOutSourcePersonDao.FIELD_ISHUMANRES,0);
			outPerson.put(IOutSourcePersonDao.FIELD_STATE,1);
			return this.add(outPerson);
	
	}

	@Override
	public boolean leadingin(String filePath, Map<String, Object> param)
			throws Exception {
		List<UTMap<String, Object>> leadinginList = new ArrayList<UTMap<String,Object>>();
		List<String> idcodeList=new ArrayList<String>();

		Timestamp createTime=UTDate.DateToTimestamp( new Date());
		
		boolean flag = true;
		// 根据路径 获取工作薄
		Sheet sheet = UTExcel.getSheets(filePath)[0];
		// 导入顺序
		
		String[] cellArray = new String[] { 
				"姓名*（长度：0-20）",
				"身份证号码*",
				"所属部门*",
				"是否人力外包人员*",
//				"业务负责人*",
//				"技术负责人*",
				"人力外包合同名称*",
				"人力外包合同编号*",
				"人员类型*",
				"人员级别*",
				"是否关键负责人*",
				"是否考核*",
				"是否发放门禁*"
		};
		int[] lengthArr = {20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		String[] fileds = new String[] {
				IOutSourcePersonDao.FIELD_NAME,
				IPeople.FIELD_IDCODE,
				IOutSourcePersonDao.FIELD_DEPARTID,
				IOutSourcePersonDao.FIELD_ISHUMANRES,
//				"servicePersonId",
//				"skillPersonId",
				"agreementName",
				"agreementCode",
				IOutSourcePersonDao.FIELD_CATEGORY,
				IOutSourcePersonDao.FIELD_LEVEL,
				IOutSourcePersonDao.FIELD_ISKEYPERSON,
				IOutSourcePersonDao.FIELD_ISACCESS,
				IOutSourcePersonDao.FIELD_ISASSESS
			 };
		
		int rowNum = sheet.getLastRowNum();
		int cellNum = fileds.length;
		//检查导入的字段标题
		if(!UTExcel.excelValidateByCell(sheet, cellArray, fileds)){
			throw new EscServiceException("导入失败，请选择正确的模板！");
		}

		Map<String, Object> pp=new HashMap<String, Object>();
		pp.put("userType", 1);
		List<UTMap<String, Object>> users=userDao.getListMaps( pp, "id","name","code");
		StringBuilder error = new StringBuilder();
		for (int i = 1; i <= rowNum; i++) {
			// 遍历excel
			Row row = sheet.getRow(i);
			UTMap<String, Object> map = new UTMap<String, Object>();
			map.put("createTime", createTime);
			//String agreementName="";
			for (int j = 0; j < cellNum; j++) {
				String cellvalue = null;
				Cell cell = row.getCell(j);
				if (cell != null) {
					cell.setCellType(Cell.CELL_TYPE_STRING);
					cellvalue = cell.getStringCellValue();
					cellvalue = StringUtils.isEmpty(cellvalue) ? null : cellvalue.trim();
				}
				//检查空
				if(j !=4&&j!=5&&j!=6&&j!=7) {
					flag = StringUtils.isEmpty(cellvalue) ? false : true;
					if (!flag) {
						error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "内容为空，请检查！" + "<br>");
					}
				}
				if (cellvalue != null) {
					//长度校验
					if (lengthArr[j] != 0 && cellvalue.length() > lengthArr[j]){
						error.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "内容长度超出限制，请检查！" + "<br>");
					}
					//防止身份证号码重复
					if(j==1 && cellvalue != null){
							if(StringUtils.isNotEmpty(cellvalue)&&idcodeList.contains(cellvalue)){
								error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "身份证号码已存在，请检查！" + "<br>");
							}else{
								idcodeList.add(cellvalue);
							}
					}
					
					//防止部门不存在
					if(j==2){
							if(cellvalue != null){
								cellvalue=cellvalue.replaceAll("!","/");
								String orgId=orgDao.getIdLongName(cellvalue);
								if(StringUtils.isNotEmpty(orgId)){
									map.put(IOutSourcePersonDao.FIELD_DEPARTID, orgId);
									continue;
								}else{
									error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "部门不存在，请检查！" + "<br>");
								}	
							}else{
								error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "部门不存在，请检查！" + "<br>");
							}
					}
	
//					if(j==4){	
//						if(StringUtils.isNotEmpty( cellvalue)){
//	
//							cellvalue=CommonUtils.getIdByUserNameAndCode(users, cellvalue, error);
//							if(StringUtils.isEmpty(cellvalue)){
//								error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "技术负责人不存在，请检查！" + "<br>");
//							}
//						}else{		
//							error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "业务负责人不存在，请检查！" + "<br>");
//						}
//					}
//					
//					if(j==5){	
//						if(StringUtils.isNotEmpty( cellvalue)){
//							cellvalue=CommonUtils.getIdByUserNameAndCode(users, cellvalue, error);
//							if(StringUtils.isEmpty(cellvalue)){
//								error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "技术负责人不存在，请检查！" + "<br>");
//							}
//						}else{		
//							error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "技术负责人不存在，请检查！" + "<br>");
//						}
//					}
					
					if(j==3||j==10||j==8||j==9){
						if(StringUtils.isNotEmpty(cellvalue)){
							cellvalue=StringUtils.equals(cellvalue, "是")?"1":"0";
						}
					}
				}
				map.put(fileds[j], cellvalue);
			}
			
			//判断身份证号码加 人名
			if(map.get("idCode")!=null&&map.get("name")!=null){
				String idCode=map.get("idCode").toString();
				String name=map.get("name").toString();
				Map<String, Object> p=new HashMap<String, Object>();
				p.put(IPeople.FIELD_IDCODE, idCode);
				p.put(IPeople.FIELD_NAME, name);
				List<UTMap<String, Object>> aList=	userDao.getListMaps(p,IPeople.FIELD_ID,IPeople.FIELD_SUPPLIERID,IPeople.FIELD_USERTYPE);
				if(aList!=null&&aList.size()>0){
					Map<String, Object> u=aList.get(0);
					map.put(IOutSourcePersonDao.FIELD_USERID,u.get("id"));
					map.put(IOutSourcePersonDao.FIELD_SUPPLIERID,u.get("supplierId"));
					map.put("userType",aList.get(0).get("userType"));
				
				}else{
					error.append("Excel内容错误，行号为" + (i+1) + "的 "+map.get("idCode").toString()+"对应供应商人员信息不存在，请检查！" + "<br>");
				}
			}
			
			if(StringUtils.equals((String)map.get(IOutSourcePersonDao.FIELD_ISHUMANRES),"1")){
				Map<String, Object> p=new HashMap<String, Object>();
				if(map.get("supplierId")!=null)
				{
					p.put("supplierId", map.get("supplierId").toString());
					if(map.get("agreementName")!=null&&map.get("agreementCode")!=null&&map.get("category")!=null&&map.get("level")!=null){
						
						//判断合同是否存在
						p.put(IAgreementManpowerInfoDao.FIELD_AGREEMENTNAME, map.get("agreementName"));
						p.put(IAgreementManpowerInfoDao.FIELD_AGREEMENTCODE, map.get("agreementCode"));
						p.put(IOutSourcePersonDao.FIELD_CATEGORY, map.get("category"));
						p.put(IOutSourcePersonDao.FIELD_LEVEL, map.get("level"));
						
						List<UTMap<String, Object>> aList=	agreementManpowerInfoDao.getAgreementCostConfig(p);
						String agreementId=aList!=null&&aList.size()>0?aList.get(0).get("agreementId").toString():null;
						String monthlyFee=aList!=null&&aList.size()>0?aList.get(0).get("monthlyFee").toString():null;
						if(StringUtils.isNotEmpty(agreementId)){
							map.put(IOutSourcePersonDao.FIELD_AGREEMENTID,agreementId);
							//添加月费用
							map.put(IOutSourcePersonDao.FIELD_MONTHLYFEE,monthlyFee);
						}else{
							error.append("Excel内容错误，行号为" + (i+1) + "的 外包人力合同，人员类型或人员级别不存在，请检查！" + "<br>");
						}
					}else{
						error.append("Excel内容错误，行号为" + (i+1) + "的 人力外包人员的 外包人力合同及编号，人员类型及级别不能为空，请检查！" + "<br>");
					}
				}
				else {
					error.append("Excel内容错误，行号为" + (i+1) + "的供应商人员所属供应商不存在，请检查供应商人员信息的正确性！" + "<br>");
				}
				
			}else{
				map.remove("agreementName");
				map.remove("agreementCode");
				map.remove("category");
				map.remove("level");
			}
			
			map.remove("agreementName");
			map.remove("agreementCode");
			map.remove("idCode");
			leadinginList.add(map);
		}
		if (StringUtils.isNotEmpty(error.toString())) {
			throw new EscServiceException(error.toString());
		}
		//获取当前最后一个排序码
		String sortcode=outSourcePersonDao.getNewCode("sortCode");
		Integer index=Integer.valueOf(sortcode);
		Integer currectIndex=index+leadinginList.size();
		
		//保存到数据库
		for (UTMap<String, Object> leadingOne : leadinginList) {
			String userType=leadingOne.get("userType").toString();
			String userId=leadingOne.get("userId").toString();
			boolean flog=true;
			currectIndex--;
			Map<String, Object> supplierEmp=new HashMap<String, Object>();
			Map<String, Object> userInfo=new HashMap<String, Object>();
			//当userType==3时 表示 该人员已经是外包人员 执行修改操作
			if(StringUtils.equals( ESCUesrType.EPIBOLY.getValue().toString(),userType)){
				supplierEmp.put(ISupplierEmpDao.FIELD_ISOUTSTOURCE, "1");
				supplierEmp.put(IPeople.FIELD_USERTYPE, ESCUesrType.EPIBOLY.getValue());
				supplierEmp.put(ISupplierEmpDao.FIELD_USERID,userId);
				supplierEmpDao.updates(supplierEmp, ISupplierEmpDao.FIELD_USERID);
				userInfo.put("id", userId);
				userInfo.put(IPeople.FIELD_USERTYPE, ESCUesrType.EPIBOLY.getValue());
				userDao.updateById(userInfo);
				flog=outSourcePersonDao.updateBy(leadingOne, ISupplierEmpDao.FIELD_USERID);	
			}
			//当userType==2时 
			else if(StringUtils.equals( ESCUesrType.SUPPLIER.getValue().toString(),userType)){
				//修改供应商人员的 isOutResource 字段
				supplierEmp.put(ISupplierEmpDao.FIELD_ISOUTSTOURCE, "1");
				supplierEmp.put(IPeople.FIELD_USERTYPE, ESCUesrType.EPIBOLY.getValue());
				supplierEmp.put(ISupplierEmpDao.FIELD_USERID,userId);
				
				supplierEmpDao.updates(supplierEmp, ISupplierEmpDao.FIELD_USERID);
				userInfo.put("id", userId);
				userInfo.put(IPeople.FIELD_USERTYPE, ESCUesrType.EPIBOLY.getValue());
				userDao.updateById(userInfo);
				
				leadingOne.put(IPeople.FIELD_SORTCODE, currectIndex);
			//	leadingOne.put("code",userCode);

				leadingOne.put(IOutSourcePersonDao.FIELD_STATE,1);
				flog=this.add(leadingOne);
			}
			else{
				continue;
			}
			
			if (!flag) {
				throw new EscServiceException("保存数据失败！");
			}
			
		}
		return flag;
	}

	@Override
	public Boolean leadinginDing(String filePath, Map<String, Object> param) throws Exception {
		List<UTMap<String, Object>> leadinginList = new ArrayList<UTMap<String,Object>>();
		boolean flag = true;
		// 根据路径 获取工作薄
		Sheet sheet = UTExcel.getSheets(filePath)[0];
		// 导入顺序

		String[] cellArray = new String[] {
				"用户编号",
				"姓名",
				"钉钉ID"
		};
		int rowNum = sheet.getLastRowNum();
		int cellNum = cellArray.length;
		//检查导入的字段标题
		if(!UTExcel.excelValidateByCell(sheet, cellArray, cellArray)){
			throw new EscServiceException("导入失败，请选择正确的模板！");
		}
		StringBuilder error = new StringBuilder();
		StringBuilder codes = new StringBuilder();
		StringBuilder dingDingIds = new StringBuilder();
		if(rowNum < 1){
			throw new EscServiceException("导入失败，导入数据为空！");
		}
		Set<String> codeSet = new HashSet<>();//防止填入数据重复
		Set<String> dingIdSet = new HashSet<>();//钉钉set，防止数据重复
		for (int i = 1; i <= rowNum; i++) {//第一次遍历，一次性找出所有的用户
			// 遍历excel
			Row row = sheet.getRow(i);
			for(int j = 0; j < cellNum; j++){
				String cellvalue = null;
				Cell cell = row.getCell(j);
				if (cell != null) {
					cell.setCellType(Cell.CELL_TYPE_STRING);
					cellvalue = cell.getStringCellValue();
				}
				if(StringUtils.isEmpty(cellvalue)){
					error.append("Excel内容错误，第" + (i + 1) + "行 "+cellArray[j]+"不能为空");
				}
				if(j == 0 && codeSet.add(cellvalue) == false){//重复
					error.append("Excel内容错误，第" + (i + 1) + "行 +"+cellArray[j]+" 内容重复");
				}
				if(j == 2 && dingIdSet.add(cellvalue) == false){//重复
					error.append("Excel内容错误，第" + (i + 1) + "行 +"+cellArray[j]+" 内容重复");
				}
			}
			codes.append(row.getCell(0).getStringCellValue()+",");
			dingDingIds.append(row.getCell(2).getStringCellValue()+",");
		}
		if (StringUtils.isNotEmpty(error.toString())) {
			throw new EscServiceException(error.toString());
		}
		//获取所有的用户
		Map<String, Object> p = new HashMap<>();
		p.put("codes", CommonUtils.getSqlId(codes.toString()));
		List<UTMap<String, Object>> outPersonList = outSourcePersonDao.getListMaps(p);
		Map<String, UTMap<String, Object>> personMap = new HashMap<>();
		if(outPersonList != null && outPersonList.size() > 0){
			for(UTMap<String, Object> map : outPersonList){
				personMap.put((String) map.get("code"), map);
			}
		}
		List<Map<String, Object>> updateList = new ArrayList<>();
		for (int i = 1; i <= rowNum; i++) {//第二次遍历，找出对呀的用户是否存在，名称有没有写错
			// 遍历excel
			Row row = sheet.getRow(i);
			String code = row.getCell(0).getStringCellValue();
			String name = row.getCell(1).getStringCellValue();
			String dingDingId = row.getCell(2).getStringCellValue();
			UTMap<String, Object> person = personMap.get(code);
			if(person == null || !person.get("name").equals(name)){//不存在
				error.append("Excel内容错误，第" + (i + 1) + "行用户编号和姓名不匹配");
			}
			Map<String, Object> map = new HashMap<>();
			map.put("id", person != null ? person.get("id") : null);
			map.put("dingDingId", dingDingId);
			updateList.add(map);
		}
		if (StringUtils.isNotEmpty(error.toString())) {
			throw new EscServiceException(error.toString());
		}
		//先解绑当前导入的钉钉Id
		outSourcePersonDao.deleteDingDingId(CommonUtils.getSqlId(dingDingIds.toString()));
		//批量修改
		outSourcePersonDao.changeOutPersonById(updateList);
		return true;
	}

	@Override
	public boolean leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String[] fileds = new String[] {
				IPeople.FIELD_CODE,
				IPeople.FIELD_NAME,
				IPeople.FIELD_SUPPLIERNAME,
				ISysUserDao.FIELD_ORGNAME,
				IPeople.FIELD_SEX,
				IPeople.FIELD_IDCODE,
				IPeople.FIELD_PHONE,
				IPeople.FIELD_QQ,
				IPeople.FIELD_EMAIL,
//				"servicePersonName",
//				"skillPersonName",
				IOutSourcePersonDao.FIELD_ISHUMANRES,
				IOutSourcePersonDao.FIELD_CATEGORY,
				IOutSourcePersonDao.FIELD_LEVEL,
				IOutSourcePersonDao.FIELD_ISKEYPERSON,
				IOutSourcePersonDao.FIELD_ISASSESS,
				IOutSourcePersonDao.FIELD_ISACCESS
			 };
		String tamlate="excelOutTamplate.outSourcePersonLeadOut";

		Map<String, Object> p=new HashMap<String, Object>();
		p.put("userType", 1);
		List<UTMap<String, Object>> users=userDao.getListMaps( p, "id","name","code");
		for (Object info : data) {
			Map<String, Object> map=(Map<String, Object>) info;
			//时间转换
			Object orgName=map.get("orgName");
			Object ISHUMANRES=map.get(IOutSourcePersonDao.FIELD_ISHUMANRES);
			Object ISACCESS=map.get(IOutSourcePersonDao.FIELD_ISACCESS);
			Object ISASSESS=map.get(IOutSourcePersonDao.FIELD_ISASSESS);
			Object SKEYPERSON=map.get(IOutSourcePersonDao.FIELD_ISKEYPERSON);
//			Object servicePersonId=map.get("servicePersonId");
//			Object skillPersonId=map.get("skillPersonId");

			map.put(IOutSourcePersonDao.FIELD_ISHUMANRES, ISHUMANRES == null ? "否" : Integer.valueOf(ISHUMANRES.toString())==1?"是":"否");
			map.put(IOutSourcePersonDao.FIELD_ISACCESS, ISACCESS==null?'否':Integer.valueOf(ISACCESS.toString())==1?"是":"否");
			map.put(IOutSourcePersonDao.FIELD_ISKEYPERSON,SKEYPERSON==null?"否": Integer.valueOf(SKEYPERSON.toString())==1?"是":"否");
			map.put(IOutSourcePersonDao.FIELD_ISASSESS,ISASSESS==null?'否': Integer.valueOf(ISASSESS.toString())==1?"是":"否");
			
//			map.put("servicePersonName",servicePersonId!=null&&StringUtils.isNotEmpty(servicePersonId.toString())?CommonUtils.getUserNameAndCodeById(users, servicePersonId.toString()):"");
//			map.put("skillPersonName",skillPersonId!=null&&StringUtils.isNotEmpty(skillPersonId.toString())?CommonUtils.getUserNameAndCodeById(users, skillPersonId.toString()):"");
			
			
			String oString=orgName!=null?orgName.toString().replaceAll("!","/"):null;
			map.put(ISysUserDao.FIELD_ORGNAME,oString );
		}
		
		return	UTExcel.leadingout( fileds, data, tamlate, request,response);
	}


	//进行逻辑删除
	@Override
	@EscOptionLog(module=SystemModule.outsourcePersonList, opType=ESCLogOpType.DELETES, table="outsource_person_list",
	primaryKey="id={1}",option="删除外包人员信息")
	public boolean deleteOutSouceByUserIds(String userIds) {
		Map<String, Object> map=new HashMap<String, Object>();
		map.put("state",0);
		map.put("userId",userIds);
		return super.updates(map, "userId");
	}


	@Override
	public UTMap<String, Object> getOutEmpByUserId(String userId) {
		return outSourcePersonDao.getOutEmpByUserId(userId);
	}


	@Override
	public Map<String, Object> getOutEmpAgreementById(String userId) {
		Map<String, Object> param=new HashMap<String, Object>();
		param.put(IOutSourcePersonDao.FIELD_USERID, userId);
		List<UTMap<String, Object>> list=outSourcePersonDao.getListMaps(param, IOutSourcePersonDao.FIELD_AGREEMENTID);
		String agreementId=list!=null&&list.size()>0?list.get(0).get("id").toString():null;
		return StringUtils.isNotEmpty(agreementId)?agreementManpowerInfoService.getAgreementManpowerByAgreementId(agreementId):null;
	}


	
	
}
