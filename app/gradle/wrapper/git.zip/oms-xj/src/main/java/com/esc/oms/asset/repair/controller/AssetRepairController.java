package com.esc.oms.asset.repair.controller;

import com.esc.oms.asset.collar.service.IAssetCollarService;
import com.esc.oms.asset.overview.service.IAssetsTrackInfoService;
import com.esc.oms.asset.physical.service.IAssetPhysicalService;
import com.esc.oms.asset.repair.service.IAssetRepairService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ExcelUtil;
import com.esc.oms.util.FunctionEnum;
import com.esc.oms.util.FunctionEnum.AssetRepairApplyType;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.esc.framework.workflow.service.IWorkflowEngine;
import org.esc.framework.workflow.service.impl.WorkflowInstanceDiagramImpl;
import org.esc.framework.workflow.utils.bpmn.Instance;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
@Controller
@RequestMapping("assetRepairPage")
public class AssetRepairController extends BaseOptionController {

	@Resource
	private IAssetRepairService assetRepairService;
	
	@Resource
	private IUserTaskService userTaskService;
	
	@Resource
	private IAssetCollarService assetCollarService;
	
	@Resource
	private IAssetPhysicalService assetPhysicalService;
	

	@Resource
	private IAssetsTrackInfoService assetsTrackInfoService;
	
	@Resource
	private WorkflowInstanceDiagramImpl processInstanceDiagramCmd;
	
	@Resource
	private IWorkflowEngine workflowEngine;
	
	@Override
	public IBaseOptionService optionService() {
		return assetRepairService;
	}
	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			assetRepairService.getPageInfo(pageBean, params);
			List<Map<String, Object>> list = pageBean.getRows();
			if(null != list && list.size() > 0 ){
				for (Map<String, Object> map : list) {
					if(null != map.get("result")){
						if((Integer)map.get("result") == 1){
							map.put("result", "维修成功");
						}else{
							map.put("result", "维修失败");
						}
					}
				}
			}
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	

	@RequestMapping(value="save", method=RequestMethod.POST)  
    @ResponseBody
    public Map<String, Object> save(@RequestBody Map<String,Object> map) {
		try {
			assetRepairService.save(map);
			map.put("success", true);
			map.put("msg", "操作成功！");
    	}catch(EscServiceException e){
    		map.put("success", false);
    		map.put("msg", e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		map.put("success", false);
    		map.put("msg", "操作失败！");
    	}
       return map;
	}
	
	/**
	 * 提交审批
	 * @param map
	 * @return
	 */
	@RequestMapping(value="submit", method=RequestMethod.POST)  
    @ResponseBody
    public Map<String, Object> submit(@RequestBody Map<String,Object> map) {
		try{
			assetRepairService.submit(map);
			map.put("success", true);
			map.put("msg", "操作成功！");
    	}catch(EscServiceException e){
    		map.put("success", false);
    		map.put("msg", e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		map.put("success", false);
    		map.put("msg", "操作失败！");
    	}
       return map;
	}
	
	@RequestMapping(value="finishRejectTask", method=RequestMethod.POST)  
    @ResponseBody
    public void finishRejectTask(@RequestBody Map<String,Object> map) {
		assetRepairService.finishRejectTask(map.get("id").toString());
	}
    
    /**
	 * 根据id查询
	 * @param param
	 * @return
	 */
	@RequestMapping(value="getById")
	@ResponseBody
	public UTMap<String, Object> defgetById(@RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = new UTMap<String, Object>();
    	try{
    		if(null != param.get("id")){
    			map = optionService().getById((String)param.get("id"));
    			if(null != map){
    				UTMap<String,Object> assets = assetCollarService.getAssetByAssetId(String.valueOf(map.get("assetsId")));
    				if(null != assets){
    					map.put("assetsName", assets.get("assetsNameCode"));
    					map.put("maintainContract", assets.get("maintainContract"));
    					map.put("supplierId", assets.get("supplierId"));
    					map.put("assetsBrand", assets.get("assetsBrand"));
    					map.put("assetsModel", assets.get("assetsModel"));
    				}
    			}
    		}
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return map;
	}
	
	/**
	 * 报修结果确认导出
	 * @param param
	 * @return
	 */
	@RequestMapping(value="exportByData")
	@ResponseBody
	public void exportByData(HttpServletRequest request, HttpServletResponse response, @RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = new UTMap<String, Object>();
		UTMap<String,Object> resultByRepair = new UTMap<String, Object>();
	  
    	try{
    		if(null != param.get("id")){
    			map = optionService().getById((String)param.get("id"));
    			if(null != map){
    				String orgLongName = assetRepairService.getOrgLongNameById(map.get("applyUnit").toString()).get("longName").toString();
    				String applyTypeName = AssetRepairApplyType.getName(map.get("applyType").toString());
    				map.put("orgLongName", orgLongName);
    				map.put("applyTypeName", applyTypeName);
    				UTMap<String,Object> assets = assetCollarService.getAssetByAssetId(String.valueOf(map.get("assetsId")));
    				if(null != assets){
    					map.put("assetsName", assets.get("assetsNameCode"));
    					map.put("maintainContractAll", assets.get("maintainContractAll"));
    					map.put("buyContractName", assets.get("buyContractName"));
    					map.put("buyContractSupplier", assets.get("buyContractSupplier"));
    					map.put("assetsBrand", assets.get("assetsBrand"));
    					map.put("assetsModel", assets.get("assetsModel"));
    				}
    			}
    			resultByRepair = assetRepairService.getResultByRepairId(param.get("id").toString());
    			String resultName = "";
    			if(resultByRepair.get("result") != null)
    				resultName = FunctionEnum.AssetRepairResultType.getName(resultByRepair.get("result").toString());
				resultByRepair.put("resultName", resultName);
    			
    			//创建一个表格
    			HSSFWorkbook wb = new HSSFWorkbook();
    			String recordId = param.get("id").toString();
    			String workflowCode = "physical_asset_repairs";
    			//流程审批信息
    	        Instance instance = workflowEngine.getInstance(workflowCode, recordId);
    	        List<Object[]> instanceList = new ArrayList<Object[]>();
    	        if (instance != null) {
    	            instance.setAuditInfoList(workflowEngine.getShowAuditInfoList(instance.getInstanceId()));
    	            List<UTMap<String, Object>> maps = workflowEngine.getShowAuditInfoList(instance.getInstanceId());
    	            for(UTMap<String, Object> map2 : maps)
    	            {
    	            	Object[] objs = new Object[5];
    	    	        objs[0] = map2.get("nodeName")==null? "" : map2.get("nodeName").toString();
    	    	        objs[1] = map2.get("createUser")==null? "" : map2.get("createUser").toString();
    	    	        objs[2] = map2.get("createTime")==null? "" : map2.get("createTime").toString();
    	    	        objs[3] = map2.get("auditResult")==null? "" : map2.get("auditResult").toString();
    	    	        objs[4] = map2.get("auditComment")==null? "" : map2.get("auditComment").toString();
    	    	        instanceList.add(objs);
    	            }
    	        }
    			response.setCharacterEncoding("UTF-8");
    			response.setContentType("application/vnd.ms-excel");
    			String fileName = "报修申请记录.xls";
    			fileName = URLEncoder.encode(fileName, "UTF-8");
    			response.addHeader("Content-Disposition", "attachment;filename=" + fileName);
    					
    			exportRepairApply(wb, map, resultByRepair, instanceList);
    			
    			try {
					OutputStream out = response.getOutputStream();
	    			wb.write(out);
	    			out.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

    		}    		    		
		}catch(Exception e){
			logger.error("Exception", e);
    	}
	}
	
	private void exportRepairApply(HSSFWorkbook wb, UTMap<String, Object> map, UTMap<String,Object> resultByRepair, List<Object[]> instanceList) 
	{
        String sheetName = "报修申请";
        //定义表的内容
        List<Object[]> dataList = new ArrayList<Object[]>();
        Object[] objs = new Object[11];
        objs[0] = map.get("assetsName")==null? "" : map.get("assetsName").toString();
        objs[1] = map.get("buyContractName")==null? "" : map.get("buyContractName").toString();
        objs[2] = map.get("buyContractSupplier")==null? "" : map.get("buyContractSupplier").toString();
        objs[3] = map.get("maintainContractAll")==null? "" : map.get("maintainContractAll").toString();
        objs[4] = map.get("assetsBrand")==null? "" : map.get("assetsBrand").toString();
        objs[5] = map.get("assetsModel")==null? "" : map.get("assetsModel").toString();
        objs[6] = map.get("applyTypeName")==null? "" : map.get("applyTypeName").toString();
        objs[7] = map.get("orgLongName")==null? "" : map.get("orgLongName").toString();
        objs[8] = map.get("budget")==null? "" : map.get("budget").toString();
        objs[9] = map.get("reason")==null? "" : map.get("reason").toString();
        objs[10] = map.get("remark")==null? "" : map.get("remark").toString();
        dataList.add(objs);
        
        String[] rowsName = new String[] { "序号", "节点", "提交人", "提交时间", "审批结果", "审批意见" };

        Object[] objs2 = new Object[7];
        objs2[0] = resultByRepair.get("beginDate")==null? "" : resultByRepair.get("beginDate").toString();
        objs2[1] = resultByRepair.get("endDate")==null? "" : resultByRepair.get("endDate").toString();
        objs2[2] = resultByRepair.get("repairUser")==null? "" : resultByRepair.get("repairUser").toString();
        objs2[3] = resultByRepair.get("repairPhone")==null? "" : resultByRepair.get("repairPhone").toString();
        objs2[4] = resultByRepair.get("cost")==null? "" : resultByRepair.get("cost").toString();
        objs2[5] = resultByRepair.get("resultName")==null? "" : resultByRepair.get("resultName").toString();
        objs2[6] = resultByRepair.get("resultRemark")==null? "" : resultByRepair.get("resultRemark").toString();
        
        // 创建ExportExcel对象
        ExcelUtil excelUtil = new ExcelUtil();
        try{
            excelUtil.exportAssetRepair(sheetName, "报修申请单", dataList, wb);
            excelUtil.exportAssetApplyInstance(sheetName, "流程详情", rowsName, instanceList, wb, 11, false);
            excelUtil.exportAssetRepairResult(sheetName, "报修结果", objs2, wb, 15 + instanceList.size(), false);
        }catch(Exception e){
            e.printStackTrace();
        }
	}
	
	@RequestMapping(value="addRepairResult",method =RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> addRepairResult(@RequestBody  Map<String, Object> map1){
		Map<String, Object> info = CommonUtils.clone(map1);
		
		String repairId = (String)info.get("repairId");
		try{
			info.put("repairId", repairId);
			assetRepairService.addRepairResult(info);
			UTMap<String,Object> ut = new UTMap<String,Object>();
			ut.put("id", repairId);
			ut.put("status", (Integer)info.get("status"));
			assetRepairService.updateById(ut);
			userTaskService.finishTask(repairId, "实物资产报修");
			
			
			//====添加资产轨迹---报修============
			UTMap<String,Object> track = new UTMap<String,Object>();
			UTMap<String,Object> repair = assetRepairService.getById(repairId);
			if(null != repair){
				UTMap<String,Object> asset = assetPhysicalService.getById(String.valueOf(repair.get("assetsId")));
				if(null != asset){
					
					track.put("assetsId", repair.get("assetsId"));
					track.put("type", 1);//实物资产
					if(StringUtils.isNotEmpty((String)asset.get("resDepartId"))){
						track.put("departId", (String)asset.get("resDepartId"));
					}
					if(StringUtils.isNotEmpty((String)asset.get("resUserId"))){
						track.put("userId", (String)asset.get("resUserId"));
					}
					track.put("changeType","报修");
					track.put("changeTime", info.get("endDate"));
					track.put("changeRemark", info.get("beginDate")+"到"+info.get("endDate")+"期间进行报修");
					assetsTrackInfoService.add(track);
					
					//=====报修结果填完后将资产状态改为使用中=====
					UTMap<String,Object> updateAssets = new UTMap<String,Object>();
					updateAssets.put("id", String.valueOf(repair.get("assetsId")));
					updateAssets.put("assetStatus","2");
					assetPhysicalService.updateById(updateAssets);
					
				}
			}
    		info.put("success", true);
    		info.put("msg", "操作成功！");
    	}catch(Exception e){
    		logger.error("Exception", e);
    		info.put("success", false);
    		info.put("msg", "操作失败！");
    	}
       return info;
	}
	
	@RequestMapping(value="updateRepairResult")
	@ResponseBody
	public String updateRepairResult(@RequestBody  Map<String, Object> info){
		String repairId = (String)info.get("repairId");
		try{
			assetRepairService.updateRepairResultById(info);
			UTMap<String,Object> ut = new UTMap<String,Object>();
			ut.put("id", repairId);
			ut.put("status", (Integer)info.get("status"));
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "操作成功");
	}
	
	/**
	 * 根据id查询
	 * @param param
	 * @return
	 */
	@RequestMapping(value="getRepairResultByRepairId")
	@ResponseBody
	public UTMap<String, Object> getRepairResultByRepairId(@RequestParam  Map<String, Object> param){		
		UTMap<String,Object> resultByRepair = null;
   	try{
   		resultByRepair = assetRepairService.getResultByRepairId(param.get("repairId").toString());
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
   	}
	   	if(null == resultByRepair){
	   		return new UTMap<String, Object>();
	   	}else{
	   		return resultByRepair;
	   	}
	}
	
	
	@RequestMapping(value="getAssetsRepairRateCount")  
    @ResponseBody
    public UTPageBean getAssetsRepairRateCount(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			assetRepairService.getAssetsRepairRateCount(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	@RequestMapping(value = "leadingout")
	@ResponseBody
	public void leadingout(@RequestParam Map<String, Object> param,
			HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = null;
			if(info != null) {
				jsonBean = JSONObject.fromObject(info);
			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = assetRepairService.getAssetsList(jsonBean);
			} else {
			// 根据条件 导出当前
			//if (UTExcel.EXCELOUTTYPE_NOW == outType) {
				// getpage
				assetRepairService.getPageInfo(utPageBean, jsonBean);
				data = utPageBean.getRows();
			}
			for(UTMap<String, Object> map : data)
			{
				map.put("name", map.get("assetsId"));
				map.put("statusDesc", FunctionEnum.AssetRepairStatusType.getName(map.get("status").toString()));
				String resultDesc = "";
				if(map.get("result") != null)
					resultDesc = FunctionEnum.AssetRepairResultType.getName(map.get("result").toString());
				map.put("resultDesc", resultDesc);
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			assetRepairService.leadingout(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
}