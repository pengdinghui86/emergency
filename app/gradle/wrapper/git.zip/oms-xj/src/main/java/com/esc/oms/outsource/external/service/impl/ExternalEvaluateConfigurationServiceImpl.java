package com.esc.oms.outsource.external.service.impl;

import com.esc.oms.outsource.external.dao.IExternalEvaluateConfigurationDao;
import com.esc.oms.outsource.external.dao.IExternalEvaluateDao;
import com.esc.oms.outsource.external.dao.IExternalEvaluateTemplateDao;
import com.esc.oms.outsource.external.dao.IExternalResultEvaluateDao;
import com.esc.oms.outsource.external.service.IExternalEvaluateConfigurationService;
import com.esc.oms.outsource.external.service.IExternalEvaluateService;
import com.esc.oms.supplier.info.service.ISupplierBaseInfoService;
import com.esc.oms.system.service.ISendMessage;
import com.esc.oms.system.templateconfiguration.dao.ITemplateConfigurationDetailDeputyDao;
import com.esc.oms.system.templateconfiguration.dao.ITemplateConfigurationDetailDeputyResultDao;
import com.esc.oms.system.templateconfiguration.service.ITemplateConfigurationDetailDeputyService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;
import com.esc.oms.util.TaskModel;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.*;

/**
 * 非驻场外包评估配置
 * @author owner
 *
 */
@Service
@Transactional
public class ExternalEvaluateConfigurationServiceImpl extends BaseOptionService implements IExternalEvaluateConfigurationService,ISendMessage{
	
	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private IExternalEvaluateConfigurationDao dao;
	
	//模板配置详情dao
	@Resource
	private IExternalEvaluateTemplateDao externalEvaluateTemplateDao;
	
	//模板配置详情副表操作dao
	@Resource
	private ITemplateConfigurationDetailDeputyDao templateConfigurationDetailDeputyDao;
	
	//非驻场外包评估
	@Resource
	private IExternalEvaluateDao externalEvaluateDao;
	
	//非驻场外包结果评估
	@Resource
	private IExternalResultEvaluateDao externalResultEvaluateDao;
	
	//非驻场外包评估
	@Resource
	private IExternalEvaluateService externalEvaluateService;
	
	//模板配置从属数据操作Service接口
	@Resource
	private ITemplateConfigurationDetailDeputyService templateConfigurationDetailDeputyService;
	
	//模板配置从属数据结果操作dao接口
	@Resource
	private ITemplateConfigurationDetailDeputyResultDao templateConfigurationDetailDeputyResultDao;
	
	//供应商
	@Resource
	private ISupplierBaseInfoService supplierBaseInfoService;

	//代办任务
	@Resource
	private IUserTaskService userTaskService;
	
	@Resource
	private MessageSend messageService;
	
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return dao;
	}

	/**
	 * 添加
	 * @param info
	 * @return
	 */
//	@UploadAddMark//aop拦截绑定上传文件的数据关系
	@EscOptionLog(module = SystemModule.externalEvaluateConfiguration, opType = ESCLogOpType.INSERT, table = "outsourc_external_evaluate_configuration", option = "新增评估标题为{evaluateTitle}的非驻场外包检查配置。")
	public boolean add(Map info){
		String evaluateTitle = info.get("evaluateTitle").toString();//评估标题
		String templateConfigurationId = info.get("templateConfigurationId")==null?"":info.get("templateConfigurationId").toString();//全面评估结果填报模板
		Map param = new HashMap();
		param.put("evaluateTitle", evaluateTitle);
		if(dao.isExist(param)){
			throw new EscServiceException(evaluateTitle+"已经存在！");
		}
		info.put("status", 0);//评估状态,初始是待评估0
		info.put("count", 0);//评估次数
		info.put("evaluateStatus", 0);//只标识供应商准入评估模板对应的个人准入评估是否已经在评估，待评估：0，评估中：1，已评估：2
		super.add(info);
		String id = info.get("id") + "";
		//初始化全面评估结果填报模板副表数据
		templateConfigurationDetailDeputyDao.initDataByTemplateConfigurationId(templateConfigurationId, id);
//		List templateList = (List)info.get("templateList");//模板列表
		generateData(info);
//		addSubData(id, templateList);
		return true;
	}
	
	/**
	 * 生成评估数据
	 * @param id
	 */
	public void generateData(Map info){
		String id = info.get("id")+"";
		String evaluateTitle = info.get("evaluateTitle")+"";
		String beginDate = info.get("beginDate")+"";
//		Map param = new HashMap();
//		param.put("externalEvaluateConfigId", id);
		//模板列表
//		List<UTMap<String, Object>> templateList = externalEvaluateTemplateDao.getListMaps(param);
		List templateList = (List)info.get("templateList");//模板列表
		String supplierId = info.get("supplierId").toString();//供应商id
		//生成过程评估数据
//		String cDateTime = UTDate.getCurDateTime();//数据的生成时间，保证同一批数据生成的时间是一致的
//		Set<String> userSet = new HashSet<String>();
		UTMap<String, Object> supplier =  supplierBaseInfoService.getById(supplierId);
		Map evaluateMap = new HashMap();
		evaluateMap.put("evaluateTitle", info.get("evaluateTitle"));//评估标题
		evaluateMap.put("beginDate", beginDate);//开始日期
		evaluateMap.put("endDate", info.get("endDate"));//结束日期
		evaluateMap.put("evaluateRemark", info.get("evaluateRemark"));//评估说明
		evaluateMap.put("supplierId", supplierId);//供应商id
		evaluateMap.put("dataType", 1);//数据类型（1：评估配置的数据，2：新增的数据）
		evaluateMap.put("externalEvaluateConfigId", id);//非驻场外包评估配置id
		evaluateMap.put("status", 0);//状态
//		evaluateMap.put("generateTime", cDateTime);//数据的生成时间，保证同一批数据生成的时间是一致的
		externalResultEvaluateDao.add(evaluateMap);
		String externalResultEvaluateId = evaluateMap.get("id")+"";
		for (Object object : templateList) {
			Map map = (Map)object;
			String templateConfigurationId = map.get("templateConfigurationId")==null?null:map.get("templateConfigurationId").toString();//原始模板id
			String evaluateBeginDate = map.get("evaluateBeginDate")+"";//过程评估开始日期
			String taskBeginDate = "" ;
			
			//如果过程评估开始日期在当天之前则待办任务开始日期显示为当天
			if(UTDate.parseDate(evaluateBeginDate).before(new Date())){
				taskBeginDate = UTDate.getCurDate();
			}else{
				taskBeginDate = evaluateBeginDate;
			}
			
			String evaluateName = map.get("evaluateName")+"";//过程评估标题
			String isSingle = map.get("isSingle")+"";//是否单一数据，1：是，0：否，默认否
			map.put("externalEvaluateConfigId", id);//非驻场外包评估配置id
			map.put("id", null);
			externalEvaluateTemplateDao.add(map);
			String externalEvaluateTemplateId = map.get("id") + "";//初始化全面评估结果填报模板副表数据
			//初始化评估模板详情副表数据
			templateConfigurationDetailDeputyDao.initDataByTemplateConfigurationId(templateConfigurationId, externalEvaluateTemplateId);
//			Map map = (Map)object;
			
//			String externalEvaluateTemplateId = map.get("id") + "";
			String evaluator = map.get("evaluator").toString();
			//评估人列表
			String[] evaluatorArr = evaluator.split(",");
			String title = "非驻场外包检查评估";
			String content = "【"+info.get("evaluateTitle")+"】下过程评估【"+evaluateName+"】的供应商【"+supplier.get("name")+"】待评估";
			//根据评估人初始化准入评估表的数据
			if("1".equals(isSingle)){//是单一数据
				evaluateMap = new HashMap();
				evaluateMap.put("externalResultEvaluateId", externalResultEvaluateId);//对应的检查结果id
				evaluateMap.put("supplierId", supplierId);//供应商id
				evaluateMap.put("externalEvaluateTemplateId", externalEvaluateTemplateId);//评估模板id
				evaluateMap.put("evaluator", map.get("evaluator").toString());//评估人
				evaluateMap.put("externalEvaluateConfigId", id);//非驻场外包评估配置id
				evaluateMap.put("status", 0);//状态
//				evaluateMap.put("generateTime", cDateTime);//数据的生成时间，保证同一批数据生成的时间是一致的
				externalEvaluateDao.add(evaluateMap);
				for (String evaluatorId : evaluatorArr) {
//					userSet.add(evaluatorId);
					userTaskService.addTaskByUserId(content, evaluateMap.get("id")+"",title, TaskModel.externalEvaluate, evaluatorId, taskBeginDate, externalResultEvaluateId);
				}
			}else{
				for (String evaluatorId : evaluatorArr) {
//					userSet.add(evaluatorId);
					evaluateMap = new HashMap();
					evaluateMap.put("externalResultEvaluateId", externalResultEvaluateId);//对应的检查结果id
					evaluateMap.put("supplierId", supplierId);//供应商id
					evaluateMap.put("externalEvaluateTemplateId", externalEvaluateTemplateId);//评估模板id
					evaluateMap.put("evaluator", evaluatorId);//评估人
					evaluateMap.put("externalEvaluateConfigId", id);//非驻场外包评估配置id
					evaluateMap.put("status", 0);//状态
//					evaluateMap.put("generateTime", cDateTime);//数据的生成时间，保证同一批数据生成的时间是一致的
					externalEvaluateDao.add(evaluateMap);
					userTaskService.addTaskByUserId(content, evaluateMap.get("id")+"",title, TaskModel.externalEvaluate, evaluatorId, taskBeginDate, externalResultEvaluateId);
				}
			}
			//判断beginDate是否在当前时间之前，如果是则马上发送提醒消息，否则通过定时任务检测来发送提醒消息
			if(!UTDate.dateCompare(UTDate.getCurDate(),evaluateBeginDate , UTDate.DATE_FORMAT)){
				sendMessage(evaluateTitle ,evaluateName, evaluator);
			}
		}
		
		
	}
	
	@Override
	public void sendMessage() {
		logger.info("检查发送非驻场外包评估消息提醒");
		try{
			Map param = new HashMap();
			param.put("isSendMessageDate", true);
			//查询出当天需要发送消息的数据
			List<UTMap<String, Object>> accessEvaluates = externalEvaluateDao.getListAll(param);
			if(accessEvaluates != null){
				for (UTMap<String, Object> accessEvaluate : accessEvaluates) {
					String evaluateTitle = accessEvaluate.get("evaluateTitle")+"";//评估配置标题
					String evaluateName = accessEvaluate.get("evaluateName")+"";//过程评估标题
					String evaluator = accessEvaluate.get("evaluator")+"";//评估人列表
					sendMessage(evaluateTitle,evaluateName, evaluator);
				}
			}
		}catch(Exception ex){
			logger.error("非驻场外包评估消息提醒异常",ex);
		}
	
//		try{
//			Map param = new HashMap();
//			param.put("isSendMessageDate", true);
//			//查询出当天需要发送消息的数据
//			List<UTMap<String, Object>> accessEvaluateConfigs = this.getListMaps(param);
//			if(accessEvaluateConfigs != null){
//				for (UTMap<String, Object> accessEvaluateConfig : accessEvaluateConfigs) {
//					String evaluateTitle = accessEvaluateConfig.get("evaluateTitle")+"";
//					Set<String> userSet = new HashSet<String>();
//					param.clear();
//					param.put("externalEvaluateConfigId", accessEvaluateConfig.get("id"));
//					List<UTMap<String, Object>> accessEvaluates = externalEvaluateDao.getListMaps(param);
//					if(accessEvaluates != null){
//						for (UTMap<String, Object> accessEvaluate : accessEvaluates) {
//							userSet.add(accessEvaluate.get("evaluator")+"");
//						}
//					}
//					sendMessage(evaluateTitle, userSet);
//				}
//			}
//		}catch(Exception ex){
//			logger.error("外包审计评估消息提醒异常",ex);
//		}
	}
	
	private void sendMessage(String evaluateTitle,String evaluateName,String userIds){
		String title = "非驻场外包检查提醒";
		String content = "非驻场外包【"+evaluateTitle+"】下的过程评估【"+evaluateName+"】已开始，请进入系统进行评价";
//		String userIds = CommonUtils.hashSetToString(userSet);
		logger.info(CommonUtils.vaildLog(title+":"+userIds));
		messageService.sendMessage(userIds,title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
	}
	
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		UTMap<String, Object> result = super.getById(id);
		Map param = new HashMap();
		param.put("externalEvaluateConfigId", id);
		//模板列表
		result.put("templateList", externalEvaluateTemplateDao.getListMaps(param));
//		formatDataToExcel(id);
		return result;
	}
	
	/**
	 * 根据ID 获取（评估结果需要的数据接口）
	 * @param info
	 * @return
	 */
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getByIdToAccessResult(String id){
		UTMap<String, Object> result = super.getById(id);
		Map param = new HashMap();
		param.put("externalEvaluateConfigId", id);
		param.put("isAccessEvaluateList", true);//过程考核数据展示排序按考核名称排，列表按时间排
		//评估人评估列表
		result.put("accessEvaluateList", externalEvaluateService.getListAll(param));
		String submitter = result.get("submitter")+"";//提交人
		result.put("treeData", templateConfigurationDetailDeputyService.getDetailsDeputy(id, submitter));
//		formatDataToExcel(id);
		return result;
	}
	
	
	
	/**
	 * 修改
	 * @param info
	 * @return
	 */
//	@UploadAddMark//aop拦截绑定上传文件的数据关系
	@EscOptionLog(module = SystemModule.externalEvaluateConfiguration, opType = ESCLogOpType.UPDATE, table = "outsourc_external_evaluate_configuration", option = "更新评估标题为{evaluateTitle}的非驻场外包检查配置。")
	public boolean updateById(Map info){
		String id = info.get("id") + "";
		Map evaluateMap = new HashMap();
		evaluateMap.put("externalEvaluateConfigId", id);//非驻场外包评估配置id
		externalResultEvaluateDao.delete(evaluateMap);
		deleteSubData(id);
//		List templateList = (List)info.get("templateList");//模板列表
//		addSubData(id, templateList);
		String templateConfigurationId = info.get("templateConfigurationId")==null?"":info.get("templateConfigurationId").toString();//全面评估结果填报模板
		//初始化全面评估结果填报模板副表数据
		templateConfigurationDetailDeputyDao.initDataByTemplateConfigurationId(templateConfigurationId, id);
		generateData(info);
		return super.updateById(info);
	}
	
	/**
	 * 总评估或者修改总评估
	 * @param info
	 * @return
	 */
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	@EscOptionLog(module = SystemModule.externalEvaluateConfiguration, opType = ESCLogOpType.UPDATE, table = "outsourc_external_evaluate_configuration", option = "评估评估标题为{evaluateTitle}的非驻场外包检查配置。")
	public boolean evaluate(Map info){
		info.put("submitTime", UTDate.getCurDateTime());//提交时间
		String status = info.get("status")+"";
		info.put("status", 1);//评估状态，未评估：0，已评估：1
		
		List<Map> resultList = new ArrayList<Map>();
		List<Map> list= (List<Map>)info.get("treeData");
		String moduleTemplateConfigurationId = info.get("id")+"";
		String submitter;//提交人作为评估结果（evaluator）绑定的数据字典
		if("0".equals(status)){//如果还未评估，评估的时候submitter取当前正在评估的用户
			submitter = EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId();
		}else{
			submitter = info.get("submitter")+"";//提交人作为评估结果（evaluator）绑定的数据字段
		}
		//先删除
		templateConfigurationDetailDeputyResultDao.deleteByModuleTemplateConfigurationIdEvaluator(moduleTemplateConfigurationId, submitter);
		submitter = EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId();//重新获取当前的操作人，用于绑定评估结果数据，避免“供应商管理员”有多个人都在修改评估结果，导致无法根据评估人（evaluator）查找到相应的数据
		CommonUtils.setTemplateConfigurationDetailDeputyResult(moduleTemplateConfigurationId, submitter, list, resultList);
		if(!resultList.isEmpty()){
			//后添加
			templateConfigurationDetailDeputyResultDao.adds(resultList);
			
		}
		info.put("submitter", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());//提交人
		return super.updateById(info);
	}
	
	/**
	 * 关闭
	 * @param info
	 * @return
	 */
	@EscOptionLog(module = SystemModule.externalEvaluateConfiguration, opType = ESCLogOpType.UPDATE, table = "outsourc_external_evaluate_configuration", option = "关闭评估标题为{evaluateTitle}的非驻场外包检查配置。")
	public boolean close(Map info){
		info.put("closeTime", UTDate.getCurDateTime());//关闭时间
		info.put("status", 2);//评估状态
		return super.updateById(info);
	}
	
	@Override
	@EscOptionLog(module = SystemModule.externalEvaluateConfiguration, opType = ESCLogOpType.DELETE, table = "outsourc_external_evaluate_configuration", primaryKey="id={1}", option = "删除评估标题为{evaluateTitle}的非驻场外包检查配置。")
	public boolean deleteById(String id) {
//		Map param = new HashMap();
//		param.put("accessEvaluateConfigId", id);
//		//模板列表
//		List<UTMap<String, Object>> list = accessEvaluateTemplateDao.getListMaps(param);
//		if(list != null){
//			for (UTMap<String, Object> utMap : list) {
//				String accessEvaluateTemplateId = utMap.get("id") + "";
//				Map info = new HashMap();
//				info.put("accessEvaluateTemplateId", accessEvaluateTemplateId);//准入评估配置模板id
//				accessEvaluateDao.delete(info);
//				templateConfigurationDetailDeputyDao.delete(info);
//				accessEvaluateTemplateDao.deleteByIds(accessEvaluateTemplateId);
//			}
//		}
		deleteSubData(id);
		return super.deleteById(id);
	}
	
//	private void addSubData(String id, List templateList){
//		if(templateList != null){
//			for (Object object : templateList) {
//				Map map = (Map)object;
//				String templateConfigurationId = map.get("templateConfigurationId")+"";//原始模板id
//				map.put("externalEvaluateConfigId", id);//非驻场外包评估配置id
//				externalEvaluateTemplateDao.add(map);
//				String externalEvaluateTemplateId = map.get("id") + "";
//				//初始化评估模板详情副表数据
//				templateConfigurationDetailDeputyDao.initDataByTemplateConfigurationId(templateConfigurationId, externalEvaluateTemplateId);
//				//评估人列表
////				String evaluator = map.get("evaluator") + "";
////				if(StringUtils.isNotEmpty(evaluator)){
////					String[] evaluatorArr = evaluator.split(",");
////					//根据评估人初始化准入评估表的数据
////					for (String evaluatorId : evaluatorArr) {
////						Map evaluateMap = new HashMap();
////						evaluateMap.put("externalEvaluateTemplateId", externalEvaluateTemplateId);//评估模板id
////						evaluateMap.put("evaluator", evaluatorId);//评估人
////						evaluateMap.put("externalEvaluateConfigId", id);//非驻场外包评估配置id
////						evaluateMap.put("status", 0);//状态
////						externalEvaluateDao.add(evaluateMap);
////					}
////				}
//			}
//		}
//	}
	
	private void deleteSubData(String id){
		Map info = new HashMap();
		info.put("moduleTemplateConfigurationId", id);
		//先删除全面评估结果需要填报的模板副表数据
		templateConfigurationDetailDeputyDao.delete(info);
		Map param = new HashMap();
		param.put("externalEvaluateConfigId", id);
		//模板列表
		List<UTMap<String, Object>> list = externalEvaluateTemplateDao.getListMaps(param);
		if(list != null){
			for (UTMap<String, Object> utMap : list) {
				String externalEvaluateTemplateId = utMap.get("id") + "";
				info = new HashMap();
				info.put("externalEvaluateTemplateId", externalEvaluateTemplateId);//准入评估配置模板id
				externalEvaluateDao.delete(info);
				info.remove("externalEvaluateTemplateId");
				info.put("moduleTemplateConfigurationId", externalEvaluateTemplateId);
				templateConfigurationDetailDeputyDao.delete(info);
				externalEvaluateTemplateDao.deleteByIds(externalEvaluateTemplateId);
			}
		}
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map param) {
		dao.getPageInfo(pageBean, param);
	}
	

}
