package com.esc.oms.asset.physical.service.impl;

import com.esc.oms.asset.assetCategory.dao.IAssetCategoryDao;
import com.esc.oms.asset.physical.dao.IAssetPhysicalDao;
import com.esc.oms.asset.physical.service.IAssetPhysicalAspectService;
import com.esc.oms.asset.physical.service.IAssetPhysicalService;
import com.esc.oms.asset.place.dao.IAssetPlaceDao;
import com.esc.oms.util.CommonUtils;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Service
public class AssetPhysicalAspectServiceImpl implements IAssetPhysicalAspectService {

    @Resource
    private IAssetPhysicalService assetPhysicalService;
    @Resource
    private IAssetPhysicalDao assetPhysicalDao;
    @Resource
    IAssetPlaceDao assetPlaceDao;
    @Resource
    IAssetCategoryDao assetCategoryDao;
    @Override
    public String saveOrUpdate(Map<String, Object> map) {
        //分成两部分保存，一部分是资产的公共属性，一部分是资产的特有属性
        Map<String, Object> mainMap = (Map<String, Object>)map.get("formDataMain");
        Map<String, Object> extMap = (map.get("formData") == null || map.size()<1)?null : (Map<String, Object>)map.get("formData");
        List<Map> sparePartList =  (List<Map>) mainMap.get("sparePartList");
        String codeNum = (String)mainMap.get("codeNum");
        String id = (String)mainMap.get("id");
        String serialNum = (String)mainMap.get("serialNum");
        mainMap.put("deleteFlag", 0);
        //判断报废状态
        String assetStatus = mainMap.get("assetStatus")!= null ? (mainMap.get("assetStatus")+"") : null;
        if("5".equals(assetStatus)){
            mainMap.put("isScrap", 1);
        }else{//不是报废状态，则需要清除报废日期
            mainMap.remove("scrapDate");
            mainMap.put("isScrap", 0);
        }
        boolean flag = false;
        if(id == null){
            Map param = new HashMap();
            if(CommonUtils.notNullStrOrEmpty(codeNum)){
                param.put("codeNum", codeNum);
                if(assetPhysicalService.isExist(param)){
                    throw new EscServiceException("资产编号已经存在！");
                }
            }
            //判断资产序列号是否为空
            param.clear();
            if(CommonUtils.notNullStrOrEmpty(serialNum)){
                param.put("serialNum", serialNum);
                param.put("deleteFlag", 0);
                if(assetPhysicalService.isExist(param)){
                    throw new EscServiceException("资产序列号已经存在！");
                }
            }
            //关于sn号
            mainMap.put("sn",assetPhysicalService.getSnNum());
            //从参数中获取sn号，并回去修改sn号，此方法必须同步
            //关于编码值
            mainMap.put("code", mainMap.get("sn"));
            flag = assetPhysicalService.add(mainMap);
            id = (String) mainMap.get("id");//添加后获取id的值

        }else{
            if(StringUtils.isNotEmpty(codeNum)){
                List<UTMap<String,Object>> names = assetPhysicalService.getAssetBycodeAndId(codeNum,id);
                if(null != names && names.size() > 0){
                    throw new EscServiceException("资产编号已经存在！");
                }
            }
            if(CommonUtils.notNullStrOrEmpty(serialNum) && assetPhysicalDao.isExitSerialNum(serialNum, id)){
                throw new EscServiceException("资产序列号已经存在！");
            }
            //如果传过来的registStatus存在且为
            flag = assetPhysicalService.updateById(mainMap);
        }
        if(flag){
            assetPhysicalService.deleteSparesById((String)mainMap.get("id"));//先删除关联再重新添加关联
            if(null != sparePartList && sparePartList.size() > 0){
                for (Map sparePart : sparePartList) {
                    UTMap<String, Object> ut = new UTMap<String,Object>();
                    ut.put("assetsId", mainMap.get("id"));
                    ut.put("backupId", sparePart.get("id"));

                    assetPhysicalService.addRelation(ut);
                }
            }
        }

        //进行机柜的操作选择
        //如果id不为空，则把和此资产相关的机柜都修改一遍，将关联删除，再添加关联
        if(id != null){
            assetPlaceDao.relievePlaceU(id);
        }
        //对前端过来的机柜数据进行验证，
        String location = (String)mainMap.get("location");//机柜id
        String CabinetStartU = (String)mainMap.get("CabinetStartU");//机柜开始U
        String CabinetEndU = (String)mainMap.get("CabinetEndU");//机柜结束U
        if(StringUtils.isNotEmpty(CabinetEndU) && StringUtils.isNotEmpty(CabinetStartU)){
            //判断开始到结束的机柜是否被占用，如果被占用，则提示
            String occupyPlaceU = assetPlaceDao.getOccupyPlaceU(location, Integer.parseInt(CabinetStartU),
                    Integer.parseInt(CabinetEndU));
            if(StringUtils.isNotEmpty(occupyPlaceU)){
                throw new EscServiceException("机柜"+occupyPlaceU+"已被占用，请选择其他机柜！");
            }
            //机柜未被占用，则将这些机柜U和资产关联
            assetPlaceDao.bindingsPlaceU(location, id,Integer.parseInt(CabinetStartU),Integer.parseInt(CabinetEndU));
        }
        //这个时候再重新添加额外属性
        String assetsInfoId = (String)mainMap.get("id");
        String categoryId = (String)mainMap.get("category");
        //资产可以获取唯一额外属性
        //先删除后添加
        assetPhysicalDao.deleteAttrValueByInfoId(assetsInfoId);
        if(extMap != null && extMap.size() > 0){//如果额外属性不为空
            List<UTMap<String, Object>> attrvalueMapList = new ArrayList<>();
            int i = 0;
            for(String s :extMap.keySet()){
                UTMap<String, Object> attrValueMap = new UTMap<>();
                attrValueMap.put("attId",s);
                attrValueMap.put("attValue",extMap.get(s));
                attrValueMap.put("assetsInfoId",assetsInfoId);
                attrValueMap.put("sort",++i);
                attrvalueMapList.add(attrValueMap);
            }
            assetCategoryDao.saveAttrValueList(attrvalueMapList);
        }
        return UTJsonUtils.getJsonMsg(true, "操作成功");
    }
}
