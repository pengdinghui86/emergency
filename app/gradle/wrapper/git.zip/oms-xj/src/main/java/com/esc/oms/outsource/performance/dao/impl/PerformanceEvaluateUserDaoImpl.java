package com.esc.oms.outsource.performance.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.performance.dao.IPerformanceEvaluateUserDao;
import com.esc.oms.util.RoleUtils;

/**
 * 外包绩效考核Dao-被考核对象dao
 * @author owner
 *
 */
@Repository
public class PerformanceEvaluateUserDaoImpl extends BaseOptionDao implements IPerformanceEvaluateUserDao{

	@Override
	public String getTableName() {
		return "outsourc_performance_evaluate_user";
	}
	
	/**
	 * 校验年份以及月份是否已经存在考核数据
	 * @param performanceEvaluator 被考核对象
	 * @param year 年份
	 * @param month 月份
	 * @return
	 */
	public boolean isExit(String performanceEvaluator,String year,String unit,String half,String quarter,String month, String projectInfoId) {
		StringBuilder sqlcount = new StringBuilder();
		sqlcount.append("select tb.*  from ").append(getTableName())
				.append(" tb  where tb.type=1  ");//评估数据类型。1：结果评估，2：过程评估
		sqlcount.append(" and tb.performanceEvaluator = '"+performanceEvaluator+"' ");//被考核对象
		if(StringUtils.equals("year", unit)){ //考核单位是“年”
			sqlcount.append(" and tb.unit = '" + unit + "' ");
			sqlcount.append(" and tb.year = '" + year + "' ");
		}
		else if(StringUtils.equals("half", unit)){ //考核单位是“半年”
			sqlcount.append(" and tb.unit = '" + unit + "' ");
			sqlcount.append(" and tb.year = '" + year + "' ");
			sqlcount.append(" and tb.half = '" + half + "' ");
		}
		else if(StringUtils.equals("quarter", unit)){ //考核单位是“季度”
			sqlcount.append(" and tb.unit = '" + unit + "' ");
			sqlcount.append(" and tb.year = '" + year + "' ");
			sqlcount.append(" and tb.quarter = '" + quarter + "' ");
		}
		else{ //考核单位是“月”
			sqlcount.append(" and tb.unit = '" + unit + "' ");
			sqlcount.append(" and tb.year = '" + year + "' ");
			sqlcount.append(" and tb.month = '" + month + "' ");
		}
		
		sqlcount.append(" and tb.projectInfoId='"+projectInfoId+"' ");
		List<UTMap<String, Object>> list = super.getListBySql(sqlcount.toString(), null);
		Integer count = list == null ? 0 : list.size();
		/*SQLQuery sqlQuery = this.getSession().createSQLQuery(
				sqlcount.toString());
		Object object=sqlQuery.uniqueResult();
		Integer count = object!=null?Integer.valueOf(object.toString()):null;*/
		return count > 0;
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params,false), pageBean, null);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params) {
		return super.getListBySql(getSearchSql(params,false), null);
	}
	
	@Override
	public List<UTMap<String, Object>> getListMaps(Map param) {
		return super.getListBySql(getSearchSql(param,false), null);
	}
	
	@Override
	public UTMap<String, Object> getById(String id) {
		String sql = this.getSearchSql(null,true);
		List<UTMap<String, Object>> list = super.getListBySql(sql, id);
		if(list != null && list.size() > 0){
			return list.get(0);
		}
		return null;
	}
	
	/**
	 * 根据过程评估删除用户评估数据
	 * @param performanceEvaluateId
	 */
	@Override
	public void deleteByPerformanceEvaluateId(String performanceEvaluateId){
		String sql = " delete from outsourc_performance_evaluate_user where performanceEvaluateId = ? ";
		this.executeUpdate(sql, performanceEvaluateId);
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params,boolean isGetById){
		StringBuilder sql = new StringBuilder();
		sql.append(" select (saet.evaluateBeginDate <= '"+UTDate.getCurDate()+"') as 'dateStatus',sae.*,concat(su.name,'/',su.code) as 'performanceEvaluatorName', su.code,sbi.name as 'supplierName',concat(su2.name,'/',su2.code) as 'evaluatorName', ");
		sql.append(" saet.templateConfigurationId,saet.templateConfigurationName,saet.templateConfigurationVersions,saet.evaluateName,saet.remark as 'templateRemark', ");
		sql.append(" saec.templateConfigurationId as 'cfgTemplateConfigurationId', pi.name as 'projectInfoName',saec.isWeight ");
		sql.append(" from outsourc_performance_evaluate_user sae ");
		sql.append(" left join outsourc_performance_evaluate_template saet on sae.performanceEvaluateTemplateId = saet.id ");
		sql.append(" left join outsourc_performance_evaluate_configuration saec on sae.performanceEvaluateConfigId = saec.id ");
		sql.append(" left join sys_user su on sae.performanceEvaluator = su.id ");
		sql.append(" left join sys_user su2 on sae.evaluator = su2.id ");
		sql.append(" left join supplier_base_info sbi on su.supplierId = sbi.id ");
		sql.append(" left join project_info pi on pi.id= sae.projectInfoId ");
		sql.append(" where 1=1 ");
		//金融机构用户不做数据过滤，供应商负责人看本供应商的数据，普通供应商人员看本人的数据
		if(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId() != null && !"1".equals(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserType()) && EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SUPPLIER_LEADERS) && !EscCurrectUserHolder.instance.getEscCurrectUserTool().isAdmin()){//供应商负责人只能看本供应商的考核结果
			sql.append(" and su.supplierId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId()+"' ");
		}else if(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId() != null && !"1".equals(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserType()) && !EscCurrectUserHolder.instance.getEscCurrectUserTool().isAdmin()){//普通供应商人员看本人的数据
			sql.append(" and sae.performanceEvaluator = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' ");
		}
		if(isGetById){
			sql.append(" and sae.id = ? ");
		}
		if(params!=null && params.size()>0){
			//过程评估编号
			if(params.get("performanceEvaluateId")!=null &&  StringUtils.isNotEmpty(params.get("performanceEvaluateId").toString())){
				sql.append(" and sae.performanceEvaluateId = '"+params.get("performanceEvaluateId").toString().trim()+"' ");
			}
			//被考核对象
			if(params.get("performanceEvaluator")!=null && StringUtils.isNotEmpty(params.get("performanceEvaluator").toString())){
				sql.append(" and sae.performanceEvaluator = '"+params.get("performanceEvaluator").toString().trim()+"' ");
			}
			//姓名
			if(params.get("performanceEvaluatorName")!=null &&  StringUtils.isNotEmpty(params.get("performanceEvaluatorName").toString())){
				sql.append(" and su.name like '%"+params.get("performanceEvaluatorName").toString().trim()+"%' ");
			}
			//评估标题
			if(params.get("evaluateTitle")!=null &&  StringUtils.isNotEmpty(params.get("evaluateTitle").toString())){
				sql.append(" and sae.evaluateTitle like '%"+params.get("evaluateTitle").toString().trim()+"%' ");
			}
			//供应商名称
			if(params.get("supplierName")!=null &&  StringUtils.isNotEmpty(params.get("supplierName").toString())){
				sql.append(" and sbi.name like '%"+params.get("supplierName").toString().trim()+"%' ");
			}
			//外包绩效考核配置编号
			if(params.get("performanceEvaluateConfigId")!=null && StringUtils.isNotEmpty(params.get("performanceEvaluateConfigId").toString())){
				sql.append(" and sae.performanceEvaluateConfigId = '"+params.get("performanceEvaluateConfigId").toString().trim()+"' ");
			}
			//外包绩效考核模板配置编号
			if(params.get("performanceEvaluateTemplateId")!=null && StringUtils.isNotEmpty(params.get("performanceEvaluateTemplateId").toString())){
				sql.append(" and sae.performanceEvaluateTemplateId = '"+params.get("performanceEvaluateTemplateId").toString().trim()+"' ");
			}
			//考核数据类型。1：结果评估，2：过程评估
			if(params.get("type")!=null && StringUtils.isNotEmpty(params.get("type").toString())){
				sql.append(" and sae.type = '"+params.get("type").toString().trim()+"' ");
			}
			/*//年
			if(params.get("year")!=null &&  StringUtils.isNotEmpty(params.get("year").toString())){
				sql.append(" and sae.year = '"+params.get("year").toString().trim()+"' ");
			}
			//月
			if(params.get("month")!=null &&  StringUtils.isNotEmpty(params.get("month").toString())){
				sql.append(" and sae.month = '"+params.get("month").toString().trim()+"' ");
			}*/
			if(params.get("year")!=null &&  StringUtils.isNotEmpty(params.get("year").toString())){
				sql.append(" and sae.year = '"+params.get("year").toString().trim()+"' ");
			}
			if(params.get("unit")!=null &&  StringUtils.isNotEmpty(params.get("unit").toString())){
				sql.append(" and sae.unit = '"+params.get("unit").toString().trim()+"' ");
			}
			if(params.get("half")!=null &&  StringUtils.isNotEmpty(params.get("half").toString())){
				sql.append(" and sae.half = '"+params.get("half").toString().trim()+"' ");
			}
			if(params.get("quarter")!=null &&  StringUtils.isNotEmpty(params.get("quarter").toString())){
				sql.append(" and sae.quarter = '"+params.get("quarter").toString().trim()+"' ");
			}
			if(params.get("month")!=null &&  StringUtils.isNotEmpty(params.get("month").toString())){
				sql.append(" and sae.month = '"+params.get("month").toString().trim()+"' ");
			}
			//考核状态
			if(params.get("status")!=null && StringUtils.isNotEmpty(params.get("status").toString())){
				sql.append("  and ( saec.status = '"+params.get("status").toString().trim()+"' || saec.status is null  ) ");//saec.status is null表示是要把自己在统计页面新增的数据也查询出来
			}
			//
			if(params.get("orgId")!=null && StringUtils.isNotEmpty(params.get("orgId").toString())){
				sql.append(" and sae.orgId = '"+params.get("orgId").toString().trim()+"' ");
			}
			if(params.get("projectInfoId")!=null && StringUtils.isNotEmpty(params.get("projectInfoId").toString())){
				sql.append(" and sae.projectInfoId = '"+params.get("projectInfoId").toString().trim()+"' ");
			}
			
			if(params.get("projectInfoName")!=null && StringUtils.isNotEmpty(params.get("projectInfoName").toString())){
				sql.append(" and pi.name like '%"+params.get("projectInfoName").toString().trim()+"%' ");
			}
			
		}
		if(params!=null && params.get("isProcessUserList")!=null ){
//			sql.append(" order by su.code,saet.evaluateName");
			sql.append(" order by performanceEvaluatorName, projectInfoName,saet.evaluateName,sbi.name,su.code");
		}else{
			sql.append(" order by sae.year desc,sae.month desc,pi.name, su.supplierId,su.name ");
		}
		return  sql.toString();
	}

	@Override
	public List<UTMap<String, Object>> getAvgEvaluateResult(String performanceEvaluateConfigId, String performanceEvaluator, String projectInfoId) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select AVG(t.evaluateResult) evaluateResult, t.performanceEvaluateTemplateId from outsourc_performance_evaluate_user t");
		sql.append(" where 1=1");
		sql.append(" and t.performanceEvaluateConfigId = '").append(performanceEvaluateConfigId).append("'");
		sql.append(" and t.performanceEvaluator = '").append(performanceEvaluator).append("'");
		sql.append(" and t.type = 2");
//		sql.append(" and t.evaluateResult REGEXP '^[0-9]+$'"); //只计算评估结果是数字的
		sql.append(" and t.projectInfoId='" + projectInfoId + "' ");
		sql.append(" group by t.performanceEvaluateTemplateId");
		return super.getListBySql(sql.toString(), null);
	}

}
