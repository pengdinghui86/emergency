package com.esc.oms.asset.associationRelation.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.asset.allocation.service.IAssetAllocationlService;
import com.esc.oms.asset.associationRelation.dao.IAssociationRelationDao;
import com.esc.oms.asset.associationRelation.service.IAllocationlRelationService;
import com.esc.oms.asset.physical.service.IAssetPhysicalService;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;

import net.sf.json.JSONArray;

@Service
@Transactional
public class AllocationRelationServiceImpl extends BaseOptionService implements IAllocationlRelationService{

	@Resource
	private IAssociationRelationDao associationRelationDao;
	
	@Resource
	private IAssetAllocationlService assetAllocationlService;
	
	@Resource
	private IAssetPhysicalService assetPhysicalService;

	@Override
	public IBaseOptionDao getOptionDao() {
		return associationRelationDao;
	}
	
	/**
	 * 添加
	 * @param info
	 * @return
	 */
	@Override
	@EscOptionLog(module=SystemModule.allocationRelation, opType=ESCLogOpType.INSERT, table="assets_assoc_relation",option="新增名称为{name}的资产关联关系")
	public boolean add(Map info){
		 boolean flag = false;
		 List<Map<String,Object>> physicalAssetsList = (List<Map<String, Object>>) info.get("physicalAssetsList");
		 List<Map<String,Object>> softwareAssetsList = (List<Map<String, Object>>) info.get("softwareAssetsList");
		 flag = getOptionDao().add(info);
		 if(flag){
			 //添加实物资产与实物资产的关联关系
			 if(null != physicalAssetsList && physicalAssetsList.size() > 0){
				 for (Map<String, Object> physicalAsset : physicalAssetsList) {
					UTMap<String,Object> ut = new UTMap<String,Object>();
					ut.put("mainAssetId", info.get("mainAssetId"));
					ut.put("physicalAssetId", physicalAsset.get("assetsId"));
					ut.put("associationRelation", physicalAsset.get("associationRelation"));
					ut.put("relationDesc", physicalAsset.get("relationDesc"));
					flag = associationRelationDao.addPhysicalAssets(ut);
				}
			 }
			 
			 //添加实物资产与软件资产的关联关系
			 if(null != softwareAssetsList && softwareAssetsList.size() > 0){
				 for (Map<String, Object> softwareAssets : softwareAssetsList) {
					UTMap<String,Object> ut = new UTMap<String,Object>();
					ut.put("relationId", info.get("mainAssetId"));
					ut.put("softwareAssetId", softwareAssets.get("softwareAssetId"));
					ut.put("associationRelation", softwareAssets.get("associationRelation"));
					ut.put("relationDesc", softwareAssets.get("relationDesc"));
					flag = associationRelationDao.addSoftwareAssets(ut);
				}
			 }
		 }
		return	flag;
	}
	
	@EscOptionLog(module=SystemModule.allocationRelation, opType=ESCLogOpType.DELETE, table="assets_assoc_relation",option="修改名称为{name}的资产关联关系")
	public boolean updateById(Map info){
		List<Map<String,Object>> physicalAssetsList = (List<Map<String, Object>>) info.get("physicalAssetsList");
		List<Map<String,Object>> softwareAssetsList = (List<Map<String, Object>>) info.get("softwareAssetsList");
			//删除关联的实物资产
			associationRelationDao.deletePhysicalAssetsById(String.valueOf(info.get("mainId")));
			//删除关联的软件资产
			associationRelationDao.deleteSoftwareAssetsById(String.valueOf(info.get("mainId")));
			
			 //添加实物资产与实物资产的关联关系
			 if(null != physicalAssetsList && physicalAssetsList.size() > 0){
				 for (Map<String, Object> physicalAsset : physicalAssetsList) {
					UTMap<String,Object> ut = new UTMap<String,Object>();
					ut.put("mainAssetId", info.get("mainAssetId"));
					ut.put("physicalAssetId", physicalAsset.get("assetsId"));
					ut.put("associationRelation", physicalAsset.get("associationRelation"));
					ut.put("relationDesc", physicalAsset.get("relationDesc"));
					associationRelationDao.addPhysicalAssets(ut);
				}
			 }
			 
			 //添加实物资产与软件资产的关联关系
			 if(null != softwareAssetsList && softwareAssetsList.size() > 0){
				 for (Map<String, Object> softwareAssets : softwareAssetsList) {
					UTMap<String,Object> ut = new UTMap<String,Object>();
					ut.put("relationId", info.get("mainAssetId"));
					ut.put("softwareAssetId", softwareAssets.get("softwareAssetId"));
					ut.put("associationRelation", softwareAssets.get("associationRelation"));
					ut.put("relationDesc", softwareAssets.get("relationDesc"));
					 associationRelationDao.addSoftwareAssets(ut);
				}
			 }
		return  getOptionDao().updateById(info);
	}

	@Transactional(readOnly=true)
	@Override
	public UTMap<String, Object> getById(String id){
		UTMap<String,Object> map = getOptionDao().getById(id);
		if(null != map){
			List<UTMap<String,Object>> physicalAssetsList = associationRelationDao.getPhysicalAssetsById(String.valueOf(map.get("mainAssetId")));
			map.put("physicalAssetsList", physicalAssetsList);
			List<UTMap<String,Object>> softwareAssetsList = associationRelationDao.getSoftwareAssetsById(String.valueOf(map.get("mainAssetId")));
			map.put("softwareAssetsList", softwareAssetsList);
			//资产类别数据源
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("allParents", "1");
			List<UTMap<String,Object>> materiralCategorySelectBox = assetAllocationlService.getListMaps(param);
			map.put("materiralCategorySelectBox", materiralCategorySelectBox);
			//资产级别数据源
			Map<String, Object> param1 = new HashMap<String, Object>();
			param.put("parentId", map.get("mainCategoryId"));
		    List<UTMap<String,Object>> subCategorySelectBox = assetAllocationlService.getListMaps(param1);
		    map.put("subCategorySelectBox", subCategorySelectBox);
		    //资产数据源
		    UTMap<String,Object> ut = new UTMap<String,Object>();
		    ut.put("category",  map.get("mainCategoryId"));
		    ut.put("subCategory",  map.get("mainSubCategoryId"));
		    ut.put("isScrap",  "0");
		    List<UTMap<String,Object>> mainAssetIdSelectBox = assetPhysicalService.getListMaps(ut);
		    map.put("mainAssetIdSelectBox", mainAssetIdSelectBox);
		}
		return  map;
	}
	
	@Override
	@EscOptionLog(module=SystemModule.allocationRelation, opType=ESCLogOpType.DELETE, table="assets_assoc_relation",option="删除名称为{name}的资产关联关系")
	public boolean delete(Map info){
		boolean flag = getOptionDao().deleteByIds(String.valueOf(info.get("id")));
		if(flag){
			//删除关联的实物资产
			flag = associationRelationDao.deletePhysicalAssetsById(String.valueOf(info.get("mainAssetId")));
			//删除关联的软件资产
			flag = associationRelationDao.deleteSoftwareAssetsById(String.valueOf(info.get("mainAssetId")));
		}
		return	flag; 
	}
	

	@Override
	public boolean addPhysicalAssets(Map info) {
		return associationRelationDao.addPhysicalAssets(info);
	}

	@Override
	public boolean addSoftwareAssets(Map info) {
		return associationRelationDao.addSoftwareAssets(info);
	}

	@Override
	public JSONArray getJson() {
		List<UTMap<String,Object>> list = associationRelationDao.getAssets();   //需要显示的资产
		for (UTMap<String, Object> map : list) {
			String assetsId = map.get("id") + "";
			List<UTMap<String, Object>> physicals = associationRelationDao.getPhyRelByAssetsId(assetsId); //找到的关联资产
			map.put("process", physicals);
		}
		return JSONArray.fromObject(list);
	}

	@Override
	public UTMap<String, Object> getRelList(String assetsId) {
		UTMap<String,Object> map = new UTMap<String, Object>();
		List<UTMap<String,Object>> physicalAssetsList = associationRelationDao.getPhysicalAssetsById(assetsId);
		List<UTMap<String,Object>> softwareAssetsList = associationRelationDao.getSoftwareAssetsById(assetsId);
		map.put("physicalAssetsList", physicalAssetsList);
		map.put("softwareAssetsList", softwareAssetsList);
		return map;
	}

	@Override
	public UTMap<String, Object> getAssetsByCode(String code) {
		return associationRelationDao.getAssetsByCode(code);
	}

	@Override
	public JSONArray getJsonById(String assetsId) {
		List<UTMap<String,Object>> list = associationRelationDao.getAssetsById(assetsId);   //需要显示的资产
		for (UTMap<String, Object> map : list) {
			String id = map.get("id") + "";
			List<UTMap<String, Object>> physicals = associationRelationDao.getPhyRelByAssetsId(id); //找到的关联资产
			map.put("process", physicals);
		}
		return JSONArray.fromObject(list);
	}
}