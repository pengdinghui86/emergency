package com.esc.oms.asset.spareParts.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.asset.spareParts.service.ISparePartsService;
import com.esc.oms.util.CommonUtils;
@Controller
@RequestMapping("spareParts")
public class SparePartsController extends BaseOptionController {


	@Resource
	private ISparePartsService sparePartsService;
	@Resource 
	private ISysUserService userService;
	
	@Override
	public IBaseOptionService optionService() {
		return sparePartsService;
	}
	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			sparePartsService.getPageInfo(pageBean, params);
			
			List<Map<String, Object>> list = pageBean.getRows();
			if(null != list && list.size() > 0 ){
				for (Map<String, Object> map : list) {
					if(1 == Integer.parseInt(map.get("offTheShelf").toString())){
						map.put("offTheShelf", "是");
					}else{
						map.put("offTheShelf", "否");
					}
				}
			}
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
    @RequestMapping(value="/saveOrUpdate",method=RequestMethod.POST)  
    @ResponseBody
    public String saveorupdate(@RequestBody Map<String,Object> map){  
    	String name = (String)map.get("name");
    	String id = (String)map.get("id");
    	try{
	    	if(id == null){
	    		Map param = new HashMap();
	    		param.put("name", name);
	    		if(sparePartsService.isExist(param)){
	    			throw new EscServiceException("该名称已经存在！");
	    		}
	    		sparePartsService.add(map);
	    	}else{
	    		List<UTMap<String,Object>> names = sparePartsService.getSparePartsByNameAndId(name, id);
	    		if(null != names && names.size() > 0){
	    			throw new EscServiceException("该名称已经存在！");
	    		}
	    		sparePartsService.updateById(map);
	    	}
    	}catch(EscServiceException e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false,e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "操作成功");
    }
    
    /**
	 * 根据id查询
	 * @param param
	 * @return
	 */
	@RequestMapping(value="getById")
	@ResponseBody
	public UTMap<String, Object> defgetById(@RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = null;
    	try{
    		map = optionService().getById(param.get("id").toString());
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return map;
	}
	
	@RequestMapping(value="getSparePartsByIds")
	@ResponseBody
	public List<UTMap<String, Object>> getSparePartsByIds(@RequestParam  Map<String, Object> param){	
		String ids = (String)param.get("ids");
		if(StringUtils.isNotEmpty(ids)){
			ids = ids.substring(0,ids.length()-1);
		}
		List<UTMap<String, Object>> map = null;
    	try{
    		map = sparePartsService.getSparePartsByIds(ids);
		}catch(Exception e){
			logger.error("Exception", e);
			return new ArrayList<UTMap<String, Object>>();
    	}
       return map;
	}
	

	@RequestMapping(value="monitorSparePartsOverTime")
	public void monitorSparePartsOverTime() {
		sparePartsService.monitorSparePartsOverTime();
	}
}