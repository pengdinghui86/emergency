package com.esc.oms.asset.application.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.utils.UTMap;

public interface IBusinessNumberDao  {
	
	public boolean add(Map<String, Object> info);
	
	public List<UTMap<String, Object>> findByParams(Map<String, Object> params);
	
	public boolean updateByParams(Map<String, Object> params);
	
	public String saveOrUpdate(String acronym,String busType,String formart);
}
