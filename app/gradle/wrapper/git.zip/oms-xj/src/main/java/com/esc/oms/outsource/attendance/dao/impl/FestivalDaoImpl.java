package com.esc.oms.outsource.attendance.dao.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.attendance.dao.IFestivalDao;

/**
 * 节假日配置dao
 * @author owner
 *
 */
@Repository
public class FestivalDaoImpl extends BaseOptionDao implements IFestivalDao{

	@Override
	public String getTableName() {
		return "attendance_festival";
	}
	
	public List<UTMap<String, Object>> getListMaps(Map param) {
		String sql=getSearchSql(param);
		return super.getListBySql(sql, null);
	}

	public void getPageInfo(UTPageBean pageBean,Map param){
		String sql=getSearchSql(param);
		 super.getPageListMapBySql(sql,pageBean, null);
	}
	
	/**
	 * 获取对应日期的节假日配置
	 * @param date
	 * @return
	 */
//	public UTMap<String, Object> getByDate(Date date){
//		String sql = " select * from attendance_festival where festivalDate = ? ";
//		List<UTMap<String, Object>>  list = this.getListBySql(sql, date);
//		if(list != null && list.size() > 0){
//			return list.get(0);
//		}
//		return null;
//	}
	
	/**
	 * 获取对应日期的节假日配置
	 * @param date
	 * @return
	 */
	public UTMap<String, Object> getByDate(String date){
		String sql = " select * from attendance_festival where festivalDate = ? ";
		List<UTMap<String, Object>>  list = this.getListBySql(sql, date);
		if(list != null && list.size() > 0){
			return list.get(0);
		}
		return null;
	}

	private String getSearchSql(Map<String, Object> param){
		Map<String, String> p=UTMap.mapObjToString(param);
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT *,CURDATE() as curDate from attendance_festival");
		sql.append(" WHERE 1=1 ");
				
		String id=p.get("id"); 
		String beginDate = p.get("beginDate");//查询开始日期
		String endDate = p.get("endDate");//查询结束日期
		String year = p.get("year");//查询结束日期
		String month = p.get("month");//查询结束日期
		String day = p.get("day");//查询结束日期
		
		if (StringUtils.isNotEmpty(id)) {
			sql.append(" and id='"+id+"'");
		}
		
		if (StringUtils.isNotEmpty(beginDate) && StringUtils.isNotEmpty(endDate)) {
			sql.append(" and festivalDate BETWEEN '"+beginDate+"' AND '"+endDate+"'  ");
		}
		
		if (StringUtils.isNotEmpty(year)) {
			sql.append(" and YEAR(festivalDate)='"+year+"'");
		}
		
		if (StringUtils.isNotEmpty(year)) {
			sql.append(" and MONTH(festivalDate)='"+month+"'");
		}
		
		if (StringUtils.isNotEmpty(year)) {
			sql.append(" and DAYOFMONTH(festivalDate)='"+day+"'");
		}

		sql.append(" ORDER BY festivalDate ");
		
		return sql.toString();
	}

	/**
	 * 根据日期判断是否是节假日
	 * @param date
	 */
	@Override
	public boolean isFestivalByDate(String date) {
		String sql = " SELECT * from attendance_festival where festivalDate = ? and festivalType != 1 ";
		return this.getCount(sql, date) > 0;
	}
	
	/**
	 * 根据日期判断是否是工作日
	 * @param date
	 */
	@Override
	public boolean isWorkdayByDate(String date) {
		String sql = " SELECT * from attendance_festival where festivalDate = ? and festivalType == 1 ";
		return this.getCount(sql, date) > 0;
	}
	
	/**
	 * 根据年和月获取对应时间的节假日数据
	 * @param year
	 * @param month
	 * @return
	 */
	public List<UTMap<String, Object>> getByYearAndMonth(int year, int month){
		String sql = " select * from attendance_festival where YEAR(festivalDate) = '"+year+"' and MONTH(festivalDate) = '"+month+"' and festivalType != 1 ";
		return this.getListBySql(sql, null);
	}
	

	
	
	

	
}
