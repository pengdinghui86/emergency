package com.esc.oms.asset.overview.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.service.ISysOrgService;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.asset.overview.dao.IAssetsTrackInfoDao;
import com.esc.oms.asset.overview.service.IAssetsTrackInfoService;
import com.esc.oms.asset.physical.dao.IAssetPhysicalDao;
import com.esc.oms.util.RoleUtils;

@Service
@Transactional
public class AssetsTrackInfoServiceImpl extends BaseOptionService implements IAssetsTrackInfoService{


	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private IAssetsTrackInfoDao dao;
	
	@Resource
	private IAssetPhysicalDao assetsDao;
	
	@Resource
	private ISysUserService userService;
	
	@Resource
	private ISysOrgService orgService;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return dao;
	}

	/**
	 * 添加
	 * @param info
	 * @return
	 */
	public boolean add(Map info){
		String assetsId = (String) info.get("assetsId");
		if(StringUtils.isEmpty(assetsId)){
			throw new EscServiceException("新增失败，资产信息为空！");
		}else{
			Map<String,Object> assets = assetsDao.getById(assetsId);
			if(assets!=null){
				info.put("assetsName", assets.get("name"));
				info.put("assetsCode", assets.get("codeNum"));
			}else{
				throw new EscServiceException("新增失败，未找到该资产！");
			}
		}
		String userId = (String) info.get("userId");
		if(RoleUtils.isAdmin(userId)){
			info.put("userName", "admin");
			info.put("departName", "");
			info.put("departId", "");
		}else{
			String userName = (String) info.get("userName");
			if(StringUtils.isEmpty(userName)){
				if(StringUtils.isEmpty(userId)){
//					throw new EscServiceException("新增失败，用户信息为空！");
				}else{			
					Map<String,Object> user = userService.getById(userId);
					if(user!=null){
						info.put("userName", user.get("name")+"/"+user.get("code"));
					}else{						
						throw new EscServiceException("新增失败，未找到该用户！");										
					}
				}
			}			
			String departId = (String) info.get("departId");
			String departName = (String) info.get("departName");
			if(StringUtils.isEmpty(departName)){
				if(StringUtils.isEmpty(departId)){
//					throw new EscServiceException("新增失败，部门信息为空！");
				}else{	
					String orgName = orgService.getLongNameById(departId);
					if(!StringUtils.isEmpty(orgName)){
						info.put("departName",orgName);			
					}else{						
						throw new EscServiceException("新增失败，未找到该部门！");						
					}
				}
			}	
		}	

		Object changeUserIdObj = info.get("changeUserId");
		if(changeUserIdObj==null) {
		  info.put("changeUserId",  EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());	
		  info.put("changeUserName", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectName()+"/"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectCode());	
		  info.put("changeDepartId",  EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserOrgId());	
		  info.put("changeDepartName",  EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserOrgName());	
		}else if(RoleUtils.isAdmin(changeUserIdObj.toString())){
			  info.put("changeUserId","");
			  info.put("changeUserName", "admin/admin");
			  info.put("changeDepartId", "");
			  info.put("changeDepartName", "");
		}
		else{
			Map<String,Object> user = userService.getById(changeUserIdObj.toString());
			//String departId = (String) info.get("departId");
			//String departName = (String) info.get("departName");
			info.put("changeUserId",user.get("id") );
			info.put("changeUserName", user.get("name")+"/"+user.get("code"));
			String orgId = (String) user.get("orgId");
			if (StringUtils.isNotEmpty(orgId)) {
				info.put("changeDepartId", orgId);
				String orgName = orgService.getLongNameById(orgId);
				info.put("changeDepartName", orgName);
			}
			/*if(StringUtils.isNotEmpty(departName)){
				info.put("changeDepartId", departId);
				String orgName = orgService.getLongNameById(departId);
				info.put("changeDepartName", orgName);
			}*/
		}
		return super.add(info);
	}
	
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map param) {
		dao.getPageInfo(pageBean, param);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params){
		return dao.getListAll(params);
	}
	
}