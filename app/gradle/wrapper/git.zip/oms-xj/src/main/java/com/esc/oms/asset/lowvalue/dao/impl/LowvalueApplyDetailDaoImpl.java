package com.esc.oms.asset.lowvalue.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.asset.lowvalue.dao.ILowvalueApplyDetailDao;
@Repository
public class LowvalueApplyDetailDaoImpl extends BaseOptionDao implements ILowvalueApplyDetailDao{
	
	@Override
	public String getTableName() {
		return "assets_lowvalue_apply_detail";
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params,false), pageBean, null);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params) {
		return super.getListBySql(getSearchSql(params,false), null);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListMaps(Map params) {
		return super.getListBySql(getSearchSql(params,false), null);
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params,boolean isGetById){
		StringBuilder sql = new StringBuilder();
		sql.append(" select detail.*,info.stockNum,info.pendConfirmNum,org.name as unitName,concat(grantUser.name,'/',grantUser.code) as grantUserName "
				+ "  from assets_lowvalue_apply_detail detail ");
		sql.append(" left join assets_lowvalue_apply apply on detail.applyId=apply.id ");
		sql.append(" left join assets_lowvalue_info info on detail.infoId=info.id ");
		sql.append(" left join sys_user grantUser on detail.grantUserId=grantUser.id ");
		sql.append(" left join sys_org org on apply.unit=org.id ");
		sql.append(" where 1=1 ");
		if(params!=null && params.size()>0){		
			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
				sql.append(" and detail.name like '%"+params.get("name").toString().trim()+"%' ");
			}
			if(params.get("code")!=null &&  StringUtils.isNotEmpty(params.get("code").toString())){
				sql.append(" and detail.code like '%"+params.get("code").toString().trim()+"%' ");
			}
			if(params.get("applyId")!=null && StringUtils.isNotEmpty(params.get("applyId").toString())){
				sql.append(" and detail.applyId='"+params.get("applyId").toString().trim()+"' ");
			}
			if(params.get("infoId")!=null && StringUtils.isNotEmpty(params.get("infoId").toString())){
				sql.append(" and detail.infoId='"+params.get("infoId").toString().trim()+"' ");
			}
			if(params.get("startDate")!=null && StringUtils.isNotEmpty(params.get("startDate").toString())){
				sql.append(" and DATE_FORMAT(detail.createTime,'%Y-%m-%d')>='"+params.get("startDate").toString().trim()+"' ");
			}
			if(params.get("endDate")!=null && StringUtils.isNotEmpty(params.get("endDate").toString())){
				sql.append(" and DATE_FORMAT(detail.createTime,'%Y-%m-%d')<='"+params.get("endDate").toString().trim()+"' ");
			}
		}
		sql.append(" order by detail.createTime desc");
		return  sql.toString();
	}

	@Override
	public List<UTMap<String, Object>> getListAllByParentParam(Map params) {
		return super.getListBySql(getSearchSqlByParentParam(params), null);
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSqlByParentParam(Map params){
		StringBuilder sql = new StringBuilder();
		sql.append(" select detail.* from assets_lowvalue_apply_detail detail ");
		sql.append(" left join assets_lowvalue_apply apply on detail.applyId=apply.id ");
		sql.append(" where 1=1 ");
		if(params!=null && params.size()>0){		
			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
				sql.append(" and apply.name like '%"+params.get("name").toString().trim()+"%' ");
			}
			if(params.get("startDate")!=null && StringUtils.isNotEmpty(params.get("startDate").toString())){
				sql.append(" and apply.applyTime>='"+params.get("startDate").toString().trim()+"' ");
			}
			if(params.get("endDate")!=null && StringUtils.isNotEmpty(params.get("endDate").toString())){
				sql.append(" and apply.applyTime<='"+params.get("endDate").toString().trim()+"' ");
			}
		}
		sql.append(" order by apply.createTime,detail.code desc");
		return  sql.toString();
	}

}
