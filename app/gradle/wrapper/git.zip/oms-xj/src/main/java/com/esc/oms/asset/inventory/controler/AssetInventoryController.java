package com.esc.oms.asset.inventory.controler;

import com.alibaba.fastjson.JSON;
import com.esc.oms.asset.inventory.service.IAssetInventoryService;
import com.esc.oms.asset.physical.service.IAssetPhysicalService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.RoleUtils;
import com.esc.oms.util.TaskModel;
import net.sf.json.JSONObject;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedOutputStream;
import java.text.SimpleDateFormat;
import java.util.*;
@Controller
@RequestMapping("assetInventory")
public class AssetInventoryController extends BaseOptionController {


	@Resource
	private IAssetInventoryService assetInventoryService;
	
	@Resource
	private MessageSend messageService;
	
	@Resource
	private IUserTaskService userTaskService;
	
	@Resource
	private ISysUserService userService;
	
	@Resource
	private IAssetPhysicalService assetPhysicalService;
	
	@Override
	public IBaseOptionService optionService() {
		return assetInventoryService;
	}
	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			assetInventoryService.getPageInfo(pageBean, params);
			List<Map<String, Object>> list = pageBean.getRows();
			if(null != list && list.size() > 0 ){
				for (int i=0;i<list.size();i++) {
					Map<String, Object> map = list.get(i);
					if("1".equals(String.valueOf(map.get("needConfirm")))){
						map.put("needConfirm", "是");
					}else{
						map.put("needConfirm", "否");
					}
					//查询盘点单下的所有资产，如果资产管理员和责任人都有的情况下，需要俩人都确定才能完成盘点，如果责任人不存在，则只需要管理员确认就可以完成盘点了
					boolean isFinish = true;
					Map<String, Object> info = new HashMap<String, Object>();
					info.put("inventoryId", map.get("id"));
					List<UTMap<String, Object>> assets = assetInventoryService.getAssetInventoryListMaps(info);
					if (null != assets && !assets.isEmpty()) {
						for (UTMap<String, Object> asset : assets) {
							String confirmStatus = asset.get("confirmStatus") == null ? "1" : asset.get("confirmStatus").toString();
							String resUserId = (String) asset.get("resUserId");
							if (StringUtils.equals("1", confirmStatus)) {//还在管理员确认阶段
								isFinish = false;
								break;
							}
							
							if (StringUtils.equals("2", confirmStatus) && StringUtils.isNotEmpty(resUserId)) {//在责任人确认节点，且责任人不为空
								isFinish = false;
								break;
							}
						}
					}
					map.put("isFinish", isFinish);
					
					//查询当前用户下的所有盘点资产是否都确认完毕
					boolean isConfirmed = true;
					Map<String, Object> aMap = new HashMap<String, Object>();
					aMap.put("inventoryId", (String)map.get("id"));
					aMap.put("viewPage", true);
	    			List<UTMap<String, Object>> assetsList = assetInventoryService.getAssetInventoryListMaps(aMap);
	    			if (null != assetsList && !assetsList.isEmpty()) {
	    				String userId = EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId();
	    				if (EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR,RoleUtils.ASSET_MANAGER)) {
	    					for (UTMap<String, Object> asset : assetsList) {
	    						String confirmStatus = ""+ asset.get("confirmStatus");
	    						String resUser = "" + asset.get("resUser");
	    						if (StringUtils.equals("1", confirmStatus)) {//待管理员确认
	    							isConfirmed = false;
	    							break;
	    						}else if (StringUtils.equals("2", confirmStatus) && StringUtils.equals(resUser, userId)){//待责任人确认
	    							isConfirmed = false;
	    							break;
	    						}
	    					}
	    				}else {
	    					for (UTMap<String, Object> asset : assetsList) {
	    						String confirmStatus = ""+ asset.get("confirmStatus");
	    						String resUser = "" + asset.get("resUser");
	    						if (StringUtils.equals("2", confirmStatus) && StringUtils.equals(resUser, userId)) {//
	    							isConfirmed = false;
	    							break;
		    					}
	    					}
	    					
	    				}
	    			}
	    			map.put("isConfirmed", isConfirmed);
				}
			}
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	/**
	 * 新增，需要返回一个给前台的其他标签
	 * @param info
	 * @return
	 */
	@RequestMapping(value="add",method =RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> add(@RequestBody  Map<String, Object> param){
		Map<String, Object> coloneParam = CommonUtils.clone(param);
		
		List<Map<String, Object>> assetsList =  (List<Map<String, Object>>) coloneParam.get("assetsList");
		boolean submitStatus = (Boolean)coloneParam.get("submitStatus");
		boolean flag = false;
		try{
			String title = (String) coloneParam.get("title");
			List<UTMap<String, Object>> all = assetInventoryService.getAll();
			for (UTMap<String, Object> map : all) {
				if (StringUtils.equals(title, (String)map.get("title"))) {
					coloneParam.put("success", false);
					coloneParam.put("msg", "盘点名称已存在！");
					return coloneParam;
				}
			}
			flag = assetInventoryService.add(coloneParam);
			String inventoryId = coloneParam.get("id").toString();
			logger.info(CommonUtils.vaildLog("新增'"+coloneParam.get("title")+"'资产盘点,id="+inventoryId));
			if(flag){
				// 添加明细
				addAssetInventory(assetsList,inventoryId,"add");
				// 需要确认、并且是提交：发送通知
				if(submitStatus){
					if("1".equals(String.valueOf(coloneParam.get("needConfirm")))) {
						sendMessage(assetsList,inventoryId);
					}else{
						UTMap<String,Object> ut =new UTMap<String,Object>();
						ut.put("id", inventoryId);
						ut.put("status", 3); // 完成确认
						optionService().updateById(ut);
						assetInventoryService.updateInventoryStatusByInventoryId(inventoryId, "4");
					}
				}
			}
			coloneParam.put("success", true);
			coloneParam.put("msg", "操作成功！");
    	}catch(Exception e){
    		logger.error("Exception", e);
    		coloneParam.put("success", false);
    		coloneParam.put("msg", "操作失败！");
    	}
       return coloneParam;
	}
	
	/**
	 * 修改
	 * @param info
	 * @return
	 */
	@RequestMapping(value="update")
	@ResponseBody
	public String update(@RequestBody  Map<String, Object> map1){
		Map<String, Object> coloneParam = CommonUtils.clone(map1);
		
		List<Map<String, Object>> assetsList =  (List<Map<String, Object>>) coloneParam.get("assetsList");
		boolean submitStatus = (Boolean)coloneParam.get("submitStatus");
		boolean flag = false;
		try{
			flag = optionService().updateById(coloneParam);
    		if(flag && (null != assetsList)){
    			addAssetInventory(assetsList,(coloneParam.get("id").toString()),"update");
    			if(submitStatus){
					if("1".equals(String.valueOf(coloneParam.get("needConfirm")))) {
						sendMessage(assetsList,(String)coloneParam.get("id"));
					}else{
						UTMap<String,Object> ut =new UTMap<String,Object>();
						ut.put("id", (String)coloneParam.get("id"));
						ut.put("status", 3); // 完成确认
						optionService().updateById(ut);
						assetInventoryService.updateInventoryStatusByInventoryId((String)coloneParam.get("id"), "4");
					}
				}
			}
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "操作成功");
	}
	
	
	/**
	 * 完成盘点
	 * @param info
	 * @return
	 */
	@RequestMapping(value="finishInventory")
	@ResponseBody
	public String finishInventory(@RequestBody  Map<String, Object> map1){
		Map<String, Object> coloneParam = CommonUtils.clone(map1);
		try{
			optionService().updateById(coloneParam);
			String inventoryId = coloneParam.get("id").toString();
			UTMap<String,Object> map = optionService().getById(inventoryId);
			
			if("1".equals(String.valueOf(map.get("needConfirm")))){   //需要确认才有代办任务
				UTMap<String,Object> params = new UTMap<String,Object>();
				params.put("inventoryId", inventoryId);
				List<UTMap<String, Object>> assetsList = assetInventoryService.getAssetInventoryListMaps(params); //获取盘点下面的资产
				if (assetsList != null && assetsList.size() > 0) {
					for (Map<String, Object> assets : assetsList) {  
						userTaskService.finishTask(inventoryId+assets.get("assetsId").toString());
						//完成盘点回填盘点结果到资产表
						String status = (String) assets.get("status");
						if (StringUtils.isNotEmpty(status) && !StringUtils.equals("-1", status)) {//盘点状态不为空，且不是未盘状态才去更新资产的盘点状态
							Map<String, Object> param = new HashMap<String, Object>();
							param.put("id", assets.get("assetsId"));
							param.put("inventory_status", assets.get("status"));
							assetPhysicalService.updateById(param);
						}
					}
				}
			}
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "操作成功");
	}
	
	
	

    
    /**
	 * 根据id查询
	 * @param param
	 * @return
	 */
	@RequestMapping(value="getById")
	@ResponseBody
	public UTMap<String, Object> defgetById(@RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = null;
		UTMap<String, Object> ut = new UTMap<String,Object>();
    	try{
    		map = optionService().getById(param.get("id").toString());
    		if(null != map && map.size() > 0){ 
    			ut.put("inventoryId", (String)map.get("id"));
    			ut.put("viewPage", true);
    			List<UTMap<String, Object>> assetsList = assetInventoryService.getAssetInventoryListMaps(ut);
    			if(null != assetsList && assetsList.size() > 0 ){
    				for (Map<String, Object> assetmap : assetsList) {
    					if("3".equals(String.valueOf(assetmap.get("confirmStatus")))){
    						assetmap.put("confirmStatus", "确认");
    					}else if("2".equals(String.valueOf(assetmap.get("confirmStatus")))){
    						assetmap.put("confirmStatus", "待责任人确认");
    					}else if("1".equals(String.valueOf(assetmap.get("confirmStatus")))){
    						assetmap.put("confirmStatus", "待管理员确认");
    					}else if("4".equals(String.valueOf(assetmap.get("confirmStatus")))){
    						assetmap.put("confirmStatus", "不需确认");
    					}
    				}
    			}
    			map.put("assetsList", assetsList);
    		}
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return map;
	}
	
	
	/**
	 * 根据id查询
	 * @param param
	 * @return
	 */
	@RequestMapping(value="getAssetInventoryByInventoryId")
	@ResponseBody
	public List<UTMap<String, Object>> getAssetInventoryByInventoryId(@RequestParam  Map<String, Object> param){		
		List<UTMap<String,Object>> assetAllocationList = null;
   	try{
   		assetAllocationList = assetInventoryService.getAssetInventoryListMaps(param);
		}catch(Exception e){
			logger.error("Exception", e);
			return new ArrayList<UTMap<String, Object>>();
   	}
      return assetAllocationList;
	}

	@RequestMapping(value="getAssetInventoryByInventoryIdPage")  
   @ResponseBody
   public UTPageBean getAssetInventoryByInventoryIdPage(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			assetInventoryService.getAssetInventoryPageInfo(pageBean, params);
			List<Map<String, Object>> list = pageBean.getRows();
			if(null != list && list.size() > 0 ){
				for (Map<String, Object> map : list) {
					if("3".equals(String.valueOf(map.get("confirmStatus")))){
						map.put("confirmStatusName", "确认");
					}else if("2".equals(String.valueOf(map.get("confirmStatus")))){
						map.put("confirmStatusName", "待责任人确认");
					}else if("1".equals(String.valueOf(map.get("confirmStatus")))){
						map.put("confirmStatusName", "待管理员确认");
					}else if("4".equals(String.valueOf(map.get("confirmStatus")))){
						map.put("confirmStatusName", "不需确认");
					}
				}
			}
		}catch(Exception e){
   		logger.error("Exception", e);
   	}
      return pageBean;
   }
	
	@RequestMapping(value="confirmInventory",method=RequestMethod.POST)  
	@ResponseBody
	public String confirmInventory(@RequestBody Map<String,Object> map){  
		try {
			assetInventoryService.updateInventoryStatusById(map.get("ids").toString(),map.get("status").toString(),map.get("inventoryId").toString());
		} catch (Exception e) {
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "操作失败");
		}
		return UTJsonUtils.getJsonMsg(true, "操作成功");
	}
	
	private void addAssetInventory(List<Map<String, Object>> assetsList,String inventoryId,String type){
		assetInventoryService.deleteAssetInventoryByInventoryId(inventoryId);//先删除关联再重新添加关联
		for (Map<String, Object> asset : assetsList) {
			UTMap<String, Object> ut = new UTMap<String,Object>();
			ut.put("inventoryId", inventoryId);
			ut.put("assetsId", asset.get("assetsId"));
			ut.put("confirmStatus", 1);
			ut.put("status", "-1");//盘点结果，默认为未盘
		    assetInventoryService.addAssetInventory(ut);
		}
		
		
	}
	
	private void sendMessage(List<Map<String, Object>> assetsList,String inventoryId) throws Exception{
		Map<String,Object> inventory = assetInventoryService.getById(inventoryId);
		String resUserIds = "";
		if(null != inventory && StringUtils.isNotEmpty(String.valueOf(inventory.get("beginDate")))){
			if(compareDate(String.valueOf(inventory.get("beginDate")))){
				String title = "资产盘点通知";
				String content = "资产盘点【"+inventory.get("title")+"】将于"+inventory.get("beginDate")+"至"+inventory.get("endDate")+"期间进行盘点，请知悉，届时请登录系统进行资产盘点确认";
				if(null != assetsList && assetsList.size() > 0){
					for (Map<String, Object> assets : assetsList) {
						if(null != assets.get("resUser") && StringUtils.isNotEmpty((String)assets.get("resUser"))){
							
							String resUser = String.valueOf(assets.get("resUser"));
							if(resUserIds.indexOf(resUser) == -1){
								resUserIds +=resUser; 
//								if(StringUtils.isNotEmpty(resUser)){
//									resUser = resUser + ","+taskUserIds;
//								}
								messageService.sendMessage(resUser,title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
							}
							
//							userTaskService.addTaskByUserId("资产【"+assets.get("name")+"/"+assets.get("code")+"】盘点确认",inventoryId, "实物资产盘点", TaskModel.AssetInventory,(String)assets.get("resUser"));			
						}
					}
					Map<String,Object> param = new HashMap<String,Object>();				
					param.put("signature", RoleUtils.ASSET_MANAGER);
					String taskUserIds = userService.getUserIds(param);
					messageService.sendMessage(taskUserIds,title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
				}
			}else{
				if(null != assetsList && assetsList.size() > 0){
					for (Map<String, Object> assets : assetsList) {
						String resUser = String.valueOf(assets.get("resUser"));
						String codeNum = (String) assets.get("codeNum");
						if (StringUtils.isEmpty(codeNum)) {
							codeNum = "";
						}else {
							codeNum = "/" + codeNum;
						}
						if(null != assets && null != resUser && StringUtils.isNotEmpty(resUser)){
							if(resUserIds.indexOf(resUser) == -1){
								resUserIds +=resUser; 
								String title = "资产盘点确认提醒";
								String content = "资产盘点:【"+inventory.get("title")+"】已开始,请在"+inventory.get("endDate")+"前，进入系统进行资产确认！";
								messageService.sendMessage(resUser,title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
							}
							
							userTaskService.addTaskByUserId("资产【"+assets.get("name")+codeNum+"】盘点责任人确认 ",inventoryId+String.valueOf(assets.get("id")), "实物资产责任人盘点", TaskModel.AssetInventory,(String)assets.get("resUser"));
						}
						userTaskService.addTaskByRole("资产【"+assets.get("name")+codeNum+"】盘点管理员确认 ",inventoryId+String.valueOf(assets.get("id")), "实物资产管理员盘点", TaskModel.AssetInventory,RoleUtils.ASSET_MANAGER);
					}
				}
			}
		}
	}
	
	private boolean compareDate(String startDate) throws Exception{
		   Date nowDate = new Date();
		   SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		   Date allocDate = sdf.parse(startDate);
		   boolean flag = allocDate.after(nowDate);
		   return flag;
	}
	
	/**
	 * 盘点单导出
	 * @param response
	 * @param params
	 * @param pageBean
	 */
	@RequestMapping("leadingout")
	public void leadingout(HttpServletResponse response, @RequestParam Map<String, Object> param) {
		UTPageBean pageBean = CommonUtils.getPageBean(param);
		Integer outType = Integer.parseInt((String) param.get("outType"));
		List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
		List<UTMap<String, Object>> outData = new ArrayList<UTMap<String, Object>>();
		Object info = param.get("params");
		JSONObject jsonBean = null;
		if(info != null) {
			jsonBean = JSONObject.fromObject(info);
		}
		// 根据条件 导出全部
		if (UTExcel.EXCELOUTTYPE_ALL == outType) {
			// getAll
			data = assetInventoryService.getListMaps(jsonBean);
		} else {
			// 根据条件 导出当前
			assetInventoryService.getPageInfo(pageBean, jsonBean);
			data = pageBean.getRows();
		}
		if (null ==  data) {
			data = new ArrayList<UTMap<String, Object>>();
		}
		for (UTMap<String, Object> map : data) {
			UTMap<String, Object> oMap = new UTMap<String, Object>();
			oMap.put("beginDate", map.get("beginDate"));
			oMap.put("endDate", map.get("endDate"));
			oMap.put("title", map.get("title"));
			oMap.put("code", map.get("code"));
			oMap.put("status", map.get("status"));
			/*
			UTMap<String,Object> dataMap = new UTMap<String,Object>();
			dataMap.put("inventoryId", map.get("id"));
			List<UTMap<String, Object>> assetsList = assetInventoryService.getAssetInventoryListMaps(dataMap); //获取盘点下面的资产
			if (null == assetsList) {
				assetsList = new ArrayList<UTMap<String, Object>>();
			}
			List<UTMap<String, Object>> oList = new ArrayList<UTMap<String, Object>>();
			if (!assetsList.isEmpty()) {
				for (UTMap<String, Object> aMap : assetsList) {
					UTMap<String, Object> oaMap = new UTMap<String, Object>();
					oaMap.put("resUserName", aMap.get("resUserName"));
					oaMap.put("code", aMap.get("code"));
					oaMap.put("name", aMap.get("name"));
					oaMap.put("location", aMap.get("location"));
					oaMap.put("serialNum", aMap.get("serialNum"));
					oaMap.put("sn", aMap.get("sn"));
					oList.add(oaMap);
				}
			}
			oMap.put("assetsList", oList);*/
			outData.add(oMap);
		}
		String jsonStr = JSON.toJSONString(outData);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		response.setContentType("text/plain");
		response.addHeader("Content-Disposition",  
                "attachment;filename=assetInventory"+ sdf.format(new Date()) +".json");
		BufferedOutputStream buff = null; 
		ServletOutputStream serOut = null;
		try {
			serOut = response.getOutputStream();
			buff = new BufferedOutputStream(serOut);
			buff.write(jsonFormart(jsonStr).getBytes("UTF-8"));
			buff.flush();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			IOUtils.closeQuietly(buff);
			IOUtils.closeQuietly(serOut);
		}
	}
	
	@RequestMapping("leadingoutById")
	public void leadingoutById(HttpServletResponse response, @RequestParam Map<String, Object> param) {
		String id = (String) param.get("id");
		UTMap<String, Object> data = assetInventoryService.getById(id);
		if (null == data) {
			data = new UTMap<String, Object>();
		}
		UTMap<String, Object> outData = new UTMap<String, Object>();
		if (!data.isEmpty()) {
			outData.put("beginDate", data.get("beginDate"));
			outData.put("endDate", data.get("endDate"));
			outData.put("title", data.get("title"));
			outData.put("code", data.get("code"));
			UTMap<String,Object> dataMap = new UTMap<String,Object>();
			dataMap.put("inventoryId", id);
			dataMap.put("isLeadingout", "1");
			List<UTMap<String, Object>> assetsList = assetInventoryService.getAssetInventoryListMaps(dataMap); //获取盘点的资产明细
			if (null == assetsList) {
				assetsList = new ArrayList<UTMap<String, Object>>();
			}
			List<UTMap<String, Object>> outList = new ArrayList<UTMap<String, Object>>();
			if (!assetsList.isEmpty()) {
				for (UTMap<String, Object> aMap : assetsList) {
					UTMap<String, Object> oMap = new UTMap<String, Object>();
					oMap.put("resUserName", aMap.get("resUserName") == null ? "" : aMap.get("resUserName"));
					oMap.put("code", aMap.get("code") == null ? "" : aMap.get("code"));
					oMap.put("codeNum", aMap.get("codeNum") == null ? "" : aMap.get("codeNum"));
					oMap.put("categoryName", aMap.get("categoryName") == null ? "" : aMap.get("categoryName"));
					oMap.put("name", aMap.get("name"));
					oMap.put("location", aMap.get("location") == null ? "" : aMap.get("location"));
					oMap.put("serialNum", aMap.get("serialNum") == null ? "" : aMap.get("serialNum"));
					oMap.put("sn", aMap.get("sn") == null ? "" : aMap.get("sn"));
					outList.add(oMap);
				}
			}
			
			outData.put("assetsList", outList);
		}
		String jsonStr = JSON.toJSONString(outData);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		response.setContentType("text/plain");
		response.addHeader("Content-Disposition",  
                "attachment;filename=assetInventory"+ sdf.format(new Date()) +".json");
		BufferedOutputStream buff = null; 
		ServletOutputStream serOut = null;
		try {
			serOut = response.getOutputStream();
			buff = new BufferedOutputStream(serOut);
			buff.write(jsonFormart(jsonStr).getBytes("UTF-8"));
			buff.flush();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			IOUtils.closeQuietly(buff);
			IOUtils.closeQuietly(serOut);
		}
	}
	
	private String getLevelStr(int level) {
        StringBuffer levelStr = new StringBuffer();
        for (int levelI = 0; levelI < level; levelI++) {
            levelStr.append("\t");
        }
        return levelStr.toString();
    }
	//格式化json串
    private String jsonFormart(String s) {
        int level = 0;
        //存放格式化的json字符串
        StringBuffer jsonForMatStr = new StringBuffer();
        for(int index=0;index<s.length();index++)//将字符串中的字符逐个按行输出
        {
            //获取s中的每个字符
            char c = s.charAt(index);
             
            //level大于0并且jsonForMatStr中的最后一个字符为\n,jsonForMatStr加入\t
            if (level > 0 && '\n' == jsonForMatStr.charAt(jsonForMatStr.length() - 1)) {
                jsonForMatStr.append(getLevelStr(level));
            }
            //遇到"{"和"["要增加空格和换行，遇到"}"和"]"要减少空格，以对应，遇到","要换行
            switch (c) {
            case '{':
            case '[':
                jsonForMatStr.append(c + "\n");
                level++;
                break;
            case ',':
                jsonForMatStr.append(c + "\n");            
                break;
            case '}':
            case ']':
                jsonForMatStr.append("\n");
                level--;
                jsonForMatStr.append(getLevelStr(level));
                jsonForMatStr.append(c);
                break;
            default:
                jsonForMatStr.append(c);
                break;
            }
        }
        return jsonForMatStr.toString();
    }
    
    @RequestMapping(value = "leadingin")
	@ResponseBody
	public UTMap<String, Object> leadingin(
			@RequestParam Map<String, Object> param, String filePath) {
		UTMap<String, Object> utMap = new UTMap<String, Object>();
		try {
			utMap.put("success", assetInventoryService.leadingin(filePath, param));
			utMap.put("msg", "导入成功！");
		} catch (EscServiceException e) {
			logger.error("EscServiceException",e);
			utMap.put("success", false);
			utMap.put("msg", e.getMessage());
		} catch (Exception e) {
			logger.error("EscServiceException",e);
			utMap.put("success", false);
			utMap.put("msg", "导入失败");
		}
		return utMap;
	} 
    
    @RequestMapping(value="updateInventoryStatus", method=RequestMethod.POST)
    @ResponseBody
    public String updateInventoryStatus(@RequestBody Map<String, Object> param) {
    	boolean flag = assetInventoryService.updateInventoryStatus(param);
    	if (flag) {
    		return UTJsonUtils.getJsonMsg(true, "操作成功");
    	}
    	return UTJsonUtils.getJsonMsg(false, "操作失败");
    }
    
}