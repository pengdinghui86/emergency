package com.esc.oms.asset.lowvalue.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.security.service.IOrgMemberService;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.esc.framework.workflow.service.IWorkflowEngine;
import org.esc.framework.workflow.utils.bpmn.Instance;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.asset.lowvalue.service.ILowvalueApplyService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ExcelUtil;

import net.sf.json.JSONObject;
@Controller
@RequestMapping("lowvalueApply")
public class LowvalueApplyController extends BaseOptionController {

	@Resource
	private ILowvalueApplyService service;
	
	@Resource
	private IWorkflowEngine workflowEngine;
	
	@Resource
	private ISysParamService sysParamService;
	
	@Resource
	private IOrgMemberService orgMemberService;
	
	@Override
	public IBaseOptionService optionService() {
		return service;
	}
	
	/**
	 * 新增，需要返回一个id给前台的其他标签
	 * @param info
	 * @return
	 */
	@RequestMapping(value="add",method =RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> add(@RequestBody  Map<String, Object> map1){
		Map<String,Object> cloneMap = CommonUtils.clone(map1);
		try{ 
    		boolean result = optionService().add(cloneMap);
    		if(result){
    			cloneMap.put("success", true);
    			cloneMap.put("msg", "操作成功！");
    		}else{
    			cloneMap.put("success", false);
//        		info.put("msg", "操作失败！");
    		}   		
    	}catch(EscServiceException e){
    		cloneMap.put("success", false);
    		cloneMap.put("msg", e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		cloneMap.put("success", false);
    		cloneMap.put("msg", "操作失败！");
    	}
       return cloneMap;
	}
	
	/**
	 * 新增或修改，需要返回一个id给前台的其他标签
	 * @param info
	 * @return
	 */
	@RequestMapping(value="saveOrUpdate",method =RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> saveOrUpdate(@RequestBody  Map<String, Object> map1){
		Map<String,Object> cloneMap = CommonUtils.clone(map1);
		try{
	    	if(cloneMap.get("id") == null){
	    		boolean result = optionService().add(cloneMap);
	    		if(result){
	    			cloneMap.put("success", true);
	    			cloneMap.put("msg", "操作成功！");
	    		}else{
	    			cloneMap.put("success", false);
	    		} 
	    	}else{
	    		optionService().updateById(cloneMap);
	    		cloneMap.put("success", true);
	    		cloneMap.put("msg", "操作成功！");
	    	}		
    	}catch(EscServiceException e){
    		cloneMap.put("success", false);
    		cloneMap.put("msg", e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		cloneMap.put("success", false);
    		cloneMap.put("msg", "操作失败！");
    	}
       return cloneMap;
	}
	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			service.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	/**
	 * 待审批列表--分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getPendApprovalPageList")  
    @ResponseBody
    public UTPageBean getPendApprovalPageList(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			service.getPendApprovalPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	/**
	 * 已审批列表--分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAlreadyApprovalPageList")  
    @ResponseBody
    public UTPageBean getAlreadyApprovalPageList(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			service.getAlreadyApprovalPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	
	/**
	 * 导出
	 * @param param
	 * @param utPageBean
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "leadingout")
	public void leadingout(@RequestParam Map<String, Object> map1,
			HttpServletRequest request,
			HttpServletResponse response) {
		//ParamObject object = CommonUtils.checkParam(map1, utPageBean1);
		Map<String, Object> param = CommonUtils.clone(map1);
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = null;
			if(info != null) {
				jsonBean = JSONObject.fromObject(info);
			}
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = service.getListAllDetail(jsonBean);
			} else {
				service.getPageInfoDetail(utPageBean, jsonBean);
				data = utPageBean.getRows();
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			service.leadingout(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	/**
	 * 申请单导出
	 */
	@RequestMapping(value="exportByData")
	@ResponseBody
	public void exportByData(HttpServletRequest request, HttpServletResponse response, @RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = new UTMap<String, Object>();
	  
    	try{
    		if(null != param.get("id")){
    			map = optionService().getById((String)param.get("id"));
    			if(null != map && map.size() > 0){
    				List<UTMap<String, Object>> mapList = new ArrayList<UTMap<String, Object>>();
    				mapList.add(map);
    				//替换下拉的值
    				Map<String, String> fieldAndParamType = new HashMap<String, String>();
    				fieldAndParamType.put("type", "lowvalueType");
    				fieldAndParamType.put("status", "lowvalueApplyStatus");
    				sysParamService.changeParamData(mapList, fieldAndParamType);
    				map = mapList.get(0);
    				if(map.get("detailList") != null)
    				{
    					List<UTMap<String, Object>> detailList = (ArrayList<UTMap<String, Object>>) map.get("detailList");
    					if(detailList != null && detailList.size() > 0)
    					{
	        				//替换下拉的值
	        				Map<String, String> fieldAndParamType1 = new HashMap<String, String>();
	        				fieldAndParamType1.put("confirmStatus", "lowvalueApplyDetailStatus");
	        				sysParamService.changeParamData(detailList, fieldAndParamType1);
	        				map.put("detailList", detailList);
    					}
    				}
    			}
    			List<UTMap<String, Object>> orgList = orgMemberService.getOrg(false);
    			for(UTMap<String, Object> org : orgList)
    			{
    				if(org.get("id").toString().equals(map.get("unit").toString()))
    				{
    					map.put("unitName", org.get("longName").toString());
    					break;
    				}
    			}
    			//创建一个表格
    			HSSFWorkbook wb = new HSSFWorkbook();
    			List<Object[]> instanceList = new ArrayList<Object[]>();
    			String id = param.get("id").toString();
    			String workflowCode = "lowvalue_asset_apply";
    			//流程审批信息
    	        Instance instance = workflowEngine.getInstance(workflowCode, id);
    	        if (instance != null) {
    	            instance.setAuditInfoList(workflowEngine.getShowAuditInfoList(instance.getInstanceId()));
    	            List<UTMap<String, Object>> maps = workflowEngine.getShowAuditInfoList(instance.getInstanceId());
    	            for(UTMap<String, Object> map2 : maps)
    	            {
    	            	Object[] objs = new Object[5];
    	    	        objs[0] = map2.get("nodeName")==null? "" : map2.get("nodeName").toString();
    	    	        objs[1] = map2.get("createUser")==null? "" : map2.get("createUser").toString();
    	    	        objs[2] = map2.get("createTime")==null? "" : map2.get("createTime").toString();
    	    	        objs[3] = map2.get("auditResult")==null? "" : map2.get("auditResult").toString();
    	    	        objs[4] = map2.get("auditComment")==null? "" : map2.get("auditComment").toString();
    	    	        instanceList.add(objs);
    	            }
    	        }
    			response.setCharacterEncoding("UTF-8");
    			response.setContentType("application/vnd.ms-excel");
    			String fileName = "低值易耗品申请记录.xls";
    			fileName = URLEncoder.encode(fileName, "UTF-8");
    			response.addHeader("Content-Disposition", "attachment;filename=" + fileName);
    					
    			exportLowValueApply(wb, map, instanceList);
    			
    			try {
					OutputStream out = response.getOutputStream();
	    			wb.write(out);
	    			out.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

    		}    		    		
		}catch(Exception e){
			logger.error("Exception", e);
    	}
	}
	
	private void exportLowValueApply(HSSFWorkbook wb, UTMap<String, Object> map, List<Object[]> instanceList) 
	{
        String sheetName = "低值易耗品申请";
        Object[] objs = new Object[7];
        objs[0] = map.get("name")==null? "" : map.get("name").toString();
        objs[1] = map.get("code")==null? "" : map.get("code").toString();
        objs[2] = map.get("type")==null? "" : map.get("type").toString();
        objs[3] = map.get("unitName")==null? "" : map.get("unitName").toString();
        objs[4] = map.get("createUser")==null? "" : map.get("createUser").toString();
        objs[5] = map.get("applyTime")==null? "" : map.get("applyTime").toString();
        objs[6] = map.get("remark")==null? "" : map.get("remark").toString();
        
        String[] rowsName = new String[] { "序号", "节点", "提交人", "提交时间", "审批结果", "审批意见" };
        List<Object[]> dataList = new ArrayList<Object[]>();
        List<Object[]> dataList1 = new ArrayList<Object[]>();
        String[] rowsName2 = new String[] {	"物品", "品牌", "规格型号", "单位", "单价（元）" , "数量", "金额", "状态"};
        String[] rowsName3 = new String[] { "申请物品", "品牌", "规格型号", "单位", "申请数" , "发放数", "发放人", "发放时间", "状态"};
        if(map.get("detailList") != null)
        {
        	List<UTMap<String, Object>> list = (List<UTMap<String, Object>>) map.get("detailList");
        	if(list != null && list.size() > 0)
        	{
        		for(UTMap<String, Object> item : list)
        		{
        			Object[] obj2 = new Object[8];
        			Object[] obj3 = new Object[9];
        			obj2[0] = (item.get("name")==null? "" : item.get("name").toString()) + "/" + (item.get("code")==null? "" : item.get("code").toString());
    		        obj2[1] = item.get("brand")==null? "" : item.get("brand").toString();
    		        obj2[2] = item.get("model")==null? "" : item.get("model").toString();
    		        obj2[3] = item.get("measure")==null? "" : item.get("measure").toString();
    		        obj2[4] = item.get("unitPrice")==null? "" : item.get("unitPrice").toString();
    		        obj2[5] = item.get("applyNum")==null? "" : item.get("applyNum").toString();
   		            obj2[6] = item.get("applyAmount")==null? "" : item.get("applyAmount").toString();
    		        obj2[7] = item.get("confirmStatus")==null? "" : item.get("confirmStatus").toString();  		      
    		        dataList.add(obj2);
    		        
    		        obj3[0] = (item.get("name")==null? "" : item.get("name").toString()) + "/" + (item.get("code")==null? "" : item.get("code").toString());
    		        obj3[1] = item.get("brand")==null? "" : item.get("brand").toString();
    		        obj3[2] = item.get("model")==null? "" : item.get("model").toString();
    		        obj3[3] = item.get("measure")==null? "" : item.get("measure").toString();
    		        obj3[4] = item.get("applyNum")==null? "" : item.get("applyNum").toString();
   		            obj3[5] = item.get("grantNum")==null? "" : item.get("grantNum").toString();
    		        obj3[6] = item.get("grantUserName")==null? "" : item.get("grantUserName").toString();  	
    		        obj3[7] = item.get("grantTime")==null? "" : (item.get("grantTime").toString()).split(" ")[0]; 
    		        obj3[8] = item.get("confirmStatus")==null? "" : item.get("confirmStatus").toString(); 
    		        dataList1.add(obj3);
        		}
        		
        	}
        }
        
        // 创建ExportExcel对象
        ExcelUtil excelUtil = new ExcelUtil();
        try{
            excelUtil.exportLowValue(sheetName, "低值易耗品申请单", objs, wb);
            int index = 8;
            if(dataList.size() > 0)
            {
                excelUtil.exportLowValueDetailList(sheetName, "申请详单", rowsName2, dataList, wb, index, false);
                index = index + 4 + dataList.size();
            }
            if(instanceList.size() > 0)
            {
            	excelUtil.exportAssetApplyInstance(sheetName, "流程详情", rowsName, instanceList, wb, index, false);
            	index = index + 4 + instanceList.size();
            }
            if(dataList1.size() > 0)
            	excelUtil.exportLowValueResult(sheetName, "领用确认单", rowsName3, dataList1, wb, index, false);
        }catch(Exception e){
            e.printStackTrace();
        }
	}
}