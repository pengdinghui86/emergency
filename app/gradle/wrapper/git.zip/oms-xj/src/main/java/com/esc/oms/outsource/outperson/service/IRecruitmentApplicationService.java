package com.esc.oms.outsource.outperson.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;


/**
 * 人力资源申请
 * @author djj
 * @date   2016-07-18
 */
public interface IRecruitmentApplicationService extends IBaseOptionService {
	
	public List<UTMap<String, Object>> getPageList(UTPageBean pageBean,Map params);

//	public boolean leadingin(String filePath, Map<String, Object> param) throws Exception ;
	
	public boolean leadingout(List data, HttpServletRequest request,HttpServletResponse response) throws Exception ;
	
	public boolean leadingoutDetail(List data, HttpServletRequest request,HttpServletResponse response) throws Exception;
	
//	public UTMap<String, Object> getExportDataById(String id);

	public void getPendApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params);

	public void getAlreadyApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params);
	/**
	 * 申请单分发
	 * @param info
	 */
	public void distribute(Map<String, Object> info);
	/**
	 * 获取人力外包供应商
	 * @param param
	 * @return
	 */
	public List<UTMap<String, Object>> getManpowerSuppliers(Map<String, Object> param);
	/**
	 * 关闭
	 * @param info
	 */
	public void close(Map<String, Object> info);
	/**
	 * 人力资源列表（分页）-包括申请详单
	 * @param pageBean
	 * @param param
	 */
	public void getPageInfoDetail(UTPageBean pageBean, Map param);

	/**
	 * 人力资源列表-包括申请详单
	 * @param param
	 */
	public List<UTMap<String, Object>> getListAllDetail(Map params);
	/**
	 * 部门人力需求报表
	 * @param params
	 * @return
	 */
	public Map<String, Object> getOrgReport(Map<String, Object> params);
	/**
	 * 获取人力外包人力类型
	 * @param param
	 * @return
	 */
	public List<UTMap<String, Object>> getManpowerCategorys(Map<String, Object> param);

	public UTMap<String, Object> getReviewFile(String applyId);

	public boolean submitViewForm(Map<String, Object> param);

	public UTMap<String, Object> getReviewFileById(String id);

	public List<UTMap<String, Object>> getProjectRes(Map<String, Object> param);

}
