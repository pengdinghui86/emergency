package com.esc.oms.outsource.manhour.service.impl;

import com.esc.oms.outsource.manhour.service.IVacationService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.TaskModel;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.workflow.service.IWorkflowCallback;
import org.esc.framework.workflow.service.IWorkflowCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class VacationWorkflowCallback implements IWorkflowCallback {
	
	@Resource
	private IVacationService vacationService;
	
	@Resource
	private IUserTaskService userTaskService;
	
	protected Logger logger = LoggerFactory.getLogger(getClass());
	/**
	 * 返回流程编码
	 * @return
	 */
	public String workflowCode() {
		return IWorkflowCode.OUTSOURCE_MANHOUR_LEAVE;
	}
	
	/**
	 * 回调方法。
	 * 流程完成时，业务上需要进行的相应操作。
	 * @param businessRecordId
	 */
	public void onFinish(String businessRecordId) {
		vacationService.finishAudit(businessRecordId);
	}


	/**
	 * 回调方法。
	 * 流程回到开始节点时，业务上需要进行的相应操作。
	 * @param businessRecordId
	 */
	public void onReject(String businessRecordId) {
		vacationService.rejectAudit(businessRecordId);
	}
	

	/**
	 * 	回调方法 
	 * 到达某一节点时执行 对应的业务方法
	 * @param businessRecordId
	 */
	public void optionNode(String workflowCode, String businessRecordId,
			String nodeName, String linkName) {
		logger.info(CommonUtils.vaildLog("workflowCode:" + workflowCode + "businessRecordId:" + businessRecordId + "nodeName:" + nodeName + "linkName:" + linkName));
		vacationService.auditing(businessRecordId);
	}
	
	/**
	 * 发送任务
	 * */
	public void sendTask(String workflowName,String businessRecordId,String nodeName,String userId){
		UTMap<String,Object> utMap = vacationService.getById(businessRecordId);
		String beginTime = UTDate.getDateStr((String) utMap.get("beginTime"));
		String endTime = UTDate.getDateStr((String) utMap.get("endTime"));
		userTaskService.addTaskByUserId(
				"【" + utMap.get("submitUser") + "】" + beginTime + "至" + endTime + "请假申请待您审批", 
				businessRecordId, nodeName, TaskModel.vacation, userId);
	}

	@Override
	public void onTerminate(String businessRecordId) {
		vacationService.terminateAudit(businessRecordId);
	}
	

}
