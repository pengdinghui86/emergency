package com.esc.oms.outsource.outperson.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;


/**
 * 简历-基本信息
 * @author djj
 * @date   2016-07-18
 */
public interface IOutSourcePersonResumeInfoService extends IBaseOptionService {
	
	public List<UTMap<String, Object>> getPageList(UTPageBean pageBean,Map params);

	public boolean leadingin(String filePath, Map<String, Object> param) throws Exception ;
	
	public boolean leadingout(List data, HttpServletRequest request,	HttpServletResponse response) throws Exception ;
	
	public UTMap<String, Object> getExportDataById(String id);

	public List<UTMap<String, Object>> getRecommendResumeList(Map<String, Object> param);
}
