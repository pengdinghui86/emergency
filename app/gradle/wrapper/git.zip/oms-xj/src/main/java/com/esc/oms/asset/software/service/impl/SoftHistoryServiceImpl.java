package com.esc.oms.asset.software.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.upload.annotation.UploadQueryMarks;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.asset.software.dao.ISoftHistoryDao;
import com.esc.oms.asset.software.service.ISoftHistoryService;


@Service
@Transactional
public class SoftHistoryServiceImpl extends BaseOptionService implements
		ISoftHistoryService {

	@Resource
	private ISoftHistoryDao softHistoryDao;
	
	
	/**
	 * 添加
	 * @param info
	 * @return
	 */
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean add(Map info){
		return super.add(info);
	}
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		return super.getById(id);
	}
	

	/**
	 * 修改
	 * @param info
	 * @return
	 */
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean updateById(Map info){
		return super.updateById(info);
	}
	
	
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return softHistoryDao;
	}


	@Override
	@UploadQueryMarks
	public List<UTMap<String, Object>> getHistoryListBySoftId(Map param) {
		return softHistoryDao.getHistoryListBySoftId(param);
	}

	@Override
	public List<UTMap<String, Object>> getHistoryListByDisableDate(Map param) {
		return softHistoryDao.getHistoryListByDisableDate(param);
	}
	
}
