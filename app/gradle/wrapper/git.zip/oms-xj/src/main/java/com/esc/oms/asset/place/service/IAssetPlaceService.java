package com.esc.oms.asset.place.service;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;

import java.util.List;
import java.util.Map;

/**
 * 
 * @author owner
 *
 */
public interface IAssetPlaceService extends IBaseOptionService{

	/**
	 * 自定义 资源查询  按条件获取
	 * @param
	 * @return
	 */
//	public List<UTMap<String, Object>> getResouceList(Map param);
	
	public UTMap<String,Object>  getIdByNameAndCode(String name,String code);

	public List<UTMap<String, Object>> getListByParentId(String parentId);

	public List<UTMap<String, Object>> getAssetPlaceUByPlaceId(String assetPlaceId);

	/**
	 * 获取连续可用的机柜U
	 * @param map
	 * @return
	 */
	public List<UTMap<String, Object>> getUsableList(Map<String, Object> map);

}
