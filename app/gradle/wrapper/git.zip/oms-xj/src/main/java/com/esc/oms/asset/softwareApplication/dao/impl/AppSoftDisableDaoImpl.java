package com.esc.oms.asset.softwareApplication.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.asset.softwareApplication.dao.IAppSoftDisableDao;
import com.esc.oms.util.RoleUtils;

@Repository
public class AppSoftDisableDaoImpl extends BaseOptionDao implements IAppSoftDisableDao {

	private static final String  TABLE_NAME="software_application_disable";

	@Override
	public String getTableName() {
		return TABLE_NAME;
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params), pageBean, null);
	}
	
	
	public String getSearchSql(Map params){
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT asd.id,asl.name AS softwareId,asd.disableDate,asd.reason,asd.spare");
		sql.append(" FROM "+TABLE_NAME+" asd");
		sql.append(" LEFT JOIN software_application_library asl ON asd.softwareId = asl.id");
		sql.append(" WHERE 1=1");
		
		//数据权限过滤
		if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR,RoleUtils.ASSET_MANAGER)){
			sql.append("  and asl.chargeId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' ");
		}
		
//		if(params!=null && params.size()>0){		
//			if(params.get("softwareId")!=null &&  StringUtils.isNotEmpty(params.get("softwareId").toString())){
//				sql.append(" AND asd.softwareId = '"+params.get("softwareId").toString().trim()+"' ");
//			}
//		}
		
		if(params!=null && params.size()>0){		
			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
				sql.append(" AND asl.name like '%"+params.get("name").toString().trim()+"%' ");
			}
		}
		
		sql.append(" order by asd.createTime desc");
		return sql.toString();
	}
	
	
	@Override
	public List<UTMap<String, Object>> getSoftDisableList(Map param) {
		return super.getListBySql(getSearchSql(param));
	}

	@Override
	public List<UTMap<String, Object>> getSoftDisableListByDisableDate(Map param) {
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT * "
				+ " FROM "+TABLE_NAME+" asu");
		sql.append(" WHERE asu.`disableDate` = '"+param.get("disableDate").toString().trim()+"' ");
		return super.getListBySql(sql.toString());
	}
	

}
