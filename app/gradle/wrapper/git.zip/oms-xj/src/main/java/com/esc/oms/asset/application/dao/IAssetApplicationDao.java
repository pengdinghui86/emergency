package com.esc.oms.asset.application.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

public interface IAssetApplicationDao extends IBaseOptionDao{
	
	public boolean addAssetIssue(Map info);
	
	public boolean deleteAssetIssueById(String id);
	
	public boolean deleteAssetIssueByAssetId(String id);
	
	public List<UTMap<String, Object>> getAssetIssueListMaps(Map param);
	
	public List<UTMap<String, Object>> getAssetListByAppId(Map param);
	
	public boolean updateIssueStatusById(String id,String status);
	
	public boolean updateAssetIssueById(Map<String,Object> info);
	
	public List<UTMap<String, Object>> getAssetIssuePageInfo(Map param);
	
	public boolean deleteAssetIssueByAppId(String id);
	
	public UTMap<String, Object> getAssetIssueById(String id);
	
	public boolean updateAssetIssueStatusByAppId(String appId,
			String status);
	
	public boolean checkAssetIssueConfirm(String appId, String status);
	
	public List<UTMap<String,Object>> getIssueAssetByStatus(String assetId);

	public List<UTMap<String, Object>> getAssetsList(Map<String, Object> param);

}
