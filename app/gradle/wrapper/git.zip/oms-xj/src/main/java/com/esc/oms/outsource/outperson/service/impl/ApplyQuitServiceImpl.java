package com.esc.oms.outsource.outperson.service.impl;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.dict.dao.ISysParamDao;
import org.esc.framework.dict.util.UTParamTransform;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.idgenerator.IDGenerationManager;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.poi.tempfrom.tempoption.IFormModelData;
import org.esc.framework.security.dao.ISysUserDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.workflow.service.IWorkflowCode;
import org.esc.framework.workflow.service.IWorkflowEngine;
import org.esc.framework.workflow.utils.bpmn.FlowForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.outperson.dao.IApplyEnterDao;
import com.esc.oms.outsource.outperson.dao.IApplyExitDao;
import com.esc.oms.outsource.outperson.dao.IApplyQuitDao;
import com.esc.oms.outsource.outperson.service.IApplyCommonService;
import com.esc.oms.outsource.outperson.service.IApplyNoticeService;
import com.esc.oms.outsource.outperson.service.IApplyQuitService;
import com.esc.oms.outsource.outperson.service.IOutSourcePersonConfigService;
import com.esc.oms.outsource.outperson.service.IPersonOptionService;
import com.esc.oms.supplier.project.dao.IProjectInfoDao;
import com.esc.oms.supplier.supplieremp.dao.ISupplierEmpDao;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;
import com.esc.oms.util.FunctionEnum.WorkRecordType;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ParamUtils;
import com.esc.oms.util.TaskModel;

@Service
@Transactional
public class ApplyQuitServiceImpl extends BaseOptionService implements IApplyQuitService,IFormModelData{
	
	protected Logger logger = LoggerFactory.getLogger(getClass());
	
	@Resource
	private IApplyQuitDao applyQuitDao;
	@Resource
	private ISysUserDao userDao;
	@Resource
	private IOutSourcePersonConfigService personConfigService;
	@Resource
	private IApplyNoticeService noticeService;
	@Resource
	private MessageSend messageSend;
	@Resource
	private ISysParamDao paramDao;
	@Resource
	private IUserTaskService userTaskService;
	@Resource
	private ISupplierEmpDao supplierEmpDao;
	@Resource
	private IProjectInfoDao projectInfoDao;
	@Resource
	private IApplyExitDao applyExitDao;
	@Resource
	private IPersonOptionService personOptionService;
	
	@Resource
	private IWorkflowEngine workflowEngine;
	private static final String STATUS_NOT_SUBMIT = "1";	// 未提交 待提交
	private static final String STATUS_APPROVAL  = "2";	//待审批  
	private static final String STATUS_AUDITING = "3";	// 审批中  
	private static final String STATUS_FINISH = "4";	// 审批完成  离职通知
	private static final String STATUS_REJECT = "5";	// 驳回
	private static final String STATUS_STOP  = "6";	// 被终止
	private static final String STATUS_CONFIG  = "7";	// 离职确认
	private static final String STATUS_OVER  = "8";	// 完成
	
	public IBaseOptionDao getOptionDao() {
		return applyQuitDao;
	}
	public String workflowCode() {
		return IWorkflowCode.OUTSOURCE_PERSON_QUIT;
	}
	@Override
	public String tempCode() {
		return "formTemp.quitApplyTemp";
	}
	//新增
	@EscOptionLog(module=SystemModule.outsourcePersonQuit, opType=ESCLogOpType.INSERT, table="outsourc_apply_quit_info",
	primaryKey="id={1.id}",option="新增外包人员离场信息：{1.quitUserName}的退出离职申请记录")
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean add(Map info){

		info.put("createUserId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
		String userId=info.get("quitUserId").toString();
		String userQuitName=userDao.getById(userId).get("name").toString();
		info.put("quitUserName", userQuitName);
		if (!info.containsKey("applyNumber")) {
			String quitApplyNumber=	IDGenerationManager.nextId("quitApplyNumber").toString();
			info.put("applyNumber",quitApplyNumber);
		}
		
		if (!info.containsKey("status")) {
			info.put("status",STATUS_NOT_SUBMIT);
		}
		
		Map<String, Object> map=new HashMap<String, Object>();
		map.put("quitUserId", userId);
		map.put("supplierId", info.get("supplierId").toString());
		if(isExist(map)){
			throw new EscServiceException("外包人员"+userQuitName+"的离职申请已存在");
		}
		//校验离职申请人员是否已经提交了退场申请，且退场申请已经审核通过
		Map<String, Object> map2=new HashMap<String, Object>();
		map2.put("exitUserId", userId);
		map2.put("supplierId", info.get("supplierId").toString());
		List<UTMap<String, Object>> exitList = applyExitDao.getListMaps(map2);
		if (null == exitList || exitList.isEmpty()) {
			throw new EscServiceException("外包人员"+userQuitName+"未提交退场申请");
		}
		
		UTMap<String, Object> exitMap = exitList.get(0);
		Integer status = Integer.valueOf(exitMap.get("status") == null ? "0" : exitMap.get("status").toString());
		if (status < 7) {//未审批完成的退场申请
			throw new EscServiceException("外包人员"+userQuitName+"提交的退场申请未审核通过");
		}
		
		return super.add(info);
	}
	
	//根据id 修改
	
	@EscOptionLog(module=SystemModule.outsourcePersonQuit, opType=ESCLogOpType.UPDATE, table="outsourc_apply_quit_info", 
	primaryKey="id={1.id}",	option="修改外包人员离职信息：{1.quitUserName}的离职申请记录")
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean updateById(Map info) {
		String id=info.get("id").toString();
		UTMap<String, Object> oldInfo =applyQuitDao.getById(id, "quitUserId","supplierId");
		String newQuitUserId=info.get("quitUserId").toString();
		String newSupplierId=info.get("supplierId").toString();
		if(!StringUtils.equals(newQuitUserId, oldInfo.get("quitUserId").toString())
				||
		!StringUtils.equals(newSupplierId, oldInfo.get("supplierId").toString())){
			String quitUserName= userDao.getById(newQuitUserId).get("name").toString();
			Map<String, Object> map=new HashMap<String, Object>();
			map.put("quitUserId", newQuitUserId);
			map.put("supplierId",newSupplierId);
			if(isExist(map)){
				throw new EscServiceException("外包人员"+quitUserName+"的离职申请已存在");
			}
			/*Map<String, Object> map2=new HashMap<String, Object>();
			map.put("exitUserId", newQuitUserId);
			map.put("supplierId", newSupplierId);
			if(applyExitDao.isExist(map2)){
				throw new EscServiceException("外包人员"+quitUserName+"已提交退场申请");
			}*/
			
			//校验离职申请人员是否已经提交了退场申请，且退场申请已经审核通过
			Map<String, Object> map2=new HashMap<String, Object>();
			map2.put("exitUserId", newQuitUserId);
			map2.put("supplierId", newSupplierId);
			List<UTMap<String, Object>> exitList = applyExitDao.getListMaps(map2);
			if (null == exitList || exitList.isEmpty()) {
				throw new EscServiceException("外包人员"+quitUserName+"未提交退场申请");
			}
			
			UTMap<String, Object> exitMap = exitList.get(0);
			Integer status = Integer.valueOf(exitMap.get("status") == null ? "0" : exitMap.get("status").toString());
			if (status < 7) {//未审批完成的退场申请
				throw new EscServiceException("外包人员"+quitUserName+"提交的退场申请未审核通过");
			}
			info.put("quitUserName",quitUserName);
		}
		
		return super.updateById(info);
	}

	
	@EscOptionLog(module=SystemModule.outsourcePersonQuit, opType=ESCLogOpType.DELETE, table="outsourc_apply_quit_info", 
	primaryKey="id={1}",	option="删除的外包人员离职申请记录")
	public boolean deleteById(String id){
		return applyQuitDao.deleteByIds(id);
	}

	
	@EscOptionLog(module=SystemModule.outsourcePersonQuit, opType=ESCLogOpType.DELETES, table="outsourc_apply_quit_info", 
	primaryKey="id={1}",	option="删除的外包人员离职申请记录")
	public boolean deleteByIds(String ids){
		return applyQuitDao.deleteByIds(ids);
	}

	
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		UTMap<String, Object> result = super.getById(id);
		return result;
	}
	
	//提交
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public void submit(Map<String,Object> map) {
		map.put("status", STATUS_APPROVAL);
		boolean flog=true;
		if(map.get("id") == null){
			flog=add(map);
    	}
		else{
			flog=updateById(map);
    	}
		String recordId =map.get("id").toString();
		//启动流程
		runInstanceId(recordId);
	}
	
	// 启动流程实例设置
	private void runInstanceId(String recordId){
		//启动流程实例
		String supplierId=applyQuitDao.getById(recordId, "supplierId").get("supplierId").toString();
		Map<String, Object> formMap = new HashMap<String, Object>();
		formMap.put(FlowForm.FormItemValue.TDGYS ,supplierId);
		String workflowInstanceId = workflowEngine.runInstance(IWorkflowCode.OUTSOURCE_PERSON_QUIT, recordId, formMap);
		
		//String workflowInstanceId = workflowEngine.runInstance(IWorkflowCode.OUTSOURCE_PERSON_QUIT, recordId);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("processId", workflowInstanceId);
		applyQuitDao.updateById(map);
		//如果没有流程 则结束流程审批状态
		if(StringUtils.isEmpty(workflowInstanceId)){
			onFinish(recordId);
		}
	}

	//审批流程驳回
	public void onReject(String recordId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("status", STATUS_REJECT);
		applyQuitDao.updateById(map);
		
		Map<String, Object> info=	applyQuitDao.getById(recordId, "createUserId","quitUserName");
		if(info==null||info.get("createUserId")==null){
			return;
		}
		String userName=info.get("quitUserName").toString();
		messageSend.sendMessage(info.get("createUserId").toString(), 
				"外包人员【"+userName+"】离职申请驳回提醒", 
				"外包人员【"+userName+"】的离职申请已被驳回，请知悉！详情请进入系统查看", MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
	
	}

	//审批流程结束
	public void onFinish(String recordId) {
		try {
			//修改申请单状态
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("id", recordId);
			//map.put("status", STATUS_FINISH);
			map.put("status", STATUS_OVER);//不需要通知和确认，所有审批流程结束，整个申请就完成了
			applyQuitDao.updateById(map);
			//删除人员关联业务
			UTMap<String, Object> applyInfo=applyQuitDao.getById(recordId, "quitUserId", "quitDate",  "remark");
			Map<String, String> infoMap=	UTMap.mapObjToString(applyInfo);
			String userId=infoMap.get("quitUserId");
			String deleteDate=infoMap.get("quitDate");
			String reason="离职";
			String remark=infoMap.get("remark");
			personOptionService.deletePersonService(userId, deleteDate, reason, remark, WorkRecordType.LEAVEOFFER);
			//发送消息
			//sendNodice(recordId);
		} catch (Exception e) {
			logger.error("Exception",e);
		}
	}

	//流程终止不进行 外包人员离职信息退出状态的修改
	public void onTerminate(String recordId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("status", STATUS_STOP);
		applyQuitDao.updateById(map);
		
		Map<String, Object> info=	applyQuitDao.getById(recordId, "createUserId","quitUserName");
		if(info==null||info.get("createUserId")==null){
			return;
		}
		String userName=info.get("quitUserName").toString();
		messageSend.sendMessage(info.get("createUserId").toString(), 
				"外包人员【"+userName+"】离职申请终止提醒", 
				"外包人员【"+userName+"】的离职申请已被终止，请知悉！详情请进入系统查看", MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
	
	}

	//审批流程 操作到某一个节点
	public void optionNode(String workflowCode, String recordId,
			String nodeName, String linkName) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("status", STATUS_AUDITING);
		applyQuitDao.updateById(map);
	}

	public void sendTask(String workflowName, String recordId,
			String nodeName, String userId) {
		String userName=applyQuitDao.getById(recordId, IApplyQuitDao.FIELD_QUITUSERNAME).get( IApplyQuitDao.FIELD_QUITUSERNAME).toString();
		//获取供应商名称
		userTaskService.addTaskByUserId("人员【"+userName+"】离职申请待您审批", recordId, nodeName, TaskModel.outSourcePersonQuit, userId);
	}

	//查询外包人员离职信息列表 
	public List<UTMap<String, Object>> searchInfo(Map<String, Object> params) {
		return applyQuitDao.searchInfo(params);
	}
	
	//查询外包人员离职信息列表
	public void searchInfoPage( UTPageBean pageBean,Map<String, Object> params) {
		 applyQuitDao.searchInfoPage(pageBean, params);
	}
	
	//查询外包人员离职信息 待审列表
	public void getPendApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) {
		applyQuitDao.getPendApprovalPageInfo(pageBean, params);
	}

	//查询外包人员离职信息 已审列表
	public void getAlreadyApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) {
		applyQuitDao.getAlreadyApprovalPageInfo(pageBean, params);
	}
	
	//导出
	public void exportData(List<UTMap<String, Object>> recordList, HttpServletRequest request, HttpServletResponse response)
		throws Exception {

		UTParamTransform statusTransform = new UTParamTransform(paramDao,"personQuitStatus");
		String[] fileds = new String[] {
				IApplyQuitDao.FIELD_QUITUSERNAME,
				"createTime",
				"supplierName",
				IApplyEnterDao.FIELD_DEPARTMENTNAME,
				IApplyQuitDao.FIELD_QUITDATE,
				"remark",
				"status"
			 };
		String tamlate="excelOutTamplate.outSourcePersonQuitLeadOut";

		Map<String, Object> p=new HashMap<String, Object>();
		for (Object info : recordList) {
			Map<String, Object> map=(Map<String, Object>) info;
			//时间转换
			Object userName	=	map.get(IApplyQuitDao.FIELD_QUITUSERNAME).toString();
			Object orgName=map.get(IApplyEnterDao.FIELD_DEPARTMENTNAME);
			Object QUITDATE=map.get(IApplyQuitDao.FIELD_QUITDATE);
			String QUITDATESTR=QUITDATE!=null?UTDate.getDateStr(QUITDATE.toString(), UTDate.DATE_FORMAT):"";

			String status=map.get(IApplyQuitDao.FIELD_STATUS)!=null?map.get(IApplyQuitDao.FIELD_STATUS).toString():"1";
			String statusStr=statusTransform.value2Name(status);
			map.put(IApplyQuitDao.FIELD_STATUS,statusStr );
			
//			map.put(IApplyEnterDao.FIELD_ISIN, ISKEYPERSON==null?"否":Integer.valueOf(ISIN.toString())==1?"是":"否");
//			map.put(IApplyEnterDao.FIELD_ISKEYPERSON, ISKEYPERSON==null?'否':Integer.valueOf(ISKEYPERSON.toString())==1?"是":"否");
			
			String oString=orgName!=null?orgName.toString().replaceAll("!","/"):null;
			map.put(IApplyQuitDao.FIELD_QUITDATE, CommonUtils.replaceAll(QUITDATESTR, "-", "/"));
			map.put("createTime",CommonUtils.replaceAll((String)map.get("createTime"), "-", "/"));
			map.put(IApplyEnterDao.FIELD_DEPARTMENTNAME,oString );
			map.put(IApplyQuitDao.FIELD_QUITUSERNAME,userName );
		}
		
		UTExcel.leadingout( fileds, recordList, tamlate, request,response);
	}
	

	//======================退场信息审核通过后 

//	//1.信息与 用户，供应商人，外包人员同步
//	//1.信息与 用户，供应商人，外包人员同步 删除(逻辑删除)
//	public void deleteSysSupplierUser(String applyId){
//		UTMap<String, Object> applyInfo=applyQuitDao.getById(applyId);
//		Map<String, String> infoMap=	UTMap.mapObjToString(applyInfo);
//		String userId=infoMap.get("quitUserId");
//		String quitDate=infoMap.get("quitDate");
//		String reason=infoMap.get("quitReason");
//		String remark=infoMap.get("remark");
//		//删除用户（逻辑删除）
//		Map<String, String> userInfo=	new HashMap<String, String>();
//		userInfo.put("id", userId);
//		userInfo.put("state",ESCDataState.CANCEL.getValue().toString());
//		userDao.updateById(userInfo);
//		//删除供应商人员（逻辑删除）
//		Map<String, String> empInfo=new HashMap<String, String>();
//		empInfo.put("userId", userId);
//		empInfo.put("state",ESCDataState.CANCEL.getValue().toString());
//		empInfo.put("endDate", quitDate);
//		empInfo.put(ISupplierEmpDao.FIELD_ISVALID,ESCDataState.CANCEL.getValue().toString());
//		empDao.updateBy(empInfo, "userId");
//		//删除外包人员（逻辑删除）
//		Map<String, String> person=	new HashMap<String, String>();
//		person.put("userId", userId);
//		person.put("state",ESCDataState.CANCEL.getValue().toString());
//		personDao.updateBy(person, "userId");
//		//注销系统用默认权限
//		personConfigService.cancelConfigByUserId(userId);
//		//释放项目人力资源
//		projectResService.releaseByProjectAndUser(null,userId);
//		//释放考核配置
//		userConfigService.deleteByUserId(userId);
//		//合同服务团队释放
//		agreementTeamService.release(userId);
//		//添加轨迹
//		workrecordDao.add(userId, "外包人员离职", quitDate, null, remark, WorkRecordType.LEAVEOFFER.getName(), WorkRecordType.LEAVEOFFER);
//	}

	public boolean cancelConfigByUserId(Map<String, Object> param) {

		Map baseInfo = (Map) ((param == null ? false : param.containsKey("baseInfo"))? param.get("baseInfo"):null);
   		if(baseInfo != null)
   		{
			String submit=baseInfo.get("issubmit").toString();
			String applyId=baseInfo.get("applyId").toString();
	   		if(StringUtils.equals(submit, "1")){
	   			List configsInfo =(List) (param.containsKey("configInfo")? param.get("configInfo"):null);
				boolean flog=	personConfigService.cancelConfigByUserId(configsInfo);
	   			//保存并提交
	   			Map<String,Object> applyInfo=new HashMap<String, Object>();
	   			applyInfo.put("id",applyId);
	   			applyInfo.put("confimUserId",EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
	   			applyInfo.put("confimDate",UTDate.getCurDate());
	   			applyInfo.put("status",ApplyQuitServiceImpl.STATUS_OVER);
	   			super.updateById(applyInfo);
	   			//发送通知
	   			//sendNodice(applyId);
	    		return flog;
	   		}else{
	   			//保存信息 但不提交
	   			Map<String,Object> applyInfo=new HashMap<String, Object>();
	   		//	String applyId=param.get("applyId").toString();
	   			applyInfo.put("id",applyId);
	   			applyInfo.put("confimUserId",EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
	   			applyInfo.put("confimDate",UTDate.getCurDate());
	   			super.updateById(applyInfo);
				List configsInfo =(List) (param.containsKey("configInfo")? param.get("configInfo"):null);
				return	personConfigService.cancelConfigByUserId(configsInfo);
	   		}
   		}
   		else {
			return false;
		}
	}
	
	//3.信息配置后发通知
	private void sendNodice(String applyId) {
		noticeService.sendApplyNoticeInfo(applyId, IApplyCommonService.APPLY_TYPE_QUIT);
		Map<String,Object> applyInfo=new HashMap<String, Object>();
			applyInfo.put("id",applyId);
			applyInfo.put("status",ApplyQuitServiceImpl.STATUS_CONFIG);
			super.updateById(applyInfo);
	}
	
	@Override
	public Map<String, Object> setModelData(String recordId) {
		Map<String, String> info=  UTMap.mapObjToString(applyQuitDao.getById(recordId));
		Map<String, Object> model= new HashMap<String, Object>();
	//UTParamTransform statusTransform2 = new UTParamTransform(paramDao,"exitReasonList");
		
		String quitUserName=info.get("quitUserName")!=null?info.get("quitUserName"):"";
		String idCode=info.get("idCode")!=null?info.get("idCode"):"";
		String phone=info.get("phone")!=null?info.get("phone"):"";
		String orgName=info.get("departmentName")!=null?info.get("departmentName").replaceAll("!", "/"):"";
		String quitDate=StringUtils.isNotEmpty("quitDate")?UTDate.chinaDate( info.get("quitDate")):"";
		String quitReason=info.get("remark")!=null?info.get("remark").toString():"";
		String supplierName=info.get("supplierName")!=null?info.get("supplierName"):""; 
		String applyNumber=info.get("applyNumber")!=null?info.get("applyNumber"):UTDate.getCurDate();
		String userId=info.get("quitUserId")!=null?info.get("quitUserId"):""; 
		String mainProject="";
		boolean mj=false;
		String mjCancelDate="";
		String mjCancelPerson="";
		boolean wl=false;
		String wlCancelPerson="";
		String wlCancelDate="";
		
		//获取 现阶段 人员入场日期和 所属主项目
		Map<String, String> empInfo=	 UTMap.mapObjToString(supplierEmpDao.getSupplierEmpDetailedByUserId(userId));
		String enterDate=empInfo!=null&&empInfo.size()>0&&StringUtils.isNotEmpty("inFactoryDate")?empInfo.get("inFactoryDate"):"";//入场日期
		String mainProjectId=empInfo.get("mainProjectId")!=null?empInfo.get("mainProjectId"):"";
		if(StringUtils.isNotEmpty(mainProjectId)){
			mainProject=projectInfoDao.getById(mainProjectId, "name").get("name").toString();
		}
		
		//获取人员配置情况
		List<UTMap<String, Object>> configs= personConfigService.getPersonConfig(userId);
		for (UTMap<String, Object> utMap : configs) {
			String itemName=utMap.get("itemName").toString();
			String cancelPerson=utMap.get("cancelPerson")!=null?utMap.get("cancelPerson").toString():"";
			String cancelDate=utMap.get("cancelDate")!=null&&StringUtils.isNotEmpty("cancelDate")?UTDate.chinaDate(utMap.get("cancelDate").toString()):"";
			//boolean isConfig=Integer.valueOf(utMap.get("isConcel").toString())==1?true:false;
			boolean isConfig=utMap.get("isConcel")!=null&&(StringUtils.equals(utMap.get("isConcel").toString(), "1"))?true:false;
			if(itemName.indexOf("门禁")>-1){
				mj=isConfig;
				if(!mj){
					continue;
				}
				//获取人员配置属性
				mjCancelPerson	=cancelPerson;
				mjCancelDate=cancelDate;
			}
			if(itemName.indexOf("网络")>-1){
				wl=isConfig;
				if(!wl){
					continue;
				}
				wlCancelPerson=cancelPerson;
				wlCancelDate=cancelDate;
			}
		}

		//model.put(IFormModelData.TEMP_FILE_NAME, quitUserName+"入场申请单");
		model.put("applyNumber", applyNumber);
		model.put("quitUserName",quitUserName);
		model.put("supplierName",supplierName);
		model.put("idCode", idCode);
		model.put("projectName", mainProject);
		model.put("phone",phone);
		model.put("orgName",orgName);
		model.put("enterDate", UTDate.chinaDate(enterDate)  );
		model.put("quitDate", quitDate);

		model.put("sq", false);
		model.put("mj", mj);
		model.put("mjOpenDate",mjCancelDate);
		model.put("mjOpenPerson", mjCancelPerson);
		model.put("wl", wl);
		model.put("wlOpenPerson", wlCancelPerson);
		model.put("wlOpenDate", wlCancelDate);
		model.put("quitReason", quitReason);
		return model;
	}
	@Override
	public List<UTMap<String, Object>> getUserBaseInfo(Map<String, Object> param) {
		// TODO Auto-generated method stub
		return applyQuitDao.getUserBaseInfo(param);
	}

}