package com.esc.oms.outsource.performance.service;

import java.util.List;
import java.util.Map;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;

/**
 * 外包绩效考核
 * @author owner
 *
 */
public interface IPerformanceEvaluateService extends IBaseOptionService{
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params);
}
