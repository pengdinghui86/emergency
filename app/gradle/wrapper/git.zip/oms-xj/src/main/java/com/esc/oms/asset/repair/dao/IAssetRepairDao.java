package com.esc.oms.asset.repair.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

public interface IAssetRepairDao extends IBaseOptionDao{
	
	public static final String STATUS_NOT_SUBMIT = "0";	// 未提交
	public static final String STATUS_NOT_AUDITING = "1";	// 待审批
	public static final String STATUS_AUDITING = "2";	// 审批中
	public static final String STATUS_FINISH = "3";	// 已审批待维修  
	public static final String STATUS_ISSUEING = "4";// 维修中
	public static final String STATUS_CONFIRM = "5";// 已维修待确认   
	public static final String STATUS_CONFIRMING = "6";// 完成
	public static final String STATUS_REJECT = "7";// 驳回
	public static final String STATUS_TERMINATE = "8";	// 被终止
	
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_CODE = "code";
	public static final String  FIELD_NAME = "name";
	public static final String  FIELD_CREATE_USER = "createUser";
	public static final String  FIELD_CREATE_TIME = "createTime";
	public static final String  FIELD_REASON = "reason";
	public static final String  FIELD_REMARK = "remark";
	public static final String  FIELD_RESULT = "resultDesc";
	public static final String  FIELD_STATUS = "statusDesc";
	
	public boolean addRepairResult(Map info);
	
	public boolean updateRepairResultById(Map info);
	
	public UTMap<String, Object> getResultByRepairId(String repairId);
	
	public UTMap<String, Object> getOrgLongNameById(String id);
	
	public boolean deleteResultByRepairId(String repairId);
	
	public void getAssetsRepairRateCount(UTPageBean pageBean, Map params);
	
	public List<UTMap<String, Object>> getAssetsList(Map param);
	
}
