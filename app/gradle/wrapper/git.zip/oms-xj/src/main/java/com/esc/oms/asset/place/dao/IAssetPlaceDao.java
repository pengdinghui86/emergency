package com.esc.oms.asset.place.dao;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

import java.util.List;
import java.util.Map;

public interface IAssetPlaceDao extends IBaseOptionDao {
//	//表属性（属于表结构）
//	public static final String  FIELD_ID= "id";
//	public static final String  FIELD_CODE= "code";
//	public static final String  FIELD_NAME= "name";
//	public static final String  FIELD_RESOURCETYPE= "resourceType";
//	public static final String  FIELD_LONGCODE= "longCode";
//	public static final String  FIELD_LONGNAME= "longName";
//	public static final String  FIELD_ICON= "icon";
//	//public static final String  FIELD_URL= "url";//资源路径
//	public static final String  FIELD_PARENTID= "parentId";
//	public static final String  FIELD_PARENTNAME= "parentName";
//	public static final String  FIELD_STATE= "state";
//	public static final String  FIELD_REMARK= "remark";
//	public static final String  FIELD_ROUTERS= "routers";//路由
//	public static final String  FIELD_SIGNATURE= "signature";//权限标识
//
//	public static final String  FIELD_ELEMENTCOUNT= "elementCount";
//
//	public static final String  FIELD_UPDATEDATE= "updateDate";
//	public static final String  FIELD_UPDATEUSER= "updateUser";
//	//功能属性 （由于业务需要定义的属性不属于 表结构）
//	public static final String  FIELD_OLDPARENTID= "oldParentId";
	
//	public String getNewCode(String parentId,String parentCode);
	
	
	//根据 父节点获取下级 所有资源
	public List<UTMap<String, Object>> getChildrenResource(String parentLongCode);
	

	public List<UTMap<String, Object>> getResourceList(Map param) ;
	
	public UTMap<String,Object>  getIdByNameAndCode(String name,String code);

	public boolean addAssetPlaceU(List<Map> infos);


	public List<UTMap<String, Object>> getListByParentId(String parentId);


	public List<UTMap<String, Object>> getAssetPlaceUByPlaceId(String assetPlaceId);

	/**
	 * 获取可用的柜子
	 * @param map
	 * @return
	 */
	public List<UTMap<String, Object>> getUsableList(Map<String, Object> map);

	/**
	 * 根据资产id解除机柜和资产的关系
	 * @param assetId
	 * @return
	 */
	public boolean relievePlaceU(String assetId);

	/**
	 * 批量解除机柜和资产的关系
	 * @param assetIds
	 * @return
	 */
	public boolean batchRelievePlaceU(String assetIds);

	/**
	 * 根据机柜id获取范围内被占用的机柜
	 * @param assets_place_id 机柜id
	 * @param startU 开始u
	 * @param endU 结束u
	 * @return
	 */
	public String getOccupyPlaceU(String assets_place_id, int startU, int endU);

	/**
	 * 绑定资产和机柜U
	 * @param assets_place_id 机柜id
	 * @param assetId 资产id
	 * @param startU 开始U
	 * @param endU 结束u
	 * @return
	 */
	public boolean bindingsPlaceU(String assets_place_id, String assetId, int startU, int endU);
}
