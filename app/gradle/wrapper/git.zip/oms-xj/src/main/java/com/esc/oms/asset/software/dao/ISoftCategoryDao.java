package com.esc.oms.asset.software.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

public interface ISoftCategoryDao extends IBaseOptionDao{
	

	public List<UTMap<String, Object>> getListCategory(Map params) ;
	
	public boolean addSubCategory(Map info);
	
	
	/**
	 * 修改
	 * @param info
	 * @return
	 */
	public boolean updateSubCategoryById(Map info);
	
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	public UTMap<String, Object> getSubCategoryById(String id);
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	public List<UTMap<String, Object>> getSubPropertyById(String id);
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	public List<UTMap<String, Object>> getSubOptionById(String id);
	
	
	/**
	 * 删除
	 * @param info
	 * @return
	 */
	public boolean deleteSubProperty(String categoryId);
	
	
	/**
	 * 删除
	 * @param info
	 * @return
	 */
	public boolean deleteSubCategory(String categoryId);
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	public List<UTMap<String, Object>> getSubCategoryByParentId(String parentId);
	
	public String getCategoryIdByName(Map<String,Object> params);
	
	public String getSubCategoryIdByName(Map<String,Object> params);
	
	public boolean deleteSubCategoryByParentId(String categoryId);
	
	/**
	 * 检查资产小类是否已经存在name
	 * @param info
	 * @return
	 */
	public boolean checkSubCategory(Map info);
	
	public List<UTMap<String, Object>> getCategoryByNameAndId(String name,String id);
	
	public UTMap<String, Object> getSubCategoryByNameAndCategoryId(String name,String id);
	
	public List<UTMap<String, Object>> getSubCategoryByNameAndCategoryIdAndSubCategoryId(String name,String id,String parentId);
	
//	public UTMap<String, Object> getIdBySubCategoryNameAndCategoryName(String categoryName,String subCategoryName);

	public List<UTMap<String, Object>> getCategoryByType(String type) ;
}
