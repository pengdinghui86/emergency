package com.esc.oms.asset.physicalRegist.service;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;


public interface IPhysicalRegistService extends IBaseOptionService{
	/**
	 * 未提交
	 */
	public static final int STATUS_NOT_SUBMIT = 1; // 未提交
	/**
	 * 待审批
	 */
	public static final int STATUS_WAITING  = 2;	// 待审批
	/**
	 * 审批中
	 */
	public static final int STATUS_AUDITING = 3;	// 审批中
	/**
	 * 已完成
	 */
	public static final int STATUS_FINISH = 4;	// 已完成
	/**
	 *  驳回
	 */
	public static final int STATUS_REJECT = 5;	// 驳回
	/**
	 * 终止
	 */
	public static final int STATUS_TERMINATE = 6;	// 终止
	public List<UTMap<String, Object>> getAssetBycodeAndId(String codeNum,String id);
	
	public boolean leadingin(String filePath, Map<String, Object> param) throws Exception;
	
	public boolean leadingout(List data, HttpServletRequest request,HttpServletResponse response) throws Exception;
	
	public void getPendPageList( Map<String, Object> params, UTPageBean pageBean) throws Exception ;
	
	public void getAlreadyApprovalPageList( Map<String, Object> params, UTPageBean pageBean) throws Exception ;
	
	public void submit( Map<String,Object> map)throws Exception;
	
	public void finishAudit(String recordId);
	
	public void rejectAudit(String recordId) ;
	
	public void terminateAudit(String recordId);
	
	public void optionNode(String workflowCode, String recordId, String nodeName, String linkName);
	
	public void getPageInfo(Map<String, Object> params, UTPageBean pageBean) throws Exception;
	
}
