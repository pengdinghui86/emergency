package com.esc.oms.outsource.monitor.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.exception.EscServiceException;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.upload.annotation.UploadQueryMarks;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.monitor.dao.IDuediligenceEvaluateConfigurationDao;
import com.esc.oms.outsource.monitor.dao.IDuediligenceEvaluateDao;
import com.esc.oms.outsource.monitor.dao.IDuediligenceEvaluateTemplateDao;
import com.esc.oms.outsource.monitor.service.IDuediligenceEvaluateService;
import com.esc.oms.system.templateconfiguration.dao.ITemplateConfigurationDetailDao;
import com.esc.oms.system.templateconfiguration.dao.ITemplateConfigurationDetailDeputyResultDao;
import com.esc.oms.system.templateconfiguration.service.ITemplateConfigurationDetailDeputyService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;

/**
 * 尽职调查评估
 * @author owner
 *
 */
@Service
@Transactional
public class DuediligenceEvaluateServiceImpl extends BaseOptionService implements IDuediligenceEvaluateService{
	
	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private IDuediligenceEvaluateDao dao;
	
	@Resource
	private IDuediligenceEvaluateTemplateDao duediligenceEvaluateTemplateDao;
	
	//模板配置详情dao
	@Resource
	private ITemplateConfigurationDetailDao detailDao;
	
	//全面风险评估配置Dao
	@Resource
	private IDuediligenceEvaluateConfigurationDao duediligenceEvaluateConfigurationDao;
	
	//模板配置从属数据操作Service接口
	@Resource
	private ITemplateConfigurationDetailDeputyService templateConfigurationDetailDeputyService;
	
	//模板配置从属数据结果操作dao接口
	@Resource
	private ITemplateConfigurationDetailDeputyResultDao templateConfigurationDetailDeputyResultDao;

	//代办任务
	@Resource
	private IUserTaskService userTaskService;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return dao;
	}

	/**
	 * 添加
	 * @param info
	 * @return
	 */
//	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean add(Map info){
		super.add(info);
		return true;
	}
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		UTMap<String, Object> result = super.getById(id);
		String duediligenceEvaluateTemplateId = result.get("duediligenceEvaluateTemplateId")+"";//全面风险评估配置模板id
//		String evaluator = result.get("id")+"";//评估人
		result.put("treeData", templateConfigurationDetailDeputyService.getDetailsDeputy(duediligenceEvaluateTemplateId, id));
		return result;
	}
	
	/**
	 * 修改
	 * @param info
	 * @return
	 */
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	@EscOptionLog(module = SystemModule.duediligenceEvaluate, opType = ESCLogOpType.UPDATE, table = "outsourc_duediligence_evaluate", option = "更新尽职调查评估配置编号为{duediligenceEvaluateConfigId}的尽职评估。")
	public boolean updateById(Map info){
		String id = info.get("id")+"";//全面风险评估配置模板id
		Map existMap = new HashMap();
		existMap.put("id", id);
		if(!dao.isExist(existMap)){
			throw new EscServiceException("当前数据已经不存在，请刷新页面重新操作！");
		}
		info.put("evaluateTime", UTDate.getCurDateTime());//评估时间
		info.put("submitTime", UTDate.getCurDateTime());//提交时间
		info.put("status", 1);//评估状态
		info.put("submitter", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());//提交人
		List<Map> resultList = new ArrayList<Map>();
		List<Map> list= (List<Map>)info.get("treeData");
		String moduleTemplateConfigurationId = info.get("duediligenceEvaluateTemplateId")+"";
//		String evaluator = info.get("evaluator")+"";
		CommonUtils.setTemplateConfigurationDetailDeputyResult(moduleTemplateConfigurationId, id, list, resultList);
		//先删除
		templateConfigurationDetailDeputyResultDao.deleteByModuleTemplateConfigurationIdEvaluator(moduleTemplateConfigurationId, id);
		if(!resultList.isEmpty()){
			//后添加
			templateConfigurationDetailDeputyResultDao.adds(resultList);
			
		}
//		String duediligenceEvaluateConfigId = info.get("duediligenceEvaluateConfigId")+"";//全面风险评估配置模板id
//		UTMap<String, Object> duediligenceEvaluateTemplate = duediligenceEvaluateTemplateDao.getById(moduleTemplateConfigurationId);
//		String isSingle = duediligenceEvaluateTemplate.get("isSingle")+"";//是否单一数据，1：是，0：否，默认否
//		Map param = new HashMap();
//		param.put("duediligenceEvaluateConfigId", duediligenceEvaluateConfigId);//全面风险评估配置模板id
		//查询全面风险评估对应模板下的所有全面风险评估数据
//		List<UTMap<String, Object>> accessEvaluateList = dao.getListMaps(param);
//		boolean temp = false;
//		for (UTMap<String, Object> accessEvaluate : accessEvaluateList) {
//			String accessEvaluateId = accessEvaluate.get("id") + "";
//			String duediligenceEvaluateTemplateId = accessEvaluate.get("duediligenceEvaluateTemplateId") + "";
//			if(id.equals(accessEvaluateId)){//不判断当前数据
//				continue;
//			}
//			//当前评估的数据模板是单一数据，则把改模板下其它人的评估数据都删除
//			if("1".equals(isSingle) && duediligenceEvaluateTemplateId.equals(moduleTemplateConfigurationId)){
//				userTaskService.finishTask(accessEvaluate.get("id")+"");//完成代办任务
//				dao.delete(accessEvaluate);
//			}else{
//				String status = accessEvaluate.get("status") + "";//全面风险评估状态 
//				//存在待评估状态的数据
//				if(!temp && "0".equals(status)){
//					temp = true;
////					break;
//				}
//			}
//		}
		//只标识供应商全面风险评估模板对应的个人全面风险评估是否已经在评估，待评估：0，评估中：1，已评估：2
//		int accessEvaluateConfigurationStatus = 0;
//		if(temp){
//			accessEvaluateConfigurationStatus = 1;
//		}else{
//			accessEvaluateConfigurationStatus = 2;
//		}
//		Map accessEvaluateConfiguration = new HashMap();
//		//修改此状态用户判断评估配置可不可以修改或删除
//		accessEvaluateConfiguration.put("evaluateStatus", accessEvaluateConfigurationStatus);
//		accessEvaluateConfiguration.put("id", duediligenceEvaluateConfigId);
		//修改对应全面风险评估配置的状态
//		duediligenceEvaluateConfigurationDao.updateBy(accessEvaluateConfiguration, "id");
		userTaskService.finishTask(id);//完成代办任务
		//在过程评估后需要将评估人加入到评估配置的评估人字段中
		CommonUtils.setConfigurationEvaluator(duediligenceEvaluateConfigurationDao,info.get("duediligenceEvaluateConfigId").toString());
		return super.updateById(info);
	}
	
	
//	private void setTemplateConfigurationDetailDeputyResult(String moduleTemplateConfigurationId, String evaluator, List<Map> list, List<Map> resultList){
//		if(list == null){
//			return;
//		}
//		for (Map item : list) {
//			Map info = new HashMap();
//			if(item.get("result") != null){
//				String result = item.get("result").toString();
//				info.put("moduleTemplateConfigurationId", moduleTemplateConfigurationId);
//				String templateConfigurationDetailDeputyId = item.get("id").toString();
//				info.put("evaluator", evaluator);
//				info.put("templateConfigurationDetailDeputyId", templateConfigurationDetailDeputyId);
//				info.put("result", result);
//				resultList.add(info);
//			}
//			
//			String type = item.get("type").toString();//类型，1：填空，2：单选，3：多选，0：是配置项
//			if(("2".equals(type) || "3".equals(type)) && item.get("options") != null){//如果是单选或者多选，保存子配置项
//				List<Map> options = (List<Map>)item.get("options");
//				setTemplateConfigurationDetailDeputyResult(moduleTemplateConfigurationId,evaluator,options,resultList);
//			}
//			if(item.get("children") != null){//如果存在子节点数据
//				List<Map> children = (List<Map>)item.get("children");
//				setTemplateConfigurationDetailDeputyResult(moduleTemplateConfigurationId,evaluator,children,resultList);
//			}
//		}
//	}
	
	@Override
	public boolean deleteById(String id) {
		detailDao.deleteByTemplateConfigurationId(id);
		return super.deleteById(id);
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map param) {
		dao.getPageInfo(pageBean, param);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	@UploadQueryMarks
	public List<UTMap<String, Object>> getListAll(Map params){
		return dao.getListAll(params);
	}

}
