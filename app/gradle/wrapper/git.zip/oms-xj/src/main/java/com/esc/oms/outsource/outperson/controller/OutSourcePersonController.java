package com.esc.oms.outsource.outperson.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.outsource.outperson.service.IOutSourcePersonService;
import com.esc.oms.supplier.supplieremp.dao.ISupplierEmpDao;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.RoleUtils;

import net.sf.json.JSONObject;


/**
 * 外包人员列表
 * @author smq
 * @date   2016-2-24 上午10:39:04
 */
@Controller
@RequestMapping("outSourcePerson")
public class OutSourcePersonController extends BaseOptionController {
	@Resource
	private IOutSourcePersonService outSourcePersonService;

	@Override
	public IBaseOptionService optionService() {
		return outSourcePersonService;
	}
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getOutPersonPage")  
    @ResponseBody
    public UTPageBean getOutPersonPage(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			if(!setDataPrower(params)){
				pageBean.setRows(new ArrayList<UTMap<String, Object>>());
				return pageBean;
			}
			outSourcePersonService.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }

	/**
	 * 供应商人员信息 从excel导入
	 * @param params
	 * @param filePath
	 * @return
	 */
	@RequestMapping(value = "leadingin")
	@ResponseBody
	public UTMap<String, Object> leadingin(@RequestParam Map<String, Object> param, String filePath) {
		UTMap<String, Object> utMap = new UTMap<String, Object>();
		try {
			utMap.put("success", outSourcePersonService.leadingin(filePath , param));
			utMap.put("msg", "导入成功！");
		} catch (Exception e) {
			logger.error("Exception",e);
			utMap.put("success", false);
			utMap.put("msg", e.getMessage());
		}
		return utMap;
	}

	/**
	 * 供应商人员钉钉信息导入，与考勤有关
	 * @param param
	 * @param filePath
	 * @return
	 */
	@RequestMapping(value = "leadinginDing")
	@ResponseBody
	public UTMap<String, Object> leadinginDing(@RequestParam Map<String, Object> param, String filePath) {
		UTMap<String, Object> utMap = new UTMap<String, Object>();
		try {
			utMap.put("success", outSourcePersonService.leadinginDing(filePath , param));
			utMap.put("msg", "导入成功！");
		} catch (Exception e) {
			logger.error("Exception",e);
			utMap.put("success", false);
			utMap.put("msg", e.getMessage());
		}
		return utMap;
	}

	/**
	 * 供应商人员信息 导出Excel
	 * @param param
	 * @param utPageBean
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "leadingout")
	public void leadingout(@RequestParam Map<String, Object> map1,
			HttpServletRequest request,
			HttpServletResponse response) {
		//ParamObject object = CommonUtils.checkParam(map1, utPageBean1);
		Map<String, Object> param = CommonUtils.clone(map1);
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = JSONObject.fromObject(info);
			if(!setDataPrower(jsonBean)){
				logger.error("没有权限操作供应商数据");
				return ;
			}
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = outSourcePersonService.getListMaps(jsonBean);
			} else {
				outSourcePersonService.getPageInfo(utPageBean, jsonBean);
				data = utPageBean.getRows();
			}
			response.setCharacterEncoding("UTF-8");
			outSourcePersonService.leadingout(data, request, response);
		
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	
	/**
	 *  外包人员详细信息  通过UserId(包括基本信息和详细信息)
	 * 参数：userId 
	 * 结果：  id,   userId, `name`, supplierId, `level`, updateTime, updateUser, departId,
		   isHumanRes , isAccess, isAssess, isKeyPerson, chargeBeginDate, chargeEndDate, category, agreementId,
		   email, phone, idCode, sex, age, fixedPhone, code, img, sbi.`name` supplierName, org.longName orgName
	 * @param userId
	 * @return
	 */
	@RequestMapping("getOutEmpInfoUserId")
	@ResponseBody
	public UTMap<String, Object> getOutEmpInfoUserId(@RequestParam Map<String, Object> param){
		String userId=param.get("userId").toString();
		return outSourcePersonService.getOutEmpByUserId(userId);
	}
	
	/**
	 *   获取 外包人的外包人力合同 通过 用户Id 
	 * 参数：userId 
	 *  结果： 基本配置 baseConfig， 折算配置 vacationConfigs 费用配置  costConfigs
	 * @param userId
	 * @return
	 */
	@RequestMapping("getOutEmpAgreementInfoUserId")
	@ResponseBody
	public Map<String, Object> getOutEmpAgreementInfoUserId(@RequestParam Map<String, Object> param){
		String userId=param.get("userId").toString();
		return outSourcePersonService.getOutEmpAgreementById(userId);
	}
	
	
	/***
	 * 添加数据权限 控制
	 * ***/
	private boolean setDataPrower(Map<String, Object> param){
		 if(RoleUtils.isSupplierAdministrator()){
				return true;
		 }
		
		//如果是 供应商负责人
		if(Integer.valueOf( EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserType())!=1 ){
			//查询所管理的所有 供应商
			param.put(ISupplierEmpDao.FIELD_SUPPLIERID,EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId());
		}

		return true;
		
	}

}
