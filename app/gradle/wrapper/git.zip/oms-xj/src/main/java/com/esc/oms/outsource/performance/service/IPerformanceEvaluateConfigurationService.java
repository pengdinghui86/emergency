package com.esc.oms.outsource.performance.service;

import java.util.Map;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.utils.UTMap;

/**
 * 外包绩效考核配置
 * @author owner
 *
 */
public interface IPerformanceEvaluateConfigurationService extends IBaseOptionService{
	
	/**
	 * 总评估或者修改总评估
	 * @param info
	 * @return
	 */
	public boolean evaluate(Map info);
	
	/**
	 * 关闭
	 * @param info
	 * @return
	 */
	public boolean close(Map info);
	
	/**
	 * 根据ID 获取（评估结果需要的数据接口）
	 * @param info
	 * @return
	 */
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getByIdToAccessResult(String id);
	
	public UTMap<String, Object> getByIdToAccessResult2(String id);
	
}
