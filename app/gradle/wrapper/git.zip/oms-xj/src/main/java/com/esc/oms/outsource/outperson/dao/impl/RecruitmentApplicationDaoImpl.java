package com.esc.oms.outsource.outperson.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.outperson.dao.IRecruitmentApplicationDao;
import com.esc.oms.util.RoleUtils;


/**
 * 人力资源申请
 * @author djj
 * @date   2016-07-18
 */
@Repository
public class RecruitmentApplicationDaoImpl extends BaseOptionDao implements IRecruitmentApplicationDao {

	@Override
	public String getTableName() {
		return "recruitment_application";
	}
	
	@Override
	public List<UTMap<String, Object>> getListMaps(Map param) {
		String sql=getSearchSql(param);
		return super.getListBySql(sql, null);
	}

	@Override
	public void getPageInfo(UTPageBean pageBean,Map param){
		String sql=getSearchSql(param);
		super.getPageListMapBySql(sql,pageBean, null);
	}
	
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	@Override
	public List<UTMap<String, Object>> getPageList(UTPageBean pageBean,Map params) {
		String sql=getSearchSql(params);
		super.getPageListMapBySql(sql,pageBean, null);
		return pageBean.getRows();
	}
	
	/**
	 * 用户 查询sql 拼接器
	 * @param param
	 * @return
	 */
	private String getSearchSql(Map<String, Object> param){
		Map<String, String> p=UTMap.mapObjToString(param);
		StringBuilder sql=new StringBuilder();
		sql.append(" select app.*,org.name as applyDepartName,org.longName as applyDepartLongName,supplierIds_to_name(app.limitSuppliers) as limitSupplierNames, pi.name as projectInfoName from recruitment_application app ");
		sql.append(" left join sys_org org on app.applyDepartId=org.id ");
		sql.append(" left join project_info pi on pi.id=app.projectId ");
		sql.append("	WHERE 1=1  ");
		if(null != param && !param.isEmpty()){
			String name = param.get("name")==null?null:param.get("name").toString();
			if(!StringUtils.isEmpty(name)){
				sql.append(" and app.name like '%"+name+"%' ");
			}
			String nameOrCode = param.get("nameOrCode")==null?null:param.get("nameOrCode").toString();
			if(!StringUtils.isEmpty(nameOrCode)){
				sql.append(" and (app.code like '%"+nameOrCode+"%' or app.name like '%"+nameOrCode+"%') ");
			}			
			String applyDepartId = param.get("applyDepartId")==null?null:param.get("applyDepartId").toString();
			if(!StringUtils.isEmpty(applyDepartId)){
				sql.append(" and app.applyDepartId='"+applyDepartId+"' ");
			}
			String applyDepartName = param.get("applyDepartName")==null?null:param.get("applyDepartName").toString();
			if(!StringUtils.isEmpty(applyDepartName)){
				sql.append(" and org.name like '%"+applyDepartName+"%' ");
			}	
			String applyDepartLongName = param.get("applyDepartLongName")==null?null:param.get("applyDepartLongName").toString();
			if(!StringUtils.isEmpty(applyDepartLongName)){
				sql.append(" and org.longName like '%"+applyDepartLongName+"%' ");
			}	
			String startDate = param.get("startDate")==null?null:param.get("startDate").toString();
			if(!StringUtils.isEmpty(startDate)){
				sql.append(" and DATE_FORMAT(app.applyDate,'%Y-%m-%d')>='"+startDate+"' ");
			}
			String endDate = param.get("endDate")==null?null:param.get("endDate").toString();
			if(!StringUtils.isEmpty(endDate)){
				sql.append(" and DATE_FORMAT(app.applyDate,'%Y-%m-%d')<='"+endDate+"' ");
			}
		}
		//数据权限控制
		/*if(!RoleUtils.isSupplierAdministrator()&&!RoleUtils.isSystemAdministrator()&&!RoleUtils.isOutsourceAudit()&&!RoleUtils.isOutsourceManager()){
			if("1".equals(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserType())){//金融机构用户
				String userId = EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId();
				sql.append(" and app.applyUserId='"+userId.trim()+"' ");
			}else{
				sql.append(" and app.applyUserId='-1'");
			}
		}*/
		if (!RoleUtils.isSupplierAdministrator()&&!RoleUtils.isSystemAdministrator()&&!RoleUtils.isOutsourceManager()) {
			sql.append(" and app.applyUserId='" + EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId() + "' ");
		}
		sql.append(" order by app.createTime desc " );
		return sql.toString();
	}

	@Override
	public void getPendApprovalPageInfo(UTPageBean pageBean,
			Map<String, Object> params) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select app.*,org.name as applyDepartName,org.longName as applyDepartLongName"
				//+ ",t4.currentExecutor as auditors,t4.currentStepName "
				+ " from recruitment_application app ");
		sql.append(" left join sys_org org on app.applyDepartId=org.id ");
		//sql.append(" left join sys_workflow_instance t4 on app.workflowInstanceId=t4.id ");
		//sql.append(" where FIND_IN_SET('"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"',t4.currentExecutor) ");
		sql.append(" where 1=1 and app.status='2' ");
		if(params!=null && params.size()>0){	
			if(params.get("nameOrCode")!=null &&  StringUtils.isNotEmpty(params.get("nameOrCode").toString())){
				sql.append(" and (app.name like '%"+params.get("nameOrCode").toString().trim()+"%' or app.code like '%"+params.get("nameOrCode").toString().trim()+"%')  ");
			}
			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
				sql.append(" and app.name like '%"+params.get("name").toString().trim()+"%' ");
			}
			if(params.get("code")!=null &&  StringUtils.isNotEmpty(params.get("code").toString())){
				sql.append(" and app.code like '%"+params.get("code").toString().trim()+"%' ");
			}
			if(params.get("startDate")!=null && StringUtils.isNotEmpty(params.get("startDate").toString())){
				sql.append(" and DATE_FORMAT(app.applyDate,'%Y-%m-%d')>='"+params.get("startDate").toString().trim()+"' ");
			}
			if(params.get("endDate")!=null && StringUtils.isNotEmpty(params.get("endDate").toString())){
				sql.append(" and DATE_FORMAT(app.applyDate,'%Y-%m-%d')<='"+params.get("endDate").toString().trim()+"' ");
			}
			String applyDepartId = params.get("applyDepartId")==null?null:params.get("applyDepartId").toString();
			if(!StringUtils.isEmpty(applyDepartId)){
				sql.append(" and app.applyDepartId='"+applyDepartId+"' ");
			}
			String applyDepartLongName = params.get("applyDepartLongName")==null?null:params.get("applyDepartLongName").toString();
			if(!StringUtils.isEmpty(applyDepartLongName)){
				sql.append(" and org.longName like '%"+applyDepartLongName+"%' ");
			}
		}
		sql.append(" order by app.updateTime desc " );
		super.getPageListMapBySql(sql.toString(), pageBean, null);		
	}

	@Override
	public void getAlreadyApprovalPageInfo(UTPageBean pageBean,
			Map<String, Object> params) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select DISTINCT(app.id) as applyId,app.*,org.name as applyDepartName,org.longName as applyDepartLongName "
				+ " from recruitment_application app ");
		sql.append(" left join sys_org org on app.applyDepartId=org.id ");
		//sql.append(" left join sys_workflow_audit_history t4 on app.workflowInstanceId=t4.instanceId ");
		//sql.append(" where FIND_IN_SET('"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"',t4.optionUserId) " );
		//sql.append(" and t4.nodeName!='开始' " );//屏蔽开始节点
		sql.append(" where 1=1 and app.status in ('4', '5', '6') ");
		if(params!=null && params.size()>0){	
			if(params.get("nameOrCode")!=null &&  StringUtils.isNotEmpty(params.get("nameOrCode").toString())){
				sql.append(" and (app.name like '%"+params.get("nameOrCode").toString().trim()+"%' or app.code like '%"+params.get("nameOrCode").toString().trim()+"%')  ");
			}
			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
				sql.append(" and app.name like '%"+params.get("name").toString().trim()+"%' ");
			}
			if(params.get("code")!=null &&  StringUtils.isNotEmpty(params.get("code").toString())){
				sql.append(" and app.code like '%"+params.get("code").toString().trim()+"%' ");
			}
			if(params.get("startDate")!=null && StringUtils.isNotEmpty(params.get("startDate").toString())){
				sql.append(" and DATE_FORMAT(app.applyDate,'%Y-%m-%d')>='"+params.get("startDate").toString().trim()+"' ");
			}
			if(params.get("endDate")!=null && StringUtils.isNotEmpty(params.get("endDate").toString())){
				sql.append(" and DATE_FORMAT(app.applyDate,'%Y-%m-%d')<='"+params.get("endDate").toString().trim()+"' ");
			}
			String applyDepartId = params.get("applyDepartId")==null?null:params.get("applyDepartId").toString();
			if(!StringUtils.isEmpty(applyDepartId)){
				sql.append(" and app.applyDepartId='"+applyDepartId+"' ");
			}
			String applyDepartLongName = params.get("applyDepartLongName")==null?null:params.get("applyDepartLongName").toString();
			if(!StringUtils.isEmpty(applyDepartLongName)){
				sql.append(" and org.longName like '%"+applyDepartLongName+"%' ");
			}
		}
		sql.append(" order by app.createTime desc " );
		super.getPageListMapBySql(sql.toString(), pageBean, null);
	}

	@Override
	public List<UTMap<String, Object>> getManpowerSuppliers(
			Map<String, Object> param) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select supplier.id,supplier.name,supplier.code from agreement_manpower_info info"
				+ " left join agreement_info agreement on info.agreementId=agreement.id"
				+ " left join supplier_base_info supplier on agreement.supplierId=supplier.id");
		return super.getListBySql(sql.toString(), null);
	}
	
	@Override
	public List<UTMap<String, Object>> getManpowerCategorys(
			Map<String, Object> param) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select category as name from agreement_manpower_cost_config group by category");
		return super.getListBySql(sql.toString(), null);
	}

	@Override
	public List<UTMap<String, Object>> getOrgReport(Map<String, Object> params) {
		StringBuilder sql=new StringBuilder();
		sql.append("select app.applyDepartId,org.name as orgName,sum(detail.num) as appNum,ifnull(sum(resumeTmp.arrivalCount),0) as arrivalNum, "
				+ " org2.longName departmentName, org2.name as orgNmae2 "
				+ " from recruitment_application_detail detail "
				+ " LEFT JOIN recruitment_application app on detail.applyId=app.id"
				+ " LEFT JOIN sys_org org on app.applyDepartId=org.id"
				+ " left join sys_org org2 on detail.departmentId=org2.id "
				+ " LEFT JOIN "
				+ " (select resume.applyDetailId,resume.applyId,resume.supplierId,count(*) as resumeCount,"
				+ " sum(case when resume.managerReviewResult=1 and resume.workflowStatus='3' then 1 else 0 end) as passInterviewCount,sum(case when resume.isArrival=1 then 1 else 0 end) as arrivalCount"
				+ " from recruitment_resume resume group by resume.applyDetailId) resumeTmp "
				+ " on detail.id=resumeTmp.applyDetailId");
		sql.append(" WHERE app.status>3  ");
		if(params!=null){
			String startDate = params.get("startDate")==null?null:params.get("startDate").toString();
			if(!StringUtils.isEmpty(startDate)){
				sql.append(" and DATE_FORMAT(app.applyDate,'%Y-%m-%d')>='"+startDate+"' ");
			}
			String endDate = params.get("endDate")==null?null:params.get("endDate").toString();
			if(!StringUtils.isEmpty(endDate)){
				sql.append(" and DATE_FORMAT(app.applyDate,'%Y-%m-%d')<='"+endDate+"' ");
			}
			String orgName = params.get("orgName")==null?null:params.get("orgName").toString();
			if(!StringUtils.isEmpty(orgName)){
				sql.append(" and org.name like '%"+orgName+"%' ");
			}
		}
		sql.append(" GROUP BY app.applyDepartId ");
		sql.append(" ORDER BY appNum desc limit 10 ");
		return super.getListBySql(sql.toString(), null);
	}

	@Override
	public boolean addReviewFile(Map<String, Object> reviewFile) {
		// TODO Auto-generated method stub
		return super.saveBySql("recruitment_application_file", reviewFile);
	}
	
	@Override
	public UTMap<String, Object> getReviewFile(String applyId){
		StringBuilder sql = new StringBuilder();
		sql.append(" select id, applyId from recruitment_application_file where applyId='" + applyId + "' ");
		List<UTMap<String, Object>> list = super.getListBySql(sql.toString(), null);
		if (null != list && !list.isEmpty()) {
			return list.get(0);
		}
		return null;
	}

	@Override
	public UTMap<String, Object> getReviewFileById(String id) {
		// TODO Auto-generated method stub
		return super.getMapById("recruitment_application_file", null, id);
	}

	@Override
	public List<UTMap<String, Object>> getProjectRes(Map<String, Object> param) {
		// TODO Auto-generated method stub
		return super.getListBySql(this.getProjectResSql(param), null);
	}
	
	private String getProjectResSql(Map<String, Object> param) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select tb.* ");
		sql.append(" from recruitment_application_project_res tb ");
		sql.append(" where 1=1 ");
		if (null != param && !param.isEmpty()) {
			String projectId = (String) param.get("projectId");
			String applyId = (String) param.get("applyId");
			if (StringUtils.isNotEmpty(projectId)) {
				sql.append(" and tb.projectId='"+projectId+"' ");
			}
			if (StringUtils.isNotEmpty(applyId)) {
				sql.append(" and tb.applyId='"+applyId+"' ");
			}
		}
		sql.append(" order by tb.memberName desc ");
		return sql.toString();
	}
	
	@Override
	public boolean deleteProjectResByApplyId(String applyId) {
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("applyId", applyId);
		return super.deleteBySql("recruitment_application_project_res", param);
	}
	
	@Override
	public boolean addProjectRes(Map<String, Object> param) {
		return super.saveBySql("recruitment_application_project_res", param);
	}
	
}
