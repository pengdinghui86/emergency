package com.esc.oms.outsource.outperson.service;

import java.util.List;
import java.util.Map;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;


/**
 * 外包人员管理 人员申请通知业务 接口
 * @author smq
 * @date   2016-7-13 下午3:41:40
 */
public interface IApplyNoticeService extends IBaseOptionService{

	/**
	 * 发送通知
	 * @param applyId
	 * @param applyType
	 */
	public void sendApplyNoticeInfo( String applyId,String applyType);
	

	/**
	 * 获取 通知 
	 * @param applyUserId
	 * @param applyId
	 * @return
	 */
	public List<UTMap<String, Object>> getApplyNoticeInfo(String applyUserId,String  applyId);


	public boolean reSend(Map<String, Object> param);
}
