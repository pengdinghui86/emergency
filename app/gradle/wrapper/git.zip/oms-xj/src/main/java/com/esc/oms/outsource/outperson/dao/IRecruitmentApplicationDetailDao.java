package com.esc.oms.outsource.outperson.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

public interface IRecruitmentApplicationDetailDao extends IBaseOptionDao{
	
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_CATEGORY = "category";
	public static final String  FIELD_LEVEL = "level";
	public static final String  FIELD_NUM = "num";
	public static final String  FIELD_PLACE = "place";
	public static final String  FIELD_HILLOCK_DATE = "hillockDate";
	public static final String  FIELD_FREED_DATE = "freedDate";
	public static final String  FIELD_STATUS = "status";
	
	//1.待推荐  2.处理中   5.完成
	public static final String STATUS_PEND_RECOMMEND = "1";
	public static final String STATUS_OPERATION = "2";
	public static final String STATUS_FINISH = "5";
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params);

	/**
	 * 根据领用记录的条件查询领用详单	
	 * @param params
	 * @return
	 */
	public List<UTMap<String, Object>> getListAllByParentParam(Map parentParams);
	/**
	 * 根据applyId进行关闭
	 * @param applyId
	 */
	public void closeByApplyId(String applyId);
	
}
