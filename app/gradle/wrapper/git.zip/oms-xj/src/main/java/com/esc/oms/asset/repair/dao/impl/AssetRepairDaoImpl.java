package com.esc.oms.asset.repair.dao.impl;

import com.esc.oms.asset.repair.dao.IAssetRepairDao;
import com.esc.oms.util.RoleUtils;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
@Repository
public class AssetRepairDaoImpl extends BaseOptionDao implements IAssetRepairDao{
	
	private String repairResultTableName = "assets_material_repair_result";
	

	@Override
	public String getTableName() {
		return "assets_material_repair_apply";
	}
	

	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params), pageBean, null);
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT DISTINCT amra.id, concat(ami.`name`,IF(ami.`serialNum` is null or ami.`serialNum`='', '', concat('/', ami.`serialNum`))) assetsId,amra.assetsId asset,amra.`code`,amra.createUser,amra.createTime, " );
		sql.append(" amra.reason,amrr.result,amra.`status`,amra.workflowInstanceId,amra.createUserId ");
		if(params!=null && params.size()>0 &&params.get("auditStatus")!=null &&  StringUtils.isNotEmpty(params.get("auditStatus").toString())){
			if("1".equals(params.get("auditStatus"))){
				sql.append(" ,t4.currentStepName ");
			}
		}
		sql.append(" FROM assets_material_repair_apply amra ");
		sql.append(" LEFT JOIN assets_material_info ami ON ami.id = amra.assetsId ");
		sql.append(" LEFT JOIN assets_material_repair_result amrr ON amra.id = amrr.repairId ");
		if(params!=null && params.size()>0 &&params.get("auditStatus")!=null &&  StringUtils.isNotEmpty(params.get("auditStatus").toString())){
			if("1".equals(params.get("auditStatus"))){
				sql.append(" left join sys_workflow_instance t4 on amra.workflowInstanceId=t4.id ");
				sql.append(" where FIND_IN_SET('"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"',t4.currentExecutor) ");
			}else if("2".equals(params.get("auditStatus"))){
				sql.append(" left join sys_workflow_audit_history t4 on amra.workflowInstanceId=t4.instanceId ");
				sql.append(" where FIND_IN_SET('"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"',t4.optionUserId) " );
				sql.append(" and t4.nodeName!='开始' " );//屏蔽开始节点
			}
		}else{
			sql.append(" WHERE 1=1 ");
		}
		if(params!=null && params.size()>0){
			if(params.get("code")!=null &&  StringUtils.isNotEmpty(params.get("code").toString())){
				sql.append(" AND amra.`code` LIKE '%"+params.get("code").toString().trim()+"%' ");
			}
			if(params.get("name")!=null && StringUtils.isNotEmpty(params.get("name").toString())){
				sql.append(" AND concat(ami.`name`,'/',ami.`code`) LIKE '%"+params.get("name").toString().trim()+"%'");
			}
		}
		if((params.get("auditStatus") ==null ||  StringUtils.isEmpty(params.get("auditStatus").toString())) && EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.COMMON_BANK_USER,RoleUtils.SYSTEM_ADMINISTRATOR)){//普通金融机构用户
			sql.append(" and amra.createUserId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' ");//非研发用户只能查询自己的数据，研发用户查询所有数据方便调试
		}
		sql.append(" ORDER BY amra.createTime desc");
		return  sql.toString();
	}

	private String getResultByRepairIdSql(String repairId){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT amrr.id,amrr.beginDate,amrr.endDate,amrr.repairUser, " );
		sql.append(" amrr.repairPhone,amrr.cost,amrr.result,amrr.resultRemark ");
		sql.append(" FROM "+repairResultTableName+" amrr ");
		sql.append(" WHERE 1=1 ");
		sql.append(" AND amrr.repairId = '"+repairId+"'");
		return  sql.toString();
	}

	private String getOrgLongNameByIdSql(String id){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT longName " );
		sql.append(" FROM sys_org ");
		sql.append(" WHERE 1=1 ");
		sql.append(" AND id = '" + id + "'");
		return  sql.toString();
	}
	
	@Override
	public UTMap<String, Object> getOrgLongNameById(String id) {
		return super.getOneBySql(getOrgLongNameByIdSql(id), null);

	}
	
	@Override
	public boolean addRepairResult(Map info) {
		return	super.saveBySql(repairResultTableName, info);
	}


	@Override
	public boolean updateRepairResultById(Map info) {
		return super.updateById(repairResultTableName, info);
	}


	@Override
	public UTMap<String, Object> getResultByRepairId(String repairId) {
		return super.getOneBySql(getResultByRepairIdSql(repairId), null);

	}


	@Override
	public boolean deleteResultByRepairId(String repairId) {
		StringBuilder sql=new StringBuilder();
		sql.append(" DELETE  FROM "
				 + repairResultTableName
				 + " WHERE repairId = '" +repairId+"'");
		return super.executeUpdate(sql.toString());
	}


	private String getAssetsRepairRateCountSql(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT FORMAT(sumBrand.brandNum/c.allBrand,2) repairRate,c.brand,sumBrand.producer,sumBrand.brandNum,c.allBrand " );
		sql.append(" FROM ( ");
		sql.append(" 	select t1.brand,t1.producer,sum(t1.brandCount) as brandNum from (");
		sql.append(" 		select * from ( ");
		sql.append(" 			select ami.brand,ami.producer,ami.id as assetsId,COUNT(*) as brandCount from assets_material_repair_apply apply left join assets_material_info ami on apply.assetsId=ami.id WHERE apply.`status` in ('6') group by ami.brand ");
		sql.append(" 		) a  ");
		sql.append(" 	union all ");
		sql.append(" 		select * from ( ");
		sql.append(" 			select ami.brand,ami.producer,ami.id as assetsId,COUNT(*) as brandCount from assets_material_repair_record record left join assets_material_info ami on record.assetsId=ami.id group by ami.brand ");
		sql.append(" 		)b  ");
		sql.append(" 	) t1  ");
		sql.append(" GROUP BY t1.brand  ");
		sql.append(" ) AS sumBrand,( ");
		sql.append(" select t2.brand,t2.allBrand from ( ");
		sql.append(" 	SELECT COUNT(ami2.id) allBrand,ami2.brand ");
		sql.append(" 	FROM assets_material_info ami2 ");
		sql.append(" 	GROUP BY ami2.brand ");
		sql.append(" )t2 ");
		sql.append(") AS c  ");
		sql.append(" WHERE (sumBrand.brand = c.brand) AND (sumBrand.brand != '') ");
		if(params!=null && params.size()>0){
			if(params.get("brand")!=null && StringUtils.isNotEmpty(params.get("brand").toString())){
				sql.append(" AND c.brand LIKE '%"+params.get("brand").toString().trim()+"%'");
			}
		}
		return  sql.toString();
	}
	
	@Override
	public void getAssetsRepairRateCount(UTPageBean pageBean, Map params) {
		 super.getPageListMapBySql(getAssetsRepairRateCountSql(params), pageBean, null);
	}
	
	@Override
	public List<UTMap<String, Object>> getAssetsList(Map param) {
		return super.getListBySql(getSearchSql(param));
	}
}
