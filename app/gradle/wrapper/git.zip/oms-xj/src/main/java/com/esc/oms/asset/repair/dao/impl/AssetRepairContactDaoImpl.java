package com.esc.oms.asset.repair.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.asset.repair.dao.IAssetRepairContactDao;

@Repository
public class AssetRepairContactDaoImpl extends BaseOptionDao implements IAssetRepairContactDao {

	
	@Override
	public String getTableName() {
		return "assets_material_repair_contact";
	}
	
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params), pageBean, null);
	}
	
	
	public String getSearchSql(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append("SELECT amrc.id,amrc.agreementId,aai.agreementName,amrc.supplierId,sbi.name as supplierName,amrc.contactUser,amrc.contactPhone,"
				+ "amrc.backupUser,amrc.backupPhone,amrc.rangee,amrc.createUser,amrc.createTime");
		sql.append(" FROM assets_material_repair_contact amrc");
		sql.append(" left join assets_agreement_info aai on amrc.agreementId = aai.agreementId");
		sql.append(" left join supplier_base_info sbi on amrc.supplierId = sbi.id");
		sql.append(" WHERE 1=1 ");
		
		if(params!=null && params.size()>0){		
			if(params.get("rangee")!=null &&  StringUtils.isNotEmpty(params.get("rangee").toString())){
				sql.append(" and amrc.rangee like '%"+params.get("rangee").toString().trim()+"%' ");
			}
//			if(params.get("supplierId")!=null && StringUtils.isNotEmpty(params.get("supplierId").toString())){
//				sql.append(" and amrc.supplierId = '"+params.get("supplierId").toString().trim()+"' ");
//			}
			
			if(params.get("supplierName")!=null && StringUtils.isNotEmpty(params.get("supplierName").toString())){
				sql.append(" and sbi.name like '%"+params.get("supplierName").toString().trim()+"%' ");
			}
		}
		
		sql.append("  order by amrc.createTime desc");
		return sql.toString();
	}
	
	
	
	
	private String getRepairByIdSql(String id){
		StringBuilder sql=new StringBuilder();
		sql.append("SELECT ");
		sql.append("amrc.id,amrc.agreementId,aai.agreementName,amrc.supplierId,sbi.name as supplierName,amrc.contactUser,amrc.contactPhone,"
				+ "amrc.backupUser,amrc.backupPhone,amrc.rangee,amrc.createUser,amrc.createTime");
		sql.append(" FROM");
		sql.append(" assets_material_repair_contact amrc");
		sql.append(" left join assets_agreement_info aai on amrc.agreementId = aai.agreementId");
		sql.append(" left join supplier_base_info sbi on amrc.supplierId = sbi.id");
		sql.append(" WHERE amrc.id = '"+id+"'");
		return  sql.toString();
	}
	
	
	@Override
	public UTMap<String, Object> getRepairById(String id) {
		return super.getOneBySql(getRepairByIdSql(id),null);
	}
	

	@Override
	public List<UTMap<String, Object>> getRepairList(Map param) {
		return super.getListBySql(getSearchSql(param));
	}

	

}
