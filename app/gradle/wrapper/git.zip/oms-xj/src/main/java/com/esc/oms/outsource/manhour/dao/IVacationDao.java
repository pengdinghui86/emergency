package com.esc.oms.outsource.manhour.dao;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

import java.util.List;
import java.util.Map;

public interface IVacationDao extends IBaseOptionDao {

	public static final String FIELD_ID = "id";
	public static final String FIELD_CODE = "code";
	public static final String FIELD_BEGINTIME = "beginTime";
	public static final String FIELD_ENDTIME = "endTime";
	public static final String FIELD_HOURS = "hours";
	public static final String FIELD_STATUS = "status";
	public static final String FIELD_TYPE = "type";
	public static final String FIELD_REASON = "reason";
	public static final String FIELD_SUPPLIERID = "supplierId";
	public static final String FIELD_SUPPLIERNAME = "supplierName";
	public static final String FIELD_ORGID = "orgId";
	public static final String FIELD_ORGNAME = "orgName";
	
	public static final String FIELD_SUBMITUSER = "submitUser";
	public static final String FIELD_SUBMITTIME = "submitTime";
	public static final String FIELD_CREATEUSER = "createUser";
	public static final String FIELD_CREATETIME = "createTime";
	public static final String FIELD_CREATEUSERID = "createUserId";
	public static final String FIELD_UPDATEUSER = "updateUser";
	public static final String FIELD_UPDATETIME = "updateTime";
	public static final String FIELD_DINGSTAUS = "dingStatus";

	/**
	 * 根据条件查询
	 * @param param 查询条件
	 * @return
	 */
	public List<UTMap<String, Object>> getVacationList(Map param);
	/**
	 * 获取分页数据
	 * @param pageBean
	 * @param param
	 * @return
	 */
	public void getVacationPage(UTPageBean pageBean,Map param);
	
	/**
	 * 校验时间区间是否有其他申请
	 * @param map
	 * @return
	 */
	public boolean isExistRecord(Map<String, Object> map);

	/**
	 * 根据条件获取请假
	 * @param param
	 * @return
	 */
	public List<UTMap<String, Object>> getMapList(Map<String, Object> param);

	/**
	 * 根据用户和事件删除
	 * @param startTime
	 * @param endTime
	 * @param userIds
	 * @return
	 */
	public boolean deleteByTime(String startTime, String endTime, String userIds);
}
