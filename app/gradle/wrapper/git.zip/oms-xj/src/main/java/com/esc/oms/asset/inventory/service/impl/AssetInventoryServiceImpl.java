package com.esc.oms.asset.inventory.service.impl;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.esc.oms.asset.application.dao.IBusinessNumberDao;
import com.esc.oms.asset.inventory.dao.IAssetInventoryDao;
import com.esc.oms.asset.inventory.service.IAssetInventoryService;
import com.esc.oms.asset.physical.dao.IAssetPhysicalDao;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;
import com.esc.oms.util.RoleUtils;
import com.esc.oms.util.TaskModel;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.idgenerator.IDGenerationManager;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.timetask.anotations.CronTimeTask;
import org.esc.framework.timetask.anotations.TimeTaskMark;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
@Transactional
@TimeTaskMark
public class AssetInventoryServiceImpl extends BaseOptionService implements IAssetInventoryService{
	
	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private IAssetInventoryDao assetInventoryDao;
	
	@Resource
	private IBusinessNumberDao businessNumberDao;
	
	@Resource
	private IUserTaskService userTaskService;
	
	@Resource
	private MessageSend messageService;
	
	@Resource
	private IAssetPhysicalDao assetPhysicalDao;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return assetInventoryDao;
	}
	
	
	@Override
	@EscOptionLog(module=SystemModule.assetInventory, opType=ESCLogOpType.INSERT, table="assets_material_inventory",option="新增名称为{title}的资产盘点信息。")
	public boolean add(Map info){
		info.put("createUserId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
		info.put("code", IDGenerationManager.nextId("assetInventoryCode"));
		return	getOptionDao().add(info);
	}
	
	
	@Override
//	@EscOptionLog(module=SystemModule.assetInventory, opType=ESCLogOpType.UPDATE, table="assets_material_inventory",option="修改名称为{title}的资产盘点信息。")
	public boolean updateById(Map info){
		return getOptionDao().updateById(info);
	}

	@Override
	public boolean addAssetInventory(Map info) {
		return assetInventoryDao.addAssetInventory(info);
	}

	@Override
	public boolean deleteAssetInventoryById(String id) {
		return assetInventoryDao.deleteAssetInventoryById(id);
	}

	@Override
	public List<UTMap<String, Object>> getAssetInventoryListMaps(Map param) {
		return assetInventoryDao.getAssetInventoryListMaps(param);
	}

	

	@Override
	public void getAssetInventoryPageInfo(UTPageBean pageBean, Map param) {
		assetInventoryDao.getAssetInventoryPageInfo(pageBean, param);
	}
	
	@Override
	public boolean updateInventoryStatusById(String ids,String status,String inventoryId) {
		boolean flag = false;
		UTMap<String, Object> ut = new UTMap<String,Object>();
		
		UTMap<String, Object> iMap = this.getById(inventoryId);
		String curUserId = EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId();
		boolean isAssetManager =  EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.ASSET_MANAGER);
		//批量确认
		if(ids.indexOf(",") > 0 ){
			String[] allocationIds = ids.split(",");
			for (String allocationId : allocationIds) {
				//管理员批量确认要把管理员和责任人属于自己的盘点都进行确认，责任人则只把属于自己的盘点进行确认
				UTMap<String,Object> inventory = assetInventoryDao.geyAssetInventoryById(allocationId);
				String confirmStatus = inventory.get("confirmStatus").toString();
				if (StringUtils.equals("1", confirmStatus) && isAssetManager) {//如果是管理员确认，并且确认状态为1
					assetInventoryDao.updateInventoryStatusById(allocationId,"2", curUserId);
				}else if (StringUtils.equals("2", confirmStatus)) {//如果如果不是管理员，并且确认状态为2
					assetInventoryDao.updateInventoryStatusById(allocationId,"3", curUserId);
				}else {//其他状态不做处理
					
				}
				
				if(null != inventory){
					userTaskService.finishTask(inventoryId+String.valueOf(inventory.get("assetsId")));
				}
			}
		}else{
			flag = assetInventoryDao.updateInventoryStatusById(ids,status, curUserId);
			UTMap<String,Object> inventory = assetInventoryDao.geyAssetInventoryById(ids);
			if(null != inventory){
				if("2".equals(status)){
					userTaskService.finishTask(inventoryId+String.valueOf(inventory.get("assetsId")), "实物资产管理员盘点");
				}else{
					userTaskService.finishTaskByUserId(inventoryId+String.valueOf(inventory.get("assetsId")), "实物资产责任人盘点",EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
				}
			}
		}
		if(flag){
			ut.put("id", inventoryId);
			ut.put("status", 2);
			getOptionDao().updateById(ut);
		}
		return flag;
	}
	
	@EscOptionLog(module=SystemModule.assetInventory, opType=ESCLogOpType.DELETE, table="assets_material_inventory",option="删除名称为{name}的资产盘点信息。")
	public boolean deleteById(String id){
		boolean flag = false;
		flag = getOptionDao().deleteByIds(id);
		if(flag){
			flag = assetInventoryDao.deleteAssetInventoryByInventoryId(id);
		}
		return	flag;
	}
	
	@EscOptionLog(module=SystemModule.assetInventory, opType=ESCLogOpType.DELETES, table="assets_material_inventory",option="删除名称为{name}的资产盘点信息。")	
	public boolean deleteByIds(String ids){
		boolean flag = false;
		flag = getOptionDao().deleteByIds(ids);
		if(flag && StringUtils.isNotEmpty(ids)){
			String[] borrowIds = ids.split(",");
			for (String borrowId : borrowIds) {
				flag = assetInventoryDao.deleteAssetInventoryByInventoryId(borrowId);
			}
		}
		return flag;
	}

	@Override
	public boolean deleteAssetInventoryByInventoryId(String id) {
		return assetInventoryDao.deleteAssetInventoryByInventoryId(id);
	}


	@Override
	public boolean updateInventoryStatusByInventoryId(String inventoryId, String status) {
		return assetInventoryDao.updateInventoryStatusByInventoryId(inventoryId, status);
	}


	@CronTimeTask(description="每天凌晨定时发送资产盘点消息",cron="0 0 0 * * ?")
	@Override
	public void generate() {
		logger.info("开始定时发送资产盘点消息！=========================================================");
		UTMap<String,Object> map = new UTMap<String,Object>();
		
		map.put("allocationDate", new Date());
		List<UTMap<String, Object>> list = assetInventoryDao.getNowDateInventoryListMaps();
		if(list != null && !list.isEmpty()){
			for (UTMap<String, Object> inventory : list) {
				String resUserIds = "";
				String inventoryId = String.valueOf(inventory.get("id"));
				List<UTMap<String, Object>> assetsList = assetInventoryDao.getAssetsByInventoryIdListMaps(inventoryId);
				if(null != assetsList && assetsList.size() > 0){
					for (Map<String, Object> assets : assetsList) {
						String confirmStatus = assets.get("confirmStatus") == null ? "" : assets.get("confirmStatus").toString();
						if (StringUtils.equals("4", confirmStatus)) {//不需要确认的时候不发送消息和待办
							continue;
						}
						String resUser = String.valueOf(assets.get("resUser"));
						String codeNum = (String) assets.get("codeNum");
						if (StringUtils.isEmpty(codeNum)) {
							codeNum = "";
						}else {
							codeNum = "/" + codeNum;
						}
						//先完成已有的待办
						userTaskService.finishTask(inventoryId+String.valueOf(assets.get("assetsId")), "实物资产管理员盘点");
						userTaskService.finishTask(inventoryId+String.valueOf(assets.get("assetsId")), "实物资产责任人盘点");
						//再添加新的待办
						if(StringUtils.equals("1", confirmStatus) || StringUtils.equals("2", confirmStatus)) {//在资产管理员或者资产责任人确认状态时发送待办给责任人
							if(null != assets && null != resUser && StringUtils.isNotEmpty(resUser)){
								if(resUserIds.indexOf(resUser) == -1){
									resUserIds +=resUser; 
									String title = "资产盘点确认提醒";
									String content = "资产盘点:【"+inventory.get("title")+"】已开始,请在"+inventory.get("endDate")+"前，进入系统进行资产确认！ ";
									messageService.sendMessage(resUser,title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
								}
								userTaskService.addTaskByUserId("资产【"+assets.get("name")+codeNum+"】盘点责任人确认 ",inventoryId+String.valueOf(assets.get("assetsId")), "实物资产责任人盘点", TaskModel.AssetInventory,(String)assets.get("resUser"));
							}
						}
						if (StringUtils.equals("1", confirmStatus)) {//在资产管理员确认的状态下发送待办给责任人
							userTaskService.addTaskByRole("资产【"+assets.get("name")+codeNum+"】盘点管理员确认 ",inventoryId+String.valueOf(assets.get("assetsId")), "实物资产管理员盘点", TaskModel.AssetInventory,RoleUtils.ASSET_MANAGER);
						}
					}
				}
			}
		}
		logger.info("成功定时开始定时发送资产盘点消息！=========================================================");
	}


	@Override
	public boolean leadingin(String filePath, Map<String, Object> param) {
		try {
			File file = new File(FilenameUtils.normalize(filePath));
			if (!file.exists()) {
				throw new EscServiceException("导入失败，导入文件不存在！");
			}
			String jsonStr = FileUtils.readFileToString(file);
			if (StringUtils.isEmpty(jsonStr)) {
				throw new EscServiceException("导入失败，文件内容为空！");
			}
			JSONArray jsonArray = JSON.parseArray(jsonStr);
			if (null == jsonArray || jsonArray.size() == 0) {
				throw new EscServiceException("导入失败，json内容为空！");
			}
			Iterator<Object> iterator = jsonArray.iterator();
			List<Map<String, Object>> listAsset = new ArrayList<Map<String, Object>>();//盘点资产明细
			String inventoryId = "";
			while(iterator.hasNext()) {
				JSONObject obj = (JSONObject) iterator.next();
				String code = (String) obj.get("code");
				if (StringUtils.isEmpty(code)) {
					throw new EscServiceException("导入失败，盘点单号不能为空！");
				}
				UTMap<String, Object> codeInven = assetInventoryDao.getInventoryByCode(code);
				if (null == codeInven || codeInven.isEmpty()) {
					throw new EscServiceException("导入失败，盘点单号为【"+code+"】的盘点单在系统中不存在！");
				}
				//盘点单id
				inventoryId = (String) codeInven.get("id");
				
				//资产列表
				JSONArray assetsList = obj.getJSONArray("assetsList");
				if (null == assetsList || assetsList.size() <= 0) {
					throw new EscServiceException("导入失败，assetsList不能为空！");
				}
				Iterator<Object> assetIt = assetsList.iterator();
				while (assetIt.hasNext()) {
					JSONObject asset = (JSONObject) assetIt.next();
					String assetsCode = asset.getString("code");//资产编号
					if (StringUtils.isEmpty(assetsCode)) {
						throw new EscServiceException("导入失败，资产编号不能为空！");
					}
					//校验资产明细中的资产是否存在于系统中
					UTMap<String, Object> assetUtmap = assetPhysicalDao.getAssetInfoByAssetCode(assetsCode);
					if (null == assetUtmap || assetUtmap.isEmpty()) {
						throw new EscServiceException("导入失败，盘点单号为【"+code+"】的盘点单中资产编号为【"+assetsCode+"】的资产在系统中不存在！");
					}
					String assetId = (String) assetUtmap.get("id");//资产id
					String status = asset.getString("status");//盘点状态
					if (StringUtils.isEmpty(status)) {
						throw new EscServiceException("导入失败，状态不能为空！");
					}
					if (StringUtils.isNotEmpty(status) && !StringUtils.equals("0", status) && !StringUtils.equals("1", status) && !StringUtils.equals("2", status)) {
						throw new EscServiceException("导入失败，状态值只能为0、1、2！");
					}
					UTMap<String, Object> oldAssetInventory = assetInventoryDao.getInventoruAsset(inventoryId, assetId);
					String oldAssetInventoryId = "";
					String isCreate = "0";
					String oldStatus = null;
					if (null == oldAssetInventory || oldAssetInventory.isEmpty()) {
						isCreate = "1";
					}else {
						oldAssetInventoryId = (String) oldAssetInventory.get("id");
						oldStatus = (String)oldAssetInventory.get("status");
					}
					Map<String, Object> mm = new HashMap<String, Object>();
					mm.put("assetsId", assetId);
					mm.put("inventoryId", inventoryId);
					mm.put("newStatus", status);
					mm.put("id", oldAssetInventoryId);
					mm.put("isCreate", isCreate);
					mm.put("oldStatus", oldStatus);
					listAsset.add(mm);
				}
			}
			for (Map<String, Object> mmp : listAsset) {
				String isCreate = (String) mmp.get("isCreate");
				mmp.put("confirmStatus", "2");
				mmp.put("assetsAdminId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
				if (StringUtils.equals("1", isCreate)) {
					mmp.put("id", UUID.randomUUID().toString());
					mmp.put("status", mmp.get("newStatus"));
					this.assetInventoryDao.addAssetInventory(mmp);
				}else {
					String newStatus = mmp.get("newStatus").toString();
					String oldStatus = mmp.get("oldStatus").toString();
					if ((StringUtils.equals("0", oldStatus) || StringUtils.equals("0", newStatus))//如果已经盘点正常
							|| (StringUtils.equals("1", oldStatus) && StringUtils.equals("2", newStatus)) //先亏后盈
							|| (StringUtils.equals("2", oldStatus) && StringUtils.equals("1", newStatus))) {//先盈后亏
						mmp.put("status", "0");
					}else {
						mmp.put("status", newStatus);
					}
					assetInventoryDao.updateInverstoryAsset(mmp);
				}
				userTaskService.finishTask(inventoryId+String.valueOf(mmp.get("assetsId")), "实物资产管理员盘点");//完成资产管理员盘点确认的待办
				//更新资产列表里面的盘点状态
				Map<String, Object> pMap = new HashMap<String, Object>();
				pMap.put("id", mmp.get("assetsId"));
				pMap.put("inventory_status", mmp.get("status"));
				assetPhysicalDao.updateById(pMap);
				
			}
			
			if (StringUtils.isNotEmpty(inventoryId)) {
				Map<String, Object> ut = new HashMap<String, Object>();
				ut.put("id", inventoryId);
				ut.put("status", 2);
				getOptionDao().updateById(ut);
			}
		} catch (IOException e) {
			e.printStackTrace();
			throw new EscServiceException("导入失败， 解析json文件失败！");
		}
		
		return true;
	}


	@Override
	public boolean leadinginForRest(List<Map<String, Object>> list) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SS");
		logger.info("----------------------------开始导入盘点结果，开始时间："+sdf.format(new Date())+"-----------------------------");
/*		String jsonStr = (String) param.get("jsonStr");
		if (StringUtils.isEmpty(jsonStr)) {
			throw new EscServiceException("导入失败，文件内容为空！");
		}
		JSONArray jsonArray = JSON.parseArray(jsonStr);*/
		if (null == list || list.size() == 0) {
			throw new EscServiceException("导入失败，json内容为空！");
		}
		Iterator<Map<String, Object>> iterator = list.iterator();
		List<Map<String, Object>> listAsset = new ArrayList<Map<String, Object>>();//盘点资产明细
		String inventoryId = "";
		while(iterator.hasNext()) {
			Map<String, Object> obj = (Map<String, Object>) iterator.next();
			String code = (String) obj.get("code");
			if (StringUtils.isEmpty(code)) {
				throw new EscServiceException("导入失败，盘点单号不能为空！");
			}
			UTMap<String, Object> codeInven = assetInventoryDao.getInventoryByCode(code);
			if (null == codeInven || codeInven.isEmpty()) {
				throw new EscServiceException("导入失败，盘点单号为【"+code+"】的盘点单在系统中不存在！");
			}
			//盘点单id
			inventoryId = (String) codeInven.get("id");
			
			//资产列表
			List<Map<String, Object>> assetsList = (List<Map<String, Object>>)obj.get("assetsList");
			if (null == assetsList || assetsList.size() <= 0) {
				throw new EscServiceException("导入失败，assetsList不能为空！");
			}
			Iterator<Map<String, Object>> assetIt = assetsList.iterator();
			while (assetIt.hasNext()) {
				Map<String, Object> asset = (Map<String, Object>) assetIt.next();
				String assetsCode = (String) asset.get("code");//资产编号
				if (StringUtils.isEmpty(assetsCode)) {
					throw new EscServiceException("导入失败，资产编号不能为空！");
				}
				//校验资产明细中的资产是否存在于系统中
				UTMap<String, Object> assetUtmap = assetPhysicalDao.getAssetInfoByAssetCode(assetsCode);
				if (null == assetUtmap || assetUtmap.isEmpty()) {
					throw new EscServiceException("导入失败，盘点单号为【"+code+"】的盘点单中资产编号为【"+assetsCode+"】的资产在系统中不存在！");
				}
				String assetId = (String) assetUtmap.get("id");//资产id
				String status = (String)asset.get("status");//盘点状态
				if (StringUtils.isEmpty(status)) {
					throw new EscServiceException("导入失败，状态不能为空！");
				}
				if (StringUtils.isNotEmpty(status) && !StringUtils.equals("0", status) && !StringUtils.equals("1", status) && !StringUtils.equals("2", status)) {
					throw new EscServiceException("导入失败，状态值只能为0、1、2！");
				}
				UTMap<String, Object> oldAssetInventory = assetInventoryDao.getInventoruAsset(inventoryId, assetId);
				String oldAssetInventoryId = "";
				String isCreate = "0";
				String oldStatus = null;
				if (null == oldAssetInventory || oldAssetInventory.isEmpty()) {
					isCreate = "1";
				}else {
					oldAssetInventoryId = (String) oldAssetInventory.get("id");
					oldStatus = (String)oldAssetInventory.get("status");
				}
				Map<String, Object> mm = new HashMap<String, Object>();
				mm.put("assetsId", assetId);
				mm.put("inventoryId", inventoryId);
				mm.put("newStatus", status);
				mm.put("id", oldAssetInventoryId);
				mm.put("isCreate", isCreate);
				mm.put("oldStatus", oldStatus);
				listAsset.add(mm);
			}
		}
		for (Map<String, Object> mmp : listAsset) {
			String isCreate = (String) mmp.get("isCreate");
			mmp.put("confirmStatus", "2");
			if (StringUtils.equals("1", isCreate)) {
				mmp.put("id", UUID.randomUUID().toString());
				mmp.put("status", mmp.get("newStatus"));
				this.assetInventoryDao.addAssetInventory(mmp);
			}else {
				String newStatus = mmp.get("newStatus").toString();
				String oldStatus = mmp.get("oldStatus").toString();
				if ((StringUtils.equals("0", oldStatus) || StringUtils.equals("0", newStatus))//如果已经盘点正常
						|| (StringUtils.equals("1", oldStatus) && StringUtils.equals("2", newStatus)) //先亏后盈
						|| (StringUtils.equals("2", oldStatus) && StringUtils.equals("1", newStatus))) {//先盈后亏
					mmp.put("status", "0");
				}else {
					mmp.put("status", newStatus);
				}
				assetInventoryDao.updateInverstoryAsset(mmp);
			}
			userTaskService.finishTask(inventoryId+String.valueOf(mmp.get("assetsId")), "实物资产管理员盘点");//完成资产管理员盘点确认的待办
			//更新资产列表里面的盘点状态
			Map<String, Object> pMap = new HashMap<String, Object>();
			pMap.put("id", mmp.get("assetsId"));
			pMap.put("inventory_status", mmp.get("status"));
			assetPhysicalDao.updateById(pMap);
			
		}
		if (StringUtils.isNotEmpty(inventoryId)) {
			Map<String, Object> ut = new HashMap<String, Object>();
			ut.put("id", inventoryId);
			ut.put("status", 2);
			getOptionDao().updateById(ut);
		}
		logger.info("----------------------------结束导入盘点结果，结束时间："+sdf.format(new Date())+"-----------------------------");
		return true;
	}


	@Override
	public UTMap<String, Object> getByCode(String code) {
		// TODO Auto-generated method stub
		return assetInventoryDao.getInventoryByCode(code);
	}


	@Override
	public boolean updateInventoryStatus(Map<String, Object> param) {
		return assetInventoryDao.updateInverstoryAsset(param);
	}
}