package com.esc.oms.asset.application.dao.impl;

import com.esc.oms.asset.application.dao.IAssetApplicationDao;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.RoleUtils;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
@Repository
public class AssetApplicationDaoImpl extends BaseOptionDao implements IAssetApplicationDao{
	
	private String applyDetailTableName = "assets_material_apply_detail";
	

	@Override
	public String getTableName() {
		return "assets_material_apply";
	}
	

	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params), pageBean, null);
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append("SELECT DISTINCT ama.id,ama.`code`,ama.title,ama.applyType,so.`longName` applyUnit,ama.applyUserId, " );
		sql.append(" ama.applyTime,ama.remark,ama.`status` ,ama.workflowInstanceId,ama.createUserId,IFNULL(concat(su.`name`,'/',su.`code`),'admin') applyUserName ");
		if(params!=null && params.size()>0 &&params.get("auditStatus")!=null &&  StringUtils.isNotEmpty(params.get("auditStatus").toString())){
			if("1".equals(params.get("auditStatus"))){
				sql.append(" ,t4.currentStepName ");
			}
		}
		sql.append(" FROM assets_material_apply ama ");
		sql.append(" LEFT JOIN sys_org so ON so.id = ama.applyUnit ");
		sql.append(" LEFT JOIN sys_user su ON su.id = ama.createUserId ");
		if(params!=null && params.size()>0 &&params.get("auditStatus")!=null &&  StringUtils.isNotEmpty(params.get("auditStatus").toString())){
			if("1".equals(params.get("auditStatus"))){
				sql.append(" left join sys_workflow_instance t4 on ama.workflowInstanceId=t4.id ");
				sql.append(" where FIND_IN_SET('"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"',t4.currentExecutor) ");
			}else if("2".equals(params.get("auditStatus"))){
				sql.append(" left join sys_workflow_audit_history t4 on ama.workflowInstanceId=t4.instanceId ");
				sql.append(" where FIND_IN_SET('"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"',t4.optionUserId) " );
				sql.append(" and t4.nodeName!='开始' " );//屏蔽开始节点
			}
		}else{
			sql.append(" WHERE 1=1 ");
		}
		if(params!=null && params.size()>0){
			if(params.get("code")!=null &&  StringUtils.isNotEmpty(params.get("code").toString())){
				sql.append(" AND ama.`code` LIKE '%"+params.get("code").toString().trim()+"%' ");
			}
			if(params.get("title")!=null && StringUtils.isNotEmpty(params.get("title").toString())){
				sql.append(" AND ama.title LIKE '%"+params.get("title").toString().trim()+"%'");
			}
			if(params.get("applyUserId")!=null && StringUtils.isNotEmpty(params.get("applyUserId").toString())){
//				sql.append(" AND ama.applyUserId LIKE '%"+params.get("applyUserId").toString().trim()+"%'");
				sql.append(" AND concat(su.name,'/',su.code) like '%"+params.get("applyUserId").toString().trim()+"%'");
			}
			if(params.get("startTime")!=null && StringUtils.isNotEmpty(params.get("startTime").toString())){
				sql.append(" AND ama.applyTime >='"+params.get("startTime").toString().trim()+"'");
			}
			if(params.get("endTime")!=null && StringUtils.isNotEmpty(params.get("endTime").toString())){
				sql.append(" AND ama.applyTime <='"+params.get("endTime").toString().trim()+"'");
			}
		}
		
		if((params.get("auditStatus") ==null ||  StringUtils.isEmpty(params.get("auditStatus").toString())) && !EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.ASSET_MANAGER,RoleUtils.SYSTEM_ADMINISTRATOR)){//普通金融机构用户
			sql.append(" and ama.createUserId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' ");//非研发用户只能查询自己的数据，研发用户查询所有数据方便调试
		}
		sql.append(" ORDER BY ama.createTime desc");
		return  sql.toString();
	}
	
	private String getAssetIssueListMapsSql(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT amad.id,concat(ami.`name`,IF(ami.`codeNum` is null or ami.`codeNum`='', '', concat('/',ami.`codeNum`))) assetsId,amc.`name` category,amsc.`name` subCategory, " );
		sql.append(" amad.grantAmount,concat(su.`name`,'/',su.`code`) grantUserId,amad.grantTime,amad.`status`,amad.assetsId asset ");
		sql.append(" FROM assets_material_apply_detail amad ");
		sql.append(" LEFT JOIN assets_material_info ami ON ami.id = amad.assetsId ");
		sql.append(" LEFT JOIN assets_material_apply ama ON ama.id = amad.applyId ");
		sql.append(" LEFT JOIN assets_material_category amc ON amc.id = ami.category ");
		sql.append(" LEFT JOIN assets_material_sub_category amsc ON amsc.id = ami.subCategory ");
		sql.append(" LEFT JOIN sys_user su ON su.id = amad.grantUserId ");
		sql.append(" WHERE 1=1 ");
		if(params!=null && params.size()>0){
			if(params.get("appId")!=null &&  StringUtils.isNotEmpty(params.get("appId").toString())){
				sql.append(" AND amad.applyId = '"+params.get("appId").toString().trim()+"' ");
			}
		}
		sql.append(" ORDER BY amad.id ");
		return  sql.toString();
	}

	private String getAssetIssueListMapsSql1(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT ami.id,ami.`name`,ami.`code`,amc.`name` categoryName,amsc.`name` subCategoryName,concat(ami.`name`,IF(ami.`serialNum` is null or ami.`serialNum`='', '', concat('/',ami.`serialNum`))) assetsNameCode," );
		sql.append(" so.`name` resDepartId,ami.buyContract,ami.maintainContract,concat(su.`name`, '/', su.`code`) grantUserId, concat(su2.`name`, '/', su2.`code`) resUserId,ami.brand,ami.model,ap.`name` location,amad.status,amad.grantTime,ami.assetsLevel ");
		sql.append(" FROM assets_material_apply_detail amad ");
		sql.append(" LEFT JOIN assets_material_info ami ON ami.id = amad.assetsId ");
		sql.append(" LEFT JOIN assets_material_apply ama ON ama.id = amad.applyId ");
		sql.append(" LEFT JOIN assets_material_category amc ON amc.id = ami.category ");
		sql.append(" LEFT JOIN assets_material_category amsc ON amsc.id = ami.subCategory ");
		sql.append(" LEFT JOIN sys_user su ON su.id = amad.grantUserId ");
		sql.append(" LEFT JOIN sys_user su2 ON su2.id = ami.resUserId ");
		sql.append(" LEFT JOIN sys_org so ON so.id = ami.resDepartId ");
		sql.append(" LEFT JOIN assets_place ap ON ap.id = ami.location ");
		sql.append(" WHERE 1=1 ");
		if(params!=null && params.size()>0){
			if(params.get("appId")!=null &&  StringUtils.isNotEmpty(params.get("appId").toString())){
				sql.append(" AND amad.applyId = '"+params.get("appId").toString().trim()+"' ");
			}
		}
		sql.append(" ORDER BY amad.grantTime ");
		return  sql.toString();
	}

	@Override
	public boolean addAssetIssue(Map info) {
		return	super.saveBySql(applyDetailTableName, info);
	}


	@Override
	public boolean deleteAssetIssueById(String id) {
		return super.deleteByIds(applyDetailTableName, id);
	}

	@Override
	public boolean deleteAssetIssueByAssetId(String id) {
		StringBuilder sql=new StringBuilder();
		sql.append(" DELETE FROM assets_material_apply_detail WHERE assetsId = '" + id + "'");
		return super.executeUpdate(sql.toString());
	}
	
	@Override
	public List<UTMap<String, Object>> getAssetIssueListMaps(Map param) {
		return super.getListBySql(getAssetIssueListMapsSql(param));
	}

	@Override
	public List<UTMap<String, Object>> getAssetListByAppId(Map param) {
		return super.getListBySql(getAssetIssueListMapsSql1(param));
	}
	
	@Override
	public boolean checkAssetIssueConfirm(String appId, String status) {
		StringBuilder sql=new StringBuilder();
		sql.append(" select * from assets_material_apply_detail amad where amad.`status` != '" + status + "' and amad.applyId = '" + appId + "'");
		List<UTMap<String, Object>> map = super.getListBySql(sql.toString());
		if(map.size() > 0)
			return false;
		return true;
	}

	
	@Override
	public boolean updateIssueStatusById(String id,String status) {
		StringBuilder sql=new StringBuilder();
		sql.append(" update assets_material_apply_detail amad SET amad.`status` = '"+status+"' WHERE amad.id = '" +id+"'");
		return super.executeUpdate(sql.toString());
	}

	@Override
	public boolean updateAssetIssueById(Map<String,Object> info) {
		StringBuilder sql=new StringBuilder();
		sql.append(" update assets_material_apply_detail amad SET amad.`status` = '" 
		+ info.get("status") + "' , amad.`grantUserId` = '"
		+ info.get("grantUserId")  + "' , amad.`grantTime` = '"
		+ info.get("grantTime")  + "' WHERE amad.id = '" + info.get("id") +"'");
		return super.executeUpdate(sql.toString());
	}

	@Override
	public List<UTMap<String, Object>> getAssetIssuePageInfo(Map param) {
		return  super.getListBySql(getAssetIssueListMapsSql(param));
	}


	@Override
	public boolean deleteAssetIssueByAppId(String id) {
		StringBuilder sql=new StringBuilder();
		sql.append("DELETE FROM assets_material_apply_detail  WHERE applyId = '"+id+"'");
		return super.executeUpdate(sql.toString());
	}


	@Override
	public UTMap<String, Object> getAssetIssueById(String id) {
		return super.getMapById(applyDetailTableName, null, id);
	}
	
	
	@Override
	public boolean updateAssetIssueStatusByAppId(String applyId,
			String status) {
		StringBuilder sql=new StringBuilder();
		sql.append(" update assets_material_apply_detail amrd SET amrd.`status` = '"+status+"' WHERE amrd.applyId = '" +applyId+"'");
		return super.executeUpdate(sql.toString());
	}
	
	@Override
	public UTMap<String, Object> getById(String id){
		return super.getOneBySql(getSearchByIdSql(id));
	}
	
	private String getSearchByIdSql(String id){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT ama.id,ama.applyTime,ama.applyType,ama.applyUnit,ama.applyUserId,amc.`name` categoryName,amsc.`name` subCategoryName, " );
		sql.append(" ama.category,ama.`code`,ama.createTime,ama.createUserId,ama.reason,ama.remark, ");
		sql.append(" ama.`status`,ama.subCategory,ama.title,ama.workflowInstanceId,so.`name` applyUnitName ");
		sql.append(" FROM assets_material_apply ama  ");
		sql.append(" LEFT JOIN sys_org so ON so.id = ama.applyUnit  ");
		sql.append(" LEFT JOIN assets_material_category amc ON amc.id = ama.category  ");
		sql.append(" LEFT JOIN assets_material_sub_category amsc ON amsc.id = ama.subCategory  ");
		sql.append(" WHERE ama.id = '"+id+"'");
		return  sql.toString();
	}


	@Override
	public List<UTMap<String,Object>> getIssueAssetByStatus(String assetId) {
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT amad.assetsId FROM assets_material_apply_detail amad "
				 + " WHERE amad.assetsId = '" + assetId + "' ");
		return super.getListBySql(sql.toString());
	}


	@Override
	public List<UTMap<String, Object>> getAssetsList(Map<String, Object> param) {
		// TODO Auto-generated method stub
		return super.getListBySql(this.getAssetsListSql(param), null);
	}
	private String getAssetsListSql(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT ami.id,ami.sn,ami.`name`,ami.`code`,ami.codeNum,ami.category,amc.`name` categoryName,amsc.`name` subCategoryName,so.`longName` resDepartId,");
//		sql.append(" IF(ami.auxiliaryAsset='1',concat(concat('(主)','',ami.`name`), IF ( ami.serialNum IS NULL OR ami.serialNum = '', '', concat('/', ami.serialNum)))," );
//		sql.append("concat( concat('(辅)', '', ami.`name`), IF ( ami.codeNum IS NULL OR ami.codeNum = '', '', concat('/', ami.codeNum)))) assetsNameCode," );
		sql.append(" IF(ami.auxiliaryAsset='1',concat('(主)','',ami.`name`)," );
		sql.append("concat('(辅)', '', ami.`name`)) assetsNameCode," );
		sql.append(" ami.status,ami.assetPrice,ami.registStatus, ami.serialNum,ami.userId,ami.brand,ami.model," );
		sql.append(" ami.salvage,ami.useYears,ami.inboundDate,ami.confidentiality,ami.subCategory, ami.assetsLevel, ");
		sql.append(" ami.maintAssetStartDate,ami.maintAssetsEndDate,ami.remark,ami.systemClass,");
		sql.append(" ami.assetStartDate,ami.assetEndDate,aai.supplierName assetSupplierName,ami.controllable,ami.otherMaint,");
		sql.append(" ami.auxiliaryAsset,ami.ownSystem,ami.producer,ami.integrity,ami.availability,ami.hasBackup,ami.totalAssets,ami.outdate, ");
		sql.append(" ami.assetsUse, ami.assetStatus, ami.assetsCosts, ami.preAssetsClass, ");
		sql.append(" ami.ip, ami.EquipmentUse, ami.isPositive, ami.assetAttributes, ami.systemName, ami.MaintenanceAmount,");
		sql.append(" ami.CabinetStartU, ami.CabinetEndU, ami.businessSystemLeader, ami.EquipmentLeader,ami.assetsType,");
		sql.append(" aai.agreementName buyContract,aai2.agreementName maintainContract,concat(su.`name`, '/', su.`code`) resUserName,");
		sql.append(" ap.`name` location,ami.resUserId resUser,ifnull(ami.isScrap,'0') isScrap,");
		sql.append(" so.`name` resDepartName,aai.agreementName buyContractName,");
		sql.append(" aai2.agreementName maintainContractName,(to_days(ami.maintAssetsEndDate)-to_days(now())) maintAssetsLeftNum,");
		sql.append( " aai2.supplierName maintSupplierName,(to_days(ami.assetEndDate)-to_days(now())) assetsLeftTime,");
		sql.append(" su2.name businessSystemLeaderName,su3.name  EquipmentLeaderName ");
		sql.append(" FROM assets_material_info ami ");
		sql.append(" LEFT JOIN assets_material_category amc ON amc.id = ami.category ");
		sql.append(" LEFT JOIN assets_material_category amsc ON amsc.id = ami.subCategory ");
		sql.append(" LEFT JOIN sys_user su ON su.id = ami.resUserId ");
		sql.append(" LEFT JOIN sys_user su2 on su2.id = ami.businessSystemLeader ");
		sql.append(" LEFT JOIN sys_user su3 on su3.id = ami.EquipmentLeader ");
		sql.append(" LEFT JOIN sys_org so ON so.id = ami.resDepartId ");
		sql.append(" LEFT JOIN assets_place ap ON ap.id = ami.location ");
		sql.append(" LEFT JOIN assets_agreement_info aai ON ami.buyContract = aai.id ");
		sql.append(" LEFT JOIN assets_agreement_info aai2 ON aai2.id = ami.maintainContract ");
		sql.append(" WHERE 1=1 ");
		sql.append(" AND (ami.deleteFlag != 1 OR ami.deleteFlag IS NULL) ");
//		sql.append(" AND ifnull(ami.isScrap,'0') <> '1'");
		if(params!=null && params.size()>0){
			if(params.get("category")!=null && CommonUtils.notNullStrOrEmpty(params.get("category").toString())){
				sql.append(" AND amc.id = '"+params.get("category").toString().trim()+"'");
			}
			if(params.get("subCategory")!=null && CommonUtils.notNullStrOrEmpty(params.get("subCategory").toString())){
				sql.append(" AND amsc.id = '"+params.get("subCategory").toString().trim()+"'");
			}
			if(params.get("agreementId")!=null && CommonUtils.notNullStrOrEmpty(params.get("agreementId").toString())){ //资产合同--资产视图
				sql.append(" AND (ami.buyContract = '"+params.get("agreementId").toString().trim()+"' "
						+ "or ami.maintainContract = '"+params.get("agreementId").toString().trim()+"')");
			}
			if(params.get("name")!=null && CommonUtils.notNullStrOrEmpty(params.get("name").toString())){ //资产合同--资产视图
				sql.append(" AND ami.name like '%"+params.get("name").toString().trim()+"%'");
			}
			if(params.get("codeNum")!=null && CommonUtils.notNullStrOrEmpty(params.get("codeNum").toString())){
				sql.append(" AND (ami.codeNum like '%"+params.get("codeNum").toString().trim()+"%' OR ami.serialNum like '%"+params.get("codeNum").toString().trim()+"%')");
			}
			if(params.get("resUserId")!=null && CommonUtils.notNullStrOrEmpty(params.get("resUserId").toString())){
//				sql.append(" and (su.name like '%"+params.get("resUserId").toString().trim()+"%' or su.code like '%"+params.get("resUserId").toString().trim()+"%')");
				sql.append(" and CONCAT(su.name,'/',su.code) like '%"+params.get("resUserId").toString().trim()+"%' ");
			}
			if(params.get("resDepartId")!=null && CommonUtils.notNullStrOrEmpty(params.get("resDepartId").toString())){
				sql.append(" AND ami.resDepartId = '"+params.get("resDepartId").toString().trim()+"'");
			}
			if(params.get("resDepartLongName")!=null && CommonUtils.notNullStrOrEmpty(params.get("resDepartLongName").toString())){
				sql.append(" AND so.`longName` like '%"+params.get("resDepartLongName").toString().trim()+"%'");
			}
			if(params.get("isScrap")!=null && CommonUtils.notNullStrOrEmpty(params.get("isScrap").toString())){
				sql.append(" AND ifnull(ami.isScrap,'0') = '"+params.get("isScrap").toString().trim()+"'");
			}else{
//				sql.append(" AND ifnull(ami.isScrap,'0') <> '1'");
			}
			if(params.get("ids")!=null && CommonUtils.notNullStrOrEmpty(params.get("ids").toString())){
				sql.append(" AND ami.id in ("+params.get("ids").toString().trim()+")");
			}
			if(params.get("userStatus")!=null && CommonUtils.notNullStrOrEmpty(params.get("userStatus").toString())){
				//sql.append(" AND (ami.resUserId is NULL OR ami.resUserId = '') ");
				
				//资产申请、借用、领用功能中，选择资产时判断条件改为当资产状态为“已入库待领用”或“闲置”才能申请、借用、领用  modified by hy 2018/11/26
				sql.append(" and ami.assetStatus in('1','3')");
				
			}
			if(params.get("auxiliaryAsset")!=null && CommonUtils.notNullStrOrEmpty(params.get("auxiliaryAsset").toString())){
				sql.append(" AND ami.auxiliaryAsset = "+params.get("auxiliaryAsset").toString().trim()+" and (ami.parentId IS NULL OR ami.parentId = '' ) ");
			}
			if(params.get("parentId")!=null && CommonUtils.notNullStrOrEmpty(params.get("parentId").toString())){
				sql.append(" AND ami.parentId = '"+params.get("parentId").toString().trim()+"'");
			}
			if(params.get("locationName")!=null && CommonUtils.notNullStrOrEmpty(params.get("locationName").toString())){
				sql.append(" AND ap.name like '%"+params.get("locationName").toString().trim()+"%'");
			}
			if(params.get("resUserName")!=null && CommonUtils.notNullStrOrEmpty(params.get("resUserName").toString())){
				sql.append(" AND su.name like '%"+params.get("resUserName").toString().trim()+"%'");
			}
			if(params.get("registStatus")!=null && CommonUtils.notNullStrOrEmpty(params.get("registStatus").toString())){
				sql.append(" AND ami.registStatus = '"+params.get("registStatus").toString().trim()+"'");
			}else{
				if(params.get("registAssets")!=null && CommonUtils.notNullStrOrEmpty(params.get("registAssets").toString())){}else{
					sql.append(" AND (ami.registStatus is NULL OR ami.registStatus = '2') ");
				}
			}
			if(params.get("assetsLevel")!=null && CommonUtils.notNullStrOrEmpty(params.get("assetsLevel").toString())){
				sql.append(" AND ami.assetsLevel = '"+params.get("assetsLevel").toString().trim()+"'");
			}
		}else{
			sql.append(" AND ifnull(ami.isScrap,'0') <> '1'");
		}

		sql.append(" and not exists ( ");
		sql.append(" SELECT amad.assetsId FROM assets_material_apply_detail amad left join assets_material_apply ama on amad.applyId=ama.id "
				+ " WHERE amad.assetsId = ami.id and ama.status in ('0', '1', '2', '3', '5', '8') ) ");

		if(params!=null && params.size()>0 && null != params.get("overviewWarn")){
			if("0".equals(String.valueOf(params.get("overviewWarn")))){
				sql.append(" order by assetsLeftTime asc");
			}else{
				sql.append(" order by maintAssetsLeftNum asc");
			}
		}else{
			sql.append(" order by ami.createTime desc,ami.sortCode ");
		}
		return  sql.toString();
	}
}
