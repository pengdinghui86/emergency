package com.esc.oms.asset.physical.controller;

import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.security.service.ISysOrgService;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.asset.agreement.service.IAssetsAgreementInfoService;
import com.esc.oms.asset.allocation.service.IAssetAllocationlService;
import com.esc.oms.asset.physical.service.IAssetPhysicalService;
import com.esc.oms.asset.place.service.IAssetPlaceService;
@Controller
@RequestMapping("none")
public class AssetPhysicalQRCodeController extends BaseOptionController {


	@Resource
	private IAssetPhysicalService assetPhysicalService;
	
	@Resource
	private IAssetAllocationlService assetAllocationlService;
	
	@Resource
	private IAssetsAgreementInfoService assetsAgreementInfoService;
	
	@Resource
	private IAssetPlaceService assetPlaceService;
	
	@Resource
	private ISysUserService sysUserService;
	
	@Resource ISysOrgService sysOrgService;
	
	@Override
	public IBaseOptionService optionService() {
		return assetPhysicalService;
	}
	
	
	@RequestMapping(value="getById")
	@ResponseBody
	public UTMap<String, Object> defgetById(@RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = null;
    	try{
    		map = assetPhysicalService.getById(param.get("id").toString());
    		if(null != map){
    			if(null != (String)map.get("category")){
    				UTMap<String,Object> category = assetAllocationlService.getById((String)map.get("category"));
    				if(null != category){
    					map.put("category", category.get("name"));
    				}
    			}
    			if(null != (String)map.get("subCategory")){
    				UTMap<String,Object> subCategory = subCategory = assetAllocationlService.getSubCategoryById((String)map.get("subCategory"));
    				if(null != subCategory){
    					map.put("subCategory", subCategory.get("name"));
    				}
    			}
    			if(null != (String)map.get("buyContract")){
    				UTMap<String,Object> buyContract = assetsAgreementInfoService.getById((String)map.get("buyContract"));
    				if(null != buyContract){
    					map.put("buyContract", buyContract.get("agreementName"));
    					map.put("contractCode", buyContract.get("agreementCode"));
    					map.put("supplier", buyContract.get("supplierName"));
    				}
    			}
    			if(null != (String)map.get("maintainContract")){
    				UTMap<String,Object> maintainContract = assetsAgreementInfoService.getById((String)map.get("maintainContract"));
    				if(null != maintainContract){
    					map.put("maintainContract", maintainContract.get("agreementName"));
    					map.put("maintainCode", maintainContract.get("agreementCode"));
    					map.put("maintainSupplier", maintainContract.get("supplierName"));
    					map.put("maintainStartDate", maintainContract.get("agreementBeginDate"));
    					map.put("maintainEndDate", maintainContract.get("agreementEndDate"));
    				}
    			}
    			if(null != (String)map.get("status")){
    				if("1".equals((String)map.get("status"))){
    					map.put("status", "已入库待领用");
    				}else if("2".equals((String)map.get("status"))){
    					map.put("status", "使用中");
    				}else if("3".equals((String)map.get("status"))){
    					map.put("status", "闲置");
    				}else if("4".equals((String)map.get("status"))){
    					map.put("status", "维修中");
    				}else{
    					map.put("status", "报废");
    				}
    			}
    			if(null != (String)map.get("location")){
    				UTMap<String,Object> location = assetPlaceService.getById((String)map.get("location"));
    				if(null != location){
    					map.put("location", location.get("name"));
    				}
    			}
    			if(null != map.get("resUserId") && StringUtils.isNotEmpty((String)map.get("resUserId"))){
    				UTMap<String,Object> resUserId = sysUserService.getById((String)map.get("resUserId"));
    				if(null != resUserId){
    					map.put("resUserId", resUserId.get("name"));
    				}
    			}
    			if(null != map.get("resDepartId") && StringUtils.isNotEmpty((String)map.get("resDepartId"))){
    				UTMap<String,Object> resDepartId = sysOrgService.getById((String)map.get("resDepartId"));
    				if(null != resDepartId){
    					map.put("resDepartId", resDepartId.get("name"));
    				}
    			}
    			if(null != (String)map.get("controllable")){
    				if("1".equals((String)map.get("controllable"))){
    					map.put("controllable", "是");
    				}else{
    					map.put("controllable", "否");
    				}
    			}
    			if(null != (String)map.get("hasBackup")){
    				if("1".equals((String)map.get("hasBackup"))){
    					map.put("hasBackup", "是");
    				}else{
    					map.put("hasBackup", "否");
    				}
    			}
    		}
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return map;
	}
	
//	@RequestMapping(value = "/assetsView")
//	public ModelAndView assetsView(String id, HttpServletRequest request) {
//		UTMap<String, Object> map = null;
//    	try{
//    		map = optionService().getById(id);
//		}catch(Exception e){
//			logger.error("Exception", e);
//    	}
//		request.setAttribute("ajaxJson", JSONObject.fromObject(map));
//		return new ModelAndView("none/assets/assetsView");
//	}
	
}