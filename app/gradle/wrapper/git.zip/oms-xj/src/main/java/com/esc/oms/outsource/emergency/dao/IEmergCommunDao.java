package com.esc.oms.outsource.emergency.dao;

import java.util.List;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

public interface IEmergCommunDao extends IBaseOptionDao{
	
	public List<UTMap<String, Object>> getEmergCommunByNameAndId(String name,String id);
}
