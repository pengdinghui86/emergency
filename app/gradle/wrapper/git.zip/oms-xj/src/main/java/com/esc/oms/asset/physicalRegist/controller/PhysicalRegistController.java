package com.esc.oms.asset.physicalRegist.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.esc.framework.workflow.service.IWorkflowEngine;
import org.esc.framework.workflow.utils.bpmn.Instance;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.asset.allocation.service.IAssetAllocationlService;
import com.esc.oms.asset.physical.dao.IAssetPhysicalDao;
import com.esc.oms.asset.physicalRegist.service.IPhysicalRegistService;
import com.esc.oms.asset.place.service.IAssetPlaceService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ExcelUtil;

import net.sf.json.JSONObject;
@Controller
@RequestMapping("physicalRegist")
public class PhysicalRegistController extends BaseOptionController {


	@Resource
	private IPhysicalRegistService physicalRegistService;
	
	@Resource
	private IAssetPlaceService assetPlaceService;
	
	@Resource
	private IAssetAllocationlService assetAllocationlService;

	@Resource
	private IAssetPhysicalDao assetPhysicalDao;

	@Resource
	private ISysParamService sysParamService;
	
	@Resource
	private IWorkflowEngine workflowEngine;

	@Override
	public IBaseOptionService optionService() {
		return physicalRegistService;
	}
	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			physicalRegistService.getPageInfo(params, pageBean);
//			physicalRegistService.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	/**
	 * 待审批列表--分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getPendPageList")  
    @ResponseBody
	public UTPageBean getPendPageList(@RequestParam Map<String, Object> params) {
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try {
			physicalRegistService.getPendPageList(params, pageBean);
		} catch (Exception e) {
			logger.error("Exception", e);
		}
		return pageBean;
	}
	
	/**
	 * 已审批列表--分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAlreadyPageList")  
    @ResponseBody
    public UTPageBean getAlreadyApprovalPageList(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try {
			physicalRegistService.getAlreadyApprovalPageList(params, pageBean);
		} catch (Exception e) {
			logger.error("Exception", e);
		}
		return pageBean;
	}
    @RequestMapping(value="/saveOrUpdate",method=RequestMethod.POST)  
    @ResponseBody
    public String saveorupdate(@RequestBody Map<String,Object> map){  
    	String codeNum = (String)map.get("codeNum");
    	String id = (String)map.get("id");
		String serialNum = (String)map.get("serialNum");
    	boolean flag = false;
    	map.put("deleteFlag", 0);
    	map.put("registStatus", "1");//预登记
    	//保存的时候，根据前台传过来的类型，判断我们的资产是否需要审批的流程
    	if(map.get("preAssetsClass") != null && "1".equals((String)map.get("preAssetsClass"))) {
    		map.put("status", IPhysicalRegistService.STATUS_NOT_SUBMIT);
    	}else{
			map.put("status",null);
		}
    	try{
	    	if(id == null){
	    		Map param = new HashMap();
				if(CommonUtils.notNullStrOrEmpty(codeNum)){
					param.put("codeNum", codeNum);
					if(physicalRegistService.isExist(param)){
						throw new EscServiceException("资产编号已经存在！");
					}
				}

				//判断资产序列号是否为空
				param.clear();
				if(CommonUtils.notNullStrOrEmpty(serialNum)){
					param.put("serialNum", serialNum);
					param.put("deleteFlag", 0);
					if(physicalRegistService.isExist(param)){
						throw new EscServiceException("资产序列号已经存在！");
					}
				}
	    		flag = physicalRegistService.add(map);
	    	}else{
	    		if(StringUtils.isNotEmpty(codeNum)){
	    			List<UTMap<String,Object>> names = physicalRegistService.getAssetBycodeAndId(codeNum,id);
	    			if(null != names && names.size() > 0){
	    				throw new EscServiceException("资产编号已经存在！");
	    			}
	    		}
				//如果是预登记的 需要判断是否已经开始审批，如果已经开始审批，则不可再进行修改
				UTMap<String,Object> nmap = physicalRegistService.getById(id);
				if("1".equals((String)nmap.get("preAssetsClass")) && ((IPhysicalRegistService.STATUS_AUDITING+"")
						.equals((String)nmap.get("status")) || (IPhysicalRegistService.STATUS_WAITING+"").equals((String)nmap.get("status"))
						|| (IPhysicalRegistService.STATUS_FINISH+"").equals((String)nmap.get("status")))) {
					throw new EscServiceException("该预登记资产已提交审批，不可修改！");
				}
				if(CommonUtils.notNullStrOrEmpty(serialNum) && assetPhysicalDao.isExitSerialNum(serialNum, id)){
					throw new EscServiceException("资产序列号已经存在！");
				}
	    		flag = physicalRegistService.updateById(map);
	    	}
    	}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "操作成功");
    }
    
    /**
	 * 提交审批
	 * @param map
	 * @return
	 */
	@RequestMapping(value="submit", method=RequestMethod.POST)  
    @ResponseBody
    public String submit(@RequestBody Map<String,Object> map) {
		try {
			//判断当前状态是否是已经提交审批状态
			if((IPhysicalRegistService.STATUS_AUDITING+"").equals((String)map.get("status"))
					|| (IPhysicalRegistService.STATUS_WAITING+"").equals((String)map.get("status"))
					|| (IPhysicalRegistService.STATUS_FINISH+"").equals((String)map.get("status"))){
				throw new EscServiceException("该预登记资产已提交审批！");
			}
			//判断编号序列号的唯一性
			String codeNum = (String)map.get("codeNum");
			String id = (String)map.get("id");
			String serialNum = (String)map.get("serialNum");
			if(id == null) {
				Map param = new HashMap();
				if(StringUtils.isNotEmpty(codeNum)) {
					param.put("codeNum", codeNum);
					if (physicalRegistService.isExist(param)) {
						throw new EscServiceException("资产编号已经存在！");
					}
				}
				//判断资产序列号是否为空
				param.clear();
				if(CommonUtils.notNullStrOrEmpty(serialNum)){
					param.put("serialNum", serialNum);
					param.put("deleteFlag", 0);
					if(physicalRegistService.isExist(param)){
						throw new EscServiceException("资产序列号已经存在！");
					}
				}
			}else{
				if(StringUtils.isNotEmpty(codeNum)) {
					List<UTMap<String, Object>> names = physicalRegistService.getAssetBycodeAndId(codeNum, id);
					if (null != names && names.size() > 0) {
						throw new EscServiceException("资产编号已经存在！");
					}
				}
				if(CommonUtils.notNullStrOrEmpty(serialNum) && assetPhysicalDao.isExitSerialNum(serialNum, id)){
					throw new EscServiceException("资产序列号已经存在！");
				}
			}
			physicalRegistService.submit(map);
			return UTJsonUtils.getJsonMsg(true, "操作成功");
		}catch(EscServiceException e){
			logger.error("EscServiceException",e);
			return UTJsonUtils.getJsonMsg(false,e.getMessage());
    	}catch (Exception e) {
    		logger.error("Exception",e);
			return UTJsonUtils.getJsonMsg(false,"操作失败");
		}
	}
    
    /**
	 * 根据id查询
	 * @param param
	 * @return
	 */
	@RequestMapping(value="getById")
	@ResponseBody
	public UTMap<String, Object> defgetById(@RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = null;
    	try{
    		map = physicalRegistService.getById(param.get("id").toString());
    		if(null != map){
//    				List<UTMap<String, Object>> subCategoryList = assetAllocationlService.getSubCategoryByParentId(String.valueOf(map.get("category")));
//        			map.put("subCategoryList", subCategoryList);
        			
        			
    				UTMap<String,Object> params = new UTMap<String,Object>();
					params.put("parentId", map.get("id"));
    				List<UTMap<String, Object>> auxiliaryList = physicalRegistService.getListMaps(params);
    				map.put("auxiliaryList", auxiliaryList);
				if(null != map.get("registStatus")){
					if("1".equals(String.valueOf(map.get("registStatus")))){
						map.put("statusName", "预登记");
					}else{
						map.put("statusName", "已入库");
					}
    			}
    		}
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return map;
	}

	/**
	 * 登记单导出
	 */
	@RequestMapping(value="exportByData")
	@ResponseBody
	public void exportByData(HttpServletRequest request, HttpServletResponse response, @RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = new UTMap<String, Object>();
	  
    	try{
    		if(null != param.get("id")){
    			map = optionService().getById((String)param.get("id"));
    			if(null != map){
    				List<UTMap<String, Object>> mapList = new ArrayList<UTMap<String, Object>>();
    				mapList.add(map);
    				//替换下拉的值
    				Map<String, String> fieldAndParamType = new HashMap<String, String>();
    				fieldAndParamType.put("assetsLevel", "assetsLevel");
    				sysParamService.changeParamData(mapList, fieldAndParamType);
    				map = mapList.get(0);
    				UTMap<String,Object> params = new UTMap<String,Object>();
					params.put("parentId", map.get("id"));
    				List<UTMap<String, Object>> auxiliaryList = physicalRegistService.getListMaps(params);
    				map.put("auxiliaryList", auxiliaryList);
					if(null != map.get("registStatus")){
						if("1".equals(String.valueOf(map.get("registStatus")))){
							map.put("statusName", "预登记");
						}else{
							map.put("statusName", "已入库");
						}
	    			}
    			}
    			
    			//创建一个表格
    			HSSFWorkbook wb = new HSSFWorkbook();
    			String id = param.get("id").toString();
    			String workflowCode = "physical_asset_preapply";
    			//流程审批信息
    	        Instance instance = workflowEngine.getInstance(workflowCode, id);
    	        List<Object[]> instanceList = new ArrayList<Object[]>();
    	        if (instance != null) {
    	            instance.setAuditInfoList(workflowEngine.getShowAuditInfoList(instance.getInstanceId()));
    	            List<UTMap<String, Object>> maps = workflowEngine.getShowAuditInfoList(instance.getInstanceId());
    	            for(UTMap<String, Object> map2 : maps)
    	            {
    	            	Object[] objs = new Object[5];
    	    	        objs[0] = map2.get("nodeName")==null? "" : map2.get("nodeName").toString();
    	    	        objs[1] = map2.get("createUser")==null? "" : map2.get("createUser").toString();
    	    	        objs[2] = map2.get("createTime")==null? "" : map2.get("createTime").toString();
    	    	        objs[3] = map2.get("auditResult")==null? "" : map2.get("auditResult").toString();
    	    	        objs[4] = map2.get("auditComment")==null? "" : map2.get("auditComment").toString();
    	    	        instanceList.add(objs);
    	            }
    	        }
    			response.setCharacterEncoding("UTF-8");
    			response.setContentType("application/vnd.ms-excel");
    			String fileName = "资产预登记记录.xls";
    			fileName = URLEncoder.encode(fileName, "UTF-8");
    			response.addHeader("Content-Disposition", "attachment;filename=" + fileName);
    					
    			exportPhsicalRegist(wb, map, instanceList);
    			
    			try {
					OutputStream out = response.getOutputStream();
	    			wb.write(out);
	    			out.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

    		}    		    		
		}catch(Exception e){
			logger.error("Exception", e);
    	}
	}
	
	private void exportPhsicalRegist(HSSFWorkbook wb, UTMap<String, Object> map, List<Object[]> instanceList) 
	{
        String sheetName = "资产预登记";
        Object[] objs = new Object[23];
        objs[0] = map.get("name")==null? "" : map.get("name").toString();
        objs[1] = map.get("codeNum")==null? "" : map.get("codeNum").toString();
        objs[2] = map.get("categoryName")==null? "" : map.get("categoryName").toString();
        objs[3] = map.get("subCategoryName")==null? "" : map.get("subCategoryName").toString();
        objs[4] = map.get("assetsLevel")==null? "" : map.get("assetsLevel").toString();
        objs[5] = map.get("serialNum")==null? "" : map.get("serialNum").toString();
        objs[6] = map.get("model")==null? "" : map.get("model").toString();
        objs[7] = map.get("locationName")==null? "" : map.get("locationName").toString();
        objs[8] = map.get("producer")==null? "" : map.get("producer").toString();
        objs[9] = map.get("brand")==null? "" : map.get("brand").toString();
        objs[10] = map.get("auxiliaryAsset")==null? "否" : (map.get("auxiliaryAsset").toString().equals("1")?"是":"否");
        objs[11] = map.get("preAssetsClass")==null? "" : (map.get("preAssetsClass").toString().equals("1")?"预登记":"借用预登记");
        objs[12] = map.get("preBorrowAssetsStartDate")==null? "" : map.get("preBorrowAssetsStartDate").toString();
        objs[13] = map.get("preBorrowAssetsEndDate")==null? "" : map.get("preBorrowAssetsEndDate").toString();
        objs[14] = map.get("partA_name")==null? "" : map.get("partA_name").toString();
        objs[15] = map.get("partA_telephone")==null? "" : map.get("partA_telephone").toString();
        objs[16] = map.get("partB_name")==null? "" : map.get("partB_name").toString();
        objs[17] = map.get("partB_telephone")==null? "" : map.get("partB_telephone").toString();
        objs[18] = map.get("assetsUse")==null? "" : map.get("assetsUse").toString();
        objs[19] = map.get("assetPrice")==null? "" : map.get("assetPrice").toString();
        objs[20] = map.get("statusName")==null? "" : map.get("statusName").toString();
        objs[21] = map.get("remark")==null? "" : map.get("remark").toString();
        
        String[] rowsName = new String[] { "序号", "节点", "提交人", "提交时间", "审批结果", "审批意见" };
        List<Object[]> dataList = new ArrayList<Object[]>();
        String[] rowsName2 = new String[] { "资产名称", "资产编号", "资产大类", "资产小类", "资产级别", "生产商" , "型号", "存放地点", "登记状态"};
        if(map.get("auxiliaryList") != null)
        {
        	List<UTMap<String, Object>> list = (List<UTMap<String, Object>>) map.get("auxiliaryList");
        	if(list != null && list.size() > 0)
        	{
        		for(UTMap<String, Object> item : list)
        		{
        			Object[] obj2 = new Object[9];
        			obj2[0] = item.get("name")==null? "" : item.get("name").toString();
    		        obj2[1] = item.get("codeNum")==null? "" : item.get("codeNum").toString();
    		        obj2[2] = item.get("categoryName")==null? "" : item.get("categoryName").toString();
    		        obj2[3] = item.get("subCategoryName")==null? "" : item.get("subCategoryName").toString();
    		        obj2[4] = item.get("assetsLevel")==null? "" : item.get("assetsLevel").toString();
    		        obj2[5] = item.get("producer")==null? "" : item.get("producer").toString();
    		        obj2[6] = item.get("model")==null? "" : item.get("model").toString();
   		            obj2[7] = item.get("locationName")==null? "" : item.get("locationName").toString();
    		        obj2[8] = item.get("registStatus")==null? "" : (item.get("registStatus").toString().equals("1")?"预登记":"已入库");
    		        
    		        dataList.add(obj2);
        		}
        		
        	}
        }
        
        // 创建ExportExcel对象
        ExcelUtil excelUtil = new ExcelUtil();
        try{
            excelUtil.exportPhsicalRegist(sheetName, "资产预登记单", objs, wb);
            int index = 15;
            if(objs[11].equals("借用预登记"))
        		index = 16;
            if(objs[10].equals("是") && dataList.size() > 0)
            {
                excelUtil.exportPhsicalRegistAssetList(sheetName, "辅资产明细", rowsName2, dataList, wb, index, false);
                index = index + 4 + dataList.size();
            }
            excelUtil.exportAssetApplyInstance(sheetName, "流程详情", rowsName, instanceList, wb, index, false);
        }catch(Exception e){
            e.printStackTrace();
        }
	}
	
	/**
	 * 从excel导入
	 * 
	 * @param
	 * @param filePath
	 * @return
	 */
	@RequestMapping(value = "leadingin")
	@ResponseBody
	public UTMap<String, Object> leadingin(
			@RequestParam Map<String, Object> param, String filePath) {
		UTMap<String, Object> utMap = new UTMap<String, Object>();
		try {
			utMap.put("success", physicalRegistService.leadingin(filePath, param));
			utMap.put("msg", "导入成功！");
		} catch (EscServiceException e) {
			logger.error("EscServiceException",e);
			utMap.put("success", false);
			utMap.put("msg", e.getMessage());
		} catch (Exception e) {
			logger.error("EscServiceException",e);
			utMap.put("success", false);
			utMap.put("msg", "导入失败");
		}
		return utMap;
	}
	
	
	@RequestMapping(value = "leadingout")
	public void leadingout(@RequestParam Map<String, Object> param,
			HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = null;
			if(info != null) {
				jsonBean = JSONObject.fromObject(info);
			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = physicalRegistService.getListMaps(jsonBean);
			} else {
			// 根据条件 导出当前
			//if (UTExcel.EXCELOUTTYPE_NOW == outType) {
				// getpage
				physicalRegistService.getPageInfo(jsonBean, utPageBean);
				data = utPageBean.getRows();
			}
			if(null != data && data.size() > 0 ){
				for (Map<String, Object> map : data) {
					if(null != map.get("registStatus") && "1".equals(String.valueOf(map.get("registStatus")))){
						map.put("registStatus", "预登记");
					}else if(null != map.get("registStatus") && "2".equals(String.valueOf(map.get("registStatus")))){
						map.put("registStatus", "已入库");
					}
					if(null != map.get("preAssetsClass") && "1".equals(String.valueOf(map.get("preAssetsClass")))){
						map.put("preAssetsClass", "预登记");
					}else if(null != map.get("preAssetsClass") && "2".equals(String.valueOf(map.get("preAssetsClass")))){
						map.put("preAssetsClass", "借用预登记");
					}
					if(map.get("assetsLevel") != null){
						map.put(IAssetPhysicalDao.FIELD_ASSETS_LEVEL, sysParamService.getParamNameByValue("assetsLevel",(String) map.get("assetsLevel")));
					}
				}
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			physicalRegistService.leadingout(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}


}