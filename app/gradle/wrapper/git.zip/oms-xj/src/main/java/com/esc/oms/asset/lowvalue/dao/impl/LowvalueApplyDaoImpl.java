package com.esc.oms.asset.lowvalue.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.asset.lowvalue.dao.ILowvalueApplyDao;
import com.esc.oms.util.RoleUtils;
@Repository
public class LowvalueApplyDaoImpl extends BaseOptionDao implements ILowvalueApplyDao{
	
	@Override
	public String getTableName() {
		return "assets_lowvalue_apply";
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params,false), pageBean, null);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params) {
		return super.getListBySql(getSearchSql(params,false), null);
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params,boolean isGetById){
		StringBuilder sql = new StringBuilder();
		sql.append(" select apply.*,org.longName as unitName,t4.currentExecutor as auditors "
				+ " from assets_lowvalue_apply apply ");
//		sql.append(" left join sys_user receptUser on apply.receptUserId=receptUser.id ");
//		sql.append(" left join sys_user grantUser on apply.grantUserId=grantUser.id ");
		sql.append(" left join sys_org org on apply.unit=org.id ");
		sql.append(" left join sys_workflow_instance t4 on apply.workflowInstanceId=t4.id ");
		sql.append(" where 1=1 ");
		if(params!=null && params.size()>0){				
			if(params.get("nameOrCode")!=null &&  StringUtils.isNotEmpty(params.get("nameOrCode").toString())){
				sql.append(" and (apply.name like '%"+params.get("nameOrCode").toString().trim()+"%' or apply.code like '%"+params.get("nameOrCode").toString().trim()+"%')  ");
			}
			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
				sql.append(" and apply.name like '%"+params.get("name").toString().trim()+"%' ");
			}
			if(params.get("code")!=null &&  StringUtils.isNotEmpty(params.get("code").toString())){
				sql.append(" and apply.code like '%"+params.get("code").toString().trim()+"%' ");
			}
			if(params.get("startDate")!=null && StringUtils.isNotEmpty(params.get("startDate").toString())){
				sql.append(" and DATE_FORMAT(apply.applyTime,'%Y-%m-%d')>='"+params.get("startDate").toString().trim()+"' ");
			}
			if(params.get("endDate")!=null && StringUtils.isNotEmpty(params.get("endDate").toString())){
				sql.append(" and DATE_FORMAT(apply.applyTime,'%Y-%m-%d')<='"+params.get("endDate").toString().trim()+"' ");
			}
		}		
		//数据权限控制
		if(!RoleUtils.isAssetManager()&&!RoleUtils.isSystemAdministrator()){
			String userId = EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId();
			String userType = EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserType();
			if("1".equals(userType)){//普通金融机构用户，只查看自己申请的记录
				sql.append(" and apply.applyUserId='"+userId+"' ");
			}				
		}
		sql.append(" order by apply.createTime desc");
		return  sql.toString();
	}

	@Override
	public void getPendApprovalPageInfo(UTPageBean pageBean,
			Map<String, Object> params) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select apply.*,org.longName as unitName,t4.currentExecutor as auditors,t4.currentStepName "
				+ " from assets_lowvalue_apply apply ");
		sql.append(" left join sys_org org on apply.unit=org.id ");
		sql.append(" left join sys_workflow_instance t4 on apply.workflowInstanceId=t4.id ");
		sql.append(" where FIND_IN_SET('"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"',t4.currentExecutor) ");
		if(params!=null && params.size()>0){	
			if(params.get("nameOrCode")!=null &&  StringUtils.isNotEmpty(params.get("nameOrCode").toString())){
				sql.append(" and (apply.name like '%"+params.get("nameOrCode").toString().trim()+"%' or apply.code like '%"+params.get("nameOrCode").toString().trim()+"%')  ");
			}
			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
				sql.append(" and apply.name like '%"+params.get("name").toString().trim()+"%' ");
			}
			if(params.get("code")!=null &&  StringUtils.isNotEmpty(params.get("code").toString())){
				sql.append(" and apply.code like '%"+params.get("code").toString().trim()+"%' ");
			}
			if(params.get("startDate")!=null && StringUtils.isNotEmpty(params.get("startDate").toString())){
				sql.append(" and DATE_FORMAT(apply.applyTime,'%Y-%m-%d')>='"+params.get("startDate").toString().trim()+"' ");
			}
			if(params.get("endDate")!=null && StringUtils.isNotEmpty(params.get("endDate").toString())){
				sql.append(" and DATE_FORMAT(apply.applyTime,'%Y-%m-%d')<='"+params.get("endDate").toString().trim()+"' ");
			}
		}
		sql.append(" order by apply.updateTime desc " );
		super.getPageListMapBySql(sql.toString(), pageBean, null);		
	}

	@Override
	public void getAlreadyApprovalPageInfo(UTPageBean pageBean,
			Map<String, Object> params) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select DISTINCT(apply.id) as applyId,apply.*,org.longName as unitName "
				+ " from assets_lowvalue_apply apply ");
		sql.append(" left join sys_org org on apply.unit=org.id ");
		sql.append(" left join sys_workflow_audit_history t4 on apply.workflowInstanceId=t4.instanceId ");
		sql.append(" where FIND_IN_SET('"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"',t4.optionUserId) " );
		sql.append(" and t4.nodeName!='开始' " );//屏蔽开始节点
		if(params!=null && params.size()>0){	
			if(params.get("nameOrCode")!=null &&  StringUtils.isNotEmpty(params.get("nameOrCode").toString())){
				sql.append(" and (apply.name like '%"+params.get("nameOrCode").toString().trim()+"%' or apply.code like '%"+params.get("nameOrCode").toString().trim()+"%')  ");
			}
			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
				sql.append(" and apply.name like '%"+params.get("name").toString().trim()+"%' ");
			}
			if(params.get("code")!=null &&  StringUtils.isNotEmpty(params.get("code").toString())){
				sql.append(" and apply.code like '%"+params.get("code").toString().trim()+"%' ");
			}
			if(params.get("startDate")!=null && StringUtils.isNotEmpty(params.get("startDate").toString())){
				sql.append(" and DATE_FORMAT(apply.applyTime,'%Y-%m-%d')>='"+params.get("startDate").toString().trim()+"' ");
			}
			if(params.get("endDate")!=null && StringUtils.isNotEmpty(params.get("endDate").toString())){
				sql.append(" and DATE_FORMAT(apply.applyTime,'%Y-%m-%d')<='"+params.get("endDate").toString().trim()+"' ");
			}
		}
		sql.append(" order by apply.createTime desc " );
		super.getPageListMapBySql(sql.toString(), pageBean, null);
	}
}
