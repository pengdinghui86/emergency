package com.esc.oms.outsource.outperson.controller;

import com.esc.oms.outsource.outperson.service.IApplyCommonService;
import net.sf.json.JSONObject;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;
import com.esc.oms.util.CommonUtils;

/**
 * 抽象类
 * 外包人员 申请 公用controller
 * @author smq
 * @date   2016-7-9 下午4:17:21
 */
public abstract class AbstractApplyController extends  BaseOptionController {

	public abstract IApplyCommonService applyService();
	
	@Override
	public IBaseOptionService optionService() {
		return applyService();
	}

	@RequestMapping("searchInfoPage")
	@ResponseBody
	public UTPageBean search(@RequestParam Map<String, Object> params, UTPageBean pageBean) {
		applyService().searchInfoPage(pageBean, params);
		return pageBean;
	}
	
	@RequestMapping("getPendApprovalPageInfo")
	@ResponseBody
	public UTPageBean getPendApprovalPageInfo(@RequestParam 
			Map<String, Object> params,UTPageBean pageBean) {
		applyService().getPendApprovalPageInfo(pageBean, params);
		return pageBean;
	}
	
	@RequestMapping("getAlreadyApprovalPageInfo")
	@ResponseBody
	public UTPageBean getAlreadyApprovalPageInfo(@RequestParam 
			Map<String, Object> params,UTPageBean pageBean) {
		applyService().getAlreadyApprovalPageInfo(pageBean, params);
		return pageBean;
	}
	

	@RequestMapping(value="save", method=RequestMethod.POST)  
    @ResponseBody
    public String save(@RequestBody Map<String,Object> map1) {
		Map<String,Object> cloneMap = CommonUtils.clone(map1);
		boolean flog=true;
		String msg="";
		try {
			if(cloneMap.get("id") == null){
				flog=optionService().add(cloneMap);
	    	}
			else{
				flog=	optionService().updateById(cloneMap);
	    	}
			msg=flog?"操作成功":"操作失败";
			if(flog){
				return UTJsonUtils.getJsonMsg(true, msg, cloneMap.get("id").toString());
			}else{
				return UTJsonUtils.getJsonMsg(false, msg);
			}
		}
		catch (Exception e) {
			logger.error("Exception",e);
			return UTJsonUtils.getJsonMsg(false, e.getMessage());
		}
	}

	@RequestMapping(value="submit", method=RequestMethod.POST)  
    @ResponseBody
    public String submit(@RequestBody Map<String,Object> map) {
		try {
			applyService().submit(map);
			return UTJsonUtils.getJsonMsg(true, "操作成功");
		}
		catch (Exception e) {
			logger.error("Exception",e);
			return UTJsonUtils.getJsonMsg(false, e.getMessage());
		}
	}

	@RequestMapping(value = "exportData")
	public void exportData(@RequestParam Map<String, Object> param, UTPageBean pageBean, 
			HttpServletRequest request, HttpServletResponse response) {
		try {
			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = JSONObject.fromObject(info);

			List<UTMap<String, Object>> recordList;
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {	// 导出全部
				recordList = applyService().searchInfo(jsonBean);
			} else {	// 导出当前页面
				applyService().searchInfoPage(pageBean, jsonBean);
				recordList =pageBean.getRows();
			}
			
			response.setCharacterEncoding("UTF-8");
			applyService().exportData(recordList, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}
}
