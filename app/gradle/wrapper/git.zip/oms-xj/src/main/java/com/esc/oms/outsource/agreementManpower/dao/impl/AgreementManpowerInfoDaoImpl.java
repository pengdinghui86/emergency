package com.esc.oms.outsource.agreementManpower.dao.impl;

import com.esc.oms.outsource.agreementManpower.dao.IAgreementManpowerInfoDao;
import com.esc.oms.outsource.outperson.dao.IOutSourcePersonDao;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 人力外包合同 配置
 * @author smq
 * @date   2016-2-24 上午10:50:04
 */
@Repository
public class AgreementManpowerInfoDaoImpl extends BaseOptionDao implements   IAgreementManpowerInfoDao{

	@Override
	public String getTableName() {
		return "agreement_manpower_info";
	}
	
	public UTMap<String, Object> getById(String id){
		Map<String, Object> param=new HashMap<String, Object>();
		param.put(IOutSourcePersonDao.FIELD_ID,id);
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT  ");
		sql.append(" ami.id,ami.agreementId,ami.agreementCode,ami.agreementName,ami.amBegin,ami.amEnd, ");
		sql.append(" ami.deductionsCycle ,ami.deductionsRate,ami.overtimeHoliday,ami.overtimeWeekend,ami.overtimeWeekday,ami.pmBegin,ami.pmEnd, ");
		sql.append(" ami.trialPeriod,ami.updateUserId,ami.updateTime, ");
		sql.append(" ai.endTime, ai.beginTime,ai.supplierId,ai.supplierName,ai.submitUser,ai.submitTime,	u.`name` submitUserName  ");
		sql.append("  from agreement_manpower_info ami ");
		sql.append(" LEFT JOIN agreement_info ai ON ami.agreementId=ai.id ");
		sql.append(" LEFT JOIN sys_user u ON u.id = ai.submitUser ");
		sql.append(" where ami.id='"+id+"'");
		return super.getOneBySql(sql.toString(), null);
	}
	
	/**
	 * 根据用户编号获取外包合同
	 * @param userId
	 * @return
	 */
	public UTMap<String, Object> getByUserId(String userId){
		StringBuilder sql=new StringBuilder();
		sql.append(" select ami.* from agreement_manpower_info ami ");
		sql.append(" left join outsource_person_list opl on opl.agreementId = ami.agreementId ");
		sql.append(" where opl.userId = '"+userId+"' ");
		return super.getOneBySql(sql.toString(), null);
	}
	
	public UTMap<String, Object> getByAgreementId(String agreementId){
		Map<String, Object> param=new HashMap<String, Object>();
		param.put(IOutSourcePersonDao.FIELD_AGREEMENTID,agreementId);
		String sql=getSearchSql(param);
		return super.getOneBySql(sql, null);
	}
	
	public List<UTMap<String, Object>> getListMaps(Map param) {
		String sql=getSearchSql(param);
		return super.getListBySql(sql, null);
	}

	public void getPageInfo(UTPageBean pageBean,Map param){
		String sql=getSearchSql(param);
		 super.getPageListMapBySql(sql,pageBean, null);
	}

	private String getSearchSql(Map<String, Object> param){
		Map<String, String> p=UTMap.mapObjToString(param);
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT  ");
		sql.append(" ami.id,ami.agreementId,ami.agreementCode,ami.agreementName,ami.createTime,ami.createUser,ami.createUserId, ");
		sql.append(" ai.endTime, ai.beginTime,ai.supplierId,ai.supplierName,ai.submitUser,ai.submitTime,ai.status ");
		sql.append("  from agreement_manpower_info ami ");
		sql.append("  JOIN agreement_info ai ON ami.agreementId=ai.id  ");
		sql.append(" WHERE 1=1  and ai.isManpower=1 ");
				
		String id=p.get(IAgreementManpowerInfoDao.FIELD_ID); 
		String agreementName=p.get(IAgreementManpowerInfoDao.FIELD_AGREEMENTNAME);
		String agreementCode=p.get(IAgreementManpowerInfoDao.FIELD_AGREEMENTCODE);
		String agreementId=p.get(IAgreementManpowerInfoDao.FIELD_AGREEMENTID);
		String supplierName=p.get("supplierName");
		String supplierId=p.get("supplierId");
		String createUserId=p.get("createUserId");
		String isClose=p.get("isClose");
		String status = p.get("status");
		
		if (StringUtils.isNotEmpty(id)) {
			sql.append(" and ami.id='"+id+"'");
		}
		if (StringUtils.isNotEmpty(isClose)) {
			sql.append(" and (ai.`status`<>5 and ai.`status`<>6 )  ");
		}
		if (StringUtils.isNotEmpty(agreementId)) {
			sql.append(" and ami.agreementId = '"+agreementId+"'");
		}
		if (StringUtils.isNotEmpty(agreementName)) {
			sql.append(" and ami.agreementName like '%"+agreementName+"%'");
		}
		if (StringUtils.isNotEmpty(agreementCode)) {
			sql.append(" and ami.agreementCode='"+agreementCode+"'");
		}
		if (StringUtils.isNotEmpty(createUserId)) {
			sql.append(" and ami.createUserId='"+createUserId+"'");
		}

		if (StringUtils.isNotEmpty(supplierId)) {
			sql.append(" and  ai.supplierId='"+supplierId+"' ");
		}
		
		if ( supplierName!=null&&StringUtils.isNotEmpty( supplierName)) {
			sql.append(" and  ai. supplierName like '%"+ supplierName+"%' ");
		}

		if(status != null && StringUtils.isNotEmpty(status)){
			sql.append(" and ai.status='"+status+"' ");
		}
		sql.append(" ORDER BY ami.createTime desc , (ami.agreementCode+0) ");
		
		return sql.toString();
	}

	//获取 所有未进行配置的人力外包合同
	@Override
	public List<UTMap<String, Object>> getAgreementManpowerNoConfig() {
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT ai.id,ai.`code`, ai.`name`,ai.endTime, ai.beginTime,ai.supplierId,ai.supplierName,ai.submitUser,ai.submitTime,u.`name` submitUserName ");
		sql.append("from  agreement_info  ai ");
		sql.append(" LEFT JOIN agreement_manpower_info ami on ai.id =ami.agreementId ");
		sql.append(" LEFT JOIN sys_user u ON u.id=ai.submitUser "); 
		sql.append(" where  (ai.`status`<>5 and ai.`status`<>6 )  and ami.agreementId is NULL and ai.isManpower=1   and ai.deleteFlag<>1 ");
		return super.getListBySql(sql.toString(), null);
	} 

	//判断合同费用配置是否存在
	public List<UTMap<String, Object>> getAgreementCostConfig(Map<String, Object> param) {
		Map<String, String> p=UTMap.mapObjToString(param);
		StringBuilder sql=new StringBuilder();
	
		sql.append(" select agi.id manpowerId, ai.supplierId supplierId,   agi.agreementCode,agi.agreementId,agi.agreementName,agcc.category,agcc.`level`,agcc.monthlyFee from agreement_manpower_info agi ");
		sql.append("		 LEFT JOIN agreement_manpower_cost_config agcc on agi.id=agcc.manpowerId ");
		sql.append("	 LEFT JOIN agreement_info ai on agi.agreementId= ai.id  ");
		sql.append(" where 1=1 ");
		

		String agreementName=p.get(IAgreementManpowerInfoDao.FIELD_AGREEMENTNAME);
		String agreementCode=p.get(IAgreementManpowerInfoDao.FIELD_AGREEMENTCODE);
		String agreementId=p.get(IAgreementManpowerInfoDao.FIELD_AGREEMENTID);
		String manpowerId=p.get("manpowerId"); 
		String level=p.get("level");
		String category=p.get("category");
		String supplierId=p.get("supplierId");

		if (StringUtils.isNotEmpty(manpowerId)) {
			sql.append(" and agi.id='"+manpowerId+"'");
		}
		if (StringUtils.isNotEmpty(supplierId)) {
			sql.append(" and ai.supplierId='"+supplierId+"'");
		}
		if (StringUtils.isNotEmpty(agreementCode)) {
			sql.append(" and agi.agreementCode='"+agreementCode+"'");
		}
		
		if (StringUtils.isNotEmpty(agreementName)) {
			sql.append(" and agi.agreementName='"+agreementName+"'");
		}
		
		if (StringUtils.isNotEmpty(agreementId)) {
			sql.append(" and agi.agreementId='"+agreementId+"'");
		}
		
		if (StringUtils.isNotEmpty(level)) {
			sql.append(" and agcc.level='"+level+"'");
		}
		
		if (StringUtils.isNotEmpty(category)) {
			sql.append(" and agcc.category='"+category+"'");
		}
		
		sql.append(" order by agcc.createTime asc ");
		
		return super.getListBySql(sql.toString(), null);
	}
	
	
	
	

	
}
