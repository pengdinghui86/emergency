package com.esc.oms.asset.borrow.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

public interface IAssetBorrowDao extends IBaseOptionDao{
	
	public boolean addAssetAllocation(Map info);
	
	public boolean deleteAssetAllocationById(String id);
	
	public List<UTMap<String, Object>> getAssetAllocationListMaps(Map param) ;
	
	public boolean updateAllocationStatusById(String id,String status);
	
	public void getAssetAllocationPageInfo(UTPageBean pageBean,Map param);
	
	public boolean deleteAssetAllocationByBorrowId(String id);
	
	public UTMap<String, Object> getAssetBorrowById(String id);
	
	public List<UTMap<String,Object>> getRemindBorrowsList();
	
	public List<UTMap<String,Object>> getBorrowsReturnList();
	
	public boolean updateAllocationStatusByBorrowId(String borrowId,String status);
	
	public List<UTMap<String,Object>> getBorrowDetailByIdAndStatus(String borrowId);
	
	public List<UTMap<String,Object>> getBorrowDetailByIds(String ids);
	
	public List<UTMap<String, Object>> getBorrowByStatusList(String assetId);

	public boolean updateAssetAllocation(Map<String, Object> param);

	public void getAssetsList(Map<String, Object> params, UTPageBean pageBean);

	public void getAssetAllocationPage(Map<String, Object> param, UTPageBean pageBean);
}
