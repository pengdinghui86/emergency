package com.esc.oms.outsource.outperson.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.outperson.dao.IOutSourcePersonChangeDao;


/**
 * 外包人员更改记录
 * @author jane
 *
 */
@Repository
public class OutSourcePersonChangeDaoImpl extends BaseOptionDao implements IOutSourcePersonChangeDao {

	@Override
	public String getTableName() {
		return "outsource_person_change";
	}
	
	@Override
	public UTMap<String, Object> getById(String id) {
		Map params = new HashMap();
		params.put("id", id);
		return this.getOneBySql(getSearchSql(params), null);
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean,Map params){
		super.getPageListMapBySql(getSearchSql(params), pageBean, null);
	}
	
	@Override
	public List<UTMap<String, Object>> getListMaps(Map params) {
		return super.getListBySql(getSearchSql(params));
	}
	
	private String getSearchSql(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT tb.*,sbi.`name` supplierName, CONCAT(su1.`name`,'/',su1.code) changeUserName,so.`longName` detPartName " );
		sql.append(" FROM outsource_person_change tb ");
		sql.append(" LEFT JOIN supplier_base_info sbi ON sbi.id = tb.supplierId ");
		sql.append(" LEFT JOIN sys_user su1 ON su1.id = tb.changeUserId ");
		sql.append(" LEFT JOIN sys_org so ON so.id = tb.changeAfter ");
		sql.append(" where 1=1 ");
		if(params!=null && params.size()>0){
			if(params.get("id")!=null &&  StringUtils.isNotEmpty(params.get("id").toString())){
				sql.append(" and tb.id = '"+params.get("id")+"' ");
			}
			if(params.get("supplierId")!=null &&  StringUtils.isNotEmpty(params.get("supplierId").toString())){
				sql.append(" and sbi.name like '%"+params.get("supplierId").toString().trim()+"%' ");
			}
			if(params.get("changePerson")!=null &&  StringUtils.isNotEmpty(params.get("changePerson").toString())){
//				sql.append(" and opl.`name` like '%"+params.get("changePerson").toString().trim()+"%' ");
				sql.append(" and CONCAT(su1.`name`,'/',su1.code) like '%"+params.get("changePerson").toString().trim()+"%' ");
			}
			if(params.get("changeType")!=null &&  StringUtils.isNotEmpty(params.get("changeType").toString())){
				sql.append(" and tb.changeType = '"+params.get("changeType").toString().trim()+"' ");
			}
			if(params.get("beginDate")!=null && StringUtils.isNotEmpty(params.get("beginDate").toString())){
				sql.append(" AND tb.beginDate = date_format(NOW(),'%Y-%m-%d') ");
			}
		}
		sql.append(" order by tb.createTime desc");
		return  sql.toString();
	}
	
	private String getLevelsByUserIdSearchSql(String userId){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT amcc.`level` ,IfNull(amcc.monthlyFee ,0) monthlyFee " );
		sql.append(" FROM outsource_person_list opl " );
		sql.append(" LEFT JOIN agreement_manpower_info ami ON ami.agreementId = opl.agreementId ");
		sql.append(" LEFT JOIN agreement_manpower_cost_config amcc ON amcc.manpowerId = ami.id ");
		sql.append(" WHERE opl.userId = '"+userId+"' AND amcc.category = opl.category ");
		return  sql.toString();
	}

	@Override
	public List<UTMap<String, Object>> getLevelsByUserId(String userId) {
		return super.getListBySql(getLevelsByUserIdSearchSql(userId));
	}
}
