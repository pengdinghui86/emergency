package com.esc.oms.outsource.grouporg.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.esc.framework.security.service.IOrgMemberService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.outsource.emergency.service.IEmerGroupDefineService;
import com.esc.oms.outsource.group.service.IGroupDefineService;
import com.esc.oms.outsource.grouporg.service.IGroupOrgService;

/**
 * 组织结构 管理controller
 * 主要用于
 * 外包组织结构配置
 * 外包应急组织结构配置
 * @author smq
 * @date   2016-2-15 上午10:29:26
 */
@Controller
@RequestMapping("groupOrg")
public class GroupOrgController {
	
	@Resource
	private IGroupOrgService groupOrgService;

	@Resource
	private IGroupDefineService groupDefineService;

	@Resource
	private IEmerGroupDefineService emerGroupDefineService;
	
	@Resource
	private IOrgMemberService orgMemberService;
	
	/**
	 * 保存
	 * @param param
	 * @return
	 */
	@RequestMapping("saveGroupOrg")
	@ResponseBody
	public String saveGroupOrg(@RequestBody Map<String, Object> param){
		//groupOrgType[1.外包组织管理架构，2.外包应急架构]
		int groupOrgType = Integer.valueOf(param.get("groupOrgType").toString());
		String jsonString = (String)param.get("jsonString");
		List<Map<String, Object>> list = parseEmergencyGroupData(jsonString);
		boolean flog=groupOrgService.saveGroupOrgAndUser(list,groupOrgType);
		return UTJsonUtils.getJsonMsg(flog, flog?"操作成功！":"操作失败！");
	}

	/**
	 * 获取 组织结构
	 * */
	@RequestMapping("getGroupOrg")
	@ResponseBody
	public Map<String, Object> getGroupOrg(@RequestParam Map<String, Object> param){
		//groupOrgType[1.外包组织管理架构，2.外包应急架构]
		int groupOrgType = Integer.valueOf(param.get("groupOrgType").toString());
		if(groupOrgType==1){
			return	getGLGroupOrg(param, groupOrgType);
		}else{
			return getEmerGroupOrg(param, groupOrgType);
		}
	}
	
	
	@RequestMapping("getGroupOrgShow")
	@ResponseBody
	public Map<String, Object> getGroupOrgShow(@RequestParam Map<String, Object> param){
		//groupOrgType[1.外包组织管理架构，2.外包应急架构]
		int groupOrgType = Integer.valueOf(param.get("groupOrgType").toString());
		Map<String, Object> map = new HashMap<String, Object>();
		//获取所有组织结构
		map.put("precautionGroupListJson",groupOrgService.getGroupOrgAndUser(groupOrgType));
		return map;
	}
	/**
	 * 将页面传过来的json数据转换成List
	 * @param jsonString
	 * @return
	 */
	public static List<Map<String, Object>> parseEmergencyGroupData(String jsonString) {
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
	//	int sort=0;
		JSONArray jsonArray = JSONArray.fromObject(jsonString);
		for (int i = 0; i < jsonArray.size(); i++) {
			Map<String, Object> map = new HashMap<String, Object>();
			JSONObject jsonObject = jsonArray.getJSONObject(i);
			String groupId=jsonObject.getString("id").substring(6);
			map.put("groupId",groupId );  // 将ID前面的"group-" 6个字符去掉
			map.put("sort",i);
			String parentId = jsonObject.getString("parentId");
			if (parentId.equals("null")|| parentId.substring(6).equals("null")) {
				map.put("parentId", null);
			}
			else {
				map.put("parentId", parentId.substring(6));
			}
			
			if(jsonObject.containsKey("users")){
				JSONArray users = jsonObject.getJSONArray("users");
				List<Map<String, Object>> userList = new ArrayList<Map<String, Object>>();
				for (int j = 0; j < users.size(); j++) {
					JSONObject user = users.getJSONObject(j);
					
					Map<String, Object> userMap = new HashMap<String, Object>();
					userMap.put("groupPost", user.getString("role"));
					userMap.put("groupId", groupId);
					userMap.put("userId",  user.getString("id"));
					
					userList.add(userMap);
				}
				map.put("users", userList);
			}
			list.add(map);
		}
		
		return list;
	}

	/**
	 * 获取 外包管理组织结构
	 * */
	private Map<String, Object>  getGLGroupOrg(Map<String, Object> param,int groupOrgType){
		List<UTMap<String, Object>> groupsList=groupDefineService.getListMaps(param);
		for (UTMap<String, Object> utMap : groupsList) {
			utMap.put("name",utMap.get("groupName"));
			utMap.remove("groupName");
		}
		Map<String, Object> map = new HashMap<String, Object>();
		//获取所有小组
		map.put("groupListJson",groupsList); 
		//获取所有组织结构
		map.put("precautionGroupListJson",groupOrgService.getGroupOrgAndUser(groupOrgType));
		//获取 所有组织内人员
		map.put("contactsJson",orgMemberService.getOrgInsideUser(false)); 
		return map;
	}
	
	
	/**
	 * 获取 应急组织结构
	 * */
	private Map<String, Object>getEmerGroupOrg( Map<String, Object> param ,int groupOrgType){

		List<UTMap<String, Object>> groupsList=emerGroupDefineService.getListMaps(param);
		for (UTMap<String, Object> utMap : groupsList) {
			utMap.put("name",utMap.get("groupName"));
			utMap.remove("groupName");
		}
		
		Map<String, Object> map = new HashMap<String, Object>();
		//获取所有小组
		map.put("groupListJson",groupsList); 
		//获取所有组织结构
		map.put("precautionGroupListJson",groupOrgService.getGroupOrgAndUser(groupOrgType ));
		//获取 所有组织内人员
		map.put("contactsJson",orgMemberService.getOrgInsideUser(false)); 
		return map;
	}
	
}
