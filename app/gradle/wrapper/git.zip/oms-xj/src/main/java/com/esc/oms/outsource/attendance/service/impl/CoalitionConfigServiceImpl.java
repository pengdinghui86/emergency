package com.esc.oms.outsource.attendance.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.exception.EscServiceException;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.dao.ISysUserDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.utils.UTMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.attendance.dao.ICoalitionConfigDao;
import com.esc.oms.outsource.attendance.service.ICoalitionConfigService;
import com.esc.oms.outsource.attendance.service.IUserConfigService;
import com.esc.oms.outsource.outperson.dao.IOutSourcePersonConfigDao;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;


/**
 * 联合考勤规则配置Service
 * @author owner
 *
 */
@Service
@Transactional
public class CoalitionConfigServiceImpl  extends BaseOptionService implements  ICoalitionConfigService {
	private static final Logger logger = LoggerFactory.getLogger(CoalitionConfigServiceImpl.class);
	
	@Resource
	private ICoalitionConfigDao coalitionConfigDao;
	
//	@Resource
//	private IUserConfigDao userConfigDao;
	
	@Resource
	private IUserConfigService userConfigService;
	
	@Resource
	private ISysUserDao sysUserDao;
	
	@Resource
	private IOutSourcePersonConfigDao personConfigDao;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return coalitionConfigDao;
	}
	@Override
	public UTMap<String, Object> getById(String id) {
		UTMap<String, Object> info = super.getById(id);
		info.put("oldUserIds", info.get("userIds"));
		return info;
	}
	
	@Override
	@EscOptionLog(module=SystemModule.coalitionConfig, opType=ESCLogOpType.INSERT, table="attendance_coalition_config", option="新增用户联合考勤规则{name}")
	public boolean add(Map info) {
		
		Map param = new HashMap();
		param.put("name", info.get("name"));
		param.put("deleteFlag", 0);
		if(coalitionConfigDao.isExist(param)){
			throw new EscServiceException("联合考勤'"+info.get("name")+"'已经存在！");
		}
		param.clear();
		String[] userIdArr = info.get("userIds").toString().split(",");
		for(int i = 0 ; i < userIdArr.length ; i ++){
			String userId = userIdArr[i];
			// 检查用户是否已经配置联合考勤
			String name = coalitionConfigDao.checkCoalitionConfig(userId,null);
			if(name != null){
				UTMap<String, Object> user = sysUserDao.getById(userId);
				throw new EscServiceException("联合考勤'"+name+"'下已经配置用户'"+user.get("name")+"/"+user.get("code")+"'！");
			}
		}
		info.put("deleteFlag", 0);//逻辑删除标识,0:未删除，1已删除
		//新增联合考勤配置
		super.add(info);
		saveOrUpdateUserConfig(userIdArr,info);
		return true;
	}
	
	@Override
	@EscOptionLog(module = SystemModule.coalitionConfig, opType = ESCLogOpType.UPDATE, table = "attendance_coalition_config", option = "修改用户联合考勤规则{name}。")
	public boolean updateById(Map info) {
		Map param = new HashMap();
		String id = info.get("id").toString();
		String[] oldUserIdArr = info.get("oldUserIds").toString().split(",");//修改前
		String[] userIdArr = info.get("userIds").toString().split(",");//修改后
		for(int i = 0 ; i < userIdArr.length ; i ++){
			String userId = userIdArr[i];
			// 检查用户是否已经配置联合考勤
			String name = coalitionConfigDao.checkCoalitionConfig(userId,id);
			if(name != null){
				UTMap<String, Object> user = sysUserDao.getById(userId);
				throw new EscServiceException("联合考勤'"+name+"'下已经配置用户'"+user.get("name")+"/"+user.get("code")+"'！");
			}
		}
		//修改联合考勤规则
		super.updateById(info);
		//获取已经被删除的用户id
		List<String> differentList = CommonUtils.different(userIdArr,oldUserIdArr);
		for (String userId : differentList) {
			userConfigService.deleteByUserId(userId);
		}
		saveOrUpdateUserConfig(userIdArr,info);
		return true;
	}
	
	@Override
	@EscOptionLog(module = SystemModule.coalitionConfig, opType = ESCLogOpType.DELETE,primaryKey="id={1}" , table = "attendance_coalition_config", option = "删除用户联合考勤规则{name}。")
	public boolean deleteById(String id) {
		Map<String, Object> coalitionConfigMap = this.getById(id);
		String[] userIdArr = coalitionConfigMap.get("userIds").toString().split(",");
		
		
//		userConfigService.deleteByCoalitionId(id);
		for(int i = 0 ; i < userIdArr.length ; i ++){
			//删除用户考勤规则
			userConfigService.deleteByUserId(userIdArr[i]);
			Map<String, Object> personConfigParam=new HashMap<String, Object>();
			personConfigParam.put("userId", userIdArr[i]);
			personConfigParam.put("isConfig", 0);
			personConfigDao.updates(personConfigParam, "userId");
		}
		coalitionConfigMap.put("deleteFlag", 1);//逻辑删除标识,0:未删除，1已删除
		return super.updateById(coalitionConfigMap);
	}
	
	/**
	 * 新增或修改用户考勤配置
	 * @param userIdArr
	 * @param info
	 */
	private void saveOrUpdateUserConfig(String[] userIdArr,Map info){
		for(int i = 0 ; i < userIdArr.length ; i ++){
			String userId = userIdArr[i];
			UTMap<String, Object> userConfigMap = userConfigService.getUserConfigByUserId(userId);
			if(userConfigMap != null){//存在则修改
				userConfigMap.put("attendancCount", info.get("attendancCount"));
				userConfigMap.put("attendancSum", info.get("attendancSum"));
				userConfigMap.put("attendanceCycle", info.get("attendanceCycle"));
				userConfigMap.put("attendanceDate", info.get("attendanceDate"));
				userConfigMap.put("attendanceDateType", info.get("attendanceDateType"));
				userConfigMap.put("attendanceType", info.get("attendanceType"));
				userConfigMap.put("beginDate", info.get("beginDate"));
				userConfigMap.put("amBegin", info.get("amBegin"));
				userConfigMap.put("amEnd", info.get("amEnd"));
				userConfigMap.put("pmBegin", info.get("pmBegin"));
				userConfigMap.put("pmEnd", info.get("pmEnd"));
				userConfigMap.put("endDate", info.get("endDate"));
				userConfigMap.put("supplierId", info.get("supplierId"));
				userConfigMap.put("coalitionId", info.get("id"));
				userConfigService.updateById(userConfigMap);
			}else{//不存在就新增
				Map<String, Object> configMap = new HashMap<String, Object>();  
				configMap.putAll(info);  
				configMap.remove("id");
//				String id = info.get("id").toString();
				configMap.put("coalitionId", info.get("id"));//联合考勤编号
				
				configMap.put("userId", userId);
				//新增用户考勤配置
				userConfigService.add(configMap);
			}
		}
	}


}
