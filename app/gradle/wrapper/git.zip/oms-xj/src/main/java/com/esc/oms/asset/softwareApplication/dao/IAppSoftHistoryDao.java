package com.esc.oms.asset.softwareApplication.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

public interface IAppSoftHistoryDao extends IBaseOptionDao{
	
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_SOFTWAREID = "softwareId";
	public static final String  FIELD_SOFTWARENAME = "softwareName";
//	public static final String  FIELD_CATEGORY = "category";
//	public static final String  FIELD_SHORTNAME = "shortName";
//	public static final String  FIELD_SUPPLIERID = "supplierId";
	public static final String  FIELD_VERSION = "version";
	public static final String  FIELD_WEBSITE = "website";
	public static final String  FIELD_CHARGEID = "chargeId";
	public static final String  FIELD_CHARGENUMBER = "chargeNumber";
	public static final String  FIELD_USEDEPARTIDS = "useDepartIds";
//	public static final String  FIELD_USERNUM = "userNum";
//	public static final String  FIELD_MAINTENANCE = "maintenance";
//	public static final String  FIELD_MAINTVALIDITY = "maintValidity";
//	public static final String  FIELD_SERVPERIOD = "servPeriod";
//	public static final String  FIELD_BEGINDATE = "beginDate";
//	public static final String  FIELD_ENDDATE = "endDate";
//	public static final String  FIELD_ISSAFECONTROL = "isSafeControl";
//	public static final String  FIELD_INFRASTRUCTURE = "infrastructure";
//	public static final String  FIELD_INTELLPROPERTY = "intellProperty";
//	public static final String  FIELD_LICENSECOUNT = "licenseCount";
	public static final String  FIELD_INTRODUCATION = "introducation";
	public static final String  FIELD_STATUS = "status";
	public static final String  FIELD_CREATEUSERID = "createUserId";
	public static final String  FIELD_CREATETIME = "createTime";
	public static final String  FIELD_OPERATION = "operation";
	
	
	public List<UTMap<String, Object>> getHistoryListBySoftId(Map param);


	public List<UTMap<String, Object>> getHistoryListByDisableDate(Map param);
	
}
