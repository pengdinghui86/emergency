package com.esc.oms.asset.physicalRegist.service.impl;

import com.esc.oms.asset.physicalRegist.service.IPhysicalRegistService;
import com.esc.oms.util.TaskModel;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.workflow.service.IWorkflowCallback;
import org.esc.framework.workflow.service.IWorkflowCode;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class PhysicalRegistWorkFlowCallback implements IWorkflowCallback {

	@Resource
	private IPhysicalRegistService physicalRegistService;
	
	@Resource
	private IUserTaskService userTaskService;
	/**
	 * 回调方法。
	 * 流程完成时，业务上需要进行的相应操作。
	 * @param businessRecordId
	 */
	@Override
	public void onFinish(String businessRecordId) {
		physicalRegistService.finishAudit(businessRecordId);
	}

	@Override
	public void onReject(String businessRecordId) {
		physicalRegistService.rejectAudit(businessRecordId);
	}

	@Override
	public void onTerminate(String businessRecordId) {
		physicalRegistService.terminateAudit(businessRecordId);
	}

	@Override
	public void optionNode(String workflowCode, String businessRecordId,String nodeName, String linkName) {
		physicalRegistService.optionNode(workflowCode, businessRecordId, nodeName, linkName);
	}

	@Override
	public void sendTask(String workflowName, String businessRecordId,String nodeName, String userId) {
		UTMap<String, Object> utMap = physicalRegistService.getById(businessRecordId);
		
		String content = "资产【"+utMap.get("name").toString()+"】预登记申请待您审批";
		
		userTaskService.addTaskByUserId(content, businessRecordId, nodeName, TaskModel.physicalRegistApply, userId);
	}

	@Override
	public String workflowCode() {
		return IWorkflowCode.PHYSICAL_ASSET_PREAPPLY;
	}

}
