package com.esc.oms.outsource.external.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.upload.annotation.UploadQueryMarks;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.external.dao.IExternalEvaluateConfigurationDao;
import com.esc.oms.outsource.external.dao.IExternalEvaluateTemplateDao;
import com.esc.oms.outsource.external.dao.IExternalResultEvaluateDao;
import com.esc.oms.outsource.external.service.IExternalEvaluateService;
import com.esc.oms.outsource.external.service.IExternalResultEvaluateService;
import com.esc.oms.supplier.info.service.ISupplierBaseInfoService;
import com.esc.oms.system.evaluateSetting.dao.IEvaluateSettingDao;
import com.esc.oms.system.templateconfiguration.dao.ITemplateConfigurationDetailDao;
import com.esc.oms.system.templateconfiguration.dao.ITemplateConfigurationDetailDeputyResultDao;
import com.esc.oms.system.templateconfiguration.service.ITemplateConfigurationDetailDeputyService;
import com.esc.oms.util.CommonUtils;

/**
 * 非驻场外包结果评估
 * @author owner
 *
 */
@Service
@Transactional
public class ExternalResultEvaluateServiceImpl extends BaseOptionService implements IExternalResultEvaluateService{
	
	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private IExternalResultEvaluateDao dao;
	
	@Resource
	private IExternalEvaluateTemplateDao externalEvaluateTemplateDao;
	
	//非驻场外包评估
	@Resource
	private IExternalEvaluateService externalEvaluateService;
	
	//模板配置详情dao
	@Resource
	private ITemplateConfigurationDetailDao detailDao;
	
	//非驻场外包评估配置Dao
	@Resource
	private IExternalEvaluateConfigurationDao externalEvaluateConfigurationDao;
	
	//模板配置从属数据操作Service接口
	@Resource
	private ITemplateConfigurationDetailDeputyService templateConfigurationDetailDeputyService;
	
	//模板配置从属数据结果操作dao接口
	@Resource
	private ITemplateConfigurationDetailDeputyResultDao templateConfigurationDetailDeputyResultDao;
	
	//系统参数
	@Resource
	private ISysParamService sysParamService;
	
	//用户Service
	@Resource
	private ISysUserService userService;
	
	//供应商Service
	@Resource
	private ISupplierBaseInfoService supplierBaseInfoService;

	//代办任务
	@Resource
	private IUserTaskService userTaskService;
	
	//评估结果配置
	@Resource
	private IEvaluateSettingDao evaluateSettingDao;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return dao;
	}

	/**
	 * 添加
	 * @param info
	 * @return
	 */
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean add(Map info){
		String evaluateTitle = info.get("evaluateTitle").toString();//评估标题
		Map param = new HashMap();
		param.put("evaluateTitle", evaluateTitle);
		if(dao.isExist(param)){
			throw new EscServiceException(evaluateTitle+"已经存在！");
		}
		info.put("dataType", 2);//数据类型（1：评估配置的数据，2：新增的数据）
		info.put("status", 2);//已评估
		info.put("submitTime", UTDate.getCurDateTime());//提交时间
		info.put("generateTime", UTDate.getCurDateTime());//数据生成时间'
		info.put("submitter", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());//提交人
		super.add(info);
		return true;
	}
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		UTMap<String, Object> result = super.getById(id);
		String externalEvaluateConfigId = result.get("externalEvaluateConfigId")+"";//非驻场外包评估配置模板id
//		String id = result.get("id")+"";
		result.put("treeData", templateConfigurationDetailDeputyService.getDetailsDeputy(externalEvaluateConfigId, id));
		Map param = new HashMap();
		param.put("externalResultEvaluateId", id);
		param.put("isAccessEvaluateList", true);//过程考核数据展示排序按考核名称排，列表按时间排
//		param.put("generateTime", result.get("generateTime"));//只查询同一批生成的数据
		result.put("accessEvaluateList", externalEvaluateService.getListAll(param));
		return result;
	}
	
	/**
	 * 修改
	 * @param info
	 * @return
	 */
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean updateById(Map info){
		String id = info.get("id")+"";//非驻场外包评估配置模板id
		Map existMap = new HashMap();
		existMap.put("id", id);
		if(!dao.isExist(existMap)){
			throw new EscServiceException("当前数据已经不存在，请刷新页面重新操作！");
		}
		info.put("evaluateTime", UTDate.getCurDateTime());//评估时间
		info.put("submitTime", UTDate.getCurDateTime());//提交时间
		info.put("status", 1);//评估状态
		info.put("submitter", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());//提交人
		List<Map> resultList = new ArrayList<Map>();
		List<Map> list= (List<Map>)info.get("treeData");
		String externalEvaluateConfigId = info.get("externalEvaluateConfigId")+"";
//		String evaluator = info.get("id")+"";
		CommonUtils.setTemplateConfigurationDetailDeputyResult(externalEvaluateConfigId, id, list, resultList);
		//先删除
		templateConfigurationDetailDeputyResultDao.deleteByModuleTemplateConfigurationIdEvaluator(externalEvaluateConfigId, id);
		if(!resultList.isEmpty()){
			//后添加
			templateConfigurationDetailDeputyResultDao.adds(resultList);
			
		}
//		String externalEvaluateConfigId = info.get("externalEvaluateConfigId")+"";//非驻场外包评估配置模板id
//		UTMap<String, Object> externalEvaluateTemplate = externalEvaluateTemplateDao.getById(moduleTemplateConfigurationId);
//		String isSingle = externalEvaluateTemplate.get("isSingle")+"";//是否单一数据，1：是，0：否，默认否
//		Map param = new HashMap();
//		param.put("externalEvaluateConfigId", externalEvaluateConfigId);//非驻场外包评估配置模板id
		//查询非驻场外包评估对应模板下的所有非驻场外包评估数据
//		List<UTMap<String, Object>> accessEvaluateList = dao.getListMaps(param);
//		boolean temp = false;
//		for (UTMap<String, Object> accessEvaluate : accessEvaluateList) {
//			String accessEvaluateId = accessEvaluate.get("id") + "";
//			String externalEvaluateTemplateId = accessEvaluate.get("externalEvaluateTemplateId") + "";
//			if(id.equals(accessEvaluateId)){//不判断当前数据
//				continue;
//			}
//			//当前评估的数据模板是单一数据，则把改模板下其它人的评估数据都删除
//			if("1".equals(isSingle) && externalEvaluateTemplateId.equals(moduleTemplateConfigurationId)){
//				dao.delete(accessEvaluate);
//			}else{
//				String status = accessEvaluate.get("status") + "";//非驻场外包评估状态 
//				//存在待评估状态的数据
//				if(!temp && "0".equals(status)){
//					temp = true;
////					break;
//				}
//			}
//		}
		//只标识供应商非驻场外包评估模板对应的个人非驻场外包评估是否已经在评估，待评估：0，评估中：1，已评估：2
//		int accessEvaluateConfigurationStatus = 0;
//		if(temp){
//			accessEvaluateConfigurationStatus = 1;
//		}else{
//			accessEvaluateConfigurationStatus = 2;
//		}
//		Map accessEvaluateConfiguration = new HashMap();
//		//修改此状态用户判断评估配置可不可以修改或删除
//		accessEvaluateConfiguration.put("evaluateStatus", accessEvaluateConfigurationStatus);
//		accessEvaluateConfiguration.put("id", externalEvaluateConfigId);
//		//修改对应非驻场外包评估配置的状态
//		externalEvaluateConfigurationDao.updateBy(accessEvaluateConfiguration, "id");
		userTaskService.finishTaskByBatch(id);
		return super.updateById(info);
	}
	
	
	private void setTemplateConfigurationDetailDeputyResult(String moduleTemplateConfigurationId, String evaluator, List<Map> list, List<Map> resultList){
		if(list == null){
			return;
		}
		for (Map item : list) {
			Map info = new HashMap();
			if(item.get("result") != null){
				String result = item.get("result").toString();
				info.put("moduleTemplateConfigurationId", moduleTemplateConfigurationId);
				String templateConfigurationDetailDeputyId = item.get("id").toString();
				info.put("evaluator", evaluator);
				info.put("templateConfigurationDetailDeputyId", templateConfigurationDetailDeputyId);
				info.put("result", result);
				resultList.add(info);
			}
			
			String type = item.get("type").toString();//类型，1：填空，2：单选，3：多选，0：是配置项
			if(("2".equals(type) || "3".equals(type)) && item.get("options") != null){//如果是单选或者多选，保存子配置项
				List<Map> options = (List<Map>)item.get("options");
				setTemplateConfigurationDetailDeputyResult(moduleTemplateConfigurationId,evaluator,options,resultList);
			}
			if(item.get("children") != null){//如果存在子节点数据
				List<Map> children = (List<Map>)item.get("children");
				setTemplateConfigurationDetailDeputyResult(moduleTemplateConfigurationId,evaluator,children,resultList);
			}
		}
	}
	
	@Override
	public boolean deleteById(String id) {
		detailDao.deleteByTemplateConfigurationId(id);
		return super.deleteById(id);
	}
	
	/**
	 * 关闭
	 * @param info
	 * @return
	 */
	public boolean close(Map info){
		info.put("closeTime", UTDate.getCurDateTime());//关闭时间
		info.put("status", 2);//评估状态
		userTaskService.finishTaskByBatch(info.get("id")+"");//关闭需要批量清除掉配置下所有代办任务
		return super.updateById(info);
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map param) {
		dao.getPageInfo(pageBean, param);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	@UploadQueryMarks
	public List<UTMap<String, Object>> getListAll(Map params){
		return dao.getListAll(params);
	}
	
	/**
	 * 导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	@Override
	public void leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String[] fileds = IExternalResultEvaluateDao.outFileds;
		String tamlate= null;
		tamlate= "excelOutTamplate.externalResult";
		
		//替换下拉的值
		Map<String, String> fieldAndParamType = new HashMap<String, String>();
		UTMap<String, Object> setting = evaluateSettingDao.getById("1");
		//判断评估结果的填报方式是下拉还是文本输入
		if(setting != null && "1".equals(setting.get("externalManager").toString())){
			fieldAndParamType.put(IExternalResultEvaluateDao.FIELD_EVALUATERESULT, "externalManagerEvaluateResult");
		}
		fieldAndParamType.put(IExternalResultEvaluateDao.FIELD_STATUS, "accessEvaluateConfigurationStatus");
		sysParamService.changeParamData(data, fieldAndParamType);
		
		Map<String,Object> param = new HashMap<String,Object>();
		param.put("state", "1");
		param.put("userType", "1");//查询甲方人员
		List<UTMap<String,Object>> userMap = userService.getUserBaseInfo(param);
		
		//转换评估人员
		for(int i=0;i<data.size();i++){
			Map<String,Object> item = (Map<String, Object>) data.get(i);
			String evaluator = (String) item.get(IExternalResultEvaluateDao.FIELD_EVALUATOR);
			item.put(IExternalResultEvaluateDao.FIELD_EVALUATOR, CommonUtils.getUserNameAndCodesByIds(userMap, evaluator));
			item.put(IExternalResultEvaluateDao.FIELD_BEGIN_DATE, CommonUtils.replaceAll((String)item.get(IExternalResultEvaluateDao.FIELD_BEGIN_DATE), "-", "/"));
			item.put(IExternalResultEvaluateDao.FIELD_END_DATE, CommonUtils.replaceAll((String)item.get(IExternalResultEvaluateDao.FIELD_END_DATE), "-", "/"));
			item.put(IExternalResultEvaluateDao.FIELD_SUBMITTIME, CommonUtils.replaceAll((String)item.get(IExternalResultEvaluateDao.FIELD_SUBMITTIME), "-", "/"));
		}
		
		UTExcel.leadingout( fileds, data, tamlate, request, response);
	}
	
	/**
	 * 从excel中导入数据
	 * @param filePath
	 * @param param
	 * @return
	 */
	@Override
	public void leadingin(String filePath, Map<String, Object> param) throws Exception {
		List<UTMap<String, Object>> leadinginList = new ArrayList<UTMap<String,Object>>();
		// 根据路径 获取工作薄
		Sheet sheet = UTExcel.getSheets(filePath)[0];
		// 导入顺序
		String[] fileds = IExternalResultEvaluateDao.inFileds;
		String[] cellArray = new String[] { 
				"评估标题*（长度：0-20）", 
				"供应商*",
				"开始日期*（格式：yyyy/MM/dd）", 
				"结束日期*（格式：yyyy/MM/dd）", 
				"检查人员*", 
				"外部专家", 
				"评估结果*（长度：0-20）",
				"结果说明*（长度：0-500）"
		};
		int[] lengthArr = {20, 0, 0, 0, 0, 0, 20, 500};
		int rowNum = sheet.getLastRowNum();
		int cellNum = fileds.length;
		
		if(!UTExcel.excelValidateByCell(sheet, cellArray, fileds)) {
			throw new EscServiceException("导入失败，请选择正确的模板！");
		}		
		
		Map<String,Object> userParam = new HashMap<String,Object>();
		userParam.put("state", "1");
		userParam.put("userType", "1");//查询甲方人员
		List<UTMap<String,Object>> userMap = userService.getUserBaseInfo(userParam);
		StringBuilder error = new StringBuilder();
		// 从excel第1行开始添加 数据，全部保存
		for (int i = 1; i <= rowNum; i++) {
			// 遍历excel
			Row row = sheet.getRow(i);
			UTMap<String, Object> map = new UTMap<String, Object>();
			for (int j = 0; j < cellNum; j++) {
				String cellvalue = null;
				Cell cell = row.getCell(j);
				if (cell != null) {
					cell.setCellType(Cell.CELL_TYPE_STRING);
					cellvalue = cell.getStringCellValue();
					cellvalue = StringUtils.isEmpty(cellvalue) ? null : cellvalue.trim();
				}
				//检查为空的字段
				if(j == 0 || j == 1 || j == 2 || j == 3 || j == 4 || j == 6 || j == 7 ) {  //不能为空
					if (StringUtils.isEmpty(cellvalue)) {
						error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "内容为空，请检查！" + "<br>");
					}
				}else{  //可以为空
					cellvalue = StringUtils.isEmpty(cellvalue) ? null : cellvalue;
				}
				if (cellvalue != null) {
					//长度校验
					if (lengthArr[j] != 0 && cellvalue.length() > lengthArr[j]){
						error.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "内容长度超出限制，请检查！" + "<br>");
					}
					//转换供应商
					if(j==1){		
	//					cellvalue = cellvalue.replaceAll("，", ",");
						Map supplierParam = new HashMap();
						supplierParam.put("fullName", cellvalue);
						List<UTMap<String, Object>> supplierList = supplierBaseInfoService.getListMaps(supplierParam);
						if(supplierList == null || supplierList.isEmpty()){
							error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "列，系统不存在供应商【"+cellvalue+"】！" + "<br>");
						}else if(supplierList.size() != 1){
							error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "列，系统存在重名的供应商【"+cellvalue+"】，无法匹配，请加入供应商编号！" + "<br>");
						}else{
							cellvalue = supplierList.get(0).get("id") + "";
						}
					}
					if ((j == 2 || j == 3) && cellvalue != null) {//开始结束日期格式校验
						if (!CommonUtils.validateDate(cellvalue)) {
							error.append("Excel内容错误，行号为" + (i+1) + "的"+cellArray[j]+"格式不对，请检查！" + "<br>");
						}
					}
					//转换检查人员
					if(j==4 && cellvalue != null){		
						cellvalue = cellvalue.replaceAll("，", ",");
						try{
							cellvalue = CommonUtils.getIdsByUserNameAndCodes(userMap, cellvalue);
						}catch(EscServiceException ex){
							error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "列，"+ex.getMessage() + "<br>");
						}
					}
				}
				map.put(fileds[j], cellvalue);
			}			
			map.put("importSort", i);
			leadinginList.add(map);
		}
		//替换下拉的值
		Map<String, String> fieldAndParamType = new HashMap<String, String>();
		UTMap<String, Object> setting = evaluateSettingDao.getById("1");
		//判断评估结果的填报方式是下拉还是文本输入
		if(setting != null && "1".equals(setting.get("externalManager").toString())){
			fieldAndParamType.put(IExternalResultEvaluateDao.FIELD_EVALUATERESULT, "externalManagerEvaluateResult");
		}
		sysParamService.changeDataToParam(leadinginList, fieldAndParamType);
		
		//保存到数据库
		for (int i = 0; i < leadinginList.size(); i ++){
			UTMap leadingOne = leadinginList.get(i);
			//判断巡检管理评估结果的填报方式是下拉还是文本输入
			if(setting != null && "1".equals(setting.get("externalManager").toString())){
				if(StringUtils.isEmpty((String) leadingOne.get(IExternalResultEvaluateDao.FIELD_EVALUATERESULT))) {
					error.append("Excel内容错误，行号为" + (i + 2) + "的评估结果参数在系统中不存在，请检查！" + "<br>");
				}
			}
		}
		
		if (StringUtils.isNotEmpty(error.toString())) {
			throw new EscServiceException(error.toString());
		}
		for (int i = 0; i < leadinginList.size(); i ++){
			UTMap leadingOne = leadinginList.get(i);
			leadingOne.put("dataType", 2);//数据类型（1：评估配置的数据，2：新增的数据）
			//往数据库插入一条数据
			add(leadingOne);
		}
	}

}
