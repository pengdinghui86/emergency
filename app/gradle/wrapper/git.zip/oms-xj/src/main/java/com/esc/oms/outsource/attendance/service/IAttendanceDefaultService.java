package com.esc.oms.outsource.attendance.service;

public interface IAttendanceDefaultService {
    /**
     * 获取默认值
     * @param configType
     * @param code
     * @return
     */
    public String getValue(String configType, String code);

    /**
     * 主要作用是清除缓存，在入口调用
     */
    public void clearCache();
}
