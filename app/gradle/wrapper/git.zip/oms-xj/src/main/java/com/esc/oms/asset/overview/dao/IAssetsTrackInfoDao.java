package com.esc.oms.asset.overview.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

public interface IAssetsTrackInfoDao extends IBaseOptionDao{
	
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_ASSETSSTORAGE = "资产入库";
	public static final String  FIELD_ASSETSCOLLAR = "资产领用";
	public static final String  FIELD_ASSETSBORROW = "资产借用";
	public static final String  FIELD_ASSETSBACK = "资产归还";
	public static final String  FIELD_ASSETSCHANGE = "资产变更";
	public static final String  FIELD_ASSETSREPAIR = "资产维修";
	public static final String  FIELD_ASSETSRETIREMENT = "资产报废";

	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params);
}
