package com.esc.oms.outsource.external.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.external.dao.IExternalEvaluateTemplateDao;

/**
 * 非驻场外包评估配置模板Dao
 * @author owner
 *
 */
@Repository
public class ExternalEvaluateTemplateDaoImpl extends BaseOptionDao implements IExternalEvaluateTemplateDao{

	@Override
	public String getTableName() {
		return "outsourc_external_evaluate_template";
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params), pageBean, null);
	}
	
 	@Override
	public List<UTMap<String, Object>> getListMaps(Map param) {
		return super.getListBySql(getSearchSql(param), null);
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append("select tb.*, CONCAT(tb.templateConfigurationName , ' ' , tb.templateConfigurationVersions) as 'templateConfiguration' from " );
		sql.append(getTableName());
		sql.append(" tb where 1=1 ");
		if(params!=null && params.size()>0){ 
			
//			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
//				sql.append(" and tb.supplierId like '%"+params.get("name").toString().trim()+"%' ");
//			}
			if(params.get("externalEvaluateConfigId")!=null && StringUtils.isNotEmpty(params.get("externalEvaluateConfigId").toString())){
				sql.append(" and tb.externalEvaluateConfigId = '"+params.get("externalEvaluateConfigId").toString().trim()+"' ");
			}
			if(params.get("supplierId")!=null && StringUtils.isNotEmpty(params.get("supplierId").toString())){
				sql.append(" and tb.supplierId = '"+params.get("supplierId").toString().trim()+"' ");
			}
//			if(params.get("subType")!=null && StringUtils.isNotEmpty(params.get("subType").toString())){
//				sql.append(" and tb.subType = "+params.get("subType").toString().trim()+" ");
//			}
		}
		sql.append(" order by createTime desc");
		return  sql.toString();
	}

}
