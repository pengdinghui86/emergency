package com.esc.oms.asset.lowvalue.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.asset.lowvalue.dao.ILowvalueInfoDao;
@Repository
public class LowvalueInfoDaoImpl extends BaseOptionDao implements ILowvalueInfoDao{
	
	@Override
	public String getTableName() {
		return "assets_lowvalue_info";
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params,false), pageBean, null);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params) {
		return super.getListBySql(getSearchSql(params,false), null);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListMaps(Map params) {
		return super.getListBySql(getSearchSql(params,false), null);
	}
	
//	@Override
//	public UTMap<String, Object> getById(String id) {
//		String sql = this.getSearchSql(null,true);
//		List<UTMap<String, Object>> list = super.getListBySql(sql, id);
//		if(list != null && list.size() > 0){
//			return list.get(0);
//		}
//		return null;
//	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params,boolean isGetById){
		StringBuilder sql = new StringBuilder();
		sql.append(" select info.*,CONCAT(name,'/',code) as showName from assets_lowvalue_info info ");
		sql.append(" where 1=1 ");
		if(params!=null && params.size()>0){
			if(params.get("accurateSearch")!=null && "true".equals(params.get("accurateSearch"))){ //精确查找，入库记录导入
				if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
					sql.append(" and info.name='"+params.get("name").toString().trim()+"' ");
				}
				if(params.get("code")!=null && StringUtils.isNotEmpty(params.get("code").toString())){
					sql.append(" and info.code='"+params.get("code").toString().trim()+"' ");
				}
			}else{
				if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
					sql.append(" and info.name like '%"+params.get("name").toString().trim()+"%' ");
				}
				if(params.get("code")!=null && StringUtils.isNotEmpty(params.get("code").toString())){
					sql.append(" and info.code like '%"+params.get("code").toString().trim()+"%' ");
				}
			}			
			if(params.get("category")!=null && StringUtils.isNotEmpty(params.get("category").toString())){
				sql.append(" and info.category='"+params.get("category").toString().trim()+"' ");
			}			
		}
		sql.append(" order by info.createTime desc");
		return  sql.toString();
	}
}
