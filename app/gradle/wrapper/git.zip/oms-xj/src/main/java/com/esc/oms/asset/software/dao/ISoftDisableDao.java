package com.esc.oms.asset.software.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

public interface ISoftDisableDao extends IBaseOptionDao{
	
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_SOFTWAREID = "softwareId";
	public static final String  FIELD_DISABLEDATE = "disableDate";
	public static final String  FIELD_REASON = "reason";
	public static final String  FIELD_SPARE = "spare";
	public static final String  FIELD_CREATEUSERID = "createUserId";
	public static final String  FIELD_CREATETIME = "createTime";
	
	
	
	public List<UTMap<String, Object>> getSoftDisableList(Map param);
	
	/**
	 * 获取禁用时间为当天的禁用记录
	 * @param param
	 * @return
	 */
	public List<UTMap<String, Object>> getSoftDisableListByDisableDate(Map param);
}
