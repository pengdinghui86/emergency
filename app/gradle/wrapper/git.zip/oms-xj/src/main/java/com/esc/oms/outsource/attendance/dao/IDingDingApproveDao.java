package com.esc.oms.outsource.attendance.dao;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

import java.util.List;
import java.util.Map;

public interface IDingDingApproveDao extends IBaseOptionDao{

    public List<UTMap<String, Object>> getListMap(Map<String, Object> param);

    /**
     * 获取还没有同步的数据
     * @return
     */
    public List<UTMap<String, Object>> getUnSynchronized();

    /**
     * 获取详细信息
     * @param param
     * @return
     */
    public List<UTMap<String, Object>> getDetailListMap(Map<String, Object> param);

    /**
     * 删除时间段内的数据
     * @param startTime
     * @param endTime
     * @param dingDingIds
     * @return
     */
    public boolean deleteByTime(String startTime, String endTime, String dingDingIds);
}
