package com.esc.oms.exemple.service;

import org.esc.framework.service.IBaseOptionService;


public interface ICrudService extends IBaseOptionService{
}
