package com.esc.oms.outsource.emergency.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.emergency.dao.IEmergCommunDao;
import com.esc.oms.util.RoleUtils;
@Repository
public class EmergCommunDaoImpl extends BaseOptionDao implements IEmergCommunDao{
	

	@Override
	public String getTableName() {
		return "epiboly_emergency_communicate";
	}
	
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params), pageBean, null);
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT tb.id,tb.name,tb.startTime,tb.endTime,tb.communicateType,tb.createTime,tb.createUser,"
				 + " tb.aim,tb.lecturer,tb.content,tb.resultText,concat(su.`name`, '/', su.`code`) promoter,tb.supplierObj,tb.internalObj,tb.externalObj from " );
		sql.append(getTableName());
		sql.append(" tb LEFT JOIN sys_user su ON su.id = tb.promoter where 1=1 ");
		if(params!=null && params.size()>0){
			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
				sql.append(" and tb.name like '%"+params.get("name").toString().trim()+"%' ");
			}
		}
//		if(EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.COMMON_BANK_USER,RoleUtils.COMMON_SUPPLIER_USER,RoleUtils.SUPPLIER_LEADERS,RoleUtils.SYSTEM_ADMINISTRATOR)){//普通金融机构用户
//			sql.append(" and tb.createUserId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' ");//非研发用户只能查询自己的数据，研发用户查询所有数据方便调试
//		}
		if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SUPPLIER_ADMINISTRATOR,RoleUtils.SYSTEM_ADMINISTRATOR)){//普通金融机构用户
			sql.append(" AND (tb.supplierObj LIKE '%"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"%' OR tb.internalObj LIKE '%"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"%' ");
			sql.append(" OR tb.promoter = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' OR tb.createUserId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"')");
		}
		sql.append(" order by tb.createTime desc");
		return  sql.toString();
	}


	@Override
	public List<UTMap<String, Object>> getEmergCommunByNameAndId(String name,
			String id) {
		String sql = "SELECT * FROM "+getTableName()+" cmh WHERE cmh.name = '"+name+"' AND cmh.id != '"+id+"'";
		return super.getListBySql(sql);
	}
}
