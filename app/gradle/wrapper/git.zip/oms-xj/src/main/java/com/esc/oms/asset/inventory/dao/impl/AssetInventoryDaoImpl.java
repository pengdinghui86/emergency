package com.esc.oms.asset.inventory.dao.impl;

import com.esc.oms.asset.inventory.dao.IAssetInventoryDao;
import com.esc.oms.util.RoleUtils;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
@Repository
public class AssetInventoryDaoImpl extends BaseOptionDao implements IAssetInventoryDao{
	
	private String inventoryDetailTableName = "assets_material_inventory_detail";
	

	@Override
	public String getTableName() {
		return "assets_material_inventory";
	}
	

	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params), pageBean, null);
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT ami.id,ami.code,ami.title,ami.beginDate,ami.endDate,ami.needConfirm,ami.remark,ami.`status`,ami.createUserId " );
		sql.append(" FROM "+getTableName()+" ami ");
		sql.append(" WHERE 1=1 ");
		if(params!=null && params.size()>0){
			if(params.get("title")!=null && StringUtils.isNotEmpty(params.get("title").toString())){
				sql.append(" AND ami.title LIKE '%"+params.get("title").toString().trim()+"%' ");
			}
			if(params.get("status")!=null && StringUtils.isNotEmpty(params.get("status").toString())){
				sql.append(" AND ami.status='"+params.get("status").toString().trim()+"' ");
			}
			if(params.get("needConfirm")!=null && StringUtils.isNotEmpty(params.get("needConfirm").toString())){
				sql.append(" AND ami.needConfirm='"+params.get("needConfirm").toString().trim()+"' ");
			}
		}
		if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR,RoleUtils.ASSET_MANAGER)){
			sql.append(" AND exists(select 1 from assets_material_inventory_detail d, assets_material_info m ");//非研发用户只能查询自己的数据，研发用户查询所有数据方便调试
			sql.append(" WHERE d.inventoryId = ami.id and d.assetsId = m.id and m.resUserId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"'  AND ami.`status` != 0 ) ");//
		}
		sql.append(" ORDER BY ami.createTime desc");
		return  sql.toString();
	}
	
	private String getAssetAllocationListMapsSql(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT am.`name` ,am.sn, amc.name categoryName,amsc.`name` subCategoryName,am.brand,am.model,amid.confirmStatus,amid.status,concat(am.`name`,IF ( am.serialNum IS NULL OR am.serialNum = '', '', concat('/', am.serialNum))) assetsNameCode,am.`code`,am.codeNum,amid.assetsAdminId,amid.resUserId amidResUser, " );
		sql.append(" ap.`name` location,so.`name` resDepartId,concat(su.`name`, '/', su.`code`) resUserId,concat(su2.`name`, '/', su2.`code`) EquipmentLeaderName,am.serialNum, su.name resUserName,ami.remark,am.id amInfoId,amid.id amidId,amid.assetsId,am.resUserId resUser,am.assetsLevel ");
		sql.append(" FROM assets_material_inventory_detail amid ");
		sql.append(" LEFT JOIN assets_material_inventory ami ON ami.id = amid.inventoryId ");
		sql.append(" LEFT JOIN assets_material_info am ON am.id = amid.assetsId ");
		sql.append(" LEFT JOIN assets_material_category amc ON amc.id = am.category ");
		sql.append(" LEFT JOIN assets_material_category amsc ON amsc.id = am.subCategory  ");
		sql.append(" LEFT JOIN assets_place ap ON ap.id = am.location  ");
		sql.append(" LEFT JOIN sys_org so ON so.id = am.resDepartId ");
		sql.append(" LEFT JOIN sys_user su ON su.id = am.resUserId ");
		sql.append(" LEFT JOIN sys_user su2 ON su2.id = am.EquipmentLeader ");
		sql.append(" WHERE 1=1 ");
		String isLeadingout = "0";
		if(params!=null && params.size()>0){
			if(params.get("inventoryId")!=null &&  StringUtils.isNotEmpty(params.get("inventoryId").toString())){
				sql.append(" AND ami.id = '"+params.get("inventoryId").toString().trim()+"' ");
			}
			isLeadingout = (String) params.get("isLeadingout");
		}
		if (!StringUtils.equals("1", isLeadingout)) {
			if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR,RoleUtils.ASSET_MANAGER)){
				sql.append(" AND am.resUserId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' ");//非研发用户只能查询自己的数据，研发用户查询所有数据方便调试
			}
		}
//		if("true".equals(String.valueOf(params.get("viewPage")))){
//		}else{
//			if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR)){
//				sql.append(" AND am.resUserId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' ");//非研发用户只能查询自己的数据，研发用户查询所有数据方便调试
//			}
//		}
		
		sql.append(" ORDER BY am.`name`,am.`code`, amid.createTime ");
		return  sql.toString();
	}


	@Override
	public boolean addAssetInventory(Map info) {
		return	super.saveBySql(inventoryDetailTableName, info);
	}


	@Override
	public boolean deleteAssetInventoryById(String id) {
		return super.deleteByIds(inventoryDetailTableName, id);
	}


	@Override
	public List<UTMap<String, Object>> getAssetInventoryListMaps(Map param) {
		return super.getListBySql(getAssetAllocationListMapsSql(param));
	}


	@Override
	public boolean updateInventoryStatusById(String id,String status, String curUserId) {
		StringBuilder sql=new StringBuilder();
		if("2".equals(status)){
			sql.append(" update assets_material_inventory_detail amid SET amid.`confirmStatus` = '"+status+"'"
					 + ", amid.assetsAdminId = '"+curUserId+"'"
					 + " WHERE amid.id = '" +id+"'");
		}else{
			sql.append(" update assets_material_inventory_detail amid SET amid.`confirmStatus` = '"+status+"'"
					 + " , amid.resUserId = '"+curUserId+"'"
					 + " WHERE amid.id = '" +id+"'");
		}
		return super.executeUpdate(sql.toString());
	}
	
	/**
	 * 批量确认
	 * @param id
	 * @return
	 */
	@Override
	public boolean batchConfirm(String id) {
		StringBuilder sql=new StringBuilder();
		//如果是资产管理员
		if(EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.ASSET_MANAGER)){
			sql.append(" update assets_material_inventory_detail amid SET amid.`confirmStatus` = '2'"
					 + ", amid.assetsAdminId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"'"
					 + " WHERE amid.id = '" +id+"'");
			return super.executeUpdate(sql.toString());
		}
		
		sql=new StringBuilder();
		sql.append(" update assets_material_inventory_detail amid,assets_material_info ami ");
		sql.append(" set amid.confirmStatus = '3' , amid.resUserId = ami.resUserId ");
		sql.append(" where amid.assetsId = ami.id and amid.id= '"+id+"' and ami.resUserId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"'");
		return super.executeUpdate(sql.toString());
	}


	@Override
	public void getAssetInventoryPageInfo(UTPageBean pageBean, Map param) {
		super.getPageListMapBySql(getAssetAllocationListMapsSql(param), pageBean, null);
		
	}


	@Override
	public boolean deleteAssetInventoryByInventoryId(String id) {
		StringBuilder sql=new StringBuilder();
		sql.append("DELETE FROM assets_material_inventory_detail  WHERE inventoryId = '"+id+"'");
		return super.executeUpdate(sql.toString());
	}


	@Override
	public boolean updateInventoryStatusByInventoryId(String inventoryId, String status) {
		StringBuilder sql=new StringBuilder();
		sql.append(" update assets_material_inventory_detail amid SET amid.`confirmStatus` = '"+status+"' WHERE amid.inventoryId = '" +inventoryId+"'");
		return super.executeUpdate(sql.toString());
	}


	@Override
	public List<UTMap<String, Object>> getNowDateInventoryListMaps() {
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT * FROM assets_material_inventory ami WHERE DATE(ami.beginDate) = CURDATE()");
		return super.getListBySql(sql.toString());
	}


	@Override
	public List<UTMap<String, Object>> getAssetsByInventoryIdListMaps(String inventoryId) {
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT amid.*, ami.codeNum, ami.name, ami.resUserId resUser FROM assets_material_inventory_detail amid ");
		sql.append(" left join assets_material_info ami on amid.assetsId=ami.id ");
		sql.append(" WHERE amid.inventoryId = '"+inventoryId+"' ");
		return super.getListBySql(sql.toString());
	}


	@Override
	public UTMap<String, Object> geyAssetInventoryById(String id) {
		return super.getMapById(inventoryDetailTableName, null, id);
	}

	@Override
	public List<UTMap<String, Object>> getListMaps(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT ami.id,ami.code,ami.title,ami.beginDate,ami.endDate,ami.needConfirm,ami.remark,ami.`status`,ami.createUserId,ami.createTime,ami.processId,ami.processStep " );
		sql.append(" FROM "+getTableName()+" ami ");
		sql.append(" WHERE 1=1 ");
		if(params!=null && params.size()>0){
			if(params.get("title")!=null && StringUtils.isNotEmpty(params.get("title").toString())){
				sql.append(" AND ami.title LIKE '%"+params.get("title").toString().trim()+"%'");
			}
			if(params.get("code")!=null && StringUtils.isNotEmpty(params.get("code").toString())){
				sql.append(" AND ami.code ='"+params.get("code").toString().trim()+"'");
			}
		}
		return super.getListBySql(sql.toString());
	}
	
	@Override
	public UTMap<String, Object> getInventoryByCode(String code){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT ami.id,ami.code,ami.title,ami.beginDate,ami.endDate,ami.needConfirm,ami.remark,ami.`status`,ami.createUserId,ami.createTime,ami.processId,ami.processStep " );
		sql.append(" FROM "+getTableName()+" ami ");
		sql.append(" WHERE code='" + code + "' ");
		return super.getOneBySql(sql.toString(), null);
	}
	
	@Override
	public UTMap<String, Object> getInventoruAsset(String inventoryId, String assetId){
		StringBuilder sql = new StringBuilder();
		sql.append(" select id, inventoryId, assetsId, confirmStatus, createUser, createTime, assetsAdminId, resUserId, status ");
		sql.append(" from assets_material_inventory_detail ");
		sql.append(" where inventoryId='" + inventoryId +"' and assetsId='" + assetId + "' ");
		return super.getOneBySql(sql.toString(), null);
	}
	
	@Override
	public boolean updateInverstoryAsset(Map<String, Object> info) {
		return super.updateById("assets_material_inventory_detail", info);
	}
}
