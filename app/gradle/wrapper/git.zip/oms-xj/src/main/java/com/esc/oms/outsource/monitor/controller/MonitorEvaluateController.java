package com.esc.oms.outsource.monitor.controller;

import com.esc.oms.outsource.monitor.service.IMonitorEvaluateService;
import com.esc.oms.util.CommonUtils;
import net.sf.json.JSONObject;
import org.apache.commons.io.FilenameUtils;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 *服务监控评估Controller
 * @author owner
 *
 */
@Controller
@RequestMapping("monitorEvaluate")
public class MonitorEvaluateController extends BaseOptionController {

	@Resource
	private IMonitorEvaluateService service;
	
	@Override
	public IBaseOptionService optionService() {
		return service;
	}
	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			service.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	/**
	 * 导出
	 * @param param
	 * @param utPageBean
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "leadingout")
	public void leadingout(@RequestParam Map<String, Object> param,
			HttpServletRequest request,
			HttpServletResponse response) {
		try {
			Map<String, Object> cloneParam = CommonUtils.clone(param);
			UTPageBean clonePageBean = CommonUtils.getPageBean(cloneParam);
			
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) cloneParam.get("outType"));
			Object info = cloneParam.get("params");
			JSONObject jsonBean = null;
			if(info != null) {
				jsonBean = JSONObject.fromObject(info);
			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = service.getListMaps(jsonBean);
			} else {
				service.getPageInfo(clonePageBean, jsonBean);
				data = clonePageBean.getRows();
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			service.leadingout(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	/**
	 * 从excel导入
	 * @param params
	 * @param filePath
	 * @return
	 */
	@RequestMapping(value = "leadingin")
	@ResponseBody
	public String leadingin(@RequestParam Map<String, Object> param, String filePath) {
		UTMap<String, Object> utMap = new UTMap<String, Object>();
		try {
			service.leadingin(FilenameUtils.normalize(filePath) , param);
		}catch(EscServiceException e){
			logger.error("导入失败！",e);
			return UTJsonUtils.getJsonMsg(false, e.getMessage());
    	} catch (Exception e) {
    		logger.error("导入失败！",e);
			return UTJsonUtils.getJsonMsg(false, "导入失败！");
		} finally {
			try {
				File file = new File(FilenameUtils.normalize(filePath));
				file.delete();
			} catch (Exception e2) {
				logger.error("删除导入的文件失败！");
			}
		}
		return UTJsonUtils.getJsonMsg(true, "导入成功！");
	}
	
	

}
