package com.esc.oms.asset.place.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTListResult;
import org.esc.framework.utils.page.UTTreeRelsult;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.asset.physical.service.IAssetPhysicalService;
import com.esc.oms.asset.place.service.IAssetPlaceService;

import net.sf.json.JSONObject;

@Controller
@RequestMapping("assetPlace")
public class AssetPlaceController extends BaseOptionController {
	@Resource
	private IAssetPlaceService assetPlaceService;
	
	@Resource
	private IAssetPhysicalService assetPhysicalService;
	
	@Override
	public IBaseOptionService optionService() {
		return assetPlaceService;
	}
	
	@RequestMapping("list")
	@ResponseBody
	public UTListResult getResourceList(@RequestParam Map<String, Object> param){
		return UTListResult.getListResult(assetPlaceService.getListMaps(param));
	}
	
	
	@RequestMapping("placeTree")
	@ResponseBody
	public UTListResult placeTree(@RequestParam Map<String, Object> param){
		return	UTTreeRelsult.ListMapToListTree("所有地点", "id","pId","name", assetPlaceService.getListMaps(param));
	}
	
	@RequestMapping(value="defgetById")
	@ResponseBody
	public UTMap<String, Object> defgetById(@RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = null;
    	try{
    		map = optionService().getById(param.get("id").toString());
    		if("-1".equals((String)map.get("parentId"))){
    			map.put("所有地点", "parentName");
    		}
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return map;
	}
	
	@RequestMapping(value="getListByParentId")
	@ResponseBody
	public List<UTMap<String, Object>> getListByParentId(@RequestParam  Map<String, Object> param){
		List<UTMap<String, Object>> list = 
				this.assetPlaceService.getListByParentId((String) param.get("parentId"));
		if (null == list) {
			return new ArrayList<UTMap<String, Object>>();
		}
		
		for (UTMap<String, Object> map : list) {
			List<UTMap<String, Object>> uList = assetPlaceService.getAssetPlaceUByPlaceId(map.get("id").toString());
			int restNum = 0;
			if (null != uList && !uList.isEmpty()) {
				for (UTMap<String, Object> umap :uList) {
					if (StringUtils.equals("0", umap.get("status").toString())) {
						restNum++;
					}
				}
			}
			map.put("restNum", restNum);
		}
		return list;
	}
	
	@RequestMapping(value="getAssetPlaceUByPlaceId")
	@ResponseBody
	public List<UTMap<String, Object>> getAssetPlaceUByPlaceId(@RequestParam  Map<String, Object> param){
		List<UTMap<String, Object>> uList = assetPlaceService.getAssetPlaceUByPlaceId(param.get("id").toString());
		if (null != uList && !uList.isEmpty()) {
			for (UTMap<String, Object> umap : uList) {
				String assetId = (String)umap.get("assetId");
				String assetName = "";
				String businessName = "";
				if (StringUtils.isNotEmpty(assetId)) {
					UTMap<String, Object> assetInfo = assetPhysicalService.getById(assetId);
					if (null != assetInfo && !assetInfo.isEmpty()) {
						assetName = (String)assetInfo.get("name");
						businessName = (String)assetInfo.get("businessName");
					}
				}
				umap.put("assetName", assetName);
				umap.put("businessName", businessName);
			}
		}
		
		return uList;
	}

	/**
	 * 获取可用的机柜
	 * @param param
	 * @return
	 */
	@RequestMapping("getUsableStartList")
	@ResponseBody
	public List<UTMap<String, Object>> getUsableStartList(@RequestParam  Map<String, Object> param){
		return assetPlaceService.getUsableList(param);
	}
	
	@RequestMapping(value="isExitItem", method=RequestMethod.POST)
	@ResponseBody
	public JSONObject isExitItem(@RequestBody Map<String, Object> param){
		String name = (String) param.get("name");
		if (StringUtils.isNotEmpty(name)) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("name", name);
			if (assetPlaceService.isExist(param)) {
				return UTJsonUtils.getMsgJson(false, "名称为【"+ name +"】的地址已存在！");
			}
		}
		return UTJsonUtils.getMsgJson(true, "");
	}
}
