package com.esc.oms.asset.software.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.idgenerator.IDGenerationManager;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.dao.ISysOrgDao;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.timetask.anotations.CronTimeTask;
import org.esc.framework.timetask.anotations.TimeTaskMark;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.asset.agreement.service.IAssetsAgreementInfoService;
import com.esc.oms.asset.application.dao.IBusinessNumberDao;
import com.esc.oms.asset.software.dao.IAssetSoftwareDao;
import com.esc.oms.asset.software.dao.ISoftHistoryDao;
import com.esc.oms.asset.software.service.IAssetSoftwareService;
import com.esc.oms.asset.software.service.ISoftCategoryService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;
import com.esc.oms.util.RoleUtils;

@Service
@Transactional
@TimeTaskMark
public class AssetSoftwareServiceImpl extends BaseOptionService implements IAssetSoftwareService {
	
	@Resource
	private IAssetSoftwareDao assetSoftwareDao;

	@Resource
	private ISysParamService sysParamService;
	
	@Resource
	private ISoftHistoryDao softHistoryDao;
	
	@Resource
	private MessageSend messageSend;
	
	@Resource
	private ISysUserService userService;
	
	@Resource
	private IBusinessNumberDao businessNumberDao;
	
	@Resource
	private ISoftCategoryService softCategoryService;
	
	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	
	protected Logger logger = LoggerFactory.getLogger(getClass());
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return assetSoftwareDao;
	}
	
	/**
	 * 添加
	 * @param info
	 * @return
	 */
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	@EscOptionLog(module=SystemModule.assetSoftware, opType=ESCLogOpType.INSERT, table="assets_software_library", option="新增名称为{name}的软件资产记录。")
	public boolean add(Map info){
		String name = info.get("name") != null ? info.get("name").toString() : "";
		if (StringUtils.isNotEmpty(name)) {
			Map map = new HashMap();
			map.put("name", name);
			if (assetSoftwareDao.isExist(map)) {
				throw new EscServiceException("软件名称已经存在！");
			}
		}
		
		/*Calendar cal = Calendar.getInstance();
		int year = cal.get(Calendar.YEAR);
		String code = businessNumberDao.saveOrUpdate("RJZC", String.valueOf(year), "%04d");*/
		info.put("code", IDGenerationManager.nextId("assetsSoftCode"));
		return super.add(info);
	}
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		UTMap<String, Object> utmap = super.getById(id);
		return utmap;
	}
	

	/**
	 * 修改
	 * @param info
	 * @return
	 */
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	@EscOptionLog(module=SystemModule.assetSoftware, opType=ESCLogOpType.UPDATE, table="assets_software_library", option="更新名称为{name}的软件资产记录。")
	public boolean updateById(Map info){
		return super.updateById(info);
	}
	
	@Override
	@EscOptionLog(module=SystemModule.assetSoftware, opType=ESCLogOpType.DELETE, primaryKey="id={1}", table="assets_software_library", option="删除名称为{name}的软件资产记录。")
	public boolean deleteById(String id){
		
		return super.deleteById(id);
	}
	

	@Override
	public List<UTMap<String, Object>> getSoftwareList(Map param) {
		return assetSoftwareDao.getSoftwareList(param);
	}

	

	@Override
	public boolean leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String[] fileds = new String[] { "code", "name", "category", "subCategory", "brand", "version",
										"maintenance", "isSafeControl", "chargeUser", "beginDate", "endDate", "status"};
		
	/*	//替换下拉的值
		Map<String, String> fieldAndParamType = new HashMap<String, String>();
		fieldAndParamType.put(IAssetSoftwareDao.FIELD_CATEGORY, "softwareCategory"); //软件类别
		sysParamService.changeParamData(data, fieldAndParamType);*/
		
		
		String template = "excelOutTamplate.assetSoftware";	
		return UTExcel.leadingout(fileds, data, template, request, response);
	}
	
	
	/**
	 * 软件服务日期结束提前一月进行提醒
	 */
	@CronTimeTask(description="软件服务日期结束提前一月进行提醒",cron="0 0 23 * * ?")
	@Override
	public void execute(){
		logger.info("~~~~~~~~~~~~~软件到期提醒定时任务");
		try {
				Date endDate = null;
				String title = "";
				String content = "";
	
				// 获取资产管理员
				Map<String, Object> param = new HashMap<String, Object>();
				param.put("signature", RoleUtils.ASSET_MANAGER);
				List<UTMap<String, Object>> suppliers = userService.getUserBaseInfo(param);
	
				List<String> userIds = new ArrayList<String>();
				for (UTMap<String, Object> utMap : suppliers) {
					userIds.add((String) utMap.get("id"));
				}
	
				List<UTMap<String, Object>> list = assetSoftwareDao.getSoftwareList(null);
				Calendar cal = Calendar.getInstance();
				cal.add(Calendar.MONTH, 1);
	
				for (UTMap<String, Object> utMap : list) {
					if (utMap.get("endDate") != null) {
						endDate = sdf.parse((String) utMap.get("endDate"));
						if (cal.getTime().after(endDate) && new Date().before(endDate)) { // 超过结束日期不提醒了。
							// userId = (String)utMap.get("chargeId"); //负责人
	
							title = "软件【" + (String) utMap.get("name") + "】到期提醒";
	
							// 软件【软件名称】将于【服务结束日期】到期，请及时处理！详情请登录【系统地址】查看
							content = "软件【" + (String) utMap.get("name") + "】将于【"+ sdf.format(endDate) + "】到期，请及时处理！";
									//+ "详情请登录【"+ systemAddress + "】查看。";
							
							messageSend.sendMessage(userIds, title, content,"email", "system");
						}
					}
				}

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

	@Override
	public boolean leadingin(String filePath, Map<String, Object> param) throws Exception {
		
		String[] cellArray = new String[] { 
				"软件名称*（长度：0-20）", 
				"软件类别*", 
				"软件子类别", 
				"简称*（长度：0-20）",
				"厂商/品牌*（长度：0-20）", 
				"版本号*（长度：0-20）", 
				"采购合同", 
				"是否维保*", 
				"维保合同", 
				"负责人*", 
				"服务开始日期*（格式：yyyy/MM/dd）", 
				"服务结束日期（格式：yyyy/MM/dd）", 
				"使用部门*", 
				"是否国产*", 
				"状态*", 
				"软件介绍*（长度：0-500）"
		};
		int[] lengthArr = {20, 0, 0, 20, 20, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 500};
		String [] fileds = new String[] {	"name", "category", "subCategory", "shortName",
											"brand", "version", "agreementId", "maintenance",
											"maintainContract", "chargeId", "beginDate", "endDate",
											"useDepartIds", "isSafeControl", "status", "introducation"};
		
		List<Map> recordList = new ArrayList<Map>();
		boolean flag = true;
		
		Sheet sheet = UTExcel.getSheets(filePath)[0];
		int rowNum = sheet.getLastRowNum();
		int cellNum = fileds.length;
		
		//检查导入的字段标题
		try {
			List<String> realityCellllist = new ArrayList<String>();
			Row rowtitle = sheet.getRow(0);
			for (int j = 0; j < cellNum; j++) {
				realityCellllist.add(rowtitle.getCell(j).getStringCellValue());
			}
			String[] array = new String[realityCellllist.size()];
			if(!UTExcel.excelValidateByCell(cellArray, realityCellllist.toArray(array))){
				flag = false;
			}
		} catch (Exception e) {
			flag = false;
		}
		
		if(!flag) {
			throw new EscServiceException("导入失败，请选择正确的模板！");
		}
		
		UTMap<String,Object> map = null;
		
		//查询甲方人员
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("state", "1");
		params.put("userType", "1");
		List<UTMap<String,Object>> orgUser = sysUserService.getUserBaseInfo(params);
		StringBuilder error = new StringBuilder();
		for (int i = 1; i <= rowNum; i++) {
			Row row = sheet.getRow(i);
			map = new UTMap<String, Object>();
			for (int j = 0; j < cellNum; j++) {
				String cellValue = null;
				Cell cell = row.getCell(j);
				if (cell != null) {
					cell.setCellType(Cell.CELL_TYPE_STRING);
					cellValue = cell.getStringCellValue();
					cellValue = StringUtils.isNotBlank(cellValue) ? cellValue.trim() : null ;
				}
				
				//检查空
				if(j == 0 || j == 1 ||  j == 3|| j == 4 || j == 5 || j == 7 || j == 9 || j == 10 || j == 12 || j == 13 || j == 14 ||j == 15) {
					flag = StringUtils.isEmpty(cellValue) ? false : true;
					if (!flag) {
						error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "内容为空，请检查！" + "<br>");
					}
				}
				if (cellValue != null) {
					//长度校验
					if (lengthArr[j] != 0 && cellValue.length() > lengthArr[j]){
						error.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "内容长度超出限制，请检查！" + "<br>");
					}
					if(j == 1){ //软件类别
						Map<String,Object> category = new HashMap<String,Object>(); 
						category.put("name", cellValue);
						cellValue = softCategoryService.getCategoryIdByName(category);
						if(StringUtils.isEmpty(cellValue)){
							error.append("Excel内容错误，行号为" + (i+1) + "的软件类别在系统中不存在，请检查！" + "<br>");
						}
					}
					
					if(j == 2){ //软件子类别（非必填）
						if(cellValue != null){
							UTMap<String,Object> subCategory = softCategoryService.getSubCategoryByNameAndCategoryId(
									cellValue, String.valueOf(map.get("category")));
							if(null != subCategory){
								cellValue = String.valueOf(subCategory.get("id"));
							}else{
								error.append("Excel内容错误，行号为" + (i+1) + "的软件子类别在系统中不存在，请检查！" + "<br>");
							}
						}
					}
					
					if(j == 6){ //采购合同（非必填）
						if(cellValue != null){
							try {
								cellValue = getContractId(cellValue,i+1,"采购合同");
							}catch(EscServiceException e) {
								error.append(e.getMessage() + "<br>");
							}
						}
					}
					
					if(j == 7){ //是否维保
						if("是".equals(cellValue)){
							cellValue = "1";
						}else if ("否".equals(cellValue)){
							cellValue = "0";
						}
					}
					
					if(j == 8){ //维保合同（非必填）
						if(cellValue != null){
							try {
								cellValue = getContractId(cellValue,i+1,"维保合同");
							}catch(EscServiceException e) {
								error.append(e.getMessage() + "<br>");
							}
							
						}
					}
					
					if(j == 9){ //负责人
						try{
							cellValue = CommonUtils.getIdsByUserNameAndCodes(orgUser, cellValue);
						}catch(EscServiceException ex){
							error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "列，" + ex.getMessage() + "<br>");
						}
					}
					
					if(j == 10 && cellValue != null){ //服务开始时间
						if (!CommonUtils.validateDate(cellValue)) {
							error.append("Excel内容错误，行号为" + (i+1) + "的服务开始时间'" + cellValue + "'格式不正确，请检查！" + "<br>");
						}
					}
					
					if(j == 11){ //服务结束日期（非必填）
						if (cellValue != null) {
							if (!CommonUtils.validateDate(cellValue)) {
								error.append("Excel内容错误，行号为" + (i+1) + "的结束日期'" + cellValue + "'格式不正确，请检查！" + "<br>");
							}
							String beginDate = CommonUtils.replaceAll((String)map.get("beginDate"), "/", "-");
							String endDate = CommonUtils.replaceAll(cellValue, "/", "-");
							if (compareDate(beginDate, endDate) > 0) {	
								error.append("Excel内容错误，行号为" + (i+1) + "的结束日期早于开始日期，请检查！" + "<br>");
							}
						}
					}
					
					if(j == 12 && cellValue != null){ //使用部门
						cellValue = cellValue.replaceAll("，", ",");
						String[] depts = cellValue.split(",");
						String orgIds = "";
						for (String string : depts) {
							if(string.contains("/")){
								string = string.replaceAll("!","/");
								orgIds += orgDao.getIdLongName(string)+ ",";
							}else{
								error.append("Excel内容错误，行号为" + (i+1) + "的使用部门格式不对，请检查！" + "<br>");
							}
						}
						if ((orgIds == null) ? false : (orgIds.length() > 0)) {
							cellValue = orgIds.substring(0, orgIds.lastIndexOf(","));
						}
					}
					
					if(j == 13){ //是否国产
						if("是".equals(cellValue)){
							cellValue = "1";
						}else if ("否".equals(cellValue)){
							cellValue = "0";
						}
					}
					
					if(j == 14){ //状态
						if("待启用".equals(cellValue)){
							cellValue = "1";
						}else if("正在使用".equals(cellValue)){
							cellValue = "2";
						}else if("维护期".equals(cellValue)){
							cellValue = "3";
						}else if("停用".equals(cellValue)){
							cellValue = "4";
						}else{
							error.append("Excel内容错误，行号为" + (i+1) + "的状态不对，请检查！" + "<br>");
						}
					}
				}
				map.put(fileds[j], cellValue);
			}
			//编号
			/*Calendar cal = Calendar.getInstance();
			int year = cal.get(Calendar.YEAR);
			String code = businessNumberDao.saveOrUpdate("RJZC", String.valueOf(year), "%04d");*/
			map.put("code", IDGenerationManager.nextId("assetsSoftCode"));
			
			//排序字段
			map.put("operation", System.currentTimeMillis()); 
			recordList.add(map);
		}
		if (StringUtils.isNotEmpty(error.toString())) {
			throw new EscServiceException(error.toString());
		}
		//保存到数据库
		flag = adds(recordList);
		return flag;
	}
	
	
	/**
	 * 判断字符串是否是日期格式 (yyyy-MM-dd)
	 * @param str
	 * @return
	 */
	private boolean isValidDate(String str) {
		try {
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			format.setLenient(false);
			format.parse(str); 
			return true;
		} catch (ParseException e) {
			return false;
		}
	}
	
	
	/**
	 * 比较两个日期大小
	 * @param dateStr1
	 * @param dateStr2
	 * @return 如果dateStr1小于dateStr2，返回-1；如果dateStr1大于dateStr2，返回1；如果dateStr1等于dateStr2，返回0。
	 * @throws EscServiceException
	 */
	private int compareDate(String dateStr1, String dateStr2) throws EscServiceException {
		try {
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Date date1 = format.parse(dateStr1);
			Date date2 = format.parse(dateStr2);
			if (date1.getTime() < date2.getTime()) {
				return -1;
			}
			else if (date1.getTime() > date2.getTime()) {
				return 1;
			}
			else {
				return 0;
			}
		} catch (ParseException e) {
			throw new EscServiceException("日期比较时出错");
		}
	}
	
	
	private String getContractId(String contractNameAndContractCodes, int lineNum, String title) {
		Map<String, Object> param = new HashMap<String, Object>();
		String returnIds = "";
		String tip = "Excel内容错误，行号为" + (lineNum + 1)+ "的" + title;
		try {
			if((contractNameAndContractCodes == null) ? false : (contractNameAndContractCodes.length() > 0)) {
				for (String contractNameAndContractCode : StringUtils.split(contractNameAndContractCodes, ",")) {
						String[] nameAndCode = contractNameAndContractCode.split("/", 2);
						String name = nameAndCode[0];
						String code = "";
						if(nameAndCode.length == 2) {
							code = nameAndCode[1];
						}
						
						List<UTMap<String, Object>> contracts = null;
						param.clear();
						if(StringUtils.isNotEmpty(name)){
							param.put("agreementName", name);
						}
						if(StringUtils.isNotEmpty(code)){
							param.put("agreementCode", code);
						}
						contracts = assetsAgreementInfoService.getListMaps(param, "id");
						if(contracts == null || contracts.size() == 0) {
							throw new EscServiceException(tip + ":"
									+ contractNameAndContractCode
									+"在系统中不存在，请检查！");
						}
						if(contracts.size() > 1) {
							throw new EscServiceException(tip + ":系统存在重名的合同【"+contractNameAndContractCode+"】，无法匹配，请加入用户编号！");
						}
						UTMap<String, Object> contract = contracts.get(0);
						
						if((returnIds == null) ? false : (returnIds.length() > 0)) {
							returnIds += ",";
						}
						returnIds += (String) contract.get("id");
				}
			}
		} catch (EscServiceException e) {
			throw e;
		} catch (Exception e) {
			logger.error("Exception",e);
			throw new EscServiceException(tip + "格式不正确，请检查！");
		}

		return returnIds;
	}
	
	@Resource
	private ISysOrgDao orgDao;
	
	@Resource
	private ISysUserService sysUserService;
	
	@Resource
	private IAssetsAgreementInfoService assetsAgreementInfoService;

}
