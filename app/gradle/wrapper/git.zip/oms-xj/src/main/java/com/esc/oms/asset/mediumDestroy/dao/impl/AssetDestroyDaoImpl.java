package com.esc.oms.asset.mediumDestroy.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.asset.mediumDestroy.dao.IAssetDestroyDao;
@Repository
public class AssetDestroyDaoImpl extends BaseOptionDao implements IAssetDestroyDao{
	

	@Override
	public String getTableName() {
		return "assets_medium_destroy";
	}

	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params), pageBean, null);
	}
	
	public List<UTMap<String, Object>> getListMaps(Map param) {
		return super.getListBySql(getSearchSql(param));
	}
	
	@Override
	public UTMap<String, Object> getById(String id){
		return super.getOneBySql(getSearchByIdSql(id));
	}
	
	public String getName(String id) {
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT amd.name ");
		sql.append(" FROM assets_medium_destroy amd ");
		sql.append(" WHERE amd.id = '"+id+"'");
		return (String) super.searchOneBySql(sql.toString(), null);
	}

	public int getMaxDestroyId() {
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT MAX(destroyId) FROM assets_medium_destroy");
		Object obj = super.searchOneBySql(sql.toString(), null);
		if (null == obj) {
			return 0;
		}
		return (int) obj;
	}
	
	@Override
	public List<UTMap<String, Object>> getAssetsList(Map param) {
		return super.getListBySql(getSearchSql(param));
	}


	private String getSearchByIdSql(String id){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT " );
		sql.append(" DISTINCT amd.id,amd.name,amd.source,amd.code,amd.departId,amd.destroyCode,amd.pnCode, ");
		sql.append(" amd.mediumType,amd.classification,amd.classificationCode,amd.assetId,amd.destroyTime,");
	    sql.append(" amd.destroyMode,amd.destroyReason,amd.createTime,amd.createUser,amd.updateTime,amd.updateUser, ");
	    sql.append(" amd.status,amd.workflowInstanceId,so.name departName, ");
	    sql.append(" amd.destroyAddress,amd.destroyNum,amd.destroyId,amd.destroyName,amd.destroyModel, ");
	    sql.append(" t2.name destroyAddressName ");
	    sql.append(" FROM assets_medium_destroy amd ");
		sql.append(" LEFT JOIN sys_org so ON so.id = amd.departId ");
		sql.append(" left join assets_place t2 on amd.destroyAddress=t2.id ");
		sql.append(" WHERE amd.id = '"+id+"'");
		sql.append(" order by amd.createTime desc ");
		return  sql.toString();
	}
	
	
	//获取待审列表
	public void getPendApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT " );
			sql.append(" DISTINCT amd.id,amd.name,amd.source,amd.code,amd.departId,amd.classificationCode,amd.assetId,amd.pnCode, ");
			sql.append(" amd.mediumType,amd.classification,amd.destroyTime,amd.destroyCode,");
		    sql.append(" amd.destroyMode,amd.destroyReason,amd.createTime,amd.createUser,amd.updateTime,amd.updateUser, ");
		    sql.append(" amd.status,amd.workflowInstanceId, ");
			sql.append(" t4.currentExecutor as auditors,t4.currentStepName,so.name departName,amd.destroyName,amd.destroyModel,t2.name destroyAddressName ");
		    sql.append(" FROM assets_medium_destroy amd ");
			sql.append(" LEFT JOIN sys_org so ON so.id = amd.departId ");
			sql.append(" left join assets_place t2 on amd.destroyAddress=t2.id ");
			sql.append(" left join sys_workflow_instance t4 on amd.workflowInstanceId=t4.id  ");
			sql.append(" where  FIND_IN_SET('"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"',t4.currentExecutor)  ");
			setSqlParam(sql, params);
			sql.append(" order by amd.createTime desc ");
			super.getPageListMapBySql(sql.toString(), pageBean, null);		
	}

	//获取已审列表
	@Override
	public void getAlreadyApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT " );
			sql.append(" DISTINCT amd.id,amd.name,amd.source,amd.code,amd.departId,amd.classificationCode,amd.assetId,amd.pnCode, ");
			sql.append(" amd.mediumType,amd.classification,amd.destroyTime,");
		    sql.append(" amd.destroyMode,amd.destroyReason,amd.createTime,amd.createUser,amd.updateTime,amd.updateUser, ");
		    sql.append(" amd.status,amd.workflowInstanceId,amd.destroyCode,");
			sql.append(" t4.optionUserId as optionUserId,so.name departName,amd.destroyName,amd.destroyModel,t2.name destroyAddressName ");
		    sql.append(" FROM assets_medium_destroy amd ");
			sql.append(" LEFT JOIN sys_org so ON so.id = amd.departId ");
			sql.append(" left join assets_place t2 on amd.destroyAddress=t2.id ");
			sql.append(" left join sys_workflow_audit_history t4 on amd.workflowInstanceId=t4.instanceId ");
			sql.append(" where FIND_IN_SET('"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"',t4.optionUserId) and t4.nodeName<>'开始' " );
			setSqlParam(sql, params);
			sql.append(" order by amd.createTime desc ");
			super.getPageListMapBySql(sql.toString(), pageBean, null);
	}

	
	
	private String getSearchSql(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT " );
		sql.append(" DISTINCT amd.id,amd.name,amd.source,amd.code,amd.departId,amd.classificationCode,amd.assetId,amd.pnCode, ");
		sql.append(" amd.mediumType,amd.classification,amd.destroyTime,amd.destroyCode,");
	    sql.append(" amd.destroyMode,amd.destroyReason,amd.createTime,amd.createUser,amd.updateTime,amd.updateUser, ");
	    sql.append(" amd.status,amd.workflowInstanceId,so.name departName,amd.destroyName,amd.destroyModel,t2.name destroyAddressName ");
	    sql.append(" FROM assets_medium_destroy amd ");
		sql.append(" LEFT JOIN sys_org so ON so.id = amd.departId ");
		sql.append(" left join assets_place t2 on amd.destroyAddress=t2.id ");
		sql.append(" WHERE 1=1 ");
		setSqlParam(sql,params);
		sql.append(" order by amd.createTime desc");
		return  sql.toString();
	}
	
	private void setSqlParam(StringBuilder sql,Map<String, Object> params) {
		if(params!=null && params.size()>0){
			if(params.get("name")!=null && StringUtils.isNotEmpty(params.get("name").toString())){
				sql.append(" AND amd.name like '%"+params.get("name").toString().trim()+"%'");
			}
			if(params.get("startdTime")!=null && StringUtils.isNotEmpty(params.get("startdTime").toString())){
				sql.append(" AND amd.destroyTime >= '"+params.get("startdTime").toString().trim()+"'");
			}
			if(params.get("enddTime")!=null && StringUtils.isNotEmpty(params.get("enddTime").toString())){
				sql.append(" AND amd.destroyTime <= '"+params.get("enddTime").toString().trim()+"'");
			}
//			if(params.get("destroyTime")!=null && StringUtils.isNotEmpty(params.get("destroyTime").toString())){
//				sql.append(" AND amd.destroyTime = '"+params.get("destroyTime").toString().trim()+"'");
//			}
			if(params.get("status")!=null && StringUtils.isNotEmpty(params.get("status").toString())){
				sql.append(" AND amd.status = '"+params.get("status").toString().trim()+"' ");
			}
			if(params.get("statusStr")!=null && StringUtils.isNotEmpty(params.get("statusStr").toString())){
				sql.append(" AND find_in_set( amd.status , '"+params.get("statusStr").toString().trim()+"') ");
			}
		}
	}

	@Override
	public List<UTMap<String, Object>> getAssetsList() {
		// TODO Auto-generated method stub
		return super.getListBySql(this.getAssetsListSql(), null);
	}
	
	
	private String getAssetsListSql() {
		StringBuilder sql = new StringBuilder();
		sql.append(" select t1.*, t2.name locationName from assets_material_info t1 ");
		sql.append(" left join assets_place t2 on t1.location=t2.id ");
		sql.append(" where t1.serialNum is not null and t1.serialNum <> '' ");
		sql.append(" and (t1.deleteFlag != 1 OR t1.deleteFlag IS NULL) ");
		sql.append(" and ifnull(t1.isScrap, '0') = '0' ");
		sql.append(" and (t1.registStatus IS NULL OR t1.registStatus = '2') ");
				
		return sql.toString();
	}
	
	
	
}
