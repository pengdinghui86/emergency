package com.esc.oms.asset.physicalRegist.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.web.bind.annotation.RequestParam;

public interface IPhysicalRegistDao extends IBaseOptionDao{
	
	public List<UTMap<String, Object>> getAssetBycodeAndId(String code,String id);
	public void getPendPageList( Map<String, Object> params, UTPageBean pageBean);
	public void getAlreadyApprovalPageList( Map<String, Object> params, UTPageBean pageBean);
	public void getPageInfo(Map params, UTPageBean pageBean) throws Exception;
}
