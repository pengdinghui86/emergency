package com.esc.oms.outsource.outperson.controller;

import com.esc.oms.outsource.outperson.service.IOutSourcePersonResumeInfoService;
import com.esc.oms.util.CommonUtils;
import freemarker.cache.StringTemplateLoader;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import net.sf.json.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.esc.framework.EscPropertyHolder;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.upload.service.ISysFileService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTListResult;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.springframework.web.bind.annotation.*;
import sun.misc.BASE64Encoder;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/resumeInfo")
public class OutSourcePersonResumeInfoController extends BaseOptionController {

	@Resource
	private IOutSourcePersonResumeInfoService outSourcePersonResumeInfoService;
	
	@Resource
	private ISysFileService fileService;
	
	@Override
	public IBaseOptionService optionService() {
		return outSourcePersonResumeInfoService;
	}
	
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){  
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			outSourcePersonResumeInfoService.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	@RequestMapping(value="getPageList")  
    @ResponseBody
    public UTPageBean getPageList(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		List<UTMap<String,Object>> list = new ArrayList<UTMap<String,Object>>();
		try{
//			outSourcePersonResumeInfoService.getPageInfo(pageBean, params);
//			list = outSourcePersonResumeInfoService.getPageList(pageBean, params);
			outSourcePersonResumeInfoService.getPageList(pageBean, params);
//			pageBean.setRows(list);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
        return pageBean;
    }
	
	/**
	 * 待推荐简历列表
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getRecommendResumeList")  
    @ResponseBody
    public UTListResult getRecommendResumeList(@RequestParam Map<String, Object> param){  
//		return UTListResult.getListResult(optionService().getListMaps(param));
		UTListResult result = new UTListResult();
		try{
			List<UTMap<String, Object>> list = outSourcePersonResumeInfoService.getRecommendResumeList(param);
			result.setRows(list);
			result.setTotal(list.size());
		}catch(Exception e){
			logger.error("Exception", e);
		}
		return result;
    }
	
	
	/**
	 * 新增，需要返回一个id给前台的其他标签
	 * @param info
	 * @return
	 */
	@RequestMapping(value="add",method =RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> add(@RequestBody  Map<String, Object> map1){
		Map<String, Object> coloneParam = CommonUtils.clone(map1);
		try{ 
    		boolean result = optionService().add(coloneParam);
    		if(result){
    			coloneParam.put("success", true);
    			coloneParam.put("msg", "操作成功！");
    		}else{
    			coloneParam.put("success", false);
//        		info.put("msg", "操作失败！");
    		}   		
    	}catch(EscServiceException e){
    		coloneParam.put("success", false);
    		coloneParam.put("msg", e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		coloneParam.put("success", false);
    		coloneParam.put("msg", "操作失败！");
    	}
       return coloneParam;
	}
	
	
	
	/**
	 * 从excel导入
	 * 
	 * @param params
	 * @param filePath
	 * @return
	 */
	@RequestMapping(value = "leadingin")
	@ResponseBody
	public UTMap<String, Object> leadingin(@RequestParam Map<String, Object> param, String filePath) {
		UTMap<String, Object> utMap = new UTMap<String, Object>();
		try {
			utMap.put("success", outSourcePersonResumeInfoService.leadingin(filePath, param));
			utMap.put("msg", "导入成功！");
		} catch (EscServiceException e) {
			logger.error("EscServiceException",e);
			utMap.put("success", false);
			utMap.put("msg", e.getMessage());
		} catch (Exception e) {
			logger.error("EscServiceException",e);
			utMap.put("success", false);
			utMap.put("msg", "导入失败");
		}
		return utMap;
	}
	
	
	@RequestMapping(value = "leadingoutList")
	public void leadingoutList(@RequestParam Map<String, Object> param, HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();

			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = null;
			if (info != null) {
				jsonBean = JSONObject.fromObject(info);
			}

			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = outSourcePersonResumeInfoService.getListMaps(jsonBean);
			} else {
				// 根据条件 导出当前
				outSourcePersonResumeInfoService.getPageInfo(utPageBean, jsonBean);
				data = utPageBean.getRows();
			}
			if (null != data && !data.isEmpty()) {
				for (int i=0;i<data.size();i++) {
					UTMap<String, Object> item = data.get(i);
					item.put("birthday", CommonUtils.replaceAll((String)item.get("birthday"), "-", "/"));
					item.put("finishSchoolDate", CommonUtils.replaceAll((String)item.get("finishSchoolDate"), "-", "/"));
				}
			}
			
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			outSourcePersonResumeInfoService.leadingout(data, request, response);
		} catch (Exception e) {
			logger.error("Exception", e);
		}
	}
	
	@RequestMapping(value = "leadingout")
	public void leadingout(@RequestParam Map<String, Object> map1,
			HttpServletRequest request,
			HttpServletResponse response) {
		logger.info("开始导出简历。。。");
		
		Map<String,Object> param = CommonUtils.clone(map1);
		try {
			String name = (String) param.get("name");
			String report = getWord(param);
			logger.info(CommonUtils.vaildLog("简历内容："+report));
			//输出到response
			response.setContentType("application/msword;charset=utf-8");
			response.setHeader("Content-disposition","attachment; filename=" + new String((name+"_简历.doc").getBytes("GBK"), "ISO8859-1"));
			PrintWriter writer = response.getWriter();
			writer.write(report);
			
		} catch (Exception e) {
			logger.error("Exception", e);
		}
	}
	
	private String getWord(Map<String, Object> param){
		String id = (String) param.get("id");	
		Map<String, Object> dataModel = outSourcePersonResumeInfoService.getExportDataById(id);	
		logger.info("dataModel:"+dataModel.toString());		
		String img = dataModel.get("img")==null?"":dataModel.get("img").toString();
		String path = EscPropertyHolder.instance.getProperty("wordOutTemplate.resumeInfo_without_img");
		String ftlWordPath = "formTemp/resume_without_img.ftl";
		if(!StringUtils.isEmpty(img)){
			ftlWordPath = "formTemp/resume_word.ftl";
			path = EscPropertyHolder.instance.getProperty("wordOutTemplate.resumeInfo");
			UTMap<String,Object> map = fileService.getById(img);
			String filePath = map.get("filePath")==null?null:map.get("filePath").toString();
			dataModel.put("img", getImageStr(filePath));
		}			
		//获取导出文件名称
		 int l=path.lastIndexOf("/");
		 int j=path.lastIndexOf("--");
		 String fileName="";
		 String title="";		 
		 if(j>0){
			 fileName=path.substring(j+2);
			 title=fileName;
			 path=path.substring(0,j);
			 fileName=fileName+path.substring(path.lastIndexOf("."));
		 }else {
			 fileName=path.substring(l+1);
			 title=fileName.substring(0,fileName.lastIndexOf("."));
		 }
		 
		URL url = this.getClass().getResource(path);
		String ftlPath = url.getPath();
		String toolPath=EscPropertyHolder.instance.getProperty("pdf.toPdfToolPath");
		boolean islinux=toolPath.indexOf("linux")>-1;
		if(!islinux){
			if(ftlPath.startsWith("/")){
				ftlPath = ftlPath.substring(1);
			}	
		}	
		logger.info(CommonUtils.vaildLog("ftlPath:"+ftlPath));
		String ftlName = ftlPath.substring(ftlPath.lastIndexOf("/")+1,ftlPath.length());
		logger.info(CommonUtils.vaildLog("模板名称："+ftlName));
//		ftlPath = ftlPath.substring(0,ftlPath.lastIndexOf("/"));		
		String report = "";		
		InputStream  inputStream = null;
		Template template;
		ByteArrayOutputStream byteArrayOutputStream = null;
		try {

			Configuration cfg = new Configuration();
			logger.info(CommonUtils.vaildLog("模板路径："+ftlPath));
			org.springframework.core.io.Resource wordPathRource = new ClassPathResource(ftlWordPath);
            StringTemplateLoader stringLoader = new StringTemplateLoader();
            inputStream = wordPathRource.getInputStream();
            byteArrayOutputStream = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) != -1) {
            	byteArrayOutputStream.write(buffer, 0, length);
            }
            String templateContent = byteArrayOutputStream.toString(StandardCharsets.UTF_8.name());
            logger.info(CommonUtils.vaildLog("templateContent："+templateContent));
            stringLoader.putTemplate("myTemplate",templateContent);
            cfg.setTemplateLoader(stringLoader);
			template = cfg.getTemplate("myTemplate","utf-8");
			logger.info(CommonUtils.vaildLog("模板数据："+dataModel.toString()));
			//将数据跟模板合并			
			report = FreeMarkerTemplateUtils.processTemplateIntoString(template, dataModel);
			
		}catch (IOException e) {
			logger.error("IOException",e);
		}catch (TemplateException e) {
			logger.error("TemplateException",e);
		}finally {
			if(inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					logger.error("IOException",e);
				}
			}
			if(byteArrayOutputStream != null) {
				try {
					byteArrayOutputStream.close();
				} catch (IOException e) {
					logger.error("IOException",e);
				}
			}
		}
		return report;
	}
	
	private String getImageStr(String filePath) {		
		String imgFile = filePath;
		InputStream in = null;
		byte[] data = null;
		String rootPath = EscPropertyHolder.instance.getProperty("leadingpath");
		try {
			in = new FileInputStream(rootPath+imgFile);
			data = new byte[in.available()];
			in.read(data);
			in.close();
		} catch (FileNotFoundException e) {
			logger.error("FileNotFoundException",e);
			return null; 
		}   catch (IOException e) {
			logger.error("IOException",e);
			return null; 
		}finally {
			if(in != null){
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		BASE64Encoder encoder = new BASE64Encoder();
		return encoder.encode(data);
	}

}
