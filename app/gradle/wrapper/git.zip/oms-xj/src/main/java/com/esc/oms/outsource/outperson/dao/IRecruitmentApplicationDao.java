package com.esc.oms.outsource.outperson.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

/**
 * 人力资源申请
 * @author djj
 * @date   2016-07-18
 */
public interface IRecruitmentApplicationDao extends IBaseOptionDao {
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_CODE= "code";
	public static final String  FIELD_NAME = "name";
	public static final String  FIELD_APPLY_USER_ID = "applyUserId";
	public static final String  FIELD_APPLY_USER_NAME = "applyUserName";
	public static final String  FIELD_APPLY_DATE = "applyDate";
	public static final String  FIELD_APPLY_DEPART_ID = "applyDepartId";
	public static final String  FIELD_APPLY_DEPART_NAME = "applyDepartName";
	public static final String  FIELD_APPLY_DEPART_LONG_NAME = "applyDepartLongName";	
	public static final String  FIELD_APPLY_REASON = "applyReason";
	public static final String  FIELD_APPLY_REASON_REMARK = "applyReasonRemark";
	public static final String  FIELD_IS_LIMIT_SUPPLIER = "isLimitSupplier";
	public static final String  FIELD_LIMIT_SUPPLIERS = "limitSuppliers";
	public static final String  FIELD_LIMIT_SUPPLIER_NAMES = "limitSupplierNames";
	public static final String  FIELD_LIMIT_REASON = "limitReason";
	public static final String  FIELD_DISTRIBUTE_SUPPLIERS = "distributeSuppliers";
	public static final String  FIELD_DISTRIBUTE_REMARK = "distributeRemark";
	public static final String  FIELD_STATUS = "status";
	public static final String  FIELD_CREATE_USER = "createUser";
	
	//-2。终止 -1。驳回 1.待提交 2.待审批  3.审批中 4.审批完成待分发 5.已分发待推送 6.处理中  9.完成
	public static final String STATUS_PEND_SUBMIT = "1";
	public static final String STATUS_PEND_AUDIT = "2";
	public static final String STATUS_AUDITING = "3";
	public static final String STATUS_PEND_DISTRIBUTE = "4";
	public static final String STATUS_PEND_RECOMMEND = "5";
	public static final String STATUS_OPETATION = "6";
	public static final String STATUS_FINISH = "9";
	public static final String STATUS_REJECT = "-1";
	public static final String STATUS_TERMINATE = "-2";
	
	public static final String TASK_APPLICATION_DISTRIBUTE = "人力资源申请单分发";
	
	
	
	public List<UTMap<String, Object>> getPageList(UTPageBean pageBean,Map params);

	public void getPendApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params);

	public void getAlreadyApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params);
	/**
	 * 查询人力外包供应商
	 * @param param
	 * @return
	 */
	public List<UTMap<String, Object>> getManpowerSuppliers(Map<String, Object> param);
	/**
	 * 查询人力外包人力类型
	 * @param param
	 * @return
	 */
	public List<UTMap<String, Object>> getManpowerCategorys(Map<String, Object> param);
	/**
	 * 部门人力需求报表
	 * @param params
	 * @return
	 */
	public List<UTMap<String, Object>> getOrgReport(Map<String, Object> params);

	public boolean addReviewFile(Map<String, Object> reviewFile);

	public UTMap<String, Object> getReviewFile(String applyId);

	public UTMap<String, Object> getReviewFileById(String id);

	public List<UTMap<String, Object>> getProjectRes(Map<String, Object> param);

	public boolean deleteProjectResByApplyId(String applyId);

	public boolean addProjectRes(Map<String, Object> param);
}
