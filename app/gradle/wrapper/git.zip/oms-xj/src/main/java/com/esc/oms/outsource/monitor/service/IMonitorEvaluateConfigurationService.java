package com.esc.oms.outsource.monitor.service;

import java.util.Map;

import org.esc.framework.service.IBaseOptionService;

/**
 * 服务监控评估配置
 * @author owner
 *
 */
public interface IMonitorEvaluateConfigurationService extends IBaseOptionService{
	
	/**
	 * 总评估或者修改总评估
	 * @param info
	 * @return
	 */
//	public boolean evaluate(Map info);
	
	/**
	 * 关闭
	 * @param info
	 * @return
	 */
	public boolean close(Map info);
	
	/**
	 * 根据ID 获取（评估结果需要的数据接口）
	 * @param info
	 * @return
	 */
//	@UploadQueryMark//aop拦截绑定上传文件的数据关系
//	public UTMap<String, Object> getByIdToAccessResult(String id);
	
	/**
	 * 暂停
	 * @param info
	 * @return
	 */
	public void pause(Map<String, Object> info);
	
	/**
	 * 启用
	 * @param info
	 * @return
	 */
	public void enabled(Map<String, Object> info);
	
	/**
	 * 生成数据
	 */
	public void generate();
	
}
