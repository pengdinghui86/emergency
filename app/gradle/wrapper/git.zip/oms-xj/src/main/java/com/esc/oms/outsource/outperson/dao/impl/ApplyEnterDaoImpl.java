package com.esc.oms.outsource.outperson.dao.impl;

import com.esc.oms.outsource.outperson.dao.IApplyEnterDao;
import com.esc.oms.util.RoleUtils;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

;
@Repository
public class ApplyEnterDaoImpl extends BaseOptionDao implements IApplyEnterDao{
	

	@Override
	public String getTableName() {
		return "outsourc_apply_enter_info";
	}

	public boolean isExist(Map param){
		StringBuilder sqlcount = new StringBuilder();
		sqlcount.append("select tb.* from outsourc_apply_enter_info  tb  where 1=1   ");
		for (Object key : param.keySet()) {
			if(StringUtils.equals("loginName", key.toString())){
				sqlcount.append(" and  tb." + key.toString() + "= '" + param.get(key) + "' ");
			}else{
				sqlcount.append(" and  tb." + key.toString() + "= '" + param.get(key) + "' ");
			}
		}
		sqlcount.append(" and( tb.status <4 or tb.status =5 )  ");
		List<UTMap<String, Object>> list = super.getListBySql(sqlcount.toString(), null);
		
		Integer count = list == null ? 0 : list.size();
		/*SQLQuery sqlQuery = this.getSession().createSQLQuery(sqlcount.toString());
		this.setParamsToSql(sqlQuery, param);
		Object object=sqlQuery.uniqueResult();
		Integer count = object!=null?Integer.valueOf(object.toString()):null;*/
		return count>0;
	}
	
	public UTMap<String, Object> getById(String id){
		StringBuilder sql=new StringBuilder();
		sql.append(" select sq.*,sbi.name supplierName,o.longName  departmentName, pi.img projectImg from outsourc_apply_enter_info sq ");
		sql.append(" left  join supplier_base_info sbi  on sq.supplierId=sbi.id ");
		sql.append(" left join sys_org o on  o.id=sq.departmentId");
		sql.append(" left join project_info pi on pi.id=sq.projectId ");
		sql.append(" where sq.id='"+id+"'   ");
		UTMap<String, Object> info= super.getOneBySql( sql.toString(),null);
		Object userIdObject=info.get(FIELD_CONFIMUSERID);
		if(userIdObject!=null && StringUtils.isNotEmpty(userIdObject.toString())){
			Object userName=super.searchOneBySql("select u.name from sys_user u where u.id='"+userIdObject.toString()+"'",null);
			info.put(FIELD_CONFIMUSERNAME, userName);
		}
		Object projectIdObject=info.get("projectId");
		if(projectIdObject!=null && StringUtils.isNotEmpty(projectIdObject.toString())){
			Object projectName=super.searchOneBySql("SELECT name from project_info where id='"+projectIdObject.toString()+"'",null);
			info.put("projectName", projectName);
		}
//		String enterUserId = (String) info.get(FIELD_ENTERUSERID);
//		if (StringUtils.isNotEmpty(enterUserId)) {
//			Object img=super.searchOneBySql("select u.img from sys_user u where u.id='"+enterUserId+"'",null);
//			info.put("img", img);
//		}
		
		return info;
	}
	
	@Override
	public List<UTMap<String, Object>> searchInfo(Map<String, Object> params) {
		return super.getListBySql(toSearchSql(params));
	}
	
	@Override
	public void searchInfoPage( UTPageBean pageBean,Map<String, Object> params) {
		getPageListMapBySql(toSearchSql(params), pageBean, null);
		//return pageBean;
	}
	
	//获取待审列表
	public void getPendApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select DISTINCT(t1.id)  as id, t2.name as supplierName,");
		sql.append("        t1.enterUserId as enterUserId, t1.enterUserName as enterUserName, t1.processId as workflowInstanceId,t1.processStep as processStep, ");
		sql.append(" t1.enterDate as enterDate, t1.exitDate as exitDate,  t1.mobilePhone as mobilePhone, t1.email as email,su.img as img,  ");
		sql.append("        t1.`status` as `status`,t1.createUserId as createUserId, t1.createUser as createUser, t1.createTime as createTime,");
		sql.append(" t1.departmentId as departmentId, REPLACE( t3.longName,'!','/')    as departmentName, t1.remark, ");
		sql.append(" t4.currentExecutor as auditors,t4.currentStepName, ");
		sql.append(" t5.name projectName ");
		sql.append("  from outsourc_apply_enter_info t1 ");
		sql.append(" left join supplier_base_info t2 on t1.supplierId=t2.id ");
		sql.append(" left join sys_user su on t1.enterUserId=su.id");
		sql.append(" left join sys_workflow_instance t4 on t1.processId=t4.id  ");
		sql.append(" left join sys_org t3 on t1.departmentId=t3.id ");
		sql.append(" left join project_info t5 on t1.projectId=t5.id ");
//		//系统管理员和admin可以查看去全部数据
//		if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR)){
			sql.append(" where  FIND_IN_SET('"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"',t4.currentExecutor)  ");
	//	}
		setSqlParam(sql, params);
		sql.append(" order by t1.createTime desc ");
		super.getPageListMapBySql(sql.toString(), pageBean, null);		
	}

	//获取已审列表
	public void getAlreadyApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select DISTINCT(t1.id)  as id, t2.name as supplierName,");
		sql.append("        t1.enterUserId as enterUserId, t1.enterUserName as enterUserName, t1.processId as workflowInstanceId,t1.processStep as processStep, ");
		sql.append(" t1.enterDate as enterDate, t1.exitDate as exitDate,  t1.mobilePhone as mobilePhone, t1.email as email,su.img as img,  ");
		sql.append("        t1.`status` as `status`,t1.createUserId as createUserId, t1.createUser as createUser, t1.createTime as createTime,");
		sql.append(" t1.departmentId as departmentId,    REPLACE( t3.longName,'!','/')  as departmentName, t1.remark, ");
		sql.append(" t4.optionUserId as optionUserId, ");
		sql.append(" t5.name projectName ");
		sql.append("  from outsourc_apply_enter_info t1 ");
		sql.append("      join supplier_base_info t2 on t1.supplierId=t2.id ");
		sql.append(" left join sys_user su on t1.enterUserId=su.id");
		sql.append(" left join sys_workflow_audit_history t4 on t1.processId=t4.instanceId ");
		sql.append("      join sys_org t3 on t1.departmentId=t3.id ");
		sql.append("      join project_info t5 on t1.projectId=t5.id ");
		//系统管理员和admin可以查看去全部数据
	//	if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR)){
			sql.append(" where FIND_IN_SET('"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"',t4.optionUserId) and t4.nodeName<>'开始' " );
	//	}
		setSqlParam(sql, params);
		sql.append(" order by t1.createTime desc ");
		super.getPageListMapBySql(sql.toString(), pageBean, null);
	}

	private String toSearchSql(Map<String, Object> params) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select DISTINCT(t1.id)  as id, t2.name as supplierName, ");
		sql.append(" t1.departmentId as departmentId,    REPLACE( t3.longName,'!','/')  as departmentName,  ");
		sql.append(" t1.isKeyPerson, t1.isIn,su.img as img, ");
		sql.append("  t1.enterUserId as enterUserId, t1.enterUserName as enterUserName, t1.processId as workflowInstanceId,t1.processStep as processStep, ");
		sql.append(" t1.enterDate as enterDate, t1.exitDate as exitDate,  t1.mobilePhone as mobilePhone, t1.email as email,t1.remark,  ");
		sql.append("        t1.`status` as `status`,t1.createUserId as createUserId, t1.createUser as createUser, t1.createTime as createTime, ");
		sql.append(" t4.name projectName, su.code, t1.idCode ");
		sql.append("  from outsourc_apply_enter_info t1 ");
		sql.append(" left join supplier_base_info t2 on t1.supplierId=t2.id ");
		sql.append(" left join sys_user su on t1.enterUserId=su.id");
		sql.append(" left join sys_org t3 on t1.departmentId=t3.id ");
		sql.append(" left join project_info t4 on t1.projectId=t4.id ");
		sql.append(" where 1= 1 ");
		setSqlParam(sql, params);
		//系统管理员和admin可以查看去全部数据,外包管理员管理所有数据，
		if(EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR) || RoleUtils.isOutsourceManagerPerson()){
			
		}else if (EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.ACCESS_CONTROL_MANAGER)
				|| EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.NETWORK_MANAGER)
				|| EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.VIRTUAL_DESKTOP_MANAGER)) {
			sql.append(" and ( 1=0 ");
			
			if (EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.ACCESS_CONTROL_MANAGER)) {
				sql.append(" or exists ( select id from outsource_person_config opc where opc.userId=t1.enterUserId and paramValue='2') ");
			}
			if (EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.NETWORK_MANAGER)) {
				sql.append(" or exists ( select id from outsource_person_config opc where opc.userId=t1.enterUserId and paramValue in('4', 5) ) ");
			}
			
			if (EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.VIRTUAL_DESKTOP_MANAGER)) {
				sql.append(" or exists ( select id from outsource_person_config opc where opc.userId=t1.enterUserId and paramValue='3') ");
			}
			sql.append(") ");
			sql.append(" and t1.status='4' ");
		}
		//普通金融机构用户管理本人的申请，供应商用户管理本供应商的申请单
		else if(RoleUtils.isSupplierAdministrator() || RoleUtils.isSupplierLeaders()){
			sql.append(" and t1.supplierId='"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId()+"'");
		}
		else{
			sql.append(" and t1.enterUserId='"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"'");
		}
		sql.append(" order by t1.createTime desc ");
		
		return sql.toString();
	}
	
	
	private StringBuilder setSqlParam(StringBuilder sql,Map<String,Object> param){

		Map<String, String> p=UTMap.mapObjToString(param);
		String enterUserName =p.get("enterUserName");
		String status = p.get("status");
		String supplierName = p.get("supplierName");
		String enterUserId = p.get("enterUserId");
		String id = p.get("id");
		
	//	String applyDate = p.get("applyDate");
		if (StringUtils.isNotBlank(id)) {
			sql.append(" and t1.id = " + id);
		}

		if (StringUtils.isNotBlank(enterUserId)) {
			sql.append(" and t1.enterUserId = " + enterUserId);
		}
		
		if (StringUtils.isNotBlank(enterUserName)) {
			sql.append(" and t1.enterUserName  like '%" + enterUserName.trim()+"%'" );
		}
		
		if (StringUtils.isNotBlank(status)) {
			sql.append(" and t1.status = " + status.trim() );
		}
		
		if (StringUtils.isNotBlank(supplierName)) {
			sql.append(" and t2.name like '%" + supplierName.trim() + "%' ");
		}
		

		
		return sql;
	}
	

}
