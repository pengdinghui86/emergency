package com.esc.oms.exemple.dao;

import org.esc.framework.persistence.dao.IBaseOptionDao;

public interface ICrudDao extends IBaseOptionDao{
	public static final String  FIELD_ID= "id";
	public static final String  FIELD_CODE= "code";
	public static final String  FIELD_NAME= "name";
	public static final String  FIELD_PARAMTYPE= "paramType";
	public static final String  FIELD_STATE= "state";
	public static final String  FIELD_PARENTID= "parentId";
	public static final String  FIELD_SORT= "sort";
	public static final String  FIELD_REMARK= "remark";
	
}
