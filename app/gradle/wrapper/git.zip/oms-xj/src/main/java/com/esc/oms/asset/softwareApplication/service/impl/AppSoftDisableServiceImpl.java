package com.esc.oms.asset.softwareApplication.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.asset.softwareApplication.dao.IAppSoftDisableDao;
import com.esc.oms.asset.softwareApplication.service.IAppSoftDisableService;
import com.esc.oms.util.CommonUtils;


@Service
@Transactional
public class AppSoftDisableServiceImpl extends BaseOptionService implements IAppSoftDisableService {
	
	@Resource
	private IAppSoftDisableDao softDisableDao;

	@Override
	public List<UTMap<String, Object>> getSoftDisableList(Map param) {
		return softDisableDao.getSoftDisableList(param);
	}

	@Override
	public boolean leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		String[] fileds = new String[] { 
				IAppSoftDisableDao.FIELD_SOFTWAREID,  
				IAppSoftDisableDao.FIELD_DISABLEDATE,   
				IAppSoftDisableDao.FIELD_REASON,
				IAppSoftDisableDao.FIELD_SPARE
		};
		if (null != data && !data.isEmpty()) {
			for (int i=0;i<data.size();i++) {
				UTMap<String, Object> item = (UTMap<String, Object>) data.get(i);
				item.put(IAppSoftDisableDao.FIELD_DISABLEDATE, 
						CommonUtils.replaceAll((String) item.get(IAppSoftDisableDao.FIELD_DISABLEDATE), "-", "/"));
			}
		}
		String tamlate="excelOutTamplate.appSoftDisable";	
		return	UTExcel.leadingout( fileds, data, tamlate, request,response);
	}

	@Override
	public IBaseOptionDao getOptionDao() {
		return softDisableDao;
	}

}
