package com.esc.oms.outsource.outperson.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.upload.annotation.UploadQueryMarks;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.outperson.dao.IRecruitmentApplicationDao;
import com.esc.oms.outsource.outperson.dao.IRecruitmentResumeDao;
import com.esc.oms.outsource.outperson.service.IRecruitmentResumeService;
import com.esc.oms.system.templateconfiguration.dao.ITemplateConfigurationDetailDeputyDao;
import com.esc.oms.system.templateconfiguration.dao.ITemplateConfigurationDetailDeputyResultDao;
import com.esc.oms.system.templateconfiguration.service.ITemplateConfigurationDetailDeputyService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;
import com.esc.oms.util.ParamUtils;
import com.esc.oms.util.RoleUtils;

@Service
@Transactional
public class RecruitmentResumeServiceImpl extends BaseOptionService implements IRecruitmentResumeService{

	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private IRecruitmentResumeDao dao;
	
//	@Resource
//	private IRecruitmentApplicationService applyService;
	
	@Resource
	private IRecruitmentApplicationDao applyDao;

	@Resource
	private MessageSend messageService;
	
	@Resource
	private ISysUserService userService;
	
	@Resource
	private IUserTaskService userTaskService;
	
	//模板配置从属数据操作Service接口
	@Resource
	private ITemplateConfigurationDetailDeputyService templateConfigurationDetailDeputyService;
	
	//模板配置从属数据结果操作dao接口
	@Resource
	private ITemplateConfigurationDetailDeputyResultDao templateConfigurationDetailDeputyResultDao;
	
	@Resource
	private ITemplateConfigurationDetailDeputyDao templateConfigurationDetailDeputyDao;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return dao;
	}

	/**
	 * 添加
	 * @param info
	 * @return
	 */
	@Override
	@EscOptionLog(module=SystemModule.outsourcePersonRecruitment, opType=ESCLogOpType.INSERT, table="recruitment_resume", primaryKey="id={1.id}",option="推荐姓名为{1.name}/{1.idCode}的简历")		
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean add(Map info){
		info.put("interviewStatus", "0");//面试状态默认为未打分
		if(info.get("isArrival")==null){
			info.put("isArrival", "0");
		}		
		return super.add(info);		
	}
	
	@Override
	@EscOptionLog(module=SystemModule.outsourcePersonRecruitment, opType=ESCLogOpType.UPDATE, table="recruitment_resume", primaryKey="id={1.id}",option="处理姓名为{1.name}/{1.idCode}的简历")	
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean updateById(Map info){
		return super.updateById(info);			
	}
	
	@Override
	@EscOptionLog(module=SystemModule.outsourcePersonRecruitment, opType=ESCLogOpType.DELETE, table="recruitment_resume",primaryKey="{1}",option="删除姓名为{1.name}/{1.idCode}的简历")			
	public boolean deleteById(String id){			
		return super.deleteById(id);			
	}
	
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map param) {
		dao.getPageInfo(pageBean, param);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	@Override
	@UploadQueryMarks
	public List<UTMap<String, Object>> getListAll(Map params){
		return dao.getListAll(params);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	@Override
	@UploadQueryMarks
	public List<UTMap<String, Object>> getListMaps(Map params){
		return super.getListMaps(params);
	}
	
	@Override
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		UTMap<String, Object> rec = super.getById(id);		
		return rec;
	}
	
	/**
	 * 根据领用记录的条件查询领用详单
	 * @param params
	 */
	@Override
	public List<UTMap<String, Object>> getListAllByParentParam(Map params){
		return dao.getListAllByParentParam(params);
	}
	
	/**
	 * 根据需求详情ID删除推荐的简历
	 * @param infoId
	 * @return
	 */
	@Override
	public boolean deleteByDetailId(String detailId){
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("detailId", detailId);
		return dao.deletes(map);
	}

	@Override
	@EscOptionLog(module=SystemModule.outsourcePersonRecruitment, opType=ESCLogOpType.UPDATE, table="recruitment_resume", primaryKey="id={1.id}",option="管理员筛选姓名为{1.name}/{1.idCode}的简历")		
	public boolean managerScreen(Map<String, Object> info) {
		
		String managerFilterResult = info.get("managerFilterResult").toString();
		if(IRecruitmentResumeDao.RESUME_FILTER_RESULT_SUCCESS.equals(managerFilterResult)){
			info.put("status", IRecruitmentResumeDao.STATUS_INTERVIEW);
		}else if(IRecruitmentResumeDao.RESUME_FILTER_RESULT_FAIL.equals(managerFilterResult)){
			info.put("status", IRecruitmentResumeDao.STATUS_FINISH);
		}		
		boolean result = super.updateById(info);		
		
		if(result&&IRecruitmentResumeDao.RESUME_FILTER_RESULT_SUCCESS.equals(managerFilterResult)){
			/*//发送消息,通知申请人进行简历推荐
			String applyId = info.get("applyId").toString();
			Map<String,Object> applyInfo = applyDao.getById(applyId);
			String taskUserIds = applyInfo.get("applyUserId").toString();	
			String title = "人力资源申请【"+applyInfo.get("name")+"/"+applyInfo.get("code")+"】简历筛选提醒";
			String content = "人力资源申请【"+applyInfo.get("name")+"/"+applyInfo.get("code")+"】有新的简历待您筛选，请进入系统进行处理";
			messageService.sendMessage(taskUserIds,title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);*/
			Map<String,Object> param = new HashMap<String,Object>();				
			param.put("signature", RoleUtils.SUPPLIER_ASSISTANT);
			param.put("supplierId", info.get("supplierId"));
			String taskUserIds = userService.getUserIds(param);	
			String applyId = info.get("applyId").toString();
			Map<String,Object> applyInfo = applyDao.getById(applyId);
			Map<String, Object> rsInfo = dao.getById((String)info.get("id"));
			String title = "人力资源申请【"+applyInfo.get("name")+"/"+applyInfo.get("code")+"】面试提醒";
			String content = "人员【"+rsInfo.get("name")+"】的简历已被选中，可安排面试，详情请进入系统查看";
			messageService.sendMessage(taskUserIds,title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
			
			Map<String,Object> managerParam = new HashMap<String,Object>();				
			managerParam.put("signature", RoleUtils.OUTSOURCE_MANAGER);
			taskUserIds = userService.getUserIds(managerParam);	
			messageService.sendMessage(taskUserIds,title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
		}
		
		return result;
	}

	@Override
	@EscOptionLog(module=SystemModule.outsourcePersonRecruitment, opType=ESCLogOpType.UPDATE, table="recruitment_resume", primaryKey="id={1.id}",option="申请人筛选姓名为{1.name}/{1.idCode}的简历")		
	public boolean applyUserScreen(Map<String, Object> info) {
		String businessFilterResult = info.get("businessFilterResult").toString();
		if(IRecruitmentResumeDao.RESUME_FILTER_RESULT_SUCCESS.equals(businessFilterResult)){
			info.put("status", IRecruitmentResumeDao.STATUS_INTERVIEW);
		}else if(IRecruitmentResumeDao.RESUME_FILTER_RESULT_FAIL.equals(businessFilterResult)){
			info.put("status", IRecruitmentResumeDao.STATUS_FINISH);
		}			
		boolean result = super.updateById(info);
		
		if(result&&IRecruitmentResumeDao.RESUME_FILTER_RESULT_SUCCESS.equals(businessFilterResult)){
			//发送消息,通知供应商助理及外包管理员进行简历推荐
			Map<String,Object> param = new HashMap<String,Object>();				
			param.put("signature", RoleUtils.SUPPLIER_ASSISTANT);
			param.put("supplierId", info.get("supplierId"));
			String taskUserIds = userService.getUserIds(param);	
			String applyId = info.get("applyId").toString();
			Map<String,Object> applyInfo = applyDao.getById(applyId);
			String title = "人力资源申请【"+applyInfo.get("name")+"/"+applyInfo.get("code")+"】面试提醒";
			String content = "人员【"+info.get("name")+"】的简历已被选中，可安排面试，详情请进入系统查看";
			messageService.sendMessage(taskUserIds,title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
			
			Map<String,Object> managerParam = new HashMap<String,Object>();				
			managerParam.put("signature", RoleUtils.OUTSOURCE_MANAGER);
			taskUserIds = userService.getUserIds(managerParam);	
			messageService.sendMessage(taskUserIds,title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
		}
		return result;
	}	
	
	@Override
	@UploadAddMark //aop拦截绑定上传文件的数据关系
	@EscOptionLog(module=SystemModule.outsourcePersonRecruitment, opType=ESCLogOpType.UPDATE, table="recruitment_resume", primaryKey="id={1.id}",option="记录姓名为{1.name}/{1.idCode}的面试信息")		
	public void interview(Map<String, Object> info) {
		info.put("status", IRecruitmentResumeDao.STATUS_FINISH);
		boolean result = super.updateById(info);
		String interviewResult = info.get("interviewResult").toString();
		if(result&&IRecruitmentResumeDao.RESULT_SUCCESS.equals(interviewResult)){
			//发送消息,通知供应商助理及外包管理员人员的面试结果
			Map<String,Object> param = new HashMap<String,Object>();				
			param.put("signature", RoleUtils.SUPPLIER_ASSISTANT);
			param.put("supplierId", info.get("supplierId"));
			String taskUserIds = userService.getUserIds(param);	
			String applyId = info.get("applyId").toString();
			Map<String,Object> applyInfo = applyDao.getById(applyId);
			String title = "人力资源申请【"+applyInfo.get("name")+"/"+applyInfo.get("code")+"】面试结果通知";
			String content = "人员【"+info.get("name")+"】已面试通过，可安排入场，详情请进入系统查看";
			messageService.sendMessage(taskUserIds,title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
			
			Map<String,Object> managerParam = new HashMap<String,Object>();				
			managerParam.put("signature", RoleUtils.OUTSOURCE_MANAGER);
			taskUserIds = userService.getUserIds(managerParam);	
			messageService.sendMessage(taskUserIds,title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
		}
	}	

	@Override
	@EscOptionLog(module=SystemModule.outsourcePersonRecruitment, opType=ESCLogOpType.UPDATE, table="recruitment_resume",option="更新姓名为{1.idCode}的到岗信息")		
	public void updateArrival(Map<String, Object> info) {
		Map<String, Object> params = new HashMap<String,Object>();
		params.put("supplierId", info.get("supplierId"));
		params.put("idCode", info.get("idCode"));
		params.put("interviewResult", IRecruitmentResumeDao.RESULT_SUCCESS);
		params.put("projectId", info.get("projectId"));
		List<UTMap<String,Object>> list = this.getListMaps(params);
		if(list!=null&&list.size()>0){			
			Map<String, Object> resume = list.get(0);
			resume.putAll(params);
			resume.put("isArrival","1");
			resume.put("arrivalDate", info.get("arrivalDate"));
			super.updateById(resume);
		}
	}

	@Override
	public List<UTMap<String, Object>> getInterviewByInfo(Map<String, Object> info) {
		// TODO Auto-generated method stub
		return dao.getInterviewByInfo(info);
	}

	@Override
	public boolean addInterview(Map<String, Object> info) {
		// TODO Auto-generated method stub
		String interviewUserIds = (String) info.get("interviewUserId");
		if (StringUtils.isEmpty(interviewUserIds)) {
			return false;
		}
		String[] userIdArr = interviewUserIds.split(",");
		boolean isSuccess = false;
		for (String userId : userIdArr) {
			if (StringUtils.isNotEmpty(userId)) {
				info.put("id", UUID.randomUUID().toString());
				info.put("interviewUserId", userId);
				isSuccess = dao.addInterview(info);
				if (isSuccess) {
					String id = (String) info.get("id");
					String templateConfigurationId = (String) info.get("templateConfigurationId");
					templateConfigurationDetailDeputyDao.initDataByTemplateConfigurationId(templateConfigurationId, id);
					//给面试人发送通知消息
					String interviewUserId = (String) info.get("interviewUserId");
					String recruitmentResumeId = (String) info.get("recruitmentResumeId");
					UTMap<String, Object> resume = this.getById(recruitmentResumeId);
					String title = "面试结果填报提醒";
					String userName = "";
					if (null != resume && !resume.isEmpty()) {
						userName = (String) resume.get("name");
					}
					String content = "人员【"+userName+"】的简历已筛选通过，可进行面试，请进入系统填报面试结果";
					messageService.sendMessage(interviewUserId, title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
				}
			}
		}
		return isSuccess;
	}

	@Override
	public boolean removeInterview(String id) {
		// TODO Auto-generated method stub
		boolean flag = dao.removeInterview(id);
		if (flag) {
			Map<String, Object> info = new HashMap<String, Object>();
			info.put("moduleTemplateConfigurationId", id);
			templateConfigurationDetailDeputyDao.delete(info);
		}
		return flag;
	}

	@Override
	public void getPageInfoForInterview(UTPageBean pageBean, Map<String, Object> params) {
		dao.getPageInfoForInterview(pageBean, params);
	}

	@Override
	@UploadAddMark //aop拦截绑定上传文件的数据关系
	public boolean updateGradeResult(Map<String, Object> info) {
		// TODO Auto-generated method stub
		boolean flag = dao.updateGradeResult(info);
		if (flag) {
			List<Map> resultList = new ArrayList<Map>();
			List<Map> list= (List<Map>)info.get("treeData");
			String id = (String) info.get("id");
			CommonUtils.setTemplateConfigurationDetailDeputyResult(id, id, list, resultList);
			//先删除
			templateConfigurationDetailDeputyResultDao.deleteByModuleTemplateConfigurationIdEvaluator(id);
			if(!resultList.isEmpty()){
				//后添加
				templateConfigurationDetailDeputyResultDao.adds(resultList);
			}
		}
		return flag;
	}

	@Override
	@UploadQueryMark //aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getInterviewById(String id) {
		// TODO Auto-generated method stub
		UTMap<String, Object> result = dao.getInterviewById(id);
		if (null != result && !result.isEmpty()) {
			result.put("treeData", templateConfigurationDetailDeputyService.getDetailsDeputy(id, id));
		}
		return result;
	}

	@Override
	public void updateInterview(UTMap<String, Object> item) {
		// TODO Auto-generated method stub
		dao.updateInterview(item);
	}	

}