package com.esc.oms.outsource.attendance.dao.impl;

import com.esc.oms.outsource.attendance.dao.IManHourEditDao;
import com.esc.oms.util.RoleUtils;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import java.util.Calendar;
import java.util.List;
import java.util.Map;

/**
 * 考勤工时填报dao
 * @author owner
 *
 */
@Repository
public class ManHourEditDaoImpl extends BaseOptionDao implements IManHourEditDao{

	@Override
	public String getTableName() {
		return "attendance_man_hour_edit";
	}
	
	public List<UTMap<String, Object>> getListMaps(Map param) {
		String sql=getSearchSql(param);
		return super.getListBySql(sql, null);
	}
	
	public List<UTMap<String, Object>> getListUserDate(Map param) {
		return getListMaps(param);
	}

	@Override
	public List<UTMap<String, Object>> getProjectByTime(String minDate, String maxDate) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT pr.memberId, pr.projectId, opl.supplierId,opl.userId FROM project_res pr ");
		sql.append(" LEFT JOIN outsource_person_list opl ON pr.memberId = opl.userId ");
		sql.append(" AND (( pr.beginDate <= '"+maxDate+"' AND pr.endDate IS NULL ) OR ( pr.endDate >= '"+minDate+"' AND pr.endDate <= '"+maxDate+"' ) ");
		sql.append(" OR ( pr.beginDate <= '"+maxDate+"' AND pr.beginDate >= '"+minDate+"' ) OR ( pr.beginDate <= '"+minDate+"' AND pr.endDate >= '"+maxDate+"' ))");
		sql.append(" where opl.supplierId is not null and opl.isHumanRes = 1 and opl.state = 1 ");
		return this.getListBySql(sql.toString());
	}

	@Override
	public List<UTMap<String, Object>> getProjectByToday(String today) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT pr.memberId, pr.projectId, opl.supplierId,opl.userId FROM project_res pr ");
		sql.append(" LEFT JOIN outsource_person_list opl ON pr.memberId = opl.userId ");
		sql.append(" where ( pr.beginDate <= '"+today+"' AND (pr.endDate IS NULL or pr.endDate is not null and pr.endDate>='"+today+"' ))");
		sql.append(" and opl.supplierId is not null and opl.isHumanRes = 1 and opl.state = 1 ");
		return this.getListBySql(sql.toString());
	}

	public void getPageInfo(UTPageBean pageBean,Map param){
		String sql=getSearchSql(param);
		 super.getPageListMapBySql(sql,pageBean, null);
	}
	
	/**
	 * 获取外包人员和相应项目的数据
	 * @return
	 */
	public List<UTMap<String, Object>> getProjectPerson() {
		StringBuilder sql = new StringBuilder();
		sql.append(" select opl.*, pi.name as projectName, pi.bleader from outsource_person_list opl ");
		sql.append(" left join project_info pi on opl.mainProjectId = pi.id ");
		sql.append(" where opl.isHumanRes = 1 ");//只人力外包人员，也就是关联了合同的人员数据
		sql.append(" and opl.state = 1  "); 
		sql.append(" and opl.mainProjectId is not null ");//必须关联项目
		return super.getListBySql(sql.toString(), null);
	}

	private String getSearchSql(Map<String, Object> param){
		Map<String, String> p=UTMap.mapObjToString(param);
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT amhe.*,pi.name projectName, pi.aleader,sbi.name supplierName,ids_to_name(pi.aleader) as projectLeader ,CONCAT(su2.name,'/',su2.code) as userName,opl.level from attendance_man_hour_edit amhe ");
		sql.append(" left join project_info pi on amhe.projectId = pi.id ");
		sql.append(" left join supplier_base_info sbi on amhe.supplierId = sbi.id ");
		sql.append(" left join outsource_person_list opl on amhe.userId = opl.userId ");
		sql.append(" left join sys_user su2 on amhe.userId = su2.id ");
		sql.append(" WHERE 1=1 ");
		
		String id=p.get("id"); 
		String year = p.get("year");//年
		String month = p.get("month");//月
		String status = p.get("status");//状态（待填报：1，已填报：2，已确认：3）
		String projectName = p.get("projectName");//项目名称
		String projectId = p.get("projectId");//项目编号
		String projectLeader = p.get("projectLeader");//项目负责人
		String supplierName = p.get("supplierName");//供应商
		String userName = p.get("userName");//姓名
		String userId = p.get("userId");//用户id
		//外包管理员可以查看和编辑所有数据，乙方的人只能看自己的   供应商负责人看本供应商的   项目的乙方负责人可以看本项目中本供应商人员的
		if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR,RoleUtils.OUTSOURCE_MANAGER)){
			if("1".equals(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserType())){//甲方用户只能查看甲方项目负责人是自己的数据
				sql.append(" and pi.aleader = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' ");
			}else{//乙方用户
				if(EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SUPPLIER_LEADERS)){// 供应商负责人看本供应商的 /项目的乙方负责人可以看本项目中本供应商人员的/乙方的人只能看自己的
					sql.append(" and (pi.bleader = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' ");
					sql.append(" or amhe.userId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' ");
					sql.append(" or amhe.supplierId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId()+"') ");
				}else{///项目的乙方负责人可以看本项目中本供应商人员的/乙方的人只能看自己的
					sql.append(" and (pi.bleader = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' ");
					sql.append(" or amhe.userId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"') ");
				}
			}
		}
		
		if (StringUtils.isNotEmpty(id)) {
			sql.append(" and amhe.id='"+id+"'");
		}
		
		if (StringUtils.isNotEmpty(year)) {
			sql.append(" and amhe.year='"+year+"'");
		}
		
		if (StringUtils.isNotEmpty(month)) {
			sql.append(" and amhe.month='"+month+"'");
		}
		
		if (StringUtils.isNotEmpty(status)) {
//			sql.append(" and amhe.status='"+status+"'");
			sql.append(" and find_in_set(amhe.status, '").append(status).append("') ");
		}
		
		if (StringUtils.isNotEmpty(projectId)) {
			sql.append(" and amhe.projectId='"+projectId+"'");
		}
		
		if (StringUtils.isNotEmpty(userId)) {
			sql.append(" and amhe.userId='"+userId+"'");
		}
		
		if (StringUtils.isNotEmpty(projectName)) {
			sql.append(" and pi.name like '%"+projectName+"%'");
		}
		
		if (StringUtils.isNotEmpty(supplierName)) {
			sql.append(" and sbi.name like '%"+supplierName+"%'");
		}
		
		if (StringUtils.isNotEmpty(projectLeader)) {
			sql.append(" and ids_to_name(pi.aleader) like '%"+projectLeader+"%'");
		}
		
		if (StringUtils.isNotEmpty(userName)) {
//			sql.append(" and su2.name like '%"+userName+"%'");
			sql.append(" and CONCAT(su2.name,'/',su2.code) like '%"+userName+"%' ");
		}
		
		//过滤掉本月的数据，本月的数据只有到下个月才可以填报
		Calendar c = Calendar.getInstance();
		sql.append(" and amhe.yearMonth !='"+c.get(c.YEAR) + "-"+(c.get(c.MONTH) +1) +"'");
		
		sql.append(" ORDER BY str_to_date(amhe.yearMonth, '%Y-%m') desc,amhe.projectId ");
		
		return sql.toString();
	}

	/**
	 * 根据日期判断是否是节假日
	 * @param date
	 */
//	@Override
//	public boolean isFestivalByDate(String date) {
////		String sql = " SELECT * from attendance_festival where festivalDate = '"+date+"' ";
//		Map param = new HashMap();
//		param.put("festivalDate", date);
//		return this.isExit(param);
//		
//	}

	
	
	

	
}
