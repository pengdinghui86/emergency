package com.esc.oms.outsource.monitor.dao.impl;

import java.util.List;

import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.monitor.dao.IDuediligenceThirdDao;

/**
 * 第三方机构检查Dao
 * @author owner
 *
 */
@Repository
public class DuediligenceThirdDaoImpl extends BaseOptionDao implements IDuediligenceThirdDao{

	@Override
	public String getTableName() {
		return "outsourc_duediligence_third";
	}
	
//	@Override
//	public void getPageInfo(UTPageBean pageBean, Map params) {
//		super.getPageListMapBySql(getSearchSql(params,false), pageBean, null);
//	}
	
	/**
	 * 根据模板配置查询对应的第三方机构数据
	 * @param duediligenceEvaluateConfigId
	 * @return
	 */
	@Override
	public UTMap<String, Object> getByDuediligenceEvaluateConfigId(String duediligenceEvaluateConfigId) {
		String sql = this.getSearchSql();
		List<UTMap<String, Object>> list = super.getListBySql(sql, duediligenceEvaluateConfigId);
		if(list != null && list.size() > 0){
			return list.get(0);
		}
		return null;
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(){
		StringBuilder sql=new StringBuilder();
		sql.append("select * from " );
		sql.append(getTableName());
		sql.append(" tb where tb.duediligenceEvaluateConfigId = ?");
//		sql.append(" order by tb.createTime desc");
		return  sql.toString();
	}

}
