package com.esc.oms.outsource.outperson.service;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;


/**
 * 外包人员列表
 * @author smq
 * @date   2016-2-24 上午10:39:04
 */
public interface IOutSourcePersonService extends IBaseOptionService {

	public UTMap<String, Object> getOutEmpByUserId(String userId);
	
	/**
	 * 获取 外包人力合同 通过 用户Id
	 * 结果： 基本配置 baseConfig， 折算配置 vacationConfigs  费用配置 costConfigs
	 * @param manpowerId
	 * @return
	 */
	public Map<String, Object> getOutEmpAgreementById(String userId);
	
	public boolean addOutSouceBySupplierEmp(Map<String, Object> empInfo);

	public boolean deleteOutSouceByUserIds(String userIds) ;

	public boolean leadingin(String filePath, Map<String, Object> param) throws Exception ;

	public Boolean leadinginDing(String filePath, Map<String, Object> param) throws Exception ;

	public boolean leadingout(List data, HttpServletRequest request,	HttpServletResponse response) throws Exception ;

	
	
}
