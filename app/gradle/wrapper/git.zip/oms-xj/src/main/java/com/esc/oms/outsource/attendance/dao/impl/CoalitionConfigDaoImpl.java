package com.esc.oms.outsource.attendance.dao.impl;

import com.esc.oms.outsource.attendance.dao.ICoalitionConfigDao;
import com.esc.oms.util.RoleUtils;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * 联合考勤规则配置dao
 * @author owner
 *
 */
@Repository
public class CoalitionConfigDaoImpl extends BaseOptionDao implements ICoalitionConfigDao{

	@Override
	public String getTableName() {
		return "attendance_coalition_config";
	}
	
	public List<UTMap<String, Object>> getListMaps(Map param) {
		String sql=getSearchSql(param);
		return super.getListBySql(sql, null);
	}

	public void getPageInfo(UTPageBean pageBean,Map param){
		String sql=getSearchSql(param);
		 super.getPageListMapBySql(sql,pageBean, null);
	}

	private String getSearchSql(Map<String, Object> param){
		Map<String, String> p=UTMap.mapObjToString(param);
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT auc.*, sbi.name as supplierName from attendance_coalition_config auc ");
		sql.append(" left join supplier_base_info sbi on auc.supplierId = sbi.id ");
//		sql.append(" left join sys_user su on auc.userId = su.id ");
		sql.append(" WHERE auc.deleteFlag = 0 ");
				
		String id=p.get("id"); 
		String name = p.get("name");//联合考勤名称
		String supplierName = p.get("supplierName");//供应商名称
		String attendanceDateType = p.get("attendanceDateType");//考勤方式
		
		if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR,RoleUtils.SUPPLIER_ADMINISTRATOR)){
			if(EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SUPPLIER_LEADERS)){//供应商负责人查看本供应商下用户的考勤配置
				sql.append(" and auc.supplierId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId()+"' ");
			}else{
				sql.append(" and auc.userIds like '%"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"%' ");//外包用户只能查询自己的数据
			}
		}
		
		if (StringUtils.isNotEmpty(id)) {
			sql.append(" and auc.id='"+id+"'");
		}
		
		if (StringUtils.isNotEmpty(name)) {
			sql.append(" and auc.name like '%"+name+"%'");
		}
		
		if (StringUtils.isNotEmpty(supplierName)) {
			sql.append(" and sbi.name like '%"+supplierName+"%'");
		}
		
		if (StringUtils.isNotEmpty(attendanceDateType)) {
			sql.append(" and auc.attendanceDateType='"+attendanceDateType+"'");
		}
//		if (StringUtils.isNotEmpty(beginDate) && StringUtils.isNotEmpty(endDate)) {
//			sql.append(" and festivalDate BETWEEN '"+beginDate+"' AND '"+endDate+"'  ");
//		}

		sql.append(" ORDER BY createTime desc ");
		
		return sql.toString();
	}

	/**
	 * 检查用户是否已经配置联合考勤
	 * @param userId
	 * @param coalitionId
	 * @return 联合考勤名称 name
	 */
	@Override
	public String checkCoalitionConfig(String userId, String coalitionId) {
//		String sql = " select * from " + getTableName() + " where 1=1 ";
		StringBuilder sql=new StringBuilder();
		sql.append(" select * from ");
		sql.append(getTableName());
		sql.append(" where deleteFlag = 0 ");
		sql.append(" and userIds like '%"+userId+"%' ");
		if(coalitionId != null){//修改的时候排除自己
			sql.append(" and id != '"+coalitionId+"'  ");
		}
		UTMap<String, Object> map = this.getOneBySql(sql.toString(), null);
		if(map != null){
			return map.get("name").toString();
		}
		return null;
	}

	@Override
	public List<UTMap<String, Object>> getCoalitionConfigs(Map<String, Object> param) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select acc.* from attendance_coalition_config acc left join attendance_user_config auc on auc.coalitionConfigId = acc.id ");
		sql.append(" left join outsource_person_list opl on opl.userId = auc.id");
		sql.append(" where (acc.deleteFlag = 0 or acc.deleteFlag is null) ");
		if(param != null){
			String dingDingIds = (String) param.get("dingDingIds");
			if(StringUtils.isNotEmpty(dingDingIds)){//联合考勤确定时间
				sql.append(" and find_in_set(opl.dingDingId,'"+dingDingIds+"') and opl.dingDingId is not null ");
				sql.append(" and auc.coalitionConfigId is not null and acc.attendanceDateType = 1");
			}
		}
		return this.getListBySql(sql.toString());


	}


}
