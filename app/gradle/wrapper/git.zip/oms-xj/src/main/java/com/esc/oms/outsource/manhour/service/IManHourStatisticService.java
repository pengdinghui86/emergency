package com.esc.oms.outsource.manhour.service;

import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

/**
 * 工时计算、统计service
 * @author lenovo
 *
 */
public interface IManHourStatisticService {

	/**
	 * 计算加班开始到结束的每天的小时数：不计算正常工作的时间
	 * @param beginTime
	 * @param endTime
	 * @param userConfig
	 * @return
	 */
	public Map<String, Object> calculateOvertimeHours(String beginTime, String endTime, UTMap<String, Object> userConfig);


	/**
	 * 计算加班开始到结束的每天的小时数
	 * 新规则，加班时长不记录每天的上班排期，
	 *
	 * 工作日为早上开始前的时间+下午下班后的时间，节假日为结束时间减去开始时间
	 * @param beginTime
	 * @param endTime
	 * @param userConfig
	 * @return
	 */
	public Map<String, Object> calculateOvertimeHoursNew(String beginTime, String endTime, UTMap<String, Object> userConfig, String userId);

	/**
	 * 计算加班开始时间到结束时间，细分为每天计算
	 * @param beginTime
	 * @param endTime
	 * @param userConfig
	 * @return
	 */
	public List<Map<String, Object>> calculateOvertimeHoursDays(String beginTime, String endTime, UTMap<String, Object> userConfig, String userId);
	/**
	 * 开始到结束的每天的秒数：工作的时间
	 * @param beginTime
	 * @param endTime
	 * @param userConfig
	 * @return
	 */
	public List<Map<String, Object>> calculateSeconds(String beginTime, String endTime, UTMap<String, Object> userConfig);

	/**
	 * 计算调休和请假的时间，上午下午一律按四个小时算
	 * @param beginTime
	 * @param endTime
	 * @param userConfig
	 * @return
	 */
	public List<Map<String, Object>> calculateVacationSeconds(String beginTime, String endTime, UTMap<String, Object> userConfig);
	/**
	 * 新疆农信新考勤规则
	 * 早上有15分钟弹性时间，不算迟到，除此之外如果迟到或者早退，不算工时
	 *
	 * @param beginTime
	 * @param endTime
	 * @param userConfig
	 * @param seasonType
	 * @return
	 */
	public Map<String, Object> calculateSecondsNew(String beginTime, String endTime, UTMap<String, Object> userConfig, String seasonType);
	/**
	 * 开始到结束的每天的秒数：工作的时间，区分考勤模块
	 * @param beginTime
	 * @param endTime
	 * @param userConfig
	 * @param isAtt true：考勤统计模块，false：按照默认
	 * @return
	 */
	public List<Map<String, Object>> calculateSeconds(String beginTime, String endTime, UTMap<String, Object> userConfig, boolean isAtt);

	/**
	 	计算请假和调休的问题，
	 	只能以半天计算时间请假和调休时间
	 * @param beginTime
	 * @param endTime
	 * @param userConfig
	 * @param isAtt true：考勤统计模块，false：按照默认
	 * @return
	 */
	public List<Map<String, Object>> calculateVocationSeconds(String beginTime, String endTime, UTMap<String, Object> userConfig);
	
	/**
	 * 判断当前是否是工作日
	 * 需要考虑考勤配置和节假日配置
	 * @param date
	 * @param userConfig
	 * @return
	 */
	public String isWorkDay(Calendar date, UTMap<String, Object> userConfig);

	public void baseOnSupplier(Map<String, Object> param, UTPageBean pageBean);

	public void baseOnOrg(Map<String, Object> param, UTPageBean pageBean);
	
	public void getDetailPage(String type, Map<String, Object> param, UTPageBean pageBean);
	
	public List<UTMap<String, Object>> getDetailList(String type, Map<String, Object> param);

	public boolean leadingout(String type, Map param, List<UTMap<String, Object>> data, HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	public boolean leadingoutDetail(String type, List<UTMap<String, Object>> data, HttpServletRequest request, HttpServletResponse response) throws Exception;

	public List<UTMap<String, Object>> baseOnSupplierList(Map<String, Object> param);

	public List<UTMap<String, Object>> baseOnOrgList(Map<String, Object> param);

	/**
	 * 首页工时统计
	 * @param type
	 * @param param
	 * @return
	 */
	public List<UTMap<String, Object>> reportForMainPage(String baseOn, String type, Map<String, Object> param);


}
