package com.esc.oms.outsource.manhour.dao.impl;

import com.esc.oms.outsource.manhour.dao.IVacationDao;
import com.esc.oms.util.RoleUtils;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class VacationDaoImpl extends BaseOptionDao implements IVacationDao {
	@Override
	public String getTableName() {
		return "workhour_vacation";
	}

	@Override
	public List<UTMap<String, Object>> getVacationList(Map param) {
		String sql = getSearchSqlString(param);
		List<UTMap<String, Object>> dataList = this.getListBySql(sql);
		for (UTMap<String, Object> data : dataList) {
			if(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId().equals(data.get("createUserId"))) {
				data.put("isOwner", "1");
			}
		}
		return dataList;
	}

	@Override
	public void getVacationPage(UTPageBean pageBean, Map param) {
		String sql = getSearchSqlString(param);
		this.getPageListMapBySql(sql , pageBean);
		List<UTMap<String, Object>> rows = pageBean.getRows();
		for (UTMap<String, Object> data : rows) {
			if(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId().equals(data.get("createUserId"))) {
				data.put("isOwner", "1");
			}
		}
	}
	
	/**
	 * 不可以根据状态查询
	 * @param param
	 * @return
	 */
	private String getSearchSqlString(Map param) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select DISTINCT s.*,DATE_FORMAT(s.beginTime, '%Y-%m-%d %H:%i') beginTimeShow,DATE_FORMAT(s.endTime, '%Y-%m-%d %H:%i') endTimeShow ");
		if(param!=null &&param.get("status")!=null &&  StringUtils.isNotEmpty(param.get("status").toString())){
			String status = (String) param.get("status");
			if("2,3".equals(status)){//待审批
				sql.append(" ,t4.currentExecutor as auditors,t4.currentStepName ");
				sql.append(" from workhour_vacation s  ");
				sql.append(" left join sys_workflow_instance t4 on s.workflowInstanceId=t4.id ");
				sql.append(" where FIND_IN_SET('"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"',t4.currentExecutor) ");
			}else if("3,4,5".equals(status)){//已审批
				sql.append(" from workhour_vacation s  ");
				sql.append(" left join sys_workflow_audit_history t4 on s.workflowInstanceId=t4.instanceId ");
				sql.append(" where FIND_IN_SET('"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"',t4.optionUserId) " );
				sql.append(" and t4.nodeName!='开始' " );//屏蔽开始节点
			} else { // 其他单个
				sql.append(" , if(b.userId is null, 0, 1) billAudited ");
				sql.append(" from workhour_vacation s ");
				sql.append(" left join workhour_bill b on s.createUserId = b.userId and DATE_FORMAT(s.beginTime, '%Y') = b.`year` and QUARTER(s.beginTime) = b.`quarter` ");
				sql.append(" WHERE 1=1 ");
			}
		}else{
			sql.append(" , if(b.userId is null, 0, 1) billAudited ");
			sql.append(" from workhour_vacation s ");
			sql.append(" left join workhour_bill b on s.createUserId = b.userId and DATE_FORMAT(s.beginTime, '%Y') = b.`year` and QUARTER(s.beginTime) = b.`quarter` ");
			sql.append(" WHERE 1=1 ");
		}
		if(param != null) {
			String id = (String) param.get("id");
			String title = (String) param.get("title");
			String beginTime = (String) param.get("beginTime");
			String endTime = (String) param.get("endTime");
			String supplierId = (String) param.get("supplierId");
			String orgId = (String) param.get("orgId");
			String supplierName = (String) param.get("supplierName");
			String createUser = (String) param.get("createUser");
			String type = (String) param.get("type");
			String submitUser = (String) param.get("submitUser");
			if(StringUtils.isNotEmpty(id)) {
				sql.append(" and s.id = '").append(id).append("' ");
			}
			if(StringUtils.isNotEmpty(title)) {
				sql.append(" and s.title like '%").append(title).append("%' ");
			}
			// 查询的开始结束时间需要根据每一天的数据
			if(StringUtils.isNotEmpty(beginTime) || StringUtils.isNotEmpty(endTime)) {
				sql.append(" and exists(select 1 from workhour_vacation_detail d where d.infoId = s.id ");
			}
			if(StringUtils.isNotEmpty(beginTime)) {
				sql.append(" and d.presentDate >= '").append(beginTime).append("' ");
			}
			if(StringUtils.isNotEmpty(endTime)) {
				sql.append(" and d.presentDate <= '").append(endTime).append("' ");
			}
			if(StringUtils.isNotEmpty(beginTime) || StringUtils.isNotEmpty(endTime)) {
				sql.append(") ");
			}
			
			if(StringUtils.isNotEmpty(orgId)) {
				sql.append(" and s.orgId = '").append(orgId).append("' ");
			}
			if(StringUtils.isNotEmpty(supplierId)) {
				sql.append(" and s.supplierId = '").append(supplierId).append("' ");
			}
			if(StringUtils.isNotEmpty(supplierName)) {
				sql.append(" and s.supplierName like '%").append(supplierName).append("%' ");
			}
			if(StringUtils.isNotEmpty(createUser)) {
				sql.append(" and s.createUser like '%").append(createUser).append("%' ");
			}
			if(StringUtils.isNotEmpty(submitUser)) {
				sql.append(" and s.submitUser like '%").append(submitUser).append("%' ");
			}
			if(StringUtils.isNotEmpty(type)){
				sql.append(" and s.type ='"+type+"'");
			}
		}
		// 权限过滤：个人只能看见自己的、供应商负责人看自己所属供应商的、供应商管理员看所有的、审核人看见自己审核的
		if(!(param != null && "1".equals(param.get("showAll")))) { // 非审核页面
			// 数据权限过滤 lba
			if(EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.OUTSOURCE_MANAGER, RoleUtils.SYSTEM_ADMINISTRATOR)) {//外包管理员
				// 不做限制
			} else if(EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SUPPLIER_LEADERS)) {// 供应商负责人
				// 只能看自己所属供应商的
				sql.append(" and s.supplierId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId()+"' ");
			} else {// 只能看自己的
				sql.append(" and s.createUserId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' ");
			}
		}
		sql.append(" order by s.submitTime desc ");
		return sql.toString();
	}

	@Override
	public boolean isExistRecord(Map<String, Object> map) {
		if(map.containsKey("beginTime") && map.containsKey("endTime")) {
			Object beginTime = map.get("beginTime");
			Object endTime = map.get("endTime");
			StringBuilder checkSql = new StringBuilder();
			checkSql.append("select s.beginTime, s.endTime from " + getTableName() + " s ");
			checkSql.append(" where s.createUserId = ? ");
			checkSql.append(" and s.status <> '6' ");
			checkSql.append(" and s.beginTime <?   AND s.endTime > ? ");
//			checkSql.append(" and ((s.beginTime >= ? and s.beginTime < ?) or (s.endTime > ? and s.endTime <= ?) ) ");
//			checkSql.append(" and ((s.beginTime BETWEEN ? and ?) or (s.endTime BETWEEN ? and ?) ) ");
			if(map.containsKey("id")) {
				String id = (String) map.get("id");
				if(StringUtils.isNotEmpty(id))
					checkSql.append(" and id <> '" + id + "' ");
			}
			
			int count = this.getCount(checkSql.toString(), EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId(), endTime, beginTime);
			if(count > 0) {
				return true;
			}
		}
		return false;
	}

	@Override
	public List<UTMap<String, Object>> getMapList(Map<String, Object> param) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select * from "+this.getTableName()+" where 1=1 ");
		if(param != null){
			String ids = (String) param.get("ids");
			if(StringUtils.isNotEmpty(ids)){
				sql.append(" and instanceId in ("+ids+")");
			}
		}
		return this.getListBySql(sql.toString());
	}

	@Override
	public boolean deleteByTime(String startTime, String endTime, String userIds) {
		StringBuilder sql = new StringBuilder();
		sql.append(" delete from workhour_vacation where (submitTime >= '"+startTime+"' and submitTime <='"+endTime+"') ");
		sql.append(" or(beginTime <= '"+startTime+"' and endTime >='"+endTime+"')");
		sql.append(" or (beginTime <= '"+startTime+"' and endTime >='"+startTime+"' and endTime <='"+endTime+"')");
		sql.append(" or (beginTime >='"+startTime+"' and beginTime <='"+endTime+"' and endTime >='"+endTime+"')");
		sql.append(" or(beginTime >= '"+startTime+"' and endTime <='"+endTime+"')");
		sql.append(" and createUserId in("+userIds+")");
		return this.executeUpdate(sql.toString());
	}
}
