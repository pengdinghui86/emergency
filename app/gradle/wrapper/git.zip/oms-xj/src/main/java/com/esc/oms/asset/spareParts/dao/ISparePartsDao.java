package com.esc.oms.asset.spareParts.dao;

import java.util.List;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

public interface ISparePartsDao extends IBaseOptionDao{
	
	public List<UTMap<String, Object>> getSparePartsByNameAndId(String name,String id);
	
	public List<UTMap<String, Object>> getSparePartsByIds(String ids);
	
	public List<UTMap<String,Object>> getSparePartByEndDateAndStatus();
	
}
