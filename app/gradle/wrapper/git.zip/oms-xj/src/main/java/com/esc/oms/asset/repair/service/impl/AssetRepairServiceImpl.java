package com.esc.oms.asset.repair.service.impl;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.idgenerator.IDGenerationManager;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.workflow.annotation.WorkflowRecordQueryMark;
import org.esc.framework.workflow.service.IWorkflowCallback;
import org.esc.framework.workflow.service.IWorkflowCode;
import org.esc.framework.workflow.service.IWorkflowEngine;
import org.esc.framework.workflow.utils.bpmn.FlowForm;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.asset.application.dao.IBusinessNumberDao;
import com.esc.oms.asset.lowvalue.dao.ILowvalueApplyDao;
import com.esc.oms.asset.physical.dao.IAssetPhysicalDao;
import com.esc.oms.asset.physical.service.IAssetPhysicalService;
import com.esc.oms.asset.repair.dao.IAssetRepairDao;
import com.esc.oms.asset.repair.service.IAssetRepairService;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;
import com.esc.oms.util.TaskModel;

@Service
@Transactional
public class AssetRepairServiceImpl extends BaseOptionService implements IAssetRepairService,IWorkflowCallback{

	@Resource
	private IAssetRepairDao assetRepairDao;
	
	@Resource
	private IBusinessNumberDao businessNumberDao;
	
	@Resource
	private IWorkflowEngine workflowEngine;
	
	@Resource
	private IAssetPhysicalService assetPhysicalService;
	
	@Resource
	private IUserTaskService userTaskService;
	
	@Resource
	private MessageSend messageService;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return assetRepairDao;
	}

	@Override
	@WorkflowRecordQueryMark
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageInfo(pageBean, params);
	}
	

	@Override
	public boolean leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String[] fileds = new String[] { 
				IAssetRepairDao.FIELD_CODE,
				IAssetRepairDao.FIELD_NAME,
				IAssetRepairDao.FIELD_CREATE_USER,
				IAssetRepairDao.FIELD_CREATE_TIME,
				IAssetRepairDao.FIELD_REASON,
				IAssetRepairDao.FIELD_RESULT,
				IAssetRepairDao.FIELD_STATUS
		};
		String tamlate="excelOutTamplate.assetRepair";	
		return	UTExcel.leadingout(fileds, data, tamlate, request,response);
	}

	@Override
	public List<UTMap<String, Object>> getAssetsList(Map param) {
		return assetRepairDao.getAssetsList(param);
	}

	@Override
	@EscOptionLog(module=SystemModule.assetRepairPage, opType=ESCLogOpType.INSERT, table="assets_material_repair_apply",option="新增名称为{name}的资产报修信息。")
	public boolean add(Map info){
		info.put("createUserId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
		info.put("code", IDGenerationManager.nextId("assetsRepairCode")); // 自动生成编号
		return	getOptionDao().add(info);
	}
	
	
	@Override
	@EscOptionLog(module=SystemModule.assetRepairPage, opType=ESCLogOpType.UPDATE, table="assets_material_repair_apply",option="修改名称为{name}的资产报修信息。")
	public boolean updateById(Map info){
		if(!info.containsKey("id")){
			throw new EscServiceException("根据id 修改map中不存在key=id");
		}
		return getOptionDao().updateById(info);
	}

	private String saveOrUpdate(Map<String,Object> map){  
		if(map.get("id") == null){
//			Calendar cal = Calendar.getInstance();
//			int year = cal.get(Calendar.YEAR);
//			String code = businessNumberDao.saveOrUpdate("ZCWX", String.valueOf(year), "%04d");
//			map.put("code", code);
    		add(map);
    	}else{
    		updateById(map);
    		finishRejectTask(map.get("id").toString());
    	}
		return (String)map.get("id");
    }
	
	@Override
	public void finishRejectTask(String id) {
		userTaskService.finishTask(id, "实物资产报修申请被驳回");
	}
	
	@Override
	public boolean addRepairResult(Map info) {
		return assetRepairDao.addRepairResult(info);
	}

	@Override
	public boolean updateRepairResultById(Map info) {
		return assetRepairDao.updateRepairResultById(info);
	}

	@Override
	public UTMap<String, Object> getResultByRepairId(String repairId) {
		return assetRepairDao.getResultByRepairId(repairId);
	}


	@Override
	public UTMap<String, Object> getOrgLongNameById(String id) {
		return assetRepairDao.getOrgLongNameById(id);
	}
	
	@Override
	public boolean deleteResultByRepairId(String repairId) {
		return assetRepairDao.deleteResultByRepairId(repairId);
	}
	
	
	@EscOptionLog(module=SystemModule.assetRepairPage, opType=ESCLogOpType.DELETE, table="assets_material_repair_apply",option="删除名称为{name}的资产报修信息。")
	public boolean deleteById(String id){
		boolean flag = false;
		flag = getOptionDao().deleteByIds(id);
		if(flag){
			flag = assetRepairDao.deleteResultByRepairId(id);
		}
		return	flag;
	}
	
	public boolean deleteByIds(String ids){
		boolean flag = false;
		flag = getOptionDao().deleteByIds(ids);
		if(flag && StringUtils.isNotEmpty(ids)){
			String[] repairIds = ids.split(",");
			for (String repairId : repairIds) {
				flag = assetRepairDao.deleteResultByRepairId(repairId);
			}
		}
		return flag;
	}

	/**
	 * 返回流程编码
	 * @return
	 */
	public String workflowCode() {
		return IWorkflowCode.PHYSICAL_ASSET_REPAIRS;
	}
	
	/**
	 * 回调方法。
	 * 流程完成时，业务上需要进行的相应操作。
	 * @param businessRecordId
	 */
	public void onFinish(String businessRecordId) {
			finishAudit(businessRecordId);
	}
	
	/**
	 * 回调方法。
	 * 流程回到开始节点时，业务上需要进行的相应操作。
	 * @param businessRecordId
	 */
	public void onReject(String businessRecordId) {
			rejectAudit(businessRecordId);
	}

	/**
	 * 回调方法。
	 * 流程节点 待办任务 可自定义内容
	 * @param businessRecordId
	 */
	public void sendTask(String workflowName, String businessRecordId,	String nodeName, String userId) {
		Map<String,Object> dataParam = new HashMap<String,Object>();
		UTMap<String,Object> utMap = super.getById(businessRecordId);
		if(null != utMap){
			UTMap<String, Object> ut = assetPhysicalService.getById((String)utMap.get("assetsId"));
			if(null != ut){
				//点击待办事项，打开待审批列表tab
				dataParam.put("dataType", "1");
				String codeNum = (String) ut.get("codeNum");
				if (StringUtils.isNotEmpty(codeNum)) {
					codeNum = "/" + codeNum;
				}else {
					codeNum = "";
				}
				userTaskService.addTaskByUserId("实物资产【"+ut.get("name")+codeNum+"】报修申请待您审批", businessRecordId, nodeName, TaskModel.PhysicalAssetRepair, userId,dataParam);
			}
		}
	}

	@Override
	public void optionNode(String workflowCode, String businessRecordId,
			String nodeName, String linkName) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("status", ILowvalueApplyDao.STATUS_AUDITING);
		map.put("id", businessRecordId);
		updateById(map);	
	}
	

	@Override
	public void save(Map<String, Object> map) {
		if(null != map.get("status") && "1".equals(map.get("status").toString())){
			map.put("status", IAssetRepairDao.STATUS_NOT_AUDITING);
		}else{
			map.put("status", IAssetRepairDao.STATUS_NOT_SUBMIT);
		}
		saveOrUpdate(map);
	}
	
	@Override
	public void submit(Map<String,Object> map) {
		map.put("status", IAssetRepairDao.STATUS_NOT_AUDITING);
		String id = saveOrUpdate(map);
//		String workflowInstanceId = workflowEngine.runInstance(IWorkflowCode.PHYSICAL_ASSET_REPAIRS, id);
		
		String orgId = map.get("applyUnit").toString();
		//从页面表单中提取 流程表单配置
		Map<String, Object> formMap=new HashMap<String, Object>();
		formMap.put(FlowForm.FormItemValue.SQDW, orgId);
		String workflowInstanceId = workflowEngine.runInstance(IWorkflowCode.PHYSICAL_ASSET_REPAIRS,  id, formMap);
		setInstanceId(id, workflowInstanceId);
	}
	
	/**
	 * 设置 workflowInstanceId 
	 * @param recordId
	 * @param workflowInstanceId
	 */
	private void setInstanceId(String recordId,String workflowInstanceId){
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("workflowInstanceId", workflowInstanceId);
		updateById(map);
	}

	@Override
	public void finishAudit(String id) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", id);
		map.put("status", IAssetRepairDao.STATUS_FINISH);
		saveOrUpdate(map);
		userTaskService.finishTask(id, "审核");
		UTMap<String,Object> ut = super.getById(id);
		if(null != ut){
			UTMap<String,Object> assets = assetPhysicalService.getById((String)ut.get("assetsId"));
			//发送消息
			String codeNum = (String) assets.get("codeNum");
			if (StringUtils.isNotEmpty(codeNum)) {
				codeNum = "/" + codeNum;
			}else {
				codeNum = "";
			}
			String title = "资产【"+assets.get("name")+codeNum+"】报修进度提醒";
			String content = "资产【"+assets.get("name")+codeNum+"】报修申请已审批通过，请在维修结束后在系统登记维修结果！";
			messageService.sendMessage(String.valueOf(ut.get("createUserId")),title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
			
			
			Map<String,Object> dataParam = new HashMap<String,Object>();
			//点击待办事项，打开申请列表tab
			dataParam.put("dataType", "0");
			//生成待办任务
			userTaskService.addTaskByUserId("资产【"+assets.get("name")+codeNum+"】报修结果待您填报", id, "实物资产报修", TaskModel.PhysicalAssetRepair, String.valueOf(ut.get("createUserId")),dataParam);
			
			//====将资产状态给为维修中=====
			UTMap<String,Object> updateAssets = new UTMap<String,Object>();
			updateAssets.put("id", (String)ut.get("assetsId"));
			updateAssets.put("assetStatus", "4");
			assetPhysicalService.updateById(updateAssets);
		}
	}
	
	@Override
	public void rejectAudit(String id) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", id);
		map.put("status", IAssetRepairDao.STATUS_REJECT);
		saveOrUpdate(map);
		
		UTMap<String,Object> ut = super.getById(id);
		if(null != ut){
			UTMap<String,Object> assets = assetPhysicalService.getById((String)ut.get("assetsId"));
			//发送消息
			String codeNum = (String) assets.get("codeNum");
			if (StringUtils.isNotEmpty(codeNum)) {
				codeNum = "/" + codeNum;
			}else {
				codeNum = "";
			}
			String title = "资产【"+assets.get("name")+codeNum+"】报修申请驳回提醒";
			String content = "资产申请：【"+assets.get("name")+codeNum+"】报修申请已被驳回，请知悉！";
			messageService.sendMessage(String.valueOf(ut.get("createUserId")),title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
			
			Map<String,Object> dataParam = new HashMap<String,Object>();
			//点击待办事项，打开申请列表tab
			dataParam.put("dataType", "0");
			//生成待办任务
			userTaskService.addTaskByUserId("资产【"+assets.get("name")+codeNum+"】报修申请已被驳回", id, "实物资产报修申请被驳回", TaskModel.PhysicalAssetRepair, String.valueOf(ut.get("createUserId")),dataParam);
			
		}
	}


	/**
	 * 回调方法。
	 * 流程中止，或非正常结束，业务上需要进行的相应操作。
	 * @param businessRecordId
	 */
	public void onTerminate(String businessRecordId) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("status", IAssetRepairDao.STATUS_TERMINATE);
		map.put("id", businessRecordId);
		super.updateById(map);
		
		UTMap<String,Object> ut = super.getById(businessRecordId);
		if(null != ut){
			UTMap<String,Object> assets = assetPhysicalService.getById((String)ut.get("assetsId"));
			//发送消息
			String codeNum = (String) assets.get("codeNum");
			if (StringUtils.isNotEmpty(codeNum)) {
				codeNum = "/" + codeNum;
			}else {
				codeNum = "";
			}
			String title = "资产【"+assets.get("name")+codeNum+"】报修申请终止提醒";
			String content = "资产申请：【"+assets.get("name")+codeNum+"】报修申请已被终止，请知悉！详情请进入系统查看！";
			messageService.sendMessage(String.valueOf(ut.get("createUserId")),title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
			
		}
	}

	@Override
	public void getAssetsRepairRateCount(UTPageBean pageBean, Map params) {
		assetRepairDao.getAssetsRepairRateCount(pageBean, params);
	}
}