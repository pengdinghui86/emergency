package com.esc.oms.outsource.outperson.service;

import java.util.Map;


/**
 * 入场申请的 业务接口
 * @author smq
 * @date   2016-7-9 下午3:36:52
 */
public interface IApplyEnterService extends IApplyCommonService{
	
	// 保存 人员配置项
	public boolean saveConfigByUserId(Map<String, Object>info);
	
	//完善资料后结束刘
	public void overApply(String userId);
	}
