package com.esc.oms.outsource.outperson.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.outperson.dao.IOutSourcePersonBlacklistDao;

@Repository
public class OutSourcePersonBlacklistDaoImpl extends BaseOptionDao implements IOutSourcePersonBlacklistDao {

	@Override
	public String getTableName() {
		return "outsoure_person_black_list";
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean,Map params){
		super.getPageListMapBySql(getSearchSql(params), pageBean, null);
	}
	
	@Override
	public List<UTMap<String, Object>> getListMaps(Map params) {
		return super.getListBySql(getSearchSql(params));
	}
	
	private String getSearchSql(Map params){
		StringBuilder sql = new StringBuilder();
		sql.append("select tb.*,concat(su.name,'/',su.code) name,su.age,su.seniority,su.phone,su.email,sb.name as supplierName from outsoure_person_black_list tb");
		sql.append(" left join sys_user su on tb.userId = su.id");
		sql.append(" left join supplier_base_info sb on tb.supplierId = sb.id");
		sql.append(" where 1 = 1");
		
		if(params!=null && params.size()>0){
			if(params.get("id")!=null &&  StringUtils.isNotEmpty(params.get("id").toString())){
				sql.append(" and tb.id = '"+params.get("id")+"' ");
			}
			if(params.get("name")!=null && StringUtils.isNotEmpty(params.get("name").toString())){
//				sql.append(" AND su.name like '%"+params.get("name").toString().trim()+"%' ");
				sql.append(" and CONCAT(su.name,'/',su.code) like '%"+params.get("name").toString().trim()+"%' ");
			}
			if(params.get("idCode")!=null && StringUtils.isNotEmpty(params.get("idCode").toString())){
				sql.append(" AND tb.idCode like '%"+params.get("idCode").toString().trim()+"%' ");
			}
			if(params.get("isClear")!=null && StringUtils.isNotEmpty(params.get("isClear").toString())){
				sql.append(" AND tb.isClear='"+params.get("isClear").toString().trim()+"' ");
			}
			if(params.get("isEnd")!=null && StringUtils.isNotEmpty(params.get("isEnd").toString())){
				sql.append(" AND tb.isEnd='"+params.get("isEnd").toString().trim()+"' ");
			}
		}
		sql.append(" order by tb.createTime desc, tb.sortCode");
		return sql.toString();
	}
	
	@Override
	public UTMap<String, Object> getById(String id){
		Map params = new HashMap();
		params.put("id", id);
		return this.getOneBySql(getSearchSql(params), null);
	}

}
