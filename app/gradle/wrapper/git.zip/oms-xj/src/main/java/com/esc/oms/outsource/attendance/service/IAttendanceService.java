package com.esc.oms.outsource.attendance.service;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 考勤Service接口
 * @author owner
 *
 */
public interface IAttendanceService extends IBaseOptionService {
	
	/**
	 * 定时根据考勤规则以及节假日配置生成考勤数据
	 * 考勤数据生成逻辑：
	 * 1.	如果考勤规则配置为周一至周日均需考勤，则为全年无休情况，不考虑节假日等因素，全年生成考勤
	 * 2.	其他情况如下处理：
	 * 	1）	如果当天为节假日、调休、其他（节假日配置中配置的法定节假日、调休、其他），不生成考勤
	 * 	2）	如果当天为周末（节假日配置中配置的周末），根据考勤规则生成考勤
	 * 	3）	如果当天为工作日（节假日配置中配置的工作日），生成考勤
	 * 	4）	其他情况，根据考勤规则生成考勤
	 */
	public void initCurrentDateAttendance();
	
	/**
	 * 重新计算所有考勤数据的考勤工时
	 */
	public void updateAllAttTime();
	
	/**
	 * 获取当前登录用户的考勤数据
	 * @return
	 */
	public UTMap<String, Object> getCurUserAttendance(String date);
	
	/**
	 * 根据用户编号和考勤日期获取用户的考勤数据
	 * @return
	 */
	public UTMap<String, Object> getCurUserAttendance(String date, String userId);
	
	/**
	 * 判断前一天的考勤是否需要跨天签退
	 * @param date
	 * @return
	 */
	public boolean isAcrossDay(Date date);
	
	/**
	 * 签到
	 */
	public void userDatein(Map param);
	
	/**
	 * 签退
	 */
	public void userDateout(Map param);
	
	/**
	 * 检查当前时间是否签到异常(//是否迟到 1:迟到;0:正常,-1:未签到)
	 * @param userConfig
	 * @return
	 */
	public int checkDateinStyle(UTMap<String, Object> userConfig, Date date);

	/**
	 *
	 * @param userConfig
	 * @param date
	 * @param season 时令，冬令时 夏令时
	 * @return
	 */
	public int checkDateinStyle(UTMap<String, Object> userConfig, Date date, String season);
	
	/**
	 * 检查当前时间是否签退异常(是否早退1：早退;0:正常;-1:未签退)
	 * @param userConfig
	 * @return
	 */
	public int checkDateoutStyle(UTMap<String, Object> userConfig, Date date);

	/**
	 *
	 * @param userConfig
	 * @param date
	 * @param workDate
	 * @param season时令，冬令时 夏令时
	 * @return
	 */
	public int checkDateoutStyle(UTMap<String, Object> userConfig, Date date, String season, String workDate);

	/**
	 * 查询考勤日历的数据
	 * @param param
	 * @return
	 */
	public List getAttendanceCalendarDate(Map param);
	
	/**
	 * 修改考勤异常原因
	 */
	public void updateReason(Map param);
	
	/**
	 * 检查指导考勤数据的加班、请假、出差汇总数据，同时判断对应的考勤异常状态
	 * @param userId 用户id
	 * @param dateStr 加班、请假、出差日期
	 */
	public int updateAttTime(String userId, String dateStr);
	
	/**
	 * 修改考勤签到签退时间,并且根据请假和出差判断考勤状态
	 * @param param
	 * @param isPage 是否从前端页面修改调用，用来判断是否要修改updateRemark
	 */
	public void updateAttTime(Map param,boolean isPage);
	
	/**
	 * 修改考勤签到签退时间,并且根据请假和出差判断考勤状态
	 */
//	public void updateAttTime(Map param);
	
	/**
	 * 导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	public void leadingout(List data, HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	/**
	 * 根据考勤规则和日期手动生成对应用户的考勤数据,这种情况用于用户节假日过来加班，手动生成考勤数据
	 * @param date 考勤日期
	 * @param userConfig 考勤规则
	 */
	public void mnulAddAttendance(Date date, UTMap<String, Object> userConfig, String remoteAddr);
	
	/**
	 * 获取个人考勤工时统计数据
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllAttHours(Map param);
	
	/**
	 * 获取个人考勤工时统计数据
	 * @param pageBean
	 * @param param
	 */
	public void getAttHours(UTPageBean pageBean,Map param);
	
	
	/**
	 * 获取供应商常规考勤维度统计数据
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllSupplierConventional(Map param);
	
	/**
	 * 获取供应商常规考勤维度统计数据
	 * @param pageBean
	 * @param param
	 */
	public void getSupplierConventional(UTPageBean pageBean,Map param);
	
	/**
	 * 获取组织机构常规考勤维度统计数据
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllOrgConventional(Map param);
	
	/**
	 * 获取组织机构常规考勤维度统计数据
	 * @param pageBean
	 * @param param
	 */
	public void getOrgConventional(UTPageBean pageBean,Map param);
	
	/**
	 * 常规考勤统计（个人）
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	public void leadingoutAttHours(List data, HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	/**
	 * 常规考勤统计（供应商）
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	public void leadingoutAttSupplierConventional(List data, HttpServletRequest request,HttpServletResponse response) throws Exception;
	
	/**
	 * 常规考勤统计（部门）
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	public void leadingoutAttOrgConventional(List data, HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	
	/**
	 * 获取联合考勤工时统计数据
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllCoalitionAttHours(Map param);
	
	/**
	 * 获取联合考勤工时统计数据
	 * @param pageBean
	 * @param param
	 */
	public void getCoalitionAttHours(UTPageBean pageBean,Map param);
	
	/**
	 * 联合考勤统计
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	public void leadingoutCoalitionAttHours(List data, HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	/**
	 * 退厂申请删除相应的考勤数据
	 * @param userId
	 * @param date
	 */
	public void deleteByPersonExit(String userId, String date);

	public int getAttendanceDateType(UTMap<String, Object> userConfig);

	public List<Map> addAttendanceSync(List<UTMap<String, Object>> userConfigs,Date date);
	
}
