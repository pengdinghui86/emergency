package com.esc.oms.outsource.manhour.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;


/**
 * 工时出差service
 * @author lenovo
 *
 */
public interface ITravelService extends IBaseOptionService {

	public static final String STATUS_NOT_SUBMIT = "1";	// 未提交
	public static final String STATUS_SUBMITD = "2";	// 提交待审批
	public static final String STATUS_AUDITING = "3";	// 审批中
	public static final String STATUS_REJECT = "4";	// 驳回
	public static final String STATUS_FINISH = "5";	// 审批通过
	public static final String STATUS_TERMINATE = "6";	// 终止
	
	/**
	 * 根据条件查询
	 * @param param 查询条件
	 * @return
	 */
	public List<UTMap<String, Object>> getTravelList(Map param) ;
	/**
	 * 获取分页数据
	 * @param pageBean
	 * @param param
	 * @return
	 */
	public UTPageBean getTravelPage(UTPageBean pageBean,Map param);
	
	public boolean leadingout(List data, HttpServletRequest request, HttpServletResponse response) throws Exception;

	/**
	 * 保存数据并提交
	 * @param map
	 */
	public void submit(Map<String,Object> map);

	/**
	 * 完成审核
	 * @param recordId 记录ID
	 */
	public void auditing(String recordId);
	
	/**
	 * 完成审核
	 * @param recordId 记录ID
	 */
	public void finishAudit(String recordId);
	
	/**
	 * 驳回审核
	 * @param recordId 记录ID
	 */
	public void rejectAudit(String recordId);
	/**
	 * 终止审核
	 * @param recordId
	 */
	public void terminateAudit(String recordId);

	/**
	 * 添加详细信息
	 * @param info 父表单信息
	 * @return
	 */
	public boolean addDetail(Map info);
	
	/**
	 * 撤销
	 * @param info
	 * @return
	 */
	public boolean undo(Map info);
	
}
