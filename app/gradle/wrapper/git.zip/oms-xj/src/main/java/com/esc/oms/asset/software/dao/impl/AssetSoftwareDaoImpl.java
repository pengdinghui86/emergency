package com.esc.oms.asset.software.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.asset.software.dao.IAssetSoftwareDao;
import com.esc.oms.util.RoleUtils;

@Repository
public class AssetSoftwareDaoImpl extends BaseOptionDao implements
		IAssetSoftwareDao {

	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params), pageBean, null);
	}
	
	@Override
	public List<UTMap<String, Object>> getListMaps(Map param) {
		return super.getListBySql(getSearchSql(param), null);
	}
	
	public String getSearchSql(Map params){
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT asi.id, asi.code,asi.name,sc.name as category,ssc.name as subCategory,asi.chargeId,asi.beginDate,asi.endDate,asi.version,asi.status,asi.supplierId,asi.softmaintainStartDate,"
				+ "asi.softmaintainEndDate,sbi.name AS supplierName,concat(su.name,'/',su.code) AS chargeUser,asi.brand,asi.maintenance,asi.isSafeControl FROM assets_software_library asi");
		sb.append(" LEFT JOIN supplier_base_info sbi ON sbi.id = asi.supplierId ");
		sb.append(" LEFT JOIN sys_user su ON su.id = asi.chargeId ");
		sb.append(" LEFT JOIN software_category sc ON sc.id = asi.category ");
		sb.append(" LEFT JOIN software_sub_category ssc ON ssc.id = asi.subCategory ");
		sb.append("	WHERE 1=1");
		
		if(params!=null && params.size()>0){		
			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
				sb.append(" AND asi.name like '%"+params.get("name").toString().trim()+"%' ");
			}
			if(params.get("supplierId")!=null && StringUtils.isNotEmpty(params.get("supplierId").toString())){
				sb.append(" AND asi.supplierId = '"+params.get("supplierId").toString().trim()+"' ");
			}
			if(params.get("category")!=null && StringUtils.isNotEmpty(params.get("category").toString())){
				sb.append(" AND asi.category = '"+params.get("category").toString().trim()+"' ");
			}
			if(params.get("subCategory")!=null && StringUtils.isNotEmpty(params.get("subCategory").toString())){
				sb.append(" AND asi.subCategory = '"+params.get("subCategory").toString().trim()+"' ");
			}
			if(params.get("brand")!=null &&  StringUtils.isNotEmpty(params.get("brand").toString())){
				sb.append(" AND asi.brand like '%"+params.get("brand").toString().trim()+"%' ");
			}
			if(params.get("agreementId")!=null && StringUtils.isNotEmpty(params.get("agreementId").toString())){
				sb.append(" AND asi.agreementId = '"+params.get("agreementId").toString().trim()+"' ");
			}
			if(params.get("isFilter")!=null && StringUtils.isNotEmpty(params.get("isFilter").toString())){
				//数据权限过滤
				if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR,RoleUtils.ASSET_MANAGER)){
					sb.append("  and asi.chargeId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' ");
				}
			}
			if(params.get("status")!=null && StringUtils.isNotEmpty(params.get("status").toString())){
				sb.append(" AND asi.status in ("+params.get("status").toString().trim()+")");
			}
			//还有一个月到期的就查出来。
			if(params.get("isExpire")!=null && StringUtils.isNotEmpty(params.get("isExpire").toString())){
				sb.append(" AND DATE_ADD(CURDATE(),INTERVAL 1 MONTH) > asi.endDate AND asi.status <> 4");
			}
		}
			
		sb.append(" order by asi.createTime desc ,asi.operation");
		return sb.toString();
	}
	
	
	
//	public String getSoftwareByIdSql(String id){
//		StringBuilder sb = new StringBuilder();
//		sb.append("SELECT asi.* FROM assets_software_library asi WHERE 1=1");
//		sb.append(" AND asi.id = '"+id+"'");
//		return sb.toString();
//	}
	
	@Override
	public UTMap<String, Object> getById(String id) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select  tb.*,s.name as supplierName,ai.agreementName,ai2.agreementName as maintainContractName,concat(su.name,'/',su.code) AS chargeUser from assets_software_library tb");
		sql.append(" left join supplier_base_info s on tb.supplierId = s.id");
		sql.append(" left join assets_agreement_info ai on tb.agreementId = ai.id ");
		sql.append(" left join assets_agreement_info ai2 on tb.maintainContract = ai2.id ");
		sql.append(" LEFT JOIN sys_user su ON su.id = tb.chargeId ");
		sql.append(" where 1 = 1");
		sql.append(" and  tb.id = '").append(id).append("'");
		return super.getOneBySql(sql.toString(), null);
	}

	@Override
	public List<UTMap<String, Object>> getSoftwareList(Map param) {
		return super.getListBySql(getSearchSql(param));
	}

	@Override
	public String getTableName() {
		return "assets_software_library";
	}

}
