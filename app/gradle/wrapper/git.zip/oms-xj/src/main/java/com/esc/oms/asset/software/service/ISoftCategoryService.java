package com.esc.oms.asset.software.service;

import java.util.List;
import java.util.Map;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;


public interface ISoftCategoryService extends IBaseOptionService{
	

	public List<UTMap<String, Object>> getListCategory(Map params) ;
	
	public boolean addSubCategory(Map info);
	
	
	/**
	 * 修改
	 * @param info
	 * @return
	 */
	public boolean updateSubCategoryById(Map info);
	
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	public UTMap<String, Object> getSubCategoryById(String id);
	
	
	/**
	 * 删除
	 * @param info
	 * @return
	 */
	public boolean deleteSubCategory(Map info);
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	public List<UTMap<String, Object>> getSubCategoryByParentId(String parentId);
	
	public String getCategoryIdByName(Map<String,Object> params);
	
	public String getSubCategoryIdByName(Map<String,Object> params);
	
	
	public List<UTMap<String, Object>> getCategoryByNameAndId(String name,String id);
	
	public UTMap<String, Object> getSubCategoryByNameAndCategoryId(String name,String id);
	
	public List<UTMap<String, Object>> getSubCategoryByNameAndCategoryIdAndSubCategoryId(String name,String id,String parentId);

	public List<UTMap<String, Object>> getCategoryByType(String type) ;
}
