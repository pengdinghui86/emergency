package com.esc.oms.outsource.outperson.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.esc.framework.dict.dao.ISysParamDao;
import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.timetask.anotations.CronTimeTask;
import org.esc.framework.timetask.anotations.TimeTaskMark;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.outperson.dao.IOutSourcePersonBlacklistDao;
import com.esc.oms.outsource.outperson.service.IOutSourcePersonBlacklistService;
import com.esc.oms.supplier.info.dao.ISupplierBaseInfoDao;
import com.esc.oms.supplier.supplieremp.dao.ISupplierEmpWorkrecordDao;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.FunctionEnum.WorkRecordType;
import com.esc.oms.util.RoleUtils;

@Service
@Transactional
@TimeTaskMark
public class OutSourcePersonBlacklistServiceImpl extends BaseOptionService implements IOutSourcePersonBlacklistService {

	@Resource
	private ISysParamDao paramDao;
	
	@Resource
	private ISysUserService sysUserService;
	
	@Resource
	private ISysParamService sysParamService;
	
	@Resource
	private ISupplierBaseInfoDao supplierBaseInfoDao;
	
	@Resource
	private IOutSourcePersonBlacklistDao outSourcePersonBlacklistDao;
	
	@Resource
	private MessageSend messageService;
	
	@Resource
	private ISupplierEmpWorkrecordDao workrecordDao;
	
	protected Logger logger = LoggerFactory.getLogger(getClass());
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return outSourcePersonBlacklistDao;
	}
	
	/**
	 * @param paramType 参数类型
	 * @param data 参数值
	 * @return 参数名称
	 */
	private String vaule2Name(String paramType ,String data){
		if(StringUtils.isEmpty(data)){
			return null;
		}
		Map<String, String> value2NameMap = new HashMap<String, String>();
		List<UTMap<String, Object>> paramList = paramDao.getValuesByType(paramType);
		for (UTMap<String, Object> param : paramList) {
			String name = (String) param.get("name");
			String value = (String) param.get("value");
			value2NameMap.put(value, name);
		}
		return value2NameMap.get(data);
	}
	
	
	@UploadAddMark
	public boolean add(Map info){
		String userId = info.get("userId") != null ? info.get("userId").toString() : "";
		if (StringUtils.isNotEmpty(userId)) {
			Map map = new HashMap();
			map.put("userId", userId);
			map.put("isClear", 0);
			if (outSourcePersonBlacklistDao.isExist(map)) {
				throw new EscServiceException("人员重复，请检查");
			}
		}
		info.put("isEnd", "0");
		info.put("isClear", "0");
		
		//供应商人员工作轨迹
		workrecordDao.add(info.get("userId").toString(), 
						"外包人员黑名单", 
						info.get("beginDate").toString(), 
						info.get("endDate")==null?null:info.get("endDate").toString(), 
						info.get("blackListType").toString().equals("1")?"暂不录用":"永不录用", 
						vaule2Name("supplierBlackReason", info.get("reason").toString()) , 
						WorkRecordType.BLACKLIST);
		
		return	super.add(info);
	}
	
	@UploadAddMark
	public boolean updateById(Map info){
		Map param = new HashMap();
		param.put("userId", info.get("userId"));
		param.put("recordType",  WorkRecordType.BLACKLIST.getValue());
		workrecordDao.delete(param);
		
		//供应商人员工作轨迹
		workrecordDao.add(info.get("userId").toString(), 
						"外包人员黑名单", 
						info.get("beginDate").toString(), 
						info.get("endDate")==null?null:info.get("endDate").toString(), 
						info.get("blackListType").toString().equals("1")?"暂不录用":"永不录用", 
						vaule2Name("supplierBlackReason", info.get("reason").toString()) , 
						WorkRecordType.BLACKLIST);
		return super.updateById(info);
	}
	
	@UploadQueryMark
	public UTMap<String, Object> getById(String id){
		return  super.getById(id);
	}
	
	public boolean deleteById(String id){
		UTMap<String, Object> info = super.getById(id);
		//删除工作轨迹
		Map param = new HashMap();
		param.put("userId", info.get("userId"));
		param.put("recordType",  WorkRecordType.BLACKLIST.getValue());
		workrecordDao.delete(param);
		return super.deleteById(id);
	}
	
	@Override
	public boolean leadingin(String filePath, Map<String, Object> param) throws Exception {
		
		String[] cellArray = new String[] { 
				"所属供应商*", 
				"姓名*",
				"身份证号*", 
				"黑名单类别*",
				"期限", 
				"开始日期*（格式：yyyy/MM/dd）", 
				"结束日期（格式：yyyy/MM/dd）", 
				"原因*", 
				"原因说明*（长度：0-500）"
		};
		int[] lengthArr = {0, 0, 0, 0, 0, 0, 0, 0, 500};
		String [] fileds = new String[] {"supplierId","userId","idCode","blackListType","term",
										  "beginDate","endDate","reason","remark"};
		
		List<UTMap<String, Object>> recordList = new ArrayList<UTMap<String, Object>>();
		boolean flag = true;
		
		Sheet sheet = UTExcel.getSheets(filePath)[0];
		int rowNum = sheet.getLastRowNum();
		int cellNum = fileds.length;
		
		//检查导入的字段标题
		try {
			List<String> realityCellllist = new ArrayList<String>();
			Row rowtitle = sheet.getRow(0);
			for (int j = 0; j < cellNum; j++) {
				realityCellllist.add(rowtitle.getCell(j).getStringCellValue());
			}
			String[] array = new String[realityCellllist.size()];
			if(!UTExcel.excelValidateByCell(cellArray, realityCellllist.toArray(array))){
				flag = false;
			}
		} catch (Exception e) {
			flag = false;
		}
		
		if(!flag) {
			throw new EscServiceException("导入失败，请选择正确的模板！");
		}
		
		//查询外包人员
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("state", "1");
		params.put("userType", "3");
		List<UTMap<String,Object>> users = sysUserService.getListMaps(params);
		
		//供应商
		List<UTMap<String, Object>>  suppliers = supplierBaseInfoDao.getAll();
		
		ParamTransform ptf = new ParamTransform("supplierBlackReason");
		StringBuilder error = new StringBuilder();
		for (int i = 1; i <= rowNum; i++) {
			Row row = sheet.getRow(i);
			UTMap<String,Object> map = new UTMap<String, Object>();
			for (int j = 0; j < cellNum; j++) {
				String cellValue = null;
				Cell cell = row.getCell(j);
				if (cell != null) {
					cell.setCellType(Cell.CELL_TYPE_STRING);
					cellValue = cell.getStringCellValue();
					cellValue = StringUtils.isNotBlank(cellValue) ? cellValue.trim() : null ;
				}
				//检查空
				if(j == 0 || j == 1 || j==2 ||  j == 3 || j == 5 || j == 7 || j == 8) {
					flag = StringUtils.isEmpty(cellValue) ? false : true;
					if (!flag) {
						error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "内容为空，请检查！" + "<br>");
					}
				}
				if (cellValue != null) {
					//长度校验
					if (lengthArr[j] != 0 && cellValue.length() > lengthArr[j]){
						error.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "内容长度超出限制，请检查！" + "<br>");
					}
					if(j == 0){ //供应商
						try{
							cellValue = CommonUtils.getIdsBySupplierNameAndCodes(suppliers,cellValue);
						}catch(EscServiceException e){
							error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "列，" + e.getMessage() + "<br>");
						}
					}
					if(j == 1){ //姓名
						try{
							cellValue = CommonUtils.getIdByUserNameAndCode(users,cellValue, null);
						}catch(EscServiceException e){
							error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "列，" + e.getMessage() + "<br>");
						}
					}
					if(j == 3){ //黑名单类别
						if("暂不录用".equals(cellValue)){
							cellValue = "1";
						}else if("永不录用".equals(cellValue)){
							cellValue = "2";
						}else{
							error.append("Excel内容错误，行号为" + (i+1) + "的黑名单类别'" + cellValue + "'在系统中不存在，请检查！" + "<br>");
						}
					}
					
					if(j == 5 && cellValue != null){ //开始时间
						if (!CommonUtils.validateDate(cellValue)) {
							error.append("Excel内容错误，行号为" + (i+1) + "的服务开始时间'" + cellValue + "'格式不正确，请检查！" + "<br>");
						}
					}
					if(j == 6){ //结束日期（非必填）
						if (cellValue != null) {
							if (!CommonUtils.validateDate(cellValue)) {
								error.append("Excel内容错误，行号为" + (i+1) + "的结束日期'" + cellValue + "'格式不正确，请检查！" + "<br>");
							}
							String beginDate = CommonUtils.replaceAll((String)map.get("beginDate"), "/", "-");
							String endDate = CommonUtils.replaceAll(cellValue, "/", "-");
							if (compareDate(beginDate, endDate) > 0) {	
								error.append("Excel内容错误，行号为" + (i+1) + "的结束日期早于开始日期，请检查！" + "<br>");
							}
						}
					}
					if(j == 7){ //原因
						cellValue = ptf.name2Value(cellValue);
						if (StringUtils.isEmpty(cellValue)) {
							error.append("Excel内容错误，行号为" + (i+1) + "的原因在系统不存在，请检查！" + "<br>");
						}
					}
				}
				if(j==4){ //期限 如果黑名单类别为“暂不录用”则必填
					String blackListType = (String)map.get("blackListType");
					if("1".equals(blackListType)){
						flag = StringUtils.isEmpty(cellValue) ? false : true;
						if (!flag) {
							error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "内容为空，请检查！" + "<br>");
						}
					}
				}
				map.put(fileds[j], cellValue);
			}
			map.put("isEnd", "0");
			map.put("isClear", "0");
			map.put("sortCode", System.currentTimeMillis()); 
			
			String userId = map.get("userId") != null ? map.get("userId").toString() : "";
			if (StringUtils.isNotEmpty(userId)) {
				Map<String, Object> info = new HashMap<String, Object>();
				info.put("userId", userId);
				info.put("isClear", 0);
				if (outSourcePersonBlacklistDao.isExist(info)) {
					error.append("Excel内容错误，行号为" + (i+1) + "的人员在系统中已存在，请检查！" + "<br>");
				}
			}
			recordList.add(map);
		}
		
		for (int i=0;i<recordList.size();i++) {
			UTMap<String, Object> item = recordList.get(i);
			String userId = (String) item.get("userId");
			String supplierId = (String) item.get("supplierId");
			String idCode = (String) item.get("idCode");
			
			if (StringUtils.isNotEmpty(userId) && StringUtils.isNotEmpty(supplierId) && StringUtils.isNotEmpty(idCode)) {
				Map<String, Object> mp = new HashMap<String, Object>();
				mp.put("userId", userId);
				mp.put("supplierId", supplierId);
				mp.put("idCode", idCode);
				List<UTMap<String, Object>> userList = sysUserService.getListMaps(mp);
				if (null == userList || userList.isEmpty()) {
					error.append("Excel内容错误，行号为" + (i+2) + "的人员在系统中不存在，请检查！");
				}
			}
			
		}
		if (StringUtils.isNotEmpty(error.toString())) {
			throw new EscServiceException(error.toString());
		}
		
		if (!recordList.isEmpty()) {
			for (int i=0;i<recordList.size();i++) {
				UTMap<String, Object> item = recordList.get(i);
				try{
					this.add(item);
				}catch(EscServiceException ex){
					throw new EscServiceException("Excel内容错误，行号为" + (i+2) + "的人员在系统中已存在，请检查！");
				}
			}
		}
		return flag;
	}
	
	/**
	 * 判断字符串是否是日期格式 (yyy-MM-dd)
	 * @param str
	 * @return
	 */
	private boolean isValidDate(String str) {
		try {
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			format.setLenient(false);
			format.parse(str); 
			return true;
		} catch (ParseException e) {
			return false;
		}
	}
	
	
	/**
	 * 比较两个日期大小
	 * @param dateStr1
	 * @param dateStr2
	 * @return 如果dateStr1小于dateStr2，返回-1；如果dateStr1大于dateStr2，返回1；如果dateStr1等于dateStr2，返回0。
	 * @throws EscServiceException
	 */
	private int compareDate(String dateStr1, String dateStr2) throws EscServiceException {
		try {
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Date date1 = format.parse(dateStr1);
			Date date2 = format.parse(dateStr2);
			if (date1.getTime() < date2.getTime()) {
				return -1;
			}
			else if (date1.getTime() > date2.getTime()) {
				return 1;
			}
			else {
				return 0;
			}
		} catch (ParseException e) {
			throw new EscServiceException("日期比较时出错");
		}
	}
	
	/**
	 * 参数数据转换器, 用于将参数value转换成参数name.
	 */
	private class ParamTransform {
		
		private Map<String, String> name2ValueMap;
		
		/**
		 * 构造函数
		 * @param paramType 参数类型
		 */
		public ParamTransform(String paramType) {
			this.name2ValueMap = new HashMap<String, String>();
			
			List<UTMap<String, Object>> paramList = paramDao.getValuesByType(paramType);
			for (UTMap<String, Object> param : paramList) {
				String name = (String) param.get("name");
				String value = (String) param.get("value");
				name2ValueMap.put(name, value);
			}
		}
		
		/**
		 * 将参数name转换成value
		 * @param names
		 * @return value
		 */
		public String name2Value(String name) {
			return name2ValueMap.get(name);
		}
		
	}

	@Override
	public boolean leadingout(List data, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		String[] fields = new String[] {"supplierName", "name", "idCode", "blackListType",
											"term","beginDate", "endDate","isEnd","isClear","reason","remark" };
		//替换下拉的值
		Map<String, String> fieldAndParamType = new HashMap<String, String>();
		fieldAndParamType.put("reason", "supplierBlackReason"); //原因
		fieldAndParamType.put("isEnd", "YesNo"); //是否到期
		fieldAndParamType.put("isClear", "YesNo"); //是否解除
		sysParamService.changeParamData(data, fieldAndParamType);
		
		String template = "excelOutTamplate.personBlacklist";
		return UTExcel.leadingout(fields, data, template, request,response);
	}
	
	
	
	@CronTimeTask(description="外包人员黑名单到期提醒定时任务",cron="0 0 23 * * ?")
	@Override
	public void execute() {
		logger.info("~~~~~~~~~~~~~~外包人员黑名单到期提醒任务开始~~~~~~~~~~~~~~~~");
		Map params = new HashMap();
		params.put("isEnd", "0");  //未到期的
		List<UTMap<String, Object>> list = outSourcePersonBlacklistDao.getListMaps(params);

		// 获取所有外包管理员
		List<String> userIds = new ArrayList<String>();
		Map<String,Object> param = new HashMap<String,Object>();
		param.put("signature", RoleUtils.OUTSOURCE_MANAGER);
		List<UTMap<String, Object>> users = sysUserService.getUserBaseInfo(param);
		for (UTMap<String, Object> utMap : users) {
			userIds.add((String) utMap.get("id"));
		}

		String title = "外包人员黑名单到期提醒";
		for (UTMap<String, Object> map : list) {
			if (map.get("endDate") != null) {
				Date endDate = UTDate.parseDate((String) map.get("endDate"));
				if (isSameDate(new Date(), endDate) || endDate.before(new Date())) { //黑名单结束日期为当天或之前
					map.put("isEnd", "1"); //设为已到期
					outSourcePersonBlacklistDao.updateById(map);
					
					String content = "外包人员【" + (String) map.get("name") + "】的黑名单已到期，请及时处理！";
					//给外包管理员发送系统消息和邮件
					messageService.sendMessage(userIds, title, content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
				}
			}
		}
	}
	
	/**
	 * @param date1
	 * @param date2
	 * @return
	 * 判断两个日期是否为同一天
	 */
	private boolean isSameDate(Date date1, Date date2) {
		Calendar cal1 = Calendar.getInstance();
		cal1.setTime(date1);
		Calendar cal2 = Calendar.getInstance();
		cal2.setTime(date2);
		boolean isSameYear = cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR);
		boolean isSameMonth = isSameYear && cal1.get(Calendar.MONTH) == cal2.get(Calendar.MONTH);
		boolean isSameDate = isSameMonth && cal1.get(Calendar.DAY_OF_MONTH) == cal2.get(Calendar.DAY_OF_MONTH);
		return isSameDate;
	 }

}
