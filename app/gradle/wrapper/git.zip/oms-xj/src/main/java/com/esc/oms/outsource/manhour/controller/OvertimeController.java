package com.esc.oms.outsource.manhour.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTListResult;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.outsource.attendance.service.IUserConfigService;
import com.esc.oms.outsource.manhour.service.IManHourStatisticService;
import com.esc.oms.outsource.manhour.service.IOvertimeService;
import com.esc.oms.util.CommonUtils;

@Controller
@RequestMapping("outsource/overtime")
public class OvertimeController extends BaseOptionController {

	@Resource
	private IOvertimeService overtimeService;
	
	@Resource
	private IUserConfigService userConfigService;
	
	@Resource
	private IManHourStatisticService manHourStatisticService;

	@Override
	public IBaseOptionService optionService() {
		return overtimeService;
	}

	/**
	 * 执行默认的条件查询方法
	 * 
	 * @param param
	 * @return
	 */
	@RequestMapping(value = "getOvertimeList")
	@ResponseBody
	public UTListResult getOvertimeList(@RequestParam Map<String, Object> param) {
		UTListResult result = new UTListResult();
		try {
			List<UTMap<String, Object>> list = overtimeService.getOvertimeList(param);
			result.setRows(list);
			result.setTotal(list.size());
		} catch (Exception e) {
			logger.error("Exception", e);
		}
		return result;
	}
	

	/**
	 * 新建或者编辑
	 * @param map
	 * @return
	 */
	@RequestMapping(value="save", method=RequestMethod.POST)  
    @ResponseBody
    public Map<String, Object> save(@RequestBody Map<String,Object> map1) {
		Map<String,Object> map = CommonUtils.clone(map1);
		try {
			//刚开始
			//驳回后可以修改和删除
			if(!IOvertimeService.STATUS_SUBMITD.equals(String.valueOf(map.get("status")))) {
				map.put("status", IOvertimeService.STATUS_NOT_SUBMIT);
			}
			if(StringUtils.isEmpty((String) map.get("id"))) {
				overtimeService.add(map);
			} else {
				overtimeService.updateById(map);
			}
			map.put("success", true);
			map.put("msg", "操作成功！");
		}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		map.put("success", false);
    		map.put("msg", e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		map.put("success", false);
    		map.put("msg", "操作失败！");
    	}
       return map;
	}
	
	/**
	 * 提交审批
	 * @param map
	 * @return
	 */
	@RequestMapping(value="submit", method=RequestMethod.POST)  
    @ResponseBody
    public Map<String, Object> submit(@RequestBody Map<String,Object> info) {
		Map<String,Object> cloneMap = CommonUtils.clone(info);
		try {
			overtimeService.submit(cloneMap);
			cloneMap.put("success", true);
			cloneMap.put("msg", "操作成功！");
		}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		cloneMap.put("success", false);
    		cloneMap.put("msg", e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		cloneMap.put("success", false);
    		cloneMap.put("msg", "操作失败！");
    	}
       return cloneMap;
	}
	
	/**
	 * 删除
	 * @param param
	 * @return
	 */
	@RequestMapping(value="delete")
	@ResponseBody
	public String delete(@RequestBody Map<String, Object> param){
		try{
			overtimeService.delete(param);
    	}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "删除失败");
    	}
    	return UTJsonUtils.getJsonMsg(true, "删除成功");
	}
	
	/**
	 * 撤销
	 * @param param
	 * @return
	 */
	@RequestMapping(value="undo")
	@ResponseBody
	public String undo(@RequestBody Map<String, Object> param){
		try{
			overtimeService.undo(param);
		}catch(EscServiceException e){
			logger.error("EscServiceException", e);
			return UTJsonUtils.getJsonMsg(false, e.getMessage());
		}catch(Exception e){
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "撤销失败");
		}
		return UTJsonUtils.getJsonMsg(true, "撤销成功");
	}
	
	/**
	 * 根据编号删除
	 * @param param
	 * @return
	 */
//	@RequestMapping(value="deleteByIds")
//	@ResponseBody
//	public String deleteByIds(@RequestBody Map<String, Object> info){
//		try{
//			String ids = (String) info.get("ids");
//			if(StringUtils.isNotEmpty(ids)) {
//				Map<String, Object> param = new HashMap<String, Object>();
//				for (String id : ids.split(",")) {
//					param.put("id", id);
//					overtimeService.delete(param);
//				}
//			}
//		}catch(EscServiceException e){
//			logger.error("EscServiceException", e);
//			return UTJsonUtils.getJsonMsg(false, e.getMessage());
//		}catch(Exception e){
//			logger.error("Exception", e);
//			return UTJsonUtils.getJsonMsg(false, "删除失败");
//		}
//		return UTJsonUtils.getJsonMsg(true, "删除成功");
//	}

	/**
	 * 分页查询
	 * 
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value = "getOvertimePage")
	@ResponseBody
	public UTPageBean getOvertimePage(@RequestParam Map<String, Object> params) {
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try {
			overtimeService.getOvertimePage(pageBean, params);
		} catch (Exception e) {
			logger.error("Exception", e);
		}
		return pageBean;
	}

	/**
	 * 根据id查询
	 * 
	 * @param param
	 * @return
	 */
	@RequestMapping(value = "getOvertimeById")
	@ResponseBody
	public UTMap<String, Object> getOvertimeById(
			@RequestParam Map<String, Object> param) {
		UTMap<String, Object> map = null;
		try {
			map = overtimeService.getById(param.get("id").toString());
		} catch (Exception e) {
			logger.error("Exception", e);
			return new UTMap<String, Object>();
		}
		return map;
	}

	@RequestMapping(value = "leadingout")
	public void leadingout(@RequestParam Map<String, Object> param,
			HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = null;
			if(info != null) {
				jsonBean = JSONObject.fromObject(info);
			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = overtimeService.getOvertimeList(UTMap.mapObjToString(jsonBean));
			} else {
				// 根据条件 导出当前
				overtimeService.getOvertimePage(utPageBean, UTMap.mapObjToString(jsonBean));
				data = utPageBean.getRows();
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			overtimeService.leadingout(data, request, response);
		}catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

	/**
	 * 计算当前人的工时
	 * 
	 * @param param
	 * @return
	 */
	@RequestMapping(value = "calculateHours")
	@ResponseBody
	public Map<String, Object> calculateHours(@RequestParam String beginTime, @RequestParam String endTime) {
		Map<String, Object> hours = null;
		try {
			UTMap<String, Object> userConfig = userConfigService.getUserConfigByUserId(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
			hours = manHourStatisticService.calculateOvertimeHours(beginTime, endTime, userConfig);
		} catch (EscServiceException e) {
			logger.error("Exception", e);
		} catch (Exception e) {
			logger.error("Exception", e);
		}
		return hours;
	}
}
