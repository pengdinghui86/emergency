package com.esc.oms.outsource.group.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.outsource.group.service.IGroupDefineService;
import com.esc.oms.util.CommonUtils;
@Controller
@RequestMapping("groupDefinde")
public class GroupDefineController extends BaseOptionController {


	@Resource
	private IGroupDefineService groupDefineService;
	
	@Override
	public IBaseOptionService optionService() {
		return groupDefineService;
	}
	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			groupDefineService.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
    @RequestMapping(value="/saveOrUpdate",method=RequestMethod.POST)  
    @ResponseBody
    public String saveorupdate(@RequestBody Map<String,Object> map){  
    	String groupName = (String)map.get("groupName");
    	String id = (String)map.get("id");
    	try{
	    	if( id== null){
	    		groupDefineService.add(map);
	    	}else{
	    		groupDefineService.updateById(map);
	    	}
    	}catch(EscServiceException e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false,e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "操作成功");
    }
    /**
	 * 从excel导入
	 * 
	 * @param params
	 * @param filePath
	 * @return
	 */
	@RequestMapping(value = "leadingin")
	@ResponseBody
	public UTMap<String, Object> leadingin(
			@RequestParam Map<String, Object> param, String filePath) {
		UTMap<String, Object> utMap = new UTMap<String, Object>();
		try {
			utMap.put("success", groupDefineService.leadingin(filePath, param));
			utMap.put("msg", "导入成功！");
		} catch (Exception e) {
			logger.error("Exception",e);
			utMap.put("success", false);
			utMap.put("msg", e.getMessage());
		}
		return utMap;
	}
	
	
	@RequestMapping(value = "leadingout")
	public void leadingout(@RequestParam Map<String, Object> param,
			HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = null;
			if(info != null) {
				jsonBean = JSONObject.fromObject(info);
			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = groupDefineService.getListMaps(jsonBean);
			} else {
			// 根据条件 导出当前
			//if (UTExcel.EXCELOUTTYPE_NOW == outType) {
				// getpage
				groupDefineService.getPageInfo(utPageBean, jsonBean);
				data = utPageBean.getRows();
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			groupDefineService.leadingout(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
}