package com.esc.oms.outsource.outperson.service;

import com.esc.oms.util.FunctionEnum.WorkRecordType;



public interface IPersonOptionService {
	
	public void timing();
	
	//获取时间区间类的每一天
	public void personFlowEveryDayResetting(String currectDate);
	
	public void addPersonFlowTimingQuit(String currectDate,String orgId,String supplierId);
	
	/**
	 *审批通过后 删除时处理用户关联业务
	 * @param userId
	 * @param deleteDate
	 * @param reason
	 * @param remark
	 * @param recordType
	 */
	public void deletePersonService(String userId,String deleteDate,String reason,String remark , WorkRecordType recordType);
	
}


