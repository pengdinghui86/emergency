package com.esc.oms.asset.software.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.asset.software.service.IAssetSoftwareService;
import com.esc.oms.asset.software.service.ISoftUpgradeService;
import com.esc.oms.util.CommonUtils;



@Controller
@RequestMapping("softUp")
public class SoftUpgradeController extends BaseOptionController {

	@Resource
	private ISoftUpgradeService softUpgradeService;
	
	@Resource
	private IAssetSoftwareService softService;
	
	
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			softUpgradeService.getPageInfo(pageBean, params);
			
			List<Map<String, Object>> list = pageBean.getRows();
			
			if(null != list && list.size() > 0 ){
				for (Map<String, Object> map : list) {
						String isOldDisabled = (String)map.get("isOldDisabled");
						if("1".equals(isOldDisabled)){
							map.put("isOldDisabled", "是");
						}else{
							map.put("isOldDisabled", "否");
						}
				}
			}
				
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	
	@RequestMapping(value="/saveOrUpdate",method=RequestMethod.POST)  
    @ResponseBody
    public String saveorupdate(@RequestBody Map<String,Object> map){  
		try {
			String id = (String) map.get("id");
			if (id == null) {
				softUpgradeService.add(map);
			} else {
				softUpgradeService.updateById(map);
			}
			
			//升级日期是否在今天之前，不包括今天
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String today = sdf.format(new Date());
			//升级日期
			Date upDate = sdf.parse((String) map.get("upDatee"));
			if (upDate.before(sdf.parse(today))) { // 若在今天之前（不包括今天），则生成历史记录，并更新软件的版本等信息	
				UTMap<String,Object> softMap = softService.getById(map.get("softwareId").toString());
				map.put("status", softMap.get("status"));			 
				softUpgradeService.upgrade(map);
			}
						
//			
//			//是否停用  1.停用
//			if ("1".equals((String) map.get("isOldDisabled"))) {
//				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//				String today = sdf.format(new Date());
//				//停用日期
//				Date disableDate = sdf.parse((String) map.get("disableDate"));
//				if (disableDate.before(sdf.parse(today))) { // disableDate before today
//					softUpgradeService.operation(map);
//				} 
//			}else{
//				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//				String today = sdf.format(new Date());
//				//升级日期
//				Date upDate = sdf.parse((String) map.get("upDatee"));
//				if (upDate.before(sdf.parse(today))) { // disableDate before today	
//					UTMap<String,Object> softMap = softService.getById(map.get("softwareId").toString());
//					map.put("status", softMap.get("status"));
//					softUpgradeService.operation(map);
//				} 
//			}
		} catch (EscServiceException e) {
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, e.getMessage());
		} catch (Exception e) {
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "操作失败");
		}
		return UTJsonUtils.getJsonMsg(true, "操作成功");
	}
	


	@RequestMapping(value="getById")
	@ResponseBody
	public UTMap<String, Object> defgetById(@RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = null;
    	try{
    		map = optionService().getById(param.get("id").toString());
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return map;
	}
	
	
	
	
	@RequestMapping(value = "leadingout")
	public void leadingout(@RequestParam Map<String, Object> map1,
			HttpServletRequest request,
			HttpServletResponse response) {
		Map<String,Object> cloneMap = CommonUtils.clone(map1);
		UTPageBean clonePageBean = CommonUtils.getPageBean(cloneMap);
		
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) cloneMap.get("outType"));
			Object info = cloneMap.get("params");
			JSONObject jsonBean = null;
			if(info != null) {
				jsonBean = JSONObject.fromObject(info);
			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = softUpgradeService.getSoftUpgradeList(jsonBean);
			} else {
			// 根据条件 导出当前
				softUpgradeService.getPageInfo(clonePageBean, jsonBean);
				data = clonePageBean.getRows();
			}
			
			if(null != data && data.size() > 0 ){
				for (Map<String, Object> map : data) {
						String isOldDisabled = (String)map.get("isOldDisabled");
						if("1".equals(isOldDisabled)){
							map.put("isOldDisabled", "是");
						}else{
							map.put("isOldDisabled", "否");
						}
						map.put("upDatee", CommonUtils.replaceAll((String) map.get("upDatee"), "-", "/"));
				}
			}
			
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			softUpgradeService.leadingout(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	
	@Override
	public IBaseOptionService optionService() {
		return softUpgradeService;
	}

}
