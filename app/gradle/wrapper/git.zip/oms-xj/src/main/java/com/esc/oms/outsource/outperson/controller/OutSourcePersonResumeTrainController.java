package com.esc.oms.outsource.outperson.controller;

import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.outsource.outperson.service.IOutSourcePersonResumeTrainService;
import com.esc.oms.util.CommonUtils;
@Controller
@RequestMapping("resumeTrain")
public class OutSourcePersonResumeTrainController extends BaseOptionController {

	@Resource
	private IOutSourcePersonResumeTrainService service;
	
	@Override
	public IBaseOptionService optionService() {
		return service;
	}
	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			service.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }	
	
}