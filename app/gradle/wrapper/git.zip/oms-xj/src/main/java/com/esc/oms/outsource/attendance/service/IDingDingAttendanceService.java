package com.esc.oms.outsource.attendance.service;

import org.esc.framework.utils.UTMap;

import java.util.List;
import java.util.Map;

/**
 * 钉钉同步接口
 */
public interface IDingDingAttendanceService {

    /**
     * 获取钉钉的access_token
     * @return
     */
    public String getaAccess_token();

    /**
     * 获取钉钉考勤 半个小时获取一次
     */
    public void getAndMergeAttendance();


    /**
     * 获取打卡结果
     * 每天同步获取一次早晚数据,工作日的早晚数据只有两条
     * 目的：获取当天关联的审批信息，
     * 处理当前场景：当用户缺卡时，当天的打卡记录是会没有的，但是会有打卡结果，这时可以得出关联的审批
     *              看是否请假外出
     * 每天获取三次， 早上3点一次，中午一次，晚上 24点一次，就可以了
     */
    public void getAndMergeAttendanceTwo();


    public void getAndMergeApprove(String startTime, String endTime);

    /**
     * 每半小时执行一次
     * 将暂存在approve表中的数据分类放入流程中
     * 没有的就新增，有改动的就修改状态
     */
    public void mergeApproves();



    /**
     * 根据开始时间和结束时间，获取考勤打卡详细记录
     * @param startTime
     * @param endTime
     * @param isFinal 是否是最后的一个循环
     */
    public void getAttendanceListByTime(String startTime, String endTime, boolean isFinal);

    /**
     * 获取加班审批模板id，加班有点特殊，获取不到
     */
    public void getOverTimeApproveId();

    /**
     * 获取配置的时令
     * @return
     */
    public List<UTMap<String, Object>> getSeason();

    /**
     * 检查冬令时和夏令时
     * @param time
     * @param list
     * @return
     */
    public String checkSeason(long time, List<UTMap<String, Object>> list);

    /**
     * 根据开始时间和结束时间获取审批实例
     * @param startTime
     * @param endTime
     * @return
     */
    public List<Map> getAndAddNonExistent(String startTime, String endTime);

    /**
     * 同步时间
     * @param startTime
     * @param endTime
     * @return
     */
    public boolean initAttendance(String startTime, String endTime, List<String> userIds, String dingIds,boolean daylily, boolean isFinal);

    /**
     * 导入 excel
     * @return
     */
    public boolean leadingInExcel(String filePath) throws Exception;

    /**
     * 获取补卡审批记录
     */
    public void getCardApply();

}
