package com.esc.oms.asset.overview.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

public interface IAssetsOverviewDao extends IBaseOptionDao{
	
	public static final String  FIELD_ID = "id";
	
	/**
	 * 根据条件查询-资产列表--分页
	 * @param params
	 */
	public void getAssetsPageList(UTPageBean pageBean, Map params);
	/**
	 * 根据条件查询-资产列表
	 * @param params
	 */
	public List<UTMap<String, Object>> getAssetsList(Map params);
	/**
	 * 预警期资产合同列表--分页
	 * @param pageBean
	 * @param params
	 */
	public void getWarnAgreementPageList(UTPageBean pageBean, Map params);
	/**
	 * 预警期资产合同列表
	 * @param params
	 * @return
	 */
	public List<UTMap<String, Object>> getWarnAgreementList(Map params);
	/**
	 * 资产统计--类别维度
	 * @param params
	 * @return
	 */
	public List<UTMap<String, Object>> getOverviewReportCategoy(Map<String, Object> params);
	
	/**
	 * 资产统计--月维度
	 * @param params
	 * @return
	 */
	public List<UTMap<String, Object>> getOverviewReportMonth(Map<String, Object> params);

	
}
