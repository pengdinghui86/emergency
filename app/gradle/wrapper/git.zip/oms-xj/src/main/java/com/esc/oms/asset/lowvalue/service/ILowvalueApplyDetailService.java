package com.esc.oms.asset.lowvalue.service;

import java.util.List;
import java.util.Map;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;


public interface ILowvalueApplyDetailService extends IBaseOptionService{
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params);
	/**
	 * 根据父表的条件查询，即根据领用记录查领用详单
	 * @param params
	 * @return
	 */
	public List<UTMap<String, Object>> getListAllByParentParam(Map params);
	/**
	 * 根据领用记录id（receptId）删除
	 * @param infoId
	 * @return
	 */
	public boolean deleteByApplyId(String applyId);
	/**
	 * 发放
	 * @param info
	 * @return
	 */
	public boolean grant(Map info);
	/**
	 * 确认
	 * @param info
	 * @return
	 */
	public boolean confirm(Map info);
	/**
	 * 驳回
	 * @param info
	 * @return
	 */
	public boolean reject(Map info);
	
}


