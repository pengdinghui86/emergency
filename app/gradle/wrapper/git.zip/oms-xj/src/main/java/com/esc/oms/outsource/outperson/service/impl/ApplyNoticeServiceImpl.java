package com.esc.oms.outsource.outperson.service.impl;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.EscPropertyHolder;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.outperson.dao.IApplyEnterDao;
import com.esc.oms.outsource.outperson.dao.IApplyExitDao;
import com.esc.oms.outsource.outperson.dao.IApplyNoticeDao;
import com.esc.oms.outsource.outperson.dao.IApplyQuitDao;
import com.esc.oms.outsource.outperson.service.IApplyCommonService;
import com.esc.oms.outsource.outperson.service.IApplyNoticeService;
import com.esc.oms.supplier.project.service.IProjectInfoService;
import com.esc.oms.util.RoleUtils;

@Service
@Transactional
public class ApplyNoticeServiceImpl extends BaseOptionService implements IApplyNoticeService{
	@Resource
	private IApplyNoticeDao applyNoticeDao;
	@Resource
	private IApplyEnterDao applyEnterDao;
	@Resource
	private IApplyExitDao applyExitDao;
	@Resource
	private IApplyQuitDao applyQuitDao;
	@Resource
	private MessageSend messageSend;
	@Resource
	private ISysUserService userService;
	
	@Resource
	private IProjectInfoService projectInfoService;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return applyNoticeDao;
	}
	

	public static final String KEY_SYSTEMURL= "system.rootAddress";
	public static final String KEY_SYSTEMNAME= "system.systemName";
	
	//记录发送邮件  applyType : enter exit quit
	public void sendApplyNoticeInfo( String applyId,String applyType){
		try {//添加try-catch捕获异常，防止消息推送异常影响流程的运行
			//发送
			if(StringUtils.equals(applyType, IApplyCommonService.APPLY_TYPE_ENTER)){
				sendNoticeINEnter(applyId);
			}
			else if(StringUtils.equals(applyType, IApplyCommonService.APPLY_TYPE_EXIT)){
				sendNoticeINExit(applyId);
			}
			else if(StringUtils.equals(applyType, IApplyCommonService.APPLY_TYPE_QUIT)){
				sendNoticeINQuit(applyId);
			}else {
				
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	// 根据申请类型 和申请人用户Id  获取 通知信息
	public List<UTMap<String, Object>> getApplyNoticeInfo(String applyUserId,String  applyId){
		Map<String, Object> param=new HashMap<String, Object>();
		param.put(IApplyNoticeDao.FIELD_PERSONID, applyUserId);
		param.put(IApplyNoticeDao.FIELD_APPLYID, applyId);
		return applyNoticeDao.getListMaps(param);
	}
	
	private void  sendNoticeINEnter(String applyId){

		//String systemUrl=EscPropertyHolder.instance.getProperty(KEY_SYSTEMURL);
		//String systemName=EscPropertyHolder.instance.getProperty(KEY_SYSTEMNAME);
		
		List<Map> lists=new ArrayList<Map>();
		
		//发送人获取
		Map<String, Object> applyInfo=applyEnterDao.getById(applyId);
		String enterUserId=applyInfo.get("enterUserId").toString();
		String enterUserName=applyInfo.get("enterUserName").toString();
		String sendTitle="【"+enterUserName+"】入场通知";
		String noticeType= IApplyCommonService.APPLY_TYPE_ENTER;
		//申请人（待处理人员）
		String loginName=applyInfo.get("loginName").toString();
		String role1="待入场人员";
		String content1="您的入场申请已完成，请及时登录系统修改密码！账号："+loginName+"，默认密码：123456";
		sendAndSaveInfo(lists, role1,sendTitle, content1, applyId, enterUserId, enterUserName,noticeType);
		
		/*//申请创建人
		String createUserId=applyInfo.get("createUserId").toString();
		String createUser=applyInfo.get("createUser").toString();
		createUser=createUser.substring(0, createUser.indexOf("/"));
		String role2="申请人";
		String content2="您提交的【"+enterUserName+"】入场申请各项权限已开通，请知悉！详情请进入系统查看";
		sendAndSaveInfo(lists, role2,sendTitle, content2, applyId, createUserId, createUser,noticeType);*/
		
		
		/*//获取所有外包管理员
		List<UTMap<String, Object>> managerUserList=userService.getUserBaseByRoleSignature(RoleUtils.OUTSOURCE_MANAGER);
		String role3="外包管理员";
		for (UTMap<String, Object> utMap : managerUserList) {
			String userId=utMap.get("id").toString();
			String userName=utMap.get("name").toString();
			String content3="【"+enterUserName+"】的入场申请已完成，请知悉，详情请登录系统查看";
			sendAndSaveInfo(lists, role3,sendTitle, content3, applyId, userId, userName,noticeType);
		}*/
		//获取申请项目的甲乙方负责人
		String projectId = (String) applyInfo.get("projectId");
		UTMap<String, Object> projectInfo = projectInfoService.getById(projectId);
		String aleader = (String) projectInfo.get("aleader");
		String bleader = (String) projectInfo.get("bleader");
		if (StringUtils.isNotEmpty(aleader)) {
			for (String aStr : aleader.split(",")) {
				UTMap<String, Object> userInfo = userService.getById(aStr);
				String userName = "";
				if (null != userInfo && !userInfo.isEmpty()) {
					userName = userInfo.get("name").toString();
				}
				String role3="甲方负责人";
				String content3="【"+enterUserName+"】的入场申请已完成，请知悉，详情请登录系统查看";
				sendAndSaveInfo(lists, role3,sendTitle, content3, applyId, aStr, userName,noticeType);
			}
		}
		if (StringUtils.isNotEmpty(bleader)) {
			for (String bStr : bleader.split(",")) {
				UTMap<String, Object> userInfo = userService.getById(bStr);
				String userName = "";
				if (null != userInfo && !userInfo.isEmpty()) {
					userName = userInfo.get("name").toString();
				}
				String role3="乙方负责人";
				String content3="【"+enterUserName+"】的入场申请已完成，请知悉，详情请登录系统查看";
				sendAndSaveInfo(lists, role3,sendTitle, content3, applyId, bStr, userName,noticeType);
			}
		}
		applyNoticeDao.adds(lists);
		
	}
	

	
	private void  sendNoticeINExit(String applyId){

		String systemUrl=EscPropertyHolder.instance.getProperty(KEY_SYSTEMURL);
		
		List<Map> lists=new ArrayList<Map>();
		
		//发送人获取
		Map<String, Object> applyInfo=applyExitDao.getById(applyId);
		String exitUserId=applyInfo.get("exitUserId").toString();
		String exitUserName=applyInfo.get("exitUserName").toString();
		String sendTitle="【"+exitUserName+"】退场通知";

		String noticeType= IApplyCommonService.APPLY_TYPE_ENTER;
		
		//申请人（待处理人员）
		String role1="待退场人员";
		String content1="您的退场申请已审批完成！详情请进入系统查看";
		sendAndSaveInfo(lists, role1,sendTitle, content1, applyId, exitUserId, exitUserName,noticeType);
		
		//申请创建人
		String createUserId=applyInfo.get("createUserId").toString();
		String createUser=applyInfo.get("createUser").toString();
		createUser=createUser.substring(0, createUser.indexOf("/"));
		String role2="申请人";
		String content2="您提交的【"+exitUserName+"】退场申请已审批完成，请知悉！详情请进入系统查看";
		sendAndSaveInfo(lists, role2,sendTitle, content2, applyId, createUserId, createUser,noticeType);
		
		
		//获取所有外包管理员
		List<UTMap<String, Object>> managerUserList=userService.getUserBaseByRoleSignature(RoleUtils.OUTSOURCE_MANAGER);
		String role3="外包管理员";
		for (UTMap<String, Object> utMap : managerUserList) {
			String userId=utMap.get("id").toString();
			String userName=utMap.get("name").toString();
			String content3="【"+exitUserName+"】的退场申请已通过，请进行相关信息的确认！详情请进入系统查看";
			sendAndSaveInfo(lists, role3,sendTitle, content3, applyId, userId, userName,noticeType);
		}
		applyNoticeDao.adds(lists);
		
	}
	
	
	private void  sendNoticeINQuit(String applyId){

		String systemUrl=EscPropertyHolder.instance.getProperty(KEY_SYSTEMURL);
		
		List<Map> lists=new ArrayList<Map>();
		
		//发送人获取
		Map<String, Object> applyInfo=applyQuitDao.getById(applyId);
		String quitUserId=applyInfo.get("quitUserId").toString();
		String quitUserName=applyInfo.get("quitUserName").toString();
		String sendTitle="【"+quitUserName+"】离职通知";
		String noticeType= IApplyCommonService.APPLY_TYPE_QUIT;
		
		//申请人（待处理人员）
		String role1="待离职人员";
		String content1="您的离职申请已审批完成！详情请进入系统查看";
		sendAndSaveInfo(lists, role1,sendTitle, content1, applyId, quitUserId, quitUserName,noticeType);
		
		//申请创建人
		String createUserId=applyInfo.get("createUserId").toString();
		String createUser=applyInfo.get("createUser").toString();
		createUser=createUser.substring(0, createUser.indexOf("/"));
		String role2="申请人";
		String content2="您提交的【"+quitUserName+"】离职申请已审批完成，请知悉！详情请进入系统查看";
		sendAndSaveInfo(lists, role2,sendTitle, content2, applyId, createUserId, createUser,noticeType);
		
		
		//获取所有外包管理员
		List<UTMap<String, Object>> managerUserList=userService.getUserBaseByRoleSignature(RoleUtils.OUTSOURCE_MANAGER);
		String role3="外包管理员";
		for (UTMap<String, Object> utMap : managerUserList) {
			String userId=utMap.get("id").toString();
			String userName=utMap.get("name").toString();
			String content3="【"+quitUserName+"】的离职申请已通过，请进行相关信息的确认！详情请进入系统查看";
			sendAndSaveInfo(lists, role3,sendTitle, content3, applyId, userId, userName,noticeType);
		}
		applyNoticeDao.adds(lists);
		
	}
	
	private void sendAndSaveInfo(List<Map>lists, String role,String title,String context,String applyId,String personIds,String personName,String noticeType){
		String [] array=personIds.split(",");
		for (int i = 0; i < array.length; i++) {
			String userId=array[i];
			Map<String, Object> info=new HashMap<String, Object>();
			info.put(IApplyNoticeDao.FIELD_ROLE, role);
			info.put(IApplyNoticeDao.FIELD_SENDTITLE, title);
			info.put(IApplyNoticeDao.FIELD_SENDTIME, UTDate.getCurDate());
			info.put(IApplyNoticeDao.FIELD_CONTEXT, context);
			info.put(IApplyNoticeDao.FIELD_SENDTYPE,"邮件,系统通知");
			info.put(IApplyNoticeDao.FIELD_APPLYID, applyId);
			info.put(IApplyNoticeDao.FIELD_CREATEUSERID, EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
			info.put(IApplyNoticeDao.FIELD_PERSONID, userId);
			info.put(IApplyNoticeDao.FIELD_PERSONNAME, personName);
			info.put(IApplyNoticeDao.FIELD_NOTICETYPE, noticeType);
			info.put("status", "1");
			try {
				messageSend.sendMessage(userId, title, context, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
			}catch(Exception e) {
				info.put("status", "0");
			}
			
			lists.add(info);
		}
	}

	@Override
	public boolean reSend(Map<String, Object> param) {
		UTMap<String, Object> info = this.getById((String)param.get("id"));
		String userId = (String) info.get(IApplyNoticeDao.FIELD_PERSONID);
		String title = (String) info.get(IApplyNoticeDao.FIELD_SENDTITLE);
		String context = (String) info.get(IApplyNoticeDao.FIELD_CONTEXT);
		info.put("status", "1");
		boolean flag = true;
		try {
			messageSend.sendMessage(userId, title, context, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
		}catch(Exception e) {
			info.put("status", "0");
			flag = false;
		}
		if (flag) {
			this.updateById(info);
		}
		return flag;
	}

}