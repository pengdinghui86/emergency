package com.esc.oms.outsource.attendance.service.impl;

import com.esc.oms.outsource.attendance.dao.IAttendanceDao;
import com.esc.oms.outsource.attendance.dao.ICoalitionConfigDao;
import com.esc.oms.outsource.attendance.dao.IFestivalDao;
import com.esc.oms.outsource.attendance.dao.IUserConfigDao;
import com.esc.oms.outsource.attendance.service.IAttendanceService;
import com.esc.oms.outsource.manhour.service.IManHourStatisticService;
import com.esc.oms.supplier.project.dao.IProjectResDao;
import com.esc.oms.supplier.supplieremp.service.ISupplierEmpService;
import com.esc.oms.util.AttendanceSyncUtil;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.FunctionEnum;
import com.esc.oms.util.LocalDateUtil;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.defval.DefaultValueTool;
import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.timetask.anotations.CronTimeTask;
import org.esc.framework.timetask.anotations.TimeTaskMark;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;


/**
 * 考勤Service
 * @author owner
 * 考勤统计：
申请加班工时：待审批+审批中+审批完成+驳回
加班工时（已批准的加班工时）：审批完成的加班工时

 *
 */
@Service
@Transactional
@TimeTaskMark
public class AttendanceServiceImpl  extends BaseOptionService implements  IAttendanceService {
	
	private static final Logger logger = LoggerFactory.getLogger(AttendanceServiceImpl.class);
	
	//考勤dao
	@Resource
	private IAttendanceDao attendanceDao;
	
	//节假日配置dao
	@Resource
	private IFestivalDao festivalDao;
	
	//用户考勤配置dao
	@Resource
	private IUserConfigDao userConfigDao;
	
	//用户联合考勤配置dao
	@Resource
	private ICoalitionConfigDao coalitionConfigDao;
	
	//外包人员
//	@Resource
//	private IOutSourcePersonService outSourcePersonService;
	
	@Resource
	private ISupplierEmpService supplierEmpService;
	
	//系统参数
	@Resource
	private ISysParamService sysParamService;
	
	//用户Service
	@Resource
	private ISysUserService userService;
	
	
	@Resource 
	private IManHourStatisticService manHourStatisticService;

	@Resource
	private IProjectResDao projectResDao;
	
//	//加班
//	@Resource
//	private IOvertimeDao overtimeDao;
//	
//	//请假
//	@Resource
//	private IVacationDetailDao vacationDetailDao;
//	
//	//出差
//	@Resource
//	private ITravelDetailDao  travelDetailDao;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return attendanceDao;
	}
	
	/**
	 * 获取当前登录用户的考勤数据
	 * @return
	 */
	public UTMap<String, Object> getCurUserAttendance(String date){
		return attendanceDao.queryUserAttendance(date,EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
	}
	
	/**
	 * 根据用户编号和考勤日期获取用户的考勤数据
	 * @return
	 */
	public UTMap<String, Object> getCurUserAttendance(String date, String userId){
		return attendanceDao.queryUserAttendance(date,userId);
	}
	
	/**
	 * 退厂申请删除相应的考勤数据
	 * @param userId
	 * @param date
	 */
	public void deleteByPersonExit(String userId, String date){
		attendanceDao.deleteByPersonExit(userId, date);
	}
	
	/**
	 * 签到
	 * @param param
	 * @return
	 */
	@Override
	public void userDatein(Map param){
		
		UTMap<String, Object> userConfig = userConfigDao.getUserConfigByUserId(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
		
//		if (userConfig == null) {
//			throw new EscServiceException("当前用户没有配置考勤规则，无法进行考勤！");
//		}
		Date date = new Date();
		String dateStr = UTDate.dateToDateString(date);
		
//		if (!this.review(userConfig)) {
//			throw new EscServiceException(dateStr+"不在您的考勤规则开始时间和结束时间范围内！如有疑问，请联系供应商管理员。");
//		}
		
		// 是否联合考勤：(coalitionId存在就表示是联合考勤)
		if (userConfig.get("coalitionId") != null) {
			String coalitionId = userConfig.get("coalitionId").toString();//联合考勤id
			UTMap<String, Object> coalitionConfig = coalitionConfigDao.getById(coalitionId);
			String userIds = coalitionConfig.get("userIds").toString();
			String[] userIdArr = userIds.split(",");
			// 考勤方式:(1.确定时间，2.不确定时间),如果考勤方式是不确定时间，则没有初始化生成过考勤数据，需要新创建一条考勤记录
			if ("2".equals(coalitionConfig.get("attendanceDateType").toString())) {
				//不确定时间考勤，并且用户是按每周或每月工作几个小时来考勤
				//attendanceType:不确定时间的考勤统计方式：（1.统计考勤次数；2.统计考勤时间（单位是小时））
				if("2".equals(coalitionConfig.get("attendanceType").toString())){
					addUncertaintyAttendance(date, userConfig, param, null, true);
				}else{
//					Date date = new Date();//确保同一联合考勤规则下的考勤数据的时间一致
					UTMap<String, Object> po = getCurUserAttendance(dateStr);
					if(po != null){
						throw new EscServiceException("您所在的联合考勤组已有别的用户进行了签到，请刷新签到页面");
					}
					// 如果是联合考勤，则将该联合考勤内的其他用户也生成一条考勤记录
					for (String userId : userIdArr) {
						addUncertaintyAttendance(date, userConfig, param, userId, false);
					}
				}
			} else {//确定时间联合考勤
//				Date date = new Date();//确保同一联合考勤规则下的考勤数据的时间一致
				int dateinStyle = checkDateinStyle(userConfig,date);
				for (String userId : userIdArr) {
					UTMap<String, Object> po = attendanceDao.queryUserAttendance(dateStr,userId);
					if (po == null) {
						//如果当前登录用户没有考勤数据，则响应异常信息
						if(userId.equals(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId())){
							throw new EscServiceException(dateStr+"不在您的考勤规则范围内！如有疑问，请联系供应商管理员。");
						}
						logger.error(CommonUtils.vaildLog("用户编号为‘"+userId+"’的联合考勤用户，"+dateStr+"没有生成考勤数据！"));
						continue;
					}
					if(po.get("startTime") != null){
						throw new EscServiceException("您所在的联合考勤组已有别的用户进行了签到，请刷新签到页面");
					}
					po.put("startTime", UTDate.dateToDateString(date,UTDate.TIMEF_FORMAT));
					po.put("startReason", param.get("reason"));//签到异常原因
					po.put("startType",param.get("reasonType"));//异常类型
					po.put("dateinStyle", dateinStyle);//是否迟到 1:迟到;0:正常,-1:未签到
					po.put("dateinIp", param.get("dateinIp"));//考勤ip
					attendanceDao.updateById(po);
				}
			}

		} else {//非联合考勤
			// 考勤方式:(1.确定时间，2.不确定时间),如果考勤方式是不确定时间，则没有初始化生成过考勤数据，需要新创建一条考勤记录
			if ("2".equals(userConfig.get("attendanceDateType").toString())) {
				
				//不确定时间考勤，并且用户是按每周或每月工作几个小时来考勤
				//attendanceType:不确定时间的考勤统计方式：（1.统计考勤次数；2.统计考勤时间（单位是小时））
				if("2".equals(userConfig.get("attendanceType").toString())){
					addUncertaintyAttendance(new Date(), userConfig, param, null, true);
				}else{
					addUncertaintyAttendance(new Date(), userConfig, param, null, false);
				}
			} else {//确定时间考勤
				UTMap<String, Object> po = getCurUserAttendance(dateStr);
				// apo为null表示非联合考勤的用户没有生成初始化考勤数据
				if (po == null) {
					throw new EscServiceException(dateStr+"不在您的考勤规则范围内！如有疑问，请联系供应商管理员。");
				}
//				Date date = new Date();
				po.put("startTime", UTDate.dateToDateString(date,UTDate.TIMEF_FORMAT));
				po.put("startReason", param.get("reason"));//签到异常原因
				po.put("startType",param.get("reasonType"));//异常类型
				po.put("dateinStyle", checkDateinStyle(userConfig,date));//是否迟到 1:迟到;0:正常,-1:未签到
				po.put("dateinIp", param.get("dateinIp"));//考勤ip
				attendanceDao.updateById(po);
			}
		}
		logger.info("用户"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectName()+"/"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectCode()+"已经签到");
	}
	
	/**
	 * 用户签退
	 */
	@Override
	public void userDateout(Map param){
		
		UTMap<String, Object> userConfig = userConfigDao.getUserConfigByUserId(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
//		String opstyle = "1";
		if (userConfig == null) {
			throw new EscServiceException("没有找到相应的考勤规则！");
		}
		String attendanceType = null;//不确定时间的考勤统计方式：（1.统计考勤次数；2.统计考勤时间（单位是小时））
		String attendanceDateType = userConfig.get("attendanceDateType").toString();//考勤方式:(1.确定时间，2.不确定时间).
		if("2".equals(userConfig.get("attendanceDateType"))){
			attendanceType = userConfig.get("attendanceType").toString();//不确定时间的考勤统计方式：（1.统计考勤次数；2.统计考勤时间（单位是小时））
		}
		
		Date date = new Date();
	
		String dateStr = UTDate.dateToString(date, UTDate.TIMEF_FORMAT);
		
		//表示是跨天签退
		if(param.get("isAcrossDay") != null){
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date); 
			calendar.add(Calendar.DATE, -1);
			date = calendar.getTime();
		}
		UTMap<String, Object> apo = getCurUserAttendance(UTDate.dateToDateString(date));
		if (apo == null || apo.get("startTime") == null) {
			throw new EscServiceException("签退失败，请先签到！");
		}
		String beginTime = apo.get("startTime").toString();
		List<Map<String, Object>> seconds = manHourStatisticService.calculateSeconds(beginTime, dateStr, userConfig,true);
		double attHours = 0d ;
		long attHoursSecond = 0l ;
		if(seconds != null && !seconds.isEmpty()){
			for (Map<String, Object> map2 : seconds) {
				attHoursSecond += Long.valueOf(map2.get("seconds").toString());
			}
			attHours = UTDate.transformSecondToHour(attHoursSecond, false);
		}
		apo.put("attHours", attHours);//考勤工时(小时)
		apo.put("attHoursSecond", attHoursSecond);//考勤工时(秒)
		//如果是手动生成的考勤数据，比如节假日过来加班了，进行了考勤后，这种情况不需要考虑考勤异常状态，直接改签退时间就行了
		if("1".equals(apo.get("attType").toString())){
			
			// 如果是否联合考勤：(coalitionId存在表示是联合考勤)
			if (userConfig.get("coalitionId") != null){
				String coalitionId = userConfig.get("coalitionId").toString();//联合考勤id
				UTMap<String, Object> coalitionConfig = coalitionConfigDao.getById(coalitionId);
				String userIds = coalitionConfig.get("userIds").toString();
				String[] userIdArr = userIds.split(",");
				for (String coalitionUserId : userIdArr) {
					UTMap<String, Object> po = attendanceDao.queryUserAttendance(UTDate.dateToDateString(date),coalitionUserId);
					if (po == null) {
						logger.error(CommonUtils.vaildLog("用户编号为‘"+coalitionUserId+"’的联合考勤用户，"+UTDate.dateToDateString(date)+"没有生成考勤数据1！"));
						continue;
					}
					po.put("endTime", UTDate.curTime());
					po.put("dateoutIp", param.get("dateoutIp"));//考勤ip
					po.put("dateoutStyle", 0);//签退正常
					attendanceDao.updateById(po);
				}
			}else{
				apo.put("endTime", UTDate.curTime());
				apo.put("dateoutIp", param.get("dateoutIp"));//考勤ip
				apo.put("dateoutStyle", 0);//签退正常
				attendanceDao.updateById(apo);
			}
							
			
			return;
		}
		
		//跨天请假单独做一次考勤规则校验
		if(param.get("isAcrossDay") != null){
			String amBegin;
			String msg;
			if ("2".equals(attendanceDateType) && "2".equals(attendanceType)){
				amBegin = DefaultValueTool.getValue("attendance","amBegin");//考勤规则默认配置的开始签到时间
				msg = "按工时考勤的用户只能在"+amBegin+"前进行跨天签退";
			}else{
				amBegin = userConfig.get("amBegin").toString();//上午签到时间
				msg = "已经过了考勤规则的开始签到时间，不可以对前一天进行跨天签退！";
			}
			String amBeginDate = UTDate.dateToDateString(date) + " " + amBegin + ":00";
			//如果在考勤规则签到时间之前，都可以进行跨天签退
			if(date.compareTo(UTDate.getDate(amBeginDate,UTDate.TIMEF_FORMAT)) >= 0){
				throw new EscServiceException(msg);
			}
		}
		
		
//		UTMap<String, Object> festival = festivalDao.getByDate(date);
//		if(festival !=null && !"1".equals(festival.get("festivalType").toString())){//节假日类型为工作日,会生成所有确定时间考勤的数据
//			apo.setEndReason(vo.getReason());
//			apo.setEndTime(new Date());
//			apo.setDateOutStyle("0");
//			apo.setEndType("1");
//			apo.setDateoutIp(vo.getDateoutIp());
//			//如果是系统考勤，则把指纹考勤时间置为null
//			apo.setFingerendTime(null);
//			attendanceDao.updateEntity(apo);
//			
//		}else{//系统生成的数据
			// 如果是否联合考勤：(coalitionId存在表示是联合考勤)
			if (userConfig.get("coalitionId") != null) {
				//是不确定时间考勤，同时每周或每月按工时考勤，只需要变更自己的考勤数据，不需要修改联合考勤组里其他用户的考勤数据
				//attendanceDateType:考勤方式:(1.确定时间，2.不确定时间).
				//attendanceType:不确定时间的考勤统计方式：（1.统计考勤次数；2.统计考勤时间（单位是小时））
				if ("2".equals(attendanceDateType) && "2".equals(attendanceType)) {
					
					apo.put("endTime", UTDate.curTime());
					apo.put("endReason", param.get("reason"));//签到异常原因
					apo.put("endType",param.get("reasonType"));//异常类型
					apo.put("dateoutStyle", 0);//是否迟到 1:迟到;0:正常,-1:未签到
					apo.put("dateoutIp", param.get("dateoutIp"));//考勤ip
					
					attendanceDao.updateById(apo);
					return;
				}
				String coalitionId = userConfig.get("coalitionId").toString();//联合考勤id
				UTMap<String, Object> coalitionConfig = coalitionConfigDao.getById(coalitionId);
				String userIds = coalitionConfig.get("userIds").toString();
				String[] userIdArr = userIds.split(",");
				if (userIdArr != null) {
					Date curDate = new Date();
					// 如果是联合考勤，则同时修改该联合考勤内的其他用户的考勤记录
					for (String userId : userIdArr) {
						UTMap<String, Object> po = attendanceDao.queryUserAttendance(UTDate.dateToDateString(date),userId);
						if (po == null) {
							logger.error(CommonUtils.vaildLog("用户编号为‘"+userId+"’的联合考勤用户，"+UTDate.dateToDateString(date)+"没有生成考勤数据2！"));
							continue;
						}
						
						po.put("endTime", UTDate.dateToDateString(curDate,UTDate.TIMEF_FORMAT));
						po.put("endReason", param.get("reason"));//签到异常原因
						po.put("endType",param.get("reasonType"));//异常类型
						//表示是跨天签退
						if(param.get("isAcrossDay") != null){
							po.put("dateoutStyle", 0);//是否迟到 1:迟到;0:正常,-1:未签到
						}else{
							po.put("dateoutStyle", checkDateoutStyle(userConfig,curDate));//是否迟到 1:迟到;0:正常,-1:未签到
						}
						po.put("attHours", attHours);//考勤工时
						po.put("attHoursSecond", attHoursSecond);//考勤工时(秒)
						po.put("dateoutIp", param.get("dateoutIp"));//考勤ip
						
						attendanceDao.updateById(po);
					}
					
				}
			} else {//非联合考勤
				Date curDate = new Date();
				apo.put("endTime", UTDate.dateToDateString(curDate,UTDate.TIMEF_FORMAT));
				apo.put("endReason", param.get("reason"));//签到异常原因
				apo.put("endType",param.get("reasonType"));//异常类型
				//考勤规则是不确定时间并且按工时统计的，不需要考虑考勤是否异常
				if ("2".equals(attendanceDateType) && "2".equals(attendanceType)){
					apo.put("dateoutStyle", 0);//是否迟到 1:迟到;0:正常,-1:未签到
				}else{
					//表示是跨天签退
					if(param.get("isAcrossDay") != null){
						apo.put("dateoutStyle", 0);//是否迟到 1:迟到;0:正常,-1:未签到
					}else{
						apo.put("dateoutStyle", checkDateoutStyle(userConfig,curDate));//是否迟到 1:迟到;0:正常,-1:未签到
					}
					
				}
				apo.put("dateoutIp", param.get("dateoutIp"));//考勤ip
				
				attendanceDao.updateById(apo);
			}
//		}
			logger.info("用户"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectName()+"/"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectCode()+UTDate.dateToDateString(date)+"已经签退");
	}
	

	
	/**
	 * 签到的时候，新增考勤规则为不确定时间的考勤数据
	 * @param date 考勤日期
	 * @param userConfig 考勤规则
	 * @param param 前端传递的参数
	 * @param userId 用户编号（如果是联合考勤新增考勤数据，需要用到传递过来的userid,否则取当前考勤用户的userId）
	 * @param isAttendanceType 是否考勤规则是按工时统计的，是的话不需要考虑考勤是否异常
	 */
	private void addUncertaintyAttendance(Date date, UTMap<String, Object> userConfig, Map param, String userId, boolean isAttendanceType) {
		if(userId == null){
			userId = userConfig.get("userId").toString();
		}
//		String userId = userConfig.get("userId").toString();
		//查询外包对应外包人员用户信息
//		UTMap<String, Object> user = outSourcePersonService.getOutEmpByUserId(userId);
		UTMap<String, Object> user = supplierEmpService.getSupplierEmpDetailedByUserId(userId);
		logger.info("签到时生成用户(" + user.get("name") + "/" + user.get("code") + ")的考勤初始化记录");
		Map po = new HashMap();
		po.put("date", UTDate.curDate());
//		if(user.get("departId") == null){
//			throw new EscServiceException("用户(" + user.get("name") + "/" + user.get("code") +")没有绑定组织机构，生成考勤记录失败!");
//		}
		po.put("startType",param.get("reasonType"));//异常类型
		po.put("startReason", param.get("reason"));//签到异常原因
		po.put("startTime", UTDate.dateToDateString(date,UTDate.TIMEF_FORMAT));//签到时间
		po.put("userId", userId);
		po.put("supplierId", userConfig.get("supplierId"));
		po.put("dateinIp", param.get("dateinIp"));//考勤ip
		//考勤规则是不确定时间并且按工时统计的，不需要考虑考勤签到是否异常
		if(isAttendanceType){
			po.put("dateinStyle", 0);//是否迟到 1:迟到;0:正常,-1:未签到
			po.put("dateoutStyle", -1);
		}else{
			po.put("dateinStyle", checkDateinStyle(userConfig,date));//是否迟到 1:迟到;0:正常,-1:未签到
			po.put("dateoutStyle", -1);
		}
		if(userConfig.get("coalitionId") != null){
			po.put("coalitionId", userConfig.get("coalitionId"));
			po.put("departId", userConfig.get("departId"));//联合考勤用户取联合考勤配置的部门，统计也按联合考勤配置的部门进行统计
		}else{
			po.put("departId", user.get("departId"));//绑定组织机构
		}
		po.put("attType", 0);//属于固定考勤用户，如果考勤记录在考勤规则范围之外，attType=1,否则为0
		po.put("attendanceDateType", getAttendanceDateType(userConfig));//考勤方式:(1.确定时间，2.不确定时间统计考勤次数,3.不确定时间统计考勤时间)
		po.put("attHours", 0);
		po.put("attHoursSecond", 0);
//		po.put("travelHour", 0);
//		po.put("travelHourApply", 0);
//		po.put("vacationHour", 0);
//		po.put("vacationHourApply", 0);
//		po.put("overtimeHour", 0);
//		po.put("overtimeHourApply", 0);
		attendanceDao.add(po);
	}
	
	/**
	 * 获取考勤方式:(1.确定时间，2.不确定时间统计考勤次数,3.不确定时间统计考勤时间)
	 * @param userConfig
	 * @return
	 */
	public int getAttendanceDateType(UTMap<String, Object> userConfig){
		//考勤方式:(1.确定时间，2.不确定时间)
		String attendanceDateType = userConfig.get("attendanceDateType").toString();
		if("1".equals(attendanceDateType)){
			return 1;
		}else{
			//不确定时间的考勤统计方式：（1.统计考勤次数；2.统计考勤时间（单位是小时））
			String attendanceType = userConfig.get("attendanceType").toString();
			if("1".equals(attendanceType)){
				return 2;//2.不确定时间统计考勤次数
			}else{
				return 3;//3.不确定时间统计考勤时间)
			}
		}
	}

	@Override
	public List<Map> addAttendanceSync(List<UTMap<String, Object>> userConfigs,Date date) {
		List<Map> maps = new ArrayList<>();
		for (UTMap<String, Object> userConfig : userConfigs) {
			String userId = userConfig.get("userId").toString();
			//查询外包对应外包人员用户信息
//			UTMap<String, Object> user = outSourcePersonService.getOutEmpByUserId(userId);
			UTMap<String, Object> user = supplierEmpService.getSupplierEmpDetailedByUserId(userId);
			String dateStr = UTDate.dateToDateString(date);
			UTMap<String, Object> att = attendanceDao.queryUserAttendance(dateStr, userId);
			//如果当前用户指定日期存在考勤记录，则不重新生成
			if(user == null){//用户被删除，不在同步
				return null;
			}
			if(att != null){
				logger.info("用户(" + user.get("name") + "/" + user.get("code") + ")已存在考勤记录");
				return null;
			}
			//获取当天打卡所属的项目
			Map<String,Object> map = projectResDao.getResByUserId(dateStr, userId);
			Map po = new HashMap();
			po.put("projectId", map != null ? map.get("projectId") : null);
			po.put("date", dateStr);
			po.put("userId", userId);
			po.put("supplierId", userConfig.get("supplierId"));
			//默认初始化考勤数据未签到和未签退
			po.put("dateinStyle", -1);
			po.put("dateoutStyle", -1);
			if(userConfig.get("coalitionId") != null){
				po.put("coalitionId", userConfig.get("coalitionId"));
				po.put("departId", userConfig.get("departId"));//联合考勤用户取联合考勤配置的部门，统计也按联合考勤配置的部门进行统计
			}else{
				po.put("departId", user.get("departId"));//绑定组织机构
			}
			po.put("attType", 0);//属于固定考勤用户，如果考勤记录在考勤规则范围之外，attType=1,否则为0
			po.put("attendanceDateType", getAttendanceDateType(userConfig));//考勤方式:(1.确定时间，2.不确定时间统计考勤次数,3.不确定时间统计考勤时间)
			po.put("attHours", 0);
			po.put("attHoursSecond", 0);
			logger.info("生成用户(" + user.get("name") + "/" + user.get("code") + ")的考勤初始化记录");
			maps.add(po);
		}
		return maps;
	}

	/**
	 * 根据考勤规则和日期手动生成对应用户的考勤数据,这种情况用于用户节假日过来加班，手动生成考勤数据
	 * @param date 考勤日期
	 * @param userConfig 考勤规则
	 */
	public void mnulAddAttendance(Date date, UTMap<String, Object> userConfig, String remoteAddr) {
		
		
		String userId = userConfig.get("userId").toString();
		//查询外包对应外包人员用户信息
		UTMap<String, Object> user = supplierEmpService.getSupplierEmpDetailedByUserId(userId);
		String dateStr = UTDate.dateToDateString(date);
		Map po = new HashMap();
		po.put("date", dateStr);
//		if(user.get("departId") == null){
////			throw new EscServiceException("用户(" + user.get("name") + "/" + user.get("code") +")没有绑定组织机构，生成考勤记录失败!");
//			logger.error("用户(" + user.get("name") + "/" + user.get("code") +")没有绑定组织机构，生成考勤记录失败!");
//			return;
//		}
//		po.put("userId", userId);
		po.put("supplierId", userConfig.get("supplierId"));
		po.put("dateinStyle", 0);//默认初始化考勤签到状态为正常
		po.put("dateoutStyle", -1);//默认初始化签退状态为未签退，只有在真正签退的时候才正常
		if(userConfig.get("coalitionId") != null){
			po.put("coalitionId", userConfig.get("coalitionId"));
			po.put("departId", userConfig.get("departId"));//联合考勤用户取联合考勤配置的部门，统计也按联合考勤配置的部门进行统计
		}else{
			po.put("departId", user.get("departId"));//绑定组织机构
		}
		po.put("attType", 1);//属于固定考勤用户，如果考勤记录在考勤规则范围之外，attType=1,否则为0
		po.put("attendanceDateType", getAttendanceDateType(userConfig));//考勤方式:(1.确定时间，2.不确定时间统计考勤次数,3.不确定时间统计考勤时间)
		po.put("attHours", 0);
		po.put("attHoursSecond", 0);
//		po.put("travelHour", 0);
//		po.put("travelHourApply", 0);
//		po.put("vacationHour", 0);
//		po.put("vacationHourApply", 0);
//		po.put("overtimeHour", 0);
//		po.put("overtimeHourApply", 0);
		po.put("startTime", UTDate.dateToDateString(date,UTDate.TIMEF_FORMAT));
		po.put("dateinIp", remoteAddr);//考勤ip
		// 是否联合考勤：(coalitionId存在就表示是联合考勤)
		if (userConfig.get("coalitionId") != null) {
			String coalitionId = userConfig.get("coalitionId").toString();//联合考勤id
			UTMap<String, Object> coalitionConfig = coalitionConfigDao.getById(coalitionId);
			String userIds = coalitionConfig.get("userIds").toString();
			String[] userIdArr = userIds.split(",");
			for (String coalitionUserId : userIdArr) {
				po.remove("id");
				po.put("userId", coalitionUserId);
				attendanceDao.add(po);
				logger.info("手动生成联合考勤用户(" + coalitionUserId + ")的考勤初始化记录");
			}
		}else{
			po.put("userId", userId);
			attendanceDao.add(po);
			logger.info("手动生成用户(" + user.get("name") + "/" + user.get("code") + ")的考勤初始化记录");
		}
		
		
	}
	
	/**
	 * 检查当前时间是否签到异常(//是否迟到 1:迟到;0:正常,-1:未签到)
	 * @param userConfig
	 * @return
	 */
	public int checkDateinStyle(UTMap<String, Object> userConfig, Date date){
		//是不确定时间考勤，同时每周或每月按工时考勤，只需要变更自己的考勤数据，不需要修改联合考勤组里其他用户的考勤数据
		//attendanceDateType:考勤方式:(1.确定时间，2.不确定时间).
		//attendanceType:不确定时间的考勤统计方式：（1.统计考勤次数；2.统计考勤时间（单位是小时））
		if ("2".equals(userConfig.get("attendanceDateType").toString()) && "2".equals(userConfig.get("attendanceType").toString())) {
			return 0;
		}
		String amBegin = userConfig.get("amBegin").toString();//上午签到时间
		String amBeginDate = UTDate.dateToDateString(date) + " " + amBegin + ":00";
		if(date.compareTo(UTDate.getDate(amBeginDate,UTDate.TIMEF_FORMAT)) <= 0){
			return 0;
		}
		
		return 1;
	}

	@Override
	public int checkDateinStyle(UTMap<String, Object> userConfig, Date date, String season) {
		//是不确定时间考勤，同时每周或每月按工时考勤，只需要变更自己的考勤数据，不需要修改联合考勤组里其他用户的考勤数据
		//attendanceDateType:考勤方式:(1.确定时间，2.不确定时间).
		//attendanceType:不确定时间的考勤统计方式：（1.统计考勤次数；2.统计考勤时间（单位是小时））

		if (userConfig == null || ("2".equals(userConfig.get("attendanceDateType").toString()) &&
				"2".equals(userConfig.get("attendanceType").toString()))) {
			return 0;
		}
		String amBegin = userConfig.get("amBegin").toString();//上午签到时间
		if(FunctionEnum.SeasonType.winter.getCode().equals(season)){//表示冬令时
			amBegin = userConfig.get("winterAmBegin") != null ? userConfig.get("winterAmBegin").toString() : amBegin;//上午签到时间
		}
		String amBeginDate = UTDate.dateToDateString(date) + " " + amBegin + ":00";
		//15分钟不算迟到
		Date actureBeginDate = LocalDateUtil.addMinute(UTDate.getDate(amBeginDate,UTDate.TIMEF_FORMAT), 15);
		if(date.compareTo(actureBeginDate) <= 0){
			return 0;
		}

		return 1;
	}

	/**
	 * 检查当前时间是否签退异常(是否早退1：早退;0:正常;-1:未签退)
	 * @param userConfig
	 * @return
	 */
	public int checkDateoutStyle(UTMap<String, Object> userConfig, Date date){
		//是不确定时间考勤，同时每周或每月按工时考勤，只需要变更自己的考勤数据，不需要修改联合考勤组里其他用户的考勤数据
		//attendanceDateType:考勤方式:(1.确定时间，2.不确定时间).
		//attendanceType:不确定时间的考勤统计方式：（1.统计考勤次数；2.统计考勤时间（单位是小时））
		if ("2".equals(userConfig.get("attendanceDateType").toString()) && "2".equals(userConfig.get("attendanceType").toString())) {
			return 0;
		}
		String pmEnd = userConfig.get("pmEnd").toString();//下午签退时间
		String amBeginDate = UTDate.dateToDateString(date) + " " + pmEnd + ":00";
		if(date.compareTo(UTDate.getDate(amBeginDate,UTDate.TIMEF_FORMAT)) >= 0){
			return 0;
		}
		return 1;
	}

	@Override
	public int checkDateoutStyle(UTMap<String, Object> userConfig, Date date, String season, String workDate) {
		//是不确定时间考勤，同时每周或每月按工时考勤，只需要变更自己的考勤数据，不需要修改联合考勤组里其他用户的考勤数据
		//attendanceDateType:考勤方式:(1.确定时间，2.不确定时间).
		//attendanceType:不确定时间的考勤统计方式：（1.统计考勤次数；2.统计考勤时间（单位是小时））
		if (userConfig == null || ("2".equals(userConfig.get("attendanceDateType").toString()) &&
				"2".equals(userConfig.get("attendanceType").toString()))) {
			return 0;
		}
		String pmEnd = userConfig.get("pmEnd").toString();//下午签退时间
		if(FunctionEnum.SeasonType.winter.getCode().equals(season)){//表示冬令时
			pmEnd = userConfig.get("winterPmEnd") != null ? userConfig.get("winterPmEnd").toString() : pmEnd;//下午签退时间
		}
		String pmBeginDate = workDate + " " + pmEnd + ":00";
		if(date.compareTo(UTDate.getDate(pmBeginDate,UTDate.TIMEF_FORMAT)) >= 0){
			return 0;
		}
		return 1;
	}

	/**
	 * 在用户考勤的时候还需要判断下用户的考勤开始时间与结束时间
	 * 
	 * @param vo
	 * @return
	 */
	private boolean review(UTMap<String, Object> userconfig ) {
		Date cuDate = new Date();
		if (userconfig.get("beginDate") != null) {
			// 如果有开始时间，判断当前时间是否在开始时间之前
			if (!cuDate.after(UTDate.parseDate(userconfig.get("beginDate").toString()))) {
				return false;
			}
		}
		if (userconfig.get("endDate") != null) {
			// 如果有结束时间，判断当前时间是否在结束时间之后
			if (cuDate.after(UTDate.parseDate(userconfig.get("endDate").toString()))) {
				return false;
			}
		}
		return true;
	}
	
	/**
	 * 定时根据考勤规则以及节假日配置生成考勤数据
	 * 考勤数据生成逻辑：
	 * 1.	如果考勤规则配置为周一至周日均需考勤，则为全年无休情况，不考虑节假日等因素，全年生成考勤
	 * 2.	其他情况如下处理：
	 * 	1）	如果当天为节假日、调休、其他（节假日配置中配置的法定节假日、调休、其他），不生成考勤
	 * 	2）	如果当天为周末（节假日配置中配置的周末），根据考勤规则生成考勤
	 * 	3）	如果当天为工作日（节假日配置中配置的工作日），生成考勤
	 * 	4）	其他情况，根据考勤规则生成考勤
	 */
	@CronTimeTask(description="每天凌晨根据用户考勤规则和节假日配置定时生成考勤数据",cron="0 0 0 * * ?")
	public void initCurrentDateAttendance(){
		List<Map> maps = new ArrayList<>();
		Date date = new Date();//生成当前时间的考勤数据
//		//钉钉处也有一个定时任务，关于新增考勤的，为了防止启动的时候两个定时任务产生多线程问题，造成数据污染，这里对时间做一个判断
//		Calendar c = Calendar.getInstance();
//		int hh = c.get(Calendar.HOUR_OF_DAY);
//		int mm = c.get(Calendar.MINUTE);
//		if ((hh <=23 && hh != 0) || mm >= 1) {//在零点范围外，不执行
//			return;
//		}
		//获取指定日期的节假日配置
		UTMap<String, Object> festival = festivalDao.getByDate(UTDate.getCurDate());
		List<UTMap<String, Object>> userConfigs = null;
		if(festival != null){
			//节假日类型：1.工作日  2.周末  3.法定节假日  4.调休  5.其他. 工作日为1，周末为2，法定节假日为3 已经写入代码中，不可更改
			String festivalType = festival.get("festivalType").toString();
			if("1".equals(festivalType)){
				//查询确认时间的考勤规则数据
				userConfigs = userConfigDao.getAttUserConfigByAttendanceDateType(date);
			}else if("2".equals(festivalType)){
				//查询指定日期需要考勤的考勤规则
				userConfigs = userConfigDao.getAttUserConfig(date);
			}else{
				//查询确认时间，并且考勤时间点为周一到周日的考勤规则数据(如果考勤规则配置为周一至周日均需考勤，则为全年无休情况，不考虑节假日等因素，全年生成考勤)
				userConfigs = userConfigDao.getAttUserConfigByAttendanceDate(date);
			}
		}else{//没有节假日配置表示正常工作日
			//查询指定日期需要考勤的考勤规则
			userConfigs = userConfigDao.getAttUserConfig(date);
		}
		
		if(userConfigs != null){
			List<Map> tempMaps = AttendanceSyncUtil.addAttendanceSync(userConfigs,date);
			if(tempMaps.size() > 0){
				try {
					attendanceDao.adds(tempMaps);
				} catch (Exception e) {
					logger.error("考勤数据生成失败");
				}
			}
//			for (UTMap<String, Object> userConfig : userConfigs) {
//				try{
//					addAttendance(date, userConfig);
//				}catch(Exception ex){
//					logger.error("考勤数据生成失败，userId="+userConfig.get("userId"));
//				}
//
//			}
		}
	}
	
	/**
	 * 根据考勤规则和日期生成对应用户的考勤数据
	 * @param date 考勤日期
	 * @param userConfig 考勤规则
	 */
	private void addAttendance(Date date, UTMap<String, Object> userConfig) {
		String userId = userConfig.get("userId").toString();
		//查询外包对应外包人员用户信息
//		UTMap<String, Object> user = outSourcePersonService.getOutEmpByUserId(userId);
//		UTMap<String, Object> user = supplierEmpService.getSupplierEmpDetailedByUserId(userId);
		String dateStr = UTDate.dateToDateString(date);
		Map<String,Object> user = projectResDao.getResByUserId(dateStr, userId);
		UTMap<String, Object> att = attendanceDao.queryUserAttendance(dateStr, userId);
		//如果当前用户指定日期存在考勤记录，则不重新生成
		if(att != null){
			logger.info("用户(" + user.get("name") + "/" + user.get("code") + ")已存在考勤记录");
			return;
		}
		Map po = new HashMap();
		po.put("date", dateStr);
//		if(user.get("departId") == null){
////			throw new EscServiceException("用户(" + user.get("name") + "/" + user.get("code") +")没有绑定组织机构，生成考勤记录失败!");
//			logger.error("用户(" + user.get("name") + "/" + user.get("code") +")没有绑定组织机构，生成考勤记录失败!");
//			return;
//		}
		po.put("userId", userId);
		po.put("supplierId", userConfig.get("supplierId"));
		//默认初始化考勤数据未签到和未签退
		po.put("dateinStyle", -1);
		po.put("dateoutStyle", -1);
		if(userConfig.get("coalitionId") != null){
			po.put("coalitionId", userConfig.get("coalitionId"));
			po.put("departId", userConfig.get("departId"));//联合考勤用户取联合考勤配置的部门，统计也按联合考勤配置的部门进行统计
		}else{
			po.put("departId", user.get("departId"));//绑定组织机构
		}
		po.put("attType", 0);//属于固定考勤用户，如果考勤记录在考勤规则范围之外，attType=1,否则为0
		po.put("attendanceDateType", getAttendanceDateType(userConfig));//考勤方式:(1.确定时间，2.不确定时间统计考勤次数,3.不确定时间统计考勤时间)
		po.put("attHours", 0);
		po.put("attHoursSecond", 0);
//		po.put("travelHour", 0);
//		po.put("travelHourApply", 0);
//		po.put("vacationHour", 0);
//		po.put("vacationHourApply", 0);
//		po.put("overtimeHour", 0);
//		po.put("overtimeHourApply", 0);
		attendanceDao.add(po);
		logger.info("生成用户(" + user.get("name") + "/" + user.get("code") + ")的考勤初始化记录");
	}
	
	
	
	/**
	 * 判断前一天的考勤是否需要跨天签退
	 * @param date
	 * @return
	 */
	public boolean isAcrossDay(Date date){
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date); 
		calendar.add(Calendar.DATE, -1);
		//查询前一天的考勤数据
		UTMap<String, Object> att = this.getCurUserAttendance(UTDate.dateToDateString(calendar.getTime()));
		if(att == null){//没有考勤数据
			return false;
		}
		if(att.get("startTime") == null){//没有签到
			return false;
		}
		if(att.get("endTime") != null){//已经签退
			return false;
		}else{
			UTMap<String, Object> userConfig = userConfigDao.getUserConfigByUserId(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
			String amBeginDate ;
			//attendanceDateType:考勤方式:(1.确定时间，2.不确定时间).
			//attendanceType:不确定时间的考勤统计方式：（1.统计考勤次数；2.统计考勤时间（单位是小时））
			if ("2".equals(userConfig.get("attendanceDateType").toString()) && "2".equals(userConfig.get("attendanceType").toString())) {
				//考勤规则是按工时统计的默认第二天默认配置的开始签到时间前都可以签到
				amBeginDate = UTDate.dateToDateString(date) + " " + DefaultValueTool.getValue("attendance","amBegin") + ":00";//考勤规则默认配置的开始签到时间
			}else{
				String amBegin = userConfig.get("amBegin").toString();//上午签到时间
				amBeginDate = UTDate.dateToDateString(date) + " " + amBegin + ":00";
			}
			
			//如果在考勤规则签到时间之前，都可以进行跨天签退
			if(date.compareTo(UTDate.getDate(amBeginDate,UTDate.TIMEF_FORMAT)) <= 0){
				return true;
			}
		}
		return false;
	}
	
	/**
	 * 查询考勤日历的数据
	 * @param param
	 * @return
	 */
	public List getAttendanceCalendarDate(Map param){
		List list = new ArrayList();
		//考勤数据
		List<UTMap<String, Object>> attList = attendanceDao.getAttendanceCalendarDate(param);
		if(list != null){
			ObjectMapper mapper = new ObjectMapper();
			for (UTMap<String, Object> utMap : attList) {
				String result = utMap.get("result").toString();
				try {
					Map<String,Object> map = mapper.readValue(result, Map.class);
					list.add(map);
				} catch (JsonParseException e) {
					logger.error("JsonParseException",e);
				} catch (JsonMappingException e) {
					logger.error("JsonMappingException",e);
				} catch (IOException e) {
					logger.error("IOException",e);
				}
			}
		}
		return list;
	}
//	
//	public static void main(String[] args) throws Exception {
//		String json = "{\"title\":\" 未签到\",\"backgroundColor\":\"#f56954\",\"borderColor\":\"#f56954\",\"start\":\"2016-07-21\"}";
//		ObjectMapper mapper = new ObjectMapper();
//		Map<String,Object> map = mapper.readValue(json, Map.class);
//		System.out.println(map.toString());
//	}

	/**
	 * 修改考勤异常原因
	 */
	@Override
	public void updateReason(Map param) {
		String id = param.get("id").toString();
		//1:签到，2：签退
		String attStyle = param.get("attStyle").toString();
		String reasonType = param.get("reasonType").toString();
		String reason = param.get("reason").toString();
		UTMap<String, Object> map = this.getById(id);
		if("1".equals(attStyle)){
			map.put("startType", reasonType);
			map.put("startReason", reason);
		}else{
			map.put("endType", reasonType);
			map.put("endReason", reason);
		}
		this.updateById(map);
	}
	
	/**
	 * 重新计算所有考勤数据的考勤工时
	 */
	public void updateAllAttTime(){
		logger.info("重新计算所有数据的考勤工时");
		List<UTMap<String, Object>> list = this.getAll();
		for (UTMap<String, Object> utMap : list) {
			try{
//				if(utMap.get("startTime") == null){
//					continue;
//				}
//				if(utMap.get("endTime") == null){
//					continue;
//				}
//				utMap.put("updateRemark","");
				this.updateAttTime(utMap,false);
			}catch(EscServiceException ex){
				logger.error(ex.getMessage());
			}catch(Exception ex){
				logger.error("Exception",ex);
			}
		}
	}
	
	/**
	 * 修改考勤签到签退时间,并且根据请假和出差判断考勤状态
	 * @param param
	 * @param isPage 是否从前端页面修改调用，用来判断是否要修改updateRemark
	 */
	public void updateAttTime(Map param,boolean isPage){
		String id = param.get("id").toString();
		String userId = param.get("userId").toString();
		String startTime = null;
		if(param.get("startTime") != null){
			startTime = param.get("startTime").toString();
		}
		String endTime = null;
		if(param.get("endTime") != null){
			endTime = param.get("endTime").toString();
		}
//		String updateRemark = param.get("updateRemark").toString();
		UTMap<String, Object> userConfig = userConfigDao.getUserConfigByUserId(userId);
		if (userConfig == null) {
			logger.error(CommonUtils.vaildLog("用户的考勤规则已被删除，无法修改此条考勤数据！id="+id));
			throw new EscServiceException("用户的考勤规则已被删除，无法修改此条考勤数据！");
		}
		if(startTime != null && endTime != null){
			long days = UTDate.getDays(startTime, endTime);//间隔天数，如果开始时间和结束时间在同一天，则等于1，
			if(days == 2){//跨了一天
				Date endTimeDate = UTDate.getDate(endTime, UTDate.TIMEF_FORMAT);
				String amBeginDate ;
				//attendanceDateType:考勤方式:(1.确定时间，2.不确定时间).
				//attendanceType:不确定时间的考勤统计方式：（1.统计考勤次数；2.统计考勤时间（单位是小时））
				if ("2".equals(userConfig.get("attendanceDateType").toString()) && "2".equals(userConfig.get("attendanceType").toString())) {
					//考勤规则是按工时统计的默认第二天默认配置的开始签到时间前都可以签到
					amBeginDate = UTDate.dateToDateString(endTimeDate) + " " + DefaultValueTool.getValue("attendance","amBegin") + ":00";//考勤规则默认配置的开始签到时间
				}else{
					String amBegin = userConfig.get("amBegin").toString();//上午签到时间
					amBeginDate = UTDate.dateToDateString(endTimeDate) + " " + amBegin + ":00";
				}
				
				//如果在考勤规则签到时间之前，都可以进行跨天签退
				if(endTimeDate.compareTo(UTDate.getDate(amBeginDate,UTDate.TIMEF_FORMAT)) > 0){
					logger.error(CommonUtils.vaildLog("签退时间只能为当天或第二天考勤开始时间之前！id="+id));
					throw new EscServiceException("签退时间只能为当天或第二天考勤开始时间之前！");
				}
			}
		}
		
		
		int dateinStyle = 0;//是否迟到 1:迟到;0:正常,-1:未签到 
		int dateoutStyle = 0;
		//属于固定考勤用户，如果考勤记录在考勤规则范围之外，比如周末过来加班考勤了，attType=1,否则为0
		if("0".equals(param.get("attType").toString())){
			if(startTime != null){
				dateinStyle = checkDateinStyle(userConfig,UTDate.getDate(startTime, UTDate.TIMEF_FORMAT));//是否迟到 1:迟到;0:正常,-1:未签到 
				if(endTime != null){
					//间隔天数等于1表示不是跨天签退，需要判断考勤签退状态，如果是跨天签退，则签退状态为正常，默认等于0
					if(UTDate.getDays(startTime, endTime) == 1){
						dateoutStyle = checkDateoutStyle(userConfig,UTDate.getDate(endTime, UTDate.TIMEF_FORMAT));//是否早退 1:早退;0:正常,-1:未签退
					}
				}else{
					dateoutStyle = -1;
				}
			}else{
				dateinStyle = -1;
				dateoutStyle = -1;
			}
		}
		
		UTMap<String, Object> att = this.getById(id);
		//考勤方式:(1.确定时间，2.不确定时间统计考勤次数，3.不确定时间统计考勤时间)
		String attendanceDateType = att.get("attendanceDateType").toString();
//		String beginTime = apo.get("startTime").toString();
		double attHours = 0d ;
		long attHoursSecond = 0l ;
		if(startTime != null && endTime != null){
			List<Map<String, Object>> seconds = manHourStatisticService.calculateSeconds(startTime, endTime, userConfig,true);
			if(seconds != null && !seconds.isEmpty()){
				for (Map<String, Object> map2 : seconds) {
					attHoursSecond += Long.valueOf(map2.get("seconds").toString());
				}
				attHours = UTDate.transformSecondToHour(attHoursSecond, false);
			}
		}
		att.put("attHours", attHours);//考勤工时(小时)
		att.put("attHoursSecond", attHoursSecond);//考勤工时(秒)
		att.put("dateinStyle", dateinStyle);
		att.put("dateoutStyle", dateoutStyle);
		//正常需要清空异常原因
		if(dateoutStyle == 0){
			att.put("startType", null);
			att.put("startReason", null);
		}
		//正常需要清空异常原因
		if(dateoutStyle == 0){
			att.put("endType", null);
			att.put("endReason", null);
		}
		att.put("startTime", startTime);
		att.put("endTime", endTime);
		if(isPage){//只有前端页面修改操作才更新updateRemark
			att.put("updateRemark", param.get("updateRemark"));
		}
		att.put("updateUserId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
		String dateStr = att.get("date").toString();
		String userIds = "";//联合考勤ids
		UTMap<String, Object> coalitionConfig = null;
		if(att.get("coalitionId") != null){
			//联合考勤id
			String coalitionId = att.get("coalitionId").toString();
			coalitionConfig = coalitionConfigDao.getById(coalitionId);
			//如果已经找不到联合考勤
			if(coalitionConfig.isEmpty()){
				logger.error(CommonUtils.vaildLog("用户的联合考勤规则已被删除，无法修改此条考勤数据！id="+id));
				throw new EscServiceException("用户的联合考勤规则已被删除，无法修改此条考勤数据！");
			}
			userIds = coalitionConfig.get("userIds").toString();
		}
		//根据请假、出差判断考勤异常,有异常才需要判断
		if((dateinStyle != 0 || dateoutStyle != 0) &&  !"3".equals(attendanceDateType)){
			Map manhourParam = new HashMap();
			manhourParam.put("presentDate", dateStr);
			//如果是联合考勤，并且不是按工时统计的，要把整个联合考勤组的请假、出差数据查询出来
			if(att.get("coalitionId") != null && !"3".equals(attendanceDateType)){
				manhourParam.put("createUserId", userIds);
			}else{
				manhourParam.put("createUserId", userId);
			}
			
			manhourParam.put("status", 5);//只查询审核通过的请假和出差数据
			List<UTMap<String, Object>> list = attendanceDao.getManhourDate(manhourParam);
			if(list != null){
				for (UTMap<String, Object> utMap : list) {
					checkAttDateoStyle(att, utMap);
				}
			}
		}
		
		//不是联合考勤
		if(att.get("coalitionId") == null){
			attendanceDao.updateById(att);
		}else{//是联合考勤
			if("3".equals(attendanceDateType)){
				attendanceDao.updateById(att);
			}else{
				//联合考勤id
//				String coalitionId = att.get("coalitionId").toString();
//				UTMap<String, Object> coalitionConfig = coalitionConfigDao.getById(coalitionId);
//				String userIds = coalitionConfig.get("userIds").toString();
				String[] userIdArr = userIds.split(",");
				for (String coalitionUserId : userIdArr) {
					UTMap<String, Object> po = attendanceDao.queryUserAttendance(dateStr,coalitionUserId);
					if (po == null) {
						logger.error(CommonUtils.vaildLog("用户编号为‘"+userId+"’的联合考勤用户，"+dateStr+"没有考勤数据！"));
						continue;
					}
					//同时修改联合考勤的考勤状态
					po.put("dateinStyle", att.get("dateinStyle"));
					po.put("dateoutStyle", att.get("dateoutStyle"));
					po.put("attHours", att.get("attHours"));//考勤工时(小时)
					po.put("attHoursSecond", att.get("attHoursSecond"));//考勤工时(秒)
					po.put("startTime", att.get("startTime"));
					po.put("endTime", att.get("endTime"));
					po.put("startType", att.get("startType"));
					po.put("startReason", att.get("startReason"));
					po.put("endType", att.get("endType"));
					po.put("endReason", att.get("endReason"));
					if(isPage){//只有前端页面修改操作才更新updateRemark
						po.put("updateRemark", att.get("updateRemark"));
					}
					po.put("updateUserId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
					attendanceDao.updateById(po);
				}
			}
		}
		
		
		
//		if("1".equals(attendanceDateType) || "3".equals(attendanceDateType)){
//			attendanceDao.updateById(att);
//		}else{
//			//联合考勤id
//			String coalitionId = att.get("coalitionId").toString();
//			UTMap<String, Object> coalitionConfig = coalitionConfigDao.getById(coalitionId);
//			String userIds = coalitionConfig.get("userIds").toString();
//			String[] userIdArr = userIds.split(",");
//			for (String coalitionUserId : userIdArr) {
//				UTMap<String, Object> po = attendanceDao.queryUserAttendance(dateStr,coalitionUserId);
//				if (po == null) {
//					logger.error("用户编号为‘"+userId+"’的联合考勤用户，"+dateStr+"没有考勤数据！");
//					continue;
//				}
//				//同时修改联合考勤的考勤状态
//				po.put("dateinStyle", att.get("dateinStyle"));
//				po.put("dateoutStyle", att.get("dateoutStyle"));
//				attendanceDao.updateById(po);
//			}
//		}
//		this.updateById(map);
	}
	
	/**
	 * 修改考勤签到签退时间
	 */
//	@Override
//	public void updateAttTime(Map param) {
//		
//	}
	
	@CronTimeTask(description="每天凌晨汇总检查前一天的请假、加班、出差数据",cron="0 10 0 * * ?")
	public void summarizingManhour(){
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, -1);
//		Map param = new HashMap();
//		param.put("date", UTDate.dateToDateString(calendar.getTime()));
//		List<UTMap<String, Object>> list = attendanceDao.getListMaps(param);
//		if(list != null){
//			for (UTMap<String, Object> att : list) {
//				summarizingManhour(att);
//			}
//		}
		logger.info("每天凌晨汇总检查前一天的请假、加班、出差数据");
		Map param = new HashMap();
		param.put("date", UTDate.dateToDateString(calendar.getTime()));
		List<UTMap<String, Object>> list = this.getListMaps(param);
		for (UTMap<String, Object> utMap : list) {
			try{
//				if(utMap.get("startTime") == null){
//					continue;
//				}
//				if(utMap.get("endTime") == null){
//					continue;
//				}
//				utMap.put("updateRemark","");
				this.updateAttTime(utMap,false);
			}catch(EscServiceException ex){
				logger.error(ex.getMessage());
			}catch(Exception ex){
				logger.error("Exception",ex);
			}
		}
	}
	
	/**
	 * 检查指导考勤数据的加班、请假、出差汇总数据，同时判断对应的考勤异常状态
	 * @param userId 用户id
	 * @param dateStr 加班、请假、出差日期
	 */
	public int updateAttTime(String userId, String dateStr){
		UTMap<String, Object> att = attendanceDao.queryUserAttendance(dateStr,userId);
		if(att != null){
			try{
				updateAttTime(att,false);
			}catch(EscServiceException ex){
				logger.error("EscServiceException",ex);
				return 0;
			}
		}
		return 1;
	}

	/**
	 * 检查指导考勤数据的加班、请假、出差汇总数据，同时判断对应的考勤异常状态
	 * @param att
	 * @return
	 */
//	public void summarizingManhour(UTMap<String, Object> att){
//		
//		String dateStr = att.get("date").toString();
//		String userId = att.get("userId").toString();
//		Map param = new HashMap();
//		param.put("presentDate", dateStr);
//		param.put("createUserId", userId);
////		param.put("status", 5);//1.待提交  2.待审批  3.审批中  4.驳回 5.审批通过 6.被终止
//		List<UTMap<String, Object>> list = attendanceDao.getManhourDate(param);
//		if(list != null){
////			float overtimeHour = 0l;//当天审批通过的加班工时
////			float overtimeHourApply = 0l;//当天申请的所有加班工时
////			float vacationHour = 0l;//当天审批通过的请假工时
////			float vacationHourApply = 0l;//当天申请的所有请假工时
////			float travelHour = 0l;//当天审批通过的出差工时
////			float travelHourApply = 0l;//当天申请的所有出差工时
//			for (UTMap<String, Object> utMap : list) {
////				String manhourType = utMap.get("manhourType").toString();
////				String status = utMap.get("status").toString();//1.待提交  2.待审批  3.审批中  4.驳回 5.审批通过 6.被终止
////				float hours = CommonUtils.convert2Float(utMap.get("hours").toString());
////				if("1".equals(manhourType)){//加班
////					if("5".equals(status)){
////						overtimeHour += hours;
////					}else if(!"6".equals(status)){//被终止的不计算
////						overtimeHourApply += hours;
////					}
//					
////				}else if("2".equals(manhourType)){//请假
////					if("5".equals(status)){
////						vacationHour += hours;
////					}else if(!"6".equals(status)){//被终止的不计算
////						vacationHourApply += hours;
////					}
//					
//					//根据请假判断考勤异常,有异常才需要判断
////					if((att.get("startTime") != null && !"0".equals(att.get("dateinStyle").toString())) || (att.get("endTime") != null && !"0".equals(att.get("dateoutStyle").toString()))){
////						checkAttDateoStyle(att, utMap);
////					}
////				}else{//出差
////					if("5".equals(status)){
////						travelHour += hours;
////					}else if(!"6".equals(status)){//被终止的不计算
////						vacationHourApply += hours;
////					}
//					
//					//根据出差判断考勤异常,有异常才需要判断
////					if((att.get("startTime") != null && !"0".equals(att.get("dateinStyle").toString())) || (att.get("endTime") != null && !"0".equals(att.get("dateoutStyle").toString()))){
////						checkAttDateoStyle(att, utMap);
////					}
////				}
//				//根据请假、出差判断考勤异常,有异常才需要判断
//				if(!"0".equals(att.get("dateinStyle").toString()) ||  !"0".equals(att.get("dateoutStyle").toString())){
//					checkAttDateoStyle(att, utMap);
//				}
//			}
////			att.put("overtimeHour", overtimeHour);
////			att.put("vacationHour", vacationHour);
////			att.put("travelHour", travelHour);
////			att.put("overtimeHourApply", overtimeHourApply);
////			att.put("vacationHourApply", vacationHourApply);
////			att.put("travelHourApply", travelHourApply);
//			//attendanceDateType:考勤方式:(1.确定时间，2.不确定时间统计考勤次数，3.不确定时间统计考勤时间)
//			String attendanceDateType = att.get("attendanceDateType").toString();
//			if("1".equals(attendanceDateType) || "3".equals(attendanceDateType)){
//				attendanceDao.updateById(att);
//			}else{
//				//联合考勤id
//				String coalitionId = att.get("coalitionId").toString();
//				UTMap<String, Object> coalitionConfig = coalitionConfigDao.getById(coalitionId);
//				String userIds = coalitionConfig.get("userIds").toString();
//				String[] userIdArr = userIds.split(",");
//				for (String coalitionUserId : userIdArr) {
//					UTMap<String, Object> po = attendanceDao.queryUserAttendance(dateStr,coalitionUserId);
//					if (po == null) {
//						logger.error("用户编号为‘"+userId+"’的联合考勤用户，"+dateStr+"没有考勤数据！");
//						continue;
//					}
//					//同时修改联合考勤的考勤状态
//					po.put("dateinStyle", att.get("dateinStyle"));
//					po.put("dateoutStyle", att.get("dateoutStyle"));
//					attendanceDao.updateById(po);
//				}
//			}
//			
//		}
//		
//	}
	
	 private String getDateStr(String dateStr, String fmt) {
	        try {
	            if (dateStr == null || dateStr.equals("")) {
	                return "";
	            }
	            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat(fmt);
	            java.util.Date d = UTDate.getDate(dateStr, UTDate.TIMEF_FORMAT);
	            String newDate = sdf.format(d);
	            return newDate;
	        } catch (Exception e) {
	            //log.debug("\n" + e.getMessage());
	        }
	        return "";
	    }
	
	
	/**
	 * 根据加班、出差数据检查考勤异常情况
	 * @param att 考勤数据
	 * @param manhour 加班、出差数据
	 * @return
	 */
	public UTMap<String, Object> checkAttDateoStyle(UTMap<String, Object> att, Map manhour){
		
		String userId = att.get("userId").toString();
		UTMap<String, Object> userConfig = userConfigDao.getUserConfigByUserId(userId);
		if (userConfig == null) {
			logger.error(CommonUtils.vaildLog("没有找到相应的考勤规则！userId="+userId));
			return att;
		}
		
		String dateStr = att.get("date").toString();//考勤日期
		Date amBegin = UTDate.getDate(dateStr + " " + userConfig.get("amBegin").toString() + ":00", UTDate.TIMEF_FORMAT);//考勤规则签到开始时间
		Date amEnd = UTDate.getDate(dateStr + " " + userConfig.get("amEnd").toString() + ":00", UTDate.TIMEF_FORMAT);
		Date pmBegin = UTDate.getDate(dateStr + " " + userConfig.get("pmBegin").toString() + ":00", UTDate.TIMEF_FORMAT);
		Date pmEnd = UTDate.getDate(dateStr + " " + userConfig.get("pmEnd").toString() + ":00", UTDate.TIMEF_FORMAT);//考勤规则签退结束时间
		
		Date beginTime = UTDate.getDate(dateStr + " " + this.getDateStr(manhour.get("beginTime").toString(), "HH:mm:ss"), UTDate.TIMEF_FORMAT);//请假、出差当天开始时间
		Date endTime = UTDate.getDate(dateStr + " " + this.getDateStr(manhour.get("endTime").toString(), "HH:mm:ss"), UTDate.TIMEF_FORMAT);//请假、出差当天结束时间
		
//		if(att.get("manhourBeginTime") != null){
//			Date manhourBeginTime = UTDate.getDate(att.get("manhourBeginTime").toString(), UTDate.TIMEF_FORMAT);
//			Date manhourEndTime = UTDate.getDate(att.get("manhourEndTime").toString(), UTDate.TIMEF_FORMAT);
//			//如果开始时间在考勤规则开始时间之前（包含等于)
//			if(manhourBeginTime.compareTo(amBegin) <= 0){
//				
//			}
//			
//		}else{
//			att.put("manhourBeginTime", beginTime);
//			att.put("manhourEndTime", endTime);
//		}
		
		//JDK Date.compareTo(Date date):如果参数 Date 等于此 Date，则返回值 0；如果此 Date 在 Date 参数之前，则返回小于 0 的值；如果此 Date 在 Date 参数之后，则返回大于 0 的值。
		//如果请假、出差当天开始时间在考勤规则签到开始时间之前（包含等于）,同时请假、出差当天结束时间在勤规则签退结束时间之后（包含等于）,则当天考勤正常
		if(beginTime.compareTo(amBegin) <= 0 && endTime.compareTo(pmEnd) >= 0 ){
			att.put("dateinStyle", 0);
			att.put("dateoutStyle", 0);
		}else{
			//有签到，同时签到异常（是否迟到 1:迟到;//null:未签到;0:正常）
			if(att.get("startTime") != null && !"0".equals(att.get("dateinStyle").toString())){
				Date attStartTime = UTDate.getDate(att.get("startTime").toString(), UTDate.TIMEF_FORMAT);//当天考勤开始时间
				//如果考勤签到时间在考勤规则的间隔时间段以内，比如中午，则设置考勤时间为考勤规则上午的结束时间，以避免下一步和考勤规则判断的时候出现误差（）
				if(attStartTime.compareTo(amEnd) > 0 && attStartTime.compareTo(pmBegin) < 0){
					attStartTime = amEnd;
				}
				//如果请假、出差当天开始时间在考勤规则签到开始时间之前（包含等于）,并且请假、出差当天结束时间在考勤时间之后（包含等于），签到正常
				if(beginTime.compareTo(amBegin) <= 0 && endTime.compareTo(attStartTime) >= 0){
					att.put("dateinStyle", 0);
				}
			}
			
			
			//有签退，同时签退异常（是否早退1：早退;0:正常;-1:未签退）
			if(att.get("endTime") != null && !"0".equals(att.get("dateoutStyle").toString())){
				Date attEndTime = UTDate.getDate(att.get("endTime").toString(), UTDate.TIMEF_FORMAT);//当天考勤结束时间
				//如果考勤签退时间在考勤规则的间隔时间段以内，比如中午，则设置考勤时间为考勤规则下午的开始时间，以避免下一步和考勤规则判断的时候出现误差（）
				if(attEndTime.compareTo(amEnd) > 0 && attEndTime.compareTo(pmBegin) < 0){
					attEndTime = pmBegin;
				}
				//如果请假、出差当天开始时间在考勤签退时间之前（包含等于）,并且请假、出差当天结束时间在考勤规则签退时间之后（包含等于），签退正常
				if(beginTime.compareTo(attEndTime) <= 0 && endTime.compareTo(pmEnd) >= 0){
					att.put("dateoutStyle", 0);
				}
			}
		}
		
		return att;
		
	}
	
	/**
	 * 获取个人考勤工时统计数据
	 * @param pageBean
	 * @param param
	 */
	@Override
	public List<UTMap<String, Object>> getAllAttHours(Map param) {
		// TODO Auto-generated method stub
		return attendanceDao.getAllAttHours(param);
	}
	
	/**
	 * 获取个人考勤工时统计数据
	 * @param pageBean
	 * @param param
	 */
	public void getAttHours(UTPageBean pageBean,Map param){
		attendanceDao.getAttHours(pageBean, param);
	}
	
	
	/**
	 * 常规考勤统计（供应商）
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllSupplierConventional(Map param){
		return attendanceDao.getAllSupplierConventional(param);
	}
	
	/**
	 * 常规考勤统计（供应商）
	 * @param pageBean
	 * @param param
	 */
	public void getSupplierConventional(UTPageBean pageBean,Map param){
		attendanceDao.getSupplierConventional(pageBean, param);
	}
	
	/**
	 * 常规考勤统计（部门）
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllOrgConventional(Map param){
		return attendanceDao.getAllOrgConventional(param);
	}
	
	/**
	 * 常规考勤统计（部门）
	 * @param pageBean
	 * @param param
	 */
	public void getOrgConventional(UTPageBean pageBean,Map param){
		attendanceDao.getOrgConventional(pageBean, param);
	}
	
	/**
	 * 导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	@Override
	public void leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String[] fileds = IAttendanceDao.outFileds;
		String tamlate = "excelOutTamplate.attendanceList";
		
		//替换下拉的值
		Map<String, String> fieldAndParamType = new HashMap<String, String>();
		fieldAndParamType.put(IAttendanceDao.FIELD_DATEINSTYLE, "attendanceStartExceptionStatus");
		fieldAndParamType.put(IAttendanceDao.FIELD_DATEOUTSTYLE, "attendanceEndExceptionStatus");
		fieldAndParamType.put(IAttendanceDao.FIELD_STARTTYPE, "attendanceExceptionType");
		fieldAndParamType.put(IAttendanceDao.FIELD_ENDTYPE, "attendanceExceptionType");
		sysParamService.changeParamData(data, fieldAndParamType);
		
		if (null != data && !data.isEmpty()) {
			for (int i=0;i<data.size();i++) {
				UTMap<String, Object> item = (UTMap<String, Object>) data.get(i);
				item.put(IAttendanceDao.FIELD_DATE, CommonUtils.replaceAll((String)item.get(IAttendanceDao.FIELD_DATE), "-", "/"));
				item.put(IAttendanceDao.FIELD_STARTTIME, CommonUtils.replaceAll((String)item.get(IAttendanceDao.FIELD_STARTTIME), "-", "/"));
				item.put(IAttendanceDao.FIELD_ENDTIME, CommonUtils.replaceAll((String)item.get(IAttendanceDao.FIELD_ENDTIME), "-", "/"));
			}
		}
//		Map<String,Object> param = new HashMap<String,Object>();
//		param.put("state", "1");
//		param.put("userType", "2");//查询供应商人员
//		List<UTMap<String,Object>> userMap = userService.getUserBaseInfo(param);
		
		//转换人员
//		for(int i=0;i<data.size();i++){
//			Map<String,Object> item = (Map<String, Object>) data.get(i);
//			String userId = (String) item.get(IAttendanceDao.FIELD_USERID);
//			item.put(IRiskOverallEvaluateConfigurationDao.FIELD_EVALUATOR, CommonUtils.getUserNameAndCodesByIds(userMap, userId));
//		}
		
		UTExcel.leadingout( fileds, data, tamlate, request, response);
	}
	
	/**
	 * 考勤工时统计(个人)导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	@Override
	public void leadingoutAttHours(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String[] fileds = IAttendanceDao.outAttHoursFileds;
		if (null != data && !data.isEmpty()) {
			for (int i=0;i<data.size();i++) {
				UTMap<String, Object> item = (UTMap<String, Object>) data.get(i);
				item.put(IAttendanceDao.FIELD_BEGINDATE, CommonUtils.replaceAll((String)item.get(IAttendanceDao.FIELD_BEGINDATE), "-", "/"));
				item.put(IAttendanceDao.FIELD_ENDDATE, CommonUtils.replaceAll((String)item.get(IAttendanceDao.FIELD_ENDDATE), "-", "/"));
			}
		}
		String tamlate = "excelOutTamplate.attendanceHours";
		UTExcel.leadingout( fileds, data, tamlate, request, response);
	}

	/**
	 * 常规考勤统计（供应商）导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	@Override
	public void leadingoutAttSupplierConventional(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String[] fileds = IAttendanceDao.outAttSupplierConventionalFileds;
		if (null != data && !data.isEmpty()) {
			for (int i=0;i<data.size();i++) {
				UTMap<String, Object> item = (UTMap<String, Object>) data.get(i);
				item.put(IAttendanceDao.FIELD_BEGINDATE, CommonUtils.replaceAll((String)item.get(IAttendanceDao.FIELD_BEGINDATE), "-", "/"));
				item.put(IAttendanceDao.FIELD_ENDDATE, CommonUtils.replaceAll((String)item.get(IAttendanceDao.FIELD_ENDDATE), "-", "/"));
			}
		}
		String tamlate = "excelOutTamplate.attSupplierConventional";
		UTExcel.leadingout( fileds, data, tamlate, request, response);
	}
	
	/**
	 * 常规考勤统计（部门）导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	@Override
	public void leadingoutAttOrgConventional(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String[] fileds = IAttendanceDao.outAttOrgConventionalFileds;
		if (null != data && !data.isEmpty()) {
			for (int i=0;i<data.size();i++) {
				UTMap<String, Object> item = (UTMap<String, Object>) data.get(i);
				item.put(IAttendanceDao.FIELD_BEGINDATE, CommonUtils.replaceAll((String)item.get(IAttendanceDao.FIELD_BEGINDATE), "-", "/"));
				item.put(IAttendanceDao.FIELD_ENDDATE, CommonUtils.replaceAll((String)item.get(IAttendanceDao.FIELD_ENDDATE), "-", "/"));
			}
		}
		String tamlate = "excelOutTamplate.attOrgConventional";
		UTExcel.leadingout( fileds, data, tamlate, request, response);
	}
	
	/**
	 * 获取联合考勤工时统计数据
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllCoalitionAttHours(Map param){
		return attendanceDao.getAllCoalitionAttHours(param);
	}
	
	/**
	 * 获取联合考勤工时统计数据
	 * @param pageBean
	 * @param param
	 */
	public void getCoalitionAttHours(UTPageBean pageBean,Map param){
		attendanceDao.getCoalitionAttHours(pageBean, param);
	}
	
	/**
	 * 联合考勤统计
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	public void leadingoutCoalitionAttHours(List data, HttpServletRequest request, HttpServletResponse response) throws Exception{
		String[] fileds = IAttendanceDao.outCoalitionAttHoursFileds;
		if (null != data && !data.isEmpty()) {
			for (int i=0;i<data.size();i++) {
				UTMap<String, Object> item = (UTMap<String, Object>) data.get(i);
				item.put(IAttendanceDao.FIELD_BEGINDATE, CommonUtils.replaceAll((String)item.get(IAttendanceDao.FIELD_BEGINDATE), "-", "/"));
				item.put(IAttendanceDao.FIELD_ENDDATE, CommonUtils.replaceAll((String)item.get(IAttendanceDao.FIELD_ENDDATE), "-", "/"));
			}
		}
		String tamlate = "excelOutTamplate.attendanceCoalitionHours";
		UTExcel.leadingout( fileds, data, tamlate, request, response);
	}

}
