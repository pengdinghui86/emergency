package com.esc.oms.asset.agreement.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.asset.agreement.dao.IAssetsAgreementWarnConfigDao;
@Repository
public class AssetsAgreementWarnConfigDaoImpl extends BaseOptionDao implements IAssetsAgreementWarnConfigDao{
	
	@Override
	public String getTableName() {
		return "assets_agreement_warn_config";
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params,false), pageBean, null);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params) {
		return super.getListBySql(getSearchSql(params,false), null);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListMaps(Map params) {
		return super.getListBySql(getSearchSql(params,false), null);
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params,boolean isGetById){
		StringBuilder sql = new StringBuilder();
		sql.append(" select config.* "
				+ "  from assets_agreement_warn_config config ");
		sql.append(" order by config.warnDayNum asc");
		return  sql.toString();
	}
	
	public UTMap<String, Object> getWarnNumList(){
		StringBuilder sql = new StringBuilder();
		sql.append(" select a.*,b.*,c.* from "
				+ "(select config.type as redType,config.warnDayNum as redDayNum from assets_agreement_warn_config config where type='红色预警') a,"
				+ "(select config.type as yellowType,config.warnDayNum as yellowDayNum from assets_agreement_warn_config config where type='黄色预警') b,"
				+ "(select config.type as blueType,config.warnDayNum as blueDayNum from assets_agreement_warn_config config where type='蓝色预警') c");
		return super.getOneBySql(sql.toString(), null);
	}

	@Override
	public int getMaxWarnNum() {
		StringBuilder sql = new StringBuilder();
		sql.append(" select max(warnDayNum) as maxNum from assets_agreement_warn_config ");
		UTMap<String, Object> map = super.getOneBySql(sql.toString(), null);
		if(map!=null){
			return (Integer) map.get("maxNum");
		}else{
			return 0;
		}		
	}

}
