package com.esc.oms.asset.lowvalue.controller;

import com.esc.oms.asset.lowvalue.service.ILowvalueStorageService;
import com.esc.oms.util.CommonUtils;
import net.sf.json.JSONObject;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
@Controller
@RequestMapping("lowvalueStorage")
public class LowvalueStorageController extends BaseOptionController {

	@Resource
	private ILowvalueStorageService service;
	
	@Override
	public IBaseOptionService optionService() {
		return service;
	}
	
	/**
	 * 新增，需要返回一个infoId给前台的其他标签
	 * @param info
	 * @return
	 */
	@RequestMapping(value="add",method =RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> add(@RequestBody  Map<String, Object> map1){
		Map<String,Object> cloneMap = CommonUtils.clone(map1);
		try{ 
    		boolean result = optionService().add(cloneMap);
    		if(result){
    			cloneMap.put("success", true);
    			cloneMap.put("msg", "操作成功！");
    		}else{
    			cloneMap.put("success", false);
//        		info.put("msg", "操作失败！");
    		}   		
    	}catch(EscServiceException e){
    		logger.error("EscServiceException",e);
    		cloneMap.put("success", false);
    		cloneMap.put("msg", e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		cloneMap.put("success", false);
    		cloneMap.put("msg", "操作失败！");
    	}
       return cloneMap;
	}
	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			service.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	

	/**
	 * 根据编号删除
	 * @param param
	 * @return
	 */
	@RequestMapping(value="deleteByIds")
	@ResponseBody
	public String defdeletes(@RequestBody Map<String, Object> param){
		try{
			String ids=param.get("ids").toString();
			if(!StringUtils.isEmpty(ids)){
				String[] str = ids.split(",");
				for(String id:str){
					service.deleteById(id);
				}
			}
//			optionService().delete(param);
    	}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "删除失败");
    	}
    	return UTJsonUtils.getJsonMsg(true, "删除成功");
	}
	
	
	/**
	 * 从excel导入
	 * @param params
	 * @param filePath
	 * @return
	 */
	@RequestMapping(value = "leadingin")
	@ResponseBody
	public UTMap<String, Object> leadingin(@RequestParam Map<String, Object> param, String filePath) {
		UTMap<String, Object> utMap = new UTMap<String, Object>();
		try {
			utMap.put("success", service.leadingin(FilenameUtils.normalize(filePath) , param));
			utMap.put("msg", "导入成功！");
		}catch(EscServiceException e){
			logger.error("EscServiceException",e);
			utMap.put("success", false);
			utMap.put("msg", e.getMessage());
    	} catch (Exception e) {
    		logger.error("Exception",e);
			utMap.put("success", false);
			utMap.put("msg", "导入失败");
		} finally {
			try {
				File file = new File(FilenameUtils.normalize(filePath));
				file.delete();
			} catch (Exception e2) {
				logger.error("删除导入的文件失败！");
			}
		}
		return utMap;
	}
	
	/**
	 * 导出
	 * @param param
	 * @param utPageBean
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "leadingout")
	public void leadingout(@RequestParam Map<String, Object> param,
			HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = null;
			if(info != null) {
				jsonBean = JSONObject.fromObject(info);
			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = service.getListAll(jsonBean);
			} else {
				service.getPageInfo(utPageBean, jsonBean);
				data = utPageBean.getRows();
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			service.leadingout(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
}