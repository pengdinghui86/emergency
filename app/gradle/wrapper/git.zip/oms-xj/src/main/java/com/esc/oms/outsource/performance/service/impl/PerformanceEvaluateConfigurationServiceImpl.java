package com.esc.oms.outsource.performance.service.impl;

import com.esc.oms.outsource.performance.dao.IPerformanceEvaluateConfigurationDao;
import com.esc.oms.outsource.performance.dao.IPerformanceEvaluateDao;
import com.esc.oms.outsource.performance.dao.IPerformanceEvaluateTemplateDao;
import com.esc.oms.outsource.performance.dao.IPerformanceEvaluateUserDao;
import com.esc.oms.outsource.performance.service.IPerformanceEvaluateConfigurationService;
import com.esc.oms.outsource.performance.service.IPerformanceEvaluateService;
import com.esc.oms.outsource.performance.service.IPerformanceEvaluateUserService;
import com.esc.oms.supplier.supplieremp.service.ISupplierEmpService;
import com.esc.oms.system.evaluateMatch.service.IEvaluateMatchService;
import com.esc.oms.system.evaluateSetting.dao.IEvaluateSettingDao;
import com.esc.oms.system.service.ISendMessage;
import com.esc.oms.system.templateconfiguration.dao.ITemplateConfigurationDetailDeputyDao;
import com.esc.oms.system.templateconfiguration.dao.ITemplateConfigurationDetailDeputyResultDao;
import com.esc.oms.system.templateconfiguration.service.ITemplateConfigurationDetailDeputyService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;
import com.esc.oms.util.TaskModel;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.dict.dao.ISysParamDao;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.service.ISysOrgService;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;

/**
 * 外包绩效考核配置
 * @author owner
 *
 */
@Service
@Transactional
public class PerformanceEvaluateConfigurationServiceImpl extends BaseOptionService implements IPerformanceEvaluateConfigurationService,ISendMessage{
	
	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private IPerformanceEvaluateConfigurationDao dao;
	
	//模板配置详情dao
	@Resource
	private IPerformanceEvaluateTemplateDao performanceEvaluateTemplateDao;
	
	//模板配置详情副表操作dao
	@Resource
	private ITemplateConfigurationDetailDeputyDao templateConfigurationDetailDeputyDao;
	
	//外包绩效考核
	@Resource
	private IPerformanceEvaluateDao performanceEvaluateDao;
	
	//外包绩效考核-被考核对象
	@Resource
	private IPerformanceEvaluateUserDao performanceEvaluateUserDao;
	
	//外包绩效考核-被考核对象
	@Resource
	private IPerformanceEvaluateUserService performanceEvaluateUserService;
	
	//外包绩效考核
	@Resource
	private IPerformanceEvaluateService performanceEvaluateService;
	
	//模板配置从属数据操作Service接口
	@Resource
	private ITemplateConfigurationDetailDeputyService templateConfigurationDetailDeputyService;
	
	//模板配置从属数据结果操作dao接口
	@Resource
	private ITemplateConfigurationDetailDeputyResultDao templateConfigurationDetailDeputyResultDao;
	
	//用户
	@Resource
	private ISysUserService sysUserService;
	
	//组织机构
	@Resource
	private ISysOrgService sysOrgService;

	//代办任务
	@Resource
	private IUserTaskService userTaskService;
	
	@Resource
	private MessageSend messageService;
	
	@Resource
	private ISysParamDao paramDao;
	
	//评估结果配置
	@Resource
	private IEvaluateSettingDao evaluateSettingDao;
	
	@Resource
	private IEvaluateMatchService evaluateMatchService; //结果匹配
	
	@Resource
	private ISupplierEmpService supplierEmpService;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return dao;
	}

	/**
	 * 添加
	 * @param info
	 * @return
	 */
//	@UploadAddMark//aop拦截绑定上传文件的数据关系
	@EscOptionLog(module = SystemModule.performanceEvaluateConfiguration, opType = ESCLogOpType.INSERT, table = "outsourc_performance_evaluate_configuration", option = "新增考核标题为{evaluateTitle}的人员绩效考核配置。")
	public boolean add(Map info){
		String evaluateTitle = info.get("evaluateTitle").toString();//评估标题
		String templateConfigurationId = info.get("templateConfigurationId")==null?"":info.get("templateConfigurationId").toString();//全面评估结果填报模板
		Map param = new HashMap();
		param.put("evaluateTitle", evaluateTitle);
		if(dao.isExist(param)){
			throw new EscServiceException(evaluateTitle+"已经存在！");
		}
		info.put("status", 0);//评估状态,初始是待评估0
		info.put("evaluateStatus", 0);//只标识供应商准入评估模板对应的个人准入评估是否已经在评估，待评估：0，评估中：1，已评估：2
		super.add(info);
		String id = info.get("id") + "";
		List templateList = (List)info.get("templateList");//模板列表
		String performanceEvaluator = info.get("performanceEvaluator") + "";
		//初始化全面评估结果填报模板副表数据
		templateConfigurationDetailDeputyDao.initDataByTemplateConfigurationId(templateConfigurationId, id);
		String[] performanceEvaluatorArr = performanceEvaluator.split(",");//被考核人用户编号
		//添加结果评估数据
		for (String userId : performanceEvaluatorArr) {
			List<UTMap<String, Object>> projectInfos = supplierEmpService.getProjectInfoByUserId(userId);
			if (null == projectInfos || projectInfos.isEmpty()) {
				UTMap<String, Object> userInfo = sysUserService.getById(userId);
				throw new EscServiceException("被考核的用户【"+userInfo.get("name")+"/"+userInfo.get("code")+"不在项目中】！"); 
			}
			for (UTMap<String, Object> projectInfo : projectInfos) {
				Map evaluateUserMap = new HashMap();
				evaluateUserMap.put("performanceEvaluateTemplateId", templateConfigurationId);//评估模板id
				evaluateUserMap.put("performanceEvaluator", userId);//被考核对象
				evaluateUserMap.put("performanceEvaluateConfigId", id);//外包绩效考核配置id
				evaluateUserMap.put("status", 0);//状态
				evaluateUserMap.put("templateEdit", 0);//是否已经填写模板（0：否，1：是）
				evaluateUserMap.put("type", 1);//评估数据类型。1：结果评估，2：过程评估
				evaluateUserMap.put("evaluateTitle", evaluateTitle);//考核标题
				evaluateUserMap.put("unit", info.get("unit"));//考核单位
				evaluateUserMap.put("year", info.get("year"));//考核的年份
				evaluateUserMap.put("half", info.get("half"));//上半年、下半年
				evaluateUserMap.put("quarter", info.get("quarter"));//季度
				evaluateUserMap.put("month", info.get("month"));//考核的月份
				evaluateUserMap.put("dataType", 1);//数据类型（1：评估配置的数据，2：新增的数据）
				evaluateUserMap.put("projectInfoId", projectInfo.get("id"));//数据类型（1：评估配置的数据，2：新增的数据）
				performanceEvaluateUserService.add(evaluateUserMap);
			}
		}
		
		addSubData(id, performanceEvaluator, templateList,evaluateTitle,info.get("year").toString(),info.get("unit").toString(),info.get("half")==null?"":info.get("half").toString(),
				info.get("quarter")==null?"":info.get("quarter").toString(),info.get("month")==null?"":info.get("month").toString());
		return true;
	}
	
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		UTMap<String, Object> result = super.getById(id);
		Map param = new HashMap();
		param.put("performanceEvaluateConfigId", id);
		//模板列表
		result.put("templateList", performanceEvaluateTemplateDao.getListMaps(param));
//		formatDataToExcel(id);
		return result;
	}
	
	/**
	 * 根据ID 获取（评估结果需要的数据接口）
	 * @param info
	 * @return
	 */
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getByIdToAccessResult(String id){
		UTMap<String, Object> result = super.getById(id);
		//评估人评估列表
		Map params = new HashMap();
		params.put("performanceEvaluateConfigId", id);//外包绩效考核配置id
		params.put("type", 1);//评估数据类型。1：结果评估，2：过程评估
		params.put("isProcessUserList", true);//过程考核数据展示排序按考核名称排，列表按时间排
		
		/*boolean isInput = false;
		UTMap<String, Object> setting = evaluateSettingDao.getById("1");
		//判断评估结果的填报方式是下拉还是文本输入
		if(setting != null && "0".equals(setting.get("humanPerformanceResult").toString())){
			isInput = true;
		}*/
		//查询结果评估数据
		List<UTMap<String, Object>> userList =  performanceEvaluateUserDao.getListAll(params);
		//根据过程评估结果和所占权重计算过程评估总分
		String isWeight = (String)result.get("isWeight");
		//if("1".equals(isWeight)){ //配置了权重
			for (UTMap<String, Object> user : userList) {
				String complianceDeduction = (String) user.get("complianceDeduction");
				if (StringUtils.isEmpty(complianceDeduction)) {
					complianceDeduction = "0";
					user.put("complianceDeduction", complianceDeduction);
				}

				//这里取平均数是因为一个被考核对象可能在一个过程评估中被多个人评估（比如过程考核配置的时候考核对象类别选择的是角色）
				String performanceEvaluator = user.get("performanceEvaluator") + "";
				String projectInfoId = (String) user.get("projectInfoId");
				List<UTMap<String, Object>> process = performanceEvaluateUserDao.getAvgEvaluateResult(id, performanceEvaluator, projectInfoId);
				float total = 0f; //过程评估总分
				float totalResult = 0f;
				for (UTMap<String, Object> pro : process) {
					String evaluateResult = pro.get("evaluateResult") + "";
					String templateId = pro.get("performanceEvaluateTemplateId") + "";
					UTMap<String,Object> template = performanceEvaluateTemplateDao.getById(templateId);
					float score = CommonUtils.convert2Float(evaluateResult);    //过程考核结果
					if("1".equals(isWeight)) {
						float percent = (float)(Integer)template.get("percent"); 	//权重百分比
						total += (percent / 100) * score;
					}else {
						totalResult += score;
					}
				}
				if (!StringUtils.equals("1", isWeight)) {
					total = totalResult / Float.parseFloat(process.size() + "");
				}
				BigDecimal b = new BigDecimal(total);
				total = b.setScale(2, BigDecimal.ROUND_HALF_UP).floatValue();//保留两位小数
				user.put("total",total); 
				/*if(StringUtils.isEmpty((String)user.get("evaluateResult")) || StringUtils.equals("0", (String)user.get("evaluateResult"))){
					//if(isInput){ 
						//填空直接把过程评估分数赋给结果评估
						user.put("evaluateResult", total);
					}else{
						//下拉根据分数找到对应的区间返回结果
						String evaluateResult = evaluateMatchService.getResult(total, "person");
						user.put("evaluateResult", evaluateResult);
					}
				}*/
				user.put("evaluateResult", total);
				Object evaluateResult = user.get("evaluateResult");
				float evaluateNum = Float.parseFloat(evaluateResult == null ? "0" : evaluateResult.toString());
				String evaluateNumStr = evaluateMatchService.getResult(evaluateNum, "person");
				if (StringUtils.isEmpty(evaluateNumStr)) {
					evaluateNumStr = "0";
				}
				user.put("evaluateNum",  evaluateNumStr);
				float totalNum = CommonUtils.convert2Float(evaluateNumStr) - CommonUtils.convert2Float(complianceDeduction);
				if (totalNum < 0f) {
					totalNum = 0f;
				}
				user.put("totalNum", totalNum);
			}
		result.put("userList", userList);
		params.put("type", 2);//评估数据类型。1：结果评估，2：过程评估
		//查询过程评估数据
		result.put("processUserListSize", performanceEvaluateUserDao.getListAll(params).size());
		return result;
	}
	
	
	/**
	 * @param id
	 * @return
	 * 查询过程考核
	 */
	public UTMap<String, Object> getByIdToAccessResult2(String id){
		UTMap<String, Object> result = super.getById(id);
		Map params = new HashMap();
		params.put("performanceEvaluateConfigId", id);//外包绩效考核配置id
		params.put("isProcessUserList", true);//过程考核数据展示排序按考核名称排，列表按时间排
		params.put("type", 1);//评估数据类型。1：结果评估，2：过程评估
		List<UTMap<String, Object>> userList =  performanceEvaluateUserDao.getListAll(params);
		params.put("type", 2);//评估数据类型。1：结果评估，2：过程评估
		
		List<Map<String, Object>> processUserList = new ArrayList<Map<String, Object>>();
		List<UTMap<String, Object>> list = performanceEvaluateUserDao.getListAll(params);
		if (list != null && list.size() > 0) {
			Set<String> userSet = new HashSet<String>();
			for(UTMap<String, Object> utMap : userList){
				
				String performanceEvaluatorName = (String)utMap.get("performanceEvaluatorName");
				if (userSet.contains(performanceEvaluatorName)) {
					continue;
				}
				userSet.add(performanceEvaluatorName);
				Map<String, Object> newMap = new HashMap<String, Object>();
				List<UTMap<String, Object>> newlist = new ArrayList<UTMap<String, Object>>();
				for (UTMap<String, Object> utMap2 : list) {
					if(performanceEvaluatorName.equals(utMap2.get("performanceEvaluatorName"))){
						newlist.add(utMap2);
					}
				}
				newMap.put("performanceEvaluatorName", performanceEvaluatorName);
				newMap.put("childList", newlist);
				processUserList.add(newMap);
				
			}
		}
		result.put("processUserList",processUserList);
		return result;
	}
	
	/**
	 * 修改
	 * @param info
	 * @return
	 */
//	@UploadAddMark//aop拦截绑定上传文件的数据关系
	@EscOptionLog(module = SystemModule.performanceEvaluateConfiguration, opType = ESCLogOpType.UPDATE, table = "outsourc_performance_evaluate_configuration", option = "更新考核标题为{evaluateTitle}的人员绩效考核配置。")
	public boolean updateById(Map info){
		String id = info.get("id") + "";
		String evaluateTitle = info.get("evaluateTitle").toString();//评估标题
//		Map param = new HashMap();
//		param.put("moduleTemplateConfigurationId", id);
//		templateConfigurationDetailDeputyDao.delete(param);//先删除模板副表对应的数据
		userTaskService.deleteByBatch(id);//删除需要批量清除掉配置下所有代办任务
		deleteSubData(id);
		String templateConfigurationId = info.get("templateConfigurationId")==null?"":info.get("templateConfigurationId").toString();//全面评估结果填报模板
		//重新初始化全面评估结果填报模板副表数据
		templateConfigurationDetailDeputyDao.initDataByTemplateConfigurationId(templateConfigurationId, id);
		Map param = new HashMap();
		param.put("performanceEvaluateConfigId", id);
		performanceEvaluateUserDao.delete(param);
		
		String performanceEvaluator = info.get("performanceEvaluator") + "";
		//初始化全面评估结果填报模板副表数据
		String[] performanceEvaluatorArr = performanceEvaluator.split(",");//被考核人用户编号
		//添加结果评估数据
		for (String userId : performanceEvaluatorArr) {
			Map evaluateUserMap = new HashMap();
			evaluateUserMap.put("performanceEvaluateTemplateId", templateConfigurationId);//评估模板id
			evaluateUserMap.put("performanceEvaluator", userId);//被考核对象
//			evaluateUserMap.put("evaluator", evaluatorId);//评估人
			evaluateUserMap.put("performanceEvaluateConfigId", id);//供应商绩效考核配置id
			evaluateUserMap.put("status", 0);//状态
			evaluateUserMap.put("type", 1);//评估数据类型。1：结果评估，2：过程评估
			evaluateUserMap.put("evaluateTitle", evaluateTitle);//考核标题
			evaluateUserMap.put("unit", info.get("unit"));//考核单位
			evaluateUserMap.put("year", info.get("year"));//考核的年份
			evaluateUserMap.put("half", info.get("half"));//上半年、下半年
			evaluateUserMap.put("quarter", info.get("quarter"));//季度
			evaluateUserMap.put("month", info.get("month"));//考核的月份
			evaluateUserMap.put("dataType", 1);//数据类型（1：评估配置的数据，2：新增的数据）
//			evaluateUserMap.put("performanceEvaluateId", id);//过程评估编号也存考核配置id，用来区分是过程评估的数据还是结果评估的数据
			performanceEvaluateUserService.add(evaluateUserMap);
		}
//		deleteSubData(id);
		List templateList = (List)info.get("templateList");//模板列表
//		String performanceEvaluator = info.get("performanceEvaluator") + "";
//		addSubData(id, performanceEvaluator, templateList,evaluateTitle,info.get("year")+"",info.get("month")==null?"":info.get("month").toString());
		addSubData(id, performanceEvaluator, templateList,evaluateTitle,info.get("year").toString(),info.get("unit").toString(),info.get("half")==null?"":info.get("half").toString(),
				info.get("quarter")==null?"":info.get("quarter").toString(),info.get("month")==null?"":info.get("month").toString());
		return super.updateById(info);
	}
	
	/**
	 * 总评估或者修改总评估
	 * @param info
	 * @return
	 */
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	@EscOptionLog(module = SystemModule.performanceEvaluateConfiguration, opType = ESCLogOpType.UPDATE , table = "outsourc_performance_evaluate_configuration", option = "评估考核标题为{evaluateTitle}的人员绩效考核配置。")
	public boolean evaluate(Map info){
		info.put("submitTime", UTDate.getCurDateTime());//提交时间
		info.put("status", 1);//评估状态，未评估：0，已评估：1
		info.put("submitter", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());//提交人
		
		List<Map> performanceEvaluatorList = (List<Map>)info.get("userList");//被考核对象列表
		if(performanceEvaluatorList != null){
			//遍历修改被考核对象的考核结果
			for (Map performanceEvaluator : performanceEvaluatorList) {
				performanceEvaluator.put("evaluateTime", UTDate.getCurDateTime());//评估时间
				performanceEvaluator.put("submitTime", UTDate.getCurDateTime());//提交时间
				performanceEvaluator.put("status", 1);//评估状态
				performanceEvaluator.put("submitter", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());//提交人
				float complianceDeduction = Float.parseFloat(performanceEvaluator.get("complianceDeduction") == null ? "0" : performanceEvaluator.get("complianceDeduction").toString());
				float evaluateNum = Float.parseFloat(performanceEvaluator.get("evaluateNum") == null ? "0" : performanceEvaluator.get("evaluateNum").toString());
				float totleNum = evaluateNum - complianceDeduction;
				if (totleNum < 0f) {
					totleNum = 0f;
				}
				performanceEvaluator.put("totalNum", totleNum + "");
				performanceEvaluateUserDao.updateById(performanceEvaluator);
			}
		}
		
		
		return super.updateById(info);
	}
	
	/**
	 * 关闭
	 * @param info
	 * @return
	 */
	@EscOptionLog(module = SystemModule.performanceEvaluateConfiguration, opType = ESCLogOpType.UPDATE , table = "outsourc_performance_evaluate_configuration", option = "关闭考核标题为{evaluateTitle}的人员绩效考核配置。")
	public boolean close(Map info){
		info.put("closeTime", UTDate.getCurDateTime());//关闭时间
		info.put("status", 2);//评估状态
		userTaskService.finishTaskByBatch(info.get("id")+"");//关闭需要批量清除掉配置下所有代办任务
		return super.updateById(info);
	}
	
	@Override
	@EscOptionLog(module = SystemModule.performanceEvaluateConfiguration, opType = ESCLogOpType.DELETE ,primaryKey="id={1}", table = "outsourc_performance_evaluate_configuration", option = "删除考核标题为{evaluateTitle}的人员绩效考核配置。")
	public boolean deleteById(String id) {
//		Map param = new HashMap();
//		param.put("accessEvaluateConfigId", id);
//		//模板列表
//		List<UTMap<String, Object>> list = accessEvaluateTemplateDao.getListMaps(param);
//		if(list != null){
//			for (UTMap<String, Object> utMap : list) {
//				String accessEvaluateTemplateId = utMap.get("id") + "";
//				Map info = new HashMap();
//				info.put("accessEvaluateTemplateId", accessEvaluateTemplateId);//准入评估配置模板id
//				accessEvaluateDao.delete(info);
//				templateConfigurationDetailDeputyDao.delete(info);
//				accessEvaluateTemplateDao.deleteByIds(accessEvaluateTemplateId);
//			}
//		}
		Map param = new HashMap();
		param.put("performanceEvaluateConfigId", id);
		performanceEvaluateUserDao.delete(param);
		param = new HashMap();
		param.put("moduleTemplateConfigurationId", id);
		templateConfigurationDetailDeputyDao.delete(param);//先删除模板副表对应的数据
		userTaskService.deleteByBatch(id);//删除需要批量清除掉配置下所有代办任务
		deleteSubData(id);
		return super.deleteById(id);
	}
	
	/**
	 * @param paramType 参数类型
	 * @param data 参数值
	 * @return 参数名称
	 */
	private String vaule2Name(String paramType ,String data){
		Map<String, String> value2NameMap = new HashMap<String, String>();
		List<UTMap<String, Object>> paramList = paramDao.getValuesByType(paramType);
		for (UTMap<String, Object> param : paramList) {
			String name = (String) param.get("name");
			String value = (String) param.get("value");
			value2NameMap.put(value, name);
		}
		return value2NameMap.get(data);
	}
	
	private void addSubData(String id, String performanceEvaluator, List templateList,String evaluateTitle,String year,String unit,String half,String quarter,String month){
		if(templateList != null){
			String title = "外包人员绩效考核";
			String content ;
			Map<String, List<Map<String, Object>>> projectInfoEvaluator = new HashMap<String, List<Map<String, Object>>>();
			String[] performanceEvaluatorArr = performanceEvaluator.split(",");
			for (String userId : performanceEvaluatorArr) {
				List<UTMap<String, Object>> projectInfos = supplierEmpService.getProjectInfoByUserId(userId);
				for (UTMap<String, Object> projectInfo : projectInfos) {
					Map<String, Object> info = new HashMap<String, Object>();
					info.put("userId", userId);
					info.put("businessOwner", projectInfo.get("businessOwner"));
					info.put("technicalOwner", projectInfo.get("technicalOwner"));
					String projectInfoId = (String) projectInfo.get("id");
					if (projectInfoEvaluator.containsKey(projectInfoId)) {
						List<Map<String, Object>> userInfo = projectInfoEvaluator.get(projectInfoId);
						userInfo.add(info);
						projectInfoEvaluator.put(projectInfoId, userInfo);
					}else {
						List<Map<String, Object>> userInfo = new ArrayList<Map<String, Object>>();
						userInfo.add(info);
						projectInfoEvaluator.put(projectInfoId, userInfo);
					}
				}
			}
			
			for (Object object : templateList) {
				Map map = (Map)object;
				String templateConfigurationId = map.get("templateConfigurationId")==null?null:map.get("templateConfigurationId").toString();//原始模板id
				String evaluateBeginDate = map.get("evaluateBeginDate")+"";//过程评估开始日期
				String taskBeginDate = "" ;
				
				//如果过程评估开始日期在当天之前则待办任务开始日期显示为当天
				if(UTDate.parseDate(evaluateBeginDate).before(new Date())){
					taskBeginDate = UTDate.getCurDate();
				}else{
					taskBeginDate = evaluateBeginDate;
				}
				String evaluateName = map.get("evaluateName")+"";//过程评估标题
				
				if(StringUtils.isEmpty(month)){
					content = year+"年外包人员考核的【"+evaluateTitle+"】下的过程考核【"+evaluateName+"】待您评估";
				}else{
					content = year+"年"+month+"月份外包人员考核的【"+evaluateTitle+"】下的过程考核【"+evaluateName+"】待您评估";
				}
				
				if(StringUtils.equals("year", unit)){ //考核单位是“年”
					content = year + "年外包人员考核的【" + evaluateTitle + "】下的过程考核【" + evaluateName + "】待您评估";
				}
				else if(StringUtils.equals("half", unit)){ //考核单位是“半年”
					content = year + "年" + vaule2Name("half",half) + "外包人员考核的【" + evaluateTitle + "】下的过程考核【" + evaluateName + "】待您评估";
				}
				else if(StringUtils.equals("quarter", unit)){ //考核单位是“季度”
					content = year + "年" + vaule2Name("quarter",quarter) + "外包人员考核的【" + evaluateTitle + "】下的过程考核【" + evaluateName + "】待您评估";
				}
				else{ //考核单位是“月”
					content = year + "年" + month + "月份外包人员考核的【" + evaluateTitle + "】下的过程考核【" + evaluateName + "】待您评估";
				}
				map.put("performanceEvaluateConfigId", id);//外包绩效考核配置id
				map.put("id", null);
				performanceEvaluateTemplateDao.add(map);
				String performanceEvaluateTemplateId = map.get("id") + "";
				//初始化评估模板详情副表数据
				templateConfigurationDetailDeputyDao.initDataByTemplateConfigurationId(templateConfigurationId, performanceEvaluateTemplateId);
				String evaluatorId = ""; 
				
				Set<String> userSet = new HashSet<String>();
				for (String projectInfoId : projectInfoEvaluator.keySet()) {
					if (StringUtils.equals(evaluateName, "业务绩效考核")) {
						evaluatorId = (String) projectInfoEvaluator.get(projectInfoId).get(0).get("businessOwner");
					}else {
						evaluatorId = (String) projectInfoEvaluator.get(projectInfoId).get(0).get("technicalOwner");
					}
					Map evaluateMap = new HashMap();
					evaluateMap.put("performanceEvaluateTemplateId", performanceEvaluateTemplateId);//评估模板id
					evaluateMap.put("performanceEvaluator", performanceEvaluator);//被考核对象
					evaluateMap.put("evaluator", evaluatorId);//评估人
					evaluateMap.put("performanceEvaluateConfigId", id);//外包绩效考核配置id
					evaluateMap.put("status", 0);//状态
					evaluateMap.put("projectInfoId", projectInfoId);
					performanceEvaluateDao.add(evaluateMap);
					
					String performanceEvaluateId = evaluateMap.get("id")+"";//过程评估编号
					
					for (Map<String, Object> userInfo : projectInfoEvaluator.get(projectInfoId)) {
						
						Map evaluateUserMap = new HashMap();
						evaluateUserMap.put("performanceEvaluateTemplateId", performanceEvaluateTemplateId);//评估模板id
						evaluateUserMap.put("performanceEvaluator", userInfo.get("userId"));//被考核对象
						evaluateUserMap.put("performanceEvaluateConfigId", id);//外包绩效考核配置id
						evaluateUserMap.put("status", 0);//状态
						evaluateUserMap.put("templateEdit", 0);//是否已经填写模板（0：否，1：是）
						evaluateUserMap.put("performanceEvaluateId", performanceEvaluateId);//过程评估编号
						evaluateUserMap.put("type", 2);//评估数据类型。1：结果评估，2：过程评估
						evaluateUserMap.put("projectInfoId", projectInfoId);
						performanceEvaluateUserDao.add(evaluateUserMap);
					}
					userSet.add(evaluatorId);
					userTaskService.addTaskByUserId(content, performanceEvaluateId, title, TaskModel.performanceEvaluate, evaluatorId, taskBeginDate, id);
				}
				//判断beginDate是否在当前时间之前，如果是则马上发送提醒消息，否则通过定时任务检测来发送提醒消息
				if(!UTDate.dateCompare(UTDate.getCurDate(), evaluateBeginDate, UTDate.DATE_FORMAT)){
					sendMessage(evaluateTitle,evaluateName, CommonUtils.hashSetToString(userSet),year,unit,half,quarter,month);
				}
			}
		}
	}
	
	/*private void addSubData(String id, String performanceEvaluator, List templateList,String evaluateTitle,String year,String unit,String half,String quarter,String month){
		if(templateList != null){
			String title = "外包人员绩效考核";
			String content ;
			for (Object object : templateList) {
				Map map = (Map)object;
				String isSingle = map.get("isSingle")+"";//是否单一数据，1：是，0：否，默认否
				String templateConfigurationId = map.get("templateConfigurationId")==null?null:map.get("templateConfigurationId").toString();//原始模板id
				String evaluateBeginDate = map.get("evaluateBeginDate")+"";//过程评估开始日期
				String taskBeginDate = "" ;
				
				//如果过程评估开始日期在当天之前则待办任务开始日期显示为当天
				if(UTDate.parseDate(evaluateBeginDate).before(new Date())){
					taskBeginDate = UTDate.getCurDate();
				}else{
					taskBeginDate = evaluateBeginDate;
				}
				String evaluateName = map.get("evaluateName")+"";//过程评估标题
				
				if(StringUtils.isEmpty(month)){
					content = year+"年外包人员考核的【"+evaluateTitle+"】下的过程考核【"+evaluateName+"】待您评估";
				}else{
					content = year+"年"+month+"月份外包人员考核的【"+evaluateTitle+"】下的过程考核【"+evaluateName+"】待您评估";
				}
				
				if(StringUtils.equals("year", unit)){ //考核单位是“年”
					content = year + "年外包人员考核的【" + evaluateTitle + "】下的过程考核【" + evaluateName + "】待您评估";
				}
				else if(StringUtils.equals("half", unit)){ //考核单位是“半年”
					content = year + "年" + vaule2Name("half",half) + "外包人员考核的【" + evaluateTitle + "】下的过程考核【" + evaluateName + "】待您评估";
				}
				else if(StringUtils.equals("quarter", unit)){ //考核单位是“季度”
					content = year + "年" + vaule2Name("quarter",quarter) + "外包人员考核的【" + evaluateTitle + "】下的过程考核【" + evaluateName + "】待您评估";
				}
				else{ //考核单位是“月”
					content = year + "年" + month + "月份外包人员考核的【" + evaluateTitle + "】下的过程考核【" + evaluateName + "】待您评估";
				}
				
				map.put("performanceEvaluateConfigId", id);//外包绩效考核配置id
				map.put("id", null);
				performanceEvaluateTemplateDao.add(map);
				String performanceEvaluateTemplateId = map.get("id") + "";
				//初始化评估模板详情副表数据
				templateConfigurationDetailDeputyDao.initDataByTemplateConfigurationId(templateConfigurationId, performanceEvaluateTemplateId);
				String performanceEvaluatorType = map.get("performanceEvaluatorType") + "";//考核对象类别（1：个人，2：角色。3：岗位）
				Set<String> userSet = new HashSet<String>();
				if("1".equals(performanceEvaluatorType)){//个人
					//评估人列表
					String evaluator = map.get("evaluator") + "";
					if(StringUtils.isNotEmpty(evaluator)){
						String[] evaluatorArr = evaluator.split(",");
						if("1".equals(isSingle)){//是单一数据
							Map evaluateMap = new HashMap();
							evaluateMap.put("performanceEvaluateTemplateId", performanceEvaluateTemplateId);//评估模板id
							evaluateMap.put("performanceEvaluator", performanceEvaluator);//被考核对象
							evaluateMap.put("evaluator", evaluator);//评估人
							evaluateMap.put("performanceEvaluateConfigId", id);//外包绩效考核配置id
							evaluateMap.put("status", 0);//状态
							performanceEvaluateDao.add(evaluateMap);
							String performanceEvaluateId = evaluateMap.get("id")+"";//过程评估编号
							String[] performanceEvaluatorArr = performanceEvaluator.split(",");//被考核人用户编号
							for (String userId : performanceEvaluatorArr) {
								Map evaluateUserMap = new HashMap();
								evaluateUserMap.put("performanceEvaluateTemplateId", performanceEvaluateTemplateId);//评估模板id
								evaluateUserMap.put("performanceEvaluator", userId);//被考核对象
//								evaluateUserMap.put("evaluator", evaluatorId);//评估人
								evaluateUserMap.put("performanceEvaluateConfigId", id);//外包绩效考核配置id
								evaluateUserMap.put("status", 0);//状态
								evaluateUserMap.put("templateEdit", 0);//是否已经填写模板（0：否，1：是）
								evaluateUserMap.put("performanceEvaluateId", performanceEvaluateId);//过程评估编号
								evaluateUserMap.put("type", 2);//评估数据类型。1：结果评估，2：过程评估
								performanceEvaluateUserDao.add(evaluateUserMap);
							}
							//代办任务
							for (String evaluatorId : evaluatorArr) {
								userSet.add(evaluatorId);
								userTaskService.addTaskByUserId(content, performanceEvaluateId, title, TaskModel.performanceEvaluate, evaluatorId, taskBeginDate, id);
							}
						}else{
							//根据评估人初始化准入评估表的数据,不是单一数据每个人都生成一条数据
							for (String evaluatorId : evaluatorArr) {
								userSet.add(evaluatorId);
								Map evaluateMap = new HashMap();
								evaluateMap.put("performanceEvaluateTemplateId", performanceEvaluateTemplateId);//评估模板id
								evaluateMap.put("performanceEvaluator", performanceEvaluator);//被考核对象
								evaluateMap.put("evaluator", evaluatorId);//评估人
								evaluateMap.put("performanceEvaluateConfigId", id);//外包绩效考核配置id
								evaluateMap.put("status", 0);//状态
								performanceEvaluateDao.add(evaluateMap);
								String performanceEvaluateId = evaluateMap.get("id")+"";//过程评估编号
								userTaskService.addTaskByUserId(content, performanceEvaluateId, title, TaskModel.performanceEvaluate, evaluatorId, taskBeginDate, id);
								String[] performanceEvaluatorArr = performanceEvaluator.split(",");//被考核人用户编号
								for (String userId : performanceEvaluatorArr) {
									Map evaluateUserMap = new HashMap();
									evaluateUserMap.put("performanceEvaluateTemplateId", performanceEvaluateTemplateId);//评估模板id
									evaluateUserMap.put("performanceEvaluator", userId);//被考核对象
									evaluateUserMap.put("evaluator", evaluatorId);//评估人
									evaluateUserMap.put("performanceEvaluateConfigId", id);//外包绩效考核配置id
									evaluateUserMap.put("status", 0);//状态
									evaluateUserMap.put("templateEdit", 0);//是否已经填写模板（0：否，1：是）
									evaluateUserMap.put("performanceEvaluateId", performanceEvaluateId);//过程评估编号
									evaluateUserMap.put("type", 2);//评估数据类型。1：结果评估，2：过程评估
									performanceEvaluateUserDao.add(evaluateUserMap);
								}
							}
						}
						
					}
					
				} else if("2".equals(performanceEvaluatorType)){//角色
					String roleId = map.get("roleId")+"";//原始模板id
					List<UTMap<String, Object>> users = sysUserService.getUsersByRoleId(roleId);
					if(users != null && !users.isEmpty()){
						if("1".equals(isSingle)){//是单一数据
							String evaluatorId = "";
							for (UTMap<String, Object> utMap : users) {
								evaluatorId += utMap.get("id")+",";
							}
							if(evaluatorId.length() > 0 ){
								evaluatorId = evaluatorId.substring(0,evaluatorId.length()-1);
							}
							
							Map evaluateMap = new HashMap();
							evaluateMap.put("performanceEvaluateTemplateId", performanceEvaluateTemplateId);//评估模板id
							evaluateMap.put("performanceEvaluator", performanceEvaluator);//被考核对象
							evaluateMap.put("evaluator", evaluatorId);//评估人
							evaluateMap.put("performanceEvaluateConfigId", id);//外包绩效考核配置id
							evaluateMap.put("status", 0);//状态
							performanceEvaluateDao.add(evaluateMap);
							String performanceEvaluateId = evaluateMap.get("id")+"";//过程评估编号
							
							String[] performanceEvaluatorArr = performanceEvaluator.split(",");//被考核人用户编号
							for (String userId : performanceEvaluatorArr) {
								Map evaluateUserMap = new HashMap();
								evaluateUserMap.put("performanceEvaluateTemplateId", performanceEvaluateTemplateId);//评估模板id
								evaluateUserMap.put("performanceEvaluator", userId);//被考核对象
//								evaluateUserMap.put("evaluator", utMap.get("id"));//评估人
								evaluateUserMap.put("performanceEvaluateConfigId", id);//外包绩效考核配置id
								evaluateUserMap.put("status", 0);//状态
								evaluateUserMap.put("templateEdit", 0);//是否已经填写模板（0：否，1：是）
								evaluateUserMap.put("performanceEvaluateId", performanceEvaluateId);//过程评估编号
								evaluateUserMap.put("type", 2);//评估数据类型。1：结果评估，2：过程评估
								performanceEvaluateUserDao.add(evaluateUserMap);
							}
							for (UTMap<String, Object> utMap : users) {
								userSet.add(utMap.get("id")+"");
								userTaskService.addTaskByUserId(content, performanceEvaluateId, title, TaskModel.performanceEvaluate, utMap.get("id")+"", taskBeginDate, id);
							}
						}else{
							for (UTMap<String, Object> utMap : users) {
								userSet.add(utMap.get("id")+"");
								Map evaluateMap = new HashMap();
								evaluateMap.put("performanceEvaluateTemplateId", performanceEvaluateTemplateId);//评估模板id
								evaluateMap.put("performanceEvaluator", performanceEvaluator);//被考核对象
								evaluateMap.put("evaluator", utMap.get("id"));//评估人
								evaluateMap.put("performanceEvaluateConfigId", id);//外包绩效考核配置id
								evaluateMap.put("status", 0);//状态
								performanceEvaluateDao.add(evaluateMap);
								String performanceEvaluateId = evaluateMap.get("id")+"";//过程评估编号
								userTaskService.addTaskByUserId(content, performanceEvaluateId, title, TaskModel.performanceEvaluate, utMap.get("id")+"", taskBeginDate, id);
								String[] performanceEvaluatorArr = performanceEvaluator.split(",");//被考核人用户编号
								for (String userId : performanceEvaluatorArr) {
									Map evaluateUserMap = new HashMap();
									evaluateUserMap.put("performanceEvaluateTemplateId", performanceEvaluateTemplateId);//评估模板id
									evaluateUserMap.put("performanceEvaluator", userId);//被考核对象
									evaluateUserMap.put("evaluator", utMap.get("id"));//评估人
									evaluateUserMap.put("performanceEvaluateConfigId", id);//外包绩效考核配置id
									evaluateUserMap.put("status", 0);//状态
									evaluateUserMap.put("templateEdit", 0);//是否已经填写模板（0：否，1：是）
									evaluateUserMap.put("performanceEvaluateId", performanceEvaluateId);//过程评估编号
									evaluateUserMap.put("type", 2);//评估数据类型。1：结果评估，2：过程评估
									performanceEvaluateUserDao.add(evaluateUserMap);
								}
							}
						}
					}
				}  else if("3".equals(performanceEvaluatorType)){//岗位
					String roleId = map.get("roleId")+"";//原始模板id
					Map<String,String> userOrg = new HashMap<String,String>();
					String[] performanceEvaluatorArr = performanceEvaluator.split(",");//被考核人用户编号
					for (String userId : performanceEvaluatorArr) {
						UTMap<String, Object> user = sysUserService.getById(userId);
						String orgId = user.get("orgId")+"";//用户所属的组织机构
						if(StringUtils.isEmpty(orgId)){
							throw new EscServiceException(user.get("name")+"无法取到部门的数据，考核对象类别无法选择岗位来考核！");
						}
						if(userOrg.containsKey(orgId)){
							String evaluators = userOrg.get(orgId);
							evaluators = evaluators + "," + userId;
							userOrg.put(orgId, evaluators);
						}else{
							userOrg.put(orgId, userId);
						}
					}
					
					Set<String> set = userOrg.keySet();
					for (String orgId : set) {
						performanceEvaluatorArr = userOrg.get(orgId).split(",");//被考核人用户编号
						//获取组织机构下指定岗位的所有用户
						List<UTMap<String, Object>> users = sysOrgService.getOrgUser(orgId, roleId, "1", null);
						if(users != null && !users.isEmpty()){
							if("1".equals(isSingle)){//是单一数据
								String evaluatorId = "";
								for (UTMap<String, Object> user : users) {
									evaluatorId += user.get("id")+",";
								}
								if(evaluatorId.length() > 0 ){
									evaluatorId = evaluatorId.substring(0,evaluatorId.length()-1);
								}
								Map evaluateMap = new HashMap();
								evaluateMap.put("performanceEvaluateTemplateId", performanceEvaluateTemplateId);//评估模板id
								evaluateMap.put("performanceEvaluator", userOrg.get(orgId));//被考核对象
								evaluateMap.put("evaluator", evaluatorId);//评估人
								evaluateMap.put("orgId", orgId);//评估人
								evaluateMap.put("performanceEvaluateConfigId", id);//外包绩效考核配置id
								evaluateMap.put("status", 0);//状态
								performanceEvaluateDao.add(evaluateMap);
								String performanceEvaluateId = evaluateMap.get("id")+"";//过程评估编号
								
								for (String userId : performanceEvaluatorArr) {
									Map evaluateUserMap = new HashMap();
									evaluateUserMap.put("performanceEvaluateTemplateId", performanceEvaluateTemplateId);//评估模板id
									evaluateUserMap.put("performanceEvaluator", userId);//被考核对象
//									evaluateUserMap.put("evaluator", user.get("id"));//评估人
									evaluateUserMap.put("performanceEvaluateConfigId", id);//外包绩效考核配置id
									evaluateUserMap.put("status", 0);//状态
									evaluateUserMap.put("templateEdit", 0);//是否已经填写模板（0：否，1：是）
									evaluateUserMap.put("performanceEvaluateId", performanceEvaluateId);//过程评估编号
									evaluateUserMap.put("type", 2);//评估数据类型。1：结果评估，2：过程评估
									performanceEvaluateUserDao.add(evaluateUserMap);
								}
								for (UTMap<String, Object> user : users) {
									userSet.add(user.get("id")+"");
									userTaskService.addTaskByUserId(content, performanceEvaluateId, title, TaskModel.performanceEvaluate, user.get("id")+"", taskBeginDate, id);
								}
								
							}else{
								for (UTMap<String, Object> user : users) {
									userSet.add(user.get("id")+"");
									Map evaluateMap = new HashMap();
									evaluateMap.put("performanceEvaluateTemplateId", performanceEvaluateTemplateId);//评估模板id
									evaluateMap.put("performanceEvaluator", userOrg.get(orgId));//被考核对象
									evaluateMap.put("evaluator", user.get("id"));//评估人
									evaluateMap.put("orgId", orgId);//评估人
									evaluateMap.put("performanceEvaluateConfigId", id);//外包绩效考核配置id
									evaluateMap.put("status", 0);//状态
									performanceEvaluateDao.add(evaluateMap);
									String performanceEvaluateId = evaluateMap.get("id")+"";//过程评估编号
									userTaskService.addTaskByUserId(content, performanceEvaluateId, title, TaskModel.performanceEvaluate, user.get("id")+"", taskBeginDate, id);
									for (String userId : performanceEvaluatorArr) {
										Map evaluateUserMap = new HashMap();
										evaluateUserMap.put("performanceEvaluateTemplateId", performanceEvaluateTemplateId);//评估模板id
										evaluateUserMap.put("performanceEvaluator", userId);//被考核对象
										evaluateUserMap.put("evaluator", user.get("id"));//评估人
										evaluateUserMap.put("performanceEvaluateConfigId", id);//外包绩效考核配置id
										evaluateUserMap.put("status", 0);//状态
										evaluateUserMap.put("templateEdit", 0);//是否已经填写模板（0：否，1：是）
										evaluateUserMap.put("performanceEvaluateId", performanceEvaluateId);//过程评估编号
										evaluateUserMap.put("type", 2);//评估数据类型。1：结果评估，2：过程评估
										performanceEvaluateUserDao.add(evaluateUserMap);
									}
								}
							}
							
						}
					}
				} 
				//判断beginDate是否在当前时间之前，如果是则马上发送提醒消息，否则通过定时任务检测来发送提醒消息
				if(!UTDate.dateCompare(UTDate.getCurDate(), evaluateBeginDate, UTDate.DATE_FORMAT)){
					sendMessage(evaluateTitle,evaluateName, CommonUtils.hashSetToString(userSet),year,unit,half,quarter,month);
				}
			}
			//判断beginDate是否在当前时间之前，如果是则马上发送提醒消息，否则通过定时任务检测来发送提醒消息
//			if(!UTDate.dateCompare(UTDate.getCurDate(), evaluateBeginDate, UTDate.DATE_FORMAT)){
//				sendMessage(evaluateTitle, userSet,year,month);
//			}
		}
	}*/
	
	@Override
	public void sendMessage() {
		logger.info("检查发送外包人员考核消息");
		try{
			Map param = new HashMap();
			param.put("isSendMessageDate", true);
			//查询出当天需要发送消息的数据
			List<UTMap<String, Object>> accessEvaluates = performanceEvaluateDao.getListAll(param);
			if(accessEvaluates != null){
				for (UTMap<String, Object> accessEvaluate : accessEvaluates) {
					String evaluateTitle = accessEvaluate.get("evaluateTitle")+"";//评估配置标题
					String evaluateName = accessEvaluate.get("evaluateName")+"";//过程评估标题
					String evaluator = accessEvaluate.get("evaluator")+"";//评估人列表
//					sendMessage(evaluateTitle,evaluateName, evaluator,accessEvaluate.get("year")+"",accessEvaluate.get("month")==null?"":accessEvaluate.get("month").toString());
					sendMessage(evaluateTitle,evaluateName, evaluator,accessEvaluate.get("year")+"",accessEvaluate.get("unit")+"",accessEvaluate.get("half")==null?"":accessEvaluate.get("half").toString(),
							accessEvaluate.get("quarter")==null?"":accessEvaluate.get("quarter").toString(),accessEvaluate.get("month")==null?"":accessEvaluate.get("month").toString());
				}
			}
		}catch(Exception ex){
			logger.error("外包人员考核消息提醒异常",ex);
		}
	
//		try{
//			Map param = new HashMap();
//			param.put("isSendMessageDate", true);
//			//查询出当天需要发送消息的数据
//			List<UTMap<String, Object>> accessEvaluateConfigs = this.getListMaps(param);
//			if(accessEvaluateConfigs != null){
//				for (UTMap<String, Object> accessEvaluateConfig : accessEvaluateConfigs) {
//					String evaluateTitle = accessEvaluateConfig.get("evaluateTitle")+"";
//					Set<String> userSet = new HashSet<String>();
//					param.clear();
//					param.put("performanceEvaluateConfigId", accessEvaluateConfig.get("id"));
//					List<UTMap<String, Object>> accessEvaluates = performanceEvaluateDao.getListMaps(param);
//					if(accessEvaluates != null){
//						for (UTMap<String, Object> accessEvaluate : accessEvaluates) {
//							userSet.add(accessEvaluate.get("evaluator")+"");
//						}
//					}
//					sendMessage(evaluateTitle, userSet,accessEvaluateConfig.get("year")+"",accessEvaluateConfig.get("month")==null?"":accessEvaluateConfig.get("month").toString());
//				}
//			}
//		}catch(Exception ex){
//			logger.error("外包人员考核消息提醒异常",ex);
//		}
	}
	
	private void sendMessage(String evaluateTitle,String evaluateName,String userIds,String year,String unit,String half,String quarter, String month){
		String title = "外包人员考核提醒";
		String content;
		if(StringUtils.equals("year", unit)){ //考核单位是“年”
			content = year+"年外包人员考核的【"+evaluateTitle+"】下的过程考核【"+evaluateName+"】已开始，请您对相关外包人员进行考核";
		}
		else if(StringUtils.equals("half", unit)){ //考核单位是“半年”
			content = year+"年"+vaule2Name("half",half)+"外包人员考核的【"+evaluateTitle+"】下的过程考核【"+evaluateName+"】已开始，请您对相关外包人员进行考核";
		}
		else if(StringUtils.equals("quarter", unit)){ //考核单位是“季度”
			content = year+"年"+vaule2Name("quarter",quarter)+"外包人员考核的【"+evaluateTitle+"】下的过程考核【"+evaluateName+"】已开始，请您对相关外包人员进行考核";
		}
		else{ //考核单位是“月”
			content = year+"年"+month+"月份外包人员考核的【"+evaluateTitle+"】下的过程考核【"+evaluateName+"】已开始，请您对相关外包人员进行考核";
		}
		
//		String userIds = CommonUtils.hashSetToString(userSet);
		logger.info(CommonUtils.vaildLog(title+":"+userIds));
		messageService.sendMessage(userIds,title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
	}
	
	private void deleteSubData(String id){
		Map info = new HashMap();
		info.put("moduleTemplateConfigurationId", id);
		//先删除全面评估结果需要填报的模板副表数据
		templateConfigurationDetailDeputyDao.delete(info);
		Map param = new HashMap();
		param.put("performanceEvaluateConfigId", id);
		//模板列表
		List<UTMap<String, Object>> list = performanceEvaluateTemplateDao.getListMaps(param);
		if(list != null){
			for (UTMap<String, Object> utMap : list) {
				String performanceEvaluateTemplateId = utMap.get("id") + "";
				info = new HashMap();
				info.put("performanceEvaluateTemplateId", performanceEvaluateTemplateId);//准入评估配置模板id
				performanceEvaluateDao.delete(info);
				info.remove("performanceEvaluateTemplateId");
				info.put("moduleTemplateConfigurationId", performanceEvaluateTemplateId);
				templateConfigurationDetailDeputyDao.delete(info);
				performanceEvaluateTemplateDao.deleteByIds(performanceEvaluateTemplateId);
			}
		}
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map param) {
		dao.getPageInfo(pageBean, param);
	}
	

}
