package com.esc.oms.outsource.agreementManpower.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

/**
 * 人力外包合同 配置
 * @author smq
 * @date   2016-2-24 上午10:50:04
 */
public interface IAgreementManpowerInfoDao extends IBaseOptionDao {
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_AGREEMENTID = "agreementId";
	public static final String  FIELD_AGREEMENTCODE = "agreementCode";//合同编号
	public static final String  FIELD_AGREEMENTNAME = "agreementName";//合同名称
	public static final String  FIELD_DEDUCTIONSCYCLE = "deductionsCycle";//扣费周期
	public static final String  FIELD_DEDUCTIONRATE = "deductionsRate";//扣费比例
	public static final String  FIELD_TRIAPERIOD= "triaPeriod";//试用期天数
	public static final String  FIELD_AMBEGIN = "amBegin";//上午开始时间
	public static final String  FIELD_AMEND= "amEnd";//上午结束时间
	public static final String  FIELD_PMBEGIN= "pmBegin";//下午开始时间
	public static final String  FIELD_PMEND = "pmEnd";//下午结束时间
	public static final String  FIELD_OVERTIMEWEEKDAY = "overtimeWeekday";//加班折算率-工作
	public static final String  FIELD_OVERTIMEWEEKEND= "overtimeWeekEnd";//加班折算率-周末
	public static final String  FIELD_OVERTIMEHOLIDAY= "overtimeHoliday";//加班折算率-节假
	public static final String  FIELD_CREATEUSERID= "createUserId";//创建人
	public static final String  FIELD_UPDATEUSERID= "updateUserId";//更新人
	public static final String  FIELD_CREATETIME= "createTime";//创建时间
	public static final String  FIELD_UPDATETIME= "updateTime";//创建时间
	

	public static final String  FIELD_STATE= "state";//创建时间
	
	

	/**
	 * 获取 所有未进行配置的人力外包合同
	 * */
	public List<UTMap<String, Object>> getAgreementManpowerNoConfig();
	

	/**
	 *  获取 所有人力外包合同费用配置
	 * @param param
	 * @return
	 */
	public List<UTMap<String, Object>> getAgreementCostConfig(Map<String, Object> param) ;
	
	/**
	 * 根据用户编号获取外包合同
	 * @param userId
	 * @return
	 */
	public UTMap<String, Object> getByUserId(String userId);
	
}
