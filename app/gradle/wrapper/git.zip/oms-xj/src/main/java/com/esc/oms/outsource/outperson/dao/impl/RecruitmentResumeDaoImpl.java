package com.esc.oms.outsource.outperson.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.outperson.dao.IRecruitmentResumeDao;
@Repository
public class RecruitmentResumeDaoImpl extends BaseOptionDao implements IRecruitmentResumeDao{
	
	@Override
	public String getTableName() {
		return "recruitment_resume";
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params,false), pageBean, null);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	@Override
	public List<UTMap<String, Object>> getListAll(Map params) {
		return super.getListBySql(getSearchSql(params,false), null);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	@Override
	public List<UTMap<String, Object>> getListMaps(Map params) {
		return super.getListBySql(getSearchSql(params,false), null);
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params,boolean isGetById){
		StringBuilder sql = new StringBuilder();
		sql.append(" select rr.*,ids_to_name(rr.interviewUserIds) as interviewUserNames, resume.phone,resume.email,resume.seniority,resume.educationalBackground, "
				+ " supplier.name as supplierName from recruitment_resume rr ");
		sql.append(" left join recruitment_application_detail detail on rr.applyDetailId=detail.id ");
		sql.append(" left join recruitment_application ra on ra.id=detail.applyId ");
		sql.append(" left join resume_info resume on resume.id=rr.resumeId ");
		sql.append(" left join supplier_base_info supplier on resume.supplierId=supplier.id ");
		sql.append(" where 1=1 ");
		if(params!=null && params.size()>0){		
//			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
//				sql.append(" and detail.name like '%"+params.get("name").toString().trim()+"%' ");
//			}
/*			if(params.get("businessFilterResult")!=null &&  StringUtils.isNotEmpty(params.get("businessFilterResult").toString())){
				sql.append(" and rr.businessFilterResult='"+params.get("businessFilterResult").toString().trim()+"' ");
			}*/
			if(params.get("managerFilterResult")!=null &&  StringUtils.isNotEmpty(params.get("managerFilterResult").toString())){
				sql.append(" and rr.managerFilterResult='"+params.get("managerFilterResult").toString().trim()+"' ");
			}
			if(params.get("applyId")!=null && StringUtils.isNotEmpty(params.get("applyId").toString())){
				sql.append(" and rr.applyId='"+params.get("applyId").toString().trim()+"' ");
			}
			if(params.get("applyDetailId")!=null && StringUtils.isNotEmpty(params.get("applyDetailId").toString())){
				sql.append(" and rr.applyDetailId='"+params.get("applyDetailId").toString().trim()+"' ");
			}
			if(params.get("supplierId")!=null && StringUtils.isNotEmpty(params.get("supplierId").toString())){
				sql.append(" and rr.supplierId='"+params.get("supplierId").toString().trim()+"' ");
			}
			if(params.get("idCode")!=null && StringUtils.isNotEmpty(params.get("idCode").toString())){
				sql.append(" and rr.idCode='"+params.get("idCode").toString().trim()+"' ");
			}
			if(params.get("interviewResult")!=null && StringUtils.isNotEmpty(params.get("interviewResult").toString())){
				sql.append(" and rr.interviewResult='"+params.get("interviewResult").toString().trim()+"' ");
			}
			
			if(params.get("projectId")!=null && StringUtils.isNotEmpty(params.get("projectId").toString())){
				sql.append(" and ra.projectId='"+params.get("projectId").toString().trim()+"' ");
			}
//			if(params.get("startDate")!=null && StringUtils.isNotEmpty(params.get("startDate").toString())){
//				sql.append(" and DATE_FORMAT(detail.createTime,'%Y-%m-%d')>='"+params.get("startDate").toString().trim()+"' ");
//			}
//			if(params.get("endDate")!=null && StringUtils.isNotEmpty(params.get("endDate").toString())){
//				sql.append(" and DATE_FORMAT(detail.createTime,'%Y-%m-%d')<='"+params.get("endDate").toString().trim()+"' ");
//			}
		}
		//数据权限控制		
		if(!"1".equals(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserType())){//供应商用户。只能查看本供应商推荐的简历
			String supplierId = EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId();
			sql.append(" and rr.supplierId='"+supplierId+"' ");
		}
		
		sql.append(" order by detail.createTime desc");
		return  sql.toString();
	}

	@Override
	public List<UTMap<String, Object>> getListAllByParentParam(Map params) {
		return super.getListBySql(getSearchSqlByParentParam(params), null);
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSqlByParentParam(Map params){
		StringBuilder sql = new StringBuilder();
		sql.append(" select detail.*, org.name as orgName, org.longName as departmentName from recruitment_application_detail detail ");
		sql.append(" left join recruitment_application apply on detail.applyId=apply.id ");
		sql.append(" left join sys_org org on org.id= detail.departmentId ");
		sql.append(" where 1=1 ");
		if(params!=null && params.size()>0){		
			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
				sql.append(" and apply.name like '%"+params.get("name").toString().trim()+"%' ");
			}
//			if(params.get("startDate")!=null && StringUtils.isNotEmpty(params.get("startDate").toString())){
//				sql.append(" and apply.applyTime>='"+params.get("startDate").toString().trim()+"' ");
//			}
//			if(params.get("endDate")!=null && StringUtils.isNotEmpty(params.get("endDate").toString())){
//				sql.append(" and apply.applyTime<='"+params.get("endDate").toString().trim()+"' ");
//			}
		}
		sql.append(" order by apply.createTime desc");
		return  sql.toString();
	}

	@Override
	public List<UTMap<String, Object>> getInterviewByInfo(Map<String, Object> info) {
		// TODO Auto-generated method stub
		StringBuilder sql = new StringBuilder();
		sql.append(" select ri.id,ri.recruitmentResumeId, ri.templateConfigurationId,CONCAT(stc.name , ' ' , stc.versions) as templateConfigurationName, ri.interviewUserId, ");
		sql.append(" CONCAT(su.name , '/' , su.code) as interviewUserName, ri.interviewDate, ri.interviewResult, ri.interviewRemark ");
		sql.append(" from recruitment_interview ri ");
		sql.append(" left join sys_user su on su.id = ri.interviewUserId ");
		sql.append(" left join sys_template_configuration stc on ri.templateConfigurationId = stc.id ");
		sql.append(" where 1=1 ");
		if (null != info && !info.isEmpty()) {
			String recruitmentResumeId = (String) info.get("recruitmentResumeId");
			if (StringUtils.isNotEmpty(recruitmentResumeId)) {
				sql.append(" and ri.recruitmentResumeId='" + recruitmentResumeId + "' ");
			}
		}
		return super.getListBySql(sql.toString(), null);
	}

	@Override
	public boolean addInterview(Map<String, Object> info) {
		return super.saveBySql("recruitment_interview", info);
	}

	@Override
	public boolean removeInterview(String id) {
		return super.deleteByIds("recruitment_interview", id);
	}

	@Override
	public void getPageInfoForInterview(UTPageBean pageBean, Map<String, Object> params) {
		super.getPageListMapBySql(getPageInfoForInterviewSql(params), pageBean, null);
	}
	
	private String getPageInfoForInterviewSql (Map<String, Object> params) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select rs.id, rs.name, rs.idCode, rs.resumeId, rs.applyId, ");
		sql.append(" rs.applyCode,rs.applyDetailId,rs.supplierId, rs.recUserId, rs.recTime, ");
		sql.append(" rs.status, rs.managerFilterResult, rs.businessFilterResult, rs.isArrival,rs.interviewResult,rs.arrivalDate, ");
		sql.append(" ra.name applicationName,ra.code applicationCode,ra.status applicaitonStatus,sbi.name supplierName, ");
		sql.append(" rad.category, rad.level, rad.remark,ri.id interviewId,ri.interviewStatus,ri.interviewResult as 'score',rs.level as 'totalLevel' ");
		sql.append(" from recruitment_resume rs ");
		sql.append(" left join recruitment_application ra on ra.id = rs.applyId ");
		sql.append(" left join recruitment_application_detail rad on rad.id = rs.applyDetailId ");
		sql.append(" left join supplier_base_info sbi on sbi.id = rs.supplierId ");
		sql.append(" left join recruitment_interview ri on ri.recruitmentResumeId=rs.id ");
		sql.append(" where 1=1 ");
		sql.append(" and rs.managerFilterResult='1' ");//管理员审核通过的简历
		sql.append(" and rs.status='3' ");//简历在预约面试
		sql.append(" and ra.status='6' ");//申请单状态在处理中
		sql.append(" and rad.status='2' ");//人力需求状态在处理中
		sql.append(" and ri.interviewUserId='" + EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId() + "' ");//面试人为当前用户
		if (null != params && !params.isEmpty()) {
			String name = (String) params.get("name");
			if (StringUtils.isNotEmpty(name)) {
				sql.append(" and rs.name like '%" + name + "%' ");
			}
			
			String category = (String) params.get("category");
			if (StringUtils.isNotEmpty(category)) {
				sql.append(" and rad.category like '%" + category + "%' ");
			}
		}
		
		sql.append(" order by ri.interviewStatus asc, ra.name ");
		return sql.toString();
	}

	@Override
	public boolean updateGradeResult(Map<String, Object> info) {
		// TODO Auto-generated method stub
		return super.updateById("recruitment_interview", info);
	}

	@Override
	public UTMap<String, Object> getInterviewById(String id) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select ri.id,ri.recruitmentResumeId, ri.templateConfigurationId,CONCAT(stc.name , ' ' , stc.versions) as templateConfigurationName, ri.interviewUserId, ");
		sql.append(" CONCAT(su.name , '/' , su.code) as interviewUserName, ri.interviewDate, ri.interviewResult, ri.interviewRemark ");
		sql.append(" from recruitment_interview ri ");
		sql.append(" left join sys_user su on su.id = ri.interviewUserId ");
		sql.append(" left join sys_template_configuration stc on ri.templateConfigurationId = stc.id ");
		sql.append(" where 1=1 and ri.id='" + id + "' ");
		List<UTMap<String, Object>> list = super.getListBySql(sql.toString(), null);
		if (null != list && !list.isEmpty()) {
			return list.get(0);
		}
		return null;
	}

	@Override
	public void updateInterview(UTMap<String, Object> item) {
		super.updateById("recruitment_interview", item);
	}

}
