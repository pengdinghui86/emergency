package com.esc.oms.outsource.external.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

/**
 * 非驻场外包评估Dao
 * @author owner
 *
 */
public interface IExternalEvaluateDao extends IBaseOptionDao{
	public static final String  FIELD_ID= "id";
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params);
	
}
