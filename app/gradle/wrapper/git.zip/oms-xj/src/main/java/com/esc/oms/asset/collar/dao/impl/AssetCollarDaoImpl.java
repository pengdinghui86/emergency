package com.esc.oms.asset.collar.dao.impl;

import com.esc.oms.asset.collar.dao.IAssetCollarDao;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.RoleUtils;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Repository
public class AssetCollarDaoImpl extends BaseOptionDao implements IAssetCollarDao{
	
	private String collarDetailTableName = "assets_material_recept_detail";

	@Override
	public String getTableName() {
		return "assets_material_recept";
	}
	
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params), pageBean, null);
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT amr.title, amr.id,ami.`codeNum` assetsCode,ami.`name` assetsName,amc.`name` assetsType,amsc.`name` assetsSubType,amr.createUserId,amr.assetsId ," );
		sql.append(" ami.brand assetsBrand,ami.model assetsModel,amr.receptType,concat(su.`name`,'/',su.`code`)  receptUserId,amr.receptTime,amr.`status`,amr.receptUserId receptUser ");
		sql.append(" FROM assets_material_recept amr ");
		sql.append(" LEFT JOIN assets_material_info ami ON ami.id = amr.assetsId ");
		sql.append(" LEFT JOIN assets_material_category amc ON amc.id = ami.category ");
		sql.append(" LEFT JOIN assets_material_sub_category amsc ON amsc.id = ami.subCategory ");
		sql.append(" LEFT JOIN sys_user su ON su.id = amr.receptUserId ");
		sql.append(" WHERE 1=1 ");
		if(params!=null && params.size()>0){
			if(params.get("status")!=null && StringUtils.isNotEmpty(params.get("status").toString())){
				sql.append(" and amr.status = '"+params.get("status").toString().trim()+"'");
			}
		}
		if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR,RoleUtils.ASSET_MANAGER)){
			sql.append(" and (amr.receptUserId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' or amr.createUserId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' )");//非研发用户只能查询自己的数据，研发用户查询所有数据方便调试
		}
		sql.append(" order by amr.createTime desc");
		return  sql.toString();
	}
	
	
	private String getAssetByAssetIdSql(String assetId){
		StringBuilder sql=new StringBuilder();
		//sql.append(" SELECT if(ami.serialNum<> '', concat(ami.name, '/',))ami.name assetsName ");
		sql.append(" SELECT ami.name assetsName,ami.`codeNum` assetsCode,amc.`name` assetsType,amsc.`name` assetsSubType,ap.`name` assetsLocation,"
				 + " ami.brand assetsBrand,ami.model assetsModel,aai.supplierName supplierId,aai.agreementName maintainContract,concat(ami.`name`,IF ( ami.serialNum IS NULL OR ami.serialNum = '', '', concat('/', ami.serialNum))) assetsNameCode ," );
		sql.append(" aai2.agreementName buyContractName, aai2.supplierName buyContractSupplier,ami.maintainContract maintainContractId,group_concat(aai3.agreementName) maintainContractAll");
		sql.append(" FROM assets_material_info ami ");
		sql.append(" LEFT JOIN assets_material_category amc ON amc.id = ami.category ");
		sql.append(" LEFT JOIN assets_material_sub_category amsc ON amsc.id = ami.subCategory ");
		sql.append(" LEFT JOIN assets_place ap ON ap.id = ami.location ");
		sql.append(" LEFT JOIN assets_agreement_info aai ON aai.id = ami.maintainContract ");
		sql.append(" LEFT JOIN assets_agreement_info aai2 on aai2.id = ami.buyContract ");
		sql.append(" LEFT JOIN assets_agreement_info aai3 on find_in_set(aai3.id, ami.maintainContract) ");
		sql.append(" WHERE ami.id = '"+assetId+"'");
		return  sql.toString();
	}
	


	@Override
	public UTMap<String, Object> getAssetByAssetId(String assetId) {
		return super.getOneBySql(getAssetByAssetIdSql(assetId),null);
	}

	private String getCollarByIdSql(String id){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT amr.id,amr.title,ami.`codeNum` assetsCode,ami.`name` assetsName,amc.`name` assetsType,amsc.`name` assetsSubType,ap.`name` assetsLocation,concat(su2.`name`,'/',su2.`code`) receptUserName,concat(su.`name`,'/',su.`code`)grantUserName, " );
		sql.append(" ami.brand assetsBrand,ami.model assetsModel,amr.receptType,amr.receptUserId,amr.receptTime,amr.`status`,amr.grantUserId,amr.assetsId,amr.receptDes ");
		sql.append(" FROM assets_material_recept amr ");
		sql.append(" LEFT JOIN assets_material_info ami ON ami.id = amr.assetsId ");
		sql.append(" LEFT JOIN assets_material_category amc ON amc.id = ami.category ");
		sql.append(" LEFT JOIN assets_material_sub_category amsc ON amsc.id = ami.subCategory ");
		sql.append(" LEFT JOIN assets_place ap ON ap.id = ami.location ");
		sql.append(" LEFT JOIN sys_user su ON su.id = amr.grantUserId ");
		sql.append(" LEFT JOIN sys_user su2 ON su2.id = amr.receptUserId ");
		sql.append(" WHERE amr.id = '"+id+"'");
		return  sql.toString();
	}

	@Override
	public UTMap<String, Object> getCollarById(String id) {
		return super.getOneBySql(getCollarByIdSql(id),null);
	}


	@Override
	public List<UTMap<String, Object>> getCollarList(Map param) {
		return super.getListBySql(getSearchSql(param));
	}


	@Override
	public UTMap<String, Object> getCollarByStatusList(String assetId) {
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT amr.id FROM assets_material_recept amr "
//				 + " LEFT JOIN assets_material_info ami ON ami.id = amr.assetsId "
				 + " WHERE  amr.assetsId = '"+assetId+"'"
				 + " AND amr.`status` = 'DQR' ");
		return super.getOneBySql(sql.toString());
	}


	@Override
	public List<UTMap<String, Object>> getAssetsList(Map<String, Object> param) {
		// TODO Auto-generated method stub
		return super.getListBySql(this.getAssetsListSql(param), null);
	}

	private String getAssetsListSql(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT ami.id,ami.sn,ami.`name`,ami.`code`,ami.codeNum,ami.category,amc.`name` categoryName,amsc.`name` subCategoryName,so.`longName` resDepartId,");
//		sql.append(" IF(ami.auxiliaryAsset='1',concat(concat('(主)','',ami.`name`), IF ( ami.serialNum IS NULL OR ami.serialNum = '', '', concat('/', ami.serialNum)))," );
//		sql.append("concat( concat('(辅)', '', ami.`name`), IF ( ami.codeNum IS NULL OR ami.codeNum = '', '', concat('/', ami.codeNum)))) assetsNameCode," );
		sql.append(" IF(ami.auxiliaryAsset='1',concat('(主)','',ami.`name`)," );
		sql.append("concat('(辅)', '', ami.`name`)) assetsNameCode," );
		sql.append(" ami.status,ami.assetPrice,ami.registStatus, ami.serialNum,ami.userId,ami.brand,ami.model," );
		sql.append(" ami.salvage,ami.useYears,ami.inboundDate,ami.confidentiality, ");
		sql.append(" ami.maintAssetStartDate,ami.maintAssetsEndDate,ami.remark,ami.systemClass,ami.assetsLevel,");
		sql.append(" ami.assetStartDate,ami.assetEndDate,aai.supplierName assetSupplierName,ami.controllable,ami.otherMaint,");
		sql.append(" ami.auxiliaryAsset,ami.ownSystem,ami.producer,ami.integrity,ami.availability,ami.hasBackup,ami.totalAssets,ami.outdate, ");
		sql.append(" ami.assetsUse, ami.assetStatus, ami.assetsCosts, ami.preAssetsClass, ");
		sql.append(" ami.ip, ami.EquipmentUse, ami.isPositive, ami.assetAttributes, ami.systemName, ami.MaintenanceAmount,");
		sql.append(" ami.CabinetStartU, ami.CabinetEndU, ami.businessSystemLeader, ami.EquipmentLeader,ami.assetsType,");
		sql.append(" aai.agreementName buyContract,aai2.agreementName maintainContract,concat(su.`name`, '/', su.`code`) resUserName,");
		sql.append(" ap.`name` location,ami.resUserId resUser,ifnull(ami.isScrap,'0') isScrap,");
		sql.append(" so.`name` resDepartName,aai.agreementName buyContractName,");
		sql.append(" aai2.agreementName maintainContractName,(to_days(ami.maintAssetsEndDate)-to_days(now())) maintAssetsLeftNum,");
		sql.append( " aai2.supplierName maintSupplierName,(to_days(ami.assetEndDate)-to_days(now())) assetsLeftTime,");
		sql.append(" su2.name businessSystemLeaderName,su3.name  EquipmentLeaderName ");
		sql.append(" FROM assets_material_info ami ");
		sql.append(" LEFT JOIN assets_material_category amc ON amc.id = ami.category ");
		sql.append(" LEFT JOIN assets_material_category amsc ON amsc.id = ami.subCategory ");
		sql.append(" LEFT JOIN sys_user su ON su.id = ami.resUserId ");
		sql.append(" LEFT JOIN sys_user su2 on su2.id = ami.businessSystemLeader ");
		sql.append(" LEFT JOIN sys_user su3 on su3.id = ami.EquipmentLeader ");
		sql.append(" LEFT JOIN sys_org so ON so.id = ami.resDepartId ");
		sql.append(" LEFT JOIN assets_place ap ON ap.id = ami.location ");
		sql.append(" LEFT JOIN assets_agreement_info aai ON ami.buyContract = aai.id ");
		sql.append(" LEFT JOIN assets_agreement_info aai2 ON aai2.id = ami.maintainContract ");
		sql.append(" WHERE 1=1 ");
		sql.append(" AND (ami.deleteFlag != 1 OR ami.deleteFlag IS NULL) ");
//		sql.append(" AND ifnull(ami.isScrap,'0') <> '1'");
		if(params!=null && params.size()>0){
			if(params.get("category")!=null && CommonUtils.notNullStrOrEmpty(params.get("category").toString())){
				sql.append(" AND amc.id = '"+params.get("category").toString().trim()+"'");
			}
			if(params.get("subCategory")!=null && CommonUtils.notNullStrOrEmpty(params.get("subCategory").toString())){
				sql.append(" AND amsc.id = '"+params.get("subCategory").toString().trim()+"'");
			}
			if(params.get("agreementId")!=null && CommonUtils.notNullStrOrEmpty(params.get("agreementId").toString())){ //资产合同--资产视图
				sql.append(" AND (ami.buyContract = '"+params.get("agreementId").toString().trim()+"' "
						+ "or ami.maintainContract = '"+params.get("agreementId").toString().trim()+"')");
			}
			if(params.get("name")!=null && CommonUtils.notNullStrOrEmpty(params.get("name").toString())){ //资产合同--资产视图
				sql.append(" AND ami.name like '%"+params.get("name").toString().trim()+"%'");
			}
			if(params.get("codeNum")!=null && CommonUtils.notNullStrOrEmpty(params.get("codeNum").toString())){
				sql.append(" AND (ami.codeNum like '%"+params.get("codeNum").toString().trim()+"%' OR ami.serialNum like '%"+params.get("codeNum").toString().trim()+"%')");
			}
			if(params.get("resUserId")!=null && CommonUtils.notNullStrOrEmpty(params.get("resUserId").toString())){
//				sql.append(" and (su.name like '%"+params.get("resUserId").toString().trim()+"%' or su.code like '%"+params.get("resUserId").toString().trim()+"%')");
				sql.append(" and CONCAT(su.name,'/',su.code) like '%"+params.get("resUserId").toString().trim()+"%' ");
			}
			if(params.get("resDepartId")!=null && CommonUtils.notNullStrOrEmpty(params.get("resDepartId").toString())){
				sql.append(" AND ami.resDepartId = '"+params.get("resDepartId").toString().trim()+"'");
			}
			if(params.get("resDepartLongName")!=null && CommonUtils.notNullStrOrEmpty(params.get("resDepartLongName").toString())){
				sql.append(" AND so.`longName` like '%"+params.get("resDepartLongName").toString().trim()+"%'");
			}
			if(params.get("isScrap")!=null && CommonUtils.notNullStrOrEmpty(params.get("isScrap").toString())){
				sql.append(" AND ifnull(ami.isScrap,'0') = '"+params.get("isScrap").toString().trim()+"'");
			}else{
//				sql.append(" AND ifnull(ami.isScrap,'0') <> '1'");
			}
			if(params.get("ids")!=null && CommonUtils.notNullStrOrEmpty(params.get("ids").toString())){
				sql.append(" AND ami.id in ("+params.get("ids").toString().trim()+")");
			}
			if(params.get("userStatus")!=null && CommonUtils.notNullStrOrEmpty(params.get("userStatus").toString())){
				//sql.append(" AND (ami.resUserId is NULL OR ami.resUserId = '') ");
				
				//资产申请、借用、领用功能中，选择资产时判断条件改为当资产状态为“已入库待领用”或“闲置”才能申请、借用、领用  modified by hy 2018/11/26
				sql.append(" and ami.assetStatus in('1','3')");
			}
			if(params.get("auxiliaryAsset")!=null && CommonUtils.notNullStrOrEmpty(params.get("auxiliaryAsset").toString())){
				sql.append(" AND ami.auxiliaryAsset = "+params.get("auxiliaryAsset").toString().trim()+" and (ami.parentId IS NULL OR ami.parentId = '' ) ");
			}
			if(params.get("parentId")!=null && CommonUtils.notNullStrOrEmpty(params.get("parentId").toString())){
				sql.append(" AND ami.parentId = '"+params.get("parentId").toString().trim()+"'");
			}
			if(params.get("locationName")!=null && CommonUtils.notNullStrOrEmpty(params.get("locationName").toString())){
				sql.append(" AND ap.name like '%"+params.get("locationName").toString().trim()+"%'");
			}
			if(params.get("resUserName")!=null && CommonUtils.notNullStrOrEmpty(params.get("resUserName").toString())){
				sql.append(" AND su.name like '%"+params.get("resUserName").toString().trim()+"%'");
			}
			if(params.get("registStatus")!=null && CommonUtils.notNullStrOrEmpty(params.get("registStatus").toString())){
				sql.append(" AND ami.registStatus = '"+params.get("registStatus").toString().trim()+"'");
			}else{
				if(params.get("registAssets")!=null && CommonUtils.notNullStrOrEmpty(params.get("registAssets").toString())){}else{
					sql.append(" AND (ami.registStatus is NULL OR ami.registStatus = '2') ");
				}
			}
		}else{
			sql.append(" AND ifnull(ami.isScrap,'0') <> '1'");
		}
		
		sql.append(" and not exists ( ");
		sql.append(" SELECT amrd.id FROM assets_material_recept_detail amrd left join assets_material_recept amr on amr.id=amrd.applyId "
				 + " WHERE  amrd.assetsId = ami.id and amr.status='DQR' ) ");//AND amr.`status` = 'DQR'

		if(params!=null && params.size()>0 && null != params.get("overviewWarn")){
			if("0".equals(String.valueOf(params.get("overviewWarn")))){
				sql.append(" order by assetsLeftTime asc");
			}else{
				sql.append(" order by maintAssetsLeftNum asc");
			}
		}else{
			sql.append(" order by ami.createTime desc,ami.sortCode ");
		}
		
		return  sql.toString();
	}


	@Override
	public void getAssetCollarPage(Map<String, Object> param, UTPageBean pageBean) {
		super.getPageListMapBySql(this.getAssetsListSql(param), pageBean, null);
	}


	@Override
	public List<UTMap<String, Object>> getAssetCollarByApplyId(Map<String, Object> param) {
		return super.getListBySql(getAssetCollarListMapsSql(param), null);
	}
	
	private String getAssetCollarListMapsSql(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append(" SELECT amrd.id,concat(ami.`name`,IF(ami.`codeNum` is null or ami.`codeNum`='','', concat('/',ami.`codeNum`))) `name`,concat(ami.`name`,IF(ami.`serialNum` is null or ami.`serialNum`='','', concat('/',ami.`serialNum`))) `assetsName`,ami.`code`,amc.`name` category,amc.`name` assetsType,amsc.`name` subCategory,amsc.`name` assetsSubType, amb.createUserId,amrd.assetsId,ami.resUserId," );
		sql.append(" concat(su3.`name`, '/', su3.`code`) resUserName,so.`name` resDepartName,ap.`name` location,ami.model,ami.brand,ami.assetsLevel,  ");
		sql.append(" amrd.grantAmount,amrd.grantUserId,concat(su2.`name`, '/', su2.`code`) grantUserName,amb.ipAddress,amrd.grantTime,amrd.`status` detailStatus,amrd.returnTime,amb.`status`,amb.endDate,DATEDIFF(amb.endDate,NOW()) returnDay ");
		sql.append(" FROM assets_material_recept_detail amrd ");
		sql.append(" LEFT JOIN assets_material_borrow amb ON amb.id = amrd.applyId ");
		sql.append(" LEFT JOIN assets_material_info ami ON ami.id = amrd.assetsId ");
		sql.append(" LEFT JOIN assets_material_category amc ON amc.id = ami.category ");
		sql.append(" LEFT JOIN assets_material_category amsc ON amsc.id = ami.subCategory ");
		sql.append(" LEFT JOIN sys_user su ON su.id = amb.createUserId  ");
		sql.append(" LEFT JOIN sys_user su2 ON su2.id = amrd.grantUserId  ");
		sql.append(" LEFT JOIN sys_user su3 ON su3.id=ami.resUserId ");
		sql.append(" LEFT JOIN sys_org so ON so.id = ami.resDepartId ");
		sql.append(" LEFT JOIN assets_place ap ON ap.id = ami.location ");
		sql.append(" WHERE 1=1 ");
		if(params!=null && params.size()>0){
			if(params.get("applyId")!=null &&  StringUtils.isNotEmpty(params.get("applyId").toString())){
				sql.append(" AND amrd.applyId = '"+params.get("applyId").toString().trim()+"' ");
			}
			if(params.get("detailStatus")!=null &&  StringUtils.isNotEmpty(params.get("detailStatus").toString())){
				sql.append(" AND amrd.status is not null  ");
			}
		}
		sql.append(" ORDER BY amrd.createTime ");
		return  sql.toString();
	}


	@Override
	public boolean addAssetCollar(Map<String, Object> newInfo) {
		// TODO Auto-generated method stub
		return super.saveBySql(collarDetailTableName, newInfo);
	}


	@Override
	public boolean deleteAssetCollarByApplyId(String applyId) {
		// TODO Auto-generated method stub
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("applyId", applyId);
		return super.deleteBySql(collarDetailTableName, param);
	}
}
