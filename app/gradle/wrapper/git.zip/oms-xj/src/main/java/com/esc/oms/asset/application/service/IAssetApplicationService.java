package com.esc.oms.asset.application.service;

import java.util.List;
import java.util.Map;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;


public interface IAssetApplicationService extends IBaseOptionService{
	
	public boolean addAssetIssue(Map<String,Object> info);
	
	public void finishRejectTask(String id);
	
	public boolean updateAssetIssueById(Map<String,Object> info);
	
	public boolean completeAssetIssue(String appId);
	
	public boolean startAssetIssue(String appId);
	
	public boolean completeAssetIssueConfirm(String appId);
	
	public boolean deleteAssetIssueById(String id);
	
	public boolean deleteAssetIssueByAssetId(String id);
	
	public boolean deleteAssetIssueByAppId(String id);
	
	public boolean checkAssetIssueConfirm(String appId, String status);
	
	public List<UTMap<String, Object>> getAssetIssueListMaps(Map param);
	
	public List<UTMap<String, Object>> getAssetListByAppId(Map param);
	
	public boolean updateIssueStatusById(String ids,String appId);
	
	public List<UTMap<String, Object>> getAssetIssuePageInfo(Map param);
	
	/**
	 * 保存数据
	 * @param map
	 */
	public String save(Map<String, Object> map);
	
	/**
	 * 保存数据并提交
	 * @param map
	 */
	public String submit(Map<String,Object> map);
	
	/**
	 * 完成审核
	 * @param recordId 记录ID
	 */
	public void finishAudit(String id);
	
	/**
	 * 驳回审核
	 * @param recordId 记录ID
	 */
	public void rejectAudit(String id);
	
	public boolean updateAssetIssueStatusByAppId(String appId,
			String status);
	
	public void addAssetsTrack(String appId);
	
	public List<UTMap<String,Object>> getIssueAssetByStatus(String assetId);

	public List<UTMap<String, Object>> getAssetsList(Map<String, Object> param);
}


