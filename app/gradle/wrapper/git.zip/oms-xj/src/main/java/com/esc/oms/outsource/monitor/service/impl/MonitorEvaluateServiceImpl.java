package com.esc.oms.outsource.monitor.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.upload.annotation.UploadQueryMarks;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.monitor.dao.IDuediligenceEvaluateConfigurationDao;
import com.esc.oms.outsource.monitor.dao.IMonitorEvaluateConfigurationDao;
import com.esc.oms.outsource.monitor.dao.IMonitorEvaluateDao;
import com.esc.oms.outsource.monitor.service.IMonitorEvaluateService;
import com.esc.oms.supplier.info.service.ISupplierBaseInfoService;
import com.esc.oms.system.evaluateSetting.dao.IEvaluateSettingDao;
import com.esc.oms.system.templateconfiguration.dao.ITemplateConfigurationDetailDao;
import com.esc.oms.system.templateconfiguration.dao.ITemplateConfigurationDetailDeputyResultDao;
import com.esc.oms.system.templateconfiguration.service.ITemplateConfigurationDetailDeputyService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;

/**
 * 服务监控评估
 * @author owner
 *
 */
@Service
@Transactional
public class MonitorEvaluateServiceImpl extends BaseOptionService implements IMonitorEvaluateService{
	
	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private IMonitorEvaluateDao dao;
	
//	@Resource
//	private IRiskOverallEvaluateTemplateDao riskOverallEvaluateTemplateDao;
	
	//模板配置详情dao
	@Resource
	private ITemplateConfigurationDetailDao detailDao;
	
	//全面风险评估配置Dao
	@Resource
	private IMonitorEvaluateConfigurationDao monitorEvaluateConfigurationDao;
	
	//模板配置从属数据操作Service接口
	@Resource
	private ITemplateConfigurationDetailDeputyService templateConfigurationDetailDeputyService;
	
	//模板配置从属数据结果操作dao接口
	@Resource
	private ITemplateConfigurationDetailDeputyResultDao templateConfigurationDetailDeputyResultDao;
	
	//系统参数
	@Resource
	private ISysParamService sysParamService;
	
	//用户Service
	@Resource
	private ISysUserService userService;
	
	//供应商Service
	@Resource
	private ISupplierBaseInfoService supplierBaseInfoService;
	
	//评估结果配置
	@Resource
	private IEvaluateSettingDao evaluateSettingDao;

	//代办任务
	@Resource
	private IUserTaskService userTaskService;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return dao;
	}

	/**
	 * 添加
	 * @param info
	 * @return
	 */
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	@EscOptionLog(module = SystemModule.monitorEvaluate, opType = ESCLogOpType.INSERT, table = "outsourc_monitor_evaluate", option = "新增服务监控评估配置编号为{monitorEvaluateConfigId}的服务监控评估。")
	public boolean add(Map info){
		String evaluateTitle = info.get("evaluateTitle").toString();//评估标题
		Map param = new HashMap();
		param.put("evaluateTitle", evaluateTitle);
		if(dao.isExist(param)){
			throw new EscServiceException(evaluateTitle+"已经存在！");
		}
		info.put("dataType", 2);//数据类型（1：评估配置的数据，2：新增的数据）
		info.put("status", 1);//已评估
		info.put("submitTime", UTDate.getCurDateTime());//提交时间
		info.put("submitter", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());//提交人
		super.add(info);
		return true;
	}
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		UTMap<String, Object> result = super.getById(id);
//		String monitorEvaluateConfigId = result.get("monitorEvaluateConfigId")+"";//全面风险评估配置模板id
//		String evaluator = result.get("evaluator")+"";//评估人
		result.put("treeData", templateConfigurationDetailDeputyService.getDetailsDeputy(id, id));
		return result;
	}
	
	/**
	 * 修改
	 * @param info
	 * @return
	 */
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	@EscOptionLog(module = SystemModule.monitorEvaluate, opType = ESCLogOpType.UPDATE, table = "outsourc_monitor_evaluate", option = "更新服务监控评估配置编号为{monitorEvaluateConfigId}的服务监控评估。")
	public boolean updateById(Map info){
		String id = info.get("id")+"";//全面风险评估配置模板id
//		Map existMap = new HashMap();
//		existMap.put("id", id);
//		if(!dao.isExist(existMap)){
//			throw new EscServiceException("当前数据已经不存在，请刷新页面重新操作！");
//		}
		info.put("evaluateTime", UTDate.getCurDateTime());//评估时间
		info.put("submitTime", UTDate.getCurDateTime());//提交时间
		info.put("status", 1);//评估状态
//		String submitter = EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId();
		info.put("submitter", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());//提交人
		List<Map> resultList = new ArrayList<Map>();
		List<Map> list= (List<Map>)info.get("treeData");
//		String monitorEvaluateConfigId = info.get("monitorEvaluateConfigId")+"";
//		String evaluator = info.get("evaluator")+"";
		
		CommonUtils.setTemplateConfigurationDetailDeputyResult(id, id, list, resultList);
		//先删除
		templateConfigurationDetailDeputyResultDao.deleteByModuleTemplateConfigurationIdEvaluator(id);
		if(!resultList.isEmpty()){
			//后添加
			templateConfigurationDetailDeputyResultDao.adds(resultList);
		}
//		UTMap<String, Object> monitorEvaluateTemplate = monitorEvaluateConfigurationDao.getById(monitorEvaluateConfigId);
//		String isSingle = monitorEvaluateTemplate.get("isSingle")+"";//是否单一数据，1：是，0：否，默认否
		//当前评估的数据模板是单一数据，则把改模板下其它人的评估数据都删除
//		if("1".equals(isSingle)){
//			String createTime = info.get("createTime") + "";
//			//单一数据评估后，需要删除同一批时间点生成的其它数据
//			dao.deleteBySingle(id, monitorEvaluateConfigId, createTime);
//		}
		userTaskService.finishTask(id);//完成代办任务
		//在过程评估后需要将评估人加入到评估配置的评估人字段中
//		CommonUtils.setConfigurationEvaluator(monitorEvaluateConfigurationDao,info.get("monitorEvaluateConfigId").toString());
		return super.updateById(info);
	}
	
	
	
	@Override
	public boolean deleteById(String id) {
		detailDao.deleteByTemplateConfigurationId(id);
		return super.deleteById(id);
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map param) {
		dao.getPageInfo(pageBean, param);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	@UploadQueryMarks
	public List<UTMap<String, Object>> getListAll(Map params){
		return dao.getListAll(params);
	}
	
	/**
	 * 导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	@Override
	public void leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String[] fileds = IMonitorEvaluateDao.outFileds;
		String tamlate= null;
		tamlate= "excelOutTamplate.monitorEvaluate";
		
		//替换下拉的值
		Map<String, String> fieldAndParamType = new HashMap<String, String>();
		UTMap<String, Object> setting = evaluateSettingDao.getById("1");
		//判断巡检管理评估结果的填报方式是下拉还是文本输入
		if(setting != null && "1".equals(setting.get("serviceMonitoring").toString())){
			fieldAndParamType.put(IMonitorEvaluateDao.FIELD_EVALUATERESULT, "serviceMonitoringEvaluateResult");
		}
		fieldAndParamType.put(IMonitorEvaluateDao.FIELD_STATUS, "accessEvaluateStatus");
		fieldAndParamType.put(IMonitorEvaluateDao.FIELD_TYPE, "serviceMonitoringType");
		sysParamService.changeParamData(data, fieldAndParamType);
		
		Map<String,Object> param = new HashMap<String,Object>();
		param.put("state", "1");
		param.put("userType", "1");//查询甲方人员
		List<UTMap<String,Object>> userMap = userService.getUserBaseInfo(param);
		
		//转换检查人员
		for(int i=0;i<data.size();i++){
			Map<String,Object> item = (Map<String, Object>) data.get(i);
			String monitorEvaluator = (String) item.get(IMonitorEvaluateDao.FIELD_MONITOREVALUATOR);
			item.put(IMonitorEvaluateDao.FIELD_MONITOREVALUATOR, CommonUtils.getUserNameAndCodesByIds(userMap, monitorEvaluator));
			String beganDate = CommonUtils.replaceAll((String)item.get(IMonitorEvaluateDao.FIELD_EVALUATEBEGINDATE), "-", "/");
			String endDate = CommonUtils.replaceAll((String)item.get(IMonitorEvaluateDao.FIELD_EVALUATEENDDATE), "-", "/");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
			if ((beganDate == null) ? false : (beganDate.length() > 0)) {
				beganDate = sdf.format(sdf.parse(beganDate));
			}
			if ((endDate == null) ? false : (endDate.length() > 0)) {
				endDate = sdf.format(sdf.parse(endDate));
			}
			item.put(IMonitorEvaluateDao.FIELD_EVALUATEBEGINDATE, beganDate);
			item.put(IMonitorEvaluateDao.FIELD_EVALUATEENDDATE, endDate);
			item.put(IMonitorEvaluateDao.FIELD_SUBMITTIME, CommonUtils.replaceAll((String)item.get(IDuediligenceEvaluateConfigurationDao.FIELD_SUBMITTIME), "-", "/"));
		}
		
		UTExcel.leadingout( fileds, data, tamlate, request, response);
	}
	
	/**
	 * 从excel中导入数据
	 * @param filePath
	 * @param param
	 * @return
	 */
	@Override
	public void leadingin(String filePath, Map<String, Object> param) throws Exception {
		List<UTMap<String, Object>> leadinginList = new ArrayList<UTMap<String,Object>>();
		// 根据路径 获取工作薄
		Sheet sheet = UTExcel.getSheets(filePath)[0];
		// 导入顺序
		String[] fileds = IMonitorEvaluateDao.inFileds;
		String[] cellArray = new String[] { 
				"监控名称*（长度：0-20）", 
				"供应商*", 
				"类别*", 
				"评估结果*（长度：0-20）", 
				"检查人员*", 
				"开始日期*（格式：yyyy/MM/dd）", 
				"结束日期*（格式：yyyy/MM/dd）", 
				"结果说明*（长度：0-500）", 
				"备注（长度：0-500）"
		};
		int[] lengthArr = {20, 0, 0, 20, 0, 0, 0, 500, 500};
		int rowNum = sheet.getLastRowNum();
		int cellNum = fileds.length;
		
		if(!UTExcel.excelValidateByCell(sheet, cellArray, fileds)) {
			throw new EscServiceException("导入失败，请选择正确的模板！");
		}		
		
		Map<String,Object> userParam = new HashMap<String,Object>();
		userParam.put("state", "1");
		userParam.put("userType", "1");//查询甲方人员
		List<UTMap<String,Object>> userMap = userService.getUserBaseInfo(userParam);
		StringBuilder error = new StringBuilder();
		// 从excel第1行开始添加 数据，全部保存
		for (int i = 1; i <= rowNum; i++) {
			// 遍历excel
			Row row = sheet.getRow(i);
			UTMap<String, Object> map = new UTMap<String, Object>();
			for (int j = 0; j < cellNum; j++) {
				String cellvalue = null;
				Cell cell = row.getCell(j);
				if (cell != null) {
					cell.setCellType(Cell.CELL_TYPE_STRING);
					cellvalue = cell.getStringCellValue();
					cellvalue = StringUtils.isEmpty(cellvalue) ? null : cellvalue.trim();
				}
				//检查为空的字段
				if(j == 0 || j == 1 || j == 2 || j == 3 || j == 4 || j == 5 || j==6 || j==7) {  //不能为空
					if (StringUtils.isEmpty(cellvalue)) {
						error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "内容为空，请检查！" + "<br>");
					}
				}else{  //可以为空
					cellvalue = StringUtils.isEmpty(cellvalue) ? null : cellvalue;
				}
				if (cellvalue != null) {
					//长度校验
					if (lengthArr[j] != 0 && cellvalue.length() > lengthArr[j]){
						error.append("Excel内容错误，行号为" + (i + 1) + "的"+ cellArray[j] + "内容长度超出限制，请检查！" + "<br>");
					}
					//转换供应商
					if(j==1 && cellvalue != null){		
	//					cellvalue = cellvalue.replaceAll("，", ",");
						Map supplierParam = new HashMap();
						supplierParam.put("fullName", cellvalue);
						List<UTMap<String, Object>> supplierList = supplierBaseInfoService.getListMaps(supplierParam);
						if(supplierList == null || supplierList.isEmpty()){
							error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "列，系统不存在供应商【"+cellvalue+"】！" + "<br>");
						}else if(supplierList.size() != 1){
							error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "列，系统存在重名的供应商【"+cellvalue+"】，无法匹配，请加入供应商编号！" + "<br>");
						}else{
							cellvalue = supplierList.get(0).get("id") + "";
						}
					}
					
					//转换检查人员
					if(j==4 && cellvalue != null){		
						cellvalue = cellvalue.replaceAll("，", ",");
						try{
							cellvalue = CommonUtils.getIdsByUserNameAndCodes(userMap, cellvalue);
						}catch(EscServiceException ex){
							error.append("Excel内容错误，行号为" + (i+1) + "的"+ cellArray[j] + "列，"+ex.getMessage() + "<br>");
						}
					}
					if ((j == 5 || j == 6) && cellvalue != null) {
						if (!CommonUtils.validateDate(cellvalue)) {
							error.append("Excel内容错误，行号为" + (i+1) + "的"+cellArray[j]+"格式不对，请检查！" + "<br>");
						}
					}
				}
				map.put(fileds[j], cellvalue);
			}			
			map.put("importSort", i);
			leadinginList.add(map);
		}
		//替换下拉的值
		Map<String, String> fieldAndParamType = new HashMap<String, String>();
		UTMap<String, Object> setting = evaluateSettingDao.getById("1");
		//判断评估结果的填报方式是下拉还是文本输入
		if(setting != null && "1".equals(setting.get("serviceMonitoring").toString())){
			fieldAndParamType.put(IMonitorEvaluateDao.FIELD_EVALUATERESULT, "serviceMonitoringEvaluateResult");
		}
		
		fieldAndParamType.put(IMonitorEvaluateDao.FIELD_TYPE, "serviceMonitoringType");
		sysParamService.changeDataToParam(leadinginList, fieldAndParamType);
		
		//保存到数据库
		for (int i = 0; i < leadinginList.size(); i ++){
			UTMap leadingOne = leadinginList.get(i);
			if(StringUtils.isEmpty((String) leadingOne.get(IMonitorEvaluateDao.FIELD_TYPE))) {
				error.append("Excel内容错误，行号为" + (i + 2) + "的类别参数在系统中不存在，请检查！" + "<br>");
			}
			//判断评估结果的填报方式是下拉还是文本输入
			if(setting != null && "1".equals(setting.get("serviceMonitoring").toString())){
				if(StringUtils.isEmpty((String) leadingOne.get(IMonitorEvaluateDao.FIELD_EVALUATERESULT))) {
					error.append("Excel内容错误，行号为" + (i + 2) + "的评估结果参数在系统中不存在，请检查！" + "<br>");
				}
			}
		}
		if (StringUtils.isNotEmpty(error.toString())) {
			throw new EscServiceException(error.toString());
		}
		for (int i = 0; i < leadinginList.size(); i ++){
			UTMap leadingOne = leadinginList.get(i);
			leadingOne.put("dataType", 2);//数据类型（1：评估配置的数据，2：新增的数据）
			//往数据库插入一条数据
			add(leadingOne);
		}
	}

}
