package com.esc.oms.outsource.agreementManpower.service;

import java.util.List;
import java.util.Map;

import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;

/**
 * 人力外包合同 配置
 * @author smq
 * @date   2016-2-24 上午10:50:04
 */
public interface IAgreementManpowerInfoService extends IBaseOptionService {
	

	/**
	 * 保存 人员外包合同配置
	 * @param baseInfoMap 基础配置
	 * @param costConfigs 费用配置
	 * @param vacationConfig 折算配置
	 * @return
	 */
	public boolean saveAgreementManpowerInfo( Map<String, Object> baseInfoMap,List<Map<String, Object>> costConfigs,List<Map<String, Object>> vacationConfig)throws EscServiceException;

	/**
	 * 删除人力外包合同配置
	 * @param id
	 * @return
	 */
	public boolean deletesAgreementManpowerInfo(String ids);

	/**
	 * 获取 所有未进行配置的人力外包合同
	 * */
	public List<UTMap<String, Object>> getAgreementManpowerNoConfig();
	
	/**
	 * 通过 合同Id 获取 外包人力合同费用配置
	 * @param manpowerId
	 * @return
	 */
	public List<UTMap<String, Object>> getManpowerCostConfigs(String manpowerId);
	
	/**
	 * 通过 合同Id 获取 外包人力合同 折算配置
	 * @param manpowerId
	 * @return
	 */
	public List<UTMap<String, Object>> getManpowerVacationConfig(String manpowerId);

	/**
	 *获取外包人力合同费用配置中所包括的人员类型  通过 合同Id
	 * @param manpowerId
	 * @return
	 */
	public List<UTMap<String, Object>> getVacationConfigCategory(String manpowerId);
	
	/**
	 * 获取 外包人力合同费用配置中对应人员类型所包括的人员级别 通过 合同Id和人员类型 
	 * @param manpowerId
	 * @return
	 */
	public List<UTMap<String, Object>> getVacationConfigLeve(String manpowerId,String category);
	
	/**
	 * 获取 外包人力合同 通过 配置Id
	 * 结果： 基本配置 baseConfig， 折算配置 vacationConfigs  费用配置 costConfigs
	 * @param manpowerId
	 * @return
	 */
	public Map<String, Object> getAgreementManpowerById(String manpowerId);
	
	/**
	 * 获取 外包人力合同 通过 配置合同Id
	 * 结果： 基本配置 baseConfig， 折算配置 vacationConfigs  费用配置 costConfigs
	 * @param manpowerId
	 * @return
	 */
	public Map<String, Object> getAgreementManpowerByAgreementId(String agreementId);
	
	/**
	 * 根据用户编号获取外包合同
	 * @param userId
	 * @return
	 */
	public UTMap<String, Object> getByUserId(String userId);
	
}
