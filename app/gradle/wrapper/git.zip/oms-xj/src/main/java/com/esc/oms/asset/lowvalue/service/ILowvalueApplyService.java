package com.esc.oms.asset.lowvalue.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;


public interface ILowvalueApplyService extends IBaseOptionService{
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params);
	/**
	 * 导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public boolean leadingout(List data, HttpServletRequest request,HttpServletResponse response) throws Exception;
	/**
	 * 列表，分页（包括领用详单）
	 * @param pageBean
	 * @param param
	 */
	public void getPageInfoDetail(UTPageBean pageBean, Map param);
	/**
	 * 列表，全部（包括领用详单）
	 * @param params
	 * @return
	 */
	public List<UTMap<String, Object>> getListAllDetail(Map params);
	
	/**
	 * 流程完成时，业务上需要进行的相应操作。
	 * @param businessRecordId
	 */
	public void finishAudit(String businessRecordId);
	/**
	 * 流程回到开始节点时（驳回），业务上需要进行的相应操作。
	 * @param businessRecordId
	 */
	public void rejectAudit(String businessRecordId);
	/**
	 * 待审批列表--分页查询
	 * @param pageBean
	 * @param params
	 */
	public void getPendApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params);
	/**
	 * 已审批列表--分页查询
	 * @param pageBean
	 * @param params
	 */
	public void getAlreadyApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params);

}


