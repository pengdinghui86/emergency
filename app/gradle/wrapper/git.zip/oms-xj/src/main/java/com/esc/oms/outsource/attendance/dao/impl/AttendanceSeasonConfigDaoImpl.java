package com.esc.oms.outsource.attendance.dao.impl;

import com.esc.oms.outsource.attendance.dao.IAttendanceSeasonConfigDao;
import com.esc.oms.util.CommonUtils;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class AttendanceSeasonConfigDaoImpl  extends BaseOptionDao implements IAttendanceSeasonConfigDao {
    @Override
    public String getTableName() {
        return "attendance_season_config";
    }
    @Override
    public boolean isExistYear(Map<String, Object> params) {
        StringBuilder sql = new StringBuilder();
        sql.append("select 1 from "+getTableName()+" where 1=1 ");
        if(params != null){
            String id = (String) params.get("id");
            String year = (String) params.get("year");
            if(CommonUtils.notNullStrOrEmpty(id)){
                sql.append(" and id='"+id+"' ");
            }
            if(StringUtils.isNotEmpty(year)){
                sql.append(" and year = '"+year+"' ");
            }
        }
        List<UTMap<String, Object>> list = this.getListBySql(sql.toString());
        return list!= null ? list.size() > 0 : false;
    }
}
