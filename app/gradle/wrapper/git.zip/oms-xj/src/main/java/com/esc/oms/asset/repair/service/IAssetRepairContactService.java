package com.esc.oms.asset.repair.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;

public interface IAssetRepairContactService extends IBaseOptionService {
	
	public UTMap<String, Object> getRepairById(String id);

	public List<UTMap<String, Object>> getRepairList(Map param);
	
	public boolean leadingout(List data, HttpServletRequest request,HttpServletResponse response) throws Exception;
}
