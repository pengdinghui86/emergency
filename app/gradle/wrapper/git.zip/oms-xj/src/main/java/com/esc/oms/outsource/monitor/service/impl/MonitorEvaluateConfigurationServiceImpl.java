package com.esc.oms.outsource.monitor.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.timetask.anotations.CronTimeTask;
import org.esc.framework.timetask.anotations.TimeTaskMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.monitor.dao.IMonitorEvaluateConfigurationDao;
import com.esc.oms.outsource.monitor.dao.IMonitorEvaluateDao;
import com.esc.oms.outsource.monitor.service.IMonitorEvaluateConfigurationService;
import com.esc.oms.outsource.monitor.service.IMonitorEvaluateService;
import com.esc.oms.system.templateconfiguration.dao.ITemplateConfigurationDetailDeputyDao;
import com.esc.oms.system.templateconfiguration.dao.ITemplateConfigurationDetailDeputyResultDao;
import com.esc.oms.system.templateconfiguration.service.ITemplateConfigurationDetailDeputyService;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;
import com.esc.oms.util.ParamUtils;
import com.esc.oms.util.TaskModel;

/**
 * 服务监控评估配置
 * @author owner
 *
 */
@Service
@Transactional
@TimeTaskMark
public class MonitorEvaluateConfigurationServiceImpl extends BaseOptionService implements IMonitorEvaluateConfigurationService{
	
	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private IMonitorEvaluateConfigurationDao dao;
	
	//模板配置详情dao
//	@Resource
//	private IRiskOverallEvaluateTemplateDao riskOverallEvaluateTemplateDao;
	
	//模板配置详情副表操作dao
	@Resource
	private ITemplateConfigurationDetailDeputyDao templateConfigurationDetailDeputyDao;
	
	//全面风险评估
	@Resource
	private IMonitorEvaluateDao monitorEvaluateDao;
	
	//全面风险评估
	@Resource
	private IMonitorEvaluateService monitorEvaluateService;
	
	//模板配置从属数据操作Service接口
	@Resource
	private ITemplateConfigurationDetailDeputyService templateConfigurationDetailDeputyService;
	
	//模板配置从属数据结果操作dao接口
	@Resource
	private ITemplateConfigurationDetailDeputyResultDao templateConfigurationDetailDeputyResultDao;

	//代办任务
	@Resource
	private IUserTaskService userTaskService;
	
	@Resource
	private MessageSend messageService;
	
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return dao;
	}

	/**
	 * 添加
	 * @param info
	 * @return
	 */
//	@UploadAddMark//aop拦截绑定上传文件的数据关系
	@EscOptionLog(module = SystemModule.monitorEvaluateConfiguration, opType = ESCLogOpType.INSERT, table = "outsourc_monitor_evaluate_configuration", option = "新增监控名称为{evaluateTitle}的服务监控配置。")
	public boolean add(Map info){
		String evaluateTitle = info.get("evaluateTitle").toString();//评估标题
		String templateConfigurationId = info.get("templateConfigurationId")==null?"":info.get("templateConfigurationId").toString();//全面评估结果填报模板
		Map param = new HashMap();
		param.put("evaluateTitle", evaluateTitle);
		if(dao.isExist(param)){
			throw new EscServiceException(evaluateTitle+"已经存在！");
		}
		info.put("status", 0);//状态.启用：0，暂停：1
		info.put("evaluateStatus", 0);//标识是否已经生成评估数据，如果已经生成，则不允许删除，未生成：0，已生成：1
//		info.put("evaluateStatus", 0);//只标识供应商准入评估模板对应的个人准入评估是否已经在评估，待评估：0，评估中：1，已评估：2
		super.add(info);
//		String id = info.get("id") + "";
		//初始化全面评估结果填报模板副表数据
//		templateConfigurationDetailDeputyDao.initDataByTemplateConfigurationId(templateConfigurationId, id);
//		//评估人列表
//		String evaluator = info.get("evaluator") + "";
//		if(StringUtils.isNotEmpty(evaluator)){
//			String[] evaluatorArr = evaluator.split(",");
//			//根据评估人初始化准入评估表的数据
//			for (String evaluatorId : evaluatorArr) {
//				Map evaluateMap = new HashMap();
//				evaluateMap.put("evaluator", evaluatorId);//评估人
//				evaluateMap.put("monitorEvaluateConfigId", id);//全面风险评估配置id
//				evaluateMap.put("status", 0);//状态
//				monitorEvaluateDao.add(evaluateMap);
//			}
//		}
		return true;
	}
	
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		UTMap<String, Object> result = super.getById(id);
		return result;
	}
	
	/**
	 * 修改
	 * @param info
	 * @return
	 */
//	@UploadAddMark//aop拦截绑定上传文件的数据关系
	@EscOptionLog(module = SystemModule.monitorEvaluateConfiguration, opType = ESCLogOpType.UPDATE, table = "outsourc_monitor_evaluate_configuration", option = "更新监控名称为{evaluateTitle}的服务监控配置。")
	public boolean updateById(Map info){
		return super.updateById(info);
	}
	
	/**
	 * 关闭
	 * @param info
	 * @return
	 */
	@EscOptionLog(module = SystemModule.monitorEvaluateConfiguration, opType = ESCLogOpType.UPDATE, table = "outsourc_monitor_evaluate_configuration", option = "关闭监控名称为{evaluateTitle}的服务监控配置。")
	public boolean close(Map info){
		info.put("closeTime", UTDate.getCurDateTime());//关闭时间
		info.put("status", 2);//评估状态
		return super.updateById(info);
	}
	
	@Override
	@EscOptionLog(module = SystemModule.monitorEvaluateConfiguration, opType = ESCLogOpType.DELETE,primaryKey="id={1}", table = "outsourc_monitor_evaluate_configuration", option = "删除监控名称为{evaluateTitle}的服务监控配置。")
	public boolean deleteById(String id) {
		return super.deleteById(id);
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map param) {
		dao.getPageInfo(pageBean, param);
	}

	@CronTimeTask(description="每天凌晨定时生成服务监控评估数据",cron="0 0 0 * * ?")
	@Override
	public void generate() {
		logger.info("开始定时生成服务监控评估数据！=========================================================");
		List<UTMap<String, Object>> list = dao.getListAllByMonitorPeriod();
		if(list != null){
			for (UTMap<String, Object> utMap : list) {
				String evaluators = utMap.get("evaluator")+"";
//				templateConfigurationDetailDeputyDao.get
				String templateConfigurationId = utMap.get("templateConfigurationId") + "";
				Map evaluateMap = new HashMap();
				evaluateMap.put("evaluator", evaluators);//评估人
				evaluateMap.put("monitorEvaluateConfigId", utMap.get("id"));//全面风险评估配置id
				evaluateMap.put("status", 0);//状态
				evaluateMap.put("evaluateTitle", utMap.get("evaluateTitle"));//评估标题
				evaluateMap.put("templateConfigurationId", utMap.get("templateConfigurationId"));//评估模板id
				evaluateMap.put("templateConfigurationName", utMap.get("templateConfigurationName"));//模板名称
				evaluateMap.put("templateConfigurationVersions", utMap.get("templateConfigurationVersions"));//模板版本
				evaluateMap.put("monitorRemark", utMap.get("monitorRemark"));//监控说明
				evaluateMap.put("type", utMap.get("type"));//类别
				evaluateMap.put("supplierId", utMap.get("supplierId"));//供应商编号
				evaluateMap.put("dataType", 1);//根据配置生成的数据
				monitorEvaluateDao.add(evaluateMap);
				String id = evaluateMap.get("id")+"";
				//初始化评估模板数据
				templateConfigurationDetailDeputyDao.initDataByTemplateConfigurationId(templateConfigurationId, id);
				utMap.put("generateTime", UTDate.getCurDateTime());//本次生成数据的时间
				utMap.put("evaluateStatus", 1);//标识是否已经生成评估数据，如果已经生成，则不允许删除，未生成：0，已生成：1
				dao.updateById(utMap);
				
				String[] evaluatorArr = evaluators.split(",");
				for (String evaluator : evaluatorArr) {
					String title = "服务监控";
					String content = "【"+utMap.get("evaluateTitle")+"】服务监控数据待您填报";
					userTaskService.addTaskByUserId(content, id, title, TaskModel.monitorEvaluate, evaluator, UTDate.getCurDate(), id);
				}
				String title = "服务监控评估提醒";
				String content = "您有【"+utMap.get("evaluateTitle")+"】服务监控数据待填报，请进入系统进行处理";
				messageService.sendMessage(evaluators,title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
			}
		}
		logger.info("成功定时生成服务监控评估数据！=========================================================");
	}

	/**
	 * 暂停
	 * @param info
	 * @return
	 */
	@Override
	public void pause(Map<String, Object> info) {
		info.put("pauseTime", UTDate.getCurDateTime());//暂停时间
		info.put("pauseUserId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());//暂停操作用户id
		dao.updateById(info);
	}

	/**
	 * 启用
	 * @param info
	 * @return
	 */
	@Override
	public void enabled(Map<String, Object> info) {
		dao.updateById(info);
	}

}
