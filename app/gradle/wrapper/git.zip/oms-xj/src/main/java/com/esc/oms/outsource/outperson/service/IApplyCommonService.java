package com.esc.oms.outsource.outperson.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.workflow.service.IWorkflowCallback;

/**
 * 外包人员申请 接口 
 * @author smq
 * @date   2016-7-9 下午4:17:21
 */
public interface IApplyCommonService extends IBaseOptionService,  IWorkflowCallback {
	

	public static final String  APPLY_TYPE_ENTER = "enter";
	public static final String  APPLY_TYPE_QUIT = "quit";
	public static final String  APPLY_TYPE_EXIT= "exit";
	
	/**
	 * 提交审批信息
	 * @param info
	 */
	public void submit(Map<String, Object> info);
	
	/**
	 * 查询供应商退出记录。(不分页)
	 * @param params
	 * @return
	 */
	public List<UTMap<String, Object>> searchInfo(Map<String, Object> params);
	
	/**
	 * 查询供应商退出记录。(分页)
	 * @param params
	 * @param pageBean
	 * @return
	 */
	public void searchInfoPage( UTPageBean pageBean,Map<String, Object> params);
	
	/**
	 * 获取待审列表
	 * @param pageBean
	 * @param params
	 */
	public void getPendApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) ;

	/**
	 * 获取已审列表
	 * @param pageBean
	 * @param params
	 */
	public void getAlreadyApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) ;
	
	/**
	 * 导出数据
	 * @param recordList 记录列表
	 * @param request
	 * @param response
	 */
	public void exportData(List<UTMap<String, Object>> recordList, HttpServletRequest request, HttpServletResponse response) throws Exception;
	
}
