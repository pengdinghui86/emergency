package com.esc.oms.outsource.manhour.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

public interface ITravelDetailDao extends IBaseOptionDao {

	public static final String FIELD_ID = "id";
	public static final String FIELD_INFOID = "infoId";
	public static final String FIELD_PRESENTDATE = "presentDate";
	public static final String FIELD_BEGINTIME = "beginTime";
	public static final String FIELD_ENDTIME = "endTime";
	public static final String FIELD_HOURS = "hours";
	
	public static final String FIELD_CREATEUSER = "createUser";
	public static final String FIELD_CREATETIME = "createTime";
	public static final String FIELD_UPDATEUSER = "updateUser";
	public static final String FIELD_UPDATETIME = "updateTime";

	public void deleteByInfoId(String infoId);

	/**
	 *工时统计的详细
	 * @param param 查询条件
	 * @return
	 */
	public List<UTMap<String, Object>> getTravelDetailList(Map param);
	/**
	 * 工时统计的详细
	 * @param pageBean
	 * @param param
	 * @return
	 */
	public void getTravelDetailPage(UTPageBean pageBean,Map param);

}
