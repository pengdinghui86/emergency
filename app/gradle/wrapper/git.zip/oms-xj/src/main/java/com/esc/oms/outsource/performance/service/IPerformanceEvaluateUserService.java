package com.esc.oms.outsource.performance.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;

/**
 * 外包绩效考核
 * @author owner
 *
 */
public interface IPerformanceEvaluateUserService extends IBaseOptionService{
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params);
	
	/**
	 * 导入
	 * @param filePath
	 * @param param
	 * @return
	 * @throws Exception
	 */
	public void leadingin(String filePath, Map<String, Object> param) throws Exception;
	
	/**
	 * 导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public void leadingout(List<UTMap<String, Object>> data, HttpServletRequest request,HttpServletResponse response) throws Exception;

	public List<UTMap<String, Object>> getAvgEvaluateResult(String performanceEvaluateConfigId,
			String performanceEvaluator, String projectInfoId);
}
