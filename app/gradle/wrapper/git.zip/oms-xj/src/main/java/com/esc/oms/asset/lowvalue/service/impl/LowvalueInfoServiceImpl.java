package com.esc.oms.asset.lowvalue.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.idgenerator.IDGenerationManager;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.asset.lowvalue.dao.ILowvalueInfoDao;
import com.esc.oms.asset.lowvalue.service.ILowvalueInfoService;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;

@Service
@Transactional
public class LowvalueInfoServiceImpl extends BaseOptionService implements ILowvalueInfoService{

	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private ILowvalueInfoDao dao;
	
	@Resource
	private ISysParamService sysParamService;

	@Resource
	private ISysUserService userService;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return dao;
	}

	/**
	 * 添加
	 * @param info
	 * @return
	 */
	@EscOptionLog(module=SystemModule.ASSETS_LOWVALUE, opType=ESCLogOpType.INSERT, table="assets_lowvalue_info", primaryKey="id={1.id}",option="新增物品：{1.name}/{1.code}")	
	public boolean add(Map info){				
		boolean isUnique = isUnique(info);
		if(isUnique){
			info.put("status", "0");
			super.add(info);		
			return true;
		}else{
			return false;
		}		
	}
	
	@EscOptionLog(module=SystemModule.ASSETS_LOWVALUE, opType=ESCLogOpType.UPDATE, table="assets_lowvalue_info", primaryKey="id={1.id}",option="修改物品信息：{1.name}/{1.code}")
	public boolean updateById(Map info){
		return super.updateById(info);
	}
	
	@EscOptionLog(module=SystemModule.ASSETS_LOWVALUE, opType=ESCLogOpType.DELETE, table="assets_lowvalue_info",primaryKey="{1}",option="删除物品：{name}/{code}")	
	public boolean deleteById(String id){
		return super.deleteById(id);
	}
	
	private boolean isUnique(Map info){			
		//判断项目名称的唯一性
		Map<String,Object> nameMap = new HashMap<String,Object>();			
		if(info.get("name")!=null){
			nameMap.put("name", info.get("name"));
			if(dao.isExist(nameMap)){
				info.put("msg", "物品名称【"+info.get("name")+"】已存在！");
				return false;
			}
		}			
		//判断编号的唯一性
		Map<String,Object> numMap = new HashMap<String,Object>();
		if(info.get("code")!=null&&String.valueOf(info.get("code")).length()>0){
			numMap.put("code", info.get("code"));
			if(dao.isExist(numMap)){
				info.put("msg", "编号【"+info.get("code")+"】已存在！");				
				return false;
			}
		}			
		return true;
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map param) {
		dao.getPageInfo(pageBean, param);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params){
		return dao.getListAll(params);
	}


//	//已存在的项目列表
//	private Map<String,String> getExistProjectMap(){
//		Map<String,String> map = new HashMap<String,String>();
//		List<UTMap<String,Object>> list = this.getAll();
//		for(UTMap<String, Object> utmap : list){
//			String name = (String) utmap.get("name");
//			String code = (String)utmap.get("code");
//			map.put(code, name);
//		}
//		return map;
//	}
//			
//	private Map<String,Map<String,String>> getUserMap(){
//		Map<String,Map<String,String>> map = new HashMap<String,Map<String,String>>();
//		Map<String,String> orgUsermap = new HashMap<String,String>();
//		Map<String,String> supplierUsermap = new HashMap<String,String>();
//		Map<String,Object> param = new HashMap<String,Object>();
//		param.put("state", "1");
//		List<UTMap<String, Object>>  supplierList = userService.getUserBaseInfo(param);
//		for(UTMap<String, Object> utmap : supplierList){
//			String userType = utmap.get("userType").toString();
//			String name = (String) utmap.get("name");
//			String code = (String) utmap.get("code");
//			String id = (String)utmap.get("id");
//			if("1".equalsIgnoreCase(userType)){
//				orgUsermap.put(name+"/"+code, id);
//			}else{
//				supplierUsermap.put(name+"/"+code, id);
//			}		
//		}
//		map.put("orgUser", orgUsermap);
//		map.put("supplierUser", supplierUsermap);
//		return map;
//	}
	
	/**
	 * 导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	@Override
	public boolean leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String[] fileds = null;
		String tamlate= null;
		tamlate= "excelOutTamplate.lowvalueList";
		fileds = new String[] {				
				ILowvalueInfoDao.FIELD_CATEGORY,
				ILowvalueInfoDao.FIELD_NAME,
				ILowvalueInfoDao.FIELD_CODE,
				ILowvalueInfoDao.FIELD_BRAND,
				ILowvalueInfoDao.FIELD_MODEL,
				ILowvalueInfoDao.FIELD_MEASURE,
				ILowvalueInfoDao.FIELD_UNIT_PRICE,
				ILowvalueInfoDao.FIELD_TOTAL_NUM,
				ILowvalueInfoDao.FIELD_STOCK_NUM,
				ILowvalueInfoDao.FIELD_AMOUNT,
				ILowvalueInfoDao.FIELD_STOCK_AMOUNT};
	
		//替换下拉的值
		Map<String, String> fieldAndParamType = new HashMap<String, String>();
		fieldAndParamType.put(ILowvalueInfoDao.FIELD_CATEGORY, "lowvalueCategory");
		sysParamService.changeParamData(data, fieldAndParamType);
		
		return	UTExcel.leadingout( fileds, data, tamlate, request, response);
	}
	
	
}