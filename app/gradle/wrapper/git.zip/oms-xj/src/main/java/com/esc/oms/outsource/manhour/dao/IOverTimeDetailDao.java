package com.esc.oms.outsource.manhour.dao;

import org.esc.framework.persistence.dao.IBaseOptionDao;

public interface IOverTimeDetailDao extends IBaseOptionDao {
    /**
     * 根据用户和事件删除
     * @param startTime
     * @param endTime
     * @param userIds
     * @return
     */
    public boolean deleteByTime(String startTime, String endTime, String userIds);
}
