package com.esc.oms.outsource.agreementManpower.dao;


import org.esc.framework.persistence.dao.IBaseOptionDao;

/**
 * 人力外包合同请假折算配置
 * @author smq
 * @date   2016-2-24 上午10:55:48
 */
public interface IAgreementManpowerVacationConfigDao extends IBaseOptionDao {

	public static final String  FIELD_ID = "id";
	public static final String  FIELD_MANPOWERID = "manpowerId";
	public static final String  FIELD_INTERVALBEGIN = "intervalBegin";//折算区间开始
	public static final String  FIELD_INTERVALEND = "intervalEnd";//折算区间结束
	public static final String  FIELD_INTERVALRATE= "intervalRate";//折算率
	
	

}
