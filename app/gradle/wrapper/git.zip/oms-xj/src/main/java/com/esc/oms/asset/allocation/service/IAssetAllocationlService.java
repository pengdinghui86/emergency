package com.esc.oms.asset.allocation.service;

import java.util.List;
import java.util.Map;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;


public interface IAssetAllocationlService extends IBaseOptionService{
	
	public boolean addProperty(Map info);
	
	public boolean addPropertyOption(Map info);
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	public List<UTMap<String, Object>> getPropertyByCategoryId(String categoryId);
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	public List<UTMap<String, Object>> getOptionByPropertyId(String propertyId);
	
	/**
	 * 修改
	 * @param info
	 * @return
	 */
	public boolean updatePropertyByCategoryId(Map info);
	
	/**
	 * 修改
	 * @param info
	 * @return
	 */
	public boolean updateOptionByPropertyId(Map info);
	
	
	public boolean addSubCategory(Map info);
	
	public boolean addSubPropertyOption(Map info);
	
	/**
	 * 修改
	 * @param info
	 * @return
	 */
	public boolean updateSubCategoryById(Map info);
	
	/**
	 * 修改
	 * @param info
	 * @return
	 */
	public boolean updateSubPropertyById(Map info);
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	public UTMap<String, Object> getSubCategoryById(String id);
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	public List<UTMap<String, Object>> getSubPropertyById(String id);
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	public List<UTMap<String, Object>> getSubOptionById(String id);
	
	/**
	 * 删除
	 * @param info
	 * @return
	 */
	public boolean deleteSubCategory(Map info);
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	public List<UTMap<String, Object>> getSubCategoryByParentId(String parentId);
	
	public String getCategoryIdByName(Map<String,Object> params);
	
	public String getSubCategoryIdByName(Map<String,Object> params);
	
	/**
	 * 删除
	 * @param info
	 * @return
	 */
	public boolean deleteProperty(String categoryId);
	
	/**
	 * 删除
	 * @param info
	 * @return
	 */
	public boolean deleteOption(String categoryId);
	
	/**
	 * 删除
	 * @param info
	 * @return
	 */
	public boolean deleteSubProperty(String categoryId);
	
	public List<UTMap<String, Object>> getCategoryByNameAndId(String name,String id);
	
	public UTMap<String, Object> getSubCategoryByNameAndCategoryId(String name,String id);
	
	public List<UTMap<String, Object>> getSubCategoryByNameAndCategoryIdAndSubCategoryId(String name,String id,String parentId);
	
//	public UTMap<String, Object> getIdBySubCategoryNameAndCategoryName(String categoryName,String subCategoryName);
}
