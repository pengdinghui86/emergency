package com.esc.oms.outsource.outperson.service;

import org.esc.framework.service.IBaseOptionService;

/**
 * 简历-培训经历
 * @author djj
 * @date   2016-07-18
 */
public interface IOutSourcePersonResumeTrainService extends IBaseOptionService {

	public void deleteByResumeId(String id);

	public void deleteByResumeIds(String ids);


}
