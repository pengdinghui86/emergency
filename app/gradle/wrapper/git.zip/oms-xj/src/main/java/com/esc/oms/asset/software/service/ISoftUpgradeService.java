package com.esc.oms.asset.software.service;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;

public interface ISoftUpgradeService extends IBaseOptionService {

	public List<UTMap<String, Object>> getSoftUpgradeList(Map param);
	
	public boolean leadingout(List data, HttpServletRequest request,HttpServletResponse response) throws Exception;
	
	public void execute();
	
	public void upgrade(Map<String, Object> map) throws ParseException;
	
	public void disable(Map<String, Object> map);
	
	public List<String> queryFileIdsByPorjectId(String projectId);
}
