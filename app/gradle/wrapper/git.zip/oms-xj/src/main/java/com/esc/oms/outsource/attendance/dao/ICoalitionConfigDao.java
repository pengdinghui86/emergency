package com.esc.oms.outsource.attendance.dao;


import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

import java.util.List;
import java.util.Map;

/**
 * 联合考勤规则配置dao接口
 * @author owner
 *
 */
public interface ICoalitionConfigDao extends IBaseOptionDao {


	/**
	 * 检查用户是否已经配置联合考勤
	 * @param userId
	 * @param coalitionId
	 * @return 联合考勤名称 name
	 */
	public String checkCoalitionConfig(String userId, String coalitionId);

	/**
	 * 获取联合考勤的数据
	 * @param param
	 * @return
	 */
	public List<UTMap<String, Object>> getCoalitionConfigs(Map<String, Object> param);
	
}
