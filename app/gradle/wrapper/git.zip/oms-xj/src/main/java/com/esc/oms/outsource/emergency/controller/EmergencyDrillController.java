package com.esc.oms.outsource.emergency.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.outsource.emergency.service.IEmergencyDrillService;
import com.esc.oms.util.CommonUtils;
@Controller
@RequestMapping("emergencyDrill")
public class EmergencyDrillController extends BaseOptionController {


	@Resource
	private IEmergencyDrillService emergencyDrillService;
	@Resource 
	private ISysUserService userService;
	
	@Override
	public IBaseOptionService optionService() {
		return emergencyDrillService;
	}
	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			emergencyDrillService.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
    @RequestMapping(value="/saveOrUpdate",method=RequestMethod.POST)  
    @ResponseBody
    public String saveorupdate(@RequestBody Map<String,Object> map){  
    	String name = (String)map.get("name");
    	String id = (String)map.get("id");
    	try{
	    	if(id == null){
	    		Map param = new HashMap();
	    		param.put("name", name);
	    		if(emergencyDrillService.isExist(param)){
	    			throw new EscServiceException("演练名称已经存在！");
	    		}
	    		emergencyDrillService.add(map);
	    	}else{
	    		List<UTMap<String,Object>> titles = emergencyDrillService.getDrillByNameAndId(name,id);
	    		if(null != titles && titles.size() > 0){
	    			throw new EscServiceException("演练名称已经存在！");
	    		}
	    		emergencyDrillService.updateById(map);
	    	}
    	}catch(EscServiceException e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false,e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "操作成功");
    }
    
    /**
	 * 根据id查询
	 * @param param
	 * @return
	 */
	@RequestMapping(value="getById")
	@ResponseBody
	public UTMap<String, Object> defgetById(@RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = null;
    	try{
    		map = optionService().getById(param.get("id").toString());
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return map;
	}
	
	@RequestMapping(value = "leadingout")
	public void leadingout(@RequestParam Map<String, Object> param,
			HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = null;
			if(info != null) {
				jsonBean = JSONObject.fromObject(info);
			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = emergencyDrillService.getListMaps(jsonBean);
			} else {
			// 根据条件 导出当前
			//if (UTExcel.EXCELOUTTYPE_NOW == outType) {
				// getpage
				emergencyDrillService.getPageInfo(utPageBean, jsonBean);
				data = utPageBean.getRows();
			}
			if( data!= null){
				String supplierObjName = "";
				String internalObjName = "";
				for (Map<String, Object> map : data) {
					String supplierObj = (String) map.get("supplierObj");
					supplierObjName = getUserName(supplierObj, supplierObjName);
					map.put("supplierObj", supplierObjName);
					String internalObj = (String) map.get("internalObj");
					internalObjName = getUserName(internalObj, internalObjName);
					map.put("internalObj", internalObjName);
				}
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			emergencyDrillService.leadingout(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	public  String getUserName(String param, String userName) {
		if(StringUtils.isNotEmpty(param)){
			String[] ids = param.split(",");
			for (String id : ids) {
				UTMap<String, Object> user = userService.getById(id);
				if(null != user){
					userName += user.get("name")+"/"+user.get("code")+",";
				}
				continue;
			}
			
			userName = userName.substring(0, userName.length()-1);
		}
		return userName;
	}
}