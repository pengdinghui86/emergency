package com.esc.oms.asset.software.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.asset.software.dao.ISoftDisableDao;
import com.esc.oms.util.RoleUtils;

@Repository
public class SoftDisableDaoImpl extends BaseOptionDao implements
		ISoftDisableDao {

	
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params), pageBean, null);
	}
	
	
	public String getSearchSql(Map params){
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT asd.id,asl.name AS softwareId,asd.disableDate,asd.reason,asd.spare");
		sql.append(" FROM assets_software_disable asd");
		sql.append(" LEFT JOIN assets_software_library asl ON asd.softwareId = asl.id");
		sql.append(" WHERE 1=1");
		
		//数据权限过滤
		if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR,RoleUtils.ASSET_MANAGER)){
			sql.append("  and asl.chargeId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' ");
		}
		
//		if(params!=null && params.size()>0){		
//			if(params.get("softwareId")!=null &&  StringUtils.isNotEmpty(params.get("softwareId").toString())){
//				sql.append(" AND asd.softwareId = '"+params.get("softwareId").toString().trim()+"' ");
//			}
//		}
		
		if(params!=null && params.size()>0){		
			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
				sql.append(" AND asl.name like '%"+params.get("name").toString().trim()+"%' ");
			}
		}
		
		sql.append(" order by asd.createTime desc");
		return sql.toString();
	}
	
	
	@Override
	public List<UTMap<String, Object>> getSoftDisableList(Map param) {
		return super.getListBySql(getSearchSql(param));
	}

	@Override
	public List<UTMap<String, Object>> getSoftDisableListByDisableDate(Map param) {
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT * "
				+ " FROM assets_software_disable asu");
		sql.append(" WHERE asu.`disableDate` = '"+param.get("disableDate").toString().trim()+"' ");
		return super.getListBySql(sql.toString());
	}
	
	@Override
	public String getTableName() {
		return "assets_software_disable";
	}

}
