package com.esc.oms.outsource.outperson.service.impl;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.util.CellRangeAddress;
import org.esc.framework.EscPropertyHolder;
import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.message.send.MessageSend;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcelTamplate;
import org.esc.framework.utils.page.UTPageBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.outperson.dao.IRecruitmentApplicationDao;
import com.esc.oms.outsource.outperson.dao.IRecruitmentApplicationDetailDao;
import com.esc.oms.outsource.outperson.dao.IRecruitmentResumeDao;
import com.esc.oms.outsource.outperson.service.IRecruitmentApplicationDetailService;
import com.esc.oms.outsource.outperson.service.IRecruitmentResumeService;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;
import com.esc.oms.util.ParamUtils;
import com.esc.oms.util.RoleUtils;

@Service
@Transactional
public class RecruitmentApplicationDetailServiceImpl extends BaseOptionService implements IRecruitmentApplicationDetailService{

	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private IRecruitmentApplicationDetailDao dao;
	
	@Resource
	private IRecruitmentResumeService resumeService;
	
	@Resource
	private ISysParamService sysParamService;
	
	@Resource
	private IRecruitmentApplicationDao applyDao;

	@Resource
	private ISysUserService userService;
	
	@Resource
	private MessageSend messageService;
	
//	@Resource
//	private IUserTaskService userTaskService;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return dao;
	}

	/**
	 * 添加
	 * @param info
	 * @return
	 */
	@EscOptionLog(module=SystemModule.outsourcePersonRecruitment, opType=ESCLogOpType.INSERT, table="recruitment_application_detail", primaryKey="id={1.id}",option="新增类别为{1.category}，级别为{1.level}的人员申请")	
	@Override
	public boolean add(Map info){
//		String infoId = (String) info.get("infoId");
//		
//		Map infoMap = new HashMap<String,Object>();
//		infoMap.put("id", info.get("infoId"));
//		infoMap.put("status", "1");
//		applyService.updateById(infoMap);
		
		return super.add(info);		
	}
	
	@Override
	@EscOptionLog(module=SystemModule.outsourcePersonRecruitment, opType=ESCLogOpType.UPDATE, table="recruitment_application_detail", primaryKey="id={1.id}",option="修改类别为{1.category}，级别为{1.level}的人员申请")	
	public boolean updateById(Map info){
		return super.updateById(info);			
	}
	
	@Override
	@EscOptionLog(module=SystemModule.outsourcePersonRecruitment, opType=ESCLogOpType.DELETE, table="recruitment_application_detail",primaryKey="{1}",option="人力资源申请详单中，删除类别为{category}，级别为{level}的人员申请")			
	public boolean deleteById(String id){		
		//删除需求详情
		resumeService.deleteByDetailId(id);	
		return super.deleteById(id);			
	}
	
	@Override
	public boolean deleteByIds(String ids){
		//删除申请详单
		if(ids!=null&&ids.length()>0){
			String receptIds[] = ids.split(",");
			for(String receptId:receptIds){
				resumeService.deleteByDetailId(receptId);	
			}	
		}		
		return super.deleteByIds(ids);
	}
	
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map param) {
		dao.getPageInfo(pageBean, param);
	}
	
	@Override
	public UTMap<String, Object> getById(String id){
		UTMap<String, Object> rec = super.getById(id);
		Map<String,Object> param = new HashMap<String,Object>();
		param.put("applyDetailId", id);
		List<UTMap<String, Object>> detailList = resumeService.getListAll(param);
		rec.put("recommendList", detailList);
		return rec;
	}
	
	@Override
	@EscOptionLog(module=SystemModule.outsourcePersonRecruitment, opType=ESCLogOpType.UPDATE, table="recruitment_application_detail", primaryKey="id={1.id}",option="为类别为{1.category}，级别为{1.level}的人员申请推荐简历")	
	public void recommendResume(Map info){
		String status = String.valueOf(info.get("status"));
		String isSubmit = info.get("isSubmit")==null?"":String.valueOf(info.get("isSubmit"));
		//保存并提交
		if(!StringUtils.isEmpty(isSubmit)){		
			info.remove("isSubmit");					
		}
		status = IRecruitmentApplicationDetailDao.STATUS_OPERATION;
		info.put("status", status);			
		//被删除的领用物品详情
		List removeDetailList = (List) info.get("removeRecommendList");
		if(removeDetailList!=null&&removeDetailList.size()>0){
			for(int i=0;i<removeDetailList.size();i++){
				Map map = (Map) removeDetailList.get(i);
				String id = (String) map.get("id");
				resumeService.deleteById(id);
			}
		}
		List detailList = (List) info.get("recommendList");
		boolean isAdd = false;
		if(detailList!=null&&detailList.size()>0){
//			String applyId = (String) info.get("id");
			for(int i=0;i<detailList.size();i++){
				Map map = (Map) detailList.get(i);
				if(map.containsKey("id")){ //修改
				}else{ //新增
					map.put("recUserId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
					map.put("recTime", UTDate.getCurDateTime());				
					map.put("supplierId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId());
					map.put("managerFilterResult", "0");
					map.put("businessFilterResult", "0");
					map.put("status", IRecruitmentResumeDao.STATUS_MANAGER_FILTER);
					resumeService.add(map);
					isAdd = true;
				}				
			}
		}	
		super.updateById(info);
		
		//更新申请单状态
		String applyId = info.get("applyId").toString();
		Map<String,Object> apply = new HashMap<String,Object>();
		apply.put("id", applyId);
		apply.put("status", IRecruitmentApplicationDao.STATUS_OPETATION);
		applyDao.updateById(apply);
		
		if(isAdd){			
			Map<String,Object> applyInfo = applyDao.getById(applyId);
			//发送消息,通知外包管理员进行简历推荐
			Map<String,Object> param = new HashMap<String,Object>();				
			param.put("signature", RoleUtils.OUTSOURCE_MANAGER);
			String taskUserIds = userService.getUserIds(param);	
			String title = "人力资源申请【"+applyInfo.get("name")+"/"+applyInfo.get("code")+"】简历筛选提醒";
			String content = "人力资源申请【"+applyInfo.get("name")+"/"+applyInfo.get("code")+"】有新的简历待您筛选，请进入系统进行处理";
			messageService.sendMessage(taskUserIds,title,content, MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
		}	
	}
	
	@Override
	@EscOptionLog(module=SystemModule.outsourcePersonRecruitment, opType=ESCLogOpType.UPDATE, table="recruitment_application_detail", primaryKey="id={1.id}",option="关闭类别为{1.category}，级别为{1.level}的人员申请")		
	public void close(Map<String, Object> info) {
		String id = info.get("id").toString();
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("id", id);
		map.put("status", IRecruitmentApplicationDetailDao.STATUS_FINISH);
		super.updateById(map);
	}
	
	@Override
	public void closeByApplyId(String applyId) {
		dao.closeByApplyId(applyId);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	@Override
	public List<UTMap<String, Object>> getListAll(Map params){
		return dao.getListAll(params);
	}
	
	/**
	 * 根据领用记录的条件查询领用详单
	 * @param params
	 */
	@Override
	public List<UTMap<String, Object>> getListAllByParentParam(Map params){
		return dao.getListAllByParentParam(params);
	}
	
	/**
	 * 根据领用记录id（applyId）删除
	 * @param infoId
	 * @return
	 */
	@Override
	public boolean deleteByApplyId(String applyId){
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("applyId", applyId);
		return dao.deletes(map);
	}	

	/**
	 * 导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	@Override
	public boolean leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String path = EscPropertyHolder.instance.getProperty("excelOutTamplate.recruitmentApplicationDetailLeadOut");
		String[] fields = new String[] { 
				"row_num",
				IRecruitmentApplicationDao.FIELD_NAME,											
				IRecruitmentApplicationDao.FIELD_CODE,
				IRecruitmentApplicationDao.FIELD_CREATE_USER,
				IRecruitmentApplicationDao.FIELD_APPLY_DEPART_NAME,
				IRecruitmentApplicationDao.FIELD_APPLY_DATE,
				IRecruitmentApplicationDao.FIELD_STATUS,
				IRecruitmentApplicationDao.FIELD_APPLY_REASON,
				IRecruitmentApplicationDao.FIELD_APPLY_REASON_REMARK,
				IRecruitmentApplicationDetailDao.FIELD_CATEGORY,
				IRecruitmentApplicationDetailDao.FIELD_LEVEL,
				IRecruitmentApplicationDetailDao.FIELD_NUM,
				IRecruitmentApplicationDetailDao.FIELD_PLACE,
				IRecruitmentApplicationDetailDao.FIELD_HILLOCK_DATE,
				IRecruitmentApplicationDetailDao.FIELD_FREED_DATE,
				IRecruitmentApplicationDetailDao.FIELD_STATUS
		};
		// 获取导出文件名称
		int l = path.lastIndexOf("/");
		int j = path.lastIndexOf("--");
		String fileName = "";
		String title = "";
		if (j > 0) {
			fileName = path.substring(j + 2);
			title = fileName;
			path = path.substring(0, j);
			fileName = fileName + path.substring(path.lastIndexOf("."));
		} else {
			fileName = path.substring(l + 1);
			title = fileName.substring(0, fileName.lastIndexOf("."));
		}
		// 创建模板对象
		UTExcelTamplate tamplate = UTExcelTamplate.getInstance();
		// 加载模板
		tamplate.readTemplateByClasspath(path);
		// 模板常量参数赋值
		Map<String, String> map = new HashMap<String, String>();
		map.put("title", title);
		map.put("time", "日期：" + UTDate.getCurDate());
		tamplate.replaceFinalData(map);
		
		//替换下拉的值
		Map<String, String> fieldAndParamType = new HashMap<String, String>();
		fieldAndParamType.put(IRecruitmentApplicationDao.FIELD_APPLY_REASON, "recruitmentApplicationReason");
		fieldAndParamType.put(IRecruitmentApplicationDao.FIELD_IS_LIMIT_SUPPLIER, "YesNo");
		fieldAndParamType.put(IRecruitmentApplicationDao.FIELD_STATUS, "recruitmentApplicationStatus");	
		sysParamService.changeParamData(data, fieldAndParamType);	
		
		Map<String, String> detailParamType = new HashMap<String, String>();
		detailParamType.put(IRecruitmentApplicationDetailDao.FIELD_STATUS, "recruitmentApplicationDetailStatus");
		
		int startDataRow = 2;
		// 循环填充excel
		for(int num=0;num<data.size();num++){
			UTMap<String, Object>  utmap = (UTMap<String, Object>) data.get(num);				
			List<UTMap<String, Object>> classifys = (List<UTMap<String, Object>>) utmap.get("detailList");
			if(classifys==null){
				classifys = new ArrayList<UTMap<String, Object>>();
			}			
			sysParamService.changeParamData(classifys, detailParamType);	
			for (UTMap<String, Object> info : classifys) {
				tamplate.createNewRow();
				tamplate.createCell(num + 1); // 第一列是序号
				
				for (int ci = 1; ci <= 8; ci++){
					String f = fields[ci];
					String v = utmap.get(f) != null ? utmap.get(f).toString() : "";
//					//类别转换
//					if(f.equals(ILowvalueApplyDao.FIELD_TYPE)){
//						v = getTypeDesc(v);
//					}						
//					//状态转换	
//					if(f.equals(ILowvalueApplyDao.FIELD_STATUS)){
//						v = getStatusDesc(v);
//					}
					tamplate.createCell(v);					
				}
				//分类和级别
				for (int i = 9; i < fields.length; i++) {
					String f = fields[i];
					String v = info.get(f) != null ? info.get(f).toString() : "";
//					//确认状态转换	
//					if(f.equals(ILowvalueApplyDetailDao.FIELD_CONFIRM_STATUS)){
//						v = getConfirmStatusDesc(v);
//					}
					tamplate.createCell(v);
				}
			}
			//合并单元格，开始行到结束行，开始单元格到结束单元格
			int endDataRow = startDataRow + classifys.size() - 1;
			for (int ci = 0; ci <= 8; ci++){
				tamplate.addMergedRegion(new CellRangeAddress(
						startDataRow, //first row (0-based)  from 行     
						endDataRow, //last row  (0-based)  to 行     
						ci, //first column (0-based) from 列     
						ci //last column  (0-based)  to 列     
	        	));
			}	
			startDataRow = endDataRow + 1;
		}	
		tamplate.setSheet(new String[]{title});
		
		try {
			fileName = new String( fileName.getBytes("GBK"), "ISO8859-1" ) ;
		} catch (UnsupportedEncodingException e) {
			logger.error("UnsupportedEncodingException",e);
		}
		try {
			OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
			response.addHeader("Content-Disposition", "attachment;filename=" + fileName);
			response.setContentType("application/octet-stream");
			tamplate.writeToStream(toClient);
		} catch (IOException e) {
			logger.error("IOException",e);
		}
		return true;
	}

}