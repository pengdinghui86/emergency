package com.esc.oms.asset.mediumDestroy.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.service.ISysOrgService;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.timetask.anotations.CronTimeTask;
import org.esc.framework.timetask.anotations.TimeTaskMark;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.workflow.service.IWorkflowCode;
import org.esc.framework.workflow.service.IWorkflowEngine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.asset.mediumDestroy.dao.IAssetDestroyDao;
import com.esc.oms.asset.mediumDestroy.service.IAssetDestroyService;
import com.esc.oms.asset.overview.service.IAssetsTrackInfoService;
import com.esc.oms.asset.physical.service.IAssetPhysicalService;
import com.esc.oms.asset.place.service.IAssetPlaceService;
import com.esc.oms.asset.transfer.dao.IAssetTransferDao;
import com.esc.oms.asset.transfer.service.IAssetTransferService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;

@Service
@Transactional
@TimeTaskMark
public class AssetDestroyServiceImpl extends BaseOptionService implements IAssetDestroyService{
	
	@Resource
	private IAssetDestroyDao assetDestroyDao;
	@Resource
	private IWorkflowEngine workflowEngine;

	@Resource
	private ISysUserService sysUserService;

	protected Logger logger = LoggerFactory.getLogger(getClass());
	public static final String STATUS_NOT_SUBMIT = "1";	// 未提交
	public static final String STATUS_AUDITING = "2";	// 审批中
	public static final String STATUS_FINISH = "3";	// 已完成
	public static final String STATUS_REJECT = "4";	// 驳回
	public static final String STATUS_APPROVAL  = "5";	// 待审批
	public static final String STATUS_STOP  = "6";	// 被终止
	
	
	
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return assetDestroyDao;
	}
	
	
	@Override
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	@EscOptionLog(module=SystemModule.assetTransfer, opType=ESCLogOpType.INSERT, table="assets_medium_destroy",option="新增名称为{name}的资产介质销毁记录。")
	public boolean add(Map info){
		String  status=(String)info.get(IAssetTransferDao.FIELD_STATUS);
		if(StringUtils.isEmpty(status)) {
			info.put(IAssetTransferDao.FIELD_STATUS, STATUS_NOT_SUBMIT);
		}
		info.put("createUserId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
		return	getOptionDao().add(info);
	}
	
	public boolean addDestroyByRetirement(List<Map> assetList) {
		List<Map> saveList=new ArrayList<>();
		for (Map map : assetList) {
			String name=(String)map.get(IAssetDestroyDao.FIELD_NAME);
			String code=(String)map.get(IAssetDestroyDao.FIELD_CODE);
			String assetId=(String)map.get("id");
			String isDestroy=(String)map.get("isDestroy").toString();
			
			if(StringUtils.equals("1",isDestroy)) {
				Map<String,Object> item=new HashMap<String,Object>();
				item.put(IAssetDestroyDao.FIELD_NAME,name);
				item.put(IAssetDestroyDao.FIELD_CODE,code);
				item.put(IAssetDestroyDao.FIELD_ASSETID,assetId);
				item.put(IAssetDestroyDao.FIELD_STATUS,STATUS_NOT_SUBMIT);
				item.put("createUserId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
				saveList.add(item);
			}
		}
		
		return	saveList.size()>0?getOptionDao().adds(saveList):true;
	}
	
	@Override
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	@EscOptionLog(module=SystemModule.assetDestroy, opType=ESCLogOpType.UPDATE, table="assets_medium_destroy",option="修改名称为{name}的资产介质销毁记录。")
	public boolean updateById(Map info){
		if(!info.containsKey("id")){
			throw new EscServiceException("根据id 修改map中不存在key=id");
		}

		String  status=(String)info.get(IAssetDestroyDao.FIELD_STATUS);
		if(StringUtils.equals(STATUS_REJECT, status)) {
			info.put(IAssetDestroyDao.FIELD_STATUS, STATUS_NOT_SUBMIT);
		}
		return getOptionDao().updateById(info);
	}
	


	@EscOptionLog(module=SystemModule.assetDestroy, opType=ESCLogOpType.DELETE, table="assets_medium_destroy",option="删除名称为{name}的资产介质销毁记录。")
	public boolean deleteById(String id){
		 boolean flag = true;
		if(flag){
			flag = getOptionDao().deleteByIds(id);
		}
		return	flag;
	}
	
	@EscOptionLog(module=SystemModule.assetDestroy, opType=ESCLogOpType.DELETES, table="assets_medium_destroy",option="删除名称为{name}的资产介质销毁记录。")
	public boolean deleteByIds(String ids){
		boolean flag = false;
			String[] detIds = ids.split(",");
			flag = getOptionDao().deleteByIds(ids);
		
		return flag;
	}


	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		return super.getById(id);
	}
	

	
	@Override
	public void getPendApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) {
		assetDestroyDao.getPendApprovalPageInfo(pageBean, params);
	}

	@Override
	public void getAlreadyApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) {
		assetDestroyDao.getAlreadyApprovalPageInfo(pageBean, params);
	}

	

	@Override
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public void submit(Map<String,Object> map) {
		map.put("status", STATUS_APPROVAL);
		boolean flog=true;
		if(map.get("id") == null){
			flog=add(map);
    	}
		else{
			flog=updateById(map);
    	}
		String recordId =map.get("id").toString();
		//启动流程
		runInstanceId(recordId);
	}
	

	private void runInstanceId(String recordId){
		
		UTMap<String, Object> des = assetDestroyDao.getById(recordId);
		String departId = "";
		if (null != des) {
			departId = (String) des.get("departId");
		}
		Map<String, Object> formMap = new HashMap<String, Object>();
		UTMap<String, Object> curUserMap = sysUserService.getById(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
		Object orgId = null;
		if (null != curUserMap && !curUserMap.isEmpty()) {
			orgId = curUserMap.get("orgId");
		}
		formMap.put("2", departId);//销毁部门
		formMap.put("1", orgId);//申请人所在部门
		//启动流程实例
		String workflowInstanceId = workflowEngine.runInstance(IWorkflowCode.PHYSICAL_ASSET_DESTORY, recordId, formMap);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("workflowInstanceId", workflowInstanceId);
		assetDestroyDao.updateById(map);
	}

	public void finishAudit(String recordId) {
	    Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("status", STATUS_FINISH);
		
		//自动生成介质销毁单号
		int destroyId = 0;
		Calendar date = Calendar.getInstance();
        int year = date.get(Calendar.YEAR);
		int currentId = assetDestroyDao.getMaxDestroyId();
		if(currentId > 0)
		{
			int dbYear = Integer.parseInt(String.valueOf(currentId).substring(0, 4));
			if(dbYear < year)
			{
				destroyId = year * 1000 + 1;
			}
			else {
				int tail = Integer.parseInt(String.valueOf(currentId).substring(4, (String.valueOf(currentId)).length()));
				if(tail + 1 > 999)
					destroyId = Integer.parseInt(String.valueOf(currentId) + String.valueOf(tail + 1));
				else {
					destroyId = dbYear * 1000 + tail + 1;
				}
			}
		}
		else
			destroyId = year * 1000 + 1;
		map.put("destroyId", destroyId);
		
		assetDestroyDao.updateById(map);
	}
	
	@Override
	public void rejectAudit(String recordId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("status", STATUS_REJECT);
		assetDestroyDao.updateById(map);
	}
	
	@Override
	public void terminate(String recordId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("status", STATUS_STOP);
		assetDestroyDao.updateById(map);
	}
	
	@Override
	public boolean optionNode(String workflowCode, String businessRecordId,String nodeName, String linkName) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", businessRecordId);
		map.put("status", STATUS_AUDITING);
	 return	assetDestroyDao.updateById(map);
	}


	@Override
	public boolean leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String[] fileds = new String[] { 
				IAssetDestroyDao.FIELD_NAME,
				"destroyCode",
				"pnCode",
				IAssetDestroyDao.FIELD_SOURCE,
				IAssetDestroyDao.FIELD_MEDIUMTYPE,
				IAssetDestroyDao.FIELD_CLASSIFICATION_CODE,
				"destroyName",
				"destroyModel",
				"destroyAddressName",
				IAssetDestroyDao.FIELD_DESTROY_MODE,
				"departName",
				IAssetDestroyDao.FIELD_DESTROY_TIME,
				IAssetDestroyDao.FIELD_DESTROY_REASON,
				IAssetDestroyDao.FIELD_STATUS
				
		};
		if (null != data && !data.isEmpty()) {
			for (int i=0;i<data.size(); i++) {
				Map item = (Map) data.get(i);
				item.put(IAssetDestroyDao.FIELD_DESTROY_TIME, CommonUtils.replaceAll((String)item.get(IAssetDestroyDao.FIELD_DESTROY_TIME), "-", "/"));
			}
		}
		String tamlate="excelOutTamplate.assetDestroy";	
		return	UTExcel.leadingout( fileds, data, tamlate, request,response);
	}


	@Override
	public List<UTMap<String, Object>> getAssetsList(Map param) {
		// TODO Auto-generated method stub
		return assetDestroyDao.getAssetsList(param);
	}


	@Override
	public List<UTMap<String, Object>> getAssetsList() {
		// TODO Auto-generated method stub
		return assetDestroyDao.getAssetsList();
	}


}