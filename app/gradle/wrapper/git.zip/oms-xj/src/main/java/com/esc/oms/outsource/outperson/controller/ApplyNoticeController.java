package com.esc.oms.outsource.outperson.controller;


import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.outsource.outperson.service.IApplyNoticeService;

/**
 * 申请通知控制器
 * @author smq
 * @date   2016-7-9 上午10:37:59
 */
@Controller
@RequestMapping("outsource/person/applynotice")
public class ApplyNoticeController extends BaseOptionController {

	@Resource
	private IApplyNoticeService noticeService;
	
	@Override
	public IBaseOptionService optionService() {
		return noticeService;
	}
	
	@RequestMapping(value="reSend", method=RequestMethod.POST)
	@ResponseBody
	public String reSend(@RequestBody Map<String, Object> param) {
		boolean flag = noticeService.reSend(param);
		if (flag) {
			return UTJsonUtils.getJsonMsg(true, "操作成功");
		}
		return UTJsonUtils.getJsonMsg(false, "操作失败");
	}

	
}