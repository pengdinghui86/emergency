package com.esc.oms.asset.allocation.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.asset.allocation.dao.IAssetAllocationDao;
import com.esc.oms.asset.allocation.service.IAssetAllocationlService;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;

@Service
@Transactional
public class AssetAllocationServiceImpl extends BaseOptionService implements IAssetAllocationlService{

	@Resource
	private IAssetAllocationDao assetAllocationDao;

	@Override
	public IBaseOptionDao getOptionDao() {
		return assetAllocationDao;
	}
	
	
	@Override
	@EscOptionLog(module=SystemModule.assetAllocation, opType=ESCLogOpType.INSERT, table="assets_material_category",option="新增名称为{name}的资产类型信息。")
	public boolean add(Map info){
		Map param = new HashMap();
		param.put("name", info.get("name"));
		if(assetAllocationDao.isExist(param)){
			throw new EscServiceException("资产大类"+info.get("name")+"已经存在！");
		}
		return	getOptionDao().add(info);
	}
	
	@Override
	@EscOptionLog(module=SystemModule.assetAllocation, opType=ESCLogOpType.UPDATE, table="assets_material_category",option="更新名称为{name}的资产类型信息。")
	public boolean updateById(Map info){
		if(!info.containsKey("id")){
			throw new EscServiceException("根据id 修改map中不存在key=id");
		}
		return getOptionDao().updateById(info);
	}
	
	@Override
	public boolean addProperty(Map info) {
		return assetAllocationDao.addProperty(info);
	}

	@Override
	public boolean addPropertyOption(Map info) {
		return assetAllocationDao.addPropertyOption(info);
	}

	@Override
	public List<UTMap<String, Object>> getPropertyByCategoryId(String categoryId) {
		return assetAllocationDao.getPropertyByCategoryId(categoryId);
	}

	@Override
	public List<UTMap<String, Object>> getOptionByPropertyId(String propertyId) {
		return assetAllocationDao.getOptionByPropertyId(propertyId);
	}

	@Override
	public boolean updatePropertyByCategoryId(Map info) {
		return assetAllocationDao.updatePropertyByCategoryId(info);
	}

	@Override
	public boolean updateOptionByPropertyId(Map info) {
		return assetAllocationDao.updateOptionByPropertyId(info);
	}

	@Override
	@EscOptionLog(module=SystemModule.assetAllocation, opType=ESCLogOpType.INSERT, table="assets_material_sub_category",option="新增名称为{name}的资产级别信息。")
	public boolean addSubCategory(Map info) {
//		Map param = new HashMap();
////		param.put("name", info.get("name"));
		if(assetAllocationDao.checkSubCategory(info)){
			throw new EscServiceException("此资产大类的资产小类中已经存在"+info.get("name"));
		}
		return assetAllocationDao.addSubCategory(info);
	}

	@Override
	public boolean addSubPropertyOption(Map info) {
		return assetAllocationDao.addSubPropertyOption(info);
	}

	@Override
	@EscOptionLog(module=SystemModule.assetAllocation, opType=ESCLogOpType.UPDATE, table="assets_material_sub_category",option="更新名称为{name}的资产级别信息。")
	public boolean updateSubCategoryById(Map info) {
		return assetAllocationDao.updateSubCategoryById(info);
	}

	@Override
	public boolean updateSubPropertyById(Map info) {
		return assetAllocationDao.updateSubPropertyById(info);
	}

	@Override
	public List<UTMap<String, Object>> getSubOptionById(String id) {
		return assetAllocationDao.getSubOptionById(id);
	}

	@Override
	public UTMap<String, Object> getSubCategoryById(String id) {
		return assetAllocationDao.getSubCategoryById(id);
	}

	@Override
	public List<UTMap<String, Object>> getSubPropertyById(String id) {
		return assetAllocationDao.getSubPropertyById(id);
	}
	
	@Override
	@EscOptionLog(module=SystemModule.assetAllocation, opType=ESCLogOpType.DELETE, table="assets_material_sub_category",option="删除名称为{name}的资产分类信息。")
	public boolean delete(Map info) {
		boolean flag = false;
		String parentId = (String) info.get("parentId");
		Map map = new HashMap();
		map.put("id", parentId);
		if(StringUtils.isNotEmpty(parentId)){
//			map = assetAllocationDao.getById(parentId);
			flag = assetAllocationDao.delete(map);
			if(null != map){
				List<UTMap<String, Object>> subCategory = assetAllocationDao.getSubCategoryByParentId(parentId);//资产小类
				if(null != subCategory && subCategory.size() > 0){
					if(flag){
						flag = assetAllocationDao.deleteSubCategoryByParentId(parentId);//删除资产小类
					}
					if(null != subCategory && subCategory.size() > 0){
						for (UTMap<String, Object> subCate : subCategory) {
							List<UTMap<String, Object>> subPropertyList = assetAllocationDao.getSubPropertyById(subCate.get("id").toString());
									if(null != subPropertyList && subPropertyList.size() > 0){
										flag = assetAllocationDao.deleteProperty(subCate.get("id").toString());//删除资产小类下的扩展属性
										for (Map<String, Object> utMap : subPropertyList) {
											List<UTMap<String, Object>> options = assetAllocationDao.getOptionByPropertyId(utMap.get("id").toString());
											if(null != options && options.size() > 0){
												flag = assetAllocationDao.deleteOption(utMap.get("id").toString());//删除资产小类下的扩展属性的值
											}
										}
									}
						}
					}
					
				}
					List<UTMap<String, Object>> propertyList = assetAllocationDao.getPropertyByCategoryId(map.get("id").toString());
					if(null != propertyList && propertyList.size() > 0){
						flag = assetAllocationDao.deleteProperty(map.get("id").toString());//级联删除扩展属性
						for (Map<String, Object> utMap : propertyList) {
							List<UTMap<String, Object>> options = assetAllocationDao.getOptionByPropertyId(utMap.get("id").toString());
							if(null != options && options.size() > 0){
								flag = assetAllocationDao.deleteOption(utMap.get("id").toString());//删除资产小类下的扩展属性的值
							}
						}
				}
			}
		}
		return flag;
	}

	@Override
	public boolean deleteSubCategory(Map info) {
		boolean flag = false;
		String id = (String) info.get("id");
		UTMap<String, Object> map = null;
		if(StringUtils.isNotEmpty(id)){
			flag = assetAllocationDao.deleteSubCategory(id);//删除资产小类
			List<UTMap<String, Object>> subPropertyList = assetAllocationDao.getSubPropertyById(id);//获取资产小类下的扩展属性
					if(null != subPropertyList && subPropertyList.size() > 0){
						if(flag){
							flag = assetAllocationDao.deleteSubProperty(id);//删除资产小类下的扩展属性
						}
						for (Map<String, Object> utMap : subPropertyList) {
							List<UTMap<String, Object>> options = assetAllocationDao.getOptionByPropertyId(utMap.get("id").toString());
							if(null != options && options.size() > 0){
								flag = assetAllocationDao.deleteOption(utMap.get("id").toString());//删除资产小类下的扩展属性的值
							}
						}
					}
		}
		return flag;
	}

	@Override
	public List<UTMap<String, Object>> getSubCategoryByParentId(String parentId) {
		return assetAllocationDao.getSubCategoryByParentId(parentId);
	}

	@Override
	public String getCategoryIdByName(Map<String, Object> params) {
		return assetAllocationDao.getCategoryIdByName(params);
	}

	@Override
	public String getSubCategoryIdByName(Map<String, Object> params) {
		return assetAllocationDao.getSubCategoryIdByName(params);
	}


	@Override
	public boolean deleteProperty(String categoryId) {
		return assetAllocationDao.deleteProperty(categoryId);
	}


	@Override
	public boolean deleteOption(String categoryId) {
		return assetAllocationDao.deleteOption(categoryId);
	}


	@Override
	public boolean deleteSubProperty(String categoryId) {
		return assetAllocationDao.deleteSubProperty(categoryId);
	}


	@Override
	public List<UTMap<String, Object>> getCategoryByNameAndId(String name,
			String id) {
		return assetAllocationDao.getCategoryByNameAndId(name, id);
	}


	@Override
	public UTMap<String, Object> getSubCategoryByNameAndCategoryId(
			String name, String id) {
		return assetAllocationDao.getSubCategoryByNameAndCategoryId(name, id);
	}


	@Override
	public List<UTMap<String, Object>> getSubCategoryByNameAndCategoryIdAndSubCategoryId(
			String name, String id, String parentId) {
		return assetAllocationDao.getSubCategoryByNameAndCategoryIdAndSubCategoryId(name,id, parentId);
	}


//	@Override
//	public UTMap<String, Object> getIdBySubCategoryNameAndCategoryName(
//			String categoryName, String subCategoryName) {
//		return assetAllocationDao.getIdBySubCategoryNameAndCategoryName(categoryName, subCategoryName);
//	}
}