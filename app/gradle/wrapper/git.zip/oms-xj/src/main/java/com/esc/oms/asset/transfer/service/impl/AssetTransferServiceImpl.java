package com.esc.oms.asset.transfer.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.esc.oms.asset.overview.service.IAssetsTrackInfoService;
import com.esc.oms.asset.physical.service.IAssetPhysicalService;
import com.esc.oms.asset.place.service.IAssetPlaceService;
import com.esc.oms.asset.transfer.dao.IAssetTransferDao;
import com.esc.oms.asset.transfer.service.IAssetTransferService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.service.ISysOrgService;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.timetask.anotations.CronTimeTask;
import org.esc.framework.timetask.anotations.TimeTaskMark;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.workflow.service.IWorkflowCode;
import org.esc.framework.workflow.service.IWorkflowEngine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service
@Transactional
@TimeTaskMark
public class AssetTransferServiceImpl extends BaseOptionService implements IAssetTransferService{
	
	@Resource
	private IAssetTransferDao assetTransferDao;
	@Resource
	private IAssetPhysicalService assetPhysicalService;
	@Resource
	private IAssetsTrackInfoService assetsTrackInfoService;
	@Resource
	private ISysUserService sysUserService;
	@Resource
	private ISysOrgService sysOrgService;
	@Resource
	private IAssetPlaceService assetPlaceService;
	@Resource
	private IWorkflowEngine workflowEngine;


	protected Logger logger = LoggerFactory.getLogger(getClass());
	public static final String STATUS_NOT_SUBMIT = "1";	// 未提交(未转移)
	public static final String STATUS_AUDITING = "2";	// 审批中
	public static final String STATUS_FINISH = "3";	// 已完成
	public static final String STATUS_REJECT = "4";	// 驳回
	public static final String STATUS_APPROVAL  = "5";	// 待审批
	public static final String STATUS_STOP  = "6";	// 被终止
	//public static final String STATUS_NO_AUDIT  = "7";	// 不需要审批
	
	
	private static final String AUDIT_YES  = "1";	
	private static final String AUDIT_NO  = "0";	
	
	private boolean isAudit(String auditStr) {
		if(StringUtils.equals(AUDIT_YES, auditStr)) {
			return true;
		}
		return false;
	}
	
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return assetTransferDao;
	}
	
	
	@Override
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	@EscOptionLog(module=SystemModule.assetTransfer, opType=ESCLogOpType.INSERT, table="assets_material_allocation",option="新增名称为{title}的资产转移信息。")
	public boolean add(Map info){
		String  isAuditStr=info.get(IAssetTransferDao.FIELD_ISAUDIT).toString();
		String  status=(String)info.get(IAssetTransferDao.FIELD_STATUS);
		String allocationDate = info.get("allocationDate").toString();
    	boolean flag = false;
    	
		if(StringUtils.isEmpty(status)) {
			info.put(IAssetTransferDao.FIELD_STATUS, STATUS_NOT_SUBMIT);
			//不需要审核
			if(!isAudit(isAuditStr)) {
				info.put(IAssetTransferDao.FIELD_STATUS, STATUS_FINISH);
			}
		}
	
		info.put("createUserId", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());
		return	getOptionDao().add(info);
	}
	
	
	
	@Override
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	@EscOptionLog(module=SystemModule.assetTransfer, opType=ESCLogOpType.UPDATE, table="assets_material_allocation",option="修改名称为{title}的资产转移信息。")
	public boolean updateById(Map info){
		if(!info.containsKey("id")){
			throw new EscServiceException("根据id 修改map中不存在key=id");
		}

		String  status=(String)info.get(IAssetTransferDao.FIELD_STATUS);
		String  isAuditStr=(String)info.get(IAssetTransferDao.FIELD_ISAUDIT);
		//不需要审核
		if(!isAudit(isAuditStr)) {
			info.put(IAssetTransferDao.FIELD_STATUS, STATUS_FINISH);
		}
		return getOptionDao().updateById(info);
	}
	

	@Override
	public boolean addRelation(Map info) {
		return assetTransferDao.addRelation(info);
	}

	@Override
	public boolean deleteAssetsById(String id) {
		return assetTransferDao.deleteAssetsById(id);
	}

	@EscOptionLog(module=SystemModule.assetTransfer, opType=ESCLogOpType.DELETE, table="assets_material_allocation",option="删除名称为{title}的资产转移信息。")
	public boolean deleteById(String id){
		 boolean flag = assetTransferDao.deleteAssetsById(id);
		if(flag){
			flag = getOptionDao().deleteByIds(id);
		}
		return	flag;
	}
	
	@EscOptionLog(module=SystemModule.assetTransfer, opType=ESCLogOpType.DELETES, table="assets_material_allocation",option="删除名称为{title}的资产转移信息。")
	public boolean deleteByIds(String ids){
		boolean flag = false;
			String[] detIds = ids.split(",");
			flag = getOptionDao().deleteByIds(ids);
			if(flag && detIds.length > 0){
				for (String id : detIds) {
					flag = assetTransferDao.deleteAssetsById(id);
				}
			}
		return flag;
	}


	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		return super.getById(id);
	}
	
	@Override
	public List<UTMap<String, Object>> getAssetsById(String id) {
		return assetTransferDao.getAssetsById(id);
	}
	
	@Override
	public void getPendApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) {
		assetTransferDao.getPendApprovalPageInfo(pageBean, params);
	}

	@Override
	public void getAlreadyApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) {
		assetTransferDao.getAlreadyApprovalPageInfo(pageBean, params);
	}

	

	@Override
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public void submit(Map<String,Object> map) {
		map.put("status", STATUS_APPROVAL);
		boolean flog=true;
		if(map.get("id") == null){
			flog=add(map);
    	}
		else{
			flog=updateById(map);
    	}
		String recordId =map.get("id").toString();
		//启动流程
		runInstanceId(recordId);
	}
	

	private void runInstanceId(String recordId){
		//启动流程实例
		String workflowInstanceId = workflowEngine.runInstance(IWorkflowCode.PHYSICAL_ASSET_TRANSFER, recordId);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("workflowInstanceId", workflowInstanceId);
		assetTransferDao.updateById(map);
	}

	public void finishAudit(String recordId) {
	    Map<String, Object> map = assetTransferDao.getById(recordId);
		map.put("status", STATUS_FINISH);
		String allocationDate = map.get("allocationDate").toString();
    	List<UTMap<String, Object>> assetsList = assetTransferDao.getAssetsById(recordId);
		
		try {
			if(compareDate(allocationDate) && null != assetsList && assetsList.size() > 0){
				map.put(IAssetTransferDao.FIELD_OVERSTATUS,"已转移");
				updateAssetsInfo(assetsList, map);
			}
			else{
				map.put(IAssetTransferDao.FIELD_OVERSTATUS,"未转移");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
		 Map<String, Object> item = assetTransferDao.getById(recordId);
		 item.put("id", recordId);
		 item.put("status", map.get("status"));
		 item.put(IAssetTransferDao.FIELD_OVERSTATUS, map.get(IAssetTransferDao.FIELD_OVERSTATUS));
		
		assetTransferDao.updateById(item);
	
	}
	
	@Override
	public void rejectAudit(String recordId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("status", STATUS_REJECT);
		assetTransferDao.updateById(map);
	}
	
	//流程终止不进行 供应商退出状态的修改
	@Override
	public void terminate(String recordId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", recordId);
		map.put("status", STATUS_STOP);
		assetTransferDao.updateById(map);
	}
	
	@Override
	public boolean optionNode(String workflowCode, String businessRecordId,String nodeName, String linkName) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", businessRecordId);
		map.put("status", STATUS_AUDITING);
	 return	assetTransferDao.updateById(map);
	}


	@Override
	public boolean leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String[] fileds = new String[] { 
				IAssetTransferDao.FIELD_TITLE,
				IAssetTransferDao.FIELD_ALLOCATIONDATE,
				IAssetTransferDao.FIELD_NEWDEPARTID,
				IAssetTransferDao.FIELD_NEWCHARGEID,
				IAssetTransferDao.FIELD_NEWPLACE,
				IAssetTransferDao.FIELD_REASON,
				IAssetTransferDao.FIELD_CREATEUSERID,
				IAssetTransferDao.FIELD_CREATETIME,
				IAssetTransferDao.FIELD_OVERSTATUS
		};
		if (null != data && !data.isEmpty()) {
			for (int i=0;i<data.size();i++) {
				UTMap<String, Object> item = (UTMap<String, Object>) data.get(i);
				item.put(IAssetTransferDao.FIELD_ALLOCATIONDATE, 
						CommonUtils.replaceAll((String)item.get(IAssetTransferDao.FIELD_ALLOCATIONDATE), "-", "/"));
				item.put(IAssetTransferDao.FIELD_CREATETIME, 
						CommonUtils.replaceAll((String)item.get(IAssetTransferDao.FIELD_CREATETIME), "-", "/"));
			}
		}
		String tamlate="excelOutTamplate.assetTransfer";	
		return	UTExcel.leadingout( fileds, data, tamlate, request,response);
	}

	@Override
	public List<UTMap<String, Object>> getAssetsList(Map param) {
		return assetTransferDao.getAssetsList(param);
	}

	@CronTimeTask(description="每天凌晨定时更新当天需要转移的资产信息",cron="0 30 1 * * ?")
	@Override
	public void generate() {
		logger.info("开始定时更新当天需要转移的资产信息！=========================================================");
		UTMap<String,Object> map = new UTMap<String,Object>();
		map.put("allocationDate", new Date());
		//不需要审核的 及已经审核完成
	
		map.put("statusStr",STATUS_FINISH);
		map.put("overStatus","未转移");
		
		List<UTMap<String, Object>> list = assetTransferDao.getListMaps(map);
		if(list != null){
			for (UTMap<String, Object> utMap : list) {
				utMap.put(IAssetTransferDao.FIELD_OVERSTATUS, "已转移");
				List<UTMap<String, Object>> assetsList = assetTransferDao.getAssetsById((String)utMap.get("id"));
				updateAssetsInfo(assetsList,utMap,true);
				assetTransferDao.updateById(utMap);
			}
		}
		logger.info("成功定时更新当天需要转移的资产信息！=========================================================");
	}

	public boolean updateAssetsInfo(List assetsList,Map<String, Object> map) {
		return updateAssetsInfo(assetsList, map, false);
	}
	
	private boolean updateAssetsInfo(List assetsList,Map<String, Object> map,boolean isTimeTask) {
		String ids = "";
		boolean flag  = false;
		String newPlace = (String)map.get("newPlace");
		String newDepartId = (String)map.get("newDepartId");
		String newChargeId = (String)map.get("newChargeId");
		for (Object obj : assetsList) {
			Map utMap = (Map)obj;
			ids += "'"+utMap.get("id").toString()+"',";
			
//			UTMap<String, Object> ut = new UTMap<String,Object>();
			UTMap<String,Object> trackModele = new UTMap<String,Object>();
			if(isTimeTask) {
				trackModele.put("changeUserId",map.get("createUserId"));
			}
			UTMap<String,Object> assetsInfo = assetPhysicalService.getById(String.valueOf(utMap.get("id")));
//			ut.put("allocationId", map.get("id"));
//			ut.put("assetsId", utMap.get("id"));
//			assetTransferService.addRelation(ut);
			if("已转移".equals((String)map.get(IAssetTransferDao.FIELD_OVERSTATUS))){
				//--------资产轨迹  资产变更--------
				trackModele.put("assetsId", utMap.get("id"));
				trackModele.put("type", 1);
				trackModele.put("changeType","变更");
				trackModele.put("changeRemark", map.get("reason"));
				trackModele.put("changeTime", map.get("allocationDate"));
				//====资产责任人变更=====
				if(null != map.get("newChargeId") && ""!= map.get("newChargeId")){
					UTMap<String,Object> track = new UTMap<String,Object>(trackModele);
					UTMap<String,Object> person = sysUserService.getById(String.valueOf(map.get("newChargeId")));
					if((null == map.get("newDepartId") || StringUtils.isEmpty(String.valueOf(map.get("newDepartId")))) && (null != assetsInfo)){
						track.put("departId", assetsInfo.get("resDepartId"));
					}else{
						track.put("departId", map.get("newDepartId"));
					}
					track.put("userId", map.get("newChargeId"));
					if(null != assetsInfo.get("resUserName2")){
						track.put("changeRemark", "责任人由【"+assetsInfo.get("resUserName2")+"】变更为【"+person.get("name")+"】");
					}else{
						track.put("changeRemark", "责任人变更为【"+person.get("name")+"】");
					}
					assetsTrackInfoService.add(track);
				}
				//====资产责任部门变更====
				if(null != map.get("newDepartId") && ""!= map.get("newDepartId")){

					UTMap<String,Object> track = new UTMap<String,Object>(trackModele);
					UTMap<String,Object> depart = sysOrgService.getById(String.valueOf(map.get("newDepartId")));
					if((null == map.get("newChargeId") || StringUtils.isEmpty(String.valueOf(map.get("newChargeId")))) && (null != assetsInfo)){
						track.put("userId", assetsInfo.get("resUserId"));
					}else{
						track.put("userId", map.get("newChargeId"));
					}
					track.put("departId", map.get("newDepartId"));
					if(null != assetsInfo.get("resDepartName")){
						track.put("changeRemark", "责任部门由【"+assetsInfo.get("resDepartName")+"】变更为【"+depart.get("name")+"】");
					}else{
						track.put("changeRemark", "责任部门变更为【"+depart.get("name")+"】");
					}
					assetsTrackInfoService.add(track);
				}
				
				//====资产存放地点变更====
				if(null != map.get("newPlace") && ""!= map.get("newPlace")){

					UTMap<String,Object> track = new UTMap<String,Object>(trackModele);
					UTMap<String,Object> place = assetPlaceService.getById(String.valueOf(map.get("newPlace")));
					if(null ==map.get("newChargeId") || (StringUtils.isEmpty(String.valueOf(map.get("newChargeId")))) && (null != assetsInfo)){
						track.put("userId", assetsInfo.get("resUserId"));
					}else{
						track.put("userId", map.get("newChargeId"));
					}
					if((null ==map.get("newDepartId") ||StringUtils.isEmpty(String.valueOf(map.get("newDepartId")))) && (null != assetsInfo)){
						track.put("departId", assetsInfo.get("resDepartId"));
					}else{
						track.put("departId", map.get("newDepartId"));
					}
					
					if(null != assetsInfo.get("locationName")){
						track.put("changeRemark", "存放地点由【"+assetsInfo.get("locationName")+"】变更为【"+place.get("name")+"】");
					}else{
						track.put("changeRemark", "存放地点变更为【"+place.get("name")+"】");
					}
					assetsTrackInfoService.add(track);
				}
			}
		}
		if(StringUtils.isNotEmpty(ids)){
			ids = ids.substring(0,ids.length()-1);
		}
		flag = assetPhysicalService.updateInfoByIds(newPlace, newChargeId, newDepartId, ids);
		if(flag){
			
		}
		return flag;
	}
	
	
	
	   private boolean compareDate(String allocationDate) throws Exception{
		   Date nowDate = new Date();
		   SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		   Date allocDate = sdf.parse(allocationDate);
		   boolean flag = allocDate.before(nowDate);
		   return flag;
	   }

}