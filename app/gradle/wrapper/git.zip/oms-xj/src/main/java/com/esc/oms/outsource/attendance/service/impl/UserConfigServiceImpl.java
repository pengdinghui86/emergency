package com.esc.oms.outsource.attendance.service.impl;

import com.esc.oms.outsource.attendance.dao.ICoalitionConfigDao;
import com.esc.oms.outsource.attendance.dao.IUserConfigDao;
import com.esc.oms.outsource.attendance.service.IUserConfigService;
import com.esc.oms.outsource.outperson.dao.IOutSourcePersonConfigDao;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.dao.ISysUserDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;


/**
 * 用户考勤规则配置Service
 * @author owner
 *
 */
@Service
@Transactional
public class UserConfigServiceImpl  extends BaseOptionService implements  IUserConfigService {
	private static final Logger logger = LoggerFactory.getLogger(UserConfigServiceImpl.class);
	
	@Resource
	private IUserConfigDao userConfigDao;
	
	@Resource
	private ICoalitionConfigDao coalitionConfigDao;
	
	@Resource
	private ISysUserDao sysUserDao;
	
	@Resource
	private IOutSourcePersonConfigDao personConfigDao;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return userConfigDao;
	}
	
	@Override
	@EscOptionLog(module=SystemModule.userConfig, opType=ESCLogOpType.INSERT, table="attendance_user_config", option="新增用户考勤规则")
	public boolean add(Map info) {
		String[] userIdArr = info.get("userId").toString().split(",");
		String attendanceDateType = info.get("attendanceDateType").toString();
		Map param = new HashMap();
		for(int i = 0 ; i < userIdArr.length ; i ++){
			info.remove("id");
			String userId = userIdArr[i];
			param.put("userId", userId);
			if(userConfigDao.isExist(param)){
				UTMap<String, Object> user = sysUserDao.getById(userId);
				throw new EscServiceException("用户'"+user.get("name")+"/"+user.get("code")+"'已经存在考勤规则配置数据！");
			}
			info.put("userId", userId);
			//// 1、确定时间考勤，2、不确定时间的考勤：不确定时间的考勤统计方式：（1.统计考勤次数；2.统计考勤时间（单位是小时））
			if("1".equals(attendanceDateType) || ("2".equals(attendanceDateType) && "1".equals(info.get("attendanceType").toString()))) {
				setHours(info);
			}
			
			super.add(info);
			Map<String, Object> personConfigParam=new HashMap<String, Object>();
			personConfigParam.put("userId", userId);
			personConfigParam.put("paramValue", "1");
			personConfigParam.put("isConfig", 1);
			personConfigDao.updates(personConfigParam, "userId","paramValue");
		}
		return true;
	}
	
	@Override
	@EscOptionLog(module = SystemModule.userConfig, opType = ESCLogOpType.UPDATE, table = "attendance_user_config", option = "修改用户考勤规则。")
	public boolean updateById(Map info) {
		String attendanceDateType = info.get("attendanceDateType").toString();
		if("1".equals(attendanceDateType) || ("2".equals(attendanceDateType) && "1".equals(info.get("attendanceType").toString()))) {
			setHours(info);
		}
		return super.updateById(info);
	}
	
	/**
	 * 设置工时
	 * @param info
	 */
	private void setHours(Map info){
		//夏令时
		long amBegin = UTDate.transformTimeToSecond((String) info.get("amBegin"));
		long amEnd = UTDate.transformTimeToSecond((String) info.get("amEnd"));
		long pmBegin = UTDate.transformTimeToSecond((String) info.get("pmBegin"));
		long pmEnd = UTDate.transformTimeToSecond((String) info.get("pmEnd"));
		//冬令时
		long winterAmBegin = UTDate.transformTimeToSecond((String) info.get("winterAmBegin"));
		long winterAmEnd = UTDate.transformTimeToSecond((String) info.get("winterAmEnd"));
		long winterPmBegin = UTDate.transformTimeToSecond((String) info.get("winterPmBegin"));
		long winterPmEnd = UTDate.transformTimeToSecond((String) info.get("winterPmEnd"));
		if(pmEnd == 0){
			pmEnd = 86400;//00:00转换为24:00的秒数
		}
		if(winterPmEnd == 0){
			winterPmEnd = 86400;//00:00转换为24:00的秒数
		}
		// 转换以秒为单位
		long dailyHoursAM = amEnd - amBegin; // 每天上午固定的工时
		long dailyHoursPM = pmEnd - pmBegin; // 每天下午固定的工时
		long breakTime = pmBegin - amEnd; // 中午休息时间
		long dailyHours = dailyHoursAM + dailyHoursPM; // 每天固定的工时
		//冬令时转换
		// 转换以秒为单位
		long winterDailyHoursAM = winterAmEnd - winterAmBegin; // 每天上午固定的工时
		long winterDailyHoursPM = winterPmEnd - winterPmBegin; // 每天下午固定的工时
		long winterBreakTime = winterPmBegin - winterAmEnd; // 中午休息时间
		long winterDailyHours = winterDailyHoursAM + winterDailyHoursPM; // 每天固定的工时
		info.put("dailyHoursAM", dailyHoursAM);
		info.put("dailyHoursPM", dailyHoursPM);
		info.put("breakTime", breakTime);
		info.put("dailyHours", dailyHours);
		//冬令时时间
		info.put("winterDailyHoursAM", winterDailyHoursAM);
		info.put("winterDailyHoursPM", winterDailyHoursPM);
		info.put("winterBreakTime", winterBreakTime);
		info.put("winterDailyHours", winterDailyHours);
	}

	/**
	 * 根据用户编号查询考勤规则
	 * @param userId
	 * @return
	 */
	@Override
	public UTMap<String, Object> getUserConfigByUserId(String userId) {
		return userConfigDao.getUserConfigByUserId(userId);
	}

	@Override
	@EscOptionLog(module = SystemModule.userConfig, opType = ESCLogOpType.DELETE,primaryKey="id={1}" , table = "attendance_user_config", option = "删除用户考勤规则。")
	public boolean deleteById(String id) {
//		detailDao.deleteByTemplateConfigurationId(id);
		Map<String, Object> userConfigMap = this.getById(id);
		String userId = userConfigMap.get("userId").toString();
		Map info = new HashMap();
		info.put("id", id);
//		Map<String, Object> personConfigParam=new HashMap<String, Object>();
//		personConfigParam.put("userId", userId);
//		personConfigParam.put("isConfig", 1);
//		personConfigDao.updates(personConfigParam, "userId");
		Map<String, Object> personConfigParam=new HashMap<String, Object>();
		personConfigParam.put("userId", userId);
		personConfigParam.put("paramValue", "1");
		personConfigParam.put("isConfig", 0);
		personConfigDao.updates(personConfigParam, "userId","paramValue");
		return getOptionDao().delete(info);
	}


	/**
	 * 根据用户id逻辑删除,退厂时调用，需要考虑联合考勤的情况
	 * @param userId
	 * @return
	 */
	@Override
	@EscOptionLog(module = SystemModule.userConfig, opType = ESCLogOpType.DELETE,primaryKey="id={1}" , table = "attendance_user_config", option = "根据用户编号删除用户考勤规则。")
	public boolean deleteByUserId(String userId) {
		UTMap<String, Object> info = userConfigDao.getUserConfigByUserId(userId);
		if(info != null){
			//如果是联合考勤，需要把联合考勤中此用户的数据删除
			if(info.get("coalitionId") != null){
				String coalitionId = info.get("coalitionId").toString();
				UTMap<String, Object> coalitionConfig =  coalitionConfigDao.getById(coalitionId);
				if(coalitionConfig.get("userIds") != null){
					String userIds = coalitionConfig.get("userIds").toString();
					if(userIds.indexOf(userId) != -1){
						userIds = userIds.replaceAll(userId, "");
						userIds = userIds.replaceAll(",,", ",");
						if(userIds.startsWith(",")){
							userIds = userIds.substring(1,userIds.length());
						}
						if(userIds.endsWith(",")){
							userIds = userIds.substring(0,userIds.length()-1);
						}
						coalitionConfig.put("userIds", userIds);
					}
					coalitionConfigDao.updateBy(coalitionConfig, null);
				}
			}
			return getOptionDao().deleteByIds(info.get("id").toString());
		}
		return true;
	}

	@Override
	public void deleteByCoalitionId(String coalitionId) {
		userConfigDao.deleteByCoalitionId(coalitionId);
	}
	
}
