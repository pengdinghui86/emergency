package com.esc.oms.outsource.outperson.dao.impl;

import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.outperson.dao.IRecruitmentConfirmLevelDao;

@Repository
public class RecruitmentConfirmLevelDaoImpl extends BaseOptionDao implements IRecruitmentConfirmLevelDao {

	@Override
	public String getTableName() {
		return "recruitment_resume";
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean,Map param) {
		super.getPageListMapBySql(this.getPageInfo(param), pageBean, null);
	}
	
	private String getPageInfo (Map<String, Object> params) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select rs.id, rs.name, rs.idCode, rs.resumeId, rs.applyId, ");
		sql.append(" rs.applyCode,rs.applyDetailId,rs.supplierId, rs.recUserId, rs.recTime, ");
		sql.append(" rs.status, rs.managerFilterResult, rs.businessFilterResult, rs.isArrival,rs.interviewResult,rs.arrivalDate, ");
		sql.append(" ra.name applicationName,ra.code applicationCode,ra.status applicaitonStatus,sbi.name supplierName, ");
		sql.append(" rad.category, rad.level, rad.remark,rs.interviewStatus,rs.level as 'totalLevel', ");
		//sql.append(" ri.interviewResult as 'score',ri.id interviewId, ");
		sql.append(" rs.managerReviewResult, rs.processId, rs.workflowStatus,swi.currentExecutor as auditors ");
		sql.append(" from recruitment_resume rs ");
		sql.append(" left join recruitment_application ra on ra.id = rs.applyId ");
		sql.append(" left join recruitment_application_detail rad on rad.id = rs.applyDetailId ");
		sql.append(" left join supplier_base_info sbi on sbi.id = rs.supplierId ");
		//sql.append(" left join recruitment_interview ri on ri.recruitmentResumeId=rs.id ");
		sql.append(" left join sys_workflow_instance swi on swi.id=rs.processId ");
		sql.append(" where 1=1 ");
		sql.append(" and rs.interviewStatus = '2' ");//面试未关闭0-为关闭，1-已关闭
		if (null != params && !params.isEmpty()) {
			String name = (String) params.get("name");
			if (StringUtils.isNotEmpty(name)) {
				sql.append(" and rs.name like '%" + name + "%' ");
			}
			
			String category = (String) params.get("category");
			if (StringUtils.isNotEmpty(category)) {
				sql.append(" and rad.category like '%" + category + "%' ");
			}
			
			String auditStatus = (String) params.get("auditStatus");
			if (StringUtils.isNotEmpty(auditStatus)) {
				sql.append(" and FIND_IN_SET(rs.workflowStatus, '"+auditStatus+"') ");
			}
			
			String status = (String) params.get("status");
			if (StringUtils.isNotEmpty(status)) {
				sql.append(" and FIND_IN_SET(rs.workflowStatus, '"+status+"') ");
			}
			
			String nameOrCode = params.get("nameOrCode")==null?null:params.get("nameOrCode").toString();
			if(!StringUtils.isEmpty(nameOrCode)){
				sql.append(" and (ra.code like '%"+nameOrCode+"%' or ra.name like '%"+nameOrCode+"%') ");
			} 
		}
		
		sql.append(" order by ra.name ");
		return sql.toString();
	}
	
	@Override
	public UTMap<String, Object> getInfoById(String id){
		return super.getOneBySql(getInfoByIdSql(id), null);
	}
	
	private String getInfoByIdSql (String id) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select rs.id, rs.interviewResult, rs.managerReviewResult, rs.level, rs.workflowStatus, rs.processId, ");
		sql.append(" ra.name, ra.code, rad.category, rad.level as 'applyLevel',rad.remark,rs.description,ra.applyDepartId ");
		sql.append(" from recruitment_resume rs ");
		sql.append(" left join recruitment_application ra on ra.id = rs.applyId ");
		sql.append(" left join recruitment_application_detail rad on rad.id = rs.applyDetailId ");
		sql.append(" where rs.id='" + id + "' ");
		
		return sql.toString();
	}

	@Override
	public void getAlreadyPageInfo(UTPageBean pageBean, Map<String, Object> params) {
		super.getPageListMapBySql(this.getAlreadyPageInfo(params), pageBean, null);
	}
	
	private String getAlreadyPageInfo (Map<String, Object> params) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select DISTINCT(rs.id), rs.name, rs.idCode, rs.resumeId, rs.applyId, ");
		sql.append(" rs.applyCode,rs.applyDetailId,rs.supplierId, rs.recUserId, rs.recTime, ");
		sql.append(" rs.status, rs.managerFilterResult, rs.businessFilterResult, rs.isArrival,rs.interviewResult,rs.arrivalDate, ");
		sql.append(" ra.name applicationName,ra.code applicationCode,ra.status applicaitonStatus,sbi.name supplierName, ");
		sql.append(" rad.category, rad.level, rad.remark,rs.interviewStatus,rs.level as 'totalLevel', ");
		//sql.append(" ri.interviewResult as 'score',ri.id interviewId, ");
		sql.append(" rs.managerReviewResult, rs.processId, rs.workflowStatus,swi.currentExecutor as auditors ");
		sql.append(" from recruitment_resume rs ");
		sql.append(" left join recruitment_application ra on ra.id = rs.applyId ");
		sql.append(" left join recruitment_application_detail rad on rad.id = rs.applyDetailId ");
		sql.append(" left join supplier_base_info sbi on sbi.id = rs.supplierId ");
		//sql.append(" left join recruitment_interview ri on ri.recruitmentResumeId=rs.id ");
		sql.append(" left join sys_workflow_instance swi on swi.id=rs.processId ");
		sql.append(" left join sys_workflow_audit_history sh on sh.instanceId=rs.processId ");
		sql.append(" where 1=1 ");
		sql.append(" and rs.interviewStatus = '2' ");//面试未关闭0-为关闭，1-已关闭
		sql.append(" and FIND_IN_SET('"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"',sh.optionUserId) and sh.nodeName<>'开始' " );
		if (null != params && !params.isEmpty()) {
			String name = (String) params.get("name");
			if (StringUtils.isNotEmpty(name)) {
				sql.append(" and rs.name like '%" + name + "%' ");
			}
			
			String category = (String) params.get("category");
			if (StringUtils.isNotEmpty(category)) {
				sql.append(" and rad.category like '%" + category + "%' ");
			}
			
			String auditStatus = (String) params.get("auditStatus");
			if (StringUtils.isNotEmpty(auditStatus)) {
				sql.append(" and FIND_IN_SET(rs.workflowStatus, '"+auditStatus+"') ");
			}
			
			String status = (String) params.get("status");
			if (StringUtils.isNotEmpty(status)) {
				sql.append(" and FIND_IN_SET(rs.workflowStatus, '"+status+"') ");
			}
			
			String nameOrCode = params.get("nameOrCode")==null?null:params.get("nameOrCode").toString();
			if(!StringUtils.isEmpty(nameOrCode)){
				sql.append(" and (ra.code like '%"+nameOrCode+"%' or ra.name like '%"+nameOrCode+"%') ");
			} 
		}
		
		sql.append(" order by ra.name ");
		return sql.toString();
	}

}
