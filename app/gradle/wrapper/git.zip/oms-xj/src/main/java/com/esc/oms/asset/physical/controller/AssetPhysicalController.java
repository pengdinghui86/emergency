package com.esc.oms.asset.physical.controller;

import com.alibaba.fastjson.JSON;
import com.esc.oms.asset.assetCategory.service.IAssetCategoryService;
import com.esc.oms.asset.physical.service.IAssetPhysicalAspectService;
import com.esc.oms.asset.physical.service.IAssetPhysicalService;
import com.esc.oms.asset.place.service.IAssetPlaceService;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.ExcelUtil;
import com.esc.oms.util.UTPoiExcelForAsset;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import net.sf.json.JSONObject;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.esc.framework.EscPropertyHolder;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.upload.service.ISysFileService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.print.*;
import javax.print.attribute.DocAttributeSet;
import javax.print.attribute.HashDocAttributeSet;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.standard.Copies;
import javax.print.attribute.standard.MediaPrintableArea;
import javax.print.attribute.standard.MediaSizeName;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
@Controller
@RequestMapping("assetPhysical")
public class AssetPhysicalController extends BaseOptionController {

	protected static Logger logger = LoggerFactory.getLogger(AssetPhysicalController.class);

	@Resource
	private IAssetPhysicalService assetPhysicalService;
	@Resource
    private IAssetPhysicalAspectService assetPhysicalAspectService;

	@Resource
	private IAssetCategoryService assetCategoryService;
	
	@Resource
	private IAssetPlaceService assetPlaceService;


	@Resource
	private ISysFileService sysFileService;
	
	@Override
	public IBaseOptionService optionService() {
		return assetPhysicalService;
	}
	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			assetPhysicalService.getPageInfo(pageBean, params);
			List<Map<String, Object>> list = pageBean.getRows();
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	/**
	 * 查询全部
	 * @param params
	 * @return
	 */
	@RequestMapping(value="getList")  
    @ResponseBody
    public List<UTMap<String, Object>> getList(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		List<UTMap<String, Object>> list = new ArrayList<>();
		try{
			list = assetPhysicalService.getListMaps(params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return list;
    }
	
	@RequestMapping(value="getAssetList")
	@ResponseBody
	public List<UTMap<String, Object>> getAssetList(@RequestParam  Map<String, Object> param){		
		List<UTMap<String,Object>> assetList = null;
    	try{
    		assetList = assetPhysicalService.getAssetsList(param);
		}catch(Exception e){
			logger.error("Exception", e);
			return new ArrayList<UTMap<String, Object>>();
    	}
       return assetList;
	}
	
    @RequestMapping(value="/saveOrUpdate",method=RequestMethod.POST)  
    @ResponseBody
    public String saveOrUpdate(@RequestBody Map<String,Object> map){
    	try{
	    	return assetPhysicalAspectService.saveOrUpdate(map);
    	}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
    }
    
    /**
	 * 根据id查询
	 * @param param
	 * @return
	 */
	@RequestMapping(value="getById")
	@ResponseBody
	public UTMap<String, Object> defgetById(@RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = null;
		String registAssets = String.valueOf(param.get("registAssets"));
    	try{
    		map = assetPhysicalService.getById(param.get("id").toString());
    		if(null != map){
//    			List<UTMap<String, Object>> subCategoryList = assetAllocationlService.getSubCategoryByParentId(String.valueOf(map.get("category")));
//    			map.put("subCategoryList", subCategoryList);
    			List<UTMap<String, Object>> sparePartList = assetPhysicalService.getSparesById((String)map.get("id"));
    			map.put("sparePartList", sparePartList);
    			
    			UTMap<String,Object> params = new UTMap<String,Object>();
    			params.put("parentId", map.get("id"));
    			params.put("registAssets",registAssets);
    			List<UTMap<String, Object>> auxiliaryList = assetPhysicalService.getListMaps(params);
    			map.put("auxiliaryList", auxiliaryList);
				UTPageBean pageBean = new UTPageBean();
				params.put("categoryId", map.get("category"));
				assetCategoryService.getAttrAll(params, pageBean);
    			//获取额外属性信息
				List<UTMap<String, Object>> attrValueList = assetCategoryService.getAttrValue(param.get("id").toString());
				//默认额外属性
				//属性值转为map
				Map<String, Object> attrValueMap = new HashMap<>();
				if(attrValueList != null && attrValueList.size()>0){
					for(UTMap<String, Object> attrValue : attrValueList){
						attrValueMap.put((String)attrValue.get("attId"), attrValue.get("attValue"));
						//如果属性类型为file，则需要获取file
						if("adjunct".equals((String) attrValue.get("type"))){
							List<UTMap<String, Object>> files = new ArrayList<>();
							files.add(sysFileService.getById(attrValue.get("attValue") != null ? (String) attrValue.get("attValue"): ""));
							attrValueMap.put("files", files);
						}
					}
				}
				//获取机柜U
				String location = (String)map.get("location");
				if(StringUtils.isNotEmpty(location)){
					Map<String, Object> sparam = new HashMap<>();
					sparam.put("assets_place_id", location);
					sparam.put("assetId", param.get("id").toString());
					List<UTMap<String, Object>> CabinetStartUSelectBox = assetPlaceService.getUsableList(sparam);
					sparam.put("startU", map.get("CabinetStartU"));
					List<UTMap<String, Object>> CabinetEndUSelectBox = assetPlaceService.getUsableList(sparam);
					map.put("CabinetStartUSelectBox", CabinetStartUSelectBox);
					map.put("CabinetEndUSelectBox", CabinetEndUSelectBox);
				}
				map.put("attrValueMap", attrValueMap);
				map.put("fieldList", pageBean.getRows());
    		}
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return map;
	}

	
	/**
	 * 从excel导入
	 * 
	 * @param
	 * @param filePath
	 * @return
	 */
	@RequestMapping(value = "leadingin")
	@ResponseBody
	public UTMap<String, Object> leadingin(
			@RequestParam Map<String, Object> param, String filePath) {
		UTMap<String, Object> utMap = new UTMap<String, Object>();
		try {
			utMap.put("success", assetPhysicalService.leadingin(FilenameUtils.normalize(filePath), param));
			utMap.put("msg", "导入成功！");
		} catch (EscServiceException e) {
			logger.error("EscServiceException",e);
			utMap.put("success", false);
			utMap.put("msg", e.getMessage());
		} catch (Exception e) {
			logger.error("EscServiceException",e);
			utMap.put("success", false);
			utMap.put("msg", "导入失败");
		}
		return utMap;
	}
	
	
	@RequestMapping(value = "leadingout")
	public void leadingout(@RequestParam Map<String, Object> param,
			HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = null;
			if(info != null) {
				jsonBean = JSONObject.fromObject(info);
			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = assetPhysicalService.getAssetsList(jsonBean);
			} else {
			// 根据条件 导出当前
			//if (UTExcel.EXCELOUTTYPE_NOW == outType) {
				// getpage
				assetPhysicalService.getPageInfo(utPageBean, jsonBean);
				data = utPageBean.getRows();
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			assetPhysicalService.leadingout(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	@RequestMapping(value = "leadingoutForJson")
	public void leadingoutForJson(@RequestParam Map<String, Object> param,
			HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		BufferedOutputStream buff = null; 
		ServletOutputStream serOut = null;
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = null;
			if(info != null) {
				jsonBean = JSONObject.fromObject(info);
			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = assetPhysicalService.getAssetsList(jsonBean);
			} else {
			// 根据条件 导出当前
			//if (UTExcel.EXCELOUTTYPE_NOW == outType) {
				// getpage
				assetPhysicalService.getPageInfo(utPageBean, jsonBean);
				data = utPageBean.getRows();
			}
			if (null ==  data) {
				data = new ArrayList<UTMap<String, Object>>();
			}
			List<UTMap<String, Object>> outData = new ArrayList<UTMap<String, Object>>();
			if (!data.isEmpty()) {
				for (UTMap<String, Object> map : data) {
					UTMap<String, Object> oMap = new UTMap<String, Object>();
					oMap.put("code", map.get("code"));
					oMap.put("codeNum", map.get("codeNum"));
					oMap.put("categoryName", map.get("categoryName"));
					oMap.put("serialNum", map.get("serialNum") == null ? "" : map.get("serialNum"));
					oMap.put("resUserName", map.get("resUserName") == null ? "" : map.get("resUserName"));
					oMap.put("name", map.get("name"));
					oMap.put("location", map.get("location") == null ? "" : map.get("location"));
					oMap.put("sn", map.get("sn") == null ? "" : map.get("sn"));
					oMap.put("brand", map.get("brand") == null ? "" : map.get("brand"));
					oMap.put("model", map.get("model") == null ? "" : map.get("model"));
					oMap.put("EquipmentLeader", map.get("EquipmentLeaderName") == null ? "" : map.get("EquipmentLeaderName"));
					outData.add(oMap);
				}
			}
			
			String jsonStr = JSON.toJSONString(outData);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			response.setContentType("text/plain");
			response.addHeader("Content-Disposition",  
	                "attachment;filename=assets"+ sdf.format(new Date()) +".json");
			serOut = response.getOutputStream();
			buff = new BufferedOutputStream(serOut);
			buff.write(jsonFormart(jsonStr).getBytes("UTF-8"));
			buff.flush();
		} catch (Exception e) {
			logger.error(e.getMessage());
		}finally {
			IOUtils.closeQuietly(buff);
			IOUtils.closeQuietly(serOut);
		}
	}
	
	private String getLevelStr(int level) {
        StringBuffer levelStr = new StringBuffer();
        for (int levelI = 0; levelI < level; levelI++) {
            levelStr.append("\t");
        }
        return levelStr.toString();
    }
	//格式化json串
    private String jsonFormart(String s) {
        int level = 0;
        //存放格式化的json字符串
        StringBuffer jsonForMatStr = new StringBuffer();
        for(int index=0;index<s.length();index++)//将字符串中的字符逐个按行输出
        {
            //获取s中的每个字符
            char c = s.charAt(index);
             
            //level大于0并且jsonForMatStr中的最后一个字符为\n,jsonForMatStr加入\t
            if (level > 0 && '\n' == jsonForMatStr.charAt(jsonForMatStr.length() - 1)) {
                jsonForMatStr.append(getLevelStr(level));
            }
            //遇到"{"和"["要增加空格和换行，遇到"}"和"]"要减少空格，以对应，遇到","要换行
            switch (c) {
            case '{':
            case '[':
                jsonForMatStr.append(c + "\n");
                level++;
                break;
            case ',':
                jsonForMatStr.append(c + "\n");            
                break;
            case '}':
            case ']':
                jsonForMatStr.append("\n");
                level--;
                jsonForMatStr.append(getLevelStr(level));
                jsonForMatStr.append(c);
                break;
            default:
                jsonForMatStr.append(c);
                break;
            }
        }
        return jsonForMatStr.toString();
    }
	
	@RequestMapping(value = "exportExcel")
	public void leadingexport(@RequestParam Map<String, Object> param,HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		try {
			List data = new ArrayList();
			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
		   JSONObject jsonBean = JSONObject.fromObject(info);
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
						// getAll
				data = assetPhysicalService.getAssetsList(jsonBean);
			} else {
				assetPhysicalService.getPageInfo(utPageBean, jsonBean);
				data = utPageBean.getRows();
			}

			assetPhysicalService.transformData(data);
			UTPoiExcelForAsset.exporetByInfo(response, param, data);

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}


	/**
	 * 判断重复
	 * @param map
	 * @return
	 */
	@RequestMapping(value="isExitItem")
	@ResponseBody
	public String isExitItem(@RequestParam Map<String, Object> map){
		String serialNum = (String)map.get("serialNum");
		String id = (String)map.get("id");
		String codeNum = (String)map.get("codeNum");
		Map<String, Object> params = new HashMap<>();
		if(StringUtils.isNotEmpty(serialNum)){//判断序列号是否唯一
			params.put("id", id);
			params.put("serialNum", serialNum);
			if(assetPhysicalService.isExistParam(map)){
				return UTJsonUtils.getJsonMsg(false, "请保证资产序列号唯一");
			}
		}
		if(StringUtils.isNotEmpty(codeNum)){
			params.clear();
			params.put("id", id);
			params.put("codeNum", codeNum);
			if(assetPhysicalService.isExistParam(map)){
				return UTJsonUtils.getJsonMsg(false, "请保证资产编号唯一");
			}
		}
		return UTJsonUtils.getJsonMsg(true, "");
	}
	
	@RequestMapping(value = "downloadExcelTemplate")
	public void downloadExcelTemplate(@RequestParam Map<String, Object> map1, HttpServletRequest request,
			HttpServletResponse response) {
		Map<String, Object> param = CommonUtils.clone(map1);
		try {
			UTPageBean pageBean = new UTPageBean();
			assetCategoryService.getAttrAll(param, pageBean);
			List<Map<String, Object>> maps = pageBean.getRows();
			//创建一个表格
			HSSFWorkbook wb = new HSSFWorkbook();
			UTMap<String, Object> map = new UTMap<String, Object>();
			// 创建ExportExcel对象
	        ExcelUtil excelUtil = new ExcelUtil();
	        excelUtil.createExcelTemplate(wb, maps, param.get("name").toString());
			
			response.setCharacterEncoding("UTF-8");
			response.setContentType("application/vnd.ms-excel");
			String fileName = "实物资产_" + param.get("name").toString() + "登记导入模板.xls";
			fileName = URLEncoder.encode(fileName, "UTF-8");
			response.addHeader("Content-Disposition", "attachment;filename=" + fileName);
			OutputStream out = response.getOutputStream();
			wb.write(out);
			out.close();
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	@RequestMapping(value="/assetBatchUpdate",method=RequestMethod.POST)  
    @ResponseBody
    public String assetBatchUpdate(@RequestBody Map<String,Object> map){
    	try{
    		assetPhysicalService.updateByIds(map);
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "操作成功");
    }
	
	
	@RequestMapping(value = "downloadQRCode")
	public void downloadQRCode(@RequestParam Map<String, Object> map1,
			HttpServletRequest request,
			HttpServletResponse response){
		
		Map<String, Object> map = CommonUtils.clone(map1);
		UTPageBean utPageBean = CommonUtils.getPageBean(map);
		
		String id = (String)map.get("id");
		String fileName = (String)map.get("name");
		if(StringUtils.isNotEmpty(fileName)){
			fileName = fileName.trim();
		}
    	try{
    		    String text =  EscPropertyHolder.instance.getProperty("system.rootAddress")+"/none/assets/assetDetail.html?id="+id;
    		    int width = 300;  
    	        int height = 300;  
    	        //二维码的图片格式  
    	        String format = "png";  
    	        Hashtable hints = new Hashtable();  
    	        //内容所使用编码  
    	        hints.put(EncodeHintType.CHARACTER_SET, "utf-8");  
    	        BitMatrix bitMatrix = new MultiFormatWriter().encode(text,  
    	                BarcodeFormat.QR_CODE, width, height, hints);  
    	        fileName = new String( fileName.getBytes("GBK"), "ISO8859-1" ) ;
    			OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
    			response.addHeader("Content-Disposition", "attachment;filename=" + fileName+".png");
    			response.setContentType("application/octet-stream");
    			MatrixToImageWriter.writeToStream(bitMatrix, format, toClient);
    	        
    	        
    	}catch(Exception e){
    		logger.error("Exception", e);
    	}
    }
	
	@RequestMapping(value = "downloadQRCode2")
	public void downloadQRCode2(@RequestParam Map<String, Object> map1,
			HttpServletRequest request,
			HttpServletResponse response){
		Map<String,Object> cloneMap = CommonUtils.clone(map1);
		UTPageBean utPageBean = CommonUtils.getPageBean(cloneMap);
		String id = (String)cloneMap.get("id");
		String fileName = (String)cloneMap.get("name");
		String fileName2 = (String)cloneMap.get("name");
		if(StringUtils.isNotEmpty(fileName2)){
			fileName2 = fileName2.trim();
		}
    	try{
    		    String text =  EscPropertyHolder.instance.getProperty("system.rootAddress")+"/none/assets/assetDetail.html?id="+id;
    		    int width = 300;  
    	        int height = 300;  
    	        //二维码的图片格式  
    	        String format = "png";  
    	        Hashtable hints = new Hashtable();  
    	        //内容所使用编码  
    	        hints.put(EncodeHintType.CHARACTER_SET, "utf-8");  
    	        BitMatrix bitMatrix = new MultiFormatWriter().encode(text,  
    	                BarcodeFormat.QR_CODE, width, height, hints);  
    	        fileName2 = new String( fileName2.getBytes("GBK"), "ISO8859-1" ) ;
    			
    	        /** * 读取二维码图片，并构建绘图对象 */
                BufferedImage image = MatrixToImageWriter.toBufferedImage(bitMatrix);
                Graphics2D g = image.createGraphics();
                g.dispose();
                //把商品名称添加上去，商品名称不要太长哦，这里最多支持两行。太长就会自动截取啦
                if (fileName != null && !fileName.equals("")) {
                    //新的图片，把带logo的二维码下面加上文字
                    BufferedImage outImage = new BufferedImage(400, 400, BufferedImage.TYPE_4BYTE_ABGR);
                    Graphics2D outg = outImage.createGraphics();
                    //画二维码到新的面板
                    outg.drawImage(image, 50,70, image.getWidth(), image.getHeight(), null);
                    //画文字到新的面板
                    outg.setColor(Color.BLACK); 
                    outg.setFont(new Font("宋体",Font.BOLD,30)); //字体、字型、字号 
                    int strWidth = outg.getFontMetrics().stringWidth(fileName);
                    if (strWidth > 399) {
                        //长度过长就换行
                        String productName1 = fileName.substring(0, fileName.length()/2);
                        String productName2 = fileName.substring(fileName.length()/2, fileName.length());
                        int strWidth1 = outg.getFontMetrics().stringWidth(productName1);
                        int strWidth2 = outg.getFontMetrics().stringWidth(productName2);
                        outg.drawString(productName1, 200  - strWidth1/2, image.getHeight() + (outImage.getHeight() - image.getHeight())/2 + 12 );
                        BufferedImage outImage2 = new BufferedImage(400, 485, BufferedImage.TYPE_4BYTE_ABGR);
                        Graphics2D outg2 = outImage2.createGraphics();
                        outg2.drawImage(outImage, 0, 0, outImage.getWidth(), outImage.getHeight(), null);
                        outg2.setColor(Color.BLACK); 
                        outg2.setFont(new Font("宋体",Font.BOLD,30)); //字体、字型、字号 
                        outg2.drawString(productName2, 200  - strWidth2/2, outImage.getHeight() + (outImage2.getHeight() - outImage.getHeight())/2 + 5 );
                        outg2.dispose(); 
                        outImage2.flush();
                        outImage = outImage2;
                    }else {
                        outg.drawString(fileName, 200  - strWidth/2 , image.getHeight() + (outImage.getHeight() - image.getHeight())/2 + 12 ); //画文字 
                    }
                    outg.dispose(); 
                    outImage.flush();
                    image = outImage;
                }
                image.flush();
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                baos.flush();
//                ImageIO.write(image, "png", baos);

    	        
    	        OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
    			response.addHeader("Content-Disposition", "attachment;filename=" + fileName2+".png");
    			response.setContentType("application/octet-stream");
    			ImageIO.write(image, "png", toClient); 
    	        
    	}catch(Exception e){
    		logger.error("Exception", e);
    	}
    }


	@RequestMapping(value = "deleteAssetPhysical")
	@ResponseBody
    public String deleteAssetPhysical(@RequestBody Map<String, Object> params){
		return assetPhysicalService.deletePhysical(params);
	}

	public static void drawImage(String fileName, int count) {
		FileInputStream fin = null;
		try {
			// 获取默认打印机
			PrintService ps = PrintServiceLookup.lookupDefaultPrintService();

			PrintRequestAttributeSet pras = new HashPrintRequestAttributeSet();
			pras.add(new Copies(count));
			pras.add(MediaSizeName.ISO_A4); // 设置打印的纸张

			DocAttributeSet das = new HashDocAttributeSet();
			das.add(new MediaPrintableArea(0, 0, 1, 1, MediaPrintableArea.INCH));
			fin = new FileInputStream(FilenameUtils.normalize(fileName));

			Doc doc = new SimpleDoc(fin, DocFlavor.INPUT_STREAM.PNG, das);
			DocPrintJob job = ps.createPrintJob();

			job.print(doc, pras);
			fin.close();
		} catch (IOException e) {
			logger.error("IOException",e);
		} catch (PrintException e) {
			logger.error("PrintException",e);
		}finally {
			if(fin != null){
				try {
					fin.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}