package com.esc.oms.outsource.attendance.controller;

import com.esc.oms.outsource.attendance.service.IManHourEditService;
import com.esc.oms.util.CommonUtils;

import net.sf.json.JSONObject;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;



/**
 * 考勤工时填报
 * @author owner
 *
 */
@Controller
@RequestMapping("manHourEditController")
public class ManHourEditController  extends BaseOptionController {
	
	@Resource
	private IManHourEditService manHourEditService;
	
	@Override
	public IBaseOptionService optionService() {
		return manHourEditService;
	}
	
	@RequestMapping(value="initManHourEdit")  
	@ResponseBody
	public String initManHourEdit() {
		Calendar c = Calendar.getInstance();
		c.setTime(UTDate.getDate("2016-08-01",UTDate.DATE_FORMAT));
		try {
			for(int i = 1 ; i <= 31 ; i++){
				manHourEditService.initData(c.getTime(),true);
				c.add(Calendar.DAY_OF_MONTH, 1);
			}
			
		} catch (EscServiceException e) {
			logger.error("EscServiceException", e);
			return UTJsonUtils.getJsonMsg(false, e.getMessage());
		} catch (Exception e) {
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "生成失败");
		}
		return UTJsonUtils.getJsonMsg(true, "生成成功");
	}
	
	@RequestMapping(value="initData")  
	@ResponseBody
	public String initData() {
		try {
				manHourEditService.initData(null,true);
		} catch (EscServiceException e) {
			logger.error("EscServiceException", e);
			return UTJsonUtils.getJsonMsg(false, e.getMessage());
		} catch (Exception e) {
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "生成失败");
		}
		return UTJsonUtils.getJsonMsg(true, "生成成功");
	}
	
	/**
	 * 重新统计生成上一个月的数据
	 */
	@RequestMapping(value="afreshDate")  
	@ResponseBody
	public String afreshDate(@RequestParam String dateTime) {
		//判断时间
		if(dateTime == null){
			return UTJsonUtils.getJsonMsg(false, "请选择重新统计的月份");
		}
		String[] timeArr = dateTime.split("-");
		LocalDateTime now = LocalDateTime.now();
		LocalDateTime date = LocalDateTime.of(Integer.parseInt(timeArr[0]),Integer.parseInt(timeArr[1]),1, 0, 0, 0);
		if(date.isAfter(now) || now.isEqual(date)){//date >= now
			return UTJsonUtils.getJsonMsg(false, "所选月份不能大于当前月份");
		}
		try {
			manHourEditService.afreshDate(date);
		} catch (EscServiceException e) {
			logger.error("EscServiceException", e);
			return UTJsonUtils.getJsonMsg(false, e.getMessage());
		} catch (Exception e) {
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "生成失败");
		}
		return UTJsonUtils.getJsonMsg(true, "生成成功");
	}
	
	/**
	 * 统计指定年月的人力外包考勤工时
	 * @param statisticsYear
	 * @param statisticsMonth
	 */
	@RequestMapping(value="statisticsManHour")  
	@ResponseBody
	public String statisticsManHour() {
		Calendar c = Calendar.getInstance();
		c.add(Calendar.MONTH, -1);//上一个月
		try {
			manHourEditService.statisticsManHour(c.get(c.YEAR),c.get(c.MONTH) + 1);
		} catch (EscServiceException e) {
			logger.error("EscServiceException", e);
			return UTJsonUtils.getJsonMsg(false, e.getMessage());
		} catch (Exception e) {
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "重新统计失败");
		}
		return UTJsonUtils.getJsonMsg(true, "重新统计成功");
	}
	
	/**
	 * 导出
	 * @param param
	 * @param utPageBean
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "leadingout")
	public void leadingout(@RequestParam Map<String, Object> param,
			HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = null;
			if(info != null) {
				jsonBean = JSONObject.fromObject(info);
			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = manHourEditService.getListMaps(jsonBean);
			} else {
				manHourEditService.getPageInfo(utPageBean, jsonBean);
				data = utPageBean.getRows();
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			manHourEditService.leadingout(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
}
