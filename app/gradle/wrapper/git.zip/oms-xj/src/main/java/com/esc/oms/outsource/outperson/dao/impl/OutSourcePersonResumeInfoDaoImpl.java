package com.esc.oms.outsource.outperson.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.outperson.dao.IOutSourcePersonResumeInfoDao;
import com.esc.oms.util.RoleUtils;


/**
 * 简历基本信息
 * @author djj
 * @date   2016-07-18
 */
@Repository
public class OutSourcePersonResumeInfoDaoImpl extends BaseOptionDao implements IOutSourcePersonResumeInfoDao {

	@Override
	public String getTableName() {
		return "resume_info";
	}
	
	@Override
	public List<UTMap<String, Object>> getListMaps(Map param) {
		String sql=getSearchSql(param);
		return super.getListBySql(sql, null);
	}

	@Override
	public void getPageInfo(UTPageBean pageBean,Map param){
		String sql=getSearchSql(param);
		super.getPageListMapBySql(sql,pageBean, null);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	@Override
	public List<UTMap<String, Object>> getPageList(UTPageBean pageBean,Map params) {
		String sql=getSearchSql(params);
		super.getPageListMapBySql(sql,pageBean, null);
		return pageBean.getRows();
	}
	
	/**
	 * 用户 查询sql 拼接器
	 * @param param
	 * @return
	 */
	private String getSearchSql(Map<String, Object> param){
		Map<String, String> p=UTMap.mapObjToString(param);
		StringBuilder sql=new StringBuilder();
		sql.append(" select info.*,supplier.name as supplierName,CONCAT(info.name,'/',info.idCode) as showName from resume_info info ");
		sql.append(" left join supplier_base_info supplier on info.supplierId=supplier.id ");
		sql.append("	WHERE 1=1  ");
		if(param!=null){
			String name = param.get("name")==null?null:param.get("name").toString();
			if(!StringUtils.isEmpty(name)){
				sql.append(" and info.name like '%"+name+"%' ");
			}
			String idCode = param.get("idCode")==null?null:param.get("idCode").toString();
			if(!StringUtils.isEmpty(idCode)){
				sql.append(" and info.idCode like '%"+idCode+"%' ");
			}
			String supplierId = param.get("supplierId")==null?null:param.get("supplierId").toString();
			if(!StringUtils.isEmpty(supplierId)){
				sql.append(" and info.supplierId='"+supplierId+"' ");
			}
			String supplierName = param.get("supplierName")==null?null:param.get("supplierName").toString();
			if(!StringUtils.isEmpty(supplierName)){
				sql.append(" and supplier.name like '%"+supplierName+"%' ");
			}
		}	
		//权限控制
		if(!RoleUtils.isSupplierAdministrator()&&!RoleUtils.isSystemAdministrator()&&!RoleUtils.isOutsourceAudit()&&!RoleUtils.isOutsourceManager()){
			if(!"1".equals(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserType())){//供应商人员，只查看本供应商的记录
				String supplierId = EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId();
				sql.append(" and info.supplierId='"+supplierId.trim()+"' ");
			}
		}
		sql.append(" order by info.createTime desc ");
		return sql.toString();
	}

	@Override
	public List<UTMap<String, Object>> getRecommendResumeList(
			Map<String, Object> param) {
		Map<String, String> p=UTMap.mapObjToString(param);
		StringBuilder sql=new StringBuilder();
		sql.append(" select info.*,supplier.name as supplierName,CONCAT(info.name,'/',info.idCode) as showName from resume_info info ");
		sql.append(" left join supplier_base_info supplier on info.supplierId=supplier.id ");
		sql.append(" WHERE info.idCode not in (select DISTINCT(IFNULL(idCode,'')) from sys_user where state='1')  ");
		sql.append(" and info.idCode not in (select DISTINCT(IFNULL(idCode,'')) from outsoure_person_black_list where isClear='0')  ");
		if(param!=null){
			String name = param.get("name")==null?null:param.get("name").toString();
			if(!StringUtils.isEmpty(name)){
				sql.append(" and info.name like '%"+name+"%' ");
			}
			String idCode = param.get("idCode")==null?null:param.get("idCode").toString();
			if(!StringUtils.isEmpty(idCode)){
				sql.append(" and info.idCode like '%"+idCode+"%' ");
			}
			String supplierId = param.get("supplierId")==null?null:param.get("supplierId").toString();
			if(!StringUtils.isEmpty(supplierId)){
				sql.append(" and info.supplierId='"+supplierId+"' ");
			}
			String applyId = (String) param.get("applyId");//招聘/申请单处理 查询推荐简历的人员信息时需要加上下面的过滤条件
			if (StringUtils.isNotEmpty(applyId)) {
				sql.append(" and not exists (select id from recruitment_resume rr where rr.resumeId=info.id and rr.applyId='"+applyId+"') ");
			}
		}	
		//权限控制
//		if(!RoleUtils.isSupplierAdministrator()&&!RoleUtils.isSystemAdministrator()&&!RoleUtils.isOutsourceAudit()&&!RoleUtils.isOutsourceManager()){
			if(!"1".equals(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserType())){//供应商人员，只查看本供应商的记录
				String supplierId = EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId();
				sql.append(" and info.supplierId='"+supplierId.trim()+"' ");
			}
//		}
		sql.append(" order by info.createTime desc ");
		return super.getListBySql(sql.toString(), null);
	}

}
