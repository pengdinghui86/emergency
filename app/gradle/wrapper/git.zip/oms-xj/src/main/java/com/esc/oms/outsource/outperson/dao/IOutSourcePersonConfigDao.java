package com.esc.oms.outsource.outperson.dao;

import org.esc.framework.persistence.dao.IBaseOptionDao;

public interface IOutSourcePersonConfigDao  extends IBaseOptionDao{

	public static final String  FIELD_ID = "id";
	public static final String  FIELD_USERID = "userId";
	public static final String  FIELD_ITEMNAME= "itemName";
	public static final String  FIELD_ITEMTYPE= "itemType";
	public static final String  FIELD_ISCONFIG = "isConfig";//是否配置
	public static final String  FIELD_ISCONCEL = "isConcel";//是否取消
	public static final String  FIELD_OPENDATE = "openDate";
	public static final String  FIELD_CONCELDATE = "concelDate";
	public static final String  FIELD_OPENPERSON = "openPerson";
	public static final String  FIELD_CONCELPERSON = "concelPerson";
	public static final String  FIELD_REMARK = "remark";
	public static final String  FIELD_CREATEUSERID = "createUserId";
	
}
