package com.esc.oms.exemple.controller;

import java.util.Map;

import org.esc.framework.utils.UTJsonUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
@RequestMapping("test")
public class TestController {

      
    @RequestMapping(value="/test1",method=RequestMethod.POST)  
    @ResponseBody
    public String test1(@RequestBody Map<String,Object> map){  
       return UTJsonUtils.getJsonMsg(true, "请求成功");
    }  
    
//	@RequestMapping(value = "/test2")
//	public ModelAndView toSaveOrupdate(HttpServletRequest request) {
//		ModelAndView mav = new ModelAndView();  
//	       mav.addObject("hello", "哈哈哈哈aaaaaa");  
//	       mav.setViewName("views/exemple/test");  
//		return mav;
//	}
}
