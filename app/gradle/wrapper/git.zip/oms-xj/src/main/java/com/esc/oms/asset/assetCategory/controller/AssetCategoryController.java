package com.esc.oms.asset.assetCategory.controller;

import com.esc.oms.asset.assetCategory.service.IAssetCategoryService;
import com.esc.oms.util.CommonUtils;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("assetCategory")
public class AssetCategoryController extends BaseOptionController {

  @Resource
  private IAssetCategoryService assetCategoryService;

  @Override
  public IBaseOptionService optionService() {
    return assetCategoryService;
  }

  /**
   * 分页查询
   * @param params
   * @param pageBean
   * @return
   */
  @RequestMapping(value="getAll")
  @ResponseBody
  public UTPageBean getAll(@RequestParam Map<String, Object> params){
	  UTPageBean pageBean = CommonUtils.getPageBean(params);
    try {
      assetCategoryService.getPageInfo(pageBean, params);
    }catch (Exception e){
      logger.error("Exception", e);
    }
    return pageBean;
  }

  /**
   * 获取所有的值
   * @param params
   * @param pageBean
   * @return
   */
  @RequestMapping(value="getAttrAll")
  @ResponseBody
  public UTPageBean getAttrAll(@RequestParam Map<String, Object> params){
	  UTPageBean pageBean = CommonUtils.getPageBean(params);
    try{
      assetCategoryService.getAttrAll(params, pageBean);
    }catch (Exception e){
      logger.error("Exception", e);
    }
    return pageBean;
  }
  @RequestMapping(value="isExitItem")
  @ResponseBody
  public String isExitItem(@RequestParam Map<String, Object> param){
    return booleanExitItem(param);
  }

  @RequestMapping(value="delete")
  @ResponseBody
  public String logicalDelete(@RequestBody Map<String, Object> param){
    String id = param.get("id")!=null?param.get("id").toString():"";
    if(StringUtils.isEmpty(id)){
      return UTJsonUtils.getJsonMsg(false, "请选择要删除的数据");
    }
    Map<String, Object> map = new HashMap<>();
    map.put("id",id);
    map.put("deleteFlag", 1);
    try{
      assetCategoryService.updateById(map);
    }catch (Exception e){
      logger.error("Exception", e);
      return UTJsonUtils.getJsonMsg(false, "操作失败");
    }
    return UTJsonUtils.getJsonMsg(true, "删除成功");
  }
  /**
   * 添加
   * @param map
   * @return
   */
  @RequestMapping(value="saveOrUpdate")
  @ResponseBody
  public String saveOrUpdate(@RequestBody Map<String,Object> map){
    String id = map.get("id")!=null?map.get("id").toString():"";
    String resultMsg = null;
    map.put("deleteFlag",0);
    try{
      if(StringUtils.isEmpty(id)){
        resultMsg = booleanExitItem(map);
        if(resultMsg.contains("false")){
          return resultMsg;
        }
        assetCategoryService.add(map);
      }else{//否则判断是否有修改成其他值导致重复
        //先根据id获取原值
        String categoryId = map.get("categoryId")!=null?map.get("categoryId").toString():"";
        String attId=map.get("attId")!=null?map.get("attId").toString():"";
        String attName=map.get("attName")!=null?map.get("attName").toString():"";
        UTMap<String, Object> assetMap = assetCategoryService.getById(id);
        //判断是否修改了attId
        Map<String, Object> paramsMap = new HashMap<>();
        paramsMap.put("categoryId",categoryId);
        paramsMap.put("deleteFlag",0);
        if(!StringUtils.equals(attId, (String)assetMap.get("attId"))){
          paramsMap.put("attId",attId);
          if(assetCategoryService.isExist(paramsMap)){
            return UTJsonUtils.getJsonMsg(false, "请保证ID名称唯一");
          }
        }
        if(!StringUtils.equals(attName, (String)assetMap.get("attName"))){
          paramsMap.remove("attId");
          paramsMap.put("attName",attName);
          if(assetCategoryService.isExist(paramsMap)){
            return UTJsonUtils.getJsonMsg(false, "请保证名称唯一");
          }
        }
        assetCategoryService.updateById(map);
      }
    }catch (Exception e){
      logger.error("Exception", e);
      return UTJsonUtils.getJsonMsg(false, "操作失败");
    }
    return UTJsonUtils.getJsonMsg(true, "操作成功");
  }

  /**
   * 判断是否重复
   * @param param
   * @return
   */
  private String booleanExitItem(Map<String, Object> param){
    String categoryId = param.get("categoryId")!=null?param.get("categoryId").toString():"";
    String attId=param.get("attId")!=null?param.get("attId").toString():"";
    String attName=param.get("attName")!=null?param.get("attName").toString():"";
    if(StringUtils.isEmpty(categoryId)){
      return UTJsonUtils.getJsonMsg(false, "资产类别不存在");
    }
    if(StringUtils.isNotEmpty(attId)){
      Map<String, Object> map=new HashMap<String, Object>();
      map.put("attId",attId);
      map.put("categoryId",categoryId);
      map.put("deleteFlag",0);
      if(assetCategoryService.isExistColumn(map)){
        return UTJsonUtils.getJsonMsg(false, "请保证ID名称唯一");
      }
    }
    if(StringUtils.isNotEmpty(attName)){
      Map<String, Object> map=new HashMap<String, Object>();
      map.put("attName",attName);
      map.put("categoryId",categoryId);
      map.put("deleteFlag",0);
      if(assetCategoryService.isExist(map)){
        return UTJsonUtils.getJsonMsg(false, "请保证名称唯一");
      }
    }
    return UTJsonUtils.getJsonMsg(true, "");
  }


  /**
   * 获取参数
   * @return
   */
  @RequestMapping(value="getdicts")
  @ResponseBody
  public UTPageBean getdicts() {
    UTPageBean utPageBean = new UTPageBean();
    List<UTMap<String, Object>> resModelList = assetCategoryService.getdicts();
    utPageBean.setRows(resModelList);
    utPageBean.setTotal(resModelList.size());
    return 	utPageBean;
  }
}
