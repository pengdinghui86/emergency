package com.esc.oms.outsource.attendance.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

/**
 * 不确定时间考勤考勤统计-按工时Service接口
 * @author owner
 *
 */
public interface IAttendanceStatisticsTimeService extends IBaseOptionService {
	
	/**
	 * 每个月1号凌晨检查生成上一个月不确定考勤时间，按工时统计的考勤统计数据
	 */
	public void initData();
	
	/**
	 * 重新统计生成上一个月的数据
	 */
	public void afreshDate();
	
	public void leadingout(List data, HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	/**
	 * 运维联合考勤统计
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllCoalitionOperations(Map param);
	
	/**
	 * 运维联合考勤统计
	 * @param pageBean
	 * @param param
	 */
	public void getCoalitionOperations(UTPageBean pageBean,Map param);
	
	/**
	 * 运维考勤统计（供应商）
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllSupplierOperations(Map param);
	
	/**
	 * 运维考勤统计（供应商）
	 * @param pageBean
	 * @param param
	 */
	public void getSupplierOperations(UTPageBean pageBean,Map param);
	
	/**
	 * 运维考勤统计（部门）
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllOrgOperations(Map param);
	
	/**
	 * 运维考勤统计（部门）
	 * @param pageBean
	 * @param param
	 */
	public void getOrgOperations(UTPageBean pageBean,Map param);
	
	/**
	 * 运维联合考勤统计导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	public void leadingoutAttCoalitionOperations(List data, HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	/**
	 * 运维考勤统计（供应商）
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	public void leadingoutAttSupplierOperations(List data, HttpServletRequest request,HttpServletResponse response) throws Exception;
	
	/**
	 * 运维考勤统计（部门）
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	public void leadingoutAttOrgOperations(List data, HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	/**
	 * 运维考勤统计详情导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	public void leadingoutAttOperationsDetail(List data, HttpServletRequest request,
			HttpServletResponse response)throws Exception;
	
	/**
	 * 点击异常率查询详情数据接口
	 * @param param
	 * @return
	 */
	public void getDetail(UTPageBean pageBean,Map param);
	
	/**
	 * 点击异常率查询详情数据接口
	 * @param param
	 * @return
	 */
	public List<UTMap<String, Object>> getDetail(Map param);
	
}
