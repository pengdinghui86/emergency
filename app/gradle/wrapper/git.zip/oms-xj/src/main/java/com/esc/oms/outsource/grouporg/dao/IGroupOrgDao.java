package com.esc.oms.outsource.grouporg.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

public interface IGroupOrgDao extends IBaseOptionDao {
	

	public static final String FIELD_GROUPORG_ID="id";
	public static final String FIELD_GROUPORG_GROUP="groupId";
	public static final String FIELD_GROUPORG_SORT="sort";
	public static final String FIELD_GROUPORG_PARENTID="parentId";
	public static final String FIELD_GROUPORGTYPE="groupOrgType";
	

	public static final String FIELD_GROUPUSER_ID="ID";
	public static final String FIELD_GROUPUSER_GROUPID="groupId";
	public static final String FIELD_GROUPUSER_USERID="userId";
	public static final String FIELD_GROUPUSER_POST="groupPost";
	

	public static final int GROUPORG_ZZJG=1;
	public static final int GROUPORG_YJJG=2;

	
	public boolean saveGroupOrg(List<Map> info,int groupOrgType);
	
	public boolean saveGroupUser(List<Map> info,String groupOrgIds);

	public List<UTMap<String, Object>> getGroupOrgAndUser(int groupOrgType);

	public boolean deleteGroupUserByGroutId(String groupIds);
}
