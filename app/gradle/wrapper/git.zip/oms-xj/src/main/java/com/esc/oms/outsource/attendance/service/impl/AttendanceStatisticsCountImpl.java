package com.esc.oms.outsource.attendance.service.impl;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.timetask.anotations.CronTimeTask;
import org.esc.framework.timetask.anotations.TimeTaskMark;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.attendance.dao.IAttendanceStatisticsCountDao;
import com.esc.oms.outsource.attendance.service.IAttendanceStatisticsCountService;
import com.esc.oms.util.CommonUtils;


/**
 * 不确定时间考勤考勤统计-按次数Service
 * @author owner
 *
 */
@Service
@Transactional
@TimeTaskMark
public class AttendanceStatisticsCountImpl  extends BaseOptionService implements  IAttendanceStatisticsCountService {
	private static final Logger logger = LoggerFactory.getLogger(AttendanceStatisticsCountImpl.class);
	
	@Resource
	private IAttendanceStatisticsCountDao attendanceStatisticsCountDao;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return attendanceStatisticsCountDao;
	}
	
	/**
	 * 重新统计生成上一个月的数据
	 */
	public void afreshDate(){
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd"); 
		//获取前月的第一天
		//获取当前日期 
		Calendar cal_1=Calendar.getInstance();
		cal_1.add(Calendar.MONTH, -1);
		//设置为1号,当前日期既为本月第一天 
		cal_1.set(Calendar.DAY_OF_MONTH,1);
		String firstDay = format.format(cal_1.getTime());
//		System.out.println("-----1------firstDay:"+firstDay);
		int year = cal_1.get(Calendar.YEAR);
		int month = cal_1.get(Calendar.MONTH)+1;
		int quarter = UTDate.getQuarter(month);
		String yearMonth = year + "-" + month;
//		System.out.println(yearMonth + "," + quarter);
		//获取前月的最后一天
		Calendar cale = Calendar.getInstance();
		//设置为1号,当前日期既为本月第一天 
		cale.set(Calendar.DAY_OF_MONTH,0);
		String lastDay = format.format(cale.getTime());
		logger.info("重新生成"+firstDay+"至"+lastDay+"按次数考勤的统计数据");
		//先删除上一个月的数据
		attendanceStatisticsCountDao.deleteByDate(yearMonth);
		//然后再重新生成
		attendanceStatisticsCountDao.initDate(firstDay, lastDay,year,month,quarter,yearMonth);
	}
	
	/**
	 * 每个月1号凌晨检查生成上一个月不确定考勤时间，按次数统计的考勤统计数据
	 */
	@Override
	@CronTimeTask(description="每个月1号凌晨检查生成上一个月不确定考勤时间，按次数统计的考勤统计数据",cron="0 15 0 1 * ?")//每月1号凌晨0:15执行
	public void initData() {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd"); 
		//获取前月的第一天
		//获取当前日期 
		Calendar cal_1=Calendar.getInstance();
		cal_1.add(Calendar.MONTH, -1);
		//设置为1号,当前日期既为本月第一天 
		cal_1.set(Calendar.DAY_OF_MONTH,1);
		String firstDay = format.format(cal_1.getTime());
//		System.out.println("-----1------firstDay:"+firstDay);
		int year = cal_1.get(Calendar.YEAR);
		int month = cal_1.get(Calendar.MONTH)+1;
		int quarter = UTDate.getQuarter(month);
		String yearMonth = year + "-" + month;
//		System.out.println(yearMonth + "," + quarter);
		//获取前月的最后一天
		Calendar cale = Calendar.getInstance();
		//设置为1号,当前日期既为本月第一天 
		cale.set(Calendar.DAY_OF_MONTH,0);
		String lastDay = format.format(cale.getTime());
//		System.out.println("-----2------lastDay:"+lastDay);
		attendanceStatisticsCountDao.initDate(firstDay, lastDay,year,month,quarter,yearMonth);
	}
	
	/**
	 * 运维联合考勤统计
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllCoalitionOperations(Map param){
		return attendanceStatisticsCountDao.getAllCoalitionOperations(param);
	}
	
	/**
	 * 运维联合考勤统计
	 * @param pageBean
	 * @param param
	 */
	public void getCoalitionOperations(UTPageBean pageBean,Map param){
		attendanceStatisticsCountDao.getCoalitionOperations(pageBean, param);
	}
	
	/**
	 * 运维考勤统计（供应商）
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllSupplierOperations(Map param){
		return attendanceStatisticsCountDao.getAllSupplierOperations(param);
	}
	
	/**
	 * 运维考勤统计（供应商）
	 * @param pageBean
	 * @param param
	 */
	public void getSupplierOperations(UTPageBean pageBean,Map param){
		attendanceStatisticsCountDao.getSupplierOperations(pageBean, param);
	}
	
	/**
	 * 运维考勤统计（部门）
	 * @param pageBean
	 * @param param
	 */
	public List<UTMap<String, Object>> getAllOrgOperations(Map param){
		return attendanceStatisticsCountDao.getAllOrgOperations(param);
	}
	
	/**
	 * 运维考勤统计（部门）
	 * @param pageBean
	 * @param param
	 */
	public void getOrgOperations(UTPageBean pageBean,Map param){
		attendanceStatisticsCountDao.getOrgOperations(pageBean, param);
	}
	
	/**
	 * 点击异常率查询详情数据接口
	 * @param param
	 * @return
	 */
	public void getDetail(UTPageBean pageBean,Map param){
		attendanceStatisticsCountDao.getDetail(pageBean,param);
	}
	
	/**
	 * 点击异常率查询详情数据接口
	 * @param param
	 * @return
	 */
	public List<UTMap<String, Object>> getDetail(Map param){
		return attendanceStatisticsCountDao.getDetail(param);
	}
	
	/**
	 * 默认导出运维考勤个人统计数据，如果isAll=true，则导出包括联合考勤的数据
	 * @param data
	 * @param request
	 * @param response
	 * @param isAll
	 * @throws Exception
	 */
	public void leadingout(List data, HttpServletRequest request, HttpServletResponse response,boolean isAll) throws Exception {
		String[] fileds = IAttendanceStatisticsCountDao.outFileds;
		if (null != data && !data.isEmpty()) {
			for (int i=0;i<data.size();i++) {
				UTMap<String, Object> item = (UTMap<String, Object>) data.get(i);
				item.put(IAttendanceStatisticsCountDao.FIELD_BEGINDATE, CommonUtils.replaceAll((String)item.get(IAttendanceStatisticsCountDao.FIELD_BEGINDATE), "-", "/"));
				item.put(IAttendanceStatisticsCountDao.FIELD_ENDDATE, CommonUtils.replaceAll((String)item.get(IAttendanceStatisticsCountDao.FIELD_ENDDATE), "-", "/"));
			}
		}
		String tamlate = "excelOutTamplate.attendanceStatisticsCount";
		if(isAll){
			fileds = IAttendanceStatisticsCountDao.outFiledsCoalition;
			tamlate = "excelOutTamplate.attendanceStatisticsCountCoalition";
		}
		UTExcel.leadingout( fileds, data, tamlate, request, response);
	}
	
	/**
	 * 运维联合考勤统计导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	@Override
	public void leadingoutAttCoalitionOperations(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String[] fileds = IAttendanceStatisticsCountDao.outAttCoalitionOperationsCountFileds;
		if (null != data && !data.isEmpty()) {
			for (int i=0;i<data.size();i++) {
				UTMap<String, Object> item = (UTMap<String, Object>) data.get(i);
				item.put(IAttendanceStatisticsCountDao.FIELD_BEGINDATE, CommonUtils.replaceAll((String)item.get(IAttendanceStatisticsCountDao.FIELD_BEGINDATE), "-", "/"));
				item.put(IAttendanceStatisticsCountDao.FIELD_ENDDATE, CommonUtils.replaceAll((String)item.get(IAttendanceStatisticsCountDao.FIELD_ENDDATE), "-", "/"));
			}
		}
		String tamlate = "excelOutTamplate.attCoalitionOperationsCount";
		UTExcel.leadingout( fileds, data, tamlate, request, response);
	}
	
	/**
	 * 运维考勤统计（供应商）导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	@Override
	public void leadingoutAttSupplierOperations(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String[] fileds = IAttendanceStatisticsCountDao.outAttSupplierOperationsCountFileds;
		if (null != data && !data.isEmpty()) {
			for (int i=0;i<data.size();i++) {
				UTMap<String, Object> item = (UTMap<String, Object>) data.get(i);
				item.put(IAttendanceStatisticsCountDao.FIELD_YEARMONTH, CommonUtils.replaceAll((String)item.get(IAttendanceStatisticsCountDao.FIELD_YEARMONTH), "-", "/"));
			}
		}
		String tamlate = "excelOutTamplate.attSupplierOperationsCount";
		UTExcel.leadingout( fileds, data, tamlate, request, response);
	}
	
	/**
	 * 运维考勤统计（部门）导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	@Override
	public void leadingoutAttOrgOperations(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String[] fileds = IAttendanceStatisticsCountDao.outAttOrgOperationsCountFileds;
		if (null != data && !data.isEmpty()) {
			for (int i=0;i<data.size();i++) {
				UTMap<String, Object> item = (UTMap<String, Object>) data.get(i);
				item.put(IAttendanceStatisticsCountDao.FIELD_YEARMONTH, CommonUtils.replaceAll((String)item.get(IAttendanceStatisticsCountDao.FIELD_YEARMONTH), "-", "/"));
			}
		}
		String tamlate = "excelOutTamplate.attOrgOperationsCount";
		UTExcel.leadingout( fileds, data, tamlate, request, response);
	}

	/**
	 * 运维考勤统计详情导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 */
	public void leadingoutAttOperationsDetail(List data, HttpServletRequest request,
			HttpServletResponse response)throws Exception{
		String[] fileds = IAttendanceStatisticsCountDao.outAttOperationsCountDetailFileds;
		if (null != data && !data.isEmpty()) {
			for (int i=0;i<data.size();i++) {
				UTMap<String, Object> item = (UTMap<String, Object>) data.get(i);
				item.put(IAttendanceStatisticsCountDao.FIELD_YEARMONTH, CommonUtils.replaceAll((String)item.get(IAttendanceStatisticsCountDao.FIELD_YEARMONTH), "-", "/"));
			}
		}
		String tamlate = "excelOutTamplate.attOperationsCountDetail";
		UTExcel.leadingout( fileds, data, tamlate, request, response);
	}

}
