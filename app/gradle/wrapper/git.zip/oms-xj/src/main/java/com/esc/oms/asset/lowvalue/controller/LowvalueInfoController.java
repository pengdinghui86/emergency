package com.esc.oms.asset.lowvalue.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.asset.lowvalue.service.ILowvalueInfoService;
import com.esc.oms.util.CommonUtils;

import net.sf.json.JSONObject;
@Controller
@RequestMapping("lowvalueInfo")
public class LowvalueInfoController extends BaseOptionController {

	@Resource
	private ILowvalueInfoService service;
	
	@Override
	public IBaseOptionService optionService() {
		return service;
	}
	
	/**
	 * 新增，需要返回一个Id给前台的其他标签
	 * @param info
	 * @return
	 */
	@RequestMapping(value="add",method =RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> add(@RequestBody  Map<String, Object> info){
		Map<String,Object> cloneMap = CommonUtils.clone(info);
		try{ 
    		boolean result = optionService().add(cloneMap);
    		if(result){
    			cloneMap.put("success", true);
    			cloneMap.put("msg", "操作成功！");
    		}else{
    			cloneMap.put("success", false);
//        		info.put("msg", "操作失败！");
    		}   		
    	}catch(EscServiceException e){
    		cloneMap.put("success", false);
    		cloneMap.put("msg", e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		cloneMap.put("success", false);
    		cloneMap.put("msg", "操作失败！");
    	}
       return cloneMap;
	}
	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			service.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	/**
	 * 导出
	 * @param param
	 * @param utPageBean
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "leadingout")
	public void leadingout(@RequestParam Map<String, Object> param,
			HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = null;
			if(info != null) {
				jsonBean = JSONObject.fromObject(info);
			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = service.getListAll(jsonBean);
			} else {
				service.getPageInfo(utPageBean, jsonBean);
				data = utPageBean.getRows();
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			service.leadingout(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
}