package com.esc.oms.asset.software.controller;

import com.esc.oms.asset.software.service.IAssetSoftwareService;
import com.esc.oms.asset.software.service.ISoftCategoryService;
import com.esc.oms.asset.software.service.ISoftHistoryService;
import com.esc.oms.util.CommonUtils;
import net.sf.json.JSONObject;
import org.apache.commons.io.FilenameUtils;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("assetSoft")
public class AssetSoftwareController extends BaseOptionController {

	@Resource
	private IAssetSoftwareService assetSoftwareService;
	
	@Resource
	private ISoftHistoryService softHistoryService;
	
	@Resource
	private ISoftCategoryService softCategoryService;
	
	
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			assetSoftwareService.getPageInfo(pageBean, params);
			
			List<Map<String, Object>> list = pageBean.getRows();
			
			if(null != list && list.size() > 0 ){
				for (Map<String, Object> map : list) {
					int status = (Integer)map.get("status");
					if(1 == status){
						map.put("status", "待启用");
					}else if(2 == status){
						map.put("status", "正在使用");
					}else if(3 == status){
						map.put("status", "维护期");
					}else{
						map.put("status", "停用");
					}
				}
			}
			
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	
	@RequestMapping(value="/saveOrUpdate",method=RequestMethod.POST)  
    @ResponseBody
    public String saveorupdate(@RequestBody Map<String,Object> map){  
    	String id = (String)map.get("id");
    	try{
	    	if(id == null){
//	    		map.put("code", System.currentTimeMillis());
	    		assetSoftwareService.add(map);
	    	}else{
	    		assetSoftwareService.updateById(map);
	    	}
    	}catch(EscServiceException e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false,e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "操作成功");
    }
	

	
	@RequestMapping(value="getById")
	@ResponseBody
	public UTMap<String, Object> defgetById(@RequestParam  Map<String, Object> param){		
		UTMap<String, Object> utmap  = null;
		try{
    		String id = param.get("id").toString();
    		utmap = optionService().getById(id);
    		
    		Map params = new HashMap();
    		params.put("softwareId", id);
    		List<UTMap<String, Object>> list = softHistoryService.getHistoryListBySoftId(params);
    		
    		if (null != list && list.size() > 0) {
    			for (Map<String, Object> map : list) {
    				int status = (Integer) map.get("status");
    				if (1 == status) {
    					map.put("status", "待启用");
    				} else if (2 == status) {
    					map.put("status", "正在使用");
    				} else if (3 == status) {
    					map.put("status", "维护期");
    				} else {
    					map.put("status", "停用");
    				}
    			}
    		}
    		utmap.put("historyList", list);
    		
    		String category = (String)utmap.get("category");
    		List<UTMap<String, Object>> list2 = softCategoryService.getSubCategoryByParentId(category);
    		utmap.put("subCategoryList", list2);
    		
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return utmap;
	}
	
	
	@RequestMapping(value = "leadingout")
	public void leadingout(@RequestParam Map<String, Object> map1,
			HttpServletRequest request,
			HttpServletResponse response) {
		Map<String, Object> param = CommonUtils.clone(map1);
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();

			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = null;
			if (info != null) {
				jsonBean = JSONObject.fromObject(info);
			}

			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = assetSoftwareService.getSoftwareList(jsonBean);
			} else {
				// 根据条件 导出当前
				assetSoftwareService.getPageInfo(utPageBean, jsonBean);
				data = utPageBean.getRows();
			}
			if (null != data && data.size() > 0) {
				for (Map<String, Object> map : data) {
					int status = (Integer) map.get("status");
					if (1 == status) {
						map.put("status", "待启用");
					} else if (2 == status) {
						map.put("status", "正在使用");
					} else if (3 == status) {
						map.put("status", "维护期");
					} else {
						map.put("status", "停用");
					}
					
					String maintenance = String.valueOf(map.get("maintenance"));
					if("1".equals(maintenance)){
						map.put("maintenance", "是");
					}else{
						map.put("maintenance", "否");
					}
					
					String isSafeControl = String.valueOf(map.get("isSafeControl"));
					if("1".equals(isSafeControl)){
						map.put("isSafeControl", "是");
					}else{
						map.put("isSafeControl", "否");
					}
					
					map.put("beginDate", CommonUtils.replaceAll((String) map.get("beginDate"), "-", "/"));
					map.put("endDate", CommonUtils.replaceAll((String) map.get("endDate"), "-", "/"));
					
				}
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			assetSoftwareService.leadingout(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	/**
	 * 从excel导入
	 * 
	 * @param params
	 * @param filePath
	 * @return
	 */
	@RequestMapping(value = "leadingin")
	@ResponseBody
	public UTMap<String, Object> leadingin(@RequestParam Map<String, Object> param, String filePath) {
		UTMap<String, Object> utMap = new UTMap<String, Object>();
		try {
			utMap.put("success", assetSoftwareService.leadingin(FilenameUtils.normalize(filePath), param));
			utMap.put("msg", "导入成功！");
		} catch (EscServiceException e) {
			logger.error("EscServiceException",e);
			utMap.put("success", false);
			utMap.put("msg", e.getMessage());
		} catch (Exception e) {
			logger.error("EscServiceException",e);
			utMap.put("success", false);
			utMap.put("msg", "导入失败");
		}
		return utMap;
	}
	
	/*
	 * // 唯一项验证验证
	 * 
	 * @RequestMapping("isExitItem")
	 * 
	 * @ResponseBody public JSONObject isExitItem(@RequestParam Map<String,
	 * Object> param) { String softName = param.get("name") != null ?
	 * param.get("name").toString() : "";
	 * 
	 * if (StringUtils.isNotEmpty(softName)) { Map<String, Object> map = new
	 * HashMap<String, Object>(); map.put("name", softName); if
	 * (assetSoftwareService.isExist(map)) { return
	 * UTJsonUtils.getMsgJson(false, "请保证软件名称唯一"); } } return
	 * UTJsonUtils.getMsgJson(true, ""); }
	 */
	
	
	
	
	@Override
	public IBaseOptionService optionService() {
		return assetSoftwareService;
	}

}
