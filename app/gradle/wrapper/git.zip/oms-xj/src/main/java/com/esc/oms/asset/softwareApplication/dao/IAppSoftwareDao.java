package com.esc.oms.asset.softwareApplication.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

public interface IAppSoftwareDao extends IBaseOptionDao{
	
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_CODE = "code";
	public static final String  FIELD_NAME = "name";
	
	public static final String  FIELD_CATEGORY   ="category";//软件类型 
	
	public static final String  FIELD_EXPLOIT_TYPE   ="exploitType";//开发类型: 自主开发，合作开发，外包 
	public static final String  FIELD_SHORT_NAME   ="shortName";//简称 
	public static final String  FIELD_STATUS   ="status";//状态：待启用，使用中，已停用 
	public static final String  FIELD_SUPPLIER_ID   ="supplierId";//所属供应商，允许多个供应商 
	public static final String  FIELD_SUPPLIER_CONTACT   ="supplierContact";//供应商联络人 
	public static final String  FIELD_SUPPLIER_CONTACTWAY   ="supplierContactWay";//供应商联络方式 
	
	
	public static final String  FIELD_AGREEMENT_ID   ="agreementId";//所属合同Ids，允许多个合同 
	public static final String  FIELD_VERSION   ="version";//版本号 
	public static final String  FIELD_VERSION_ADDRESS   ="versionAddress";//版本号存放位置 
	public static final String  FIELD_SCCODE_ADDRESS   ="scCodeAddress";//源代码位置 
	public static final String  FIELD_DOCUMENT_ADDRESS   ="documentAddress";//文档存放位置 
	
	public static final String  FIELD_CHARGEID  ="chargeId";//应用开发负责人 
	public static final String  FIELD_CHARGE_NUMBERr  ="chargeNumber";//应用开发负责人联系方式 
	public static final String  FIELD_MAINTAINID ="maintainId";//应用维护负责人 
	public static final String  FIELD_MAINTAIN_NUMBER  ="maintainNumber";//应用维护负责人 
	
	public static final String  FIELD_USE_DEPART_IDS="useDepartIds";//主管业务部门 
	
	public static final String  FIELD_USER_NUM  ="userNum";//用户量 
	public static final String  FIELD_MAINTENANCE   ="maintenance";//是否维保 
	
	public static final String  FIELD_STARTTIME   ="startDate";//服务开始日期 
	public static final String  FIELD_ENDTIME   ="endDate";//服务结束日期 
	
	public static final String  FIELD_IS_STEERABLE   ="isSteerable";//是否自主安全可控 
	public static final String  FIELD_INTELL_PROPERTY   ="intellProperty";//知识产权 
	public static final String  FIELD_INTRODUCATION   ="introducation";//软件介绍 
	
	public static final String  FIELD_CREATE_USERID   ="createUserId"; 
	public static final String  FIELD_IS_EXPIRE   ="isExpire";//是否到期
	public static final String  FIELD_MAINTAIN_CONTRACTID   ="maintainContractId";//维保合同id
	
	
	
	
	public List<UTMap<String, Object>> getSoftwareList(Map param);
	

}
