package com.esc.oms.outsource.outperson.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.outperson.dao.IOutSourcePersonResumeLanguageDao;


/**
 * 简历基本信息
 * @author djj
 * @date   2016-07-18
 */
@Repository
public class OutSourcePersonResumeLanguageDaoImpl extends BaseOptionDao implements IOutSourcePersonResumeLanguageDao {

	@Override
	public String getTableName() {
		return "resume_language";
	}
	
	@Override
	public List<UTMap<String, Object>> getListMaps(Map param) {
		String sql=getSearchSql(param);
		return super.getListBySql(sql, null);
	}

	@Override
	public void getPageInfo(UTPageBean pageBean,Map param){
		String sql=getSearchSql(param);
		 super.getPageListMapBySql(sql,pageBean, null);
	}
	/**
	 * 用户 查询sql 拼接器
	 * @param param
	 * @return
	 */
	private String getSearchSql(Map<String, Object> param){
		Map<String, String> p=UTMap.mapObjToString(param);
		StringBuilder sql=new StringBuilder();
		sql.append(" select * from resume_language language");
		sql.append("	WHERE 1=1  ");
		if(param!=null){
			String infoId = param.get("infoId")==null?null:param.get("infoId").toString();
			if(!StringUtils.isEmpty(infoId)){
				sql.append(" and language.infoId='"+infoId+"'");
			}
		}
		return sql.toString();
	}

}
