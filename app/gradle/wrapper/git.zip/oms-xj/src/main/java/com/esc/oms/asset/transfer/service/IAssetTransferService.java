package com.esc.oms.asset.transfer.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;


public interface IAssetTransferService extends IBaseOptionService{
	
	public boolean addRelation(Map info);
	
	
	/**
	 * 根据资产id删除备件联系
	 * @param id
	 * @return
	 */
	public boolean deleteAssetsById(String id);
	

	/**
	 * 查询备件
	 * */
	public List<UTMap<String, Object>> getAssetsById(String id) ;
	

	/**
	 * 获取待审列表
	 * @param pageBean
	 * @param params
	 */
	public void getPendApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) ;

	/**
	 * 获取已审列表
	 * @param pageBean
	 * @param params
	 */
	public void getAlreadyApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) ;
	

	/** 
	* @Title: getAssetsList 
	* @Description: TODO 
	* @param param
	* @return List<UTMap<String,Object>>
	* @author smq
	* @date 2018年9月3日上午11:56:38
	*/ 
	public List<UTMap<String, Object>> getAssetsList(Map param);
	
	/** 
	* @Title: leadingout 
	* @Description: TODO 
	* @param data
	* @param request
	* @param response
	* @return
	* @throws Exception boolean
	* @author smq
	* @date 2018年9月3日上午11:56:32
	*/ 
	public boolean leadingout(List data, HttpServletRequest request,HttpServletResponse response) throws Exception;
	
	
	/**
    * 生成数据
	* @Title: generate 
	* @Description: TODO  void
	* @author smq
	* @date 2018年9月3日上午11:56:41
	*/ 
	public void generate();
	
	/** 
	* @Title: updateAssetsInfo 
	* @Description: TODO 
	* @param assetsList
	* @param map
	* @return boolean
	* @author smq
	* @date 2018年9月3日上午11:56:57
	*/ 
	public boolean updateAssetsInfo(List assetsList,Map<String, Object> map);
	
	
	/**
	 * 保存数据并提交
	 * @param map
	 */
	public void submit(Map<String,Object> map);
	
	/**
	 * 完成审核
	 * @param recordId 记录ID
	 */
	public void finishAudit(String recordId);
	
	/**
	 * 驳回审核
	 * @param recordId 记录ID
	 */
	public void rejectAudit(String recordId);
	

	/**
	 * 终止审核
	 * @param recordId
	 */
	public void terminate(String recordId);
	

	/**
	 * 流程进行到某个节点的时候
	 * @param workflowCode
	 * @param businessRecordId
	 * @param nodeName
	 * @param linkName
	 * @return
	 */
	public boolean optionNode(String workflowCode, String businessRecordId,	String nodeName, String linkName) ;
	

}
