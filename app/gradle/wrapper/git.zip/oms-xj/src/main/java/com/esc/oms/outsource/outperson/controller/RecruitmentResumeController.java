package com.esc.oms.outsource.outperson.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.upload.service.ISysFileService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.outsource.outperson.service.IRecruitmentResumeService;
import com.esc.oms.util.CommonUtils;

@Controller
@RequestMapping("/recruitmentResume")
public class RecruitmentResumeController extends BaseOptionController {

	@Resource
	private IRecruitmentResumeService service;
	
	@Resource
	private ISysFileService fileService;
	
	@Override
	public IBaseOptionService optionService() {
		return service;
	}
	
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			service.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	@RequestMapping(value="getAllForInterview")  
    @ResponseBody
    public UTPageBean getAllForInterview(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			service.getPageInfoForInterview(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	/**
	 * 管理员筛选
	 * @param info
	 * @return
	 */
	@RequestMapping(value="managerScreen",method =RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> managerScreen(@RequestBody  Map<String, Object> info){
		try{ 		
			boolean result = service.managerScreen(info);
    		if(result){
    			info.put("success", true);
        		info.put("msg", "操作成功！");
    		}else{
    			info.put("success", false);
        		info.put("msg", "操作失败！");
    		}   		
    	}catch(EscServiceException e){
			info.put("success", false);
			info.put("msg", e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		info.put("success", false);
    		info.put("msg", "操作失败！");
    	}
       return info;
	}
	
	/**
	 * 申请人筛选
	 * @param info
	 * @return
	 */
	@RequestMapping(value="applyUserScreen",method =RequestMethod.POST)
	@ResponseBody
	public  Map<String, Object> applyUserScreen(@RequestBody  Map<String, Object> info){
		try{ 			
			boolean result = service.applyUserScreen(info);
    		if(result){
    			info.put("success", true);
        		info.put("msg", "操作成功！");
    		}else{
    			info.put("success", false);
        		info.put("msg", "操作失败！");
    		}   		
    	}catch(EscServiceException e){
			info.put("success", false);
			info.put("msg", e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		info.put("success", false);
    		info.put("msg", "操作失败！");
    	}
       return info;
	}
	
	/**
	 * 面试结果
	 * @param info
	 * @return
	 */
	@RequestMapping(value="interview",method =RequestMethod.POST)
	@ResponseBody
	public String interview(@RequestBody  Map<String, Object> info){
		try{			
			service.interview(info);
    	}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "操作成功");
	}
	@RequestMapping(value="addInterview", method=RequestMethod.POST)
	@ResponseBody
	public String addInterview(@RequestBody  Map<String, Object> map1) {
		Map<String, Object> info = CommonUtils.clone(map1);
		try{		
			info.put("interviewStatus", "0");
			boolean flag = service.addInterview(info);
			//UTMap<String, Object> item = service.getInterviewById(info.get("id").toString());
			if (!flag) {
				return UTJsonUtils.getJsonMsg(false, "操作失败");
			}else {
				String recruitmentResumeId = (String) info.get("recruitmentResumeId");
				Map<String, Object> param = new HashMap<String, Object>();
				param.put("recruitmentResumeId", recruitmentResumeId);
				List<UTMap<String, Object>> interviews = service.getInterviewByInfo(param);
				if (null != interviews && !interviews.isEmpty()) {
					boolean isFinish = true;
					boolean isPassed = true;
					for (UTMap<String, Object> interview : interviews) {
						String interviewResult = (String) interview.get("interviewResult");
						
						if (StringUtils.isEmpty(interviewResult)) {//有为空的则表示还存在未打分的面试人
							isFinish = false;
						}
						
						if (StringUtils.isNotEmpty(interviewResult) && Float.valueOf(interviewResult) < 60.0) {//有小于60分的就表示不通过
							isPassed = false;
						}
					}
					
					if(isFinish) {//如果已经完成则统计打分结果
						Map<String, Object> map = new HashMap<String, Object>();
						map.put("id", recruitmentResumeId);
						if (isPassed) {
							map.put("interviewResult", "1");
						}else {
							map.put("interviewResult", "2");
						}
						service.updateById(map);
					}else {
						Map<String, Object> map = new HashMap<String, Object>();
						map.put("id", recruitmentResumeId);
						map.put("interviewResult", "");
						if (!isPassed) {
							map.put("interviewResult", "2");
						}
						service.updateById(map);
					}
				}

			}
    	}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
		return UTJsonUtils.getJsonMsg(true, "操作成功");
	}
	@RequestMapping(value = "getInterviewByInfo",method =RequestMethod.POST)
	@ResponseBody
	public List<UTMap<String, Object>> getInterviewByInfo(@RequestBody  Map<String, Object> info){
		
		return service.getInterviewByInfo(info);
	}
	
	@RequestMapping(value = "getInterviewById", method= RequestMethod.POST)
	@ResponseBody
	public UTMap<String, Object> getInterviewById(@RequestBody Map<String, Object> info){
		return service.getInterviewById((String) info.get("id"));
	}
	
	@RequestMapping(value="removeInterview", method=RequestMethod.POST)
	@ResponseBody
	public String removeInterview(@RequestBody  Map<String, Object> info) {
		String id = (String) info.get("id");
		UTMap<String, Object> item = service.getInterviewById(id);
		boolean flag = service.removeInterview(id);
		if (flag) {
			String recruitmentResumeId = (String) item.get("recruitmentResumeId");
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("recruitmentResumeId", recruitmentResumeId);
			List<UTMap<String, Object>> interviews = service.getInterviewByInfo(param);
			if (null != interviews && !interviews.isEmpty()) {
				boolean isFinish = true;
				boolean isPassed = true;
				for (UTMap<String, Object> interview : interviews) {
					String interviewResult = (String) interview.get("interviewResult");
					if (StringUtils.isEmpty(interviewResult)) {//有为空的则表示还存在未打分的面试人
						isFinish = false;
					}
					if (StringUtils.isNotEmpty(interviewResult) && Float.valueOf(interviewResult) < 60.0) {//有小于60分的就表示不通过
						isPassed = false;
					}
				}
				
				if(isFinish) {//如果已经完成则统计打分结果
					Map<String, Object> map = new HashMap<String, Object>();
					map.put("id", recruitmentResumeId);
					if (isPassed) {
						map.put("interviewResult", "1");
					}else {
						map.put("interviewResult", "2");
					}
					service.updateById(map);
				}else {
					Map<String, Object> map = new HashMap<String, Object>();
					map.put("id", recruitmentResumeId);
					map.put("interviewResult", "");
					if (!isPassed) {
						map.put("interviewResult", "2");
					}
					service.updateById(map);
				}
			}
			return UTJsonUtils.getJsonMsg(true, "操作成功");
		}else {
			return UTJsonUtils.getJsonMsg(false, "操作失败");
		}
		
	}
	
	/**
	 * 关闭面试
	 * @param info
	 * @return
	 */
	@RequestMapping(value="closeInterview", method=RequestMethod.POST)
	@ResponseBody
	public String closeInterview(@RequestBody  Map<String, Object> info) {
		info.put("workflowStatus", "0");
		if (service.updateById(info)) {
			//更新面试人数据
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("recruitmentResumeId", info.get("id"));
			List<UTMap<String, Object>> interviews = service.getInterviewByInfo(param);
			if (null != interviews && !interviews.isEmpty()) {
				for (UTMap<String, Object>  item : interviews) {
					UTMap<String, Object> newItem = new UTMap<String, Object>();
					newItem.put("interviewStatus", "2");
					newItem.put("id", item.get("id"));
					service.updateInterview(newItem);
				}
			}
			return UTJsonUtils.getJsonMsg(true, "操作成功");
		}
		return UTJsonUtils.getJsonMsg(false, "操作失败");
	}
	
	@RequestMapping(value="updateGradeResult", method=RequestMethod.POST)
	@ResponseBody
	public String updateGradeResult(@RequestBody  Map<String, Object> info) {
		info.put("interviewStatus", "1");
		boolean flag = service.updateGradeResult(info);
		if (flag) {
			String recruitmentResumeId = (String) info.get("recruitmentResumeId");
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("recruitmentResumeId", recruitmentResumeId);
			List<UTMap<String, Object>> interviews = service.getInterviewByInfo(param);
			if (null != interviews && !interviews.isEmpty()) {
				boolean isFinish = true;
				boolean isPassed = true;
				for (UTMap<String, Object> interview : interviews) {
					String interviewResult = (String) interview.get("interviewResult");
					if (StringUtils.isEmpty(interviewResult)) {//有为空的则表示还存在未打分的面试人
						isFinish = false;
					}
					if (StringUtils.isNotEmpty(interviewResult) && Float.valueOf(interviewResult) < 60.0) {//有小于60分的就表示不通过
						isPassed = false;
					}
				}
				
				if(isFinish) {//如果已经完成则统计打分结果
					Map<String, Object> map = new HashMap<String, Object>();
					map.put("id", recruitmentResumeId);
					if (isPassed) {
						map.put("interviewResult", "1");
					}else {
						map.put("interviewResult", "2");
					}
					service.updateById(map);
				}else {
					Map<String, Object> map = new HashMap<String, Object>();
					map.put("id", recruitmentResumeId);
					map.put("interviewResult", "");
					if (!isPassed) {
						map.put("interviewResult", "2");
					}
					service.updateById(map);
				}
			}
			return UTJsonUtils.getJsonMsg(true, "操作成功");
		}else {
			return UTJsonUtils.getJsonMsg(false, "操作失败");
		}
	}

}
