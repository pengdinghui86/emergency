package com.esc.oms.outsource.external.controller;

import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.outsource.external.service.IExternalEvaluateConfigurationService;
import com.esc.oms.util.CommonUtils;

/**
 * 非驻场外包评估配置Controller
 * @author owner
 *
 */
@Controller
@RequestMapping("externalEvaluateConfiguration")
public class ExternalEvaluateConfigurationController extends BaseOptionController {

	@Resource
	private IExternalEvaluateConfigurationService service;
	
	@Override
	public IBaseOptionService optionService() {
		return service;
	}
	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			service.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	/**
	 * 根据id查询
	 * @param param
	 * @return
	 */
	@RequestMapping(value="getByIdToAccessResult")
	@ResponseBody
	public UTMap<String, Object> getByIdToAccessResult(@RequestParam  Map<String, Object> param){		
//		logger.info("执行默认根据Id获取方法");
//		return UTJsonUtils.getResultJson(true, optionService().getById(param.get("id").toString()));
		UTMap<String, Object> map = null;
    	try{
    		map = service.getByIdToAccessResult(param.get("id").toString());
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return map;
	}
	
	/**
	 * 总评估
	 * @param info
	 * @return
	 */
	@RequestMapping(value="evaluate")
	@ResponseBody
	public String evaluate(@RequestBody  Map<String, Object> info){
		try{
			service.evaluate(info);
    	}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "操作成功");
	}
	
	/**
	 * 关闭
	 * @param info
	 * @return
	 */
	@RequestMapping(value="close")
	@ResponseBody
	public String close(@RequestBody  Map<String, Object> info){
		try{
			service.close(info);
    	}catch(EscServiceException e){
    		logger.error("EscServiceException", e);
    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "关闭失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "关闭成功");
	}
	
	/**
	 * 生成评估数据
	 * @param id
	 */
//	@RequestMapping(value="generateData")
//	@ResponseBody
//	public String generateData(@RequestParam  Map<String, Object> info){
//		try{
//			service.generateData(info.get("id")+"");
//    	}catch(EscServiceException e){
//    		logger.error("EscServiceException", e);
//    		return UTJsonUtils.getJsonMsg(false, e.getMessage());
//    	}catch(Exception e){
//    		logger.error("Exception", e);
//    		return UTJsonUtils.getJsonMsg(false, "数据生成失败！");
//    	}
//       return UTJsonUtils.getJsonMsg(true, "数据生成成功");
//	}

}
