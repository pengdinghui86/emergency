package com.esc.oms.outsource.attendance.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.utils.UTDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.attendance.dao.IFestivalDao;
import com.esc.oms.outsource.attendance.service.IFestivalService;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;


/**
 * 节假日配置Service
 * @author owner
 *
 */
@Service
@Transactional
public class FestivalServiceImpl  extends BaseOptionService implements  IFestivalService {
	private static final Logger logger = LoggerFactory.getLogger(FestivalServiceImpl.class);
	
	@Resource
	private IFestivalDao festivalDao;
	@Override
	public IBaseOptionDao getOptionDao() {
		return festivalDao;
	}
	
	
	/**
	 * 生成当前时间往后一年周末节假日数据
	 */
	@Override
	@EscOptionLog(module=SystemModule.festival, opType=ESCLogOpType.INSERT, table="attendance_festival", option="生成当前时间往后一年周末节假日数据")
	public void initWeekend() {
		Date today = new Date();
		Date oneYearLater = UTDate.getOneYearLaterDay();
		List<String> weekendList = new ArrayList<String>();
		weekendList = UTDate.getWeekendDay(today, oneYearLater, weekendList);
		List<Map> list = new ArrayList<Map>();
		Map po = null;
		Map param = new HashMap();
		
		//批量生成
        for(int i=0; i<weekendList.size(); i++){
        	po = new HashMap();
    		po.put("discription", "周末");
    		po.put("festivalType", 2);//节假日类型：1.工作日  2.周末  3.法定节假日  4.调休  5.其他 
    		po.put("festivalDate", weekendList.get(i));
    		po.put("isFestival", 1);//标识是否为节假日（1.为节假日  0.非节假日）
//        	FestivalPO fpo=festivalDao.findByDate(weekendList.get(i));
    		param.put("festivalDate", weekendList.get(i));
        	if(festivalDao.isExist(param)){
        		logger.info(weekendList.get(i)+"节假日配置在数据库里已经有，不需要重复生成！");
        	}else{
        		festivalDao.add(po);
        		logger.info("---------------------"+weekendList.get(i)+"周末节假日配置生成成功！");
        	}
        }
		
	}
	
	@Override
	@EscOptionLog(module=SystemModule.festival, opType=ESCLogOpType.INSERT, table="attendance_festival", option="新增节{festivalDate}的假日配置")
	public boolean add(Map info) {
		return super.add(info);
	}
	
	@Override
	@EscOptionLog(module=SystemModule.festival, opType=ESCLogOpType.UPDATE, table="attendance_festival", option="修改{festivalDate}的假日配置")
	public boolean updateById(Map info) {
		return super.updateById(info);
	}

	@Override
	@EscOptionLog(module = SystemModule.festival, opType = ESCLogOpType.DELETE,primaryKey="id={1}" , table = "attendance_festival", option = "删除{festivalDate}的节假日配置。")
	public boolean deleteById(String id) {
		// TODO Auto-generated method stub
		return super.deleteById(id);
	}

}
