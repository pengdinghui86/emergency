package com.esc.oms.outsource.attendance.controller;

import javax.annotation.Resource;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.outsource.attendance.service.IFestivalService;



/**
 * 节假日配置
 * @author owner
 *
 */
@Controller
@RequestMapping("festivalController")
public class FestivalController  extends BaseOptionController {
	
	@Resource
	private IFestivalService festivalService;
	
	@Override
	public IBaseOptionService optionService() {
		return festivalService;
	}

	/**
	 * 生成当前年的周末节假日数据
	 */
	@RequestMapping(value="initWeekend")  
	@ResponseBody
	public String getAgreementManpowerPage() {
		try {
			festivalService.initWeekend();
		} catch (Exception e) {
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "生成失败");
		}
		return UTJsonUtils.getJsonMsg(true, "生成成功");
	}
	
}
