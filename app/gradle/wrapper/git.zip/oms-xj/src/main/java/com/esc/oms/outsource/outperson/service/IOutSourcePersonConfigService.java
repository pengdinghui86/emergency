package com.esc.oms.outsource.outperson.service;

import java.util.List;
import java.util.Map;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTListResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

public interface IOutSourcePersonConfigService  extends IBaseOptionService {

	// 为每个 外包人员创建 基础配置
	public void createConfigByUserId(String userId);
	
	//为指定用户添加配置项
	public boolean saveConfigByUserId(List<Map<String, Object>> configsInfo);
	public boolean saveConfigByUserId2(List<Map<String, Object>> configsInfo);
	
	//注销指定用户的配置项
	public boolean cancelConfigByUserId(List<Map<String, Object>> configsInfo);
	
	//指定注销指定用户的 固定配置项
	public void cancelConfigByUserId(String userId);
	public void createConfigByUserId2(String userId);
	
	//基于 系统参数中 配置项 拼接用户配置进行选择
	public 	List<UTMap<String, Object>>  getPersonConfig(String userId);

	public List<UTMap<String, Object>> InitgetPersonConfig(String userId);
	
}
