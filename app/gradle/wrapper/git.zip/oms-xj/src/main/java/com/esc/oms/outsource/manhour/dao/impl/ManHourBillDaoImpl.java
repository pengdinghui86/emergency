package com.esc.oms.outsource.manhour.dao.impl;

import com.esc.oms.outsource.manhour.dao.IManHourBillDao;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 工时账单
 * @author lenovo
 *
 */
@Repository
public class ManHourBillDaoImpl extends BaseOptionDao implements IManHourBillDao {
	@Override
	public String getTableName() {
		return "attendance_man_hour_edit";
	}

	public void billPage(Map<String, Object> param, UTPageBean pageBean) {
		String sql = getBillSql(param);
		super.getPageListMapBySql(sql, pageBean);
	}
	
	public List<UTMap<String, Object>> billList(Map<String, Object> param) {
		String sql = getBillSql(param);
		return super.getListBySql(sql);
	}
	
	private String getBillSql(Map param) {
		StringBuilder sql = new StringBuilder();
		if(param != null && "3".equals(param.get("status"))) {
			sql.append("SELECT s.*, ids_to_name(pi.businessOwner) businessOwnerName,ids_to_name(pi.technicalOwner) technicalOwnerName");
			sql.append(" FROM workhour_bill s ");
			sql.append(" left join project_info pi on pi.id = s.projectId");
			sql.append(" where 1=1 ");
			String supplierName = (String) param.get("supplierName");
			String userName = (String) param.get("userName");
			String orgName = (String) param.get("orgName");
			String projectLeaderName = (String) param.get("projectLeaderName");
			String year = (String) param.get("year");
			String quarter = (String) param.get("quarter");
			String month = (String) param.get("month");
			if(StringUtils.isNotEmpty(orgName)) {
				sql.append(" and s.orgName like '%").append(orgName).append("%' ");
			}
			if(StringUtils.isNotEmpty(supplierName)) {
				sql.append(" and s.supplierName like '%").append(supplierName).append("%' ");
			}
			if(StringUtils.isNotEmpty(userName)) {
				sql.append(" and s.userName like '%").append(userName).append("%' ");
			}
			if(StringUtils.isNotEmpty(projectLeaderName)) {
				sql.append(" and s.projectLeaderName like '%").append(projectLeaderName).append("%' ");
			}
			if(StringUtils.isNotEmpty(year)) {
				sql.append(" and s.year = '").append(year).append("' ");
			}
			if(StringUtils.isNotEmpty(quarter)) {
				sql.append(" and s.quarter = '").append(quarter).append("' ");
			}
			if(StringUtils.isNotEmpty(month)) {
				sql.append(" and s.month = '").append(month).append("' ");
			}
//			sql.append(" group by s.year, s.`quarter`, s.userId,s.projectId ");
		} else {
			sql.append("SELECT s.`year`,s.quarter,ids_to_name(pi.businessOwner) businessOwnerName,ids_to_name(pi.technicalOwner) technicalOwnerName, ");
			sql.append(" ROUND(sum(s.total),2) quarterManhours, ");
			sql.append(" ROUND(sum(s.totalDays),2) quarterManDays, ");
			sql.append(" o.`level`, o.monthlyFee, ");
			sql.append(" s.userId,concat(u.name,'/',u.`code`) userName, ");
			sql.append(" u.orgId departId, u.orgName, ");
			sql.append(" s.supplierId, i.name supplierName, ");
			sql.append(" s.projectId, pi.name projectName, ids_to_name(pi.aleader) projectLeaderName,pi.aleader ");
			
			sql.append(" FROM attendance_man_hour_edit s ");
			sql.append(" join outsource_person_list o on s.userId = o.userId ");
			sql.append(" join supplier_base_info i on i.id = s.supplierId ");
			sql.append(" left join sys_user u on u.id = s.userId ");
			sql.append(" LEFT JOIN project_info pi ON s.projectId = pi.id ");
			
			sql.append(" where 1=1 ");
//			sql.append(" and (year * 10 + `quarter`) < (YEAR(SYSDATE()) * 10 + QUARTER(SYSDATE())) "); // 当前季度之前的数据才显示
			
			if(param != null) {
				String supplierName = (String) param.get("supplierName");
				String userName = (String) param.get("userName");
				String orgName = (String) param.get("orgName");
				String year = (String) param.get("year");
				String quarter = (String) param.get("quarter");
				String month = (String) param.get("month");
				String status = (String) param.get("status");
				if(StringUtils.isNotEmpty(orgName)) {
					sql.append(" and u.orgName like '%").append(orgName).append("%' ");
				}
				if(StringUtils.isNotEmpty(supplierName)) {
					sql.append(" and i.name like '%").append(supplierName).append("%' ");
				}
				if(StringUtils.isNotEmpty(userName)) {
//					sql.append(" and (u.name like '%").append(userName).append("%' ");
//					sql.append(" or u.code like '%").append(userName).append("%') ");
					sql.append(" and CONCAT(u.name,'/',u.code) like '%"+userName+"%' ");
				}
				if(StringUtils.isNotEmpty(year)) {
					sql.append(" and s.year = '").append(year).append("' ");
				}
				if(StringUtils.isNotEmpty(quarter)) {
					sql.append(" and s.quarter = '").append(quarter).append("' ");
				}
				if(StringUtils.isNotEmpty(month)) {
					sql.append(" and s.month = '").append(month).append("' ");
				}
				if(StringUtils.isNotEmpty(status)) {
					sql.append(" and find_in_set(s.status, '").append(status).append("') ");
				}
			}
			sql.append(" group by s.year, s.`quarter`,pi.id, s.userId ");
		}
		


		if(param != null && param.get("projectLeaderName") != null) {
			String projectLeaderName = (String) param.get("projectLeaderName");
			sql.append(" HAVING projectLeaderName LIKE '%").append(projectLeaderName).append("%' ");
		}
		
		sql.append(" order by s.`year` desc, s.`quarter` desc ");
		
		return sql.toString();
	}
	

	public List<UTMap<String, Object>> evaluateDetailList(Map<String, String> param) {
		String sql = getEvaluateDetailSql(param);
		return super.getListBySql(sql);
	}
	
	private String getEvaluateDetailSql(Map<String, String> param) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select e.performanceEvaluator, e.evaluateResult,e.evaluateNum,e.type, ");
		sql.append(" e.performanceEvaluateTemplateId,e.totalNum ");
		sql.append(" from  outsourc_performance_evaluate_user e  where 1=1 ");

		if(param != null) {
			String year = (String) param.get("year");
			String quarter = (String) param.get("quarter");
			String userIds = (String) param.get("userIds");
			String userId = (String) param.get("userId");
			String type = (String) param.get("type");
			String projectId = (String) param.get("projectId");
			if(StringUtils.isNotEmpty(year)) {
				sql.append(" and e.year = '").append(year).append("' ");
			}
			if(StringUtils.isNotEmpty(quarter)) {
				sql.append(" and e.quarter = '").append(quarter).append("' ");
			}
			if(StringUtils.isNotEmpty(userId)) {
				sql.append(" and e.performanceEvaluator = '").append(userId).append("' ");
			}
			if(StringUtils.isNotEmpty(type)) {
				sql.append(" and e.type = '").append(type).append("' ");
			}
			if(StringUtils.isNotEmpty(userIds)) {
				sql.append(" and find_in_set(e.performanceEvaluator, '").append(userIds).append("' ");
			}
			if(StringUtils.isNotEmpty(projectId)){
				sql.append(" and e.projectInfoId  = '"+projectId+"'");
			}
		}
		sql.append(" order by e.performanceEvaluator,e.performanceEvaluateTemplateId ");
		
		return sql.toString();
	}

	public boolean saveBill(Map<String, Object> param) {
		Map<String, Object> info = new HashMap<String, Object>();
		info.put("year", param.get("year"));
		info.put("quarter", param.get("quarter"));
		info.put("userId", param.get("userId"));
		info.put("projectId", param.get("projectId"));
		
		List<UTMap<String, Object>> exists = super.getListByTable("workhour_bill", info, new String[]{"id"});
		if(exists != null && exists.size() > 0) {
			param.put("id", exists.get(0).get("id"));
			return super.updateByPrimaryKey("workhour_bill", param, "id");
		} else {
			return super.saveBySql("workhour_bill", param);
		}
		
	}
}
