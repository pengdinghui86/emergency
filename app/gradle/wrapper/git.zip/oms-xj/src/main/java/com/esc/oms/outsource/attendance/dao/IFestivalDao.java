package com.esc.oms.outsource.attendance.dao;


import java.util.Date;
import java.util.List;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

/**
 * 节假日配置dao接口
 * @author owner
 *
 */
public interface IFestivalDao extends IBaseOptionDao {
	
	/**
	 * 获取对应日期的节假日配置
	 * @param date
	 * @return
	 */
//	public UTMap<String, Object> getByDate(Date date);
	
	/**
	 * 获取对应日期的节假日配置
	 * @param date
	 * @return
	 */
	public UTMap<String, Object> getByDate(String date);


	/**
	 * 根据日期判断是否是节假日
	 * @param date
	 */
	public boolean isFestivalByDate(String date);
	
	/**
	 * 根据日期判断是否是工作日
	 * @param date
	 */
	public boolean isWorkdayByDate(String date);
	
	
	/**
	 * 根据年和月获取对应时间的节假日数据
	 * @param year
	 * @param month
	 * @return
	 */
	public List<UTMap<String, Object>> getByYearAndMonth(int year, int month);
}
