package com.esc.oms.asset.repair.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.log.annotation.EscOptionLog;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.asset.overview.dao.IAssetsTrackInfoDao;
import com.esc.oms.asset.overview.service.IAssetsTrackInfoService;
import com.esc.oms.asset.physical.dao.IAssetPhysicalDao;
import com.esc.oms.asset.repair.dao.IAssetRepairRecordDao;
import com.esc.oms.asset.repair.service.IAssetRepairRecordService;
import com.esc.oms.util.ESCLogEnum.ESCLogOpType;
import com.esc.oms.util.ESCLogEnum.SystemModule;

@Service
@Transactional
public class AssetRepairRecordServiceImpl extends BaseOptionService implements
		IAssetRepairRecordService {

	@Resource
	private IAssetRepairRecordDao assetRepairRecordDao;
	
	@Resource
	private IAssetsTrackInfoService assetsTrackInfoService;
	
	@Resource
	private IAssetPhysicalDao assetPhysicalDao;
	
	@Override
//	@EscOptionLog(module=SystemModule.assetRepairRecord, opType=ESCLogOpType.INSERT, table="assets_material_repair_record", option="新增id为{id}的维修记录。")
	public boolean add(Map info){
		addTrack(info);
		return super.add(info);
	}
	
	@Override
//	@EscOptionLog(module=SystemModule.assetRepairRecord, opType=ESCLogOpType.UPDATE, table="assets_material_repair_record", option="更新id为{id}的维修记录。")
	public boolean updateById(Map info){
//		addTrack(info);
		return super.updateById(info);
	}
	
//	@EscOptionLog(module=SystemModule.assetRepairRecord, opType=ESCLogOpType.DELETE, table="assets_material_repair_record", option="删除id为{id}的维修记录。")
	public boolean deleteById(String id){
		return super.deleteById(id);
	}

	/**
	 * @param info
	 * 添加资产跟踪记录
	 */
	private void addTrack(Map info) {
		UTMap<String,Object> track = new UTMap<String,Object>(); 
		
		String assetsId = (String)info.get("assetsId");
		UTMap<String,Object> asset = assetPhysicalDao.getById(assetsId);
		
		track.put("assetsId",assetsId );
		track.put("userId", asset.get("resUserId"));
		track.put("departId", asset.get("resDepartId"));
		track.put("changeTime", info.get("endTime"));
//		track.put("changeType", IAssetsTrackInfoDao.FIELD_ASSETSREPAIR);
		track.put("changeType", "维修");
		track.put("changeRemark",info.get("beginTime")+"到"+info.get("endTime")+"期间进行维修。");
		track.put("type", 1);
		assetsTrackInfoService.add(track);
	}

	@Override
	public UTMap<String, Object> getRepairRecordById(String id) {
		return assetRepairRecordDao.getRepairRecordById(id);
	}

	@Override
	public List<UTMap<String, Object>> getRepairRecordList(Map param) {
		return assetRepairRecordDao.getRepairRecordList(param);
	}

	@Override
	public IBaseOptionDao getOptionDao() {
		return assetRepairRecordDao;
	}

}
