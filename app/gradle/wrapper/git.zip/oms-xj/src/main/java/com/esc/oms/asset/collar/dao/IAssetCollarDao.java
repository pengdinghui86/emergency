package com.esc.oms.asset.collar.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

public interface IAssetCollarDao extends IBaseOptionDao{
	
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_ASSETSCODE = "assetsCode";
	public static final String  FIELD_ASSETSNAME = "assetsName";
	public static final String  FIELD_ASSETSTYPE = "assetsType";
	public static final String  FIELD_ASSETSSUBTYPE = "assetsSubType";
	public static final String  FIELD_ASSETSBRAND = "assetsBrand";
	public static final String  FIELD_ASSETSMODEL = "assetsModel";
	public static final String  FIELD_RECEPTTYPE = "receptType";
	public static final String  FIELD_RECEPTUSERID = "receptUserId";
	public static final String  FIELD_RECEPTTIME = "receptTime";
	public static final String  FIELD_STATUS = "status";
	public static final String  FIELD_GRANTUSERID = "grantUserId";
	public static final String  FIELD_ASSETSID = "assetsId";
	public static final String  FIELD_RECEPTDES = "receptDes";
	public static final String FIELD_TITLE = "title";
	
	public UTMap<String, Object> getAssetByAssetId(String assetId);
	
	public UTMap<String, Object> getCollarById(String id);
	
	public List<UTMap<String, Object>> getCollarList(Map param);
	
	public UTMap<String, Object> getCollarByStatusList(String assetId);

	public List<UTMap<String, Object>> getAssetsList(Map<String, Object> param);

	public void getAssetCollarPage(Map<String, Object> param, UTPageBean pageBean);

	public List<UTMap<String, Object>> getAssetCollarByApplyId(Map<String, Object> param);

	public boolean addAssetCollar(Map<String, Object> newInfo);

	public boolean deleteAssetCollarByApplyId(String applyId);
	
}
