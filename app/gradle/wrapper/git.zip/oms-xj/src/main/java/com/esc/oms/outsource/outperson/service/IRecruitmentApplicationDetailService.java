package com.esc.oms.outsource.outperson.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTMap;


public interface IRecruitmentApplicationDetailService extends IBaseOptionService{
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params);
	/**
	 * 根据父表的条件查询，即根据领用记录查领用详单
	 * @param params
	 * @return
	 */
	public List<UTMap<String, Object>> getListAllByParentParam(Map params);
	/**
	 * 根据申请id删除
	 * @param applyId
	 * @return
	 */
	public boolean deleteByApplyId(String applyId);
	/**
	 * 简历推荐
	 * @param info
	 */
	public void recommendResume(Map<String, Object> info);
	/**
	 * 关闭
	 * @param info
	 */
	public void close(Map<String, Object> info);
	/**
	 * 导出
	 * @param data
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public boolean leadingout(List data, HttpServletRequest request,HttpServletResponse response) throws Exception ;
	/**
	 * 根据applyId进行关闭
	 * @param applyId
	 */
	public void closeByApplyId(String applyId);
	
}


