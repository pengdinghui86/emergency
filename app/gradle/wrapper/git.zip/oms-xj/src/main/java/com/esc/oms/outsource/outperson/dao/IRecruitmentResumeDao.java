package com.esc.oms.outsource.outperson.dao;

import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

public interface IRecruitmentResumeDao extends IBaseOptionDao{
	
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_CODE = "code";
	public static final String  FIELD_NAME = "name";
	
	//1.管理员筛选  2.业务部门筛选   3.预约及面试  4.完成
	public static final String STATUS_MANAGER_FILTER = "1";
	public static final String STATUS_BUSINESS_FILTER = "2";
	public static final String STATUS_INTERVIEW = "3";
	public static final String STATUS_FINISH = "4";
	
	//面试结果
	public static final String RESULT_SUCCESS = "1";
	public static final String RESULT_FAIL = "2";
	
	//简历筛选结果
	public static final String RESUME_FILTER_RESULT_SUCCESS = "1";
	public static final String RESUME_FILTER_RESULT_FAIL = "-1";
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	public List<UTMap<String, Object>> getListAll(Map params);

	/**
	 * 根据领用记录的条件查询领用详单	
	 * @param params
	 * @return
	 */
	public List<UTMap<String, Object>> getListAllByParentParam(Map parentParams);

	public List<UTMap<String, Object>> getInterviewByInfo(Map<String, Object> info);

	public boolean addInterview(Map<String, Object> info);

	public boolean removeInterview(String id);

	public void getPageInfoForInterview(UTPageBean pageBean, Map<String, Object> params);

	public boolean updateGradeResult(Map<String, Object> info);

	public UTMap<String, Object> getInterviewById(String id);

	public void updateInterview(UTMap<String, Object> item);
	
}
