package com.esc.oms.outsource.outperson.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.service.ISysOrgService;
import org.esc.framework.security.service.impl.SysUserService;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.timetask.anotations.CronTimeTask;
import org.esc.framework.timetask.anotations.TimeTaskMark;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.outperson.dao.IOutSourcePersonChangeDao;
import com.esc.oms.outsource.outperson.service.IOutSourcePersonChangeService;
import com.esc.oms.outsource.outperson.service.IOutSourcePersonService;
import com.esc.oms.supplier.supplieremp.dao.ISupplierEmpWorkrecordDao;
import com.esc.oms.util.CommonUtils;
import com.esc.oms.util.FunctionEnum.WorkRecordType;


/**
 * 外包人员更改记录
 * @author jane
 *
 */
@Service
@Transactional
@TimeTaskMark
public class OutSourcePersonChangeServiceImpl extends BaseOptionService implements IOutSourcePersonChangeService  {
	
	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private IOutSourcePersonChangeDao outSoucePersonChangeDao;
	
	@Resource
	private IOutSourcePersonService outSourcePersonService;
	
	@Resource
	private SysUserService sysUserService;
	
	@Resource
	private ISysOrgService sysOrgService;
	
	@Resource
	private ISupplierEmpWorkrecordDao workrecordDao;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return outSoucePersonChangeDao;
	}
	
	@Override
	public List<UTMap<String, Object>> getLevelsByUserId(String userId) {
		return outSoucePersonChangeDao.getLevelsByUserId(userId);
	}
	
	/**
	 * 添加
	 * @param info
	 * @return
	 */
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean add(Map info){
		boolean flag = false;
		flag = getOptionDao().add(info);
		String beginDate = info.get("beginDate").toString();
		try {
			if(flag && compareDate(beginDate)){
				changePersonInfo(info);
			}
		} catch (Exception e) {
			logger.error("Exception",e);
		}
		return	flag;
	}
	
	/**
	 * 修改
	 * @param info
	 * @return
	 */
	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean updateById(Map info){
		boolean flag = false;
		flag = getOptionDao().updateById(info);
		String beginDate = info.get("beginDate").toString();
		try {
			if(flag && compareDate(beginDate)){
				changePersonInfo(info);
			}
		} catch (Exception e) {
			logger.error("Exception",e);
		}
		return flag;
	}

	@Override
	public boolean leadingout(List data, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String[] fileds = new String[] { 
				IOutSourcePersonChangeDao.FIELD_SUPPLIERNAME,
				IOutSourcePersonChangeDao.FIELD_CHANGEUSERNAME,
				IOutSourcePersonChangeDao.FIELD_CHANGETYPE,
				IOutSourcePersonChangeDao.FIELD_BEGINDATE,
				IOutSourcePersonChangeDao.FIELD_CHANGEBEFORE,
				IOutSourcePersonChangeDao.FIELD_CHANGEAFTER,
				IOutSourcePersonChangeDao.FIELD_REMARK
		};
		if (null != data && !data.isEmpty()) {
			for (int i=0;i<data.size();i++) {
				UTMap<String, Object> item = (UTMap<String, Object>) data.get(i);
				item.put(IOutSourcePersonChangeDao.FIELD_BEGINDATE, CommonUtils.replaceAll((String)item.get(IOutSourcePersonChangeDao.FIELD_BEGINDATE), "-", "/"));
			}
		}
		String tamlate="excelOutTamplate.outSoucePersonChange";	
		return	UTExcel.leadingout( fileds, data, tamlate, request,response);
	}

	 private boolean compareDate(String beginDate) throws Exception{
		   Date nowDate = new Date();
		   SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		   Date allocDate = sdf.parse(beginDate);
		   boolean flag = allocDate.before(nowDate);
		   return flag;
	   }
	 
	 	@CronTimeTask(description="每天凌晨定时更新当天需要变更的外包人员信息",cron="0 0 0 * * ?")
		@Override
		public void generate() {
			logger.info("开始定时更新当天需要变更的外包人员信息！=========================================================");
			UTMap<String,Object> map = new UTMap<String,Object>();
			map.put("beginDate", new Date());
			List<UTMap<String, Object>> list = outSoucePersonChangeDao.getListMaps(map);
			if(list != null){
				for (UTMap<String, Object> utMap : list) {
					changePersonInfo(utMap);
			}
			logger.info("成功定时更新当天需要变更的外包人员信息！=========================================================");
		}
	}
	 
	 public void changePersonInfo(Map utMap){
		 if("0".equals(String.valueOf(utMap.get("changeType")))){
				//更改外包人员信息
				UTMap<String,Object> outSourcePerson = new UTMap<String,Object>();
				outSourcePerson.put("userId", utMap.get("changeUserId"));
				outSourcePerson.put("level", utMap.get("changeAfter"));
				outSourcePerson.put("monthlyFee", utMap.get("monthlyFee"));
				outSourcePersonService.updateBy(outSourcePerson, "userId");
				
				//外包人员轨迹
				workrecordDao.add(String.valueOf(utMap.get("changeUserId")), "人员级别变更", String.valueOf(utMap.get("beginDate")), null,"由级别【"+String.valueOf(utMap.get("changeBefore"))+"】变更为【"+String.valueOf(utMap.get("changeAfter"))+"】",String.valueOf(utMap.get("remark")), WorkRecordType.UPDATELEVE);
				
			}else{
				//更改外包人员信息
				UTMap<String,Object> outSourcePerson = new UTMap<String,Object>();
				outSourcePerson.put("userId", utMap.get("changeUserId"));
				outSourcePerson.put("departId", utMap.get("changeAfter"));
				outSourcePersonService.updateBy(outSourcePerson, "userId");
				
				//更改人员信息
				Map<String,Object> user = new UTMap<String,Object>();
				user.put("id", utMap.get("changeUserId"));
				user.put("orgId", utMap.get("changeAfter"));
//				user.put("orgId", utMap.get("changeAfter"));
				UTMap<String,Object> org = sysOrgService.getById(String.valueOf(utMap.get("changeAfter")));
				if(null != org){
					user.put("orgName", org.get("longName"));
				}
				sysUserService.updateBy(user,"id");
				
				//外包人员轨迹
				workrecordDao.add(String.valueOf(utMap.get("changeUserId")), "部门变更", String.valueOf(utMap.get("beginDate")), null,"由部门【"+String.valueOf(utMap.get("changeBefore"))+"】变更为【"+org.get("longName").toString().replace('!', '/')+"】",String.valueOf(utMap.get("remark")), WorkRecordType.UPDATEDEP);
		}
	 }
}
