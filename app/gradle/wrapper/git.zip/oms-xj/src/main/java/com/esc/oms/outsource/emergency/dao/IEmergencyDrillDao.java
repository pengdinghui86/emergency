package com.esc.oms.outsource.emergency.dao;

import java.util.List;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

public interface IEmergencyDrillDao extends IBaseOptionDao{
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_NAME = "name";
	public static final String  FIELD_STARTTIME = "startTime";
	public static final String  FIELD_ENDTIME = "endTime";
	public static final String  FIELD_COMMUNICATETYPE = "communicateType";
	public static final String  FIELD_AIM = "aim";
	public static final String  FIELD_LECTURER = "lecturer";
	public static final String  FIELD_CONTENT = "content";
	public static final String  FIELD_RESULTTEXT = "resultText";
	public static final String  FIELD_PROMOTER = "promoter";
	public static final String  FIELD_SUPPLIEROBJ = "supplierObj";
	public static final String  FIELD_INTERNALOBJ = "internalObj";
	public static final String  FIELD_DRILLNAME = "drillName";
	public static final String  FIELD_RESULTEXPLAIN = "resultExplain";
	
	public List<UTMap<String, Object>> getDrillByNameAndId(String name,String id);
}
