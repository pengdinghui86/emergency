package com.esc.oms.outsource.attendance.service;

import org.esc.framework.service.IBaseOptionService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

/**
 * 考勤工时填报Service接口
 * @author owner
 *
 */
public interface IManHourEditService extends IBaseOptionService {
	
	/**
	 * 每天检查生成工时填报的数据
	 */
	public void initData(Date date,boolean isStatisticsManHour);
	
	/**
	 * 重新统计生成上一个月的数据
	 */
	public void afreshDate(LocalDateTime dateTime);
	
	/**
	 * 统计指定年月的人力外包考勤工时
	 * @param statisticsYear
	 * @param statisticsMonth
	 */
	public void statisticsManHour(int statisticsYear, int statisticsMonth);
	
	public void leadingout(List data, HttpServletRequest request, HttpServletResponse response) throws Exception;
	
}
