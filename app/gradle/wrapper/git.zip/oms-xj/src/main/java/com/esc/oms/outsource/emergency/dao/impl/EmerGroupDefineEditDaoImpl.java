package com.esc.oms.outsource.emergency.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.emergency.dao.IEmerGroupDefineEditDao;
@Repository
public class EmerGroupDefineEditDaoImpl extends BaseOptionDao implements IEmerGroupDefineEditDao{
	

	@Override
	public String getTableName() {
		return "outsource_emergroup_define";
	}
	

	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params), pageBean, null);
	}

	public List<UTMap<String, Object>> getListMaps(Map param) {
		return	super.getListBySql(getSearchSql(param), null);
	}
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params){
		StringBuilder sql=new StringBuilder();
		sql.append("select tb.id,tb.`groupName`,tb.responsDefine,tb.createUser,tb.createTime,tb.updateTime,tb.updateUser from " );
		sql.append(getTableName());
		sql.append(" tb where 1=1 ");
		if(params!=null && params.size()>0){
			if(params.get("groupName")!=null &&  StringUtils.isNotEmpty(params.get("groupName").toString())){
				sql.append(" and tb.groupName like '%"+params.get("groupName").toString().trim()+"%' ");
			}
		}
		sql.append(" order by tb.createTime desc,tb.code");
		return  sql.toString();
	}
	
	
	@Override
	public List<UTMap<String, Object>> getListByName(String groupName) {
		StringBuilder sql=new StringBuilder();
		sql.append("select * from " );
		sql.append(getTableName());
		sql.append(" tb where 1=1 ");
		sql.append(" and tb.groupName = '"+groupName+"' ");
		return super.getListBySql(sql.toString());
	}


	@Override
	public List<UTMap<String, Object>> getGroupDefineByNameAndId(
			String groupName, String id) {
		String sql = "SELECT * FROM "+getTableName()+" tb WHERE tb.groupName = '"+groupName+"' AND tb.id != '"+id+"'";
		return super.getListBySql(sql);
	}
}
