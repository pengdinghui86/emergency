package com.esc.oms.outsource.monitor.dao;

import java.util.List;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

/**
 * 服务监控评估配置模板
 * @author owner
 *
 */
public interface IMonitorEvaluateConfigurationDao extends IBaseOptionDao{
	public static final String  FIELD_ID= "id";
	
	/**
	 * 根据当前时间查询服务监控模板配置数据，用来生成评估数据
	 * @return
	 */
	public List<UTMap<String, Object>> getListAllByMonitorPeriod();
}
