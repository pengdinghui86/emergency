package com.esc.oms.outsource.outperson.dao;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;

import java.util.List;
import java.util.Map;

/**
 * 外包人员列表
 * @author smq
 * @date   2016-2-24 上午10:39:04
 */
public interface IOutSourcePersonDao extends IBaseOptionDao {
	public static final String  FIELD_ID = "id";
	public static final String  FIELD_CODE= "code";
	public static final String  FIELD_NAME = "name";
	public static final String  FIELD_STATE = "state";
	public static final String  FIELD_USERID = "userId";
	public static final String  FIELD_SUPPLIERID = "supplierId";
	public static final String  FIELD_ISHUMANRES = "isHumanRes";//是否人力外包
	public static final String  FIELD_AGREEMENTID = "agreementId";//合同Id
	public static final String  FIELD_CATEGORY= "category";//人员类型
	public static final String  FIELD_LEVEL = "level";//等级
	public static final String  FIELD_CHANGEBEGINDATE = "changeBeginDate";//计费开始时间
	public static final String  FIELD_CHANGEENDDATE = "changeEndDate";//计费开始时间
	public static final String  FIELD_ISKEYPERSON = "isKeyPerson";//是否关键负责人
	public static final String  FIELD_ISASSESS = "isAssess";//是否考核
	public static final String  FIELD_ISACCESS = "isAccess";//是否发放门禁
	public static final String  FIELD_DEPARTID = "departId";//所属部门
	public static final String  FIELD_MAINPROJECTID = "mainProjectId";//所属主项目
	public static final String  FIELD_MONTHLYFEE = "monthlyFee";//所属主项目
	
	

	/**
	 * 通过
	 * @param userId
	 * @return
	 */
	public UTMap<String, Object> getOutEmpByUserId(String userId);

	/**
	 * 获取所有钉钉ID
	 * @return
	 */
	public List<UTMap<String, Object>> getAllDingDingId();

	/**
	 * 根据Id 来修改钉钉ID
	 * @return
	 */
	public boolean changeOutPersonById(List<Map<String, Object>> paramList)throws Exception;

	/**
	 * 删除所有的钉钉Id解绑
	 * @param dingDingId
	 * @return
	 */
	public boolean deleteDingDingId(String dingDingIds);


}
