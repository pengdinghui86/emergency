package com.esc.oms.asset.overview.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.asset.overview.dao.IAssetsOverviewDao;
import com.esc.oms.asset.overview.service.IAssetsOverviewService;

@Service
@Transactional
public class AssetsOverviewServiceImpl implements IAssetsOverviewService{

	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private IAssetsOverviewDao dao;
	
	@Resource
	private ISysParamService sysParamService;
	
	@Resource
	private ISysUserService userService;

	@Override
	public List<UTMap<String, Object>> getAssetsList(Map params) {
		return dao.getAssetsList(params);
	}

	@Override
	public void getAssetsPageList(UTPageBean pageBean,Map<String, Object> params) {
		dao.getAssetsPageList(pageBean, params);
	}

	@Override
	public List<UTMap<String, Object>> getWarnAgreementList(Map params) {
		return dao.getWarnAgreementList(params);
	}

	@Override
	public void getWarnAgreementPageList(UTPageBean pageBean,Map<String, Object> params) {
		dao.getWarnAgreementPageList(pageBean, params);
		//转换合同负责人
//		List list = pageBean.getRows();		
//		if(list!=null&&list.size()>0){
//			List<UTMap<String, Object>> users = userService.getUsersByUserType("1");
//			for(int i=0;i<list.size();i++){
//				UTMap<String,Object> map = (UTMap<String, Object>) list.get(i);
//				String aleaders = (String) map.get("aleaders");
//				String aleaderNames = CommonUtils.getUserNameAndCodesByIds(users, aleaders);
//				map.put("aleaderNames", aleaderNames);
//			}
//			pageBean.setRows(list);
//		}
	}

	@Override
	public Map<String,Object> getOverviewReportCategoy(
			Map<String, Object> params) {
		List<UTMap<String, Object>> list = dao.getOverviewReportCategoy(params);
		String[] titleData = new String[list.size()];
		int[] data = new int[list.size()];
		Map<String,Object> resultMap = new HashMap<String,Object>();
		for(int i=0;i<list.size();i++){
			UTMap<String, Object> map = list.get(i);					
			String categoryName = (String) map.get("categoryName");
			titleData[i]=categoryName;
			int num = map.get("num")==null?0:Integer.parseInt(String.valueOf(map.get("num")));
			data[i]=num;
		}
		resultMap.put("titleData", titleData);
		resultMap.put("data", data);
		return resultMap;
	}
	
	@Override
	public Map<String,Object> getOverviewReportMonth(
			Map<String, Object> params) {
		List<UTMap<String, Object>> list = dao.getOverviewReportMonth(params);
		String[] titleData = new String[list.size()];
		int[] data = new int[list.size()];
		Map<String,Object> resultMap = new HashMap<String,Object>();
		for(int i=0;i<list.size();i++){
			UTMap<String, Object> map = list.get(i);					
			String categoryName = (String) map.get("month");
			titleData[i]=categoryName;
			int num = map.get("num")==null?0:Integer.parseInt(String.valueOf(map.get("num")));
			data[i]=num;
		}
		resultMap.put("titleData", titleData);
		resultMap.put("data", data);
		return resultMap;
	}
	
}