package com.esc.oms.outsource.outperson.dao;


import java.util.List;
import java.util.Map;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;


public interface IApplyQuitDao extends IBaseOptionDao{

	public static final String  FIELD_ID = "id";
	public static final String  FIELD_QUITUSERID = "quitUserId";
	public static final String  FIELD_QUITUSERNAME= "quitUserName";
	public static final String  FIELD_SUPPLIERID= "supplierId";
	public static final String  FIELD_PROCESSID = "processId";
	public static final String  FIELD_PROCESSSTEP = "processStep"; 
	public static final String  FIELD_QUITDATE = "quitDate";
	public static final String  FIELD_ISNOTICE = "isNotice";
	public static final String  FIELD_STATUS = "status";
	public static final String  FIELD_ISCONFIRM = "isConfirm";
	public static final String  FIELD_CREATEUSERID = "createUserId";

	public static final String  FIELD_CONFIMUSERID = "confimUserId";
	public static final String  FIELD_CONFIMDATE = "confimDate";
	public static final String  FIELD_CONFIMUSERNAME = "confimUserName";


	public List<UTMap<String, Object>> searchInfo(Map<String, Object> params) ;
	
	public void searchInfoPage(UTPageBean pageBean,Map<String, Object> params) ;
	
	public void getPendApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) ;

	public void getAlreadyApprovalPageInfo(UTPageBean pageBean,Map<String, Object> params) ;

	public List<UTMap<String, Object>> getUserBaseInfo(Map<String, Object> param);
}
