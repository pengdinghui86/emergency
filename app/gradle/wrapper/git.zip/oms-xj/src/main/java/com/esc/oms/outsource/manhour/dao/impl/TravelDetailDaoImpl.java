package com.esc.oms.outsource.manhour.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.manhour.dao.ITravelDetailDao;
import com.esc.oms.util.RoleUtils;

@Repository
public class TravelDetailDaoImpl extends BaseOptionDao implements ITravelDetailDao {
	@Override
	public String getTableName() {
		return "workhour_travel_detail";
	}
	
	public void deleteByInfoId(String infoId) {
		Map params = new HashMap();
		params.put("infoId", infoId);
		super.deleteBySql(getTableName(), params );
	}


	@Override
	public List<UTMap<String, Object>> getTravelDetailList(Map param) {
		String sql = getSearchSqlString(param);
		List<UTMap<String, Object>> dataList = this.getListBySql(sql);
		return dataList;
	}

	@Override
	public void getTravelDetailPage(UTPageBean pageBean, Map param) {
		String sql = getSearchSqlString(param);
		this.getPageListMapBySql(sql , pageBean);
	}
	
	private String getSearchSqlString(Map param) {
		StringBuilder sql = new StringBuilder();
		sql.append(" select s.supplierName, s.orgName, s.code, s.status, s.createUser,s.place,d.hours,d.presentDate,d.coalitionId, DATE_FORMAT(d.beginTime, '%Y-%m-%d %H:%i') beginTime,DATE_FORMAT(d.endTime, '%Y-%m-%d %H:%i') endTime ");
		sql.append(" from workhour_travel s, workhour_travel_detail d ");
		sql.append(" WHERE s.id = d.infoId and d.hours > 0 ");
		if(param != null) {
			String id = (String) param.get("id");
			String beginTime = (String) param.get("beginTime");
			String endTime = (String) param.get("endTime");
			String supplierId = (String) param.get("supplierId");
			String supplierName = (String) param.get("supplierName");
			String orgId = (String) param.get("orgId");
			String orgName = (String) param.get("orgName");
			String status = (String) param.get("status");
			String queryStatus = (String) param.get("queryStatus");
			String createUser = (String) param.get("createUser");
			String createUserId = (String) param.get("createUserId");
			String coalitionId = (String) param.get("coalitionId");
			if(StringUtils.isNotEmpty(id)) {
				sql.append(" and s.id = '").append(id).append("' ");
			}
			if(StringUtils.isNotEmpty(status)) {
				sql.append(" and find_in_set(s.status, '").append(status).append("') ");
			}
			if(StringUtils.isNotEmpty(queryStatus)) {
				sql.append(" and find_in_set(s.status, '").append(queryStatus).append("') ");
			}
			if(StringUtils.isNotEmpty(beginTime)) {
				sql.append(" and d.presentDate >= '").append(beginTime).append("' ");
			}
			if(StringUtils.isNotEmpty(endTime)) {
				sql.append(" and d.presentDate <= '").append(endTime).append("' "); // 查询的结束时间
			}
			if(StringUtils.isNotEmpty(orgId)) {
				sql.append(" and s.orgId = '").append(orgId).append("' ");
			}
			if(StringUtils.isNotEmpty(orgName)) {
				sql.append(" and s.orgName = '").append(orgName).append("' ");
			}
			if(StringUtils.isNotEmpty(supplierId)) {
				sql.append(" and s.supplierId = '").append(supplierId).append("' ");
			}
			if(StringUtils.isNotEmpty(supplierName)) {
				sql.append(" and s.supplierName like '%").append(supplierName).append("%' ");
			}
			if(StringUtils.isNotEmpty(createUser)) {
				sql.append(" and s.createUser like '%").append(createUser).append("%' ");
			}
			if(StringUtils.isNotEmpty(createUserId)) {
				sql.append(" and s.createUserId = '").append(createUserId).append("' ");
			}
			if(StringUtils.isNotEmpty(coalitionId)) {
				sql.append(" and d.coalitionId = '").append(coalitionId).append("' ");
			}
		}
		// 权限过滤：供应商负责人看自己所属供应商的、外包管理员看所有的
		// 数据权限过滤 lba
		if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.OUTSOURCE_MANAGER, RoleUtils.SYSTEM_ADMINISTRATOR)) {//外包管理员
			// 只能看自己所属供应商的
			sql.append(" and s.supplierId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId()+"' ");
		}
		sql.append(" order by d.presentDate desc, createUser desc ");
		return sql.toString();
	}

}
