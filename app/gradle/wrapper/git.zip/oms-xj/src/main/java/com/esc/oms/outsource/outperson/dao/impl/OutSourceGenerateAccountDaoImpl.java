package com.esc.oms.outsource.outperson.dao.impl;

import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.outperson.dao.IOutSourceGenerateAccountDao;

@Repository
public class OutSourceGenerateAccountDaoImpl implements IOutSourceGenerateAccountDao {
	private final static String TABLE_NAME = "outsourc_apply_enter_info";
}
