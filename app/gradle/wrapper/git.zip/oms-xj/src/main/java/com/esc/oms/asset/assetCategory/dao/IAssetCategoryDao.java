package com.esc.oms.asset.assetCategory.dao;

import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;

import java.util.List;
import java.util.Map;

public interface IAssetCategoryDao extends IBaseOptionDao {

  public List<UTMap<String, Object>> getdicts();
  
  public List<UTMap<String, Object>> getdictByDictType(String type);
  
  public List<UTMap<String, Object>> getdictByDictName(String name);

  /**
   * 获取所有的值
   * @return
   */
  public void getAttrAll(Map<String, Object> params, UTPageBean pageBean);

  /**
   * 获取所有的属性值
   * @param categoryId
   * @return
   */
  public List<UTMap<String, Object>> getAttrAllMap(String categoryId);
  /**
   * 保存属性值
   * @param list
   * @return
   */
  public boolean saveAttrValueList(List<UTMap<String, Object>> list);

  /**
   * 根据资产id获取额外属性
   * @param infoId
   * @return
   */
  public List<UTMap<String, Object>> getAttrValue(String infoId);
  
  /**
   * 根据资产分类名称获取资产分类id
   * @param name
   * @return
   */
  public String getAssetCategoryIdByName(String name);

  /**
   * 根据大小类名称获取数据
   * @param parentName
   * @param name
   * @return
   */
  public String getAssetCategoryIdByNames(String parentName, String name);

  /**
   * 判断是否在资产表的column
   * @return
   */
  public boolean isAssetInfoColumn(String ID);

  /**
   * 根据条件获取额外属性的值
   * @param params
   * @return
   */
  public List<UTMap<String, Object>> getAttrList(Map<String, Object> params);
}
