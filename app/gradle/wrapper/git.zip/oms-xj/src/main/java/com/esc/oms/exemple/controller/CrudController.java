package com.esc.oms.exemple.controller;

import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.exemple.service.ICrudService;
import com.esc.oms.util.CommonUtils;

/**
 * 开发模板
 * @author owner
 *
 */
@Controller
@RequestMapping("crud")
public class CrudController extends BaseOptionController {

	@Resource
	private ICrudService crudService;
	
	@Override
	public IBaseOptionService optionService() {
		return crudService;
	}
	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			crudService.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }

}
