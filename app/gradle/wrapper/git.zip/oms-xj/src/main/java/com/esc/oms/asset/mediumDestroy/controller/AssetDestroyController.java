package com.esc.oms.asset.mediumDestroy.controller;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.lang3.StringUtils;
import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.esc.framework.workflow.service.IWorkflowEngine;
import org.esc.framework.workflow.utils.bpmn.Instance;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.asset.mediumDestroy.dao.IAssetDestroyDao;
import com.esc.oms.asset.mediumDestroy.service.IAssetDestroyService;
import com.esc.oms.util.CommonUtils;

@Controller
@RequestMapping("assetDestroy")
public class AssetDestroyController extends BaseOptionController {


	@Resource
	private IAssetDestroyService assetDestroyService;

	@Resource
	private ISysParamService sysParamService;
	
	@Resource
	private IWorkflowEngine workflowEngine;
	
	@Override
	public IBaseOptionService optionService() {
		return assetDestroyService;
	}
	
	/**
	 * 分页查询
	 * @param params
	 * @param pageBean
	 * @return
	 */
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			assetDestroyService.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	
	/**
	 * 获取带审批列表
	 * */
	@RequestMapping("getPendApprovalPageInfo")
	@ResponseBody
	public UTPageBean getPendApprovalPageInfo(@RequestParam Map<String, Object> params) {
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		assetDestroyService.getPendApprovalPageInfo(pageBean, params);
		return pageBean;
	}
	
	/**
	 * 获取已审批列表
	 * */
	@RequestMapping("getAlreadyApprovalPageInfo")
	@ResponseBody
	public UTPageBean getAlreadyApprovalPageInfo(@RequestParam Map<String, Object> params) {
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		assetDestroyService.getAlreadyApprovalPageInfo(pageBean, params);
		return pageBean;
	}
	
    @RequestMapping(value="/saveOrUpdate",method=RequestMethod.POST)  
    @ResponseBody
    public Map<String, Object> saveorupdate(@RequestBody Map map) throws Exception{  
    	Map <String,Object> item=new HashMap<String, Object>();
		item.put("success", true);
		item.put("msg", "操作成功");
    	try{
    		boolean flag=true;
    			if(map.get("id") == null){
    				flag = assetDestroyService.add(map);
    			}else{
    				flag = assetDestroyService.updateById(map);
    			}
    			item.put("id",map.get("id"));
    	}catch(Exception e){
    		logger.error("Exception", e);
    		item.put("success", false);
    		item.put("msg", "操作失败");
    		return item;
    	}
       return item;
    }
    
    /**
	 * 提交审批
	 * @param map
	 * @return
	 */
	@RequestMapping(value="submit", method=RequestMethod.POST)  
    @ResponseBody
    public String submit(@RequestBody Map<String,Object> map) {
		try {
			assetDestroyService.submit(map);
			return UTJsonUtils.getJsonMsg(true, "操作成功");
		}
		catch (Exception e) {
			logger.error("Exception",e);
			return UTJsonUtils.getJsonMsg(false, "操作失败");
		}
	}
    
    /**
	 * 根据id查询
	 * @param param
	 * @return
	 */
	@RequestMapping(value="getById")
	@ResponseBody
	public UTMap<String, Object> defgetById(@RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = null;
    	try{
    		String id = (String) param.get("id");
    		if (null == id || StringUtils.isEmpty(id)) {
    			return null;
    		}
    		map = optionService().getById(param.get("id").toString());
    	
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return map;
	}

	/**
	 * 打印预览
	 */
	@RequestMapping(value="printById")
	@ResponseBody
	public Map<String, Object> printById(@RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = new UTMap<String, Object>();
		UTMap<String, Object> result = new UTMap<String, Object>();
		List<UTMap<String, Object>> mapList = new ArrayList<UTMap<String, Object>>();
    	try{
    		if(null != param.get("id")){
    			map = optionService().getById((String)param.get("id"));
    			if(map!=null && map.size()>0) {
    				mapList.add(map);
    				//替换下拉的值
    				Map<String, String> fieldAndParamType = new HashMap<String, String>();
    				fieldAndParamType.put(IAssetDestroyDao.FIELD_MEDIUMTYPE, "mediumType");
    				fieldAndParamType.put(IAssetDestroyDao.FIELD_STATUS, "assetDestroyStatus");
    				fieldAndParamType.put(IAssetDestroyDao.FIELD_CLASSIFICATION, "classificationType");
    				fieldAndParamType.put(IAssetDestroyDao.FIELD_DESTROY_MODE, "destroyModeType");
    				sysParamService.changeParamData(mapList, fieldAndParamType);
    				map = mapList.get(0);
    			}
    			String id = param.get("id").toString();
    			String workflowCode = "physical_asset_destory";
    	        //流程审批信息
    	        Instance instance = workflowEngine.getInstance(workflowCode, id);
    	        List<UTMap<String, Object>> maps = new ArrayList<>();
    	        if (instance != null) {
    	            instance.setAuditInfoList(workflowEngine.getShowAuditInfoList(instance.getInstanceId()));
    	            maps = workflowEngine.getShowAuditInfoList(instance.getInstanceId());   	       
    	        }
    	        result.put("destroyInfo", map);
     	        result.put("workFlow", maps);
     	        result.put("success", true);
     	        result.put("msg", "操作成功！");
    		}
    		else {
    			result.put("success", false);
			}
 			return result;
		}catch(Exception e){
			logger.error("Exception", e);
			result.put("msg", "查询失败！");
			result.put("success", false);
			return result;
    	}
	}
	
	@RequestMapping(value = "leadingout")
	public void leadingout(@RequestParam Map<String, Object> map1,
			HttpServletRequest request,
			HttpServletResponse response) {
		
		Map<String, Object> param = CommonUtils.clone(map1);
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = null;
			if(info != null) {
				jsonBean = JSONObject.fromObject(info);
			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = assetDestroyService.getAssetsList(jsonBean);
			} else {
			// 根据条件 导出当前
			//if (UTExcel.EXCELOUTTYPE_NOW == outType) {
				// getpage
				assetDestroyService.getPageInfo(utPageBean, jsonBean);
				data = utPageBean.getRows();
			}
			if(data!=null && data.size()>0) {
				//替换下拉的值
				Map<String, String> fieldAndParamType = new HashMap<String, String>();
				fieldAndParamType.put(IAssetDestroyDao.FIELD_MEDIUMTYPE, "mediumType");
				fieldAndParamType.put(IAssetDestroyDao.FIELD_STATUS, "assetDestroyStatus");
				fieldAndParamType.put(IAssetDestroyDao.FIELD_CLASSIFICATION, "classificationType");
				fieldAndParamType.put(IAssetDestroyDao.FIELD_DESTROY_MODE, "destroyModeType");
				sysParamService.changeParamData(data, fieldAndParamType);
			}
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			assetDestroyService.leadingout(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	/**
	 * 介质销毁查询所属介质序列号资产列表
	 * @return py
	 */
	@RequestMapping("getAssetList")
	@ResponseBody
	public List<UTMap<String, Object>> getAssetList(){
		return assetDestroyService.getAssetsList();
	}
   
}