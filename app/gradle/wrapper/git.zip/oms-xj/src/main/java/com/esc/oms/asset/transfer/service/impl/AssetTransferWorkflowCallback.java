package com.esc.oms.asset.transfer.service.impl;


import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.message.send.MessageSend;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.workflow.service.IWorkflowCallback;
import org.esc.framework.workflow.service.IWorkflowCode;
import org.springframework.stereotype.Service;

import com.esc.oms.asset.transfer.dao.IAssetTransferDao;
import com.esc.oms.asset.transfer.service.IAssetTransferService;
import com.esc.oms.util.ParamUtils;
import com.esc.oms.util.TaskModel;

@Service
public class AssetTransferWorkflowCallback implements IWorkflowCallback {
	
	@Resource
	private IAssetTransferService assetTransferService;
	@Resource
	private IAssetTransferDao assetTransferDao;
	@Resource
	private MessageSend messageSend;
	
	@Resource
	private IUserTaskService userTaskService;
	
	
	
	/**
	 * 返回流程编码
	 * @return
	 */
	public String workflowCode() {
		return IWorkflowCode.PHYSICAL_ASSET_TRANSFER;
	}
	
	/**
	 * 回调方法。
	 * 流程完成时，业务上需要进行的相应操作。
	 * @param businessRecordId
	 */
	public void onFinish(String businessRecordId) {
		assetTransferService.finishAudit(businessRecordId);
	}

//	public void onFinish(String businessRecordId,String isnull) {
//		assetTransferService.finishAudit(businessRecordId,isnull);
//	}


	/**
	 * 发送任务
	 * */
	public void sendTask(String workflowName,String businessRecordId,String nodeName,String userId){
	
		String name=assetTransferDao.getTittle(businessRecordId);
		userTaskService.addTaskByUserId("资产清单【"+name+"】的转移申请待您审批", businessRecordId, nodeName, TaskModel.PhysicalAssetTransfer, userId);
	}

	@Override
	public void optionNode(String workflowCode, String businessRecordId,	String nodeName, String linkName) {
		
		assetTransferService.optionNode(workflowCode, businessRecordId, nodeName, linkName);
	}
	/**
	 * 回调方法。
	 * 流程回到开始节点时，业务上需要进行的相应操作。
	 * @param businessRecordId
	 */
	public void onReject(String businessRecordId) {
		Map<String, Object> info=	assetTransferDao.getById(businessRecordId, "createUserId");
		if(info==null||info.get("createUserId")==null){
			return;
		}
		String name=assetTransferDao.getTittle(businessRecordId);
		assetTransferService.rejectAudit(businessRecordId);
		messageSend.sendMessage(info.get("createUserId").toString(), 
				"资产清单【"+name+"】的转移申请驳回提醒", 
				"资产清单【"+name+"】的转移申请已被驳回，请知悉！详情请进入系统查看", MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
	}
	
	@Override
	public void onTerminate(String businessRecordId) {
		//System.out.println("执行非正常流程结束的回调方法");
		Map<String, Object> info=	assetTransferDao.getById(businessRecordId, "createUserId");
		if(info==null||info.get("createUserId")==null){
			return;
		}
		String name=assetTransferDao.getTittle(businessRecordId);
		assetTransferService.terminate(businessRecordId);
		messageSend.sendMessage(info.get("createUserId").toString(), 
				"资产清单【"+name+"】的转移申请终止提醒", 
				"资产清单【"+name+"】的转移申请已被终止，请知悉！详情请进入系统查看", MessageSend.Type.MAIL,MessageSend.Type.SYSTEM);
	
	}

}
