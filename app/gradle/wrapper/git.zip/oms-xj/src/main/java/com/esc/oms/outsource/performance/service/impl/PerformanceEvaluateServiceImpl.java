package com.esc.oms.outsource.performance.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.security.service.ISysUserService;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.upload.annotation.UploadAddMark;
import org.esc.framework.upload.annotation.UploadQueryMark;
import org.esc.framework.upload.annotation.UploadQueryMarks;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.performance.dao.IPerformanceEvaluateConfigurationDao;
import com.esc.oms.outsource.performance.dao.IPerformanceEvaluateDao;
import com.esc.oms.outsource.performance.dao.IPerformanceEvaluateTemplateDao;
import com.esc.oms.outsource.performance.dao.IPerformanceEvaluateUserDao;
import com.esc.oms.outsource.performance.service.IPerformanceEvaluateService;
import com.esc.oms.supplier.supplieremp.service.ISupplierEmpService;
import com.esc.oms.system.templateconfiguration.dao.ITemplateConfigurationDetailDao;
import com.esc.oms.system.templateconfiguration.dao.ITemplateConfigurationDetailDeputyResultDao;
import com.esc.oms.system.templateconfiguration.service.ITemplateConfigurationDetailDeputyService;

/**
 * 外包绩效考核
 * @author owner
 *
 */
@Service
@Transactional
public class PerformanceEvaluateServiceImpl extends BaseOptionService implements IPerformanceEvaluateService{
	
	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private IPerformanceEvaluateDao dao;
	
	//外包绩效考核-被考核对象
	@Resource
	private IPerformanceEvaluateUserDao performanceEvaluateUserDao;
	
	@Resource
	private IPerformanceEvaluateTemplateDao performanceEvaluateTemplateDao;
	
	//模板配置详情dao
	@Resource
	private ITemplateConfigurationDetailDao detailDao;
	
	//外包绩效考核配置Dao
	@Resource
	private IPerformanceEvaluateConfigurationDao performanceEvaluateConfigurationDao;
	
	//模板配置从属数据操作Service接口
	@Resource
	private ITemplateConfigurationDetailDeputyService templateConfigurationDetailDeputyService;
	
	//模板配置从属数据结果操作dao接口
	@Resource
	private ITemplateConfigurationDetailDeputyResultDao templateConfigurationDetailDeputyResultDao;
	
	//用户
	@Resource
	private ISysUserService sysUserService;

	//代办任务
	@Resource
	private IUserTaskService userTaskService;
	
	@Resource
	private ISupplierEmpService supplierEmpService;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return dao;
	}

	/**
	 * 添加
	 * @param info
	 * @return
	 */
//	@UploadAddMark//aop拦截绑定上传文件的数据关系
	public boolean add(Map info){
		super.add(info);
		return true;
	}
	
	/**
	 * 根据ID 获取
	 * @param info
	 * @return
	 */
	@UploadQueryMark//aop拦截绑定上传文件的数据关系
	public UTMap<String, Object> getById(String id){
		UTMap<String, Object> result = super.getById(id);
		String performanceEvaluateTemplateId = result.get("performanceEvaluateTemplateId")+"";//外包绩效考核配置模板id
		String evaluator = result.get("evaluator")+"";//评估人
		Map params = new HashMap();
		params.put("performanceEvaluateId", id);
		params.put("type", 2);//评估数据类型。1：结果评估，2：过程评估
		params.put("isProcessUserList", true);
		result.put("userList", performanceEvaluateUserDao.getListAll(params));
//		result.put("treeData", templateConfigurationDetailDeputyService.getDetailsDeputy(performanceEvaluateTemplateId, evaluator));
		return result;
	}
	
	/**
	 * 修改
	 * @param info
	 * @return
	 */
	@UploadAddMark//aop拦截绑定上传文件的数据关系
//	@EscOptionLog(module = SystemModule.performanceEvaluate, opType = ESCLogOpType.UPDATE, table = "outsourc_performance_evaluate", option = "更新外包绩效考核配置编号为{performanceEvaluateConfigId}的绩效考核评估。")
	public boolean updateById(Map info){
		String id = info.get("id")+"";//外包绩效考核配置模板id
		Map existMap = new HashMap();
		existMap.put("id", id);
		if(!dao.isExist(existMap)){
			throw new EscServiceException("当前数据已经不存在，请刷新页面重新操作！");
		}
		info.put("evaluateTime", UTDate.getCurDateTime());//评估时间
		info.put("submitTime", UTDate.getCurDateTime());//提交时间
		info.put("status", 1);//评估状态
		info.put("submitter", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());//提交人
		List<Map> list= (List<Map>)info.get("treeData");
		String moduleTemplateConfigurationId = info.get("performanceEvaluateTemplateId")+"";
		String evaluator = info.get("evaluator")+"";
		//编辑或添加模板数据
		templateConfigurationDetailDeputyService.addTemplateConfigurationDetailDeputyResult(moduleTemplateConfigurationId, evaluator, list);		
		
		List<Map> performanceEvaluatorList = (List<Map>)info.get("userList");//被考核对象列表
		if(performanceEvaluatorList != null){
			//遍历修改被考核对象的考核结果
			for (Map performanceEvaluator : performanceEvaluatorList) {
				performanceEvaluator.put("evaluateTime", UTDate.getCurDateTime());//评估时间
				performanceEvaluator.put("submitTime", UTDate.getCurDateTime());//提交时间
				performanceEvaluator.put("status", 1);//评估状态
				performanceEvaluator.put("submitter", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());//提交人
				performanceEvaluator.put("evaluator", EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId());//提交人
				performanceEvaluateUserDao.updateById(performanceEvaluator);
			}
		}
		userTaskService.finishTask(id);//完成代办任务
		return super.updateById(info);
	}
	
	
//	private void setTemplateConfigurationDetailDeputyResult(String moduleTemplateConfigurationId, String evaluator, List<Map> list, List<Map> resultList){
//		if(list == null){
//			return;
//		}
//		for (Map item : list) {
//			Map info = new HashMap();
//			if(item.get("result") != null){
//				String result = item.get("result").toString();
//				info.put("moduleTemplateConfigurationId", moduleTemplateConfigurationId);
//				String templateConfigurationDetailDeputyId = item.get("id").toString();
//				info.put("evaluator", evaluator);
//				info.put("templateConfigurationDetailDeputyId", templateConfigurationDetailDeputyId);
//				info.put("result", result);
//				resultList.add(info);
//			}
//			
//			String type = item.get("type").toString();//类型，1：填空，2：单选，3：多选，0：是配置项
//			if(("2".equals(type) || "3".equals(type)) && item.get("options") != null){//如果是单选或者多选，保存子配置项
//				List<Map> options = (List<Map>)item.get("options");
//				setTemplateConfigurationDetailDeputyResult(moduleTemplateConfigurationId,evaluator,options,resultList);
//			}
//			if(item.get("children") != null){//如果存在子节点数据
//				List<Map> children = (List<Map>)item.get("children");
//				setTemplateConfigurationDetailDeputyResult(moduleTemplateConfigurationId,evaluator,children,resultList);
//			}
//		}
//	}
	
	@Override
	public boolean deleteById(String id) {
		detailDao.deleteByTemplateConfigurationId(id);
		return super.deleteById(id);
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map param) {
		dao.getPageInfo(pageBean, param);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	@UploadQueryMarks
	public List<UTMap<String, Object>> getListAll(Map params){
		return dao.getListAll(params);
	}

}
