package com.esc.oms.outsource.outperson.service.impl;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.dict.dao.ISysParamDao;
import org.esc.framework.persistence.dao.IBaseOptionDao;
import org.esc.framework.service.BaseOptionService;
import org.esc.framework.task.service.IUserTaskService;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTMap;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esc.oms.outsource.outperson.dao.IOutSourcePersonConfigDao;
import com.esc.oms.outsource.outperson.service.IOutSourcePersonConfigService;

@Service
@Transactional
public class OutSourcePersonConfigServiceImpl extends BaseOptionService implements IOutSourcePersonConfigService{
	@Resource
	private IOutSourcePersonConfigDao personConfigDao;
	@Resource
	private ISysParamDao paramDao;
	@Resource
	private IUserTaskService userTaskService;
	
	@Override
	public IBaseOptionDao getOptionDao() {
		return personConfigDao;
	}

	
	//创建用户 权限配置项
	public void createConfigByUserId(String userId){
		List<Map> list=new ArrayList<Map>();
		Map<String, Object> p=new HashMap<String, Object>();
		p.put("paramType","outsourcePersonConfig");
		List<UTMap<String, Object>> configs=paramDao.getListMaps(p);
		for (UTMap<String, Object> item : configs) {
			Integer v= Integer.valueOf(item.get("value").toString());
			String itemName=item.get("name").toString();
			String remark=item.get("remark")!=null?item.get("remark").toString():"";
			Integer itemType= v<4?1:2;//1 固定项，2非固定项
			Integer isConfig= v<3?1:0;
			Map<String, Object> info=new HashMap<String, Object>();
			info.put(IOutSourcePersonConfigDao.FIELD_USERID, userId);
			info.put(IOutSourcePersonConfigDao.FIELD_ITEMTYPE, itemType);
			info.put(IOutSourcePersonConfigDao.FIELD_ITEMNAME, itemName);
			info.put(IOutSourcePersonConfigDao.FIELD_ISCONFIG, isConfig);//默认为没有配置
			info.put(IOutSourcePersonConfigDao.FIELD_REMARK, remark);//默认为没有配置
			info.put("paramValue",v);
			if(v<3){
				info.put(IOutSourcePersonConfigDao.FIELD_OPENDATE, UTDate.getCurDate());
			}
			list.add(info);
		}
		personConfigDao.adds(list);
	}
	
	//创建用户 权限配置项(默认配置 2,3 固定配置项)
	public void createConfigByUserId2(String userId){
		List<Map> list=new ArrayList<Map>();
		Map<String, Object> p=new HashMap<String, Object>();
		p.put("paramType","outsourcePersonConfig");
		List<UTMap<String, Object>> configs=paramDao.getListMaps( p);
		for (UTMap<String, Object> item : configs) {
			Integer v= Integer.valueOf(item.get("value").toString());
			String itemName=item.get("name").toString();
			String remark=item.get("remark")!=null?item.get("remark").toString():"";
			Integer itemType= v<4?1:2;//1 固定项，2非固定项
			Integer isConfig= v<4&&v>1?1:0;
			Map<String, Object> info=new HashMap<String, Object>();
			info.put(IOutSourcePersonConfigDao.FIELD_USERID, userId);
			info.put(IOutSourcePersonConfigDao.FIELD_ITEMTYPE, itemType);
			info.put(IOutSourcePersonConfigDao.FIELD_ITEMNAME, itemName);
			info.put(IOutSourcePersonConfigDao.FIELD_ISCONFIG, isConfig);//默认为没有配置
			info.put(IOutSourcePersonConfigDao.FIELD_REMARK, remark);//默认为没有配置
			info.put("paramValue",v);
			if(v<4&&v>1){
				info.put(IOutSourcePersonConfigDao.FIELD_OPENDATE, UTDate.getCurDate());
			}
			list.add(info);
		}
		personConfigDao.adds(list);
	}
	
	//针对用户 id 和 外包人员Id 创建人员 权限配置 
	/**
	 * 返回 true 表示需要添加考勤规则 返回false 不添加
	 * */
	public boolean saveConfigByUserId(List<Map<String, Object>> configsInfo){
		boolean flog=false;
		for (Map<String, Object> item : configsInfo) {
			String isConfig=item.get("isConfig").toString();
			String paramValue=item.get("paramValue").toString();
			
			if(StringUtils.isEmpty(isConfig)||StringUtils.equals(isConfig,"false")){
				item.put("isConfig",0);
			}
			else if(StringUtils.equals(isConfig,"true")){
				item.put("isConfig",1);
			}
			else{
				item.put("isConfig",isConfig);
			}
			 
			String f=item.get("isConfig").toString();
			
			//判断是否生成考勤规则
			if(StringUtils.equals("1",paramValue)&&StringUtils.equals("1", f)){
				flog=true;
			}
			
		//	flog=personConfigDao.updateById(item);
			if(!personConfigDao.updateById(item)){
				return false; //终止
			}
		}
		return flog;
	}
	
	public boolean saveConfigByUserId2(List<Map<String, Object>> configsInfo){
		boolean flog=true;
		for (Map<String, Object> item : configsInfo) {
			String isConfig=item.get("isConfig").toString();
			String paramValue=item.get("paramValue").toString();
			
			if(StringUtils.isEmpty(isConfig)||StringUtils.equals(isConfig,"false")){
				item.put("isConfig",0);
			}
			else if(StringUtils.equals(isConfig,"true")){
				item.put("isConfig",1);
			}
			else{
				item.put("isConfig",isConfig);
			}
			 
		//	flog=personConfigDao.updateById(item);
			if(item.containsKey("id")){
				if( !personConfigDao.updateById(item)){
					return false; //终止
				}
			}else{
				if( !personConfigDao.add(item)){
					return false; //终止
				}
			}
		
		}
		return flog;
	}
	
	// 注销 
	//针对用户 id 和 外包人员Id 创建人员 注销配置手动
	public boolean cancelConfigByUserId(List<Map<String, Object>> configsInfo){
		boolean flog=true;
		for (Map<String, Object> item : configsInfo) {
			//item.put("isConcel", 1);
			Object isconfig=item.get("isConcel");
			Object isConfig2=item.get("isConfig");
			if(isconfig!=null&&StringUtils.equals("true", isconfig.toString())){
				item.put("isConcel",1);
			}
			if(isconfig!=null&&StringUtils.equals("false", isconfig.toString())){
				item.put("isConcel",0);
			}
			
			if(isConfig2!=null&&StringUtils.equals("false", isConfig2.toString())){
				item.put("isConfig",0);
			}
			if(isConfig2!=null&&StringUtils.equals("true", isConfig2.toString())){
				item.put("isConfig",1);
			}
			item.put("cancelDate",item.containsKey("cancelDate")?item.get("cancelDate"):UTDate.getCurDate());
			flog=personConfigDao.updateById(item);
			if(!flog){
				return false;
			}
		}
		return true;
	}

	//针对用户 id 和 外包人员Id 创建人员 注销配置自动注销	注销固定项
	public void cancelConfigByUserId(String userId){
		Map<String, Object> p=new HashMap<String, Object>();
		p.put("paramType","outsourcePersonConfig");
		List<UTMap<String, Object>> configs=paramDao.getListMaps( p);
		for (UTMap<String, Object> item : configs) {
			Integer v= Integer.valueOf(item.get("value").toString());
			String name= item.get("name").toString();
			if(v<4){
				Map<String, Object> info=new HashMap<String, Object>();
				info.put("userId", userId);
				info.put("itemName", name);
//				if(isconfig!=null&&StringUtils.equals("TRUE", isconfig.toString())){
//					info.put("isConfig",1);
//				}
				info.put("isConcel", 1);
				info.put("cancelDate",item.containsKey("cancelDate")?item.get("cancelDate") == null ? UTDate.getCurDate(): item.get("cancelDate") :UTDate.getCurDate());
				//info.put("isConfig", 0);
				personConfigDao.updateBy(info, "userId","itemName");
			}
		}
	}

	@Override
	public 	List<UTMap<String, Object>> getPersonConfig(String userId) {
		Map<String, Object> param=new HashMap<String, Object>();
		param.put("userId", userId);
		List<UTMap<String, Object>> userConfigs=personConfigDao.getListMaps(param);

		UTMap [] configArray=new UTMap[userConfigs.size()];
		List<String> vlist=new ArrayList<String>();
		for (UTMap<String, Object> utMap : userConfigs) {
			Integer v= Integer.valueOf(utMap.get("paramValue").toString());
			vlist.add(utMap.get("paramValue").toString());
			utMap.put("select", true);
			configArray[ v-1]=utMap;
		}
		return  new ArrayList(Arrays.asList(configArray));
	}


	@Override
	public List<UTMap<String, Object>> InitgetPersonConfig(String userId) {
		Map<String, Object>  p=new HashMap<String, Object>();
		p.put("paramType","outsourcePersonConfig");
		List<UTMap<String, Object>> configs=paramDao.getListMaps(p);
		
		Map<String, Object> param=new HashMap<String, Object>();
		param.put("userId", userId);
		List<UTMap<String, Object>> userConfigs=personConfigDao.getListMaps(param);
		int size = 0;
		int configsSize = configs.size();
		int userConfigsSize = userConfigs.size();
		if (configsSize > userConfigsSize) {
			size = configsSize;
		}else {
			size = userConfigsSize;
		}
		UTMap [] configArray=new UTMap[size];
		List<String> vlist=new ArrayList<String>();
		for (UTMap<String, Object> utMap : userConfigs) {
			Integer v= Integer.valueOf(utMap.get("paramValue").toString());
			vlist.add(utMap.get("paramValue").toString());
			utMap.put("select", true);
			configArray[ v-1]=utMap;
		}

		for (UTMap<String, Object> item : configs) {
			Integer v= Integer.valueOf(item.get("value").toString());
			String itemName=item.get("name").toString();
			String remark=item.get("remark")!=null?item.get("remark").toString():"";
			Integer itemType= v == 1?1:2;//1 固定项，2非固定项
			Integer isConfig= v == 1?1:0;//默认配置  默认不勾选 考勤配置项
			UTMap<String, Object> info=new UTMap<String, Object>();
			info.put(IOutSourcePersonConfigDao.FIELD_USERID, userId);
			info.put(IOutSourcePersonConfigDao.FIELD_ITEMTYPE, itemType);
			info.put(IOutSourcePersonConfigDao.FIELD_ITEMNAME, itemName);
			info.put(IOutSourcePersonConfigDao.FIELD_ISCONFIG, isConfig);//默认为没有配置
			info.put(IOutSourcePersonConfigDao.FIELD_REMARK, remark);//默认为没有配置
			info.put(IOutSourcePersonConfigDao.FIELD_ISCONCEL, item.get("isConcel"));
			info.put(IOutSourcePersonConfigDao.FIELD_CONCELPERSON, item.get("cancelPerson"));
			info.put(IOutSourcePersonConfigDao.FIELD_CONCELDATE, item.get("cancelDate"));
			info.put("paramValue",v);
			if(v==1){
				info.put(IOutSourcePersonConfigDao.FIELD_OPENDATE, UTDate.getCurDate());
			}
			
			if(!vlist.contains(v.toString())){
				configArray[v-1]=info;
			}
		}
		//排序
		
		return  new ArrayList(Arrays.asList(configArray));
	}	
}