package com.esc.oms.outsource.outperson.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import com.esc.oms.outsource.outperson.dao.IRecruitmentApplicationDetailDao;
import com.esc.oms.util.RoleUtils;
@Repository
public class RecruitmentApplicationDetailDaoImpl extends BaseOptionDao implements IRecruitmentApplicationDetailDao{
	
	@Override
	public String getTableName() {
		return "recruitment_application_detail";
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		boolean isGetOperationList = params.get("isGetOperationList")==null?false:true;
		super.getPageListMapBySql(getSearchSql(params,isGetOperationList), pageBean, null);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	@Override
	public List<UTMap<String, Object>> getListAll(Map params) {
		return super.getListBySql(getSearchSql(params,false), null);
	}
	
	/**
	 * 根据条件查询
	 * @param params
	 */
	@Override
	public List<UTMap<String, Object>> getListMaps(Map params) {
		return super.getListBySql(getSearchSql(params,false), null);
	}
	
//	/**
//	 * 根据条件查询
//	 * @param params
//	 */
//	@Override
//	public UTMap<String, Object> getById(String id) {
//		SQLQuery sqlQuery = this.getSession().createSQLQuery(sql.toString());
//		sqlQuery.setResultTransformer(new HibernateTramsFrame());
//		this.setParamsToSql(sqlQuery,param);
//		Object object=sqlQuery.uniqueResult();
//		return object!=null? (UTMap)object:new UTMap<String, Object>();
//	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSql(Map params,boolean isGetOperationList){
		StringBuilder sql = new StringBuilder();
		sql.append(" select detail.*,apply.code as applyCode,apply.name as applyName,apply.applyUserId as applyUserId,"
				+ " IFNULL(resumeTmp.passInterviewCount,0) as passInterviewCount,IFNULL(resumeTmp.arrivalCount,0) as arrivalCount, "
				+ " org.name as orgName, org.longName as departmentName "
				+ "  from recruitment_application_detail detail ");
		sql.append(" left join recruitment_application apply on detail.applyId=apply.id ");
		sql.append(" left join sys_org org on org.id = detail.departmentId ");
		sql.append(" left join (select resume.applyDetailId,resume.applyId,resume.supplierId,count(*) as resumeCount,"
				+ " sum(case when resume.managerReviewResult=1 and resume.workflowStatus='3' then 1 else 0 end) as passInterviewCount,sum(case when resume.isArrival=1 then 1 else 0 end) as arrivalCount "
				+ " from recruitment_resume resume group by resume.applyDetailId) resumeTmp on detail.id=resumeTmp.applyDetailId");
		sql.append(" where 1=1 ");
		if(isGetOperationList){
			sql.append(" and apply.status>4 ");
		}
		if(params!=null && params.size()>0){		
			if(params.get("category")!=null &&  StringUtils.isNotEmpty(params.get("category").toString())){
				sql.append(" and detail.category like '%"+params.get("category").toString().trim()+"%' ");
			}
			String nameOrCode = params.get("nameOrCode")==null?null:params.get("nameOrCode").toString();
			if(!StringUtils.isEmpty(nameOrCode)){
				sql.append(" and (apply.code like '%"+nameOrCode+"%' or apply.name like '%"+nameOrCode+"%') ");
			}	
			if(params.get("code")!=null &&  StringUtils.isNotEmpty(params.get("code").toString())){
				sql.append(" and apply.code like '%"+params.get("code").toString().trim()+"%' ");
			}
			if(params.get("applyId")!=null && StringUtils.isNotEmpty(params.get("applyId").toString())){
				sql.append(" and detail.applyId='"+params.get("applyId").toString().trim()+"' ");
			}
			if(params.get("status")!=null && StringUtils.isNotEmpty(params.get("status").toString())){
				sql.append(" and detail.status='"+params.get("status").toString().trim()+"' ");
			}
//			if(params.get("startDate")!=null && StringUtils.isNotEmpty(params.get("startDate").toString())){
//				sql.append(" and DATE_FORMAT(detail.createTime,'%Y-%m-%d')>='"+params.get("startDate").toString().trim()+"' ");
//			}
//			if(params.get("endDate")!=null && StringUtils.isNotEmpty(params.get("endDate").toString())){
//				sql.append(" and DATE_FORMAT(detail.createTime,'%Y-%m-%d')<='"+params.get("endDate").toString().trim()+"' ");
//			}
		}
		//数据权限控制
		if(!RoleUtils.isSupplierAdministrator()&&!RoleUtils.isSystemAdministrator()&&!RoleUtils.isOutsourceAudit()&&!RoleUtils.isOutsourceManager()){
			if("1".equals(EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserType())){//金融机构用户
				String userId = EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId();
				sql.append(" and apply.applyUserId='"+userId.trim()+"' ");
			}else{//供应商用户
				String supplierId = EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserSupplierId();
				sql.append(" and find_in_set('"+supplierId+"',apply.distributeSuppliers)");
			}
		}
		sql.append(" order by detail.createTime desc");
		return  sql.toString();
	}

	@Override
	public List<UTMap<String, Object>> getListAllByParentParam(Map params) {
		return super.getListBySql(getSearchSqlByParentParam(params), null);
	}
	
	/**
	 * 条件查询
	 * @param params
	 * @return
	 */
	private String getSearchSqlByParentParam(Map params){
		StringBuilder sql = new StringBuilder();
		sql.append(" select detail.*, org.name as orgName, org.longName as departmentName from recruitment_application_detail detail ");
		sql.append(" left join recruitment_application apply on detail.applyId=apply.id ");
		sql.append(" left join sys_org org on org.id=detail.departmentId ");
		sql.append(" where 1=1 ");
		if(params!=null && params.size()>0){		
			if(params.get("name")!=null &&  StringUtils.isNotEmpty(params.get("name").toString())){
				sql.append(" and apply.name like '%"+params.get("name").toString().trim()+"%' ");
			}
//			if(params.get("startDate")!=null && StringUtils.isNotEmpty(params.get("startDate").toString())){
//				sql.append(" and apply.applyTime>='"+params.get("startDate").toString().trim()+"' ");
//			}
//			if(params.get("endDate")!=null && StringUtils.isNotEmpty(params.get("endDate").toString())){
//				sql.append(" and apply.applyTime<='"+params.get("endDate").toString().trim()+"' ");
//			}
		}
		sql.append(" order by apply.createTime desc");
		return  sql.toString();
	}

	@Override
	public void closeByApplyId(String applyId) {
		String sql = " update recruitment_application_detail set status='"+IRecruitmentApplicationDetailDao.STATUS_FINISH+"' where"
				+ " applyId='"+applyId+"'";
		this.executeUpdate(sql, null);
	}

}
