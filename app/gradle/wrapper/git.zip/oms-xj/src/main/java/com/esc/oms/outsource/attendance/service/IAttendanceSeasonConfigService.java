package com.esc.oms.outsource.attendance.service;

import org.esc.framework.service.IBaseOptionService;

import java.util.Map;

public interface IAttendanceSeasonConfigService extends IBaseOptionService {
    /**
     * 是否存在年份
     * @param year
     * @return
     */
    public boolean isExistYear(Map<String, Object> params);
}
