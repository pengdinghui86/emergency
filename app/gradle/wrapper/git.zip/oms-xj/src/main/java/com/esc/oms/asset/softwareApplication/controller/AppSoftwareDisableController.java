package com.esc.oms.asset.softwareApplication.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esc.framework.dict.service.ISysParamService;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.service.IBaseOptionService;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.esc.framework.web.BaseOptionController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.asset.softwareApplication.dao.IAppSoftwareDao;
import com.esc.oms.asset.softwareApplication.service.IAppSoftDisableService;
import com.esc.oms.asset.softwareApplication.service.IAppSoftHistoryService;
import com.esc.oms.asset.softwareApplication.service.IAppSoftUpgradeService;
import com.esc.oms.asset.softwareApplication.service.IAppSoftwareService;
import com.esc.oms.util.CommonUtils;

import net.sf.json.JSONObject;



/**
 * 软件停用
 *	
 */
@Controller
@RequestMapping("appSoftDisable")
public class AppSoftwareDisableController extends BaseOptionController {

	@Resource
	private IAppSoftDisableService softDisableService;	
	
	@Resource
	private IAppSoftwareService assetSoftwareService;
	
	@Resource
	private IAppSoftHistoryService softHistoryService;
	
	@Resource
	private IAppSoftUpgradeService softUpgradeService;

	@Resource
	private ISysParamService sysParamService;

	@Override
	public IBaseOptionService optionService() {
		return softDisableService;
	}
	
	@RequestMapping(value="getAll")  
    @ResponseBody
    public UTPageBean getAll(@RequestParam Map<String, Object> params){
		UTPageBean pageBean = CommonUtils.getPageBean(params);
		try{
			softDisableService.getPageInfo(pageBean, params);
		}catch(Exception e){
    		logger.error("Exception", e);
    	}
       return pageBean;
    }
	
	@RequestMapping(value="/saveOrUpdate",method=RequestMethod.POST)  
    @ResponseBody
    public String saveorupdate(@RequestBody Map<String,Object> map){  
    	String id = (String)map.get("id");
    	UTMap<String, Object> software = assetSoftwareService.getById((String)map.get("softwareId"));		
    	try{
	    	if(id == null){
	    		softDisableService.add(map);	    	
	    	}else{
	    		softDisableService.updateById(map);	 
	    	}
	    	
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String today = sdf.format(new Date());
			//升级日期
			Date disableDate = sdf.parse((String) map.get("disableDate"));
			if (disableDate.before(sdf.parse(today))) { // 若在今天之前（不包括今天），则生成历史记录，并更新软件的版本等信息	
				softUpgradeService.disable(map);
			}
		
			
    	}catch(EscServiceException e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false,e.getMessage());
    	}catch(Exception e){
    		logger.error("Exception", e);
    		return UTJsonUtils.getJsonMsg(false, "操作失败");
    	}
       return UTJsonUtils.getJsonMsg(true, "操作成功");
    }
	
	
	@RequestMapping(value="getById")
	@ResponseBody
	public UTMap<String, Object> defgetById(@RequestParam  Map<String, Object> param){		
		UTMap<String, Object> map = null;
    	try{
    		map = optionService().getById(param.get("id").toString());
		}catch(Exception e){
			logger.error("Exception", e);
			return new UTMap<String, Object>();
    	}
       return map;
	}
	
	
	@RequestMapping(value = "leadingout")
	public void leadingout(@RequestParam Map<String, Object> param,
			HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean utPageBean = CommonUtils.getPageBean(param);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = null;
			if(info != null) {
				jsonBean = JSONObject.fromObject(info);
			}
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = softDisableService.getSoftDisableList(jsonBean);
			} else {
			// 根据条件 导出当前
				optionService().getPageInfo(utPageBean, jsonBean);
				data = utPageBean.getRows();
			}
			//替换下拉的值
			Map<String, String> fieldAndParamType = new HashMap<String, String>();
			fieldAndParamType.put(IAppSoftwareDao.FIELD_STATUS, "appSoftStatus");
			sysParamService.changeParamData(data, fieldAndParamType);
			response.setCharacterEncoding("UTF-8");
			// 解析数据导出
			softDisableService.leadingout(data, request, response);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	

}
