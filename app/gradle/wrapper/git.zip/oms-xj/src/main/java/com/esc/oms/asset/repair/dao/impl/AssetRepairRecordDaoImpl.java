package com.esc.oms.asset.repair.dao.impl;

import com.esc.oms.asset.repair.dao.IAssetRepairRecordDao;
import com.esc.oms.util.RoleUtils;
import org.apache.commons.lang.StringUtils;
import org.esc.framework.EscCurrectUserHolder;
import org.esc.framework.persistence.dao.BaseOptionDao;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.page.UTPageBean;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class AssetRepairRecordDaoImpl extends BaseOptionDao implements
		IAssetRepairRecordDao {

	@Override
	public String getTableName() {
		return "assets_material_repair_record";
	}
	
	@Override
	public void getPageInfo(UTPageBean pageBean, Map params) {
		super.getPageListMapBySql(getSearchSql(params), pageBean, null);
	}
	
	
	public String getSearchSql(Map params){
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT amrr.id,amrr.repairUser,amrr.repairPhone,amrr.cost,amrr.reason,amrr.result,amrr.resultRemark, amrr.beginTime,amrr.endTime,"
				+ " concat(ami.name,if(ami.serialNum<> '', concat('/',ami.serialNum), '')) AS assetsId, "
				+ "concat(su.name,'/',su.code) AS applyUserId,"
				+ "sbi.name AS repairSupplier "
				+ " FROM assets_material_repair_record amrr ");
		sb.append(" LEFT JOIN assets_material_info ami ON amrr.assetsId = ami.id");
		sb.append(" LEFT JOIN supplier_base_info sbi ON sbi.id = amrr.repairSupplier ");
		sb.append(" LEFT JOIN sys_user su ON su.id = amrr.applyUserId ");
		sb.append(" WHERE 1 = 1");
		
		//数据权限过滤
		if(!EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.SYSTEM_ADMINISTRATOR,RoleUtils.ASSET_MANAGER) && EscCurrectUserHolder.instance.getEscCurrectUserTool().isRole(RoleUtils.COMMON_BANK_USER)){
			sb.append("  and amrr.applyUserId = '"+EscCurrectUserHolder.instance.getEscCurrectUserTool().getCurrectUserId()+"' ");
		}
		
		if(params!=null && params.size()>0){		
			if(params.get("assetsName")!=null &&  StringUtils.isNotEmpty(params.get("assetsName").toString())){
//				sb.append(" and ami.name like '%"+params.get("assetsName").toString().trim()+"%' or ami.code like '%"+params.get("assetsName").toString().trim()+"%'");
				sb.append(" and concat(ami.name,'/',ami.code) like '%"+params.get("assetsName").toString().trim()+"%'");
			}
//			if(params.get("repairSupplier")!=null && StringUtils.isNotEmpty(params.get("repairSupplier").toString())){
//				sb.append(" and amrr.repairSupplier = '"+params.get("repairSupplier").toString().trim()+"' ");
//			}
			if(params.get("supplierName")!=null && StringUtils.isNotEmpty(params.get("supplierName").toString())){
				sb.append(" and sbi.name like '%"+params.get("supplierName").toString().trim()+"%' ");
			}
		}
		sb.append(" order by amrr.createTime desc");
		return sb.toString();
	}
	
	
	
	public String getRepairRecordByIdSql(String id){
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT amrr.id,amrr.assetsId,concat(ami.`name`,IF ( ami.serialNum IS NULL OR ami.serialNum = '', '', concat('/', ami.serialNum))) AS assetsName,ami.code AS assetsCode,amrr.applyUserId,amrr.repairUser,amrr.repairPhone,amrr.repairSupplier,"
				+ "amrr.cost,amrr.reason,amrr.result,amrr.resultRemark ,amrr.beginTime,amrr.endTime,sbi.name as supplierName"
				+ " FROM assets_material_repair_record amrr ");
		sb.append(" LEFT JOIN assets_material_info ami ON ami.id = amrr.assetsId ");
		sb.append(" LEFT JOIN supplier_base_info sbi ON sbi.id = amrr.repairSupplier ");
		sb.append(" WHERE amrr.id = '"+id+"'");
		
		return sb.toString();
	}
	
	
	@Override
	public UTMap<String, Object> getRepairRecordById(String id) {
		return super.getOneBySql(getRepairRecordByIdSql(id),null);
	}
	

	@Override
	public List<UTMap<String, Object>> getRepairRecordList(Map param) {
		return super.getListBySql(getSearchSql(param));
	}

	
	

}
