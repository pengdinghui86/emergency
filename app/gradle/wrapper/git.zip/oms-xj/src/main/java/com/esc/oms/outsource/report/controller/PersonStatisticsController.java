package com.esc.oms.outsource.report.controller;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.esc.framework.exception.EscServiceException;
import org.esc.framework.utils.UTDate;
import org.esc.framework.utils.UTJsonUtils;
import org.esc.framework.utils.UTMap;
import org.esc.framework.utils.excel.UTExcel;
import org.esc.framework.utils.page.UTPageBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esc.oms.outsource.outperson.service.IPersonOptionService;
import com.esc.oms.outsource.report.service.IPersonStatisticsService;
import com.esc.oms.util.CommonUtils;

@Controller
@RequestMapping("outsource/person/statistics")
public class PersonStatisticsController  {
	
	protected Logger logger = LoggerFactory.getLogger(getClass());
	
	@Resource
	private IPersonStatisticsService personStatisticsService;
	@Resource
	private IPersonOptionService personOptionService;
	/**
	 * 已组织为 维度统计 各个组织内的人员
	 * @return
	 */
	@RequestMapping("getPersonStatisticeByOrg")
	@ResponseBody
	public UTPageBean getPersonStatisticeByOrg(@RequestParam Map<String, Object> param){
		UTPageBean pageBean = CommonUtils.getPageBean(param);
		personStatisticsService.getPersonStatisticeByOrg(param,pageBean);
		return pageBean;
	}
	/**
	 * 已供应商为 维度统计 各个组织内的人员
	 * @return
	 */
	@RequestMapping("getPersonStatisticeBySupplier")
	@ResponseBody
	public UTPageBean  getPersonStatisticeBySupplier(@RequestParam Map<String,Object> param){
		UTPageBean pageBean = CommonUtils.getPageBean(param);
		 personStatisticsService.getPersonStatisticeBySupplier(param,pageBean);
		 return pageBean;
	}
	@RequestMapping("getPersonStatisticeSupplierCharData")
	@ResponseBody
	public Map<String, Map<String, String>>  getPersonStatisticeSupplierCharData(@RequestParam Map<String,Object> param){
		UTPageBean pageBean = CommonUtils.getPageBean(param);
		UTPageBean utPageBean2=new UTPageBean();
		utPageBean2.setPage(pageBean.getPage());
		utPageBean2.setCount(pageBean.getCount());

		 personStatisticsService.getPersonStatisticeBySupplier(param,utPageBean2);
		 
		 Map<String, Map<String, String>> results=new HashMap<String, Map<String,String>>();
		 Map<String, String> supplier=new HashMap<String, String>();
		 List<String> names2=new ArrayList<String>();
		 List<String>  rcs2=new ArrayList<String>();
		 List<String>  tcs2=new ArrayList<String>();
		 List<String>  ldvs2=new ArrayList<String>();
		 for (Object item : utPageBean2.getRows()) {
			 
			UTMap<String, Object> itemMap=(UTMap<String, Object>) item;
			Object flowRate=itemMap.get("flowRate");
			Double fr=flowRate!=null?Double.valueOf(flowRate.toString()):0;
			if(fr.compareTo(new Double("0"))==0){
				continue;
			}
			names2.add(itemMap.get("shortName").toString());
			rcs2.add(itemMap.get("enterUserCount").toString());
			tcs2.add(itemMap.get("exitUserCount").toString());
	
			ldvs2.add(fr.toString() );
		}
		 
		 supplier.put("names", StringUtils.join(names2.toArray(),","));
		 supplier.put("rcs", StringUtils.join(rcs2.toArray(),","));
		 supplier.put("tcs", StringUtils.join(tcs2.toArray(),","));
		 supplier.put("ldvs", StringUtils.join(ldvs2.toArray(),","));
		 
		 results.put("supplier", supplier);
		 
		 return results;
	}
	
	@RequestMapping("getPersonStatisticeOrgCharData")
	@ResponseBody
	public Map<String, Map<String, String>>  getPersonStatisticeCharData(@RequestParam Map<String,Object> param){
		UTPageBean pageBean = CommonUtils.getPageBean(param);
		UTPageBean utPageBean1=new UTPageBean();
		utPageBean1.setPage(pageBean.getPage());
		utPageBean1.setCount(pageBean.getCount());
		
	
		 personStatisticsService.getPersonStatisticeByOrg(param, utPageBean1);
		 
		 Map<String, Map<String, String>> results=new HashMap<String, Map<String,String>>();
		 Map<String, String> org=new HashMap<String, String>();
		 
		 List<String> names1=new ArrayList<String>();
		 List<String>  rcs1=new ArrayList<String>();
		 List<String>  tcs1=new ArrayList<String>();
		 List<String>  ldvs1=new ArrayList<String>();
		 for (Object item : utPageBean1.getRows()) {
			UTMap<String, Object> itemMap=(UTMap<String, Object>) item;		
			Object flowRate=itemMap.get("flowRate");
			Double fr=flowRate!=null?Double.valueOf(flowRate.toString()):0;
			if(fr.compareTo(new Double("0"))==0){
				continue;
			}
			names1.add(itemMap.get("shortName").toString());
			rcs1.add(itemMap.get("enterUserCount").toString());
			tcs1.add(itemMap.get("exitUserCount").toString());
	
			//itemMap.put("flowRate", fr>0?(fr)+"%":"0%" );
			ldvs1.add(fr.toString() );
		}
		 org.put("names", StringUtils.join(names1.toArray(),","));
		 org.put("rcs", StringUtils.join(rcs1.toArray(),","));
		 org.put("tcs", StringUtils.join(tcs1.toArray(),","));
		 org.put("ldvs", StringUtils.join(ldvs1.toArray(),","));
		 
		 results.put("org", org);
		 
		 return results;
	}
	
	@RequestMapping(value = "exportStatisticeByOrg")
	public void exportStatisticeByOrg(@RequestParam Map<String, Object> param,
			HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean pageBean = CommonUtils.getPageBean(param);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = JSONObject.fromObject(info);
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = personStatisticsService.getPersonStatisticeByOrg(jsonBean);
			} else {
				personStatisticsService.getPersonStatisticeByOrg(jsonBean, pageBean);
				data = pageBean.getRows();
			}
			response.setCharacterEncoding("UTF-8");
			personStatisticsService.exportPersonStatisticeByOrg(data, request, response);
		
		} catch (Exception e) {
		//	logger.error(e.getMessage());
		}
	}

	@RequestMapping(value = "exportStatisticeBySupplier")
	public void exportStatisticeBySupplier(@RequestParam Map<String, Object> param,
			HttpServletRequest request,
			HttpServletResponse response) {
		UTPageBean pageBean = CommonUtils.getPageBean(param);
		try {
			List<UTMap<String, Object>> data = new ArrayList<UTMap<String, Object>>();
			
			Integer outType = Integer.parseInt((String) param.get("outType"));
			Object info = param.get("params");
			JSONObject jsonBean = JSONObject.fromObject(info);
			
			// 根据条件 导出全部
			if (UTExcel.EXCELOUTTYPE_ALL == outType) {
				// getAll
				data = personStatisticsService.getPersonStatisticeBySupplier(jsonBean);
			} else {
				personStatisticsService.getPersonStatisticeBySupplier(jsonBean, pageBean);
				data = pageBean.getRows();
			}
			response.setCharacterEncoding("UTF-8");
			personStatisticsService.exportPersonStatisticeBySupplier(data, request, response);
		
		} catch (Exception e) {
		//	logger.error(e.getMessage());
		}
	}
	
	//重置每天流动率
	@RequestMapping(value = "personFlowEveryDayResetting")
	public void personFlowEveryDayResetting(){
		personOptionService.personFlowEveryDayResetting(UTDate.getCurDate());
	}
	
	@RequestMapping(value="timing")  
	@ResponseBody
	public String initData() {
		try {
			personOptionService.timing();
		} catch (EscServiceException e) {
			logger.error("EscServiceException", e);
			return UTJsonUtils.getJsonMsg(false, e.getMessage());
		} catch (Exception e) {
			logger.error("Exception", e);
			return UTJsonUtils.getJsonMsg(false, "生成失败");
		}
		return UTJsonUtils.getJsonMsg(true, "生成成功");
	}
}
