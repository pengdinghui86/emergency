Outsourcing Manager System
打包命令：mvn clean package

启动方式：
1.直接通过main函数启动：/idap/src/main/java/com/esc/idap/IdapApplication.java
2.通过maven插件的方式启动：在Maven Build添加启动命令：spring-boot:run
3.打成Jar包，通过java命令启动：java -Dfile.encoding=utf-8 -jar oms-0.1.jar>>>>>>> .r16
