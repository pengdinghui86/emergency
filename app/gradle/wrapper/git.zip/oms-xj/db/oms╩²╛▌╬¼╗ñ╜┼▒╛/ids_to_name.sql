/**
*用户ids列表转username
**/
drop procedure if exists `ids_to_name`;
drop function if exists `ids_to_name`;
delimiter ;;
create function `ids_to_name`(
    ids text
) returns text
begin 
    declare p int;
    declare result text;
    declare v_ids text;
    declare v_id varchar(36);
    declare userName varchar(36);
    declare v_split varchar(2);
     
 
    set result = '';
    set v_ids = ids;
    set v_split = '';
     
    repeat 
        set p = INSTR(v_ids, ',');
        if p > 0 then 
            set v_id = SUBSTR(v_ids FROM 1 for p-1);
            set v_ids = SUBSTR(v_ids, p + 1);
        else 
            set v_id = v_ids;
            set v_ids = '';
        end if;
         
        select concat(`name`,'/',`code`) into userName from `sys_user` where `id` = v_id;
        set result = concat(result, v_split, userName);
        set v_split = ', ';
         
    until LENGTH(v_ids) <= 0 end repeat;
    return result;
     
end;;
 
delimiter ;