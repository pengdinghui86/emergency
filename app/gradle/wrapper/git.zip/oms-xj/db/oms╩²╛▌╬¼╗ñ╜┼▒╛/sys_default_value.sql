-- ----------------------------
-- Table structure for sys_default_value
-- ----------------------------
DROP TABLE IF EXISTS `sys_default_value`;
CREATE TABLE `sys_default_value` (
  `id` char(36) NOT NULL,
  `code` varchar(50) DEFAULT NULL,
  `configType` varchar(50) DEFAULT NULL COMMENT '模块',
  `value` varchar(500) DEFAULT NULL COMMENT '值',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_default_value
-- ----------------------------
INSERT INTO `sys_default_value` VALUES ('04376553-61d8-4602-b82e-5453fd87e095', 'attendanceDate', 'attendance', '2,4,5,6,7');
INSERT INTO `sys_default_value` VALUES ('2368f81d-29fe-4beb-a5df-c955ef71fc6b', 'amEnd', 'attendance', '12:00');
INSERT INTO `sys_default_value` VALUES ('338887fd-6997-48f0-a7ab-ee491836da60', 'endDate', 'attendance', '2016-08-31');
INSERT INTO `sys_default_value` VALUES ('3a85105b-2ce3-4054-a326-ae74143e92a9', 'attendanceDateType', 'attendance', '1');
INSERT INTO `sys_default_value` VALUES ('40ebafb5-aa18-49b2-9a34-a3f00479b24c', 'dailyHours', 'attendance', '21600');
INSERT INTO `sys_default_value` VALUES ('4e839594-bb47-4d6a-9b03-f68b88a3b3a3', 'pmBegin', 'attendance', '14:00');
INSERT INTO `sys_default_value` VALUES ('76afc095-6603-4f6e-9db5-04c5ab95974d', 'breakTime', 'attendance', '7200');
INSERT INTO `sys_default_value` VALUES ('8e59ab0f-16b8-4d2c-a4aa-c3ee88958af0', 'pmEnd', 'attendance', '17:00');
INSERT INTO `sys_default_value` VALUES ('c115b248-8676-4308-a739-d3a2ca33fc1b', 'dailyHoursPM', 'attendance', '10800');
INSERT INTO `sys_default_value` VALUES ('c9899043-4a5c-438f-bbf1-d6f9b0869a84', 'beginDate', 'attendance', '2016-08-31');
INSERT INTO `sys_default_value` VALUES ('e2c21c4c-515e-45ec-bf29-6805bd8a76d2', 'dailyHoursAM', 'attendance', '10800');
INSERT INTO `sys_default_value` VALUES ('f64a6369-1c57-4b23-9200-078fdc8b85ec', 'amBegin', 'attendance', '09:00');
