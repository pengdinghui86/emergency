﻿# Host: localhost  (Version: 5.6.23-log)
# Date: 2016-04-07 11:19:05
# Generator: MySQL-Front 5.3  (Build 4.198)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "sys_workflow"
#

DROP TABLE IF EXISTS `sys_workflow`;
CREATE TABLE `sys_workflow` (
  `id` varchar(36) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `orderNum` int(11) DEFAULT NULL,
  `createUser` varchar(255) DEFAULT NULL,
  `createTime` timestamp NULL DEFAULT NULL,
  `updateUser` varchar(255) DEFAULT NULL,
  `updateTime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Structure for table "sys_workflow_audit_history"
#

DROP TABLE IF EXISTS `sys_workflow_audit_history`;
CREATE TABLE `sys_workflow_audit_history` (
  `id` char(36) NOT NULL,
  `instanceId` char(36) DEFAULT NULL,
  `nodeName` varchar(255) DEFAULT NULL,
  `auditResult` varchar(255) DEFAULT NULL,
  `auditComment` text,
  `createUser` varchar(255) DEFAULT NULL,
  `createTime` timestamp NULL DEFAULT NULL,
  `optionUserId` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Structure for table "sys_workflow_branch"
#

DROP TABLE IF EXISTS `sys_workflow_branch`;
CREATE TABLE `sys_workflow_branch` (
  `id` char(36) NOT NULL,
  `workflowVersionId` char(36) NOT NULL,
  `flowElementId` varchar(255) DEFAULT NULL,
  `decisionFlowElementId` varchar(255) DEFAULT NULL,
  `stepFlowElementId` varchar(255) DEFAULT NULL,
  `branchCondition` text,
  `createUser` varchar(255) DEFAULT NULL,
  `createTime` timestamp NULL DEFAULT NULL,
  `updateUser` varchar(255) DEFAULT NULL,
  `updateTime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Structure for table "sys_workflow_business_user_history"
#

DROP TABLE IF EXISTS `sys_workflow_business_user_history`;
CREATE TABLE `sys_workflow_business_user_history` (
  `id` char(36) NOT NULL,
  `instanceId` char(36) DEFAULT NULL,
  `businessRecordId` varchar(255) DEFAULT NULL,
  `flowElementId` varchar(255) DEFAULT NULL,
  `optionUserIds` longtext,
  `iscause` varchar(255) DEFAULT NULL COMMENT '是否扭转过来的人',
  `createUser` varchar(255) DEFAULT NULL,
  `createTime` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updateUser` varchar(255) DEFAULT NULL,
  `updateTime` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Structure for table "sys_workflow_decision"
#

DROP TABLE IF EXISTS `sys_workflow_decision`;
CREATE TABLE `sys_workflow_decision` (
  `id` char(36) NOT NULL,
  `workflowVersionId` char(36) NOT NULL,
  `flowElementId` varchar(255) DEFAULT NULL,
  `executorType` char(1) DEFAULT NULL,
  `executorValue` text,
  `formItemValue` varchar(50) DEFAULT NULL,
  `createUser` varchar(255) DEFAULT NULL,
  `createTime` timestamp NULL DEFAULT NULL,
  `updateUser` varchar(255) DEFAULT NULL,
  `updateTime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Structure for table "sys_workflow_element_seat"
#

DROP TABLE IF EXISTS `sys_workflow_element_seat`;
CREATE TABLE `sys_workflow_element_seat` (
  `id` char(36) NOT NULL,
  `workflowVersionId` char(36) DEFAULT NULL,
  `flowElementId` varchar(255) DEFAULT NULL,
  `style` varchar(255) DEFAULT NULL COMMENT '记录位置比例',
  `detailedSeat` varchar(500) DEFAULT NULL,
  `executorType` varchar(255) DEFAULT NULL,
  `createUser` varchar(255) DEFAULT NULL,
  `createTime` timestamp NULL DEFAULT NULL,
  `updateUser` varchar(255) DEFAULT NULL,
  `updateTime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Structure for table "sys_workflow_exchange"
#

DROP TABLE IF EXISTS `sys_workflow_exchange`;
CREATE TABLE `sys_workflow_exchange` (
  `id` char(36) NOT NULL,
  `instanceId` char(36) DEFAULT NULL,
  `flowElementId` varchar(255) DEFAULT NULL,
  `flowElementName` varchar(255) DEFAULT NULL,
  `cause` varchar(655) DEFAULT NULL COMMENT '流转原因',
  `currentExecutor` longtext COMMENT '当前执行人',
  `executor` longtext COMMENT '转向后执行人',
  `optionsUser` varchar(255) DEFAULT NULL,
  `createUser` varchar(255) DEFAULT NULL,
  `createTime` timestamp NULL DEFAULT NULL,
  `updateUser` varchar(255) DEFAULT NULL,
  `updateTime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Structure for table "sys_workflow_form"
#

DROP TABLE IF EXISTS `sys_workflow_form`;
CREATE TABLE `sys_workflow_form` (
  `id` varchar(36) NOT NULL,
  `workflowId` varchar(36) DEFAULT NULL,
  `formItemName` varchar(50) DEFAULT NULL,
  `formItemValue` varchar(50) DEFAULT NULL,
  `formItemOrder` int(11) DEFAULT NULL,
  `tableName` varchar(255) DEFAULT NULL,
  `tableField` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Structure for table "sys_workflow_instance_link"
#

DROP TABLE IF EXISTS `sys_workflow_instance_link`;
CREATE TABLE `sys_workflow_instance_link` (
  `id` char(36) NOT NULL,
  `instanceId` char(36) DEFAULT NULL,
  `sourceId` varchar(255) DEFAULT NULL,
  `targetId` varchar(255) DEFAULT NULL,
  `linkName` varchar(255) DEFAULT NULL,
  `createUser` varchar(255) DEFAULT NULL,
  `createTime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Structure for table "sys_workflow_instance_node"
#

DROP TABLE IF EXISTS `sys_workflow_instance_node`;
CREATE TABLE `sys_workflow_instance_node` (
  `id` char(36) NOT NULL,
  `instanceId` char(36) DEFAULT NULL,
  `nodeId` varchar(255) DEFAULT NULL,
  `nodeName` varchar(255) DEFAULT NULL,
  `nodeType` varchar(255) DEFAULT NULL,
  `nodeStatus` char(1) DEFAULT NULL,
  `createUser` varchar(255) DEFAULT NULL,
  `createTime` timestamp NULL DEFAULT NULL,
  `style` varchar(600) DEFAULT NULL COMMENT '节点位置',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Structure for table "sys_workflow_step"
#

DROP TABLE IF EXISTS `sys_workflow_step`;
CREATE TABLE `sys_workflow_step` (
  `id` char(36) NOT NULL,
  `workflowVersionId` char(36) DEFAULT NULL,
  `flowElementId` varchar(255) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `executorType` char(1) DEFAULT NULL,
  `executorValue` longtext,
  `formItemValue` varchar(50) DEFAULT NULL,
  `createUser` varchar(255) DEFAULT NULL,
  `createTime` timestamp NULL DEFAULT NULL,
  `updateUser` varchar(255) DEFAULT NULL,
  `updateTime` timestamp NULL DEFAULT NULL,
  `messageType` varchar(255) DEFAULT NULL COMMENT '信息发送方式',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Structure for table "sys_workflow_version"
#

DROP TABLE IF EXISTS `sys_workflow_version`;
CREATE TABLE `sys_workflow_version` (
  `id` char(36) NOT NULL,
  `workflowId` char(36) DEFAULT NULL,
  `versionNumber` int(11) DEFAULT NULL,
  `modelId` varchar(255) DEFAULT NULL,
  `deploymentId` varchar(255) DEFAULT NULL,
  `bpmnXml` longtext,
  `createUser` varchar(255) DEFAULT NULL,
  `createTime` timestamp NULL DEFAULT NULL,
  `updateUser` varchar(255) DEFAULT NULL,
  `updateTime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Structure for table "sys_workflow_instance"
#

DROP TABLE IF EXISTS `sys_workflow_instance`;
CREATE TABLE `sys_workflow_instance` (
  `id` char(36) NOT NULL,
  `workflowVersionId` char(36) DEFAULT NULL,
  `workflowCode` varchar(50) DEFAULT NULL,
  `businessRecordId` char(36) DEFAULT NULL,
  `createUser` varchar(255) DEFAULT NULL,
  `createTime` timestamp NULL DEFAULT NULL,
  `currentStep` varchar(255) DEFAULT NULL,
  `currentExecutor` longtext,
  `formMap` longtext COMMENT '申请单位Id',
  `currentStepName` varchar(255) DEFAULT NULL COMMENT '当前节点名称',
  `createUserId` char(36) DEFAULT NULL COMMENT '流程发起人Id',
  PRIMARY KEY (`id`),
  KEY `FK_SYS_WORK_REFERENCE_SYS_WORK` (`workflowVersionId`),
  CONSTRAINT `FK_SYS_WORK_REFERENCE_SYS_WORK` FOREIGN KEY (`workflowVersionId`) REFERENCES `sys_workflow_version` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
