select * from sys_resource where code like '6%'

-- 删除资产管理菜单数据
delete from sys_resource where code like '6%'

-- 删除资产管理员的菜单权限
delete from sys_role_resource where roleId = '3f57aff5-5b6f-4434-8214-cbb8c7372957'