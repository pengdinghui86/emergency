
DROP FUNCTION IF EXISTS `manhour_parse`;

/** 加班、请假、调休考勤日历查询函数 workflow/instance/getAuditHistory
* status 1.待提交  2.待审批  3.审批中  4.驳回 5.审批通过 6.被终止
* presentDate 数据日期 
* hours 工时 
* manhourType 加班：1，请假：2，出差：3
**/
CREATE FUNCTION `manhour_parse`(id char(36),presentDate date, status int,hours double,manhourType int) RETURNS varchar(255)  
BEGIN 

DECLARE title VARCHAR(20) DEFAULT ''; -- 时分秒
DECLARE color VARCHAR(10) DEFAULT ''; -- 根据考勤正常与否返回相应的颜色，异常红色，正常绿色
DECLARE presentDateStr VARCHAR(20) DEFAULT ''; -- 时分秒
SET presentDateStr = CONCAT(presentDate,' 23:59:59');-- 后面加‘23:59:59’是为了数据排在考勤日历后面 

IF(manhourType = 1) THEN 
	SET title = '加班申请';  -- 黄色
ELSEIF (manhourType = 2)THEN  
	SET title = '请假申请';  -- 黄色
ELSE  
	SET title = '出差申请';  -- 被终止是红色
END IF; 

-- 1.待提交  2.待审批  3.审批中  4.驳回 5.审批通过 6.被终止
IF(status = 1) THEN 
	SET color = '#E9C341';  -- 黄色
	SET title = CONCAT(title,'待提交'); 
ELSEIF (status = 2)THEN  
	SET color = '#E9C341';  -- 黄色
	SET title = CONCAT(title,'待审批');
ELSEIF (status = 3)THEN  
	SET color = '#E9C341';  -- 黄色
	SET title = CONCAT(title,'审批中');
ELSEIF (status = 4)THEN  
	SET color = '#A7A7A7';  -- 驳回是灰色
	SET title = CONCAT(title,'被驳回');
ELSEIF (status = 5)THEN  
	SET color = '#00a65a'; -- 审批通过是绿色
	SET title = CONCAT(title,'审批通过:',hours,'小时');
ELSE  
	SET color = '#A7A7A7';  -- 被终止是灰色
	SET title = CONCAT(title,'被终止');
END IF; 

RETURN CONCAT('{"title":"',title,'","backgroundColor":"',color,'","borderColor":"',color,'","start":"',presentDateStr,'","id":"',id,'","manhourType":"',manhourType,'"}');  
END;