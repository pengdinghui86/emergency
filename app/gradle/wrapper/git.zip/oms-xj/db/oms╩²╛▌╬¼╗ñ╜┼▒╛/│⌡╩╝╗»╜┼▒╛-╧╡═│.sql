-- ----------------------------
-- ϵͳ��ɫ(sys_role)
-- ---------------------------- 
INSERT INTO `sys_role`(`id`,`code`,`name`,`roleType`,`state`,`remark`,`createUser`,`createTime`,`updateUser`,`updateTime`,`signature`) VALUES ('07be9bda-66cc-43bc-8433-7a7e11b25809', '107', '��Ӧ�̹���Ա', '1', null, '��Ӧ�̼������ҵ�����Ա��һ��Թ�Ӧ�̼����ҵ��������Ĺ���Ȩ��', '[admin]admin', '2016-03-28 18:00:58', '[admin]admin', '2016-03-28 14:56:19', 'supplierAdministrator');
INSERT INTO `sys_role`(`id`,`code`,`name`,`roleType`,`state`,`remark`,`createUser`,`createTime`,`updateUser`,`updateTime`,`signature`) VALUES ('1', '101', 'ϵͳ����Ա', '1', null, null, null, '2016-03-28 18:01:51', '[admin]admin', '2016-03-28 14:54:20', 'systemAdministrator');
INSERT INTO `sys_role`(`id`,`code`,`name`,`roleType`,`state`,`remark`,`createUser`,`createTime`,`updateUser`,`updateTime`,`signature`) VALUES ('2', '102', '��ͨ�û�', '1', null, null, null, '2016-03-28 17:55:31', null, '2015-12-17 19:46:41', 'commonUser');
INSERT INTO `sys_role`(`id`,`code`,`name`,`roleType`,`state`,`remark`,`createUser`,`createTime`,`updateUser`,`updateTime`,`signature`) VALUES ('2e398065-74b3-461d-8064-427b40627ca8', '115', '��Ӧ��������', '1', null, '������Ϣ�Ƽ������ƣ��Թ�Ӧ�̼�����������ݾ��в鿴Ȩ�ޣ������߱��༭Ȩ��', '[admin]admin', '2016-03-29 10:38:07', '[admin]admin', '2016-03-28 14:57:26', 'outsourceAudit');
INSERT INTO `sys_role`(`id`,`code`,`name`,`roleType`,`state`,`remark`,`createUser`,`createTime`,`updateUser`,`updateTime`,`signature`) VALUES ('3f57aff5-5b6f-4434-8214-cbb8c7372957', '114', '�ʲ�����Ա', '1', null, null, '[admin]admin', '2016-03-28 17:55:38', '[admin]admin', '2016-01-23 17:27:03', 'assetsManager');
INSERT INTO `sys_role`(`id`,`code`,`name`,`roleType`,`state`,`remark`,`createUser`,`createTime`,`updateUser`,`updateTime`,`signature`) VALUES ('9eaad00c-15de-4941-823e-22083af0ff40', '113', '��ȫ���Ա', '1', null, null, '[admin]admin', '2016-03-28 17:56:53', '[admin]admin', '2016-01-23 17:25:19', 'securityCheck');
INSERT INTO `sys_role`(`id`,`code`,`name`,`roleType`,`state`,`remark`,`createUser`,`createTime`,`updateUser`,`updateTime`,`signature`) VALUES ('bd643a10-988d-465d-866e-f887cd212a2a', '112', '��Ӧ������', '1', null, null, '[admin]admin', '2016-03-28 17:57:28', '[admin]admin', '2016-03-28 11:20:56', 'supplierAssistant');
INSERT INTO `sys_role`(`id`,`code`,`name`,`roleType`,`state`,`remark`,`createUser`,`createTime`,`updateUser`,`updateTime`,`signature`) VALUES ('bdd89c2b-2be1-4b98-a56f-8868d32f57d3', '110', '��ͨ��Ӧ���û�', '1', null, null, '[admin]admin', '2016-03-28 17:57:45', '[admin]admin', '2016-01-23 17:23:47', 'commonSupplierUser');
INSERT INTO `sys_role`(`id`,`code`,`name`,`roleType`,`state`,`remark`,`createUser`,`createTime`,`updateUser`,`updateTime`,`signature`) VALUES ('be935630-e062-4687-8d18-8ea8f9840a94', '109', 'Ѳ������Ա', '1', null, null, '[admin]admin', '2016-03-28 17:58:06', '[admin]admin', '2016-01-23 17:23:16', 'inspectionConfig');
INSERT INTO `sys_role`(`id`,`code`,`name`,`roleType`,`state`,`remark`,`createUser`,`createTime`,`updateUser`,`updateTime`,`signature`) VALUES ('ca5d9511-9bf9-426b-9126-503bdc6b3058', '108', '��ͨ���ڻ����û�', '1', null, null, '[admin]admin', '2016-03-28 17:58:16', '[admin]admin', '2016-01-23 17:22:33', 'commonBankUser');
INSERT INTO `sys_role`(`id`,`code`,`name`,`roleType`,`state`,`remark`,`createUser`,`createTime`,`updateUser`,`updateTime`,`signature`) VALUES ('f54b2f07-6ae5-4ae3-8b1f-7988cc8eeacf', '105', '��Ӧ�̸�����', '1', null, '��Ӧ�̵ĸ����ˣ�������Ӧ�̵����ҵ��', null, '2016-03-28 17:58:45', '[admin]admin', '2016-03-28 14:55:30', 'supplierLeader');
INSERT INTO `sys_role`(`id`,`code`,`name`,`roleType`,`state`,`remark`,`createUser`,`createTime`,`updateUser`,`updateTime`,`signature`) VALUES ('03e3fbb2-9d20-4f5c-8c15-f9c6462a6ba0', '111', '���ո���Ա', '1', null, null, '[admin]admin', '2016-03-28 17:55:07', '[admin]admin', '2016-01-23 17:24:19', 'riskTrack');


-- ----------------------------
-- ϵͳ��������(sys_param_type)
-- ---------------------------- 
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('003087a4-d8e1-4280-b3b1-819d2bd44176', 'recordType', '�����켣����', '1', null, '[admin]admin', '[admin]admin', '2016-02-23 17:29:50', '2016-02-23 17:29:50');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('04cdb1a0-fa51-47b6-86b1-e09ed322cf93', 'agreementStatus', '��ͬ״̬', '1', null, '[admin]admin', '[admin]admin', '2016-01-23 16:41:01', '2016-01-23 16:41:01');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('06918f98-a4f0-4c95-8c20-a855f8db59ca', 'LogType', '��־����', '1', null, null, '', '2015-12-30 12:30:33', '2015-12-21 09:20:26');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('07e2c5bc-f43f-48f5-b218-39f289ec7fdf', 'lowvalueReceptionDetailConfirmStatus', '��ֵ�׺�Ʒ����ȷ��״̬', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:08:13', '2016-03-23 12:08:13');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('0ca56582-829e-4947-9e0a-3d7ec6943de8', 'agreementEvaluateStatus', '��ͬ��������״̬', '1', '��ͬ��������״̬', '[admin]admin', '[admin]admin', '2016-03-26 16:34:54', '2016-03-26 16:34:54');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('0cbebe04-de89-4833-8594-c0ccec960327', 'SystemModule', 'ϵͳģ��', '1', null, null, null, '2015-12-30 10:52:23', '2015-12-17 12:12:01');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('1dfff039-921a-4bf6-a80e-fffaf959dd79', 'agreementCloseStatus', '��ͬ�ر�״̬', '1', null, '[admin]admin', '[admin]admin', '2016-03-09 15:43:24', '2016-03-09 15:43:24');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('228a6d33-1ba8-41b7-b6be-fbb447c8150b', 'riskAssessment', '��������', '1', '��������', '[admin]admin', '[admin]admin', '2016-01-12 17:03:24', '2016-01-12 17:03:24');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('2a77675b-d079-4b93-9976-382a856a905e', 'accessEvaluateConfigurationStatus', '��Ӧ��׼������״̬', '1', '��Ӧ��׼������״̬', '[admin]admin', '[admin]admin', '2016-02-03 15:44:55', '2016-01-21 18:59:21');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('2e9be425-3542-4d13-aa79-922864ceeeb2', 'performanceEvaluateConfigurationStatus', '�����Ա����״̬', '1', '�����Ա����״̬', '[admin]admin', '[admin]admin', '2016-03-22 16:02:38', '2016-03-22 16:02:38');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('381990ef-9c83-46f5-ad4a-1c622330171f', 'lowvalueType', '��ֵ�׺�Ʒ���롢��������', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:02:15', '2016-03-23 12:02:52');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('4cdf319d-e930-46b3-aaf9-b6dd4586cace', 'performance', '��Ч', '1', '��Ч', '[admin]admin', '[admin]admin', '2016-01-12 17:00:18', '2016-01-12 17:00:18');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('52df19ac-0a0a-4c3c-ae2d-0b95941eb0d6', 'resourceType', '��Դ����', '1', null, null, null, '2015-12-21 14:23:10', '2015-12-21 14:23:10');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('62159b1a-db61-4f53-a012-fcc9f00a7cd6', 'assetApplicationStatus', '�ʲ�����״̬', '1', '�ʲ�����״̬', '[FB0001]��ԣ��', '[FB0001]��ԣ��', '2016-03-24 17:38:45', '2016-03-24 17:38:45');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('63f27bec-27d0-4bd2-ac46-cc904d19f6b8', 'riskState', '���ո���״̬', '1', null, '[admin]admin', '[admin]admin', '2016-02-01 15:58:37', '2016-02-01 15:58:37');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('6ded796a-2a74-4e83-96c4-e748c87c4453', 'supplierQuitStatus', '��Ӧ���˳�״̬', '1', null, '[admin]admin', '[admin]admin', '2016-03-09 17:19:53', '2016-03-09 17:19:53');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('717d8a00-0dbd-4991-a476-84fc58e6bd29', 'assetRetirementStatus', '�ʲ�����״̬', '1', null, '[101]������1', '[101]������1', '2016-03-28 16:41:00', '2016-03-28 16:41:00');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('730ae0ee-2b0d-4428-8f02-332fa305a7f1', 'assetRepairStatus', '�ʲ�ά��״̬', '1', null, '[admin]admin', '[admin]admin', '2016-03-27 15:07:15', '2016-03-27 15:07:15');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('744db36e-99ef-46c3-bb38-3a61e32e4078', 'lowvalueApplyStatus', '��ֵ�׺�Ʒ����״̬', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:10:04', '2016-03-23 12:10:04');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('7562f732-1188-4f81-a96c-fbb5086e7d86', 'purchaseStatus', '�ɹ�����״̬', '1', null, '[admin]admin', '[admin]admin', '2016-01-25 10:06:26', '2016-01-25 10:06:26');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('7d805453-18db-4978-b6d1-39abb41b692f', 'faultStatus', '����״̬', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 11:59:38', '2016-03-23 11:59:38');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('843b9599-634f-4a99-aaab-cc8693a068bd', 'assetsInventoryStatus', '�ʲ��̵�״̬', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 10:52:07', '2016-03-23 10:45:01');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('894adb90-51be-4cab-8654-21d7bd5316b1', 'serviceMonitoringStatus', '������״̬', '1', '������״̬', '[admin]admin', '[admin]admin', '2016-03-03 10:42:46', '2016-03-03 10:42:46');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('899352c4-7302-40e8-9821-0ae3640ee533', 'inventoryConfirmStatus', '�ʲ��̵�ȷ��״̬', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 10:52:17', '2016-03-23 10:48:36');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('8ffed177-52a5-4a3b-9371-179623904292', 'safetyCheck', '��ȫ���', '1', '��ȫ���', '[admin]admin', '[admin]admin', '2016-01-12 17:02:10', '2016-01-12 17:02:10');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('93062185-6f1f-4879-bd82-6b335f5a4c1b', 'accessEvaluateStatus', '׼������״̬', '1', '׼������', '[admin]admin', '[admin]admin', '2016-01-21 18:56:03', '2016-01-21 18:56:03');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('99faf0b8-b1c6-42e7-a784-b2a34da878c9', 'lowvalueApplyDetailStatus', '��ֵ�׺�Ʒ������Ʒ״̬', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:15:42', '2016-03-23 12:15:42');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('9baab822-1142-40de-82d5-65d46fe7b803', 'roleType', '��ɫ����', '1', null, null, null, '2015-12-17 18:23:49', '2015-12-17 18:23:49');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('a22d3a99-a6c1-4956-9b72-cafaa6a31eea', 'projectRiskStatus', '��Ŀ����״̬', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 11:55:44', '2016-03-23 11:55:44');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('a9abe36c-7d52-46ac-912e-94bdccf4beb3', 'userType', '�û�����', '1', '', null, null, '2015-12-30 10:08:44', '2015-12-30 10:08:44');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('ae3521a1-8498-499c-97bf-c9bfcb02759a', 'performanceEvaluatorType', '���˶������', '1', '���˶������', '[admin]admin', '[admin]admin', '2016-03-16 15:38:55', '2016-03-16 15:38:55');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('b004bf0a-4dec-4152-bf5e-6618893a9ccd', 'workflowType', '��������', '1', '��������', '[admin]admin', '[admin]admin', '2016-02-01 17:24:06', '2016-02-01 17:24:06');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('b5b6479a-8d88-4ca3-92da-072a25503ee6', 'borrowStatus', '�ʲ�����״̬', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:17:36', '2016-03-23 12:17:36');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('b9cf65c7-a6f9-4a40-97dc-be154b4e6508', 'performanceEvaluateStatus', '�����Ա���̿���״̬', '1', '�����Ա���̿���״̬', '[admin]admin', '[admin]admin', '2016-03-22 16:02:33', '2016-03-22 15:56:39');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('be68fd9e-711d-46a3-8e56-e955174ea0a9', 'lowvalueReceptionStatus', '��ֵ�׺�Ʒ����״̬', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:05:13', '2016-03-23 12:05:13');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('c22d9588-77ea-4f6f-80dd-8c16afaa8285', 'patrolObjectType', 'Ѳ�쵥λ���', '1', 'Ѳ�쵥λ���', '[admin]admin', '[admin]admin', '2016-03-07 15:51:06', '2016-03-07 15:51:06');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('c6c34f9a-942d-4d62-abdf-24686b8e6a4a', 'agreementPayStatus', '��ͬ����״̬', '1', '��ͬ����ͳ��', '[admin]admin', '[admin]admin', '2016-03-22 11:42:55', '2016-03-22 11:42:55');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('c9bd830e-5920-45d9-87b1-678ff86c7f01', 'formOperationType', 'ҳ�������б���������', '1', 'ҳ�������б��������ͣ����������û��ڵ�ǰҳ���Ƿ��������������޸ġ����߲鿴���������', null, null, '2016-01-06 11:11:26', '2016-01-06 11:11:26');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('ca227466-8d9d-40e1-80b0-348e180e907b', 'agreementEvaluateConfigurationStatus', '��ͬ����״̬', '1', '��ͬ����״̬', '[admin]admin', '[admin]admin', '2016-03-26 16:30:50', '2016-03-26 16:30:50');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('cdf8b2f3-381c-4da8-9799-a127915c8775', 'deductionsCycle', '�۷�����', '1', '�۷�����', '[admin]admin', '[admin]admin', '2016-02-27 11:36:54', '2016-02-27 11:36:54');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('cdfe09a1-6454-456b-9f7c-ca75c5bc727e', 'borrowDetailStatus', '�����ʲ���ϸ״̬', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:23:06', '2016-03-23 12:23:24');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('ce89fe85-b3d4-4ab7-9383-05ef227534b7', 'LogOpType', '��־��������', '1', null, null, null, '2015-12-29 12:16:16', '2015-12-21 19:33:43');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('d7f01dcd-218e-48d0-a9e8-cef390e8c372', 'agreementChangeStatus', '��ͬ���״̬', '1', null, '[admin]admin', '[admin]admin', '2016-03-08 15:01:26', '2016-03-08 15:01:26');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('e4bf1f28-8b5a-49bd-98c5-5ebe4441a541', 'groupPost', '���ڸ�λ', '1', null, '[admin]admin', '[admin]admin', '2016-01-27 10:40:50', '2016-01-27 10:37:22');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('eb7f30c8-f84d-4185-a364-11075aad4235', 'supplierPerformanceEvaluatorType', '��Ӧ�̿��˶������', '1', '��Ӧ�̿��˶������', '[admin]admin', '[admin]admin', '2016-03-23 12:20:58', '2016-03-23 12:20:58');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('fa2df8c1-0433-413a-9f52-1c05fc0e66b5', 'triggerState', '������״̬', '1', '��ʱ���񴥷���״̬', null, null, '2015-12-22 10:11:08', '2015-12-22 10:11:08');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('fd7bb0da-93fa-401e-b610-ae93d25e0240', 'assetsWarnConfigCycle', '�ʲ���ͬ������������', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:20:29', '2016-03-23 12:20:29');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('83a0bc64-bec4-4320-a553-868921d7f1b4', 'faultIssueType', '�����·����', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:20:29', '2016-03-23 12:20:29');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('f75fc4b5-dfb7-43f4-8230-d20b2f7e4150', 'faultHandleConfirm', '�����Ƿ���', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:20:29', '2016-03-23 12:20:29');



-- ----------------------------
-- ҵ���������(sys_param_type)
-- ---------------------------- 
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('0225b7b0-98d2-4e0e-ae92-7ca0d399331b', 'agreementCloseReason', '��ͬ�ر�ԭ��', '2', null, '[admin]admin', '[admin]admin', '2016-03-09 16:28:32', '2016-03-09 16:28:32');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('0320b57d-4799-4daa-8c70-f36a26e2c897', 'performanceResult', '��Ա��Ч���˽��', '2', '��Ա��Ч���˽��', '[admin]admin', '[admin]admin', '2016-03-22 15:44:56', '2016-03-22 15:44:56');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('05fc6690-07c6-4974-a98a-5a6ada3be6b9', 'securityCheckEvaluateResult', '��ȫ����������', '2', '��ȫ����������', '[admin]admin', '[admin]admin', '2016-03-24 16:22:19', '2016-03-24 16:22:19');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('0a69d3e9-0a0d-44b2-995a-cd0fa9a0ec21', 'assetsAgreementType', '�ʲ���ͬ��ͬ����', '2', null, '[admin]admin', '[admin]admin', '2016-03-23 12:18:29', '2016-03-23 12:18:29');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('0e6d4cb3-d08f-4f59-9a42-a355fb8eb13e', 'purchaseType', '�ɹ���������', '2', null, '[admin]admin', '[admin]admin', '2016-01-23 16:38:37', '2016-01-23 16:38:37');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('148007c5-1f7c-4818-a885-6d5a50f1f362', 'agreementEvaluateResult', '��ͬ�������', '2', '��ͬ�������', '[admin]admin', '[admin]admin', '2016-03-15 19:50:17', '2016-03-15 19:50:17');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('1a64472a-88ad-480f-9a0f-557afbd15481', 'secureTrainType', '��ȫ��ѵ����', '2', '��ȫ��ѵ����', '[admin]admin', '[admin]admin', '2016-03-15 11:03:36', '2016-03-15 11:03:36');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('1d78a196-0e3d-4142-a8d7-40e5bebdfac7', 'agreementTeamRole', '�����Ŷӽ�ɫ', '2', '��Ӧ�̷����Ŷӽ�ɫ', '[admin]admin', '[admin]admin', '2016-02-27 11:18:25', '2016-02-27 11:18:25');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('1e0d6a36-2cb7-4490-b79f-8771c70352c7', 'outsourceType', '�������', '2', null, '[admin]admin', '[admin]admin', '2016-01-21 12:01:00', '2016-01-21 12:01:00');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('23b704b7-057d-48f0-8988-fb0fa1efa2b8', 'projectCategory', '��Ŀ���', '2', null, '[admin]admin', '[admin]admin', '2016-02-22 09:33:46', '2016-02-22 09:33:46');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('2a98c4ba-3cd4-4675-ae00-9adf5a508460', 'supplierType', '��Ӧ�����', '2', null, null, null, '2016-01-05 15:06:48', '2016-01-05 15:06:48');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('2fbafa08-cfe2-4df6-b8fb-f3fe60527e3a', 'companyNature', '��˾����', '2', null, '[admin]admin', '[admin]admin', '2016-01-12 20:19:42', '2016-01-12 20:19:42');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('367abc73-8f7c-4296-be46-e9e44ce0b1b5', 'supplierBlackReason', '��Ӧ�̺�����ԭ��', '2', null, '[admin]admin', '[admin]admin', '2016-03-30 10:11:01', '2016-03-30 10:11:01');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('3c14ded4-35c8-4b55-b3cc-c8a95a6b7ea6', 'patrolManner', 'Ѳ�췽ʽ', '2', 'Ѳ�췽ʽ', '[admin]admin', '[admin]admin', '2016-03-07 15:07:39', '2016-03-07 15:07:39');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('3cdd54c7-be8b-4a53-ab5b-0809ed808256', 'agreementCategory', '��ͬ���', '2', null, '[admin]admin', '[admin]admin', '2016-01-23 16:40:26', '2016-01-23 16:40:26');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('3d7a9832-dcad-4d7a-b6a4-e0066c3fcae1', 'riskLevel', '���ռ���', '2', null, '[admin]admin', '[admin]admin', '2016-01-12 17:14:28', '2016-01-12 17:14:28');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('3d8c0b50-b17c-4d4e-95c5-8946b5445465', 'templateConfigurationType', 'ģ������', '2', 'ģ����������', '[admin]admin', '[admin]admin', '2016-01-12 16:34:02', '2016-01-12 16:34:02');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('40291d63-251f-4ed4-84ed-0ea89092258f', 'projectRiskCategory', '��Ŀ�������', '2', null, '[admin]admin', '[admin]admin', '2016-02-23 11:50:07', '2016-02-23 11:50:07');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('46608e67-aa39-49e1-a1ba-f679339a738d', 'nationType', '��������', '2', null, null, null, '2015-12-30 11:32:46', '2015-12-30 11:32:19');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('46d4c8d1-f2fe-4d19-bf61-2be58cf54129', 'belongIndustries', '������ҵ', '2', null, '[admin]admin', '[admin]admin', '2016-01-13 11:40:21', '2016-01-13 09:14:05');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('48b9b425-9a5b-40c7-b27e-12468e35c2b0', 'supplierPerformanceResult', '��Ӧ�̼�Ч���˽��', '2', '��Ӧ�̼�Ч���˽��', '[admin]admin', '[admin]admin', '2016-03-23 12:23:53', '2016-03-23 12:23:53');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('4d035348-1191-4ec7-bd17-3a6bf7369d48', 'supplierQuitReason', '�˳�ԭ��', '2', null, '[admin]admin', '[admin]admin', '2016-02-26 16:17:10', '2016-02-26 16:17:10');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('4ffd6b94-ebfe-4291-bacd-2a0c274d2829', 'duediligenceEvaluateResult', '��ְ�����������', '2', '��ְ�����������', '[admin]admin', '[admin]admin', '2016-03-24 16:07:47', '2016-03-24 16:07:47');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('50245782-83c6-429c-b43a-06ca326fa574', 'purchaseCategory', '�ɹ����', '2', '1', '[admin]admin', '[admin]admin', '2016-01-26 15:55:42', '2016-01-23 16:39:27');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('59fabc2d-b718-4454-9a8c-276a5ea2a3a5', 'externalManagerEvaluateResult', '��פ������������', '2', '��פ������������', '[admin]admin', '[admin]admin', '2016-03-24 16:29:50', '2016-03-24 16:29:50');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('5d117a65-a69a-4b3e-984b-3a41a5fe8f55', 'faultImpact', '����Ӱ�췶Χ', '2', null, '[admin]admin', '[admin]admin', '2016-02-27 14:42:58', '2016-02-27 14:42:58');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('628acc50-6bea-4096-9e28-14c67393f17d', 'messageModel', '֪ͨ��ʽ', '2', null, '[admin]admin', '[admin]admin', '2016-03-30 19:50:39', '2016-03-30 19:50:39');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('66eb7e39-5d5f-4a48-95b2-e76e3677722d', 'serviceMonitoringType', '���������', '2', '���������', '[admin]admin', '[admin]admin', '2016-03-03 10:41:29', '2016-03-03 10:41:29');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('68af5e64-00bb-496c-aa69-676c9a37d0dc', 'projectRiskLevel', '��Ŀ���յȼ�', '2', null, '[admin]admin', '[admin]admin', '2016-02-23 11:50:26', '2016-02-23 11:50:26');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('6b79bb65-8f46-4934-9427-8e05253bc291', 'impactScope', 'Ӱ�췶Χ', '2', 'Ӱ�췶Χ', '[admin]admin', '[admin]admin', '2016-03-15 11:05:12', '2016-03-15 11:05:12');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('7bd6802f-0c7a-4252-b9e0-1ee57c0e1377', 'agreementEvaluate', '��ͬ����', '2', '��ͬ����', '[admin]admin', '[admin]admin', '2016-03-15 19:46:39', '2016-03-15 19:46:39');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('7d1bd4f3-a1b5-4e83-9495-732cf13470b3', 'YesNo', '�Ƿ�', '2', null, null, null, '2015-12-29 11:47:26', '2015-12-21 09:22:28');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('7feecf2a-1dca-48de-88fd-d21f4c06834f', 'communicateType', '��ͨ���', '2', null, '[admin]admin', '[admin]admin', '2016-01-20 18:42:04', '2016-01-20 18:41:37');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('86303f2f-d44e-4031-973f-48a94e6f6940', 'softwareCategory', '�������', '2', null, '[admin]admin', '[admin]admin', '2016-03-17 14:50:31', '2016-03-17 14:48:53');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('8878615c-d4d0-420a-bf97-b3db2269109f', 'faultUrgent', '���Ͻ����̶�', '2', null, '[admin]admin', '[admin]admin', '2016-02-27 14:42:35', '2016-02-27 14:42:35');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('8ef8d08f-b793-451a-9599-80a86e7b81f7', 'specialAudit', 'ר����������', '2', 'ר����������', '[admin]admin', '[admin]admin', '2016-02-24 11:21:14', '2016-02-24 10:45:43');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('9052a8a5-1142-4fa0-a25e-b88de9d75852', 'faultHandleResult', '���ϴ������', '2', null, '[admin]admin', '[admin]admin', '2016-02-29 12:16:50', '2016-02-29 12:17:34');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('9137c602-9e84-4f0c-9f3f-a850e9c705f5', 'supplierRelation', '��Ӧ�̹�����ϵ', '2', null, '[admin]admin', '[admin]admin', '2016-01-12 18:56:44', '2016-01-12 18:56:44');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('9af0e227-da6c-4568-96eb-6122cd943102', 'trainType', '��ѵ���', '2', null, '[admin]admin', '[admin]admin', '2016-01-20 10:05:22', '2016-01-20 10:05:22');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('9bcefdfa-d486-4f4c-b531-8f4007c1aef5', 'communType', '��ͨ��ʽ', '2', null, null, null, '2016-01-11 15:33:52', '2016-01-11 15:33:52');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('9d44124a-6120-4256-b9c1-04417d8a180e', 'projectGrade', '��Ŀ����', '2', null, '[admin]admin', '[admin]admin', '2016-02-22 09:44:10', '2016-02-22 09:44:10');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('a21dfc6b-cf8d-4998-81d7-5f3dd8e2460c', 'riskOverallEvaluateResult', 'ȫ������������', '2', 'ȫ������������', '[admin]admin', '[admin]admin', '2016-03-24 15:38:23', '2016-03-24 15:38:23');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('a3226649-e64f-41be-8801-06e12b352ba6', 'patrolEvaluateResult', 'Ѳ���������', '2', 'Ѳ���������', '[admin]admin', '[admin]admin', '2016-03-24 15:04:39', '2016-03-24 15:04:39');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('ad50214a-662c-4b34-9019-9cbc90905d2c', 'accessEvaluateResult', '׼���������', '2', null, null, null, '2016-02-22 11:54:59', '2016-02-22 11:55:45');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('ae784bc7-60bc-41e0-9192-b69dde5854a7', 'agreementChangeType', '��ͬ�������', '2', null, '[admin]admin', '[admin]admin', '2016-03-08 15:02:53', '2016-03-08 15:02:53');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('bf0c0f05-79b3-4678-a70f-6dd00ec69ad5', 'agreementRelation', '��ͬ������ϵ', '2', null, '[admin]admin', '[admin]admin', '2016-02-24 20:25:16', '2016-02-24 20:25:16');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('c1371cc1-26fb-4690-b1c7-ffa9831bfae4', 'faultType', '��������', '2', null, '[admin]admin', '[admin]admin', '2016-02-27 14:41:53', '2016-02-27 14:41:53');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('ccaed11f-4bc3-44e4-899d-751d469318de', 'serviceMonitoringEvaluateResult', '�������������', '2', '�������������', '[admin]admin', '[admin]admin', '2016-03-24 16:16:03', '2016-03-24 16:16:03');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('cf3de349-2840-4cdb-95ce-0e548da0e4fc', 'agreementStakeholdersRole', '��ͬ��ϵ�˽�ɫ', '2', null, '[admin]admin', '[admin]admin', '2016-02-27 12:43:22', '2016-02-27 12:43:22');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('cf414474-e512-4938-bc4a-61d87b239fa9', 'riskType', '�������', '2', null, '[admin]admin', '[admin]admin', '2016-01-12 17:12:40', '2016-01-12 17:12:40');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('d3a87103-4e16-478a-b6d8-0ef4a98ba804', 'supplierLevel', '��Ӧ�̼���', '2', null, null, null, '2016-01-05 15:09:48', '2016-01-05 15:09:48');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('d3e9629a-cf71-474c-be41-b7a8c678e91d', 'auditCategory', '������', '2', '������', '[admin]admin', '[admin]admin', '2016-02-24 10:08:28', '2016-02-24 10:08:28');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('dc548519-5956-4ac2-b392-7104d97a4b34', 'severity', '���س̶�', '2', '���س̶�', '[admin]admin', '[admin]admin', '2016-03-15 11:07:03', '2016-03-15 11:07:03');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('e101daa6-b81c-4540-b291-9d2b299e98d4', 'lowvalueCategory', '��ֵ�׺�Ʒ���', '2', null, '[admin]admin', '[admin]admin', '2016-03-04 15:26:16', '2016-03-04 15:26:16');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('e2e83f2f-c6a3-4e08-a8ec-77a27e746381', 'riskImportantEvaluateResult', '��Ҫ����̷����������', '2', '��Ҫ����̷����������', '[admin]admin', '[admin]admin', '2016-03-24 15:48:46', '2016-03-24 15:48:46');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('e3bbf9e6-6957-46db-8d2f-f05a4f706bad', 'faultHandleAssess', '���ϴ����������', '2', null, '[admin]admin', '[admin]admin', '2016-02-29 12:18:17', '2016-02-29 12:18:17');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('e514cabf-5052-4a64-aec0-287560d8b9c7', 'staffSize', '��Ӧ����Ա��ģ', '2', null, '[admin]admin', '[admin]admin', '2016-01-13 09:16:16', '2016-01-13 09:16:16');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('e59fabed-71e4-42b5-843e-cb1e14199134', 'patrolType', 'Ѳ������', '2', 'Ѳ������', '[admin]admin', '[admin]admin', '2016-03-07 15:06:02', '2016-03-03 12:01:58');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('f83f1fcb-df73-4b00-928f-551076b73d32', 'exam', '����', '2', '����', '[admin]admin', '[admin]admin', '2016-01-12 16:56:51', '2016-01-12 16:56:51');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('f85a04c5-c8f4-4a7c-8c3d-eadc8d85cbda', 'projectRole', '��Ŀ��ɫ', '2', null, '[admin]admin', '[admin]admin', '2016-02-22 17:42:19', '2016-02-22 17:42:19');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('fad25ef7-bd67-4136-9e3c-e87f1cd72270', 'riskAuditEvaluateResult', '�������������', '2', '�������������', '[admin]admin', '[admin]admin', '2016-03-24 15:55:58', '2016-03-24 15:55:58');
INSERT INTO `sys_param_type`(`id`,`code`,`name`,`type`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('ff87cfd4-b14c-4b71-82b8-7f6d44a1b212', 'projectPerformanceResult', '��Ŀ��Ч���˽��', '2', '��Ŀ��Ч���˽��', '[admin]admin', '[admin]admin', '2016-03-23 20:02:50', '2016-03-23 20:02:50');



-- ----------------------------
-- ϵͳ����(sys_param)
-- ---------------------------- 
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('01e20396-b7b2-47ad-b157-0c85f739d0eb', '�ر�', 'GB', 'riskState', '2', null, '[admin]admin', '[admin]admin', '2016-02-01 16:00:02', '2016-02-01 16:00:02');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('03abd11f-a863-4423-b677-b8a513547e2a', '������־', 'option', 'LogType', '1', null, null, null, '2015-12-30 12:30:33', '2015-12-30 12:23:59');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('0426584f-0adf-4c55-baaf-f4e60892ea51', '�����۴��ر�', '1', 'agreementEvaluateConfigurationStatus', '2', '�����۴��ر�', '[admin]admin', '[admin]admin', '2016-03-26 16:31:39', '2016-03-26 16:31:39');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('0500565e-9d1c-4da4-8dc5-2a6c85b3307b', 'ÿ��', '1', 'assetsWarnConfigCycle', null, null, '[admin]admin', '[admin]admin', '2016-03-23 12:20:42', '2016-03-23 12:20:42');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('09332587-99ea-4f55-a60b-2832543e90b3', '����', '1', 'lowvalueType', null, null, '[admin]admin', '[admin]admin', '2016-03-23 12:03:27', '2016-03-23 12:03:27');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('0a57401d-5349-4ac5-876d-a2093146d4f1', '�����С���ʱ�������ͬ�ѵ��ڣ�����ͬ��δ�ύ�ر����롿', '4', 'agreementStatus', '4', null, '[admin]admin', '[admin]admin', '2016-01-25 11:08:22', '2016-01-25 11:08:22');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('0b05ec04-71b1-4f14-a151-4b8cc3e26c18', '����Ԫ��', '2', 'resourceType', '2', null, null, null, '2015-12-21 14:23:49', '2015-12-21 14:23:49');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('0cb5c59e-99dc-49ea-9ef7-d7d485e5273f', 'δȷ��', '0', 'lowvalueReceptionDetailConfirmStatus', null, null, '[admin]admin', '[admin]admin', '2016-03-23 12:08:42', '2016-03-23 12:08:42');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('0cbe4f71-3a9e-43db-8b5c-52fcfec5a14f', '����', '4', 'triggerState', '5', '����', null, null, '2015-12-22 10:13:09', '2015-12-22 10:13:09');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('0f50415d-77e0-4451-aedc-79edd432c8e1', '��Ӧ�̹���', 'supplier', 'SystemModule', '2', null, '[admin]admin', '[admin]admin', '2016-02-15 16:48:09', '2016-02-15 16:48:09');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('11770dfb-54d6-45b2-8ecf-676987e4c085', '�볡', '1', 'recordType', '1', null, '[admin]admin', '[admin]admin', '2016-02-23 17:31:59', '2016-02-23 17:31:59');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('11782047-8bf0-4754-8bdf-221000925a69', '������', '2', 'borrowStatus', null, null, '[admin]admin', '[admin]admin', '2016-03-23 12:19:47', '2016-03-23 12:19:47');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('11a86773-6342-41cd-a082-98302d9718d3', '������', '2', 'lowvalueApplyStatus', '2', null, '[admin]admin', '[admin]admin', '2016-03-23 12:12:23', '2016-03-23 12:11:15');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('14307b00-b6ac-4fb6-83f7-f9c13f152cf9', '����ִͬ��', '4', 'purchaseStatus', '4', null, '[admin]admin', '[admin]admin', '2016-03-01 10:08:54', '2016-01-25 11:01:50');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('15889c87-d7f6-4f7e-a5fc-88310dc6c2e2', '��ȷ��', '5', 'assetApplicationStatus', '5', null, '[admin]admin', '[admin]admin', '2016-03-26 16:31:45', '2016-03-26 15:03:06');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('1702ddce-5b17-41f4-8017-990cb83ee750', '���ύ', '0', 'lowvalueApplyStatus', '0', null, '[admin]admin', '[admin]admin', '2016-03-23 12:12:32', '2016-03-23 12:10:41');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('1804be75-2c0f-4edf-a3de-9f7d3510deac', '������', '1', 'assetApplicationStatus', '1', null, '[FB0001]��ԣ��', '[admin]admin', '2016-03-26 16:30:37', '2016-03-24 17:39:54');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('18671ec9-50e8-429a-8eae-256a7445b83f', '���б�', '1', 'purchaseStatus', '1', null, '[admin]admin', '[admin]admin', '2016-03-01 10:08:20', '2016-01-25 11:01:23');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('19220911-d3cd-4af3-a060-30ccee9bb818', '��¼��־', 'login', 'LogType', '2', null, null, null, '2015-12-30 12:30:33', '2015-12-30 12:24:16');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('1a6c6f37-b60a-4340-9f3e-01c53f64f567', '������-ר�����', 'specialAudit', 'riskAssessment', '3', '������-ר�����', '[admin]admin', '[admin]admin', '2016-02-24 11:41:02', '2016-01-12 17:05:44');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('1cb441fe-432e-4f04-8b6a-3c1665262e38', '��ȷ��', '5', 'lowvalueApplyStatus', '5', null, '[admin]admin', '[admin]admin', '2016-03-23 12:13:01', '2016-03-23 12:12:03');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('1e04ca1d-b051-431c-8c65-a9008d633044', '��ȷ����Ӧ��', '2', 'purchaseStatus', '2', null, '[admin]admin', '[admin]admin', '2016-03-01 10:08:31', '2016-01-25 11:01:31');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('203d3270-167f-4dc9-8fef-326bad44b382', '��ȷ��', '2', 'lowvalueReceptionStatus', null, null, '[admin]admin', '[admin]admin', '2016-03-23 12:06:45', '2016-03-23 12:06:45');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('20440b2d-27b6-454f-b8f9-16dded3fd3f8', '��ȷ��', '3', 'borrowDetailStatus', null, null, '[admin]admin', '[admin]admin', '2016-03-23 12:23:42', '2016-03-23 12:24:25');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('222c1efb-63b1-4b0e-b7ee-7aeef450b87a', '������', '1', 'lowvalueApplyDetailStatus', null, null, '[admin]admin', '[admin]admin', '2016-03-23 12:16:31', '2016-03-23 12:16:31');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('2243fdfb-1149-4b10-b38f-33556f32c881', '������', '2', 'assetApplicationStatus', '2', null, '[FB0001]��ԣ��', '[admin]admin', '2016-03-26 16:30:51', '2016-03-24 17:40:04');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('25651895-0a89-400d-a1c1-5dfe1ef32e5a', '��ͣ', '1', 'serviceMonitoringStatus', '2', '����', '[admin]admin', '[admin]admin', '2016-03-03 11:26:58', '2016-03-03 10:43:22');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('25b7acd3-9baa-49c7-ae2b-0681c8a1aa11', '�ص㹩Ӧ�̷�������', 'riskAssessmentIsTheKeySuppliers', 'riskAssessment', '2', '�ص㹩Ӧ�̷�������', '[admin]admin', '[admin]admin', '2016-01-12 17:04:37', '2016-01-12 17:04:37');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('25bc12ed-cf6e-485a-970e-0ba9a48d8e22', '����', '1', 'supplierPerformanceEvaluatorType', '1', '����', '[admin]admin', '[admin]admin', '2016-03-23 12:21:21', '2016-03-23 12:21:21');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('262df87c-3451-4dc4-8204-a70e7a86fc06', '�޸�', 'update', 'LogOpType', '2', null, null, null, '2015-12-29 12:16:50', '2015-12-29 12:16:50');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('298b489f-3808-4bdc-b0e0-e04ed7daa8fa', '������', '3', 'lowvalueApplyStatus', '3', null, '[admin]admin', '[admin]admin', '2016-03-23 12:12:16', '2016-03-23 12:11:34');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('2bb7c226-71f9-4e48-a892-3b2e35c9bc02', '�����', '3', 'supplierQuitStatus', '3', null, '[admin]admin', '[admin]admin', '2016-03-21 15:12:43', '2016-03-21 15:12:43');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('2e954d74-feb1-42d7-be80-c2e1973aa33d', '������', '1', 'assetRepairStatus', '1', null, '[admin]admin', '[admin]admin', '2016-03-27 15:09:55', '2016-03-27 15:09:55');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('2ec11921-69ec-476a-9bb1-d54a81356860', '���', '4', 'faultStatus', '4', null, '[admin]admin', '[admin]admin', '2016-03-23 12:00:49', '2016-03-23 12:00:49');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('30ee43c8-289c-4849-86ad-42bd0c01f064', '����', '-1', 'lowvalueApplyStatus', '0', null, '[admin]admin', '[admin]admin', '2016-03-23 12:12:45', '2016-03-23 12:10:27');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('311949af-297f-46e9-8a38-c31cf054d20f', '���������ر�', '1', 'accessEvaluateConfigurationStatus', '2', '���������ر�', '[admin]admin', '[admin]admin', '2016-02-03 16:46:38', '2016-01-21 19:00:02');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('31a24398-ee2c-401e-ad1a-6bf984cf61c7', '��λ����֯��ɫ��', '2', 'roleType', null, null, null, null, '2015-12-17 18:24:33', '2015-12-17 18:24:33');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('320d7916-6206-4340-a857-9d66ef75220e', '����', '4', 'agreementChangeStatus', '4', null, '[admin]admin', '[admin]admin', '2016-03-28 14:40:43', '2016-03-08 15:02:19');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('33ec671e-17d9-4382-ae8e-4aa703705fbb', '��ȷ��', '4', 'borrowDetailStatus', null, null, '[admin]admin', '[admin]admin', '2016-03-23 12:24:58', '2016-03-23 12:24:58');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('35cfd084-08bf-48a1-b1fc-bc5062e5650a', '�ѹر�', '2', 'agreementEvaluateConfigurationStatus', '3', '�ѹر�', '[admin]admin', '[admin]admin', '2016-03-26 16:31:56', '2016-03-26 16:31:56');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('3655b912-b5f0-42b5-bb26-cd79af283018', 'ȷ����', '2', 'assetsInventoryStatus', null, null, '[admin]admin', '[admin]admin', '2016-03-23 10:52:07', '2016-03-23 10:46:20');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('375bbfb7-0440-4eb4-8906-9aed8ae5a823', '����', '-1', 'lowvalueReceptionDetailConfirmStatus', null, null, '[admin]admin', '[admin]admin', '2016-03-23 12:08:30', '2016-03-23 12:08:30');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('38c22b5c-2835-4c1d-8b74-a28aa184c390', '������', 'selfAssessment', 'safetyCheck', '1', '������', '[admin]admin', '[admin]admin', '2016-01-12 17:02:44', '2016-01-12 17:02:44');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('38d0c4aa-e1ba-48c9-9b0e-fc09ab7a417c', '������', '0', 'agreementEvaluateStatus', '2', '������', '[admin]admin', '[admin]admin', '2016-03-26 16:35:46', '2016-03-26 16:35:46');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('3a6448a4-57e4-4b63-b1ad-374908d1f1d9', '������', '1', 'lowvalueApplyStatus', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:13:06', '2016-03-23 12:10:56');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('3b429287-dd2a-4062-a09a-614e377b796d', '��������', '1', 'projectRiskStatus', null, null, '[admin]admin', '[admin]admin', '2016-03-23 11:56:15', '2016-03-23 11:56:15');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('3d4202e3-6d8c-4ccf-a5e5-8f62079c16ce', '������', '1', 'agreementEvaluateStatus', '1', '������', '[admin]admin', '[admin]admin', '2016-03-26 16:35:33', '2016-03-26 16:35:33');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('3dbfcb30-b4bb-498a-aba6-0a26e3b10c14', '������', '5', 'agreementCloseStatus', '5', null, '[admin]admin', '[admin]admin', '2016-03-09 15:44:40', '2016-03-09 15:44:40');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('3e757fe2-29d3-456c-af75-5d936c03c97e', '����', '3', 'inventoryConfirmStatus', null, null, '[admin]admin', '[admin]admin', '2016-03-23 10:53:50', '2016-03-23 10:53:50');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('404da963-1d97-47e9-a618-78f8cb5ac154', '���ύ', '0', 'assetRepairStatus', '0', null, '[admin]admin', '[admin]admin', '2016-03-27 15:09:39', '2016-03-27 15:09:39');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('44e4ba63-e1b0-4137-92b1-24b4590681ae', 'δȷ��', '0', 'lowvalueReceptionStatus', null, null, '[admin]admin', '[admin]admin', '2016-03-23 12:05:25', '2016-03-23 12:05:25');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('4728aac4-d150-4789-ae0c-348b5da6d3d8', '����', '0', 'serviceMonitoringStatus', '1', '����', '[admin]admin', '[admin]admin', '2016-03-03 10:43:03', '2016-03-03 10:43:03');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('473a19a5-290a-489d-af6d-7050359d934a', 'ȷ����', '6', 'lowvalueApplyStatus', '6', null, '[admin]admin', '[admin]admin', '2016-03-23 12:12:52', '2016-03-23 12:12:23');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('476d900f-bc7f-4f50-bdd2-c21bf7f8e436', '������', '2', 'agreementPayStatus', '2', null, '[admin]admin', '[admin]admin', '2016-03-22 11:43:34', '2016-03-22 11:43:34');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('48591910-0d71-45a8-b27d-fd7c7ca92230', '������', '3', 'assetApplicationStatus', '3', null, '[FB0001]��ԣ��', '[admin]admin', '2016-03-26 16:31:05', '2016-03-24 17:40:14');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('49c374a0-083d-40c4-96bf-ab8dc474eefb', '��Ӧ����Ա', '2', 'userType', '2', null, null, '[admin]admin', '2016-03-23 12:22:35', '2015-12-30 10:09:49');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('49f498fb-59c1-46c5-b145-f21b8d188096', '����', '2', 'lowvalueType', null, null, '[admin]admin', '[admin]admin', '2016-03-23 12:03:55', '2016-03-23 12:03:55');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('49fbefc6-9512-4aa8-a0cf-4eaef19553b0', '���ύ������', '2', 'agreementCloseStatus', '2', null, '[admin]admin', '[admin]admin', '2016-03-09 15:43:55', '2016-03-09 15:43:55');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('4a3c0fc7-451c-49ba-adc8-238b1bca35d0', 'ϵͳ', 'system', 'SystemModule', '1', null, null, '[admin]admin', '2016-02-15 16:25:11', '2015-12-19 16:17:42');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('4aa09c50-a4f6-4ba9-beec-3a6f3e534176', '�������', 'wbgl', 'workflowType', '2', null, '[admin]admin', '[admin]admin', '2016-02-01 17:26:23', '2016-02-01 17:26:23');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('4ac36948-0b39-4b6d-a8c1-46f6ad02b82b', '������', '2', 'assetRepairStatus', '2', null, '[admin]admin', '[admin]admin', '2016-03-27 15:10:12', '2016-03-27 15:10:12');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('4acf33c2-5d39-4dbc-84ea-b121cfeed1f7', '����', 'assessment', 'safetyCheck', '2', '����', '[admin]admin', '[admin]admin', '2016-01-12 17:03:00', '2016-01-12 17:03:00');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('4c09cbe5-6889-4ecb-8296-d7d105e41ef6', '��ȷ��', '3', 'faultStatus', '3', null, '[admin]admin', '[admin]admin', '2016-03-23 12:00:35', '2016-03-23 12:00:35');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('4c42ec3b-2c3e-40ca-9e49-583f04bcef34', '��ɫ', '2', 'supplierPerformanceEvaluatorType', '2', '��ɫ', '[admin]admin', '[admin]admin', '2016-03-23 12:21:37', '2016-03-23 12:21:37');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('4eea5f3d-8946-47ae-b5bc-ad365cb004bc', '�쳣��־', 'execption', 'LogType', '3', null, null, null, '2015-12-30 12:30:33', '2015-12-30 12:24:47');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('4f7701c4-3d20-43f8-aa1a-fcc341e9fdbe', '��Ӧ��', 'supplier', 'performance', '2', '��Ӧ��', '[admin]admin', '[admin]admin', '2016-01-12 17:01:07', '2016-01-12 17:01:07');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('4fa01996-2d3b-40bd-b568-905984c56910', 'ÿ����', '2', 'assetsWarnConfigCycle', null, null, '[admin]admin', '[admin]admin', '2016-03-23 12:20:53', '2016-03-23 12:20:53');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('51833159-84f3-473a-a39d-e172cda255a4', '���', '7', 'lowvalueApplyStatus', '7', null, '[admin]admin', '[admin]admin', '2016-03-23 12:12:09', '2016-03-23 12:12:41');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('537e9735-a70c-410f-89d1-7abfc4f5e39b', '���ύ', '1', 'agreementChangeStatus', '1', null, '[admin]admin', '[admin]admin', '2016-03-08 15:01:40', '2016-03-08 15:01:40');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('53da95e2-59ac-49be-9641-b7247f3a9867', 'һ��', '5', 'assetsWarnConfigCycle', null, null, '[admin]admin', '[admin]admin', '2016-03-23 12:21:31', '2016-03-23 12:21:31');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('54fb9392-eb4c-49a3-a379-edbc2d5e5ba9', '�ѹرա���ɺ�ͬ���ۡ���', '7', 'agreementStatus', '7', null, '[admin]admin', '[admin]admin', '2016-01-25 11:08:58', '2016-01-25 11:08:58');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('55e0661f-02aa-42f7-a9ea-49cf8dbbf52d', '������', '2', 'faultStatus', '2', null, '[admin]admin', '[admin]admin', '2016-03-23 12:00:22', '2016-03-23 12:00:22');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('56015002-7e12-4e13-829d-d813d736ca5e', '��ά�޴�ȷ��', '5', 'assetRepairStatus', '5', null, '[admin]admin', '[admin]admin', '2016-03-27 15:11:00', '2016-03-27 15:11:00');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('590daa1e-ffca-4af7-b1b5-f0a3dbf13730', '������', '2', 'deductionsCycle', '2', null, '[admin]admin', '[admin]admin', '2016-02-27 11:38:03', '2016-02-27 11:38:03');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('5e4c5943-35d1-4057-9e08-dda5c14e4625', '������', '4', 'assetApplicationStatus', '4', null, '[admin]admin', '[admin]admin', '2016-03-26 17:28:49', '2016-03-26 17:28:49');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('5f3c73e6-4bfa-409f-be15-923d8c583a6f', 'ÿ��', '4', 'assetsWarnConfigCycle', null, null, '[admin]admin', '[admin]admin', '2016-03-23 12:21:20', '2016-03-23 12:21:20');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('61a14cbd-0395-49b3-9011-cfd50051c80f', 'ȷ��', '2', 'inventoryConfirmStatus', null, null, '[admin]admin', '[admin]admin', '2016-03-23 10:53:43', '2016-03-23 10:53:43');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('623fe1b3-d101-4aa8-8330-6e2e2c27f047', 'ÿ��', '3', 'assetsWarnConfigCycle', null, null, '[admin]admin', '[admin]admin', '2016-03-23 12:21:10', '2016-03-23 12:21:10');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('660dd864-899a-443e-bc42-14338fca3665', '����', '-1', 'lowvalueApplyDetailStatus', null, null, '[admin]admin', '[admin]admin', '2016-03-23 12:15:58', '2016-03-23 12:15:58');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('6a0130c6-a613-49b5-be8b-b222ddcd6691', '��ȷ��', '4', 'borrowStatus', null, null, '[admin]admin', '[admin]admin', '2016-03-23 12:21:08', '2016-03-23 12:21:08');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('6b347ea2-ce02-44a4-a093-5e0a68079d80', '���', '5', 'purchaseStatus', '5', null, '[admin]admin', '[admin]admin', '2016-03-01 10:09:21', '2016-01-25 11:01:58');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('6b8dde03-7be2-4865-9fb8-42d62fa1b9e7', '������', '0', 'performanceEvaluateConfigurationStatus', '1', '������', '[admin]admin', '[admin]admin', '2016-03-22 16:03:53', '2016-03-22 16:03:53');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('6ba26860-a0ca-489f-afe2-96a6c768947c', '�鳤', '1', 'groupPost', '1', null, '[admin]admin', '[admin]admin', '2016-01-27 10:40:50', '2016-01-27 10:37:46');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('6cee1483-3f54-4195-910c-bf388d169295', '���ύ', '1', 'borrowStatus', null, null, '[admin]admin', '[admin]admin', '2016-03-23 12:19:37', '2016-03-23 12:19:37');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('6d2f7dc4-848a-4527-beb4-db704e736902', '���ύ', '0', 'lowvalueApplyDetailStatus', null, null, '[admin]admin', '[admin]admin', '2016-03-23 12:16:19', '2016-03-23 12:16:19');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('6ee11e31-ab21-48e8-97d5-fe440fe95a13', '�˵�', '1', 'resourceType', '1', null, null, null, '2015-12-21 14:23:28', '2015-12-21 14:23:28');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('6ef80543-25c2-48bf-9856-1c4c4b56e6dc', '������', '6', 'agreementCloseStatus', '6', null, '[admin]admin', '[admin]admin', '2016-03-09 15:44:53', '2016-03-09 15:44:53');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('71f9b540-0851-45a6-a965-3d17f3820443', '�޸�', 'operUpdate', 'formOperationType', '2', '�޸Ĳ���', null, null, '2016-01-06 11:12:44', '2016-01-06 11:12:44');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('75400f7c-7db5-400c-9f9a-e21e09eb8b6f', '������', '0', 'agreementEvaluateConfigurationStatus', '1', '������', '[admin]admin', '[admin]admin', '2016-03-26 16:31:21', '2016-03-26 16:31:21');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('78f5e54f-4493-40cb-847b-309ba0c3aec8', '�ѹر�', '2', 'performanceEvaluateConfigurationStatus', '3', '�ѹر�', '[admin]admin', '[admin]admin', '2016-03-22 16:04:23', '2016-03-22 16:04:23');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('7bc45143-ed3d-4134-8d3a-89c8996a6882', '����', 'personage', 'performance', '1', '����', '[admin]admin', '[admin]admin', '2016-01-12 17:00:49', '2016-01-12 17:00:49');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('7c3dfb3a-d4c7-4a52-8a3d-697ca8711bc3', '��ͣ', '1', 'triggerState', '2', '��ͣ', null, null, '2015-12-22 10:12:12', '2015-12-22 10:12:12');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('7eb8561c-b21b-4372-b183-669edcf347bf', '�Ѵ�����������ɡ�', '2', 'agreementStatus', '2', null, '[admin]admin', '[admin]admin', '2016-01-25 11:07:56', '2016-01-25 11:07:56');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('7fa4b056-028c-43dc-9c22-e2ed0d75bef9', '����', '4', 'supplierQuitStatus', '4', null, '[admin]admin', '[admin]admin', '2016-03-21 15:12:59', '2016-03-21 15:12:59');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('800a5588-b876-424c-a8b8-7c5cb4e6ee12', '���رա����ύ�ر�����)��', '5', 'agreementStatus', '5', null, '[admin]admin', '[admin]admin', '2016-01-25 11:08:34', '2016-01-25 11:08:34');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('812002b3-31d5-499e-8b7c-1066e4f7a412', '�˳�', '2', 'recordType', '2', null, '[admin]admin', '[admin]admin', '2016-02-23 17:32:44', '2016-02-23 17:32:44');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('831d02aa-0e01-452c-973c-bcdcf7356fbe', '��λ', '3', 'performanceEvaluatorType', '3', '��λ', '[admin]admin', '[admin]admin', '2016-03-16 15:39:34', '2016-03-16 15:39:34');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('8403e98d-b751-4e2f-8d94-111b74891fe0', '����', '3', 'triggerState', '4', '����', null, null, '2015-12-22 10:12:56', '2015-12-22 10:12:56');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('8504cfba-1c7f-4e7b-85e1-7f356d14340e', '���ٷ���', '2', 'projectRiskStatus', null, null, '[admin]admin', '[admin]admin', '2016-03-23 11:56:36', '2016-03-23 11:56:36');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('85664c7a-a3a6-43ed-9928-163058ae59ef', '��֯����Ա', '1', 'userType', '1', null, null, '[admin]admin', '2016-03-23 12:26:28', '2015-12-30 10:09:38');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('871cc37c-e8cf-4e72-8a08-46f309ef5148', 'δȷ��', '1', 'inventoryConfirmStatus', null, null, '[admin]admin', '[admin]admin', '2016-03-23 10:53:33', '2016-03-23 10:53:33');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('8a534a95-a531-41e9-8f11-c96ae685033c', '�ѿ���', '1', 'performanceEvaluateStatus', '1', '�ѿ���', '[admin]admin', '[admin]admin', '2016-03-22 15:57:01', '2016-03-22 15:57:01');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('8b971234-02e7-4618-8401-b54013df96c7', '������', '3', 'agreementChangeStatus', '3', null, '[admin]admin', '[admin]admin', '2016-03-28 17:10:00', '2016-03-08 15:02:05');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('8c22c984-0e6a-4628-b5b4-0fe7d9392357', '����������', '1', 'agreementStatus', '1', null, '[admin]admin', '[admin]admin', '2016-01-25 11:07:27', '2016-01-25 11:07:27');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('8db23688-c318-41f8-bafc-652eed14d43c', '������', '0', 'performanceEvaluateStatus', '2', '������', '[admin]admin', '[admin]admin', '2016-03-22 15:59:47', '2016-03-22 15:57:10');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('8efd93ad-eef1-4749-aa2c-a9823f8641d9', '�ѷ��Ŵ�ȷ��', '2', 'lowvalueApplyDetailStatus', null, null, '[admin]admin', '[admin]admin', '2016-03-23 12:16:40', '2016-03-23 12:16:40');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('903e1990-21b0-4257-bca2-bfae5064ac32', '��ȷ��', '3', 'lowvalueApplyDetailStatus', null, null, '[admin]admin', '[admin]admin', '2016-03-23 12:16:51', '2016-03-23 12:16:51');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('93198212-0bf4-4932-8470-f4a697af7607', '����Ӧ', '1', 'faultStatus', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:00:08', '2016-03-23 12:00:05');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('96b93267-6911-4885-9947-13d816cf6554', '���', '7', 'assetApplicationStatus', '7', null, '[admin]admin', '[admin]admin', '2016-03-26 16:34:06', '2016-03-26 16:34:06');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('96c5385f-f985-419c-a7cb-aaf831381fd8', '�ر�', '3', 'projectRiskStatus', null, null, '[admin]admin', '[admin]admin', '2016-03-23 11:56:54', '2016-03-23 11:56:54');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('98f3c17f-bb0c-4342-9051-d050685186bc', '������', '1', 'accessEvaluateStatus', '1', '������', '[admin]admin', '[admin]admin', '2016-01-21 18:56:29', '2016-01-21 18:56:29');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('9b96e0d0-9cdb-4e34-886f-a47c6c2b6879', '��Ŀ', 'project', 'performance', '3', '��Ŀ', '[admin]admin', '[admin]admin', '2016-01-12 17:01:27', '2016-01-12 17:01:27');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('9c278dad-c375-42fc-af0b-2c31ecd84817', '���', '5', 'borrowStatus', null, null, '[admin]admin', '[admin]admin', '2016-03-23 12:21:17', '2016-03-23 12:21:17');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('9cffeb57-1a93-46a0-ba57-d97e2f9bcb45', '����', '2', 'patrolObjectType', '2', '����', '[admin]admin', '[admin]admin', '2016-03-07 15:51:27', '2016-03-07 15:51:27');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('a1943491-cbe7-4b01-b469-5d28f61f23a4', '������-ȫ�����', 'comprehensiveAudit', 'riskAssessment', '4', '������-ȫ�����', '[admin]admin', '[admin]admin', '2016-02-24 11:41:28', '2016-01-12 17:06:11');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('a2a75d8e-bceb-41a3-8c8b-298c9516da0c', '��Ӧ�̹���', 'gysgl', 'workflowType', '1', null, '[admin]admin', '[admin]admin', '2016-02-01 17:25:53', '2016-02-01 17:25:53');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('a2d2b30c-c0fd-489e-a68c-03142e09029e', '�Ѹ���', '3', 'agreementPayStatus', '3', null, '[admin]admin', '[admin]admin', '2016-03-22 11:43:44', '2016-03-22 11:43:44');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('a4a8a020-e555-4337-a5e0-d3c677ecd131', '��Ӧ��', '1', 'patrolObjectType', '1', '��Ӧ��', '[admin]admin', '[admin]admin', '2016-03-07 15:51:16', '2016-03-07 15:51:16');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('a4eb2ac9-809e-40bc-806c-c623f11c026e', '�������', '4', 'agreementCloseStatus', '4', null, '[admin]admin', '[admin]admin', '2016-03-09 15:44:25', '2016-03-09 15:44:25');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('a6730707-115d-402b-b943-4dd256a7f2fe', '���ύ', '0', 'assetApplicationStatus', '0', null, '[FB0001]��ԣ��', '[admin]admin', '2016-03-26 16:30:26', '2016-03-24 17:39:42');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('a6e73cbe-8194-4ce8-8053-64167eccc45c', '����', 'operAdd', 'formOperationType', '1', '��������', null, null, '2016-01-06 11:12:01', '2016-01-06 11:12:01');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('a777ba4c-a805-4900-a532-5bddc0500932', '�����', '2', 'triggerState', '3', '�����', null, null, '2015-12-22 10:12:35', '2015-12-22 10:12:35');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('a84ff6fc-4fba-4695-9797-877f7ddb5405', 'ȫ���������', 'comprehensiveRiskAssessments', 'riskAssessment', '1', 'ȫ���������', '[admin]admin', '[admin]admin', '2016-01-12 17:03:57', '2016-01-12 17:03:57');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('a98ed1fe-99c1-4be8-a748-d23f1de4cc58', '��ɫ', '2', 'performanceEvaluatorType', '2', '��ɫ', '[admin]admin', '[admin]admin', '2016-03-16 15:39:20', '2016-03-16 15:39:20');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('b114f5f3-f8de-44cb-b56a-9b55976cfbf8', '��̬ģ��', '3', 'resourceType', '3', null, null, null, '2015-12-21 14:24:08', '2015-12-21 14:24:08');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('b299d89d-b980-4e5d-9058-2ba44eaa37ad', 'ȷ����', '1', 'lowvalueReceptionStatus', null, null, '[admin]admin', '[admin]admin', '2016-03-23 12:06:23', '2016-03-23 12:06:23');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('b5a643f8-c8f4-4b48-8056-2a9e3c2502fe', '������Ŀ', '7', 'recordType', '7', null, '[admin]admin', '[admin]admin', '2016-02-23 17:34:54', '2016-02-23 17:34:54');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('b6c27078-a505-4daf-85cb-ebd9d52a6263', 'δ����', '1', 'agreementPayStatus', '1', null, '[admin]admin', '[admin]admin', '2016-03-22 11:43:23', '2016-03-22 11:43:23');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('b7a7541d-1288-4fa0-ad85-23fa099add9d', '���鳤', '2', 'groupPost', '2', null, '[admin]admin', '[admin]admin', '2016-01-27 10:40:50', '2016-01-27 10:38:13');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('b87edc36-f197-4a8b-b9c9-021e3a83fc3c', '��ͬ', 'contract', 'performance', '4', '��ͬ', '[admin]admin', '[admin]admin', '2016-01-12 17:01:53', '2016-01-12 17:01:53');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('b94d50e0-98d3-4fcf-940b-ac1ad0c01107', '��Ա', '3', 'groupPost', '3', null, '[admin]admin', '[admin]admin', '2016-01-27 10:40:50', '2016-01-27 10:38:27');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('b9d90fa8-2681-4fb7-9d1f-6da0c744d1cb', '������', '3', 'agreementCloseStatus', '3', null, '[admin]admin', '[admin]admin', '2016-03-09 15:44:08', '2016-03-09 15:44:08');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('badd9a82-70d8-4c0b-a2e2-8900faccde46', '���ȷ��', '3', 'assetsInventoryStatus', null, null, '[admin]admin', '[admin]admin', '2016-03-23 10:52:07', '2016-03-23 10:46:29');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('bd02512d-bf39-4273-840a-d2cfd5ce4ce1', 'δ�ύ', '1', 'supplierQuitStatus', '1', null, '[admin]admin', '[admin]admin', '2016-03-09 17:20:21', '2016-03-09 17:20:21');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('bdb3dac9-0f93-4ca8-ad46-096213665a1d', '����', 'insert', 'LogOpType', '1', null, null, null, '2015-12-29 12:16:57', '2015-12-29 12:16:36');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('c04ae568-7b70-4cb0-87c5-6a5825423548', 'ϵͳ��ɫ', '1', 'roleType', null, null, null, null, '2015-12-17 18:24:18', '2015-12-17 18:24:18');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('c1fc5eba-2686-464c-837e-a77cc36243e1', '������', '4', 'lowvalueApplyStatus', '4', null, '[admin]admin', '[admin]admin', '2016-03-23 12:11:59', '2016-03-23 12:11:49');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('c20cb46d-7cbb-4a4a-a2aa-bdd2a3151651', '���ύ', '1', 'agreementCloseStatus', '1', null, '[admin]admin', '[admin]admin', '2016-03-09 15:43:42', '2016-03-09 15:43:42');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('c27278d9-025d-485b-ba29-cfaafc575aba', '�ύ������', '2', 'agreementChangeStatus', '2', null, '[admin]admin', '[admin]admin', '2016-03-28 17:09:50', '2016-03-08 15:01:52');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('c3eb3f58-6ae5-49de-b048-d9e7815ee446', 'ɾ��', 'delete', 'LogOpType', '3', null, null, null, '2015-12-29 12:17:11', '2015-12-29 12:17:11');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('c40c6a24-e0fe-4395-9327-5a1f9abb16e0', '������', '3', 'agreementStatus', '3', null, '[admin]admin', '[admin]admin', '2016-01-25 11:08:07', '2016-01-25 11:08:07');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('c4d8740f-39d0-4052-9f1c-f8fb35732181', '�����Ա', '3', 'userType', '3', null, null, null, '2016-01-03 11:18:51', '2016-01-03 11:18:51');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('c51ce9ec-6532-4def-9da8-1068cea96f34', '�������', '7', 'agreementCloseStatus', '7', null, '[admin]admin', '[admin]admin', '2016-03-09 15:45:07', '2016-03-09 15:45:07');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('ce2956db-798d-486d-b48d-29b319f43b3f', '�ѿ��˴��ر�', '1', 'performanceEvaluateConfigurationStatus', '2', '�ѿ��˴��ر�', '[admin]admin', '[admin]admin', '2016-03-22 16:04:11', '2016-03-22 16:04:11');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('cf8cf35a-5341-421b-aaf5-01a8fed7056f', 'δ�ύ', '0', 'assetRetirementStatus', '0', null, '[101]������1', '[101]������1', '2016-03-28 16:40:52', '2016-03-28 16:41:43');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('d2ef46e9-9104-4ef5-a851-ec26effab69d', '������', '3', 'assetRetirementStatus', '3', null, '[101]������1', '[101]������1', '2016-03-28 16:42:23', '2016-03-28 16:42:23');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('d4364075-17e4-413f-ae22-d1dae9afa826', '���黹', '3', 'borrowStatus', null, null, '[admin]admin', '[admin]admin', '2016-03-23 12:20:04', '2016-03-23 12:20:04');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('d59fddc8-1567-4bf1-9db6-be44d731f9a4', '��ǩ����ͬ', '3', 'purchaseStatus', '3', null, '[admin]admin', '[admin]admin', '2016-03-01 10:08:43', '2016-01-25 11:01:41');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('d70c03d7-c474-48a0-8b8b-0e56e043bd18', '��ȷ��', '1', 'lowvalueReceptionDetailConfirmStatus', null, null, '[admin]admin', '[admin]admin', '2016-03-23 12:08:53', '2016-03-23 12:08:53');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('d76bd695-93a9-408d-9f93-8bfc81876ffb', '���', '6', 'assetRepairStatus', '6', null, '[admin]admin', '[admin]admin', '2016-03-27 15:11:16', '2016-03-27 15:11:16');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('d8f94a3f-3f3c-440e-b518-9ebd470979bb', '����', '0', 'triggerState', '1', '����', null, null, '2015-12-22 10:11:29', '2015-12-22 10:11:29');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('d9c4cb08-77fb-4446-9bf3-b6ef30773df8', '����', '8', 'assetApplicationStatus', '8', null, '[admin]admin', '[admin]admin', '2016-03-26 16:32:41', '2016-03-26 15:04:07');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('dad638e9-ad7b-46c6-ae76-1353f7e79b4b', '������', '2', 'assetRetirementStatus', '2', null, '[101]������1', '[101]������1', '2016-03-28 16:42:14', '2016-03-28 16:42:14');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('db150b3c-e8e6-470c-8a2c-56ad6a29363f', 'ͬ��رա���������ͨ����', '6', 'agreementStatus', '6', null, '[admin]admin', '[admin]admin', '2016-01-25 11:08:46', '2016-01-25 11:08:46');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('df6a6bb8-7213-47fe-9199-904cd58be3b5', '����ͨ��', '5', 'agreementChangeStatus', '5', null, '[admin]admin', '[admin]admin', '2016-03-28 17:10:13', '2016-03-28 17:10:13');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('e12a98d9-50ba-4a18-bd00-03e0b35b2307', '���ű��', '5', 'recordType', '5', null, '[admin]admin', '[admin]admin', '2016-02-23 17:34:32', '2016-02-23 17:34:32');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('e1e146f3-e491-4102-b873-acc683f4dfaf', '����', '1', 'deductionsCycle', '1', null, '[admin]admin', '[admin]admin', '2016-02-27 11:37:47', '2016-02-27 11:37:47');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('e3db5de8-28aa-4694-8793-a74fa737c906', '������', '0', 'accessEvaluateConfigurationStatus', '1', '������', '[admin]admin', '[admin]admin', '2016-02-03 15:34:13', '2016-01-21 18:59:44');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('e4dd7eb7-3e36-4511-868e-89dd32e2c4d9', '��������ά��', '3', 'assetRepairStatus', '3', null, '[admin]admin', '[admin]admin', '2016-03-27 15:10:30', '2016-03-27 15:10:30');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('e9be4ba9-87ba-4cba-9f0f-d364b90f0bcd', '����', 'GZ', 'riskState', '1', null, '[admin]admin', '[admin]admin', '2016-02-01 15:59:32', '2016-02-01 15:59:32');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('e9c8e6c9-2078-4bc3-aa41-a4ee2e16e3ac', '��ְ', '4', 'recordType', '4', null, '[admin]admin', '[admin]admin', '2016-02-23 17:34:18', '2016-02-23 17:34:18');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('ee2290cb-8c66-43f6-98d7-9204dfb058e4', '�����ͬ', '6', 'recordType', '6', null, '[admin]admin', '[admin]admin', '2016-02-23 17:34:44', '2016-02-23 17:34:44');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('ef0966d8-0662-4705-a85e-edb25ccf9b66', '������', '2', 'supplierQuitStatus', '2', null, '[admin]admin', '[admin]admin', '2016-03-21 15:12:33', '2016-03-09 17:20:40');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('f14e7fa1-3f7c-43bd-aa69-c00c8fd0b695', 'δȷ��', '1', 'assetsInventoryStatus', null, null, '[admin]admin', '[admin]admin', '2016-03-23 10:52:07', '2016-03-23 10:45:52');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('f173f0cf-ab2e-40c8-ae7d-27f5527546a8', '����', '3', 'deductionsCycle', '3', null, '[admin]admin', '[admin]admin', '2016-02-27 11:38:14', '2016-02-27 11:38:14');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('f205263b-e37e-4c95-8a2f-af92494b7316', 'ȷ����', '6', 'assetApplicationStatus', '6', null, '[admin]admin', '[admin]admin', '2016-03-26 16:32:06', '2016-03-26 15:03:16');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('f42ac38c-b999-4308-b9bf-e596a5e961ca', '������', '1', 'assetRetirementStatus', '1', null, '[101]������1', '[101]������1', '2016-03-28 16:41:53', '2016-03-28 16:41:53');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('f4d2b550-c27b-4772-8ce4-b6bad7a47e66', '�ѹر�', '2', 'accessEvaluateConfigurationStatus', '3', '�ѹر�', '[admin]admin', '[admin]admin', '2016-01-22 15:20:21', '2016-01-21 19:00:27');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('f7e45ee0-6ab5-4722-ab3a-dc1ae14401f6', '����', '3', 'recordType', '3', null, '[admin]admin', '[admin]admin', '2016-02-23 17:33:54', '2016-02-23 17:33:54');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('f98a9834-3a68-46af-82c3-a39987e105de', '����', '4', 'assetRetirementStatus', '4', null, '[101]������1', '[101]������1', '2016-03-28 16:42:34', '2016-03-28 16:42:34');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('fab8b369-a7ba-48e5-8f49-68e884d07aeb', 'ά����', '4', 'assetRepairStatus', '4', null, '[admin]admin', '[admin]admin', '2016-03-27 15:10:45', '2016-03-27 15:10:45');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('faed1758-ef4f-43e1-9fb9-066e14f504bb', '����', '1', 'performanceEvaluatorType', '1', '����', '[admin]admin', '[admin]admin', '2016-03-16 15:39:12', '2016-03-16 15:39:12');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('fb5fa9f5-ff35-4028-8171-d817e30d5900', '�ʲ�����', 'zcgl', 'workflowType', '3', null, '[admin]admin', '[admin]admin', '2016-02-01 17:26:41', '2016-02-01 17:26:41');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('ffad3e81-49ba-4f21-90fe-e97910aa120f', '����', 'operDetail', 'formOperationType', '3', '�鿴����', null, null, '2016-01-06 11:13:06', '2016-01-06 11:13:06');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('ffe10998-8271-48b1-967f-528573a05750', '������', '0', 'accessEvaluateStatus', '2', '������', '[admin]admin', '[admin]admin', '2016-01-21 18:56:45', '2016-01-21 18:56:45');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('30bf6bf5-bfc3-4fae-b900-86634b7d1d9b', '�׷�������', 'aleader', 'projectRole', null, null, '[admin]admin', '[admin]admin', '2016-01-21 18:56:45', '2016-01-21 18:56:45');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('d9b089a8-1e64-48fa-973d-0deedf26b0ca', '�ҷ�������', 'bleader', 'projectRole', null, null, '[admin]admin', '[admin]admin', '2016-01-21 18:56:45', '2016-01-21 18:56:45');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('360a1843-15cb-4fad-ac6b-42977aa45a2b', '����', '2', 'faultIssueType', null, null, '[admin]admin', '[admin]admin', '2016-01-21 18:56:45', '2016-01-21 18:56:45');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('fe3d1891-5565-471e-b957-6696b4ccef40', '��Ӧ��', '1', 'faultIssueType', null, null, '[admin]admin', '[admin]admin', '2016-01-21 18:56:45', '2016-01-21 18:56:45');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('69bbabc6-dd19-4730-99f8-83144fc7a25a', '��', '3', 'faultHandleConfirm', null, null, '[admin]admin', '[admin]admin', '2016-01-21 18:56:45', '2016-01-21 18:56:45');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('7ede4c1c-8585-4539-b415-09f4a45a136c', '���ڴ���', '2', 'faultHandleConfirm', null, null, '[admin]admin', '[admin]admin', '2016-01-21 18:56:45', '2016-01-21 18:56:45');
INSERT INTO `sys_param`(`id`,`name`,`value`,`paramType`,`sort`,`remark`,`createUser`,`updateUser`,`updateTime`,`createTime`) VALUES ('c362fe43-30ac-49a1-a1c1-1ffa5e9de86a', '��', '1', 'faultHandleConfirm', null, null, '[admin]admin', '[admin]admin', '2016-01-21 18:56:45', '2016-01-21 18:56:45');


-- ----------------------------
-- ���ղ�������(risk_param_type)
-- ----------------------------
INSERT INTO `risk_param_type`(`id`,`name`,`code`,`type`,`riskType`,`remark`) VALUES 
('380300fd-0ad8-49a2-842b-0bb1f6d51c24','��������','projectOtherRisk','1','1',null);
INSERT INTO `risk_param_type`(`id`,`name`,`code`,`type`,`riskType`,`remark`) VALUES 
('a48295b7-be42-488b-ac87-7c09c7b06843','��������','supplierOtherRisk','1','2',null);

-- ----------------------------
-- ���ղ���(risk_param)
-- ----------------------------
INSERT INTO `risk_param`(`id`,`name`,`value`,`paramType`,`sort`,`riskType`,`type`,`handle`,`remark`) VALUES 
('0304fba0-301d-442f-bb03-a64d5ede5d16','��������','0','supplierOtherRisk',null,'2',null,'��������','��������');
INSERT INTO `risk_param`(`id`,`name`,`value`,`paramType`,`sort`,`riskType`,`type`,`handle`,`remark`) VALUES 
('26143071-404e-41e2-bc8a-3b51282860d1','��������','0','projectOtherRisk',null,'1',null,'��������','��������');


-- ----------------------------
-- �ʲ���ͬԤ������(assets_agreement_warn_config)
-- ----------------------------
INSERT INTO `assets_agreement_warn_config`(`id`,`type`,`warnDayNum`,`warnCycle`,`warnModeSys`,`warnModeEmail`,`warnModeSms`) VALUES ('2b5f56cd-615e-4c73-9149-f1e3c1607ad9', '��ɫԤ��', '90', '3', '1', '1', '0');
INSERT INTO `assets_agreement_warn_config`(`id`,`type`,`warnDayNum`,`warnCycle`,`warnModeSys`,`warnModeEmail`,`warnModeSms`)  VALUES ('31ca46a4-71eb-4796-b0df-f284f37a0ce6', '��ɫԤ��', '30', '4', '1', '1', '0');
INSERT INTO `assets_agreement_warn_config`(`id`,`type`,`warnDayNum`,`warnCycle`,`warnModeSys`,`warnModeEmail`,`warnModeSms`)  VALUES ('561df3a2-4bb7-4066-b2c3-8d267ee4e9c4', '��ɫԤ��', '180', '2', '1', '1', '0');


-- ----------------------------
-- ģ������(sys_evaluate_setting)
-- ----------------------------
INSERT INTO `sys_evaluate_setting`(`id`,`accessEvaluate`,`agreementEvaluateManager`,`patrolManager`,`supplierPerformance`,`projectPerformance`,`riskOverall`,`riskImportant`,`riskAudit`,`duediligence`,`serviceMonitoring`,`securityCheck`,`externalManager`,`humanPerformance`) VALUES ('1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1');



-- ----------------------------
-- ����������
-- ----------------------------
delete from `act_evt_log`;
delete from `act_ge_property`;
delete from `act_hi_actinst`;
delete from `act_hi_attachment`;
delete from `act_hi_comment`;
delete from `act_hi_detail`;
delete from `act_hi_identitylink`;
delete from `act_hi_procinst`;
delete from `act_hi_taskinst`;
delete from `act_hi_varinst`;
delete from `act_id_group`;
delete from `act_id_info`;
delete from `act_id_user`;
delete from `act_id_membership`;
/**acitvity ����*/
delete from `act_re_model`;
delete from `act_re_procdef`;
delete from `act_ru_execution`;
delete from `act_ru_event_subscr`;
delete from `act_ru_job`;
delete from `act_ru_task`;
delete from `act_ru_identitylink`;
delete from `act_ru_variable`;
delete from `act_ge_bytearray`;
delete from `act_re_deployment`;

INSERT INTO  `act_ge_property` (`NAME_`, `VALUE_`, `REV_`) VALUES ('next.dbid', '237501', '96');
INSERT INTO  `act_ge_property` (`NAME_`, `VALUE_`, `REV_`) VALUES ('schema.history', 'create(5.17.0.2)', '1');
INSERT INTO  `act_ge_property` (`NAME_`, `VALUE_`, `REV_`) VALUES ('schema.version', '5.17.0.2', '1');


/**sys_workflow ����*/
delete from `sys_workflow`;
delete from `sys_workflow_audit_history`;
delete from `sys_workflow_branch`;
delete from `sys_workflow_business_user_history`;
delete from `sys_workflow_decision`;
delete from `sys_workflow_element_seat`;
delete from `sys_workflow_exchange`;
delete from `sys_workflow_form`;
delete from `sys_workflow_instance_link`;
delete from `sys_workflow_instance_node`;
delete from `sys_workflow_step`;
delete from `sys_workflow_instance`;
delete from `sys_workflow_version`;
INSERT INTO `sys_workflow` (
	`id`,
	`name`,
	`code`,
	`type`,
	`orderNum`,
	`createUser`,
	`createTime`,
	`updateUser`,
	`updateTime`
)
VALUES
	(
		'16a93432-799d-4281-ad04-a9901d086432',
		'ʵ���ʲ�-�ʲ�����',
		'physical_asset_repairs',
		'zcgl',
		12,
		NULL,
		NULL,
		NULL,
		NULL
	),
	(
		'285e5e29-23f9-4da5-b33c-e9bdaea29275',
		'�����ʱ-�Ӱ�',
		'outsource_manhour_overtime',
		'wbgl',
		8,
		NULL,
		NULL,
		NULL,
		NULL
	),
	(
		'5d889186-7488-482f-9d66-509cf6424683',
		'������',
		'supplier_blacklist',
		'gysgl',
		4,
		NULL,
		NULL,
		NULL,
		NULL
	),
	(
		'7476b5f5-299b-4625-bc10-b027262e2106',
		'ʵ���ʲ�-�ʲ�����',
		'physical_asset_apply',
		'zcgl',
		11,
		NULL,
		NULL,
		'[admin]admin',
		'2016-02-03 15:08:44'
	),
	(
		'8f1a70f1-b9b3-49e0-bedd-bc6d1028dd7e',
		'�����Ա-��ְ',
		'outsource_person_dimission',
		'wbgl',
		7,
		NULL,
		NULL,
		NULL,
		NULL
	),
	(
		'9b28d6e3-7edc-4ea6-9b8f-e7aa15b07d09',
		'�����ʱ-���',
		'outsource_manhour_leave',
		'wbgl',
		9,
		NULL,
		NULL,
		NULL,
		NULL
	),
	(
		'afd513fb-6f3f-43be-a28a-125e1a76a358',
		'�����ʱ-����',
		'outsource_manhour_on_business',
		'wbgl',
		10,
		NULL,
		NULL,
		NULL,
		NULL
	),
	(
		'c4919d97-3d56-46df-91df-6d47c1f2c331',
		'��ֵ�׺�-�ʲ�����',
		'lowvalue_asset_apply',
		'zcgl',
		13,
		NULL,
		NULL,
		NULL,
		NULL
	),
	(
		'e0a6b73d-8d8c-4845-80eb-460c10defe2f',
		'�����Ա-�˳�',
		'outsource_person_exit',
		'wbgl',
		6,
		NULL,
		NULL,
		NULL,
		NULL
	),
	(
		'e90bb592-0d76-4e66-83f3-2d47adbed475',
		'��ͬ�ر�',
		'supplier_agreement_close',
		'gysgl',
		1,
		NULL,
		NULL,
		'[admin]admin',
		'2016-02-15 17:03:20'
	),
	(
		'f0aa29f9-4a31-4090-bde8-d56c06cedb62',
		'��Ӧ���˳�',
		'supplier_quit',
		'gysgl',
		3,
		NULL,
		NULL,
		NULL,
		NULL
	),
	(
		'f2c2970e-8fcb-4490-90ed-71a89bdde058',
		'�����Ա-�볡',
		'outsource_person_enter',
		'wbgl',
		5,
		NULL,
		NULL,
		NULL,
		NULL
	),
	(
		'f94f8e80-2f24-44d1-95b0-d4b2366e2607',
		'��ͬ���',
		'supplier_agreement_change',
		'gysgl',
		2,
		NULL,
		NULL,
		'[admin]admin',
		'2016-02-02 17:22:27'
	),
	(
		'f94f8e80-2f24-44d1-95b0-d4b2366e2608',
		'ʵ���ʲ�����',
		'physical_asset_scrap',
		'zcgl',
		14,
		NULL,
		NULL,
		'[admin]admin',
		NULL
	);

#
# Data for table "sys_workflow_form"
#
INSERT INTO `sys_workflow_form` (
	`id`,
	`workflowId`,
	`formItemName`,
	`formItemValue`,
	`formItemOrder`,
	`tableName`,
	`tableField`
)
VALUES
	(
		'2050637c-fc43-48ee-b926-4c38a82830d6',
		'c4919d97-3d56-46df-91df-6d47c1f2c331',
		'���뵥λ',
		'2',
		1,
		NULL,
		NULL
	),
	(
		'3590198c-849d-4e87-b3ec-4fa3d9962e6f',
		'e90bb592-0d76-4e66-83f3-2d47adbed475',
		'���������ڲ���',
		'1',
		1,
		NULL,
		NULL
	),
	(
		'4b10af3a-2e89-4f70-9de5-19df325e9cec',
		'afd513fb-6f3f-43be-a28a-125e1a76a358',
		'���������ڲ���',
		'1',
		1,
		NULL,
		NULL
	),
	(
		'4b810029-2ec3-4fcc-b0c7-752a420f8de6',
		'f0aa29f9-4a31-4090-bde8-d56c06cedb62',
		'���������ڲ���',
		'1',
		1,
		NULL,
		NULL
	),
	(
		'4b810029-2ec3-4fcc-b0c7-752a420f8de7',
		'f0aa29f9-4a31-4090-bde8-d56c06cedb62',
		'���뵥λ',
		'2',
		2,
		NULL,
		NULL
	),
	(
		'73aa59ba-8d3f-44e2-9b13-d7b86543a637',
		'f94f8e80-2f24-44d1-95b0-d4b2366e2607',
		'���������ڲ���',
		'1',
		1,
		NULL,
		NULL
	),
	(
		'88b27f18-1bc7-4486-a26b-a944b47e7de6',
		'8f1a70f1-b9b3-49e0-bedd-bc6d1028dd7e',
		'���������ڲ���',
		'1',
		1,
		NULL,
		NULL
	),
	(
		'99b1b239-ac73-4e17-a816-bbe9b88ef1f0',
		'e0a6b73d-8d8c-4845-80eb-460c10defe2f',
		'���������ڲ���',
		'1',
		1,
		NULL,
		NULL
	),
	(
		'b8656b27-f3f8-4aa9-a7fa-b7275feeef8b',
		'16a93432-799d-4281-ad04-a9901d086432',
		'���뵥λ',
		'2',
		1,
		NULL,
		NULL
	),
	(
		'b8b4f32d-6390-4b45-8ab3-d565005fcd6a',
		'285e5e29-23f9-4da5-b33c-e9bdaea29275',
		'���������ڲ���',
		'1',
		1,
		NULL,
		NULL
	),
	(
		'cf9683a3-1d1f-4d78-bdb5-8d8c512d7b02',
		'7476b5f5-299b-4625-bc10-b027262e2106',
		'���뵥λ',
		'2',
		1,
		NULL,
		NULL
	),
	(
		'd4885ceb-61fb-4fb6-9896-b7df2bd643d3',
		'5d889186-7488-482f-9d66-509cf6424683',
		'���������ڲ���',
		'1',
		1,
		NULL,
		NULL
	),
	(
		'f06cd641-8075-42de-a389-f0065a3c8a30',
		'9b28d6e3-7edc-4ea6-9b8f-e7aa15b07d09',
		'���������ڲ���',
		'1',
		1,
		NULL,
		NULL
	),
	(
		'f85c20ac-509b-4536-bb94-24abe18395ba',
		'f2c2970e-8fcb-4490-90ed-71a89bdde058',
		'���������ڲ���',
		'1',
		1,
		NULL,
		NULL
	),
	(
		'f85c20ac-509b-4536-bb94-24abe18395bb',
		'f94f8e80-2f24-44d1-95b0-d4b2366e2608',
		'���������ڲ���',
		'1',
		1,
		NULL,
		NULL
	),
	(
		'f85c20ac-509b-4536-bb94-24abe18395bc',
		'f94f8e80-2f24-44d1-95b0-d4b2366e2608',
		'���뵥λ',
		'2',
		2,
		NULL,
		NULL
	);

