
DROP FUNCTION IF EXISTS `attendance_parse`;

/** 考勤信息日历展示
* attdate 考勤日期
* attDateTime 考勤时间 
* dateStyle 是否迟到、早退 1:迟到;//null:未签到;0:正常
* attStyle 1:签到，2：签退
**/
CREATE FUNCTION `attendance_parse`(id char(36), attdate date,attDateTime datetime,dateStyle varchar(10),attStyle int) RETURNS varchar(255)  
BEGIN 

DECLARE time VARCHAR(20) DEFAULT ''; -- 时分秒
DECLARE color VARCHAR(10) DEFAULT ''; -- 根据考勤正常与否返回相应的颜色，异常红色，正常绿色
DECLARE attStr VARCHAR(10) DEFAULT '';  -- 已签到、未签到、已签退、未签退
DECLARE attDateTimeStr VARCHAR(20) DEFAULT '';  -- 考勤时间

SET attDateTimeStr = attdate; 
-- 如果是签到
IF(attStyle = 1) THEN 
	IF(ISNULL(attDateTime)) THEN 
		SET attStr = '未签到';
		SET attDateTimeStr = CONCAT(attdate,' 00:00:00');-- 后面加‘00:00:00’是为了让未签到排在考勤日历最前面
	ELSE 
		SET attStr = '已签到';  
		SET time = date_format(attDateTime,'%H:%i:%s'); 
		SET attDateTimeStr = attDateTime; 
	END IF;
ELSEIF (attStyle = 2)THEN  -- 否则是签退
	IF(ISNULL(attDateTime)) THEN 
		SET attStr = '未签退';
		SET attDateTimeStr = CONCAT(attdate,' 23:59:58');-- 后面加‘23:59:59’是为了让未签退排在考勤日历签到后面 
	ELSE 
		SET attStr = '已签退';
		-- 如果跨天签退，time需要显示年月日+时分秒
		IF(attDateTime > CONCAT(attdate,' 23:59:59')) THEN
			SET time = attDateTime; 
			SET attDateTimeStr = CONCAT(attdate,' 23:59:58');-- 后面加‘23:59:59’是为了让未签退排在考勤日历签到后面 
		ELSE 
			SET time = date_format(attDateTime,'%H:%i:%s');
			SET attDateTimeStr = attDateTime; 
		END IF;
		
	END IF;
END IF; 

-- 判断考勤异常情况
IF(dateStyle = 0) THEN 
		SET color = '#00a65a'; -- 正常是绿色
ELSE 
		SET color = '#D9534F';  -- 异常是红色
END IF;

RETURN CONCAT('{"title":"',time,' ',attStr,'","backgroundColor":"',color,'","borderColor":"',color,'","start":"',attDateTimeStr,'","attStyle":"',attStyle,'","id":"',id,'","dateStyle":"',dateStyle,'"}');  
END;
