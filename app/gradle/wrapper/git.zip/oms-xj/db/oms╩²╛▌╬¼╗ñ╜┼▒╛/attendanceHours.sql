-- 考勤个人工时统计查询脚本
	select tb.*, wotb1.overtimeHours,wotb2.overtimeHourApplys,wvdtb1.vacationHours,wvdtb2.vacationHourApplys,wtdtb1.travelHours,wtdtb2.travelHourApplys from (
		select att.userId,count(att.userId) as attDays,sum(if(att.dateinStyle!=0 or att.dateoutStyle!=0,1,0)) as attExDays,SUM(att.attHour) as attHours ,sbi.name as supplierName, CONCAT(su.name,'/',su.code) as userName ,su.orgName, '"+beginDate+"' as beginDate , '"+endDate+"' as endDate from attendance att
		left join supplier_base_info sbi on att.supplierId = sbi.id
		left join sys_user su on att.userId = su.id
		where att.date BETWEEN '2016-7-3' AND '2016-8-3'
		and att.attType = 0 -- 固定考勤的数据,非周末加班时手动生成的数据
		and attendanceDateType = 1 -- 考勤方式:(1.确定时间，2.不确定时间)
		group by att.userId
		ORDER BY sbi.name
	) tb
	left join (
		select wo1.createUserId,sum(wo1.hours) as overtimeHours from workhour_overtime wo1 where wo1.status = 5 and wo1.presentDate BETWEEN '2016-7-3' AND '2016-8-3' group by wo1.createUserId
	) wotb1 on tb.userId = wotb1.createUserId
	left join (
		select wo2.createUserId,sum(wo2.hours) as overtimeHourApplys from workhour_overtime wo2 where wo2.status != 6 and wo2.presentDate BETWEEN '2016-7-3' AND '2016-8-3' group by wo2.createUserId
	) wotb2 on tb.userId = wotb2.createUserId
	left join (
		select wvd1.createUserId,sum(wvd1.hours) as vacationHours from workhour_vacation_detail wvd1 where wvd1.status = 5 and wvd1.presentDate BETWEEN '2016-7-3' AND '2016-8-3' group by wvd1.createUserId
	) wvdtb1 on tb.userId = wvdtb1.createUserId
	left join (
		select wvd2.createUserId,sum(wvd2.hours) as vacationHourApplys from workhour_vacation_detail wvd2 where wvd2.status != 6 and wvd2.presentDate BETWEEN '2016-7-3' AND '2016-8-3' group by wvd2.createUserId
	) wvdtb2 on tb.userId = wvdtb2.createUserId
	left join (
		select wtd1.createUserId,sum(wtd1.hours) as travelHours from workhour_travel_detail wtd1 where wtd1.status = 5 and wtd1.presentDate BETWEEN '2016-7-3' AND '2016-8-3' group by wtd1.createUserId
	) wtdtb1 on tb.userId = wtdtb1.createUserId
	left join (
		select wtd2.createUserId,sum(wtd2.hours) as travelHourApplys from workhour_travel_detail wtd2 where wtd2.status != 6 and wtd2.presentDate BETWEEN '2016-7-3' AND '2016-8-3' group by wtd2.createUserId
	) wtdtb2 on tb.userId = wtdtb2.createUserId;  
