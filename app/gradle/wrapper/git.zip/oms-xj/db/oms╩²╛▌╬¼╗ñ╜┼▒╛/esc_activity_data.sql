

delete from `act_evt_log`;


delete from `act_ge_property`;

delete from `act_hi_actinst`;


delete from `act_hi_attachment`;



delete from `act_hi_comment`;


delete from `act_hi_detail`;

delete from `act_hi_identitylink`;



delete from `act_hi_procinst`;


delete from `act_hi_taskinst`;



delete from `act_hi_varinst`;


delete from `act_id_group`;



delete from `act_id_info`;


delete from `act_id_user`;



delete from `act_id_membership`;






delete from `act_re_model`;



delete from `act_re_procdef`;


delete from `act_ru_execution`;


delete from `act_ru_event_subscr`;



delete from `act_ru_job`;


delete from `act_ru_task`;


delete from `act_ru_identitylink`;


delete from `act_ru_variable`;

delete from `act_ge_bytearray`;



delete from `act_re_deployment`;

INSERT INTO  `act_ge_property` (`NAME_`, `VALUE_`, `REV_`) VALUES ('next.dbid', '237501', '96');
INSERT INTO  `act_ge_property` (`NAME_`, `VALUE_`, `REV_`) VALUES ('schema.history', 'create(5.17.0.2)', '1');
INSERT INTO  `act_ge_property` (`NAME_`, `VALUE_`, `REV_`) VALUES ('schema.version', '5.17.0.2', '1');
