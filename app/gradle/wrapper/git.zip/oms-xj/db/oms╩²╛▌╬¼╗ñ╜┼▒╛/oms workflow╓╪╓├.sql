

delete from `act_evt_log`;


delete from `act_ge_property`;

delete from `act_hi_actinst`;


delete from `act_hi_attachment`;



delete from `act_hi_comment`;


delete from `act_hi_detail`;

delete from `act_hi_identitylink`;



delete from `act_hi_procinst`;


delete from `act_hi_taskinst`;



delete from `act_hi_varinst`;


delete from `act_id_group`;



delete from `act_id_info`;


delete from `act_id_user`;



delete from `act_id_membership`;




/**acitvity 重置*/

delete from `act_re_model`;



delete from `act_re_procdef`;


delete from `act_ru_execution`;


delete from `act_ru_event_subscr`;



delete from `act_ru_job`;


delete from `act_ru_task`;


delete from `act_ru_identitylink`;


delete from `act_ru_variable`;

delete from `act_ge_bytearray`;



delete from `act_re_deployment`;

INSERT INTO  `act_ge_property` (`NAME_`, `VALUE_`, `REV_`) VALUES ('next.dbid', '237501', '96');
INSERT INTO  `act_ge_property` (`NAME_`, `VALUE_`, `REV_`) VALUES ('schema.history', 'create(5.17.0.2)', '1');
INSERT INTO  `act_ge_property` (`NAME_`, `VALUE_`, `REV_`) VALUES ('schema.version', '5.17.0.2', '1');


/**sys_workflow 重置*/
delete from `sys_workflow`;

delete from `sys_workflow_audit_history`;


delete from `sys_workflow_branch`;

delete from `sys_workflow_business_user_history`;

delete from `sys_workflow_decision`;

delete from `sys_workflow_element_seat`;

delete from `sys_workflow_exchange`;

delete from `sys_workflow_form`;

delete from `sys_workflow_instance_link`;

delete from `sys_workflow_instance_node`;


delete from `sys_workflow_step`;



delete from `sys_workflow_instance`;


delete from `sys_workflow_version`;

INSERT INTO   `sys_workflow` (`id`, `name`, `code`, `type`, `orderNum`, `createUser`, `createTime`, `updateUser`, `updateTime`) VALUES ('16a93432-799d-4281-ad04-a9901d086432', '实物资产-资产报修', 'physical_asset_repairs', 'zcgl', '12', NULL, NULL, NULL, NULL);
INSERT INTO   `sys_workflow` (`id`, `name`, `code`, `type`, `orderNum`, `createUser`, `createTime`, `updateUser`, `updateTime`) VALUES ('285e5e29-23f9-4da5-b33c-e9bdaea29275', '外包工时-加班', 'outsource_manhour_overtime', 'wbgl', '8', NULL, NULL, NULL, NULL);
INSERT INTO   `sys_workflow` (`id`, `name`, `code`, `type`, `orderNum`, `createUser`, `createTime`, `updateUser`, `updateTime`) VALUES ('5d889186-7488-482f-9d66-509cf6424683', '黑名单', 'supplier_blacklist', 'gysgl', '4', NULL, NULL, NULL, NULL);
INSERT INTO   `sys_workflow` (`id`, `name`, `code`, `type`, `orderNum`, `createUser`, `createTime`, `updateUser`, `updateTime`) VALUES ('7476b5f5-299b-4625-bc10-b027262e2106', '实物资产-资产申请', 'physical_asset_apply', 'zcgl', '11', NULL, NULL, '[admin]admin', '2016-02-03 15:08:44');
INSERT INTO   `sys_workflow` (`id`, `name`, `code`, `type`, `orderNum`, `createUser`, `createTime`, `updateUser`, `updateTime`) VALUES ('8f1a70f1-b9b3-49e0-bedd-bc6d1028dd7e', '外包人员-离职', 'outsource_person_dimission', 'wbgl', '7', NULL, NULL, NULL, NULL);
INSERT INTO   `sys_workflow` (`id`, `name`, `code`, `type`, `orderNum`, `createUser`, `createTime`, `updateUser`, `updateTime`) VALUES ('9b28d6e3-7edc-4ea6-9b8f-e7aa15b07d09', '外包工时-请假', 'outsource_manhour_leave', 'wbgl', '9', NULL, NULL, NULL, NULL);
INSERT INTO   `sys_workflow` (`id`, `name`, `code`, `type`, `orderNum`, `createUser`, `createTime`, `updateUser`, `updateTime`) VALUES ('afd513fb-6f3f-43be-a28a-125e1a76a358', '外包工时-出差', 'outsource_manhour_on_business', 'wbgl', '10', NULL, NULL, NULL, NULL);
INSERT INTO   `sys_workflow` (`id`, `name`, `code`, `type`, `orderNum`, `createUser`, `createTime`, `updateUser`, `updateTime`) VALUES ('c4919d97-3d56-46df-91df-6d47c1f2c331', '低值易耗-资产申请', 'lowvalue_asset_apply', 'zcgl', '13', NULL, NULL, NULL, NULL);
INSERT INTO   `sys_workflow` (`id`, `name`, `code`, `type`, `orderNum`, `createUser`, `createTime`, `updateUser`, `updateTime`) VALUES ('e0a6b73d-8d8c-4845-80eb-460c10defe2f', '外包人员-退场', 'outsource_person_exit', 'wbgl', '6', NULL, NULL, NULL, NULL);
INSERT INTO   `sys_workflow` (`id`, `name`, `code`, `type`, `orderNum`, `createUser`, `createTime`, `updateUser`, `updateTime`) VALUES ('e90bb592-0d76-4e66-83f3-2d47adbed475', '合同关闭', 'supplier_agreement_close', 'gysgl', '1', NULL, NULL, '[admin]admin', '2016-02-15 17:03:20');
INSERT INTO   `sys_workflow` (`id`, `name`, `code`, `type`, `orderNum`, `createUser`, `createTime`, `updateUser`, `updateTime`) VALUES ('f0aa29f9-4a31-4090-bde8-d56c06cedb62', '供应商退出', 'supplier_quit', 'gysgl', '3', NULL, NULL, NULL, NULL);
INSERT INTO   `sys_workflow` (`id`, `name`, `code`, `type`, `orderNum`, `createUser`, `createTime`, `updateUser`, `updateTime`) VALUES ('f2c2970e-8fcb-4490-90ed-71a89bdde058', '外包人员-入场', 'outsource_person_enter', 'wbgl', '5', NULL, NULL, NULL, NULL);
INSERT INTO   `sys_workflow` (`id`, `name`, `code`, `type`, `orderNum`, `createUser`, `createTime`, `updateUser`, `updateTime`) VALUES ('f94f8e80-2f24-44d1-95b0-d4b2366e2607', '合同变更', 'supplier_agreement_change', 'gysgl', '2', NULL, NULL, '[admin]admin', '2016-02-02 17:22:27');
INSERT INTO   `sys_workflow` (`id`, `name`, `code`, `type`, `orderNum`, `createUser`, `createTime`, `updateUser`, `updateTime`) VALUES ('f94f8e80-2f24-44d1-95b0-d4b2366e2608', '实物资产报废', 'physical_asset_scrap', 'zcgl', '14', NULL, NULL, '[admin]admin', NULL);


#
# Data for table "sys_workflow_form"
#
INSERT INTO  `sys_workflow_form` (`id`, `workflowId`, `formItemName`, `formItemValue`, `formItemOrder`, `tableName`, `tableField`) VALUES ('2050637c-fc43-48ee-b926-4c38a82830d6', 'c4919d97-3d56-46df-91df-6d47c1f2c331', '申请单位', '2', '1', NULL, NULL);
INSERT INTO  `sys_workflow_form` (`id`, `workflowId`, `formItemName`, `formItemValue`, `formItemOrder`, `tableName`, `tableField`) VALUES ('3590198c-849d-4e87-b3ec-4fa3d9962e6f', 'e90bb592-0d76-4e66-83f3-2d47adbed475', '申请人所在部门', '1', '1', NULL, NULL);
INSERT INTO  `sys_workflow_form` (`id`, `workflowId`, `formItemName`, `formItemValue`, `formItemOrder`, `tableName`, `tableField`) VALUES ('4b10af3a-2e89-4f70-9de5-19df325e9cec', 'afd513fb-6f3f-43be-a28a-125e1a76a358', '申请人所在部门', '1', '1', NULL, NULL);
INSERT INTO  `sys_workflow_form` (`id`, `workflowId`, `formItemName`, `formItemValue`, `formItemOrder`, `tableName`, `tableField`) VALUES ('4b810029-2ec3-4fcc-b0c7-752a420f8de6', 'f0aa29f9-4a31-4090-bde8-d56c06cedb62', '申请人所在部门', '1', '1', NULL, NULL);
INSERT INTO  `sys_workflow_form` (`id`, `workflowId`, `formItemName`, `formItemValue`, `formItemOrder`, `tableName`, `tableField`) VALUES ('4b810029-2ec3-4fcc-b0c7-752a420f8de7', 'f0aa29f9-4a31-4090-bde8-d56c06cedb62', '申请单位', '2', '2', NULL, NULL);
INSERT INTO  `sys_workflow_form` (`id`, `workflowId`, `formItemName`, `formItemValue`, `formItemOrder`, `tableName`, `tableField`) VALUES ('73aa59ba-8d3f-44e2-9b13-d7b86543a637', 'f94f8e80-2f24-44d1-95b0-d4b2366e2607', '申请人所在部门', '1', '1', NULL, NULL);
INSERT INTO  `sys_workflow_form` (`id`, `workflowId`, `formItemName`, `formItemValue`, `formItemOrder`, `tableName`, `tableField`) VALUES ('88b27f18-1bc7-4486-a26b-a944b47e7de6', '8f1a70f1-b9b3-49e0-bedd-bc6d1028dd7e', '申请人所在部门', '1', '1', NULL, NULL);
INSERT INTO  `sys_workflow_form` (`id`, `workflowId`, `formItemName`, `formItemValue`, `formItemOrder`, `tableName`, `tableField`) VALUES ('99b1b239-ac73-4e17-a816-bbe9b88ef1f0', 'e0a6b73d-8d8c-4845-80eb-460c10defe2f', '申请人所在部门', '1', '1', NULL, NULL);
INSERT INTO  `sys_workflow_form` (`id`, `workflowId`, `formItemName`, `formItemValue`, `formItemOrder`, `tableName`, `tableField`) VALUES ('b8656b27-f3f8-4aa9-a7fa-b7275feeef8b', '16a93432-799d-4281-ad04-a9901d086432', '申请单位', '2', '1', NULL, NULL);
INSERT INTO  `sys_workflow_form` (`id`, `workflowId`, `formItemName`, `formItemValue`, `formItemOrder`, `tableName`, `tableField`) VALUES ('b8b4f32d-6390-4b45-8ab3-d565005fcd6a', '285e5e29-23f9-4da5-b33c-e9bdaea29275', '申请人所在部门', '1', '1', NULL, NULL);
INSERT INTO  `sys_workflow_form` (`id`, `workflowId`, `formItemName`, `formItemValue`, `formItemOrder`, `tableName`, `tableField`) VALUES ('cf9683a3-1d1f-4d78-bdb5-8d8c512d7b02', '7476b5f5-299b-4625-bc10-b027262e2106', '申请单位', '2', '1', NULL, NULL);
INSERT INTO  `sys_workflow_form` (`id`, `workflowId`, `formItemName`, `formItemValue`, `formItemOrder`, `tableName`, `tableField`) VALUES ('d4885ceb-61fb-4fb6-9896-b7df2bd643d3', '5d889186-7488-482f-9d66-509cf6424683', '申请人所在部门', '1', '1', NULL, NULL);
INSERT INTO  `sys_workflow_form` (`id`, `workflowId`, `formItemName`, `formItemValue`, `formItemOrder`, `tableName`, `tableField`) VALUES ('f06cd641-8075-42de-a389-f0065a3c8a30', '9b28d6e3-7edc-4ea6-9b8f-e7aa15b07d09', '申请人所在部门', '1', '1', NULL, NULL);
INSERT INTO  `sys_workflow_form` (`id`, `workflowId`, `formItemName`, `formItemValue`, `formItemOrder`, `tableName`, `tableField`) VALUES ('f85c20ac-509b-4536-bb94-24abe18395ba', 'f2c2970e-8fcb-4490-90ed-71a89bdde058', '申请人所在部门', '1', '1', NULL, NULL);
INSERT INTO  `sys_workflow_form` (`id`, `workflowId`, `formItemName`, `formItemValue`, `formItemOrder`, `tableName`, `tableField`) VALUES ('f85c20ac-509b-4536-bb94-24abe18395bb', 'f94f8e80-2f24-44d1-95b0-d4b2366e2608', '申请人所在部门', '1', '1', NULL, NULL);
INSERT INTO  `sys_workflow_form` (`id`, `workflowId`, `formItemName`, `formItemValue`, `formItemOrder`, `tableName`, `tableField`) VALUES ('f85c20ac-509b-4536-bb94-24abe18395bc', 'f94f8e80-2f24-44d1-95b0-d4b2366e2608', '申请单位', '2', '2', NULL, NULL);


