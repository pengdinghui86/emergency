
-- 定时任务执行记录表    2016-12-05
DROP TABLE IF EXISTS `qrtz_exec_info`;
create table `qrtz_exec_info` (
	`id` char (108),
	`taskName` varchar (300),
	`execTime` datetime ,
	`errorMsg` varchar (1500),
	`status` varchar (30),
	`transactor` varchar (300)
); 

DROP TABLE IF EXISTS QRTZ_JOB_LISTENERS;
DROP TABLE IF EXISTS QRTZ_TRIGGER_LISTENERS;
DROP TABLE IF EXISTS QRTZ_FIRED_TRIGGERS;
DROP TABLE IF EXISTS QRTZ_PAUSED_TRIGGER_GRPS;
DROP TABLE IF EXISTS QRTZ_SCHEDULER_STATE;
DROP TABLE IF EXISTS QRTZ_LOCKS;
DROP TABLE IF EXISTS QRTZ_SIMPLE_TRIGGERS;
DROP TABLE IF EXISTS QRTZ_CRON_TRIGGERS;
DROP TABLE IF EXISTS QRTZ_BLOB_TRIGGERS;
DROP TABLE IF EXISTS QRTZ_TRIGGERS;
DROP TABLE IF EXISTS QRTZ_JOB_DETAILS;
DROP TABLE IF EXISTS QRTZ_CALENDARS;


CREATE TABLE QRTZ_JOB_DETAILS
  (
    JOB_NAME  VARCHAR(200) NOT NULL,
    JOB_GROUP VARCHAR(200) NOT NULL,
    DESCRIPTION VARCHAR(250) NULL,
    JOB_CLASS_NAME   VARCHAR(250) NOT NULL,
    IS_DURABLE VARCHAR(1) NOT NULL,
    IS_VOLATILE VARCHAR(1) NOT NULL,
    IS_STATEFUL VARCHAR(1) NOT NULL,
    REQUESTS_RECOVERY VARCHAR(1) NOT NULL,
    JOB_DATA BLOB NULL,
    PRIMARY KEY (JOB_NAME,JOB_GROUP)
);

CREATE TABLE QRTZ_JOB_LISTENERS
  (
    JOB_NAME  VARCHAR(200) NOT NULL,
    JOB_GROUP VARCHAR(200) NOT NULL,
    JOB_LISTENER VARCHAR(200) NOT NULL,
    PRIMARY KEY (JOB_NAME,JOB_GROUP,JOB_LISTENER),
    FOREIGN KEY (JOB_NAME,JOB_GROUP)
        REFERENCES QRTZ_JOB_DETAILS(JOB_NAME,JOB_GROUP)
);

CREATE TABLE QRTZ_TRIGGERS
  (
    TRIGGER_NAME VARCHAR(200) NOT NULL,
    TRIGGER_GROUP VARCHAR(200) NOT NULL,
    JOB_NAME  VARCHAR(200) NOT NULL,
    JOB_GROUP VARCHAR(200) NOT NULL,
    IS_VOLATILE VARCHAR(1) NOT NULL,
    DESCRIPTION VARCHAR(250) NULL,
    NEXT_FIRE_TIME BIGINT(13) NULL,
    PREV_FIRE_TIME BIGINT(13) NULL,
    PRIORITY INTEGER NULL,
    TRIGGER_STATE VARCHAR(16) NOT NULL,
    TRIGGER_TYPE VARCHAR(8) NOT NULL,
    START_TIME BIGINT(13) NOT NULL,
    END_TIME BIGINT(13) NULL,
    CALENDAR_NAME VARCHAR(200) NULL,
    MISFIRE_INSTR SMALLINT(2) NULL,
    JOB_DATA BLOB NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (JOB_NAME,JOB_GROUP)
        REFERENCES QRTZ_JOB_DETAILS(JOB_NAME,JOB_GROUP)
);

CREATE TABLE QRTZ_SIMPLE_TRIGGERS
  (
    TRIGGER_NAME VARCHAR(200) NOT NULL,
    TRIGGER_GROUP VARCHAR(200) NOT NULL,
    REPEAT_COUNT BIGINT(7) NOT NULL,
    REPEAT_INTERVAL BIGINT(12) NOT NULL,
    TIMES_TRIGGERED BIGINT(10) NOT NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP)
        REFERENCES QRTZ_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);

CREATE TABLE QRTZ_CRON_TRIGGERS
  (
    TRIGGER_NAME VARCHAR(200) NOT NULL,
    TRIGGER_GROUP VARCHAR(200) NOT NULL,
    CRON_EXPRESSION VARCHAR(200) NOT NULL,
    TIME_ZONE_ID VARCHAR(80),
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP)
        REFERENCES QRTZ_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);

CREATE TABLE QRTZ_BLOB_TRIGGERS
  (
    TRIGGER_NAME VARCHAR(200) NOT NULL,
    TRIGGER_GROUP VARCHAR(200) NOT NULL,
    BLOB_DATA BLOB NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP)
        REFERENCES QRTZ_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);

CREATE TABLE QRTZ_TRIGGER_LISTENERS
  (
    TRIGGER_NAME  VARCHAR(200) NOT NULL,
    TRIGGER_GROUP VARCHAR(200) NOT NULL,
    TRIGGER_LISTENER VARCHAR(200) NOT NULL,
    PRIMARY KEY (TRIGGER_NAME,TRIGGER_GROUP,TRIGGER_LISTENER),
    FOREIGN KEY (TRIGGER_NAME,TRIGGER_GROUP)
        REFERENCES QRTZ_TRIGGERS(TRIGGER_NAME,TRIGGER_GROUP)
);


CREATE TABLE QRTZ_CALENDARS
  (
    CALENDAR_NAME  VARCHAR(200) NOT NULL,
    CALENDAR BLOB NOT NULL,
    PRIMARY KEY (CALENDAR_NAME)
);



CREATE TABLE QRTZ_PAUSED_TRIGGER_GRPS
  (
    TRIGGER_GROUP  VARCHAR(200) NOT NULL, 
    PRIMARY KEY (TRIGGER_GROUP)
);

CREATE TABLE QRTZ_FIRED_TRIGGERS
  (
    ENTRY_ID VARCHAR(95) NOT NULL,
    TRIGGER_NAME VARCHAR(200) NOT NULL,
    TRIGGER_GROUP VARCHAR(200) NOT NULL,
    IS_VOLATILE VARCHAR(1) NOT NULL,
    INSTANCE_NAME VARCHAR(200) NOT NULL,
    FIRED_TIME BIGINT(13) NOT NULL,
    PRIORITY INTEGER NOT NULL,
    STATE VARCHAR(16) NOT NULL,
    JOB_NAME VARCHAR(200) NULL,
    JOB_GROUP VARCHAR(200) NULL,
    IS_STATEFUL VARCHAR(1) NULL,
    REQUESTS_RECOVERY VARCHAR(1) NULL,
    PRIMARY KEY (ENTRY_ID)
);

CREATE TABLE QRTZ_SCHEDULER_STATE
  (
    INSTANCE_NAME VARCHAR(200) NOT NULL,
    LAST_CHECKIN_TIME BIGINT(13) NOT NULL,
    CHECKIN_INTERVAL BIGINT(13) NOT NULL,
    PRIMARY KEY (INSTANCE_NAME)
);

CREATE TABLE QRTZ_LOCKS
  (
    LOCK_NAME  VARCHAR(40) NOT NULL, 
    PRIMARY KEY (LOCK_NAME)
);


INSERT INTO QRTZ_LOCKS values('TRIGGER_ACCESS');
INSERT INTO QRTZ_LOCKS values('JOB_ACCESS');
INSERT INTO QRTZ_LOCKS values('CALENDAR_ACCESS');
INSERT INTO QRTZ_LOCKS values('STATE_ACCESS');
INSERT INTO QRTZ_LOCKS values('MISFIRE_ACCESS');


commit;


/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50627
Source Host           : localhost:3306
Source Database       : esc_oms

Target Server Type    : MYSQL
Target Server Version : 50627
File Encoding         : 65001

Date: 2016-12-08 11:55:23
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for sys_param
-- ----------------------------
DROP TABLE IF EXISTS `sys_param`;
CREATE TABLE `sys_param` (
  `id` char(36) NOT NULL,
  `name` varchar(128) NOT NULL COMMENT '名称',
  `value` varchar(128) NOT NULL,
  `paramType` char(128) NOT NULL,
  `backgroundColor` varchar(10) DEFAULT NULL COMMENT '背景颜色',
  `sort` int(11) DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL COMMENT '是否系统参数',
  `remark` varchar(255) DEFAULT NULL,
  `createUser` varchar(255) DEFAULT NULL COMMENT '创建人',
  `updateUser` varchar(255) DEFAULT NULL COMMENT '修改人',
  `updateTime` timestamp NULL DEFAULT NULL,
  `createTime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统参数表';

-- ----------------------------
-- Records of sys_param
-- ----------------------------
INSERT INTO `sys_param` VALUES ('01e20396-b7b2-47ad-b157-0c85f739d0eb', '关闭', 'GB', 'riskState', null, '2', '1', null, '[admin]admin', '[admin]admin', '2016-02-01 16:00:02', '2016-02-01 16:00:02');
INSERT INTO `sys_param` VALUES ('02f431c6-5fb9-402c-9821-857507e97d45', 'CentOS', 'CentOS', 'systemClass', null, '2', '2', null, '孙明钱/BANK1029', '孙明钱/BANK1029', '2016-06-23 11:15:47', '2016-06-23 11:15:47');
INSERT INTO `sys_param` VALUES ('03a72d9e-a110-4e32-bd9a-2d2ad5e73202', '部分处理', 'part', 'faultHandleResult', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-02-29 12:20:14', '2016-02-29 12:20:14');
INSERT INTO `sys_param` VALUES ('03abd11f-a863-4423-b677-b8a513547e2a', '操作日志', 'option', 'LogType', null, '1', '1', null, null, null, '2015-12-30 12:30:33', '2015-12-30 12:23:59');
INSERT INTO `sys_param` VALUES ('03e20438-b284-4e43-8e8c-38f2b5ad4ede', '服务监控', 'serviceMonitoring', 'templateConfigurationType', null, '10', '2', '服务监控', '[admin]admin', '[admin]admin', '2016-01-12 16:45:59', '2016-01-12 16:36:59');
INSERT INTO `sys_param` VALUES ('0426584f-0adf-4c55-baaf-f4e60892ea51', '已评价待关闭', '1', 'agreementEvaluateConfigurationStatus', '#f0ad4e', '2', '1', '已评价待关闭', '[admin]admin', 'admin/admin', '2016-12-08 11:29:08', '2016-03-26 16:31:39');
INSERT INTO `sys_param` VALUES ('0475811d-185a-4e83-ade7-8840a229107f', 'R2', 'r2', 'projectGrade', null, '2', '2', null, '[admin]admin', '[admin]admin', '2016-02-22 09:51:40', '2016-02-22 09:51:40');
INSERT INTO `sys_param` VALUES ('0498a99e-14b2-43b1-80b5-cfdcaf86f3a1', '服务水平监控', '2', 'serviceMonitoringType', null, '2', '2', '服务水平监控', '[admin]admin', '[admin]admin', '2016-03-03 10:42:13', '2016-03-03 10:42:13');
INSERT INTO `sys_param` VALUES ('0500565e-9d1c-4da4-8dc5-2a6c85b3307b', '每月', '1', 'assetsWarnConfigCycle', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:20:42', '2016-03-23 12:20:42');
INSERT INTO `sys_param` VALUES ('0516a9d3-23cb-45ee-9981-40e0e295ec92', '汉族', '汉族', 'nationType', null, '1', '2', null, null, null, '2015-12-30 11:32:59', '2015-12-30 11:32:59');
INSERT INTO `sys_param` VALUES ('059626fc-6fd8-40b2-9840-2e5b2c6364f9', '外包合同及要求', '5', 'specialAudit', null, '5', '2', '外包合同及要求', '[admin]admin', '[admin]admin', '2016-02-24 11:21:14', '2016-02-24 10:49:19');
INSERT INTO `sys_param` VALUES ('05a10b5c-dbec-4498-a15a-f49598e66b58', '项目经理', 'pm', 'projectRole', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-02-22 17:42:55', '2016-02-22 17:42:55');
INSERT INTO `sys_param` VALUES ('0649f391-18d2-4af3-a7c9-04638bc99818', '合格', '3', 'agreementEvaluateResult', null, '3', '2', '合格', '[admin]admin', '[admin]admin', '2016-03-15 19:51:01', '2016-03-15 19:51:01');
INSERT INTO `sys_param` VALUES ('082742d7-9082-487d-90b0-83fec7e2177b', '优秀', '1', 'agreementEvaluate', null, '1', '2', '优秀', '[admin]admin', '[admin]admin', '2016-03-15 19:47:04', '2016-03-15 19:47:04');
INSERT INTO `sys_param` VALUES ('09308680-b49d-438e-a4de-40d9172de937', '不通过', '2', 'interviewResult', null, '2', '1', '', 'admin/admin', 'admin/admin', '2016-07-29 11:11:23', '2016-07-29 11:11:23');
INSERT INTO `sys_param` VALUES ('09332587-99ea-4f55-a60b-2832543e90b3', '个人', '1', 'lowvalueType', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:03:27', '2016-03-23 12:03:27');
INSERT INTO `sys_param` VALUES ('096ec88f-a7ab-4768-9764-4b0b9eecca77', '代理公司', '1', 'supplierRelation', null, '1', '2', null, '[admin]admin', '[admin]admin', '2016-01-12 18:58:23', '2016-01-12 18:57:23');
INSERT INTO `sys_param` VALUES ('0a57401d-5349-4ac5-876d-a2093146d4f1', '履行中【超时】', '3', 'agreementStatus', null, '3', '1', null, '[admin]admin', 'admin/admin', '2016-04-12 09:09:41', '2016-01-25 11:08:22');
INSERT INTO `sys_param` VALUES ('0b05ec04-71b1-4f14-a151-4b8cc3e26c18', '功能元素', '2', 'resourceType', null, '2', '1', null, null, null, '2015-12-21 14:23:49', '2015-12-21 14:23:49');
INSERT INTO `sys_param` VALUES ('0b6693a2-cf5f-4864-8b09-2e1f8ad09d5d', '批量删除', 'deletes', 'LogOpType', null, '4', '1', null, 'admin/admin', 'admin/admin', '2016-05-04 15:21:06', '2016-05-04 15:21:06');
INSERT INTO `sys_param` VALUES ('0cb5c59e-99dc-49ea-9ef7-d7d485e5273f', '未确认', '0', 'lowvalueReceptionDetailConfirmStatus', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:08:42', '2016-03-23 12:08:42');
INSERT INTO `sys_param` VALUES ('0cbe4f71-3a9e-43db-8b5c-52fcfec5a14f', '阻塞', '4', 'triggerState', null, '5', '1', '阻塞', null, null, '2015-12-22 10:13:09', '2015-12-22 10:13:09');
INSERT INTO `sys_param` VALUES ('0e68b383-dac1-4352-87d3-91616b814930', '审批中', '3', 'personEnterStatus', null, '3', '1', null, 'admin/admin', 'admin/admin', '2016-07-12 19:48:31', '2016-07-12 19:48:31');
INSERT INTO `sys_param` VALUES ('0f50415d-77e0-4451-aedc-79edd432c8e1', '供应商管理', 'supplier', 'SystemModule', null, '2', '1', null, '[admin]admin', '[admin]admin', '2016-02-15 16:48:09', '2016-02-15 16:48:09');
INSERT INTO `sys_param` VALUES ('1034aa67-f97e-43cb-bc68-dee83831a79e', '软件类', '2', 'belongIndustries', null, '2', '2', null, '[admin]admin', '[admin]admin', '2016-02-17 15:45:55', '2016-02-17 15:45:55');
INSERT INTO `sys_param` VALUES ('106947c2-afd2-4809-b770-8f0742f0d2bd', '删除', 'delete', 'LogOpType', null, '3', '1', null, 'admin/admin', 'admin/admin', '2016-05-04 15:20:51', '2016-05-04 15:20:51');
INSERT INTO `sys_param` VALUES ('10a9bfce-ede2-49c1-9f27-83c4a4ea3609', '否', '0', 'YesNo', null, '2', '2', null, null, null, '2015-12-29 11:47:26', '2015-12-21 19:40:12');
INSERT INTO `sys_param` VALUES ('10cc788a-4a2c-4777-b79e-9fbe29be5184', '属于', '2', 'associationRelation', null, '2', '2', null, 'admin/admin', '柳青青/BANK2000', '2016-09-06 10:10:32', '2016-09-06 09:55:57');
INSERT INTO `sys_param` VALUES ('11770dfb-54d6-45b2-8ecf-676987e4c085', '入场', '1', 'recordType', null, '1', '1', null, '[admin]admin', '[admin]admin', '2016-02-23 17:31:59', '2016-02-23 17:31:59');
INSERT INTO `sys_param` VALUES ('11782047-8bf0-4754-8bdf-221000925a69', '待分配', '2', 'borrowStatus', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:19:47', '2016-03-23 12:19:47');
INSERT INTO `sys_param` VALUES ('11a86773-6342-41cd-a082-98302d9718d3', '审批中', '2', 'lowvalueApplyStatus', null, '2', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:12:23', '2016-03-23 12:11:15');
INSERT INTO `sys_param` VALUES ('11c1c7c1-71e5-40b3-9bec-667adbf03aa1', '各分行', 'GFH', 'impactScope', null, '3', '2', null, '[admin]admin', '[admin]admin', '2016-03-15 11:06:16', '2016-03-15 11:06:16');
INSERT INTO `sys_param` VALUES ('127c9d4a-ee8d-4ad6-9348-bbf53496159c', '待确认', '7', 'personQuitStatus', null, '7', '1', null, 'admin/admin', 'admin/admin', '2016-07-19 11:26:53', '2016-07-14 11:47:52');
INSERT INTO `sys_param` VALUES ('12a8cd28-ed29-425b-99ab-ff2153afe0d8', '办公用品', 'office', 'lowvalueCategory', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-03-04 15:26:46', '2016-03-04 15:26:46');
INSERT INTO `sys_param` VALUES ('1321fcee-8f0f-4969-a9a5-32eb1e4209d5', '合格供应商', 'hggys', 'supplierLevel', null, '3', '2', null, null, null, '2016-01-11 10:47:16', '2016-01-05 15:12:38');
INSERT INTO `sys_param` VALUES ('13ef93d9-ad46-4236-86f5-8f426c15b066', '不严重', 'BYZ', 'severity', null, '5', '2', null, '[admin]admin', '[admin]admin', '2016-03-15 11:08:39', '2016-03-15 11:08:39');
INSERT INTO `sys_param` VALUES ('14307b00-b6ac-4fb6-83f7-f9c13f152cf9', '待合同执行', '4', 'purchaseStatus', null, '4', '1', null, '[admin]admin', '[admin]admin', '2016-03-01 10:08:54', '2016-01-25 11:01:50');
INSERT INTO `sys_param` VALUES ('14abc94a-1502-41af-9103-510f0982b220', '不通过', '2', 'riskOverallEvaluateResult', null, '2', '2', '不通过', '[admin]admin', '[admin]admin', '2016-03-24 15:39:34', '2016-03-24 15:39:34');
INSERT INTO `sys_param` VALUES ('14e3005d-43f1-11e6-ad17-fce33ca489b2', '驳回', '4', 'overtimeStatus', null, '4', '1', null, '[admin]admin', '[admin]admin', '2016-03-28 14:40:43', '2016-03-08 15:02:19');
INSERT INTO `sys_param` VALUES ('14e4318f-5095-42b0-b654-df09df6b69ce', '驳回', '5', 'supplierBlackListState', null, '5', '2', null, 'admin/admin', 'admin/admin', '2016-04-23 15:02:19', '2016-04-23 15:01:27');
INSERT INTO `sys_param` VALUES ('14e4d3b2-43f1-11e6-ad17-fce33ca489b2', '待提交', '1', 'overtimeStatus', null, '1', '1', null, '[admin]admin', '[admin]admin', '2016-03-08 15:01:40', '2016-03-08 15:01:40');
INSERT INTO `sys_param` VALUES ('14e765d3-43f1-11e6-ad17-fce33ca489b2', '被终止', '6', 'overtimeStatus', null, '6', '1', null, 'admin/admin', 'admin/admin', '2016-05-19 20:12:18', '2016-05-19 20:12:18');
INSERT INTO `sys_param` VALUES ('14e9da4e-43f1-11e6-ad17-fce33ca489b2', '审批中', '3', 'overtimeStatus', null, '3', '1', null, '[admin]admin', '[admin]admin', '2016-03-28 17:10:00', '2016-03-08 15:02:05');
INSERT INTO `sys_param` VALUES ('14ec50d3-43f1-11e6-ad17-fce33ca489b2', '待审批', '2', 'overtimeStatus', null, '2', '1', null, '[admin]admin', 'admin/admin', '2016-05-05 19:01:54', '2016-03-08 15:01:52');
INSERT INTO `sys_param` VALUES ('14eeb3a4-43f1-11e6-ad17-fce33ca489b2', '已完成', '5', 'overtimeStatus', null, '5', '1', null, '[admin]admin', '柳青青/BANK2000', '2016-10-25 11:25:54', '2016-03-28 17:10:13');
INSERT INTO `sys_param` VALUES ('152f3d22-c286-4b57-ae5d-6fa78341201b', '使用中', '2', 'assetsStatus', null, '2', '2', null, '孙明钱/BANK1029', '孙明钱/BANK1029', '2016-06-24 12:17:11', '2016-06-24 12:17:11');
INSERT INTO `sys_param` VALUES ('15889c87-d7f6-4f7e-a5fc-88310dc6c2e2', '待确认', '5', 'assetApplicationStatus', null, '5', '1', null, '[admin]admin', '[admin]admin', '2016-03-26 16:31:45', '2016-03-26 15:03:06');
INSERT INTO `sys_param` VALUES ('15e7d2cd-6215-4a1e-883c-f2b9ffe47958', '不合格', '5', 'agreementEvaluateResult', null, '5', '2', '不合格', '[admin]admin', '[admin]admin', '2016-03-15 19:51:18', '2016-03-15 19:51:18');
INSERT INTO `sys_param` VALUES ('165e6d6d-0d8e-41c7-b52b-b76949d93096', '小学', 'xx', 'educationalType', null, '8', '2', null, 'admin/admin', 'admin/admin', '2016-07-25 11:47:39', '2016-07-25 11:47:39');
INSERT INTO `sys_param` VALUES ('1702ddce-5b17-41f4-8017-990cb83ee750', '待提交', '0', 'lowvalueApplyStatus', null, '0', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:12:32', '2016-03-23 12:10:41');
INSERT INTO `sys_param` VALUES ('1804be75-2c0f-4edf-a3de-9f7d3510deac', '待审批', '1', 'assetApplicationStatus', null, '1', '1', null, '[FB0001]廖裕卿', '[admin]admin', '2016-03-26 16:30:37', '2016-03-24 17:39:54');
INSERT INTO `sys_param` VALUES ('18671ec9-50e8-429a-8eae-256a7445b83f', '待招标', '1', 'purchaseStatus', null, '1', '1', null, '[admin]admin', '[admin]admin', '2016-03-01 10:08:20', '2016-01-25 11:01:23');
INSERT INTO `sys_param` VALUES ('19220911-d3cd-4af3-a060-30ccee9bb818', '登录日志', 'login', 'LogType', null, '2', '1', null, null, null, '2015-12-30 12:30:33', '2015-12-30 12:24:16');
INSERT INTO `sys_param` VALUES ('1a6c6f37-b60a-4340-9f3e-01c53f64f567', '外包审计-专项审计', 'specialAudit', 'riskAssessment', null, '3', '1', '外包审计-专项审计', '[admin]admin', '[admin]admin', '2016-02-24 11:41:02', '2016-01-12 17:05:44');
INSERT INTO `sys_param` VALUES ('1cb441fe-432e-4f04-8b6a-3c1665262e38', '待确认', '5', 'lowvalueApplyStatus', null, '5', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:13:01', '2016-03-23 12:12:03');
INSERT INTO `sys_param` VALUES ('1dd7ab4a-4859-4854-9807-a6820803512d', '预登记', '1', 'assetsRegistStatus', null, '1', '2', null, 'admin/admin', 'admin/admin', '2016-07-02 11:39:31', '2016-07-02 11:39:31');
INSERT INTO `sys_param` VALUES ('1e04ca1d-b051-431c-8c65-a9008d633044', '待确定供应商', '2', 'purchaseStatus', null, '2', '1', null, '[admin]admin', '[admin]admin', '2016-03-01 10:08:31', '2016-01-25 11:01:31');
INSERT INTO `sys_param` VALUES ('1e0be7e1-009c-4eb9-b0a6-ddbc7ce67499', '通过', '1', 'duediligenceEvaluateThirdResult', null, '1', '2', '通过', 'admin/admin', 'admin/admin', '2016-04-28 18:41:28', '2016-04-28 18:41:28');
INSERT INTO `sys_param` VALUES ('1e1be058-e12a-4757-89a4-9fabdc22c2e8', '尽职调查', 'dueDiligence', 'templateConfigurationType', null, '9', '2', '尽职调查', '[admin]admin', '[admin]admin', '2016-01-12 16:45:39', '2016-01-12 16:36:20');
INSERT INTO `sys_param` VALUES ('2003e733-0d08-4b7b-ab12-9433bcbd5c46', '业务参数', '2', 'paramType', null, '2', '1', null, 'admin/admin', 'admin/admin', '2016-04-07 18:03:10', '2016-04-07 18:03:10');
INSERT INTO `sys_param` VALUES ('20196455-09f1-43fa-90bd-179c58d9daca', '完成', '6', 'purchaseStatus', null, '6', '1', null, '[admin]admin', '[admin]admin', '2016-03-30 16:59:28', '2016-03-30 16:59:28');
INSERT INTO `sys_param` VALUES ('203d3270-167f-4dc9-8fef-326bad44b382', '已确认', '3', 'lowvalueReceptionStatus', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:06:45', '2016-03-23 12:06:45');
INSERT INTO `sys_param` VALUES ('20440b2d-27b6-454f-b8f9-16dded3fd3f8', '已归还待确认', '2', 'borrowDetailStatus', null, '2', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:23:42', '2016-03-23 12:24:25');
INSERT INTO `sys_param` VALUES ('216e7fd8-aaba-48da-87f9-9dfdab3d71dd', '财务风险', 'CWFX', 'riskType', null, '1', '2', null, '[admin]admin', '[admin]admin', '2016-01-12 17:12:40', '2016-01-12 17:13:21');
INSERT INTO `sys_param` VALUES ('222c1efb-63b1-4b0e-b7ee-7aeef450b87a', '待发放', '1', 'lowvalueApplyDetailStatus', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:16:31', '2016-03-23 12:16:31');
INSERT INTO `sys_param` VALUES ('22330bb1-6448-4319-b14d-dd820aae6bdd', '工程类', '5', 'agreementCategory', null, '5', '2', null, '[admin]admin', '[admin]admin', '2016-01-26 09:14:03', '2016-01-26 09:14:03');
INSERT INTO `sys_param` VALUES ('2243fdfb-1149-4b10-b38f-33556f32c881', '审批中', '2', 'assetApplicationStatus', null, '2', '1', null, '[FB0001]廖裕卿', '[admin]admin', '2016-03-26 16:30:51', '2016-03-24 17:40:04');
INSERT INTO `sys_param` VALUES ('22f33494-26ac-4dbd-8b8d-beaa140d8d36', '个人', '1', 'projectPerformanceEvaluatorType', null, '1', '1', '个人', 'admin/admin', 'admin/admin', '2016-04-12 17:56:15', '2016-04-12 17:56:15');
INSERT INTO `sys_param` VALUES ('23de28da-2e78-48b1-b271-3de3f6f83dbd', '总行', 'ZH', 'impactScope', null, '2', '2', null, '[admin]admin', '[admin]admin', '2016-03-15 11:05:53', '2016-03-15 11:05:53');
INSERT INTO `sys_param` VALUES ('240ec82c-ab07-493a-88b7-2f3950acb5f2', 'Redhat Linux', 'Redhat Linux', 'systemClass', null, '4', '2', null, '孙明钱/BANK1029', '孙明钱/BANK1029', '2016-06-23 11:21:47', '2016-06-23 11:21:47');
INSERT INTO `sys_param` VALUES ('2414048b-bcfe-4610-95a3-114893c71d19', '电话', '4', 'messageModel', null, '4', '2', null, 'admin/admin', 'admin/admin', '2016-05-24 17:49:33', '2016-05-24 17:49:33');
INSERT INTO `sys_param` VALUES ('24d13393-eaa6-4af5-95dd-278ade0c4b2d', '弃权', '3', 'riskImportantEvaluateResult', null, '3', '2', '弃权', '[admin]admin', '[admin]admin', '2016-03-24 15:49:44', '2016-03-24 15:49:44');
INSERT INTO `sys_param` VALUES ('256372ab-7cce-4665-833d-ae8eee56481d', '病假', '6', 'vacationType', null, '6', '1', null, 'admin/admin', 'admin/admin', '2016-07-11 15:44:13', '2016-07-11 15:44:13');
INSERT INTO `sys_param` VALUES ('25651895-0a89-400d-a1c1-5dfe1ef32e5a', '暂停', '1', 'serviceMonitoringStatus', null, '2', '1', '禁用', '[admin]admin', '[admin]admin', '2016-03-03 11:26:58', '2016-03-03 10:43:22');
INSERT INTO `sys_param` VALUES ('258c6499-a3ad-4605-be20-f5dc423476c8', '甲方', '3', 'patrolObjectType', null, '3', '1', null, 'admin/admin', 'admin/admin', '2016-07-05 17:02:45', '2016-07-05 17:02:36');
INSERT INTO `sys_param` VALUES ('25b7acd3-9baa-49c7-ae2b-0681c8a1aa11', '重点供应商风险评估', 'riskAssessmentIsTheKeySuppliers', 'riskAssessment', null, '2', '1', '重点供应商风险评估', '[admin]admin', '[admin]admin', '2016-01-12 17:04:37', '2016-01-12 17:04:37');
INSERT INTO `sys_param` VALUES ('25ba0637-747f-4707-ab53-32a7561f6925', '未使用', 'WSY', 'assetSparePartsUserStatus', null, '1', '1', null, 'admin/admin', 'admin/admin', '2016-05-12 12:26:45', '2016-05-12 12:26:45');
INSERT INTO `sys_param` VALUES ('25bc12ed-cf6e-485a-970e-0ba9a48d8e22', '个人', '1', 'supplierPerformanceEvaluatorType', null, '1', '1', '个人', '[admin]admin', '[admin]admin', '2016-03-23 12:21:21', '2016-03-23 12:21:21');
INSERT INTO `sys_param` VALUES ('26183dd6-18d9-4f25-991d-782b892cd00e', '待分发', '4', 'recruitmentApplicationStatus', null, '5', '1', '', 'admin/admin', 'admin/admin', '2016-07-29 15:18:32', '2016-07-29 15:18:32');
INSERT INTO `sys_param` VALUES ('26c86efa-0bba-47d7-83db-1bfb1bfadc2a', '附属合同', '1', 'agreementRelation', null, '1', '2', null, '[admin]admin', '[admin]admin', '2016-02-24 20:25:31', '2016-02-24 20:25:31');
INSERT INTO `sys_param` VALUES ('287126c9-194d-49eb-b57a-22671cb2c282', '通过', '1', 'externalManagerEvaluateResult', null, '1', '2', '通过', '[admin]admin', 'admin/admin', '2016-12-08 11:43:10', '2016-03-24 16:30:11');
INSERT INTO `sys_param` VALUES ('28f5de7d-3e48-410c-9454-4c86e0df1988', '维保', '3', 'assetsAgreementType', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-03-23 12:19:09', '2016-03-23 12:19:09');
INSERT INTO `sys_param` VALUES ('298b489f-3808-4bdc-b0e0-e04ed7daa8fa', '待发放', '3', 'lowvalueApplyStatus', null, '3', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:12:16', '2016-03-23 12:11:34');
INSERT INTO `sys_param` VALUES ('29e6b186-7653-4bcd-a5ec-fb070bb22938', '待通知', '4', 'personExitStatus', null, '4', '1', null, 'admin/admin', 'admin/admin', '2016-07-19 11:25:32', '2016-07-14 11:44:57');
INSERT INTO `sys_param` VALUES ('2b15b80b-0c05-4a3b-a709-9b153870d08f', '安全违规', '1', 'supplierBlackReason', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-03-30 10:11:25', '2016-03-30 10:11:25');
INSERT INTO `sys_param` VALUES ('2b7c71c2-3c2d-45b6-b873-4a5d08d12f76', 'R1', 'r1', 'projectRiskLevel', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-02-23 11:51:47', '2016-02-23 11:51:47');
INSERT INTO `sys_param` VALUES ('2bb7c226-71f9-4e48-a892-3b2e35c9bc02', '已完成', '3', 'supplierQuitStatus', null, '3', '1', null, '[admin]admin', '[admin]admin', '2016-03-21 15:12:43', '2016-03-21 15:12:43');
INSERT INTO `sys_param` VALUES ('2beb7bfb-9341-4235-bdd9-f45d70a55e85', '新增', 'add', 'recruitmentApplicationReason', null, '2', '2', null, 'admin/admin', 'admin/admin', '2016-08-20 14:17:37', '2016-08-20 14:17:37');
INSERT INTO `sys_param` VALUES ('2e6f56a3-788e-48c6-9b76-57e8a084682a', '信息科技外包战略', '1', 'specialAudit', null, '1', '2', '信息科技外包战略', '[admin]admin', '[admin]admin', '2016-02-24 11:21:14', '2016-02-24 10:48:32');
INSERT INTO `sys_param` VALUES ('2e9528cc-5d44-40a9-a543-1438d5a9fa8d', '闲置', '3', 'assetsStatus', null, '3', '2', null, '孙明钱/BANK1029', '孙明钱/BANK1029', '2016-06-24 12:18:11', '2016-06-24 12:18:11');
INSERT INTO `sys_param` VALUES ('2e954d74-feb1-42d7-be80-c2e1973aa33d', '待审批', '1', 'assetRepairStatus', null, '1', '1', null, '[admin]admin', '[admin]admin', '2016-03-27 15:09:55', '2016-03-27 15:09:55');
INSERT INTO `sys_param` VALUES ('2ec11921-69ec-476a-9bb1-d54a81356860', '完成', '4', 'faultStatus', null, '4', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:00:49', '2016-03-23 12:00:49');
INSERT INTO `sys_param` VALUES ('2f66d85e-5665-4e60-8314-e0de2cfc4863', '招标采购', '1', 'purchaseType', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-01-23 16:42:43', '2016-01-23 16:42:43');
INSERT INTO `sys_param` VALUES ('3045828d-5654-4516-a7e3-adf6dc7df140', '弃权', '3', 'securityCheckEvaluateResult', null, '3', '2', '弃权', '[admin]admin', '[admin]admin', '2016-03-24 16:22:40', '2016-03-24 16:22:40');
INSERT INTO `sys_param` VALUES ('30bf6bf5-bfc3-4fae-b900-86634b7d1d9b', '甲方负责人', 'aleader', 'projectRole', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-01-21 18:56:45', '2016-01-21 18:56:45');
INSERT INTO `sys_param` VALUES ('30ee43c8-289c-4849-86ad-42bd0c01f064', '驳回', '-1', 'lowvalueApplyStatus', null, '0', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:12:45', '2016-03-23 12:10:27');
INSERT INTO `sys_param` VALUES ('311949af-297f-46e9-8a38-c31cf054d20f', '已评估待关闭', '1', 'accessEvaluateConfigurationStatus', '#f0ad4e', '2', '1', '已评估待关闭', '[admin]admin', 'admin/admin', '2016-12-07 17:48:16', '2016-01-21 19:00:02');
INSERT INTO `sys_param` VALUES ('31a24398-ee2c-401e-ad1a-6bf984cf61c7', '岗位（组织角色）', '2', 'roleType', null, null, '1', null, null, null, '2015-12-17 18:24:33', '2015-12-17 18:24:33');
INSERT INTO `sys_param` VALUES ('31d54b92-5048-4506-81e1-c3c7ff2931eb', 'R1', 'r1', 'projectGrade', null, '1', '2', null, '[admin]admin', '[admin]admin', '2016-02-22 09:51:09', '2016-02-22 09:51:24');
INSERT INTO `sys_param` VALUES ('320d7916-6206-4340-a857-9d66ef75220e', '驳回', '4', 'agreementChangeStatus', null, '4', '1', null, '[admin]admin', '[admin]admin', '2016-03-28 14:40:43', '2016-03-08 15:02:19');
INSERT INTO `sys_param` VALUES ('321295c2-35f6-4dc8-8da3-6cfeea7e56c3', '完成', '5', 'recruitmentApplicationDetailStatus', null, '5', '1', '', 'admin/admin', 'admin/admin', '2016-08-01 10:28:35', '2016-08-01 10:28:35');
INSERT INTO `sys_param` VALUES ('3334e412-9eb9-413e-b20e-d5820bab9f22', 'C', 'C', 'supplierPerformanceResult', null, '3', '2', 'C', '[admin]admin', '[admin]admin', '2016-03-23 12:24:32', '2016-03-23 12:24:32');
INSERT INTO `sys_param` VALUES ('33ec671e-17d9-4382-ae8e-4aa703705fbb', '已确认', '3', 'borrowDetailStatus', null, '3', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:24:58', '2016-03-23 12:24:58');
INSERT INTO `sys_param` VALUES ('349dbc72-7eff-4a5e-aecb-acdf5c126638', '被终止', '8', 'lowvalueApplyStatus', null, null, '1', null, 'admin/admin', 'admin/admin', '2016-04-21 15:18:45', '2016-04-21 15:18:45');
INSERT INTO `sys_param` VALUES ('3555d848-5834-40e8-a79c-c46347b5f5f7', '终止', '-2', 'recruitmentApplicationStatus', null, '0', '1', '', 'admin/admin', 'admin/admin', '2016-08-16 20:51:00', '2016-07-29 15:16:33');
INSERT INTO `sys_param` VALUES ('35aaf0ba-771d-448f-bced-7c0f228c65ef', '事假', '3', 'vacationType', null, '3', '1', null, 'admin/admin', 'admin/admin', '2016-07-11 15:43:38', '2016-07-11 15:43:38');
INSERT INTO `sys_param` VALUES ('35c8e932-1916-4e6e-87c8-44890926f728', '维修中', '4', 'assetsStatus', null, '4', '2', null, '孙明钱/BANK1029', '孙明钱/BANK1029', '2016-06-24 12:20:11', '2016-06-24 12:20:11');
INSERT INTO `sys_param` VALUES ('35cfd084-08bf-48a1-b1fc-bc5062e5650a', '已关闭', '2', 'agreementEvaluateConfigurationStatus', '#5cb85c', '3', '1', '已关闭', '[admin]admin', 'admin/admin', '2016-12-08 11:29:12', '2016-03-26 16:31:56');
INSERT INTO `sys_param` VALUES ('360a1843-15cb-4fad-ac6b-42977aa45a2b', '个人', '2', 'faultIssueType', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-01-21 18:56:45', '2016-01-21 18:56:45');
INSERT INTO `sys_param` VALUES ('3630f010-d1f9-4533-a489-5952cb85639b', 'D', 'D', 'projectPerformanceResult', null, '4', '2', 'D', '[admin]admin', '[admin]admin', '2016-03-23 20:03:33', '2016-03-23 20:03:33');
INSERT INTO `sys_param` VALUES ('364650db-5062-4e66-8e5d-a9d8882c5b38', '发放', 'grant', 'LogOpType', null, '7', '1', null, 'admin/admin', 'admin/admin', '2016-05-04 15:42:37', '2016-05-04 15:42:37');
INSERT INTO `sys_param` VALUES ('3655b912-b5f0-42b5-bb26-cd79af283018', '确认中', '2', 'assetsInventoryStatus', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 10:52:07', '2016-03-23 10:46:20');
INSERT INTO `sys_param` VALUES ('36fbf666-3d99-4384-99f1-c11427f6aba8', '本部门', 'BBM', 'impactScope', null, '4', '2', null, '[admin]admin', '[admin]admin', '2016-03-15 11:06:30', '2016-03-15 11:06:30');
INSERT INTO `sys_param` VALUES ('37530623-39dd-42ac-90a6-41d2728eeaee', '软件采购', '2', 'purchaseCategory', null, '2', '2', null, '[admin]admin', '[admin]admin', '2016-01-26 09:12:12', '2016-01-26 09:12:12');
INSERT INTO `sys_param` VALUES ('375bbfb7-0440-4eb4-8906-9aed8ae5a823', '驳回', '-1', 'lowvalueReceptionDetailConfirmStatus', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:08:30', '2016-03-23 12:08:30');
INSERT INTO `sys_param` VALUES ('379994d5-1791-41b4-b711-2c691c8837f5', '外包商尽职调查', '4', 'specialAudit', null, '4', '2', '外包商尽职调查', '[admin]admin', '[admin]admin', '2016-02-24 11:21:14', '2016-02-24 10:49:09');
INSERT INTO `sys_param` VALUES ('37cd6de2-17a6-416b-b9f1-c35f53c8abbc', '面授式', 'MSS', 'secureTrainType', null, '2', '2', null, '[admin]admin', '[admin]admin', '2016-03-15 11:04:19', '2016-03-15 11:04:19');
INSERT INTO `sys_param` VALUES ('384db684-472c-461d-b45b-b170b29ecf50', '角色', '2', 'projectPerformanceEvaluatorType', null, '2', '1', '角色', 'admin/admin', 'admin/admin', '2016-04-12 17:56:26', '2016-04-12 17:56:26');
INSERT INTO `sys_param` VALUES ('38c22b5c-2835-4c1d-8b74-a28aa184c390', '自评估', 'selfAssessment', 'safetyCheck', null, '1', '1', '自评估', '[admin]admin', '[admin]admin', '2016-01-12 17:02:44', '2016-01-12 17:02:44');
INSERT INTO `sys_param` VALUES ('38d0c4aa-e1ba-48c9-9b0e-fc09ab7a417c', '待评价', '0', 'agreementEvaluateStatus', '#d9534f', '2', '1', '待评价', '[admin]admin', 'admin/admin', '2016-12-08 11:28:12', '2016-03-26 16:35:46');
INSERT INTO `sys_param` VALUES ('3931d26b-6bf6-428b-bda7-f7b3458837ef', '应急培训', 'YJPX', 'communicateType', null, '1', '2', null, '[admin]admin', '[admin]admin', '2016-01-20 18:43:49', '2016-01-20 18:43:49');
INSERT INTO `sys_param` VALUES ('396f20ad-29ba-46c1-9c67-473bc478345f', '待审批', '2', 'personEnterStatus', null, '2', '1', null, 'admin/admin', 'admin/admin', '2016-07-14 17:59:33', '2016-07-12 19:48:08');
INSERT INTO `sys_param` VALUES ('3973a4ff-b4c6-4c44-937e-84656cddce20', '早退', '1', 'attendanceEndExceptionStatus', '#d9534f', '2', '1', '早退', 'admin/admin', 'admin/admin', '2016-12-08 10:32:24', '2016-07-28 11:34:55');
INSERT INTO `sys_param` VALUES ('39c8cc87-b40e-4d6f-a890-c26ed59b7048', '每周', '1', 'attendanceCycle', null, '1', '1', '每周', 'admin/admin', 'admin/admin', '2016-07-20 15:45:41', '2016-07-20 15:45:41');
INSERT INTO `sys_param` VALUES ('3a458d6c-96d4-4c8d-b83e-f6dd99a363af', '已填报', '2', 'manHourEditType', '#f0ad4e', '2', '1', '已填报', 'admin/admin', 'admin/admin', '2016-12-08 10:35:44', '2016-07-14 11:28:15');
INSERT INTO `sys_param` VALUES ('3a6448a4-57e4-4b63-b1ad-374908d1f1d9', '待审批', '1', 'lowvalueApplyStatus', null, '1', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:13:06', '2016-03-23 12:10:56');
INSERT INTO `sys_param` VALUES ('3a7319d6-2c27-4eea-b0f2-94ad086c7e00', '机构集中度风险管理', '9', 'specialAudit', null, '9', '2', '机构集中度风险管理', '[admin]admin', '[admin]admin', '2016-02-24 11:21:14', '2016-02-24 10:50:03');
INSERT INTO `sys_param` VALUES ('3b3de325-e551-4010-abee-8d082842efc6', '通过', '1', 'riskAuditEvaluateResult', null, '1', '2', '通过', '[admin]admin', '[admin]admin', '2016-03-24 15:59:37', '2016-03-24 15:59:37');
INSERT INTO `sys_param` VALUES ('3b429287-dd2a-4062-a09a-614e377b796d', '创建风险', '1', 'projectRiskStatus', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 11:56:15', '2016-03-23 11:56:15');
INSERT INTO `sys_param` VALUES ('3b7eb462-2f94-4515-a56c-1a48e5ed61ad', '通过', '1', 'riskOverallEvaluateResult', null, '1', '2', '通过', '[admin]admin', '[admin]admin', '2016-03-24 15:39:25', '2016-03-24 15:39:25');
INSERT INTO `sys_param` VALUES ('3b8cff17-38c0-445b-a991-6b55ea25ba22', '周末', '2', 'festivalType', null, '2', '2', '周末', 'admin/admin', 'admin/admin', '2016-07-18 10:43:42', '2016-07-11 09:47:55');
INSERT INTO `sys_param` VALUES ('3bd52a43-e3d2-4c05-800d-28e665f36dff', 'R2', 'R2', 'riskLevel', null, '2', '2', null, '[admin]admin', '[admin]admin', '2016-01-12 17:15:05', '2016-01-12 17:15:05');
INSERT INTO `sys_param` VALUES ('3c5bca04-6afd-4ed2-806e-0d56848cac5d', '安全检查', 'safetyCheck', 'templateConfigurationType', null, '8', '2', '安全检查', '[admin]admin', '[admin]admin', '2016-01-12 16:45:14', '2016-01-12 16:36:10');
INSERT INTO `sys_param` VALUES ('3c61f9a0-d367-4ec7-b7a6-0d9f59d090f0', '技术风险', 'tech', 'projectRiskCategory', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-02-23 11:50:59', '2016-02-23 11:50:59');
INSERT INTO `sys_param` VALUES ('3c9740de-48ba-43fe-b6d8-1aec687baf85', '待推荐', '1', 'recruitmentApplicationDetailStatus', null, '1', '1', '', 'admin/admin', 'admin/admin', '2016-08-01 10:28:09', '2016-08-01 10:28:09');
INSERT INTO `sys_param` VALUES ('3d4202e3-6d8c-4ccf-a5e5-8f62079c16ce', '已评价', '1', 'agreementEvaluateStatus', '#5cb85c', '1', '1', '已评价', '[admin]admin', 'admin/admin', '2016-12-08 11:28:08', '2016-03-26 16:35:33');
INSERT INTO `sys_param` VALUES ('3d683146-2b87-4033-8152-c83f56081caf', '类别退出', '1', 'supplierQuitType', null, '1', '2', null, 'admin/admin', 'admin/admin', '2016-04-11 15:23:13', '2016-04-11 15:23:13');
INSERT INTO `sys_param` VALUES ('3dbfcb30-b4bb-498a-aba6-0a26e3b10c14', '待评价', '5', 'agreementCloseStatus', null, '5', '1', '审批完成就是待评价', '[admin]admin', '[admin]admin', '2016-03-09 15:44:40', '2016-03-09 15:44:40');
INSERT INTO `sys_param` VALUES ('3e757fe2-29d3-456c-af75-5d936c03c97e', '确认中', '3', 'inventoryConfirmStatus', null, null, '1', null, 'admin/admin', 'admin/admin', '2016-06-29 14:21:30', '2016-03-23 10:53:50');
INSERT INTO `sys_param` VALUES ('3f4125ea-f5cf-43d4-a574-833535f7ef83', '待推荐', '5', 'recruitmentApplicationStatus', null, '6', '1', '', 'admin/admin', 'admin/admin', '2016-07-29 15:18:50', '2016-07-29 15:18:50');
INSERT INTO `sys_param` VALUES ('404da963-1d97-47e9-a618-78f8cb5ac154', '待提交', '0', 'assetRepairStatus', null, '0', '1', null, '[admin]admin', '[admin]admin', '2016-03-27 15:09:39', '2016-03-27 15:09:39');
INSERT INTO `sys_param` VALUES ('411288d5-085f-474c-ba61-3f6cfff53800', '因私', '1', 'attendanceExceptionType', null, '1', '1', '因私', 'admin/admin', 'admin/admin', '2016-07-28 11:35:31', '2016-07-28 11:35:31');
INSERT INTO `sys_param` VALUES ('41357da7-b11a-427b-bb38-7cef3b81be68', '邮件', '2', 'messageModel', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-03-30 19:51:04', '2016-03-30 19:51:04');
INSERT INTO `sys_param` VALUES ('413e6d80-7c0c-4aa4-9db0-c9e185ec3508', '管理员筛选', '1', 'recruitmentApplicationResumeStatus', null, '1', '1', '', 'admin/admin', 'admin/admin', '2016-08-01 10:28:54', '2016-08-01 10:28:54');
INSERT INTO `sys_param` VALUES ('42cd7e21-ad35-4946-a1bb-47b2bae7fdb7', '外包服务监控与评价', '7', 'specialAudit', null, '7', '2', '外包服务监控与评价', '[admin]admin', '[admin]admin', '2016-02-24 11:21:14', '2016-02-24 10:49:42');
INSERT INTO `sys_param` VALUES ('433e353c-de65-4fdc-92c1-6d99ed9523fa', '被终止', '8', 'assetRepairStatus', null, '8', '1', null, 'admin/admin', 'admin/admin', '2016-05-16 14:52:38', '2016-05-16 14:52:38');
INSERT INTO `sys_param` VALUES ('446b5844-6814-4e4f-a75e-268e2a217914', '被终止', '6', 'supplierQuitStatus', null, '6', '1', null, 'admin/admin', 'admin/admin', '2016-05-18 12:15:24', '2016-05-18 12:15:24');
INSERT INTO `sys_param` VALUES ('44e4ba63-e1b0-4137-92b1-24b4590681ae', '未确认', '1', 'lowvalueReceptionStatus', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:05:25', '2016-03-23 12:05:25');
INSERT INTO `sys_param` VALUES ('45466207-d449-45f5-88f0-bd87d477b7bd', '外包服务中断与终止', '8', 'specialAudit', null, '8', '2', '外包服务中断与终止', '[admin]admin', '[admin]admin', '2016-02-24 11:21:14', '2016-02-24 10:49:53');
INSERT INTO `sys_param` VALUES ('46d70a0c-765c-4183-8934-85772eabc4d3', '年假', '1', 'vacationType', null, '1', '1', null, 'admin/admin', 'admin/admin', '2016-07-11 15:43:14', '2016-07-11 15:43:14');
INSERT INTO `sys_param` VALUES ('46f95fcb-e82b-415f-9ce0-d74d131a3c95', '被终止', '6', 'personExitStatus', null, '6', '1', null, 'admin/admin', 'admin/admin', '2016-07-14 11:45:23', '2016-07-14 11:45:23');
INSERT INTO `sys_param` VALUES ('4728aac4-d150-4789-ae0c-348b5da6d3d8', '启用', '0', 'serviceMonitoringStatus', null, '1', '1', '启用', '[admin]admin', '[admin]admin', '2016-03-03 10:43:03', '2016-03-03 10:43:03');
INSERT INTO `sys_param` VALUES ('473a19a5-290a-489d-af6d-7050359d934a', '确认中', '6', 'lowvalueApplyStatus', null, '6', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:12:52', '2016-03-23 12:12:23');
INSERT INTO `sys_param` VALUES ('4752b177-369a-4b70-b0d1-397333ded70b', '按工时', '2', 'attendanceType', null, '2', '1', '按工时', 'admin/admin', 'admin/admin', '2016-07-20 15:47:14', '2016-07-20 15:47:14');
INSERT INTO `sys_param` VALUES ('476d900f-bc7f-4f50-bdd2-c21bf7f8e436', '付款中', '2', 'agreementPayStatus', null, '2', '1', null, '[admin]admin', '[admin]admin', '2016-03-22 11:43:34', '2016-03-22 11:43:34');
INSERT INTO `sys_param` VALUES ('4787c303-dbe0-4a34-a223-296ac4158521', '本科', 'bk', 'educationalType', null, '3', '2', null, 'admin/admin', 'admin/admin', '2016-06-02 09:29:33', '2016-06-02 09:29:33');
INSERT INTO `sys_param` VALUES ('4800cf9c-37a6-4fe6-ae7a-8ecf2dcdf62c', '会议', 'HY', 'communType', null, '3', '2', null, null, null, '2016-01-11 15:35:44', '2016-01-11 15:35:44');
INSERT INTO `sys_param` VALUES ('4813c20e-9435-484e-a92e-f8a03aebd22a', '未提交', '0', 'assetsInventoryStatus', null, '0', '1', null, 'admin/admin', 'admin/admin', '2016-04-08 12:17:22', '2016-04-08 12:17:22');
INSERT INTO `sys_param` VALUES ('48591910-0d71-45a8-b27d-fd7c7ca92230', '待发放', '3', 'assetApplicationStatus', null, '3', '1', null, '[FB0001]廖裕卿', '[admin]admin', '2016-03-26 16:31:05', '2016-03-24 17:40:14');
INSERT INTO `sys_param` VALUES ('49c374a0-083d-40c4-96bf-ab8dc474eefb', '供应商人员', '2', 'userType', null, '2', '1', null, null, '[admin]admin', '2016-03-23 12:22:35', '2015-12-30 10:09:49');
INSERT INTO `sys_param` VALUES ('49f498fb-59c1-46c5-b145-f21b8d188096', '部门', '2', 'lowvalueType', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:03:55', '2016-03-23 12:03:55');
INSERT INTO `sys_param` VALUES ('49fbefc6-9512-4aa8-a0cf-4eaef19553b0', '待审批', '2', 'agreementCloseStatus', null, '2', '1', null, '[admin]admin', 'admin/admin', '2016-05-05 19:02:33', '2016-03-09 15:43:55');
INSERT INTO `sys_param` VALUES ('4a3c0fc7-451c-49ba-adc8-238b1bca35d0', '系统', 'system', 'SystemModule', null, '1', '1', null, null, '[admin]admin', '2016-02-15 16:25:11', '2015-12-19 16:17:42');
INSERT INTO `sys_param` VALUES ('4a5694ec-6d1d-4533-bc2e-f261e6b29813', '已过期', 'YGQ', 'assetSparePartsUserStatus', null, '3', '1', null, 'admin/admin', 'admin/admin', '2016-05-12 12:27:14', '2016-05-12 12:27:14');
INSERT INTO `sys_param` VALUES ('4a930645-9d89-471c-9f3e-9815ee17afff', '完成', '8', 'personQuitStatus', null, '8', '1', null, 'admin/admin', 'admin/admin', '2016-07-19 11:27:03', '2016-07-14 11:48:02');
INSERT INTO `sys_param` VALUES ('4aa09c50-a4f6-4ba9-beec-3a6f3e534176', '外包管理', 'wbgl', 'workflowType', null, '2', '1', null, '[admin]admin', '[admin]admin', '2016-02-01 17:26:23', '2016-02-01 17:26:23');
INSERT INTO `sys_param` VALUES ('4ac36948-0b39-4b6d-a8c1-46f6ad02b82b', '审批中', '2', 'assetRepairStatus', null, '2', '1', null, '[admin]admin', '[admin]admin', '2016-03-27 15:10:12', '2016-03-27 15:10:12');
INSERT INTO `sys_param` VALUES ('4acf33c2-5d39-4dbc-84ea-b121cfeed1f7', '评估', 'assessment', 'safetyCheck', null, '2', '1', '评估', '[admin]admin', '[admin]admin', '2016-01-12 17:03:00', '2016-01-12 17:03:00');
INSERT INTO `sys_param` VALUES ('4ad8cc94-3b88-4fff-87ad-be8a47473a37', '被合并', '3', 'supplierRelation', null, '3', '2', null, '[admin]admin', '[admin]admin', '2016-01-12 18:58:46', '2016-01-12 18:58:46');
INSERT INTO `sys_param` VALUES ('4c09cbe5-6889-4ecb-8296-d7d105e41ef6', '待确认', '3', 'faultStatus', null, '3', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:00:35', '2016-03-23 12:00:35');
INSERT INTO `sys_param` VALUES ('4c0eda13-a803-4d2b-b918-2576bd7c28eb', '下半年', '2', 'half', null, '2', '2', null, 'admin/admin', 'admin/admin', '2016-07-08 10:40:41', '2016-07-08 10:40:41');
INSERT INTO `sys_param` VALUES ('4c42ec3b-2c3e-40ca-9e49-583f04bcef34', '角色', '2', 'supplierPerformanceEvaluatorType', null, '2', '1', '角色', '[admin]admin', '[admin]admin', '2016-03-23 12:21:37', '2016-03-23 12:21:37');
INSERT INTO `sys_param` VALUES ('4c8b7670-3955-47e6-bbc9-70fe511ab763', '驳回', 'reject', 'LogOpType', null, '9', '1', null, 'admin/admin', 'admin/admin', '2016-05-04 15:43:11', '2016-05-04 15:43:11');
INSERT INTO `sys_param` VALUES ('4cf5a979-9fbe-4757-a4d4-f41020c0d206', '视频学习', 'SPZX', 'secureTrainType', null, '3', '2', null, '[admin]admin', '[admin]admin', '2016-03-15 11:04:38', '2016-03-15 11:04:38');
INSERT INTO `sys_param` VALUES ('4e7ebd6d-199c-4dc8-939b-7a5ebd31ef22', '不合格', '4', 'agreementEvaluate', null, '4', '2', '不合格', '[admin]admin', '[admin]admin', '2016-03-15 19:47:47', '2016-03-15 19:47:47');
INSERT INTO `sys_param` VALUES ('4eea5f3d-8946-47ae-b5bc-ad365cb004bc', '异常日志', 'execption', 'LogType', null, '3', '1', null, null, null, '2015-12-30 12:30:33', '2015-12-30 12:24:47');
INSERT INTO `sys_param` VALUES ('4f7701c4-3d20-43f8-aa1a-fcc341e9fdbe', '供应商', 'supplier', 'performance', null, '2', '1', '供应商', '[admin]admin', '[admin]admin', '2016-01-12 17:01:07', '2016-01-12 17:01:07');
INSERT INTO `sys_param` VALUES ('4fa01996-2d3b-40bd-b568-905984c56910', '每两周', '2', 'assetsWarnConfigCycle', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:20:53', '2016-03-23 12:20:53');
INSERT INTO `sys_param` VALUES ('513daa21-336b-4b2d-9487-c355301b38b6', '函件', 'HJ', 'communType', null, '2', '2', null, null, null, '2016-01-11 15:35:24', '2016-01-11 15:35:24');
INSERT INTO `sys_param` VALUES ('5179dee9-4943-4a8f-a768-9954a8e0748e', '申请人筛选', '2', 'recruitmentApplicationResumeStatus', null, '2', '1', null, 'admin/admin', '柳青青/BANK2000', '2016-09-27 15:10:44', '2016-08-01 10:29:07');
INSERT INTO `sys_param` VALUES ('51833159-84f3-473a-a39d-e172cda255a4', '完成', '7', 'lowvalueApplyStatus', null, '7', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:12:09', '2016-03-23 12:12:41');
INSERT INTO `sys_param` VALUES ('51bfbb31-23b5-43d1-8ed4-546dda19bab6', '正常', '0', 'noticeState', null, '0', '1', null, 'admin/admin', 'admin/admin', '2016-05-25 14:32:23', '2016-05-25 14:32:23');
INSERT INTO `sys_param` VALUES ('53495186-bfde-41bf-9117-bef8ddb5e811', '较严重', 'JYZ', 'severity', null, '2', '2', null, '[admin]admin', '[admin]admin', '2016-03-15 11:07:48', '2016-03-15 11:07:48');
INSERT INTO `sys_param` VALUES ('537e9735-a70c-410f-89d1-7abfc4f5e39b', '待提交', '1', 'agreementChangeStatus', null, '1', '1', null, '[admin]admin', '[admin]admin', '2016-03-08 15:01:40', '2016-03-08 15:01:40');
INSERT INTO `sys_param` VALUES ('53da95e2-59ac-49be-9641-b7247f3a9867', '一次', '5', 'assetsWarnConfigCycle', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:21:31', '2016-03-23 12:21:31');
INSERT INTO `sys_param` VALUES ('541ac44a-a836-4083-ad38-c306270773ea', '待审批', '2', 'personQuitStatus', null, '2', '1', null, 'admin/admin', 'admin/admin', '2016-07-14 11:46:56', '2016-07-14 11:46:56');
INSERT INTO `sys_param` VALUES ('548aa8ee-3c8c-4b97-a6f4-1ccd8dfe9300', '审批中', '3', 'recruitmentApplicationStatus', null, '4', '1', '', 'admin/admin', 'admin/admin', '2016-07-29 15:18:00', '2016-07-29 15:18:00');
INSERT INTO `sys_param` VALUES ('54fb9392-eb4c-49a3-a379-edbc2d5e5ba9', '已关闭', '6', 'agreementStatus', null, '6', '1', null, '[admin]admin', 'admin/admin', '2016-04-12 09:10:50', '2016-01-25 11:08:58');
INSERT INTO `sys_param` VALUES ('55e0661f-02aa-42f7-a9ea-49cf8dbbf52d', '待处理', '2', 'faultStatus', null, '2', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:00:22', '2016-03-23 12:00:22');
INSERT INTO `sys_param` VALUES ('56015002-7e12-4e13-829d-d813d736ca5e', '已维修待确认', '5', 'assetRepairStatus', null, '5', '1', null, '[admin]admin', '[admin]admin', '2016-03-27 15:11:00', '2016-03-27 15:11:00');
INSERT INTO `sys_param` VALUES ('56e86634-9335-492f-8ef8-336b70e1568d', '咨询采购', '3', 'purchaseCategory', null, '3', '2', null, '[admin]admin', '[admin]admin', '2016-01-26 09:12:23', '2016-01-26 09:12:23');
INSERT INTO `sys_param` VALUES ('574c5882-55e5-41f2-bff2-c1e2f7243230', 'D', 'D', 'performanceResult', null, '4', '2', 'D', '[admin]admin', '[admin]admin', '2016-03-22 15:45:58', '2016-03-22 15:45:58');
INSERT INTO `sys_param` VALUES ('578d21f5-a649-441d-9324-7a2e2b27ad73', 'R5', 'R5', 'riskLevel', null, '5', '2', null, '[admin]admin', '[admin]admin', '2016-01-12 17:15:52', '2016-01-12 17:15:52');
INSERT INTO `sys_param` VALUES ('57d3c2c3-6211-45ed-b6bc-f61678ca8165', '文档自学', 'WDZX', 'secureTrainType', null, '1', '2', null, '[admin]admin', '[admin]admin', '2016-03-15 11:04:00', '2016-03-15 11:04:00');
INSERT INTO `sys_param` VALUES ('57dcbdce-2f9d-4c57-bf5c-87d1347b1871', '满意', '2', 'agreementEvaluateResult', null, '2', '2', '满意', '[admin]admin', '[admin]admin', '2016-03-15 19:50:46', '2016-03-15 19:50:46');
INSERT INTO `sys_param` VALUES ('58a099ea-7c04-456e-89d4-96ee40a2f47f', '合同负责人', '2', 'agreementStakeholdersRole', null, '2', '2', null, '[admin]admin', '[admin]admin', '2016-02-27 12:44:01', '2016-02-27 12:44:01');
INSERT INTO `sys_param` VALUES ('590daa1e-ffca-4af7-b1b5-f0a3dbf13730', '按季度', '2', 'deductionsCycle', null, '2', '1', null, '[admin]admin', '[admin]admin', '2016-02-27 11:38:03', '2016-02-27 11:38:03');
INSERT INTO `sys_param` VALUES ('59ef4cf5-adac-4f67-9f04-c923995c0cb6', '中专', 'zz', 'educationalType', null, '6', '2', null, 'admin/admin', 'admin/admin', '2016-07-25 11:46:55', '2016-06-02 09:30:20');
INSERT INTO `sys_param` VALUES ('5a627751-ff7a-49a1-95e8-e4a20f8c37e9', '采购', '1', 'assetsAgreementType', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-03-23 12:18:46', '2016-03-23 12:18:46');
INSERT INTO `sys_param` VALUES ('5aa9d27f-a987-4463-9707-92a510128afa', 'AIX', 'AIX', 'systemClass', null, '1', '2', null, '孙明钱/BANK1029', '孙明钱/BANK1029', '2016-06-23 11:04:56', '2016-06-23 11:00:44');
INSERT INTO `sys_param` VALUES ('5c8b058c-12b9-4eb9-a6a6-1ca716d80410', '计算机技术', '1', 'belongIndustries', null, '1', '2', null, '[admin]admin', '[admin]admin', '2016-01-13 10:03:27', '2016-01-13 10:03:27');
INSERT INTO `sys_param` VALUES ('5dda70ba-e354-47e7-a84e-a455332c209a', '20人以下', '20', 'staffSize', null, '1', '2', null, '[admin]admin', '[admin]admin', '2016-01-13 10:05:31', '2016-01-13 10:05:31');
INSERT INTO `sys_param` VALUES ('5e190c08-a5a9-4d51-b4e8-d9e4422596e9', '因公', '2', 'attendanceExceptionType', null, '2', '1', '因公', 'admin/admin', 'admin/admin', '2016-07-28 11:35:44', '2016-07-28 11:35:44');
INSERT INTO `sys_param` VALUES ('5e4c5943-35d1-4057-9e08-dda5c14e4625', '发放中', '4', 'assetApplicationStatus', null, '4', '1', null, '[admin]admin', '[admin]admin', '2016-03-26 17:28:49', '2016-03-26 17:28:49');
INSERT INTO `sys_param` VALUES ('5e5315bf-052c-45d5-8cc5-d094a722be08', '绩效考核系统账号及权限', '6', 'outsourcePersonConfig', null, '6', '2', null, '柳青青/BANK2000', '柳青青/BANK2000', '2016-09-05 15:26:10', '2016-09-05 15:26:10');
INSERT INTO `sys_param` VALUES ('5ec464a4-bcaa-422c-b082-1e2d81ca9e7e', '应急会议', 'YJHY', 'communicateType', null, '2', '2', null, '[admin]admin', '[admin]admin', '2016-01-20 18:44:17', '2016-01-20 18:44:17');
INSERT INTO `sys_param` VALUES ('5efea903-3ae6-4aa9-b32a-100124da0677', '完成', '9', 'personEnterStatus', null, '9', '1', null, 'admin/admin', 'admin/admin', '2016-07-15 15:05:21', '2016-07-12 19:50:51');
INSERT INTO `sys_param` VALUES ('5f23b15b-8e10-41dc-99ee-512212e3b639', '通过', '1', 'duediligenceEvaluateResult', null, '1', '2', '通过', '[admin]admin', '[admin]admin', '2016-03-24 16:07:54', '2016-03-24 16:07:54');
INSERT INTO `sys_param` VALUES ('5f38b02a-ce19-46f1-98ea-393525ee42f6', '紧急', 'high', 'faultUrgent', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-02-27 15:02:05', '2016-02-27 14:48:27');
INSERT INTO `sys_param` VALUES ('5f3c73e6-4bfa-409f-be15-923d8c583a6f', '每天', '4', 'assetsWarnConfigCycle', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:21:20', '2016-03-23 12:21:20');
INSERT INTO `sys_param` VALUES ('6057d592-6d4b-48ed-bfd8-6438704d9cd6', '正常', '0', 'attendanceEndExceptionStatus', '#5cb85c', '1', '1', '正常', 'admin/admin', 'admin/admin', '2016-12-08 10:32:20', '2016-07-28 11:34:43');
INSERT INTO `sys_param` VALUES ('60a60e48-7dd4-498c-a314-cfde07921e69', '集成类', 'JCFL', 'outsourceType', null, '5', '2', null, '[admin]admin', '[admin]admin', '2016-01-21 12:04:41', '2016-01-21 12:04:41');
INSERT INTO `sys_param` VALUES ('60f69478-b669-4253-a6a7-d8840182f596', '完成', '8', 'personExitStatus', null, '8', '1', null, 'admin/admin', 'admin/admin', '2016-07-19 11:26:11', '2016-07-14 11:46:07');
INSERT INTO `sys_param` VALUES ('616f1725-cb48-412e-97bb-0334590e8c5b', '工龄假', '2', 'vacationType', null, '2', '1', null, 'admin/admin', 'admin/admin', '2016-07-11 15:43:27', '2016-07-11 15:43:27');
INSERT INTO `sys_param` VALUES ('61a14cbd-0395-49b3-9011-cfd50051c80f', '确认', '2', 'inventoryConfirmStatus', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 10:53:43', '2016-03-23 10:53:43');
INSERT INTO `sys_param` VALUES ('623fe1b3-d101-4aa8-8330-6e2e2c27f047', '每周', '3', 'assetsWarnConfigCycle', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:21:10', '2016-03-23 12:21:10');
INSERT INTO `sys_param` VALUES ('62d37f8d-6e41-43f0-a6f3-32832abb4745', '完成', '9', 'recruitmentApplicationStatus', null, '10', '1', '', 'admin/admin', 'admin/admin', '2016-07-29 15:19:43', '2016-07-29 15:19:43');
INSERT INTO `sys_param` VALUES ('6325475c-9a5f-4354-876f-6326d082ed2a', '咨询类', 'consult', 'projectCategory', null, '1', '2', null, '[admin]admin', '[admin]admin', '2016-02-22 09:46:05', '2016-02-22 09:46:05');
INSERT INTO `sys_param` VALUES ('64105479-79cb-4782-a8a9-7d2d1d9d0033', 'B', 'B', 'projectPerformanceResult', null, '2', '2', 'B', '[admin]admin', '[admin]admin', '2016-03-23 20:03:15', '2016-03-23 20:03:15');
INSERT INTO `sys_param` VALUES ('64c1acf4-fb34-4792-a716-31a1b507604f', '函件', '5', 'messageModel', null, '5', '2', null, 'admin/admin', 'admin/admin', '2016-05-24 17:49:48', '2016-05-24 17:49:48');
INSERT INTO `sys_param` VALUES ('64f9f1d0-3cb7-49a7-ba85-03f5e2f8e588', '待审批', '5', 'supplierQuitStatus', null, '5', '1', null, 'admin/admin', 'admin/admin', '2016-05-11 10:59:54', '2016-05-11 10:59:54');
INSERT INTO `sys_param` VALUES ('65c95296-49a8-4678-a347-096de6e8291e', '不通过', '2', 'duediligenceEvaluateResult', null, '2', '2', '不通过', '[admin]admin', '[admin]admin', '2016-03-24 16:08:02', '2016-03-24 16:08:02');
INSERT INTO `sys_param` VALUES ('660dd864-899a-443e-bc42-14338fca3665', '驳回', '-1', 'lowvalueApplyDetailStatus', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:15:58', '2016-03-23 12:15:58');
INSERT INTO `sys_param` VALUES ('667224c5-15b6-4cfa-9ce5-7a009e1a8b32', '法定节假日', '3', 'festivalType', null, '3', '2', '法定节假日', 'admin/admin', 'admin/admin', '2016-07-18 10:43:52', '2016-07-11 09:48:07');
INSERT INTO `sys_param` VALUES ('66d25fb3-b24d-4984-b27a-07e0a38fc0f6', '安全违规', '1', 'supplierQuitReason', null, '1', '2', null, '[admin]admin', '[admin]admin', '2016-02-26 16:17:41', '2016-02-26 16:17:41');
INSERT INTO `sys_param` VALUES ('677a22aa-80b3-420d-b096-260622017be9', '考试', 'exam', 'templateConfigurationType', null, '1', '2', '考试', '[admin]admin', '[admin]admin', '2016-01-12 16:42:05', '2016-01-12 16:34:31');
INSERT INTO `sys_param` VALUES ('67e24e2b-d6f9-4da6-b776-9093b22bee6a', '被终止', '6', 'agreementChangeStatus', null, '6', '1', null, 'admin/admin', 'admin/admin', '2016-05-19 20:12:18', '2016-05-19 20:12:18');
INSERT INTO `sys_param` VALUES ('68c27963-1e66-4912-8445-bf15e7c5ee8d', '已入库待领用', '1', 'assetsStatus', null, '1', '2', null, '孙明钱/BANK1029', '孙明钱/BANK1029', '2016-06-24 12:11:11', '2016-06-24 12:11:11');
INSERT INTO `sys_param` VALUES ('69bbabc6-dd19-4730-99f8-83144fc7a25a', '否', '3', 'faultHandleConfirm', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-01-21 18:56:45', '2016-01-21 18:56:45');
INSERT INTO `sys_param` VALUES ('69c13f04-2b23-463f-b730-462bfbde43cf', '邮件', 'YJ', 'communType', null, '1', '2', null, null, null, '2016-01-11 15:34:58', '2016-01-11 15:34:58');
INSERT INTO `sys_param` VALUES ('6a0130c6-a613-49b5-be8b-b222ddcd6691', '待确认', '4', 'borrowStatus', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:21:08', '2016-03-23 12:21:08');
INSERT INTO `sys_param` VALUES ('6a11d390-c925-4f49-a5ac-69f4ddbb5848', '待确认', '7', 'personExitStatus', null, '7', '1', null, 'admin/admin', 'admin/admin', '2016-07-19 11:25:58', '2016-07-14 11:45:39');
INSERT INTO `sys_param` VALUES ('6a25d400-1098-4c13-8e32-cc6490481e46', '供应商准入', 'accessToSuppliers', 'templateConfigurationType', null, '5', '2', '供应商准入', '[admin]admin', '[admin]admin', '2016-01-12 16:44:13', '2016-01-12 16:35:28');
INSERT INTO `sys_param` VALUES ('6a4a1325-c367-47b5-9c75-08da6dedae90', '不通过', '2', 'duediligenceEvaluateThirdResult', null, '2', '2', '不通过', 'admin/admin', 'admin/admin', '2016-04-28 18:41:35', '2016-04-28 18:41:35');
INSERT INTO `sys_param` VALUES ('6a61953b-412a-4746-a966-e8edd614be14', 'A', 'A', 'projectPerformanceResult', null, '1', '2', 'A', '[admin]admin', '[admin]admin', '2016-03-23 20:03:09', '2016-03-23 20:03:09');
INSERT INTO `sys_param` VALUES ('6ab4b5f4-2720-4b05-abfe-71637844438a', '不通过', '2', 'riskImportantEvaluateResult', null, '2', '2', '不通过', '[admin]admin', '[admin]admin', '2016-03-24 15:49:37', '2016-03-24 15:49:37');
INSERT INTO `sys_param` VALUES ('6b347ea2-ce02-44a4-a093-5e0a68079d80', '合同执行', '5', 'purchaseStatus', null, '5', '1', null, '[admin]admin', '[admin]admin', '2016-03-01 10:09:21', '2016-01-25 11:01:58');
INSERT INTO `sys_param` VALUES ('6b8dde03-7be2-4865-9fb8-42d62fa1b9e7', '待考核', '0', 'performanceEvaluateConfigurationStatus', '#d9534f', '1', '1', '待考核', '[admin]admin', 'admin/admin', '2016-12-08 11:02:31', '2016-03-22 16:03:53');
INSERT INTO `sys_param` VALUES ('6ba26860-a0ca-489f-afe2-96a6c768947c', '组长', '1', 'groupPost', null, '1', '1', null, '[admin]admin', '[admin]admin', '2016-01-27 10:40:50', '2016-01-27 10:37:46');
INSERT INTO `sys_param` VALUES ('6bcef448-561a-40df-91c1-d57c34e4db65', '驳回', '5', 'personQuitStatus', null, '5', '1', null, 'admin/admin', 'admin/admin', '2016-07-14 11:47:21', '2016-07-14 11:47:21');
INSERT INTO `sys_param` VALUES ('6c273614-efbe-4f6e-b5cb-e28113928eac', '产品经理', '1', 'agreementTeamRole', null, '1', '2', null, '[admin]admin', '[admin]admin', '2016-02-27 11:22:09', '2016-02-27 11:22:09');
INSERT INTO `sys_param` VALUES ('6c4e02d8-6023-4873-8e85-7511ba922d8f', '待归还', '1', 'borrowDetailStatus', null, '1', '1', null, 'admin/admin', 'admin/admin', '2016-04-07 15:23:35', '2016-04-07 15:23:35');
INSERT INTO `sys_param` VALUES ('6c81bd06-fa55-4aee-a4b0-8ce21bc3e093', '按次数', '1', 'attendanceType', null, '1', '1', '按次数', 'admin/admin', 'admin/admin', '2016-07-20 15:47:03', '2016-07-20 15:47:03');
INSERT INTO `sys_param` VALUES ('6cc724b7-3726-4369-9edf-16888e670728', '其他', 'other', 'projectRole', null, '3', '2', null, '[admin]admin', '[admin]admin', '2016-02-22 17:43:56', '2016-02-22 17:43:56');
INSERT INTO `sys_param` VALUES ('6cee1483-3f54-4195-910c-bf388d169295', '待提交', '1', 'borrowStatus', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:19:37', '2016-03-23 12:19:37');
INSERT INTO `sys_param` VALUES ('6cefc52a-321c-45b7-8015-748a4b352117', 'R2', 'r2', 'projectRiskLevel', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-02-23 11:52:00', '2016-02-23 11:52:00');
INSERT INTO `sys_param` VALUES ('6d2f7dc4-848a-4527-beb4-db704e736902', '待提交', '0', 'lowvalueApplyDetailStatus', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:16:19', '2016-03-23 12:16:19');
INSERT INTO `sys_param` VALUES ('6d660e61-7183-4ac8-86bf-5c9d08836e04', '正常', '0', 'attendanceStartExceptionStatus', '#5cb85c', '1', '1', '正常', 'admin/admin', 'admin/admin', '2016-12-08 10:31:48', '2016-07-28 11:36:09');
INSERT INTO `sys_param` VALUES ('6ee11e31-ab21-48e8-97d5-fe440fe95a13', '菜单', '1', 'resourceType', null, '1', '1', null, null, null, '2015-12-21 14:23:28', '2015-12-21 14:23:28');
INSERT INTO `sys_param` VALUES ('6ef4684b-6f56-4a73-87ca-d2226ced930d', '硬件类', '1', 'agreementCategory', null, '1', '2', null, '[admin]admin', '[admin]admin', '2016-01-26 16:13:40', '2016-01-26 09:13:32');
INSERT INTO `sys_param` VALUES ('6f1f66ba-72ac-40db-a63c-8c9c266f5e92', '全行', 'QH', 'impactScope', null, '1', '2', null, '[admin]admin', '[admin]admin', '2016-03-15 11:05:34', '2016-03-15 11:05:34');
INSERT INTO `sys_param` VALUES ('6feea13a-31b8-4ea0-9214-17bb0f7bd13a', '待填报', '1', 'manHourEditType', '#d9534f', '1', '1', '待填报', 'admin/admin', 'admin/admin', '2016-12-08 10:35:38', '2016-07-14 11:28:04');
INSERT INTO `sys_param` VALUES ('70a34d5b-4316-43cd-b0bc-ab66d18152fb', '第二季度', '2', 'quarter', null, '2', '2', null, 'admin/admin', 'admin/admin', '2016-07-08 10:41:57', '2016-07-08 10:41:57');
INSERT INTO `sys_param` VALUES ('710d0fc5-e5b5-42a2-8f05-736d80ae59a2', '延期', '3', 'agreementChangeType', null, '3', '2', null, '[admin]admin', '[admin]admin', '2016-03-08 15:03:37', '2016-03-08 15:03:37');
INSERT INTO `sys_param` VALUES ('7125e363-6418-436f-94cc-f36332a8386b', '预约及面试', '3', 'recruitmentApplicationResumeStatus', null, '3', '1', '', 'admin/admin', 'admin/admin', '2016-08-01 10:29:25', '2016-08-01 10:29:25');
INSERT INTO `sys_param` VALUES ('71619cff-acac-4e01-8cbc-1a67183c604f', '风险评估', 'riskAssessment', 'templateConfigurationType', null, '11', '2', '风险评估', '[admin]admin', '[admin]admin', '2016-01-12 16:46:21', '2016-01-12 16:37:13');
INSERT INTO `sys_param` VALUES ('716f335a-a1d7-4361-acb5-95902607b95a', '硬件采购', '1', 'purchaseCategory', null, '1', '2', null, '[admin]admin', '[admin]admin', '2016-01-26 16:11:13', '2016-01-23 16:42:16');
INSERT INTO `sys_param` VALUES ('71a498e1-dbc6-42a2-9478-5e019fc9bfed', '每月', '2', 'attendanceCycle', null, '2', '1', '每月', 'admin/admin', 'admin/admin', '2016-07-20 15:45:51', '2016-07-20 15:45:51');
INSERT INTO `sys_param` VALUES ('71f9b540-0851-45a6-a965-3d17f3820443', '修改', 'operUpdate', 'formOperationType', null, '2', '1', '修改操作', null, null, '2016-01-06 11:12:44', '2016-01-06 11:12:44');
INSERT INTO `sys_param` VALUES ('728cbbf9-ae9d-464f-9d13-173be732da6a', '补充协议', '6', 'agreementCategory', null, '6', '2', null, '[admin]admin', '[admin]admin', '2016-01-26 09:14:16', '2016-01-26 09:14:16');
INSERT INTO `sys_param` VALUES ('7354def9-69d4-4e4c-8c90-12274289f0a7', '人力外包类', '3', 'agreementCategory', null, '3', '2', null, '[admin]admin', '[admin]admin', '2016-01-26 09:13:42', '2016-01-26 09:13:42');
INSERT INTO `sys_param` VALUES ('7412424b-22ba-4289-994e-0db81601a114', '优选供应商', 'yxgys', 'supplierLevel', null, '2', '2', null, null, null, '2016-01-05 15:11:41', '2016-01-05 15:11:41');
INSERT INTO `sys_param` VALUES ('74834aa8-c523-4b10-98b0-c42b1113049d', 'B', 'B', 'supplierPerformanceResult', null, '2', '2', 'B', '[admin]admin', '[admin]admin', '2016-03-23 12:24:24', '2016-03-23 12:24:24');
INSERT INTO `sys_param` VALUES ('75161b04-562b-4766-84b8-d3a9de95e3aa', '信息中心', 'tech', 'faultImpact', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-02-27 15:01:01', '2016-02-27 14:45:38');
INSERT INTO `sys_param` VALUES ('751d85fa-14c9-4beb-babf-75e26ffb2833', '定期巡检', '1', 'patrolManner', null, '1', '2', '定期巡检', '[admin]admin', '[admin]admin', '2016-03-07 15:42:47', '2016-03-07 15:42:47');
INSERT INTO `sys_param` VALUES ('75400f7c-7db5-400c-9f9a-e21e09eb8b6f', '待评价', '0', 'agreementEvaluateConfigurationStatus', '#d9534f', '1', '1', '待评价', '[admin]admin', 'admin/admin', '2016-12-08 11:29:04', '2016-03-26 16:31:21');
INSERT INTO `sys_param` VALUES ('767b0d41-cbd7-4e09-a490-a5eb036345ad', '中', 'common', 'faultHandleAssess', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-02-29 12:19:05', '2016-02-29 12:19:05');
INSERT INTO `sys_param` VALUES ('76b65a65-e81a-4058-9182-92c49914415a', '非常满意', '1', 'agreementEvaluateResult', null, '1', '2', '非常满意', '[admin]admin', '[admin]admin', '2016-03-15 19:50:36', '2016-03-15 19:50:36');
INSERT INTO `sys_param` VALUES ('78f54c0b-7d10-4855-b21e-96b98f98b699', '季度', 'quarter', 'examUnit', null, '3', '2', null, 'admin/admin', 'admin/admin', '2016-07-08 11:07:32', '2016-07-08 11:07:32');
INSERT INTO `sys_param` VALUES ('78f5e54f-4493-40cb-847b-309ba0c3aec8', '已关闭', '2', 'performanceEvaluateConfigurationStatus', '#5cb85c', '3', '1', '已关闭', '[admin]admin', 'admin/admin', '2016-12-08 11:02:39', '2016-03-22 16:04:23');
INSERT INTO `sys_param` VALUES ('799fd21f-c7ce-49b9-9162-1e79e1b0e0a8', '民营公司', '2', 'companyNature', null, '2', '2', null, '[admin]admin', '[admin]admin', '2016-01-13 10:03:46', '2016-01-12 20:20:02');
INSERT INTO `sys_param` VALUES ('7a3db42a-8584-4a42-87c6-1514a299c17c', '即时通讯工具', '6', 'messageModel', null, '6', '2', null, 'admin/admin', 'admin/admin', '2016-05-24 17:50:33', '2016-05-24 17:50:33');
INSERT INTO `sys_param` VALUES ('7a6bf326-5feb-493a-8e5f-50cbdb296a80', '良好', '2', 'agreementEvaluate', null, '2', '2', '良好', '[admin]admin', '[admin]admin', '2016-03-15 19:47:17', '2016-03-15 19:47:17');
INSERT INTO `sys_param` VALUES ('7b5fd2a5-39e8-442d-b473-f5549ac558b4', '月度', 'month', 'examUnit', null, '4', '2', null, 'admin/admin', 'admin/admin', '2016-07-08 11:07:46', '2016-07-08 11:07:46');
INSERT INTO `sys_param` VALUES ('7bc45143-ed3d-4134-8d3a-89c8996a6882', '个人', 'personage', 'performance', null, '1', '1', '个人', '[admin]admin', '[admin]admin', '2016-01-12 17:00:49', '2016-01-12 17:00:49');
INSERT INTO `sys_param` VALUES ('7c3dfb3a-d4c7-4a52-8a3d-697ca8711bc3', '暂停', '1', 'triggerState', null, '2', '1', '暂停', null, null, '2015-12-22 10:12:12', '2015-12-22 10:12:12');
INSERT INTO `sys_param` VALUES ('7c6da9c4-fcd7-4c74-a40d-4cffaa44812a', 'A', 'A', 'performanceResult', null, '1', '2', 'A', '[admin]admin', '[admin]admin', '2016-03-22 15:45:33', '2016-03-22 15:45:33');
INSERT INTO `sys_param` VALUES ('7cfc188e-bcf5-449e-b4a8-ad6f46955f8b', '研发中心', 'dev', 'faultImpact', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-02-27 15:01:14', '2016-02-27 14:45:20');
INSERT INTO `sys_param` VALUES ('7ede4c1c-8585-4539-b415-09f4a45a136c', '延期处理', '2', 'faultHandleConfirm', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-01-21 18:56:45', '2016-01-21 18:56:45');
INSERT INTO `sys_param` VALUES ('7f092008-2713-4383-a294-73c4b066a67a', '待配置信息', '4', 'personEnterStatus', null, '4', '1', null, 'admin/admin', '柳青青/BANK2000', '2016-08-23 15:56:30', '2016-07-12 19:49:04');
INSERT INTO `sys_param` VALUES ('7f43643b-edab-428e-ab27-19639dcd4cfe', '苗族', '苗族', 'nationType', null, '2', '2', null, null, null, '2015-12-30 11:33:34', '2015-12-30 11:33:34');
INSERT INTO `sys_param` VALUES ('7fa4b056-028c-43dc-9c22-e2ed0d75bef9', '驳回', '4', 'supplierQuitStatus', null, '4', '1', null, '[admin]admin', '[admin]admin', '2016-03-21 15:12:59', '2016-03-21 15:12:59');
INSERT INTO `sys_param` VALUES ('800a5588-b876-424c-a8b8-7c5cb4e6ee12', '待关闭', '4', 'agreementStatus', null, '4', '1', null, '[admin]admin', 'admin/admin', '2016-04-12 09:09:58', '2016-01-25 11:08:34');
INSERT INTO `sys_param` VALUES ('802ed9c5-6d7c-4636-9314-098a8feed6e3', '临时巡检', '2', 'patrolManner', null, '2', '2', '临时巡检', '[admin]admin', '[admin]admin', '2016-03-07 15:42:57', '2016-03-07 15:42:57');
INSERT INTO `sys_param` VALUES ('812002b3-31d5-499e-8b7c-1066e4f7a412', '退场', '2', 'recordType', null, '2', '1', null, '[admin]admin', '[admin]admin', '2016-02-23 17:32:44', '2016-02-23 17:32:44');
INSERT INTO `sys_param` VALUES ('81646e3a-18df-4e05-8b15-25731757e1fc', '制度培训', 'ZDPX', 'trainType', null, '2', '2', null, '[admin]admin', '[admin]admin', '2016-01-20 10:08:55', '2016-01-20 10:08:55');
INSERT INTO `sys_param` VALUES ('81666a6f-69a0-4357-8a2c-8892203b5566', '项目经理', '2', 'agreementTeamRole', null, '2', '2', null, '[admin]admin', '[admin]admin', '2016-02-27 11:22:21', '2016-02-27 11:22:21');
INSERT INTO `sys_param` VALUES ('81dc4f24-a98c-43d1-bddc-ec5976ffb427', '初中', 'cz', 'educationalType', null, '7', '2', null, 'admin/admin', 'admin/admin', '2016-07-25 11:47:26', '2016-07-25 11:47:26');
INSERT INTO `sys_param` VALUES ('81ffb159-1977-4fc4-907a-d22822684c29', '产假', '4', 'vacationType', null, '4', '1', null, 'admin/admin', 'admin/admin', '2016-07-11 15:43:49', '2016-07-11 15:43:49');
INSERT INTO `sys_param` VALUES ('831d02aa-0e01-452c-973c-bcdcf7356fbe', '岗位', '3', 'performanceEvaluatorType', null, '3', '1', '岗位', '[admin]admin', '[admin]admin', '2016-03-16 15:39:34', '2016-03-16 15:39:34');
INSERT INTO `sys_param` VALUES ('8364696e-030e-4925-a133-535b41513ad6', '完成', '4', 'recruitmentApplicationResumeStatus', null, '4', '1', '', 'admin/admin', 'admin/admin', '2016-08-01 10:29:38', '2016-08-01 10:29:38');
INSERT INTO `sys_param` VALUES ('83df0356-c469-452a-89da-1226664f5e69', '系统参数', '1', 'paramType', null, '1', '1', null, 'admin/admin', 'admin/admin', '2016-04-07 18:04:12', '2016-04-07 18:02:57');
INSERT INTO `sys_param` VALUES ('83e66009-40a2-4522-904c-469b23ccb25a', '一般', 'YB', 'severity', null, '4', '2', null, '[admin]admin', '[admin]admin', '2016-03-15 11:08:23', '2016-03-15 11:08:23');
INSERT INTO `sys_param` VALUES ('8403e98d-b751-4e2f-8d94-111b74891fe0', '错误', '3', 'triggerState', null, '4', '1', '错误', null, null, '2015-12-22 10:12:56', '2015-12-22 10:12:56');
INSERT INTO `sys_param` VALUES ('843caa72-afc0-45cc-8097-48062971eb66', '驳回', '-1', 'recruitmentApplicationStatus', null, '1', '1', '', 'admin/admin', 'admin/admin', '2016-07-29 15:16:44', '2016-07-29 15:16:44');
INSERT INTO `sys_param` VALUES ('8504cfba-1c7f-4e7b-85e1-7f356d14340e', '跟踪风险', '2', 'projectRiskStatus', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 11:56:36', '2016-03-23 11:56:36');
INSERT INTO `sys_param` VALUES ('8563e857-b705-4a84-a68f-06534b3b5fc0', '半系统半业务', '3', 'paramType', null, '3', '1', null, '孙明钱/BANK1029', '孙明钱/BANK1029', '2016-04-15 15:22:13', '2016-04-15 15:22:13');
INSERT INTO `sys_param` VALUES ('85664c7a-a3a6-43ed-9928-163058ae59ef', '组织内人员', '1', 'userType', null, '1', '1', null, null, '[admin]admin', '2016-03-23 12:26:28', '2015-12-30 10:09:38');
INSERT INTO `sys_param` VALUES ('85c451d1-f704-4b5d-ad96-5da24c4b7219', '被终止', '5', 'assetRetirementStatus', null, '5', '1', null, 'admin/admin', 'admin/admin', '2016-05-16 15:00:43', '2016-05-16 15:00:43');
INSERT INTO `sys_param` VALUES ('862c03a5-2355-4ed6-aaf4-d2d45226c304', '专项审计', 'specialAudit', 'auditCategory', null, '2', '2', '专项审计', '[admin]admin', '[admin]admin', '2016-02-24 10:44:27', '2016-02-24 10:44:27');
INSERT INTO `sys_param` VALUES ('871cc37c-e8cf-4e72-8a08-46f309ef5148', '未确认', '1', 'inventoryConfirmStatus', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 10:53:33', '2016-03-23 10:53:33');
INSERT INTO `sys_param` VALUES ('8732ff2a-d615-41ea-9d7f-7c6e46daece8', '待提交', '0', 'faultStatus', null, '0', '1', null, 'admin/admin', 'admin/admin', '2016-06-30 11:17:40', '2016-06-28 14:56:13');
INSERT INTO `sys_param` VALUES ('875635b6-8b81-46bb-8c80-358442c885ab', '不通过', '2', 'serviceMonitoringEvaluateResult', null, '2', '2', '不通过', '[admin]admin', '[admin]admin', '2016-03-24 16:16:33', '2016-03-24 16:16:33');
INSERT INTO `sys_param` VALUES ('88b69d76-4060-41fe-8859-1ff371926724', '驳回', '5', 'personExitStatus', null, '5', '1', null, 'admin/admin', 'admin/admin', '2016-07-14 11:45:08', '2016-07-14 11:45:08');
INSERT INTO `sys_param` VALUES ('89090139-f6e7-47bb-aaf9-60dac1d3b4e1', '弃权', '3', 'riskAuditEvaluateResult', null, '3', '2', '弃权', '[admin]admin', '[admin]admin', '2016-03-24 15:59:52', '2016-03-24 15:59:52');
INSERT INTO `sys_param` VALUES ('8961d585-4c84-41ef-a02b-246d7061caf4', '提交', 'submit', 'LogOpType', null, '10', '1', null, 'admin/admin', 'admin/admin', '2016-05-04 15:43:25', '2016-05-04 15:43:25');
INSERT INTO `sys_param` VALUES ('897aea65-abb1-4f85-9c69-db23661014e2', '运维类', 'YWFL', 'outsourceType', null, '3', '2', null, '[admin]admin', '[admin]admin', '2016-01-21 12:03:59', '2016-01-21 12:03:59');
INSERT INTO `sys_param` VALUES ('89b316b7-66cf-4932-a3c6-95f688983cf9', '创建风险', 'CJ', 'riskState', null, null, '1', null, 'admin/admin', 'admin/admin', '2016-07-14 16:37:49', '2016-07-14 16:37:49');
INSERT INTO `sys_param` VALUES ('8a209595-57c5-4d4b-87eb-25aaa6c656b4', '通过', '1', 'accessEvaluateResult', null, '1', '2', '通过', '[admin]admin', '[admin]admin', '2016-01-21 16:25:18', '2016-01-21 16:25:18');
INSERT INTO `sys_param` VALUES ('8a34bc75-b86d-42dc-a8c5-6ab73d7cfa5a', '驳回发放', '-2', 'lowvalueApplyStatus', null, null, '1', null, 'admin/admin', 'admin/admin', '2016-04-14 17:36:56', '2016-04-14 17:36:56');
INSERT INTO `sys_param` VALUES ('8a534a95-a531-41e9-8f11-c96ae685033c', '已考核', '1', 'performanceEvaluateStatus', '#5cb85c', '1', '1', '已考核', '[admin]admin', 'admin/admin', '2016-12-08 11:01:56', '2016-03-22 15:57:01');
INSERT INTO `sys_param` VALUES ('8ac729b7-e4ec-412a-872c-cc87cd993062', '待提交', '1', 'personEnterStatus', null, '1', '1', null, 'admin/admin', '柳青青/BANK2000', '2016-08-23 15:56:37', '2016-07-12 19:47:49');
INSERT INTO `sys_param` VALUES ('8b971234-02e7-4618-8401-b54013df96c7', '审批中', '3', 'agreementChangeStatus', null, '3', '1', null, '[admin]admin', '[admin]admin', '2016-03-28 17:10:00', '2016-03-08 15:02:05');
INSERT INTO `sys_param` VALUES ('8bbb2352-f97a-407b-a69a-dc02c0be8b80', '故障', '2', 'patrolEvaluateResult', null, '2', '2', '故障', '[admin]admin', '[admin]admin', '2016-03-24 15:08:01', '2016-03-24 15:08:01');
INSERT INTO `sys_param` VALUES ('8bf2fad2-3873-4350-a946-df07a4ce9529', '替补', 'replace', 'recruitmentApplicationReason', null, '1', '2', null, 'admin/admin', 'admin/admin', '2016-09-02 12:01:56', '2016-08-20 14:17:21');
INSERT INTO `sys_param` VALUES ('8c22c984-0e6a-4628-b5b4-0fe7d9392357', '已创建', '1', 'agreementStatus', null, '1', '1', null, '[admin]admin', '[admin]admin', '2016-03-29 12:17:00', '2016-01-25 11:07:27');
INSERT INTO `sys_param` VALUES ('8c78e0a2-86c4-4985-8b0f-b4551a271bb1', '调休', '4', 'festivalType', null, '4', '2', '调休', 'admin/admin', 'admin/admin', '2016-07-18 10:44:00', '2016-07-11 09:48:15');
INSERT INTO `sys_param` VALUES ('8d2173b2-c624-47fb-90a5-61675b7d6428', '咨询类', 'zx', 'supplierType', null, '1', '2', null, null, null, '2016-01-05 15:08:56', '2016-01-05 15:08:56');
INSERT INTO `sys_param` VALUES ('8d974d0c-debf-4b8c-9b88-4a394a7913b4', '导入', 'leadingin', 'LogOpType', null, '5', '1', null, 'admin/admin', 'admin/admin', '2016-05-04 15:21:19', '2016-05-04 15:21:19');
INSERT INTO `sys_param` VALUES ('8db23688-c318-41f8-bafc-652eed14d43c', '待考核', '0', 'performanceEvaluateStatus', '#d9534f', '2', '1', '待考核', '[admin]admin', 'admin/admin', '2016-12-08 11:02:00', '2016-03-22 15:57:10');
INSERT INTO `sys_param` VALUES ('8e190817-691c-443c-b029-40facafa75b5', '被终止', '6', 'personQuitStatus', null, '6', '1', null, 'admin/admin', 'admin/admin', '2016-07-14 11:47:34', '2016-07-14 11:47:34');
INSERT INTO `sys_param` VALUES ('8efd93ad-eef1-4749-aa2c-a9823f8641d9', '待确认', '2', 'lowvalueApplyDetailStatus', null, null, '1', null, '[admin]admin', '柳青青/BANK2000', '2016-09-12 11:37:21', '2016-03-23 12:16:40');
INSERT INTO `sys_param` VALUES ('8f556201-7637-42b0-9e16-4989a7e9e09a', 'R4', 'R4', 'riskLevel', null, '4', '2', null, '[admin]admin', '[admin]admin', '2016-01-12 17:15:38', '2016-01-12 17:15:38');
INSERT INTO `sys_param` VALUES ('903e1990-21b0-4257-bca2-bfae5064ac32', '已确认', '3', 'lowvalueApplyDetailStatus', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:16:51', '2016-03-23 12:16:51');
INSERT INTO `sys_param` VALUES ('9041d20b-f333-42e9-8f11-5683753841c2', '新增', 'insert', 'LogOpType', null, '1', '1', null, 'admin/admin', 'admin/admin', '2016-05-04 15:20:05', '2016-05-04 15:20:05');
INSERT INTO `sys_param` VALUES ('911aa07c-6f73-44ff-9c05-cdfbb2c989c9', '全面审计', 'comprehensiveAudit', 'auditCategory', null, '1', '2', '全面审计', '[admin]admin', '[admin]admin', '2016-02-24 10:44:02', '2016-02-24 10:44:02');
INSERT INTO `sys_param` VALUES ('919c0e67-2978-47bb-bb64-901ed2d44135', '待完善', '8', 'personEnterStatus', null, '8', '1', null, 'admin/admin', 'admin/admin', '2016-07-15 15:05:11', '2016-07-12 19:50:29');
INSERT INTO `sys_param` VALUES ('923b35ba-d9b1-4300-8492-7f9e897a047f', 'A', 'A', 'supplierPerformanceResult', null, '1', '2', 'A', '[admin]admin', '[admin]admin', '2016-03-23 12:24:17', '2016-03-23 12:24:17');
INSERT INTO `sys_param` VALUES ('92eae815-f723-4eac-8e8c-27b0797af8da', '离职', '1', 'exitReasonList', null, '1', '2', null, 'admin/admin', 'admin/admin', '2016-07-13 11:23:25', '2016-07-13 11:23:25');
INSERT INTO `sys_param` VALUES ('9309d4fd-12a6-4d42-8816-e1aa78533c74', '安全培训', 'AQPX', 'trainType', null, '1', '2', null, '[admin]admin', '[admin]admin', '2016-01-20 10:07:24', '2016-01-20 10:07:24');
INSERT INTO `sys_param` VALUES ('93198212-0bf4-4932-8470-f4a697af7607', '待响应', '1', 'faultStatus', null, '1', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:00:08', '2016-03-23 12:00:05');
INSERT INTO `sys_param` VALUES ('931a1f70-90b0-4d8e-af94-1aebe27f05b2', '合同完成', '1', 'agreementCloseReason', null, '1', '2', null, '[admin]admin', '[admin]admin', '2016-03-09 17:06:37', '2016-03-09 16:29:12');
INSERT INTO `sys_param` VALUES ('944cb808-37e3-46b3-91c8-31472dc94497', '不需确认', '4', 'inventoryConfirmStatus', null, '4', '1', null, 'admin/admin', 'admin/admin', '2016-05-13 12:17:44', '2016-05-13 12:17:44');
INSERT INTO `sys_param` VALUES ('946eaac3-b40e-4216-8200-5738264a6aa6', '待关闭', '0', 'securityEvaluateConfigurationStatus', '#f0ad4e', '0', '2', '待关闭', 'admin/admin', 'admin/admin', '2016-12-08 11:22:38', '2016-04-14 11:30:25');
INSERT INTO `sys_param` VALUES ('94bdbd9d-2864-4733-a5da-deb919daf9fc', '人力外包类', 'rlwb', 'supplierType', null, '3', '2', null, '柳青青/BANK2000', '柳青青/BANK2000', '2016-08-26 16:09:02', '2016-08-26 16:09:02');
INSERT INTO `sys_param` VALUES ('9613f933-c7ee-466f-a1a4-37894c5ae390', '博士', 'bs', 'educationalType', null, '1', '2', null, 'admin/admin', 'admin/admin', '2016-06-02 09:28:57', '2016-06-02 09:28:57');
INSERT INTO `sys_param` VALUES ('96b93267-6911-4885-9947-13d816cf6554', '完成', '7', 'assetApplicationStatus', null, '7', '1', null, '[admin]admin', '[admin]admin', '2016-03-26 16:34:06', '2016-03-26 16:34:06');
INSERT INTO `sys_param` VALUES ('96c5385f-f985-419c-a7cb-aaf831381fd8', '关闭', '3', 'projectRiskStatus', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 11:56:54', '2016-03-23 11:56:54');
INSERT INTO `sys_param` VALUES ('97b3b232-3783-4479-9423-bd7c772e4eef', '待通知', '7', 'personEnterStatus', null, '7', '1', null, 'admin/admin', 'admin/admin', '2016-07-15 15:04:46', '2016-07-12 19:50:10');
INSERT INTO `sys_param` VALUES ('98064e26-7cae-4e26-ad2e-4a784ad36c3a', '已确认', '3', 'manHourEditType', '#5cb85c', '3', '1', '已确认', 'admin/admin', 'admin/admin', '2016-12-08 10:35:47', '2016-07-14 11:28:24');
INSERT INTO `sys_param` VALUES ('984af96d-5659-4466-aaab-7e7b32d963d3', '迟到', '1', 'attendanceStartExceptionStatus', '#d9534f', '2', '1', '迟到', 'admin/admin', 'admin/admin', '2016-12-08 10:31:51', '2016-07-28 11:36:21');
INSERT INTO `sys_param` VALUES ('98f3c17f-bb0c-4342-9051-d050685186bc', '已评估', '1', 'accessEvaluateStatus', '#5cb85c', '1', '1', '已评估', '[admin]admin', 'admin/admin', '2016-12-08 11:40:53', '2016-01-21 18:56:29');
INSERT INTO `sys_param` VALUES ('991fe3d2-313b-40a1-a945-8779f67d75fc', '走访', 'ZF', 'communType', null, '4', '2', null, null, null, '2016-01-11 15:36:02', '2016-01-11 15:36:02');
INSERT INTO `sys_param` VALUES ('9a30e42a-1e1e-40c1-b013-ddbaaf027e23', '其他', 'QT', 'trainType', null, '4', '2', null, '[admin]admin', '[admin]admin', '2016-01-20 10:10:47', '2016-01-20 10:10:47');
INSERT INTO `sys_param` VALUES ('9a3c8d19-f2e3-493d-9016-5cca4e08a7ee', '半年', 'half', 'examUnit', null, '2', '2', null, 'admin/admin', 'admin/admin', '2016-07-08 11:07:22', '2016-07-08 11:07:22');
INSERT INTO `sys_param` VALUES ('9aa08c43-9e8f-4ca1-bf58-fb1587b18159', '第一季度', '1', 'quarter', null, '1', '2', null, 'admin/admin', 'admin/admin', '2016-07-08 10:41:39', '2016-07-08 10:41:39');
INSERT INTO `sys_param` VALUES ('9b96e0d0-9cdb-4e34-886f-a47c6c2b6879', '项目', 'project', 'performance', null, '3', '1', '项目', '[admin]admin', '[admin]admin', '2016-01-12 17:01:27', '2016-01-12 17:01:27');
INSERT INTO `sys_param` VALUES ('9ba1a9e7-36a8-4590-8d5e-786d51c14beb', '考勤规则配置', '1', 'outsourcePersonConfig', null, '1', '1', '默认为5*7小时工作制，周一至周五，上午09:00-12:00，下午14:00-18:00', 'admin/admin', '柳青青/BANK2000', '2016-11-16 12:01:43', '2016-07-13 16:05:51');
INSERT INTO `sys_param` VALUES ('9bd10cb4-23f5-4d72-a620-6beafc18ee45', '暂停', '2', 'agreementChangeType', null, '2', '2', null, '[admin]admin', '[admin]admin', '2016-03-08 15:03:25', '2016-03-08 15:03:25');
INSERT INTO `sys_param` VALUES ('9c278dad-c375-42fc-af0b-2c31ecd84817', '完成', '5', 'borrowStatus', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:21:17', '2016-03-23 12:21:17');
INSERT INTO `sys_param` VALUES ('9c2f9c7f-ae07-4f30-b292-24cf1c385dc5', '单一来源采购', '2', 'purchaseType', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-01-23 16:42:56', '2016-01-23 16:42:56');
INSERT INTO `sys_param` VALUES ('9c92fbe7-9032-450e-accc-617d09f6947e', '安全培训考试', 'safetyTrainingExamination', 'exam', null, '1', '2', '安全培训考试', '[admin]admin', '[admin]admin', '2016-01-12 16:59:27', '2016-01-12 16:59:27');
INSERT INTO `sys_param` VALUES ('9cb84750-6315-4305-bbd9-e9272be7562b', '已下架', '1', 'noticeState', null, '1', '1', null, 'admin/admin', 'admin/admin', '2016-05-25 14:32:40', '2016-05-25 14:32:40');
INSERT INTO `sys_param` VALUES ('9cffeb57-1a93-46a0-ba57-d97e2f9bcb45', '个人', '2', 'patrolObjectType', null, '2', '1', '个人', '[admin]admin', '[admin]admin', '2016-03-07 15:51:27', '2016-03-07 15:51:27');
INSERT INTO `sys_param` VALUES ('9d00c6c9-bafa-480f-aa5d-9f621a22525c', '未签退', '-1', 'attendanceEndExceptionStatus', '#d9534f', '3', '1', '未签退', 'admin/admin', 'admin/admin', '2016-12-08 10:32:27', '2016-07-28 11:35:08');
INSERT INTO `sys_param` VALUES ('9d7e77b7-af9d-4f7f-a51d-c016ca6797f2', '部门负责人', '1', 'agreementStakeholdersRole', null, '1', '2', null, '[admin]admin', '[admin]admin', '2016-02-27 12:43:49', '2016-02-27 12:43:49');
INSERT INTO `sys_param` VALUES ('9e2dc4d3-0166-4ce9-a0ac-1325da172f4f', '信息科技外包风险管理', '2', 'specialAudit', null, '2', '2', '信息科技外包风险管理', '[admin]admin', '[admin]admin', '2016-02-24 11:21:14', '2016-02-24 10:48:48');
INSERT INTO `sys_param` VALUES ('9e6705b1-b808-448b-9ba8-12a56fe4de78', 'B', 'B', 'performanceResult', null, '2', '2', 'B', '[admin]admin', '[admin]admin', '2016-03-22 15:45:45', '2016-03-22 15:45:45');
INSERT INTO `sys_param` VALUES ('9e79801c-e04f-4661-bfb6-3fdb17d99d39', '待审批', '2', 'recruitmentApplicationStatus', null, '3', '1', '', 'admin/admin', 'admin/admin', '2016-07-29 15:17:32', '2016-07-29 15:17:32');
INSERT INTO `sys_param` VALUES ('9ef7dd70-47bd-4bba-b890-a0581af5adf6', '通过', '1', 'interviewResult', null, '1', '1', '', 'admin/admin', 'admin/admin', '2016-07-29 11:11:50', '2016-07-29 11:11:13');
INSERT INTO `sys_param` VALUES ('9f452ba5-d1b2-400d-8086-4d945477f34c', 'SLA参考模板', 'SLAReferenceTemplate', 'templateConfigurationType', null, '2', '2', 'SLA参考模板', '[admin]admin', '[admin]admin', '2016-01-12 16:42:40', '2016-01-12 16:34:49');
INSERT INTO `sys_param` VALUES ('9fbd91f2-7b25-4782-89da-46322713f83f', '其他', '4', 'exitReasonList', null, '4', '2', null, 'admin/admin', 'admin/admin', '2016-07-13 11:24:06', '2016-07-13 11:24:06');
INSERT INTO `sys_param` VALUES ('a00a0400-43d7-424d-b410-74b06f88aa1c', '子公司', '2', 'supplierRelation', null, '2', '2', null, '[admin]admin', '[admin]admin', '2016-01-12 18:58:19', '2016-01-12 18:58:19');
INSERT INTO `sys_param` VALUES ('a0650421-e8e8-42ec-8cee-4154fe3aed20', '严重', 'YZ', 'severity', null, '1', '2', null, '[admin]admin', '[admin]admin', '2016-03-15 11:07:32', '2016-03-15 11:07:32');
INSERT INTO `sys_param` VALUES ('a08c37ea-7e7e-4206-aebd-9b179ea09827', '通过', '1', 'securityCheckEvaluateResult', null, '1', '2', '通过', '[admin]admin', '[admin]admin', '2016-03-24 16:22:26', '2016-03-24 16:22:26');
INSERT INTO `sys_param` VALUES ('a1943491-cbe7-4b01-b469-5d28f61f23a4', '外包审计-全面审计', 'comprehensiveAudit', 'riskAssessment', null, '4', '1', '外包审计-全面审计', '[admin]admin', '[admin]admin', '2016-02-24 11:41:28', '2016-01-12 17:06:11');
INSERT INTO `sys_param` VALUES ('a26da8cc-4910-488e-997f-f6f75c1a4066', 'AIX', 'AIX', 'systemClass', null, '1', '2', null, '孙明钱/BANK1029', '孙明钱/BANK1029', '2016-06-23 11:12:11', '2016-06-23 11:12:11');
INSERT INTO `sys_param` VALUES ('a2a75d8e-bceb-41a3-8c8b-298c9516da0c', '供应商管理', 'gysgl', 'workflowType', null, '1', '1', null, '[admin]admin', '[admin]admin', '2016-02-01 17:25:53', '2016-02-01 17:25:53');
INSERT INTO `sys_param` VALUES ('a2d2b30c-c0fd-489e-a68c-03142e09029e', '已付款', '3', 'agreementPayStatus', null, '3', '1', null, '[admin]admin', '[admin]admin', '2016-03-22 11:43:44', '2016-03-22 11:43:44');
INSERT INTO `sys_param` VALUES ('a3619f6d-da16-45bb-adde-9340f91b42dc', '中止', '1', 'agreementChangeType', null, '1', '2', null, '[admin]admin', '[admin]admin', '2016-03-08 15:03:11', '2016-03-08 15:03:11');
INSERT INTO `sys_param` VALUES ('a4a8a020-e555-4337-a5e0-d3c677ecd131', '供应商', '1', 'patrolObjectType', null, '1', '1', '供应商', '[admin]admin', '[admin]admin', '2016-03-07 15:51:16', '2016-03-07 15:51:16');
INSERT INTO `sys_param` VALUES ('a4b5f21e-7565-495b-b088-090d22b0cc40', '合格', '3', 'agreementEvaluate', null, '3', '2', '合格', '[admin]admin', '[admin]admin', '2016-03-15 19:47:33', '2016-03-15 19:47:33');
INSERT INTO `sys_param` VALUES ('a4eb2ac9-809e-40bc-806c-c623f11c026e', '驳回', '4', 'agreementCloseStatus', null, '4', '1', null, '[admin]admin', '[admin]admin', '2016-03-09 15:44:25', '2016-03-09 15:44:25');
INSERT INTO `sys_param` VALUES ('a52bfe11-c3c5-4572-a872-f3ea14c2877c', '更新', 'update', 'LogOpType', null, '2', '1', null, 'admin/admin', 'admin/admin', '2016-05-04 15:20:39', '2016-05-04 15:20:39');
INSERT INTO `sys_param` VALUES ('a668b8ae-6288-4c81-a918-5b690545e660', '是', '1', 'YesNo', null, '1', '2', null, null, null, '2015-12-29 11:47:26', '2015-12-21 19:39:44');
INSERT INTO `sys_param` VALUES ('a6730707-115d-402b-b943-4dd256a7f2fe', '待提交', '0', 'assetApplicationStatus', null, '0', '1', null, '[FB0001]廖裕卿', '[admin]admin', '2016-03-26 16:30:26', '2016-03-24 17:39:42');
INSERT INTO `sys_param` VALUES ('a6e73cbe-8194-4ce8-8053-64167eccc45c', '新增', 'operAdd', 'formOperationType', null, '1', '1', '新增操作', null, null, '2016-01-06 11:12:01', '2016-01-06 11:12:01');
INSERT INTO `sys_param` VALUES ('a777ba4c-a805-4900-a532-5bddc0500932', '已完成', '2', 'triggerState', null, '3', '1', '已完成', null, null, '2015-12-22 10:12:35', '2015-12-22 10:12:35');
INSERT INTO `sys_param` VALUES ('a84ff6fc-4fba-4695-9797-877f7ddb5405', '全面风险评估', 'comprehensiveRiskAssessments', 'riskAssessment', null, '1', '1', '全面风险评估', '[admin]admin', '[admin]admin', '2016-01-12 17:03:57', '2016-01-12 17:03:57');
INSERT INTO `sys_param` VALUES ('a87923e2-eaee-400d-a7ca-b01203405161', '年', 'year', 'examUnit', null, '1', '2', null, 'admin/admin', 'admin/admin', '2016-07-08 11:07:05', '2016-07-08 11:07:05');
INSERT INTO `sys_param` VALUES ('a96a909e-beba-40dc-8e95-7c688a81fb38', '未提交', '1', 'personExitStatus', null, '1', '1', null, 'admin/admin', 'admin/admin', '2016-07-14 11:44:09', '2016-07-14 11:44:09');
INSERT INTO `sys_param` VALUES ('a96ff58c-af9f-4346-9682-9da758c9aa83', '项目干系人', 'pr', 'projectRole', null, '2', '2', null, '[admin]admin', '[admin]admin', '2016-02-25 12:05:39', '2016-02-22 17:43:41');
INSERT INTO `sys_param` VALUES ('a98ed1fe-99c1-4be8-a748-d23f1de4cc58', '角色', '2', 'performanceEvaluatorType', null, '2', '1', '角色', '[admin]admin', '[admin]admin', '2016-03-16 15:39:20', '2016-03-16 15:39:20');
INSERT INTO `sys_param` VALUES ('aa23b7fd-b83c-47db-81b1-13dbddff5095', '未提交', '1', 'personQuitStatus', null, '1', '1', null, 'admin/admin', 'admin/admin', '2016-07-14 11:46:45', '2016-07-14 11:46:45');
INSERT INTO `sys_param` VALUES ('ac535556-5b30-4cac-b0ae-d411cbe5fa12', '专科', 'dz', 'educationalType', null, '4', '2', null, 'admin/admin', 'admin/admin', '2016-08-05 10:02:13', '2016-07-25 11:47:09');
INSERT INTO `sys_param` VALUES ('ac839801-da79-4e13-8273-95451b9c08c0', '实施人员', 'implement', 'projectRole', null, '1', '2', null, 'admin/admin', 'admin/admin', '2016-08-19 11:09:35', '2016-08-19 11:09:35');
INSERT INTO `sys_param` VALUES ('ace04b9a-fa2e-428a-9442-57038623edb7', '审批中', '3', 'personExitStatus', null, '3', '1', null, 'admin/admin', 'admin/admin', '2016-07-14 11:44:46', '2016-07-14 11:44:46');
INSERT INTO `sys_param` VALUES ('ae476dfe-dce6-4358-af2f-386deb4fa5d4', '弃权', '3', 'duediligenceEvaluateResult', null, '3', '2', '弃权', '[admin]admin', '[admin]admin', '2016-03-24 16:08:09', '2016-03-24 16:08:09');
INSERT INTO `sys_param` VALUES ('b114f5f3-f8de-44cb-b56a-9b55976cfbf8', '功能路径', '3', 'resourceType', null, '3', '1', null, null, null, '2015-12-21 14:24:08', '2015-12-21 14:24:08');
INSERT INTO `sys_param` VALUES ('b299d89d-b980-4e5d-9058-2ba44eaa37ad', '确认中', '2', 'lowvalueReceptionStatus', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:06:23', '2016-03-23 12:06:23');
INSERT INTO `sys_param` VALUES ('b2f869e9-24ed-4ad9-9cf7-83d79017bfc9', '通过', '1', 'riskImportantEvaluateResult', null, '1', '2', '通过', '[admin]admin', '[admin]admin', '2016-03-24 15:49:30', '2016-03-24 15:49:30');
INSERT INTO `sys_param` VALUES ('b3ba526f-d44c-4152-a8cb-b1c6e9997694', '弃权', '3', 'serviceMonitoringEvaluateResult', null, '3', '2', '弃权', '[admin]admin', '[admin]admin', '2016-03-24 16:16:39', '2016-03-24 16:16:39');
INSERT INTO `sys_param` VALUES ('b3d85c42-3d45-4c78-bf1e-69040720838c', '实施类', 'implement', 'projectCategory', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-02-22 09:47:13', '2016-02-22 09:47:13');
INSERT INTO `sys_param` VALUES ('b418cb42-7981-4cb2-a3a7-ce68dd3778af', '审批中', '3', 'personQuitStatus', null, '3', '1', null, 'admin/admin', 'admin/admin', '2016-07-14 11:47:06', '2016-07-14 11:47:06');
INSERT INTO `sys_param` VALUES ('b463b552-fc8c-45a2-8cc3-7480c178b38f', '待提交', '1', 'supplierBlackListState', null, '1', '2', null, 'admin/admin', 'admin/admin', '2016-04-23 15:00:43', '2016-04-23 15:00:43');
INSERT INTO `sys_param` VALUES ('b46d810d-3ad2-4083-861e-a82b7013ca8b', '运维类', 'yw', 'supplierType', null, '2', '2', null, null, null, '2016-01-05 15:09:25', '2016-01-05 15:09:25');
INSERT INTO `sys_param` VALUES ('b510df1a-410a-43f1-a93d-7d8f8ac55815', '不通过', '2', 'accessEvaluateResult', null, '2', '2', '不通过', '[admin]admin', '[admin]admin', '2016-01-21 16:25:32', '2016-01-21 16:25:32');
INSERT INTO `sys_param` VALUES ('b5a643f8-c8f4-4b48-8056-2a9e3c2502fe', '服务项目', '7', 'recordType', null, '7', '1', null, '[admin]admin', '[admin]admin', '2016-02-23 17:34:54', '2016-02-23 17:34:54');
INSERT INTO `sys_param` VALUES ('b5a8f6db-5ee9-4155-8848-05ecceb343d3', '处理中', '6', 'recruitmentApplicationStatus', null, '7', '1', '', 'admin/admin', 'admin/admin', '2016-08-04 20:29:36', '2016-08-04 20:29:36');
INSERT INTO `sys_param` VALUES ('b5c916a4-d7f7-4a60-81d9-bb17771a88a0', '不通过', '2', 'externalManagerEvaluateResult', null, '2', '2', '不通过', '[admin]admin', 'admin/admin', '2016-12-08 11:43:14', '2016-03-24 16:30:18');
INSERT INTO `sys_param` VALUES ('b604980b-c49f-472f-9878-d36502cc2268', '巡检', 'patrolType', 'templateConfigurationType', null, '3', '2', '巡检', '[admin]admin', '[admin]admin', '2016-03-07 16:03:31', '2016-01-12 16:35:01');
INSERT INTO `sys_param` VALUES ('b6088ae2-4539-4d06-a662-10e138e7efba', '上半年', '1', 'half', null, '1', '2', null, 'admin/admin', 'admin/admin', '2016-07-08 10:40:27', '2016-07-08 10:40:27');
INSERT INTO `sys_param` VALUES ('b6c27078-a505-4daf-85cb-ebd9d52a6263', '未付款', '1', 'agreementPayStatus', null, '1', '1', null, '[admin]admin', '[admin]admin', '2016-03-22 11:43:23', '2016-03-22 11:43:23');
INSERT INTO `sys_param` VALUES ('b7a7541d-1288-4fa0-ad85-23fa099add9d', '副组长', '2', 'groupPost', null, '2', '1', null, '[admin]admin', '[admin]admin', '2016-01-27 10:40:50', '2016-01-27 10:38:13');
INSERT INTO `sys_param` VALUES ('b8286cfd-b46d-4359-bfc3-be7c9c92f207', '挂载', '1', 'associationRelation', null, '1', '2', null, 'admin/admin', 'admin/admin', '2016-12-08 11:41:26', '2016-09-06 09:55:45');
INSERT INTO `sys_param` VALUES ('b87edc36-f197-4a8b-b9c9-021e3a83fc3c', '合同', 'contract', 'performance', null, '4', '1', '合同', '[admin]admin', '[admin]admin', '2016-01-12 17:01:53', '2016-01-12 17:01:53');
INSERT INTO `sys_param` VALUES ('b93de500-a025-4718-b633-4da54bc94f89', '高中', 'gz', 'educationalType', null, '5', '2', null, 'admin/admin', 'admin/admin', '2016-06-02 09:31:00', '2016-06-02 09:31:00');
INSERT INTO `sys_param` VALUES ('b94d50e0-98d3-4fcf-940b-ac1ad0c01107', '成员', '3', 'groupPost', null, '3', '1', null, '[admin]admin', '[admin]admin', '2016-01-27 10:40:50', '2016-01-27 10:38:27');
INSERT INTO `sys_param` VALUES ('b977e009-3a89-44f8-bc40-2e554a7683ad', '博士后', 'bsh', 'educationalType', null, '0', '2', null, 'admin/admin', 'admin/admin', '2016-07-25 11:46:37', '2016-07-25 11:46:37');
INSERT INTO `sys_param` VALUES ('b9d90fa8-2681-4fb7-9d1f-6da0c744d1cb', '审批中', '3', 'agreementCloseStatus', null, '3', '1', null, '[admin]admin', '[admin]admin', '2016-03-09 15:44:08', '2016-03-09 15:44:08');
INSERT INTO `sys_param` VALUES ('baa72b1b-c09c-4729-9030-ec46d2f9a0d8', '应用开发类', 'YYKF', 'outsourceType', null, '2', '2', null, '[admin]admin', '[admin]admin', '2016-01-21 12:03:35', '2016-01-21 12:03:35');
INSERT INTO `sys_param` VALUES ('bab8a6ca-2882-47d8-9bce-63338ddb548a', '机房巡检', '1', 'patrolType', null, '1', '2', '机房巡检', '[admin]admin', '[admin]admin', '2016-03-07 15:06:02', '2016-03-03 12:02:30');
INSERT INTO `sys_param` VALUES ('badd9a82-70d8-4c0b-a2e2-8900faccde46', '完成确认', '3', 'assetsInventoryStatus', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 10:52:07', '2016-03-23 10:46:29');
INSERT INTO `sys_param` VALUES ('bb341a49-55a6-48da-bbcb-3e6f91955ee5', '供应商退出', '2', 'supplierQuitType', null, '2', '2', null, 'admin/admin', 'admin/admin', '2016-04-11 15:23:27', '2016-04-11 15:23:27');
INSERT INTO `sys_param` VALUES ('bb5a42cb-3380-4109-8a0c-bfa097112f50', '被终止', '6', 'personEnterStatus', null, '6', '1', null, 'admin/admin', 'admin/admin', '2016-07-12 19:49:34', '2016-07-12 19:49:34');
INSERT INTO `sys_param` VALUES ('bd02512d-bf39-4273-840a-d2cfd5ce4ce1', '未提交', '1', 'supplierQuitStatus', null, '1', '1', null, '[admin]admin', '[admin]admin', '2016-03-09 17:20:21', '2016-03-09 17:20:21');
INSERT INTO `sys_param` VALUES ('bd538b84-d1d4-4ba1-89de-afb0c48ed513', '已完成', '4', 'supplierBlackListState', null, '4', '2', null, 'admin/admin', 'admin/admin', '2016-04-23 15:02:11', '2016-04-23 15:01:16');
INSERT INTO `sys_param` VALUES ('be22b6da-31f0-42ee-8be5-97211004f271', '被终止', '6', 'supplierBlackListState', null, '6', '2', null, 'admin/admin', 'admin/admin', '2016-05-18 12:01:35', '2016-05-18 12:01:24');
INSERT INTO `sys_param` VALUES ('be56e1ff-be78-4dd9-8257-0941fdfad3a8', '业务相关人员', '3', 'agreementStakeholdersRole', null, '3', '2', null, 'admin/admin', 'admin/admin', '2016-05-04 16:22:34', '2016-05-04 16:22:34');
INSERT INTO `sys_param` VALUES ('be654106-252a-4864-8415-74ddd4ebde59', '不通过', '2', 'securityCheckEvaluateResult', null, '2', '2', '不通过', '[admin]admin', '[admin]admin', '2016-03-24 16:22:33', '2016-03-24 16:22:33');
INSERT INTO `sys_param` VALUES ('bedde6c7-1ec8-48c5-bb53-d290db8653cc', '正常', '1', 'patrolEvaluateResult', null, '1', '2', '正常', '[admin]admin', '[admin]admin', '2016-03-24 15:08:18', '2016-03-24 15:05:27');
INSERT INTO `sys_param` VALUES ('c04ae568-7b70-4cb0-87c5-6a5825423548', '系统角色', '1', 'roleType', null, null, '1', null, null, null, '2015-12-17 18:24:18', '2015-12-17 18:24:18');
INSERT INTO `sys_param` VALUES ('c1afda8f-728a-4e5f-9c6a-703fee3dd0bd', '口头', '7', 'messageModel', null, '7', '2', null, 'admin/admin', 'admin/admin', '2016-05-24 17:50:48', '2016-05-24 17:50:48');
INSERT INTO `sys_param` VALUES ('c1fc5eba-2686-464c-837e-a77cc36243e1', '发放中', '4', 'lowvalueApplyStatus', null, '4', '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:11:59', '2016-03-23 12:11:49');
INSERT INTO `sys_param` VALUES ('c20cb46d-7cbb-4a4a-a2aa-bdd2a3151651', '待提交', '1', 'agreementCloseStatus', null, '1', '1', null, '[admin]admin', '[admin]admin', '2016-03-09 15:43:42', '2016-03-09 15:43:42');
INSERT INTO `sys_param` VALUES ('c27278d9-025d-485b-ba29-cfaafc575aba', '待审批', '2', 'agreementChangeStatus', null, '2', '1', null, '[admin]admin', 'admin/admin', '2016-05-05 19:01:54', '2016-03-08 15:01:52');
INSERT INTO `sys_param` VALUES ('c339e578-6002-488e-bd4b-0ad7d5de85ab', '确认', 'confirm', 'LogOpType', null, '8', '1', null, 'admin/admin', 'admin/admin', '2016-05-04 15:42:53', '2016-05-04 15:42:53');
INSERT INTO `sys_param` VALUES ('c362fe43-30ac-49a1-a1c1-1ffa5e9de86a', '是', '1', 'faultHandleConfirm', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-01-21 18:56:45', '2016-01-21 18:56:45');
INSERT INTO `sys_param` VALUES ('c3aa6685-0dcd-48a0-afee-b78d80a686d8', '服务商监控', '3', 'serviceMonitoringType', null, '3', '2', '服务商监控', '[admin]admin', '[admin]admin', '2016-03-03 10:42:29', '2016-03-03 10:42:29');
INSERT INTO `sys_param` VALUES ('c40c6a24-e0fe-4395-9327-5a1f9abb16e0', '履行中', '2', 'agreementStatus', null, '2', '1', null, '[admin]admin', 'admin/admin', '2016-04-12 09:09:33', '2016-01-25 11:08:07');
INSERT INTO `sys_param` VALUES ('c4d8740f-39d0-4052-9f1c-f8fb35732181', '外包人员', '3', 'userType', null, '3', '1', null, null, null, '2016-01-03 11:18:51', '2016-01-03 11:18:51');
INSERT INTO `sys_param` VALUES ('c4e7e20c-91be-42ef-ad57-944231826f01', '战略供应商', 'zlgys', 'supplierLevel', null, '1', '2', 'zh', null, null, '2016-01-11 10:10:58', '2016-01-05 15:12:15');
INSERT INTO `sys_param` VALUES ('c51ce9ec-6532-4def-9da8-1068cea96f34', '已关闭', '6', 'agreementCloseStatus', null, '6', '1', '评价完成后更新', '[admin]admin', '[admin]admin', '2016-03-09 15:45:07', '2016-03-09 15:45:07');
INSERT INTO `sys_param` VALUES ('c5612698-d979-4e4e-bc1e-2bd420e81f55', '通过', '1', 'serviceMonitoringEvaluateResult', null, '1', '2', '通过', '[admin]admin', '[admin]admin', '2016-03-24 16:16:24', '2016-03-24 16:16:24');
INSERT INTO `sys_param` VALUES ('c655a283-fe94-47e4-aa3b-9763b4b597d6', '信息类', '3', 'belongIndustries', null, '3', '2', null, '[admin]admin', '[admin]admin', '2016-02-17 15:46:59', '2016-02-17 15:46:59');
INSERT INTO `sys_param` VALUES ('c668a53c-3295-420b-bb0e-f1bf7f4642bd', '报废', '5', 'assetsStatus', null, '5', '2', null, '孙明钱/BANK1029', '孙明钱/BANK1029', '2016-06-24 12:22:11', '2016-06-24 12:22:11');
INSERT INTO `sys_param` VALUES ('c6fa029e-8b50-4efa-87d2-f7c5a4c8cb53', '项目角色', '3', 'projectPerformanceEvaluatorType', null, '3', '1', '项目角色', 'admin/admin', 'admin/admin', '2016-09-06 18:08:21', '2016-04-12 17:56:39');
INSERT INTO `sys_param` VALUES ('c8affbfb-3e72-4989-82f7-04b02d46a704', '已入库', '2', 'assetsRegistStatus', null, '2', '2', null, 'admin/admin', 'admin/admin', '2016-07-02 11:43:31', '2016-07-02 11:43:31');
INSERT INTO `sys_param` VALUES ('cb326240-5836-459e-a800-efc6295df548', '人力风险', 'person', 'projectRiskCategory', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-02-23 11:51:26', '2016-02-23 11:51:26');
INSERT INTO `sys_param` VALUES ('cb3913a7-1e5d-4a12-9e26-e55d37e3150c', '未签到', '-1', 'attendanceStartExceptionStatus', '#d9534f', '3', '1', '未签到', 'admin/admin', 'admin/admin', '2016-12-08 10:31:55', '2016-07-28 11:36:33');
INSERT INTO `sys_param` VALUES ('cc7219ff-2038-4b88-b4a6-438cbb7c3773', '驳回', '5', 'personEnterStatus', null, '5', '1', null, 'admin/admin', 'admin/admin', '2016-07-12 19:49:17', '2016-07-12 19:49:17');
INSERT INTO `sys_param` VALUES ('cc8c38c1-c670-41c4-9e07-8afe353b1f7c', '系统', '3', 'messageModel', null, '3', '2', null, 'admin/admin', 'admin/admin', '2016-05-24 17:48:29', '2016-05-24 17:48:29');
INSERT INTO `sys_param` VALUES ('ce2956db-798d-486d-b48d-29b319f43b3f', '已考核待关闭', '1', 'performanceEvaluateConfigurationStatus', '#f0ad4e', '2', '1', '已考核待关闭', '[admin]admin', 'admin/admin', '2016-12-08 11:02:36', '2016-03-22 16:04:11');
INSERT INTO `sys_param` VALUES ('ce37182a-f39a-49f2-b349-86c3d35dd32e', '清退', '3', 'exitReasonList', null, '3', '2', null, 'admin/admin', 'admin/admin', '2016-07-13 11:23:55', '2016-07-13 11:23:55');
INSERT INTO `sys_param` VALUES ('cf8cf35a-5341-421b-aaf5-01a8fed7056f', '未提交', '0', 'assetRetirementStatus', null, '0', '1', null, '[101]刘宝安1', '[101]刘宝安1', '2016-03-28 16:40:52', '2016-03-28 16:41:43');
INSERT INTO `sys_param` VALUES ('d14699bc-70f1-4506-b342-1455c62ac181', '常规配件', 'CGPJ', 'assetSparePartsType', null, '1', '1', null, 'admin/admin', 'admin/admin', '2016-05-12 12:26:18', '2016-05-12 12:26:18');
INSERT INTO `sys_param` VALUES ('d188d92d-e738-4055-99c9-317ecb334eb2', '丧假', '5', 'vacationType', null, '5', '1', null, 'admin/admin', 'admin/admin', '2016-07-11 15:44:01', '2016-07-11 15:44:01');
INSERT INTO `sys_param` VALUES ('d19f0ca8-2006-4e9f-8d56-8724dff268ac', '弃权', '3', 'externalManagerEvaluateResult', null, '3', '2', '弃权', '[admin]admin', 'admin/admin', '2016-12-08 11:43:17', '2016-03-24 16:30:26');
INSERT INTO `sys_param` VALUES ('d21bb08f-9dbe-45cc-98b2-7017ae3f0623', '其它', '5', 'festivalType', null, '5', '2', '其它', 'admin/admin', 'admin/admin', '2016-07-18 10:43:25', '2016-07-18 10:43:25');
INSERT INTO `sys_param` VALUES ('d2ef46e9-9104-4ef5-a851-ec26effab69d', '已审批', '3', 'assetRetirementStatus', null, '3', '1', null, '[101]刘宝安1', '[101]刘宝安1', '2016-03-28 16:42:23', '2016-03-28 16:42:23');
INSERT INTO `sys_param` VALUES ('d3443131-076c-4290-8874-c88be03fd809', '供应商风险', '2', 'riskParamType', null, null, '1', '', 'admin/admin', 'admin/admin', '2016-07-08 15:21:29', '2016-07-08 15:21:29');
INSERT INTO `sys_param` VALUES ('d3c8e0a0-973b-4655-98d7-8690ba06d778', '短信', '1', 'messageModel', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-03-30 19:50:55', '2016-03-30 19:50:55');
INSERT INTO `sys_param` VALUES ('d40fafbd-fb72-4124-b489-00d41a7fa135', '项目风险', '1', 'riskParamType', null, null, '1', '', 'admin/admin', 'admin/admin', '2016-07-08 15:21:17', '2016-07-08 15:21:17');
INSERT INTO `sys_param` VALUES ('d4191c5b-9839-437d-98fc-d4fe268ece72', 'R1', 'R1', 'riskLevel', null, '1', '2', null, '[admin]admin', '[admin]admin', '2016-01-12 17:14:49', '2016-01-12 17:14:49');
INSERT INTO `sys_param` VALUES ('d4312ffe-5973-454d-b193-cac067473e13', '驳回', '7', 'assetRepairStatus', null, '7', '1', null, 'admin/admin', 'admin/admin', '2016-05-16 14:52:01', '2016-05-16 14:52:01');
INSERT INTO `sys_param` VALUES ('d4364075-17e4-413f-ae22-d1dae9afa826', '待归还', '3', 'borrowStatus', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:20:04', '2016-03-23 12:20:04');
INSERT INTO `sys_param` VALUES ('d48ae545-c593-494f-b782-6bf4a0fecdda', '弃权', '3', 'riskOverallEvaluateResult', null, '3', '2', '弃权', '[admin]admin', '[admin]admin', '2016-03-24 15:39:42', '2016-03-24 15:39:42');
INSERT INTO `sys_param` VALUES ('d5341d46-77c0-4366-9c35-64471b433dfe', '审批中', '3', 'supplierBlackListState', null, '3', '2', null, 'admin/admin', 'admin/admin', '2016-04-23 15:01:59', '2016-04-23 15:01:04');
INSERT INTO `sys_param` VALUES ('d5435a8a-a23d-41ca-8c65-c58ef162b94b', '不确定时间', '2', 'attendanceDateType', null, '2', '1', '不确定时间', 'admin/admin', 'admin/admin', '2016-07-20 15:46:36', '2016-07-20 15:46:36');
INSERT INTO `sys_param` VALUES ('d564a667-5f67-46e0-9f49-c661cd4f5fcd', '涉嫌造假', '2', 'supplierQuitReason', null, '2', '2', null, '[admin]admin', '[admin]admin', '2016-02-26 16:18:04', '2016-02-26 16:18:04');
INSERT INTO `sys_param` VALUES ('d59fddc8-1567-4bf1-9db6-be44d731f9a4', '待签订合同', '3', 'purchaseStatus', null, '3', '1', null, '[admin]admin', '[admin]admin', '2016-03-01 10:08:43', '2016-01-25 11:01:41');
INSERT INTO `sys_param` VALUES ('d5bf2f3f-eb40-4281-b09b-4434181d7baf', '好', 'good', 'faultHandleAssess', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-02-29 12:18:50', '2016-02-29 12:18:50');
INSERT INTO `sys_param` VALUES ('d70c03d7-c474-48a0-8b8b-0e56e043bd18', '已确认', '1', 'lowvalueReceptionDetailConfirmStatus', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 12:08:53', '2016-03-23 12:08:53');
INSERT INTO `sys_param` VALUES ('d76bd695-93a9-408d-9f93-8bfc81876ffb', '完成', '6', 'assetRepairStatus', null, '6', '1', null, '[admin]admin', '[admin]admin', '2016-03-27 15:11:16', '2016-03-27 15:11:16');
INSERT INTO `sys_param` VALUES ('d7a6ab81-1a7f-4d0c-8319-87814de30895', '硕士', 'ss', 'educationalType', null, '2', '2', null, 'admin/admin', 'admin/admin', '2016-06-02 09:29:15', '2016-06-02 09:29:15');
INSERT INTO `sys_param` VALUES ('d820b92f-b121-4858-846e-cc4616f7f79f', '一般', 'common', 'faultUrgent', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-02-27 15:01:38', '2016-02-27 14:48:54');
INSERT INTO `sys_param` VALUES ('d8c10370-803f-4281-9775-1739e10f3015', '基础设施建设类', 'JCSSJSL', 'outsourceType', null, '4', '2', null, '[admin]admin', '[admin]admin', '2016-01-21 12:04:24', '2016-01-21 12:04:24');
INSERT INTO `sys_param` VALUES ('d8c120e8-4155-4ff9-b7e4-c3eceeb9fc83', '工作日', '1', 'festivalType', null, '1', '2', '工作日', 'admin/admin', 'admin/admin', '2016-07-18 10:43:34', '2016-07-11 09:47:43');
INSERT INTO `sys_param` VALUES ('d8f94a3f-3f3c-440e-b518-9ebd470979bb', '正常', '0', 'triggerState', null, '1', '1', '正常', null, null, '2015-12-22 10:11:29', '2015-12-22 10:11:29');
INSERT INTO `sys_param` VALUES ('d969b44e-ceda-417b-a2b3-7169971ae1e2', '外包风险评估与准入', '3', 'specialAudit', null, '3', '2', '外包风险评估与准入', '[admin]admin', '[admin]admin', '2016-02-24 11:21:14', '2016-02-24 10:48:59');
INSERT INTO `sys_param` VALUES ('d9b089a8-1e64-48fa-973d-0deedf26b0ca', '乙方负责人', 'bleader', 'projectRole', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-01-21 18:56:45', '2016-01-21 18:56:45');
INSERT INTO `sys_param` VALUES ('d9c4cb08-77fb-4446-9bf3-b6ef30773df8', '驳回', '8', 'assetApplicationStatus', null, '8', '1', null, '[admin]admin', '[admin]admin', '2016-03-26 16:32:41', '2016-03-26 15:04:07');
INSERT INTO `sys_param` VALUES ('daca7d1a-d965-444c-84c1-d5b0397c5d22', '其他', '9', 'vacationType', null, '9', '1', null, 'admin/admin', 'admin/admin', '2016-07-11 15:44:47', '2016-07-11 15:44:47');
INSERT INTO `sys_param` VALUES ('dad638e9-ad7b-46c6-ae76-1353f7e79b4b', '审批中', '2', 'assetRetirementStatus', null, '2', '1', null, '[101]刘宝安1', '[101]刘宝安1', '2016-03-28 16:42:14', '2016-03-28 16:42:14');
INSERT INTO `sys_param` VALUES ('daf71d2d-e93a-4e4a-aaeb-5d27562680f2', '级别变更', '8', 'recordType', null, '8', '1', null, 'admin/admin', 'admin/admin', '2016-08-29 12:23:56', '2016-08-29 12:23:56');
INSERT INTO `sys_param` VALUES ('db150b3c-e8e6-470c-8a2c-56ad6a29363f', '同意关闭', '5', 'agreementStatus', null, '5', '1', null, '[admin]admin', 'admin/admin', '2016-04-12 09:10:38', '2016-01-25 11:08:46');
INSERT INTO `sys_param` VALUES ('dbebc414-1611-4ad4-811b-09676584ac5f', '第四季度', '4', 'quarter', null, '4', '2', null, 'admin/admin', 'admin/admin', '2016-07-08 10:42:17', '2016-07-08 10:42:17');
INSERT INTO `sys_param` VALUES ('dc2b4ea3-f5d0-4226-9134-bc656c5ebe0c', '外包属性配置', '3', 'outsourcePersonConfig', null, '3', '1', '请进入“外包人员列表”页面进行配置', 'admin/admin', '柳青青/BANK2000', '2016-09-01 20:14:24', '2016-07-13 16:06:43');
INSERT INTO `sys_param` VALUES ('dc7bc8e2-9f81-46fe-8af9-88fbc6de62d6', '不通过', '2', 'riskAuditEvaluateResult', null, '2', '2', '不通过', '[admin]admin', '[admin]admin', '2016-03-24 15:59:45', '2016-03-24 15:59:45');
INSERT INTO `sys_param` VALUES ('de4dd892-4bf0-4a06-aafd-e0b9960a712d', '国有企业', '1', 'companyNature', null, '1', '2', null, '[admin]admin', '[admin]admin', '2016-01-13 10:03:38', '2016-01-12 20:20:20');
INSERT INTO `sys_param` VALUES ('df40a575-cb2d-4952-bc27-d555eb689939', '其它', '8', 'messageModel', null, '8', '2', null, 'admin/admin', 'admin/admin', '2016-05-24 17:51:00', '2016-05-24 17:51:00');
INSERT INTO `sys_param` VALUES ('df6a6bb8-7213-47fe-9199-904cd58be3b5', '审批通过', '5', 'agreementChangeStatus', null, '5', '1', null, '[admin]admin', '[admin]admin', '2016-03-28 17:10:13', '2016-03-28 17:10:13');
INSERT INTO `sys_param` VALUES ('df87289b-ba13-418f-96b3-98e38c90fabe', '确定时间', '1', 'attendanceDateType', null, '1', '1', '确定时间', 'admin/admin', 'admin/admin', '2016-07-20 15:46:24', '2016-07-20 15:46:24');
INSERT INTO `sys_param` VALUES ('e12a98d9-50ba-4a18-bd00-03e0b35b2307', '部门变更', '5', 'recordType', null, '5', '1', null, '[admin]admin', '[admin]admin', '2016-02-23 17:34:32', '2016-02-23 17:34:32');
INSERT INTO `sys_param` VALUES ('e1e146f3-e491-4102-b873-acc683f4dfaf', '按月', '1', 'deductionsCycle', null, '1', '1', null, '[admin]admin', '[admin]admin', '2016-02-27 11:37:47', '2016-02-27 11:37:47');
INSERT INTO `sys_param` VALUES ('e2532273-4fdd-4c0c-b913-68a2b76cc510', '研发咨询类', '4', 'agreementCategory', null, '4', '2', null, '[admin]admin', '[admin]admin', '2016-01-26 09:13:53', '2016-01-26 09:13:53');
INSERT INTO `sys_param` VALUES ('e2738379-83d9-4d4c-8840-596ff20c34e2', '非驻场外包', 'notInOtcPackage', 'templateConfigurationType', null, '6', '2', '非驻场外包', '[admin]admin', '[admin]admin', '2016-01-12 16:44:42', '2016-01-12 16:35:42');
INSERT INTO `sys_param` VALUES ('e29c3409-6342-4477-bd97-187dca6792d9', '一般', '4', 'agreementEvaluateResult', null, '4', '2', '一般', '[admin]admin', '[admin]admin', '2016-03-15 19:51:10', '2016-03-15 19:51:10');
INSERT INTO `sys_param` VALUES ('e3965b13-5cca-4355-bf13-7aaa8dac8bcb', '已关闭', '1', 'securityEvaluateConfigurationStatus', '#5cb85c', '1', '2', '已关闭', 'admin/admin', 'admin/admin', '2016-12-08 11:22:42', '2016-04-14 11:30:37');
INSERT INTO `sys_param` VALUES ('e3989a0d-0ff2-41c2-8efe-ef20823afac2', '待提交', '0', 'lowvalueReceptionStatus', null, null, '1', null, null, null, null, null);
INSERT INTO `sys_param` VALUES ('e3ceb4a9-e957-40d2-bfec-e5d42d493f10', '调休', '8', 'vacationType', null, '8', '1', null, 'admin/admin', 'admin/admin', '2016-07-11 15:44:36', '2016-07-11 15:44:36');
INSERT INTO `sys_param` VALUES ('e3db5de8-28aa-4694-8793-a74fa737c906', '待评估', '0', 'accessEvaluateConfigurationStatus', '#d9534f', '1', '1', '待评估', '[admin]admin', 'admin/admin', '2016-12-08 10:23:12', '2016-01-21 18:59:44');
INSERT INTO `sys_param` VALUES ('e40e766d-209b-4a65-9ff8-406202dc7279', '项目完成', '2', 'exitReasonList', null, '2', '2', null, 'admin/admin', 'admin/admin', '2016-07-13 11:23:38', '2016-07-13 11:23:38');
INSERT INTO `sys_param` VALUES ('e4727ee7-7dc9-4e0a-ae16-c71a035a7439', '中等', 'ZD', 'severity', null, '3', '2', null, '[admin]admin', '[admin]admin', '2016-03-15 11:08:07', '2016-03-15 11:08:07');
INSERT INTO `sys_param` VALUES ('e4dd7eb7-3e36-4511-868e-89dd32e2c4d9', '已审批待维修', '3', 'assetRepairStatus', null, '3', '1', null, '[admin]admin', '[admin]admin', '2016-03-27 15:10:30', '2016-03-27 15:10:30');
INSERT INTO `sys_param` VALUES ('e542dc65-bead-4fa0-94ce-66cbb0d09d73', '门禁卡', '4', 'outsourcePersonConfig', null, '4', '2', null, 'admin/admin', '柳青青/BANK2000', '2016-09-01 20:19:36', '2016-07-13 16:07:05');
INSERT INTO `sys_param` VALUES ('e587317e-044e-4f7b-b3e4-cb302bbd290c', '应急培训', 'YJPX', 'trainType', null, '3', '2', null, '[admin]admin', '[admin]admin', '2016-01-20 10:09:48', '2016-01-20 10:09:48');
INSERT INTO `sys_param` VALUES ('e62ff1c5-c21b-4b3c-8399-41e6e796557a', '完全处理', 'all', 'faultHandleResult', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-02-29 12:20:00', '2016-02-29 12:20:00');
INSERT INTO `sys_param` VALUES ('e71e0069-7afd-451f-9cb1-f7825afa4752', '不紧急', 'low', 'faultUrgent', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-02-27 15:01:53', '2016-02-27 14:49:05');
INSERT INTO `sys_param` VALUES ('e77638bc-473b-11e6-ad17-fce33ca489b2', '驳回', '4', 'travelStatus', null, '4', '1', null, '[admin]admin', '[admin]admin', '2016-03-28 14:40:43', '2016-03-08 15:02:19');
INSERT INTO `sys_param` VALUES ('e7792899-473b-11e6-ad17-fce33ca489b2', '待提交', '1', 'travelStatus', null, '1', '1', null, '[admin]admin', '[admin]admin', '2016-03-08 15:01:40', '2016-03-08 15:01:40');
INSERT INTO `sys_param` VALUES ('e77c1d9f-473b-11e6-ad17-fce33ca489b2', '被终止', '6', 'travelStatus', null, '6', '1', null, 'admin/admin', 'admin/admin', '2016-05-19 20:12:18', '2016-05-19 20:12:18');
INSERT INTO `sys_param` VALUES ('e77f0246-473b-11e6-ad17-fce33ca489b2', '审批中', '3', 'travelStatus', null, '3', '1', null, '[admin]admin', '[admin]admin', '2016-03-28 17:10:00', '2016-03-08 15:02:05');
INSERT INTO `sys_param` VALUES ('e78191c8-473b-11e6-ad17-fce33ca489b2', '待审批', '2', 'travelStatus', null, '2', '1', null, '[admin]admin', 'admin/admin', '2016-05-05 19:01:54', '2016-03-08 15:01:52');
INSERT INTO `sys_param` VALUES ('e7844b43-473b-11e6-ad17-fce33ca489b2', '已完成', '5', 'travelStatus', null, '5', '1', null, '[admin]admin', '柳青青/BANK2000', '2016-10-25 11:25:05', '2016-03-28 17:10:13');
INSERT INTO `sys_param` VALUES ('e7899aa5-473b-11e6-ad17-fce33ca489b2', '驳回', '4', 'vacationStatus', null, '4', '1', null, '[admin]admin', '[admin]admin', '2016-03-28 14:40:43', '2016-03-08 15:02:19');
INSERT INTO `sys_param` VALUES ('e78bbe4b-473b-11e6-ad17-fce33ca489b2', '待提交', '1', 'vacationStatus', null, '1', '1', null, '[admin]admin', '[admin]admin', '2016-03-08 15:01:40', '2016-03-08 15:01:40');
INSERT INTO `sys_param` VALUES ('e78e1b3f-473b-11e6-ad17-fce33ca489b2', '被终止', '6', 'vacationStatus', null, '6', '1', null, 'admin/admin', 'admin/admin', '2016-05-19 20:12:18', '2016-05-19 20:12:18');
INSERT INTO `sys_param` VALUES ('e790c4e3-473b-11e6-ad17-fce33ca489b2', '审批中', '3', 'vacationStatus', null, '3', '1', null, '[admin]admin', '[admin]admin', '2016-03-28 17:10:00', '2016-03-08 15:02:05');
INSERT INTO `sys_param` VALUES ('e793745c-473b-11e6-ad17-fce33ca489b2', '待审批', '2', 'vacationStatus', null, '2', '1', null, '[admin]admin', 'admin/admin', '2016-05-05 19:01:54', '2016-03-08 15:01:52');
INSERT INTO `sys_param` VALUES ('e7973159-473b-11e6-ad17-fce33ca489b2', '已完成', '5', 'vacationStatus', null, '5', '1', null, '[admin]admin', '柳青青/BANK2000', '2016-10-25 11:25:26', '2016-03-28 17:10:13');
INSERT INTO `sys_param` VALUES ('e9b7358f-8b2f-4959-8851-1bbb4c422cf9', '跨境外包风险管理', '10', 'specialAudit', null, '10', '2', '跨境外包风险管理', '[admin]admin', '[admin]admin', '2016-02-24 11:21:14', '2016-02-24 10:50:17');
INSERT INTO `sys_param` VALUES ('e9be4ba9-87ba-4cba-9f0f-d364b90f0bcd', '跟踪', 'GZ', 'riskState', null, '1', '1', null, '[admin]admin', '[admin]admin', '2016-02-01 15:59:32', '2016-02-01 15:59:32');
INSERT INTO `sys_param` VALUES ('e9c1742d-b035-4c5f-bc1d-221a696aba68', '已使用', 'YSY', 'assetSparePartsUserStatus', null, '2', '1', null, 'admin/admin', 'admin/admin', '2016-05-12 12:26:58', '2016-05-12 12:26:58');
INSERT INTO `sys_param` VALUES ('e9c8e6c9-2078-4bc3-aa41-a4ee2e16e3ac', '离职', '4', 'recordType', null, '4', '1', null, '[admin]admin', '[admin]admin', '2016-02-23 17:34:18', '2016-02-23 17:34:18');
INSERT INTO `sys_param` VALUES ('e9d8be16-4924-4260-b3a6-e21c508fe08b', 'C', 'C', 'performanceResult', null, '3', '2', 'C', '[admin]admin', '[admin]admin', '2016-03-22 15:45:52', '2016-03-22 15:45:52');
INSERT INTO `sys_param` VALUES ('ea26ca66-05ee-492c-ac4a-73eb687902a5', '绩效', 'performance', 'templateConfigurationType', null, '7', '2', '绩效', '[admin]admin', '[admin]admin', '2016-01-12 16:44:57', '2016-01-12 16:35:58');
INSERT INTO `sys_param` VALUES ('ea337c78-4fea-45b7-97b9-40460f5da8bf', '被终止', '9', 'assetApplicationStatus', null, '9', '1', null, 'admin/admin', 'admin/admin', '2016-05-16 14:43:19', '2016-05-16 14:43:19');
INSERT INTO `sys_param` VALUES ('eaeee1f6-e1d7-46fc-85f9-294f4d0fb7f1', '法律纠纷', '2', 'supplierBlackReason', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-03-30 10:11:38', '2016-03-30 10:11:38');
INSERT INTO `sys_param` VALUES ('ebfa9784-a469-4a21-9ff2-cc92f308f0b0', '释放', 'release', 'LogOpType', null, '6', '1', null, 'admin/admin', 'admin/admin', '2016-05-04 15:42:24', '2016-05-04 15:42:24');
INSERT INTO `sys_param` VALUES ('ecda20d4-a357-48b5-9b17-a04508e56601', '行业监管外包商管理', '12', 'specialAudit', null, '12', '2', '行业监管外包商管理', '[admin]admin', '[admin]admin', '2016-02-24 11:21:14', '2016-02-24 10:50:37');
INSERT INTO `sys_param` VALUES ('ecea3b2a-f6c1-4746-95bb-431cde887b98', '技术故障', 'tech', 'faultType', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-02-27 15:01:27', '2016-02-27 14:47:56');
INSERT INTO `sys_param` VALUES ('ed0e31f8-fd09-41aa-8ee6-cf4984cfc693', 'R3', 'R3', 'riskLevel', null, '3', '2', null, '[admin]admin', '[admin]admin', '2016-01-12 17:15:23', '2016-01-12 17:15:23');
INSERT INTO `sys_param` VALUES ('ed12e7aa-4d69-4c94-8bcf-2a7d325b8c23', '服务质量监控', '1', 'serviceMonitoringType', null, '1', '2', '服务质量监控', '[admin]admin', '[admin]admin', '2016-03-03 10:41:53', '2016-03-03 10:41:53');
INSERT INTO `sys_param` VALUES ('ed70bb31-4fff-4d71-af81-458f81b16237', '被终止', '7', 'agreementCloseStatus', null, '7', '1', null, 'admin/admin', 'admin/admin', '2016-05-19 20:12:44', '2016-05-19 20:12:44');
INSERT INTO `sys_param` VALUES ('edcfe538-c5c2-40e2-ace0-b8be6bc46d3c', '人员外包类', 'RYWB', 'outsourceType', null, '1', '2', null, '[admin]admin', '[admin]admin', '2016-01-21 12:02:33', '2016-01-21 12:02:33');
INSERT INTO `sys_param` VALUES ('ede6e343-41e9-4c11-a356-e0fb51e98b1c', 'C', 'C', 'projectPerformanceResult', null, '3', '2', 'C', '[admin]admin', '[admin]admin', '2016-03-23 20:03:24', '2016-03-23 20:03:24');
INSERT INTO `sys_param` VALUES ('ee2290cb-8c66-43f6-98d7-9204dfb058e4', '服务合同', '6', 'recordType', null, '6', '1', null, '[admin]admin', '[admin]admin', '2016-02-23 17:34:44', '2016-02-23 17:34:44');
INSERT INTO `sys_param` VALUES ('ef0966d8-0662-4705-a85e-edb25ccf9b66', '审批中', '2', 'supplierQuitStatus', null, '2', '1', null, '[admin]admin', '[admin]admin', '2016-03-21 15:12:33', '2016-03-09 17:20:40');
INSERT INTO `sys_param` VALUES ('ef6616a4-10dc-4e0e-9a0c-dfa89d0d4580', '待提交', '1', 'recruitmentApplicationStatus', null, '2', '1', '', 'admin/admin', 'admin/admin', '2016-07-29 15:17:38', '2016-07-29 15:17:14');
INSERT INTO `sys_param` VALUES ('f14e7fa1-3f7c-43bd-aa69-c00c8fd0b695', '提交未确认', '1', 'assetsInventoryStatus', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-03-23 10:52:07', '2016-03-23 10:45:52');
INSERT INTO `sys_param` VALUES ('f173f0cf-ab2e-40c8-ae7d-27f5527546a8', '按年', '3', 'deductionsCycle', null, '3', '1', null, '[admin]admin', '[admin]admin', '2016-02-27 11:38:14', '2016-02-27 11:38:14');
INSERT INTO `sys_param` VALUES ('f1ccc4a8-c259-4fec-9dce-6581cedaf0c1', '非驻场外包风险管理', '11', 'specialAudit', null, '11', '2', '非驻场外包风险管理', '[admin]admin', '[admin]admin', '2016-02-24 11:21:14', '2016-02-24 10:50:27');
INSERT INTO `sys_param` VALUES ('f205263b-e37e-4c95-8a2f-af92494b7316', '确认中', '6', 'assetApplicationStatus', null, '6', '1', null, '[admin]admin', '[admin]admin', '2016-03-26 16:32:06', '2016-03-26 15:03:16');
INSERT INTO `sys_param` VALUES ('f22fb703-8dec-4ae5-8f59-5f955a458e05', '待审批', '2', 'supplierBlackListState', null, '2', '2', null, 'admin/admin', 'admin/admin', '2016-04-23 15:01:44', '2016-04-23 15:00:51');
INSERT INTO `sys_param` VALUES ('f29971db-243e-464d-b69b-3b4665048db0', '软件类', '2', 'agreementCategory', null, '2', '2', null, '[admin]admin', '[admin]admin', '2016-01-26 09:13:17', '2016-01-23 16:41:29');
INSERT INTO `sys_param` VALUES ('f42ac38c-b999-4308-b9bf-e596a5e961ca', '待审批', '1', 'assetRetirementStatus', null, '1', '1', null, '[101]刘宝安1', '[101]刘宝安1', '2016-03-28 16:41:53', '2016-03-28 16:41:53');
INSERT INTO `sys_param` VALUES ('f4d2b550-c27b-4772-8ce4-b6bad7a47e66', '已关闭', '2', 'accessEvaluateConfigurationStatus', '#5cb85c', '3', '1', '已关闭', '[admin]admin', 'admin/admin', '2016-12-07 17:48:24', '2016-01-21 19:00:27');
INSERT INTO `sys_param` VALUES ('f5d93a9d-e5bc-4745-afc9-663052444c85', '实施人员', '3', 'agreementTeamRole', null, '3', '2', null, 'admin/admin', 'admin/admin', '2016-05-04 16:24:18', '2016-05-04 16:24:18');
INSERT INTO `sys_param` VALUES ('f60bea50-99df-4f99-9a4f-ec8591acac2c', '应急配件', 'YJPJ', 'assetSparePartsType', null, '2', '1', null, 'admin/admin', 'admin/admin', '2016-05-12 12:26:31', '2016-05-12 12:26:31');
INSERT INTO `sys_param` VALUES ('f75c4b59-e26b-4952-9817-b31fbc3b4fa1', '外包服务安全管理', '6', 'specialAudit', null, '6', '2', '外包服务安全管理', '[admin]admin', '[admin]admin', '2016-02-24 11:21:14', '2016-02-24 10:49:32');
INSERT INTO `sys_param` VALUES ('f78cfe81-0db0-46e6-a39d-69d2a350f772', '婚假', '7', 'vacationType', null, '7', '1', null, 'admin/admin', 'admin/admin', '2016-07-11 15:44:25', '2016-07-11 15:44:25');
INSERT INTO `sys_param` VALUES ('f78e43ac-af37-4e7f-82cb-a5ffb672c4c3', '待通知', '4', 'personQuitStatus', null, '4', '1', null, 'admin/admin', 'admin/admin', '2016-07-19 11:26:42', '2016-07-14 11:47:42');
INSERT INTO `sys_param` VALUES ('f7e45ee0-6ab5-4722-ab3a-dc1ae14401f6', '黑名单', '3', 'recordType', null, '3', '1', null, '[admin]admin', '柳青青/BANK2000', '2016-08-29 11:00:03', '2016-02-23 17:33:54');
INSERT INTO `sys_param` VALUES ('f8970172-2149-4d01-8c29-5e5699bd9b0b', '弃权', '5', 'accessEvaluateResult', null, '5', '2', null, '孙明钱/BANK1029', '孙明钱/BANK1029', '2016-06-29 12:12:39', '2016-06-22 17:12:01');
INSERT INTO `sys_param` VALUES ('f8c9e7f8-fc11-446c-bff2-bac40ff2a5bd', '第三季度', '3', 'quarter', null, '3', '2', null, 'admin/admin', 'admin/admin', '2016-07-08 10:42:06', '2016-07-08 10:42:06');
INSERT INTO `sys_param` VALUES ('f98a9834-3a68-46af-82c3-a39987e105de', '驳回', '4', 'assetRetirementStatus', null, '4', '1', null, '[101]刘宝安1', '[101]刘宝安1', '2016-03-28 16:42:34', '2016-03-28 16:42:34');
INSERT INTO `sys_param` VALUES ('f9d9bbd1-f2c4-4ce7-bb32-a8d76063fa78', '采购+维保', '2', 'assetsAgreementType', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-03-23 12:18:57', '2016-03-23 12:18:57');
INSERT INTO `sys_param` VALUES ('fab48ab1-66ae-41f6-8dc4-e6a03e3f4fc0', '考核属性配置', '2', 'outsourcePersonConfig', null, '2', '1', '默认为“需要考核”，若需特殊配置，请进入外包人员列表页面进行修改', 'admin/admin', '柳青青/BANK2000', '2016-09-01 20:12:20', '2016-07-13 16:06:24');
INSERT INTO `sys_param` VALUES ('fab8b369-a7ba-48e5-8f49-68e884d07aeb', '维修中', '4', 'assetRepairStatus', null, '4', '1', null, '[admin]admin', '[admin]admin', '2016-03-27 15:10:45', '2016-03-27 15:10:45');
INSERT INTO `sys_param` VALUES ('faed1758-ef4f-43e1-9fb9-066e14f504bb', '个人', '1', 'performanceEvaluatorType', null, '1', '1', '个人', '[admin]admin', '[admin]admin', '2016-03-16 15:39:12', '2016-03-16 15:39:12');
INSERT INTO `sys_param` VALUES ('fb5fa9f5-ff35-4028-8171-d817e30d5900', '资产管理', 'zcgl', 'workflowType', null, '3', '1', null, '[admin]admin', '[admin]admin', '2016-02-01 17:26:41', '2016-02-01 17:26:41');
INSERT INTO `sys_param` VALUES ('fb87d360-404f-4c9e-9252-cdae55c67319', '差', 'bad', 'faultHandleAssess', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-02-29 12:19:15', '2016-02-29 12:19:15');
INSERT INTO `sys_param` VALUES ('fc8fb389-1699-4b8e-928f-0f4ef7cadbcb', '全行', 'all', 'faultImpact', null, null, '2', null, '[admin]admin', '[admin]admin', '2016-02-27 15:00:38', '2016-02-27 14:43:31');
INSERT INTO `sys_param` VALUES ('fd3dd5cb-6bf5-4259-aca7-3759e310f7f0', '待审批', '2', 'personExitStatus', null, '2', '1', null, 'admin/admin', 'admin/admin', '2016-07-14 11:44:36', '2016-07-14 11:44:36');
INSERT INTO `sys_param` VALUES ('fdbdc160-1eb8-4682-a6a4-6a14b52fbd9f', 'HP-UX', 'HP-UX', 'systemClass', null, '3', '2', null, '孙明钱/BANK1029', '孙明钱/BANK1029', '2016-06-23 11:18:47', '2016-06-23 11:18:47');
INSERT INTO `sys_param` VALUES ('fe3d1891-5565-471e-b957-6696b4ccef40', '供应商', '1', 'faultIssueType', null, null, '1', null, '[admin]admin', '[admin]admin', '2016-01-21 18:56:45', '2016-01-21 18:56:45');
INSERT INTO `sys_param` VALUES ('fe3fa54d-a7de-4dc6-9b01-882ab90c2363', '处理中', '2', 'recruitmentApplicationDetailStatus', null, '2', '1', '', 'admin/admin', 'admin/admin', '2016-08-01 10:28:23', '2016-08-01 10:28:23');
INSERT INTO `sys_param` VALUES ('ff4b4edb-1782-4a0b-8be6-d0b4a7ed9c80', '技术风险', 'JSFX', 'riskType', null, '2', '2', null, '[admin]admin', '[admin]admin', '2016-01-12 17:12:50', '2016-01-12 17:13:38');
INSERT INTO `sys_param` VALUES ('ffad3e81-49ba-4f21-90fe-e97910aa120f', '详情', 'operDetail', 'formOperationType', null, '3', '1', '查看详情', null, null, '2016-01-06 11:13:06', '2016-01-06 11:13:06');
INSERT INTO `sys_param` VALUES ('ffc35bad-b577-4da2-9abc-c25f30ada08b', '合同评价', 'agreementCategory', 'templateConfigurationType', null, '4', '2', '合同评价', '[admin]admin', '[admin]admin', '2016-03-15 19:42:29', '2016-01-12 16:35:14');
INSERT INTO `sys_param` VALUES ('ffe10998-8271-48b1-967f-528573a05750', '待评估', '0', 'accessEvaluateStatus', '#d9534f', '2', '1', '待评估', '[admin]admin', 'admin/admin', '2016-12-08 10:37:27', '2016-01-21 18:56:45');
INSERT INTO `sys_param` VALUES ('fff8319e-31cb-41e9-a933-3fec87a8d07b', '网络权限', '5', 'outsourcePersonConfig', null, '5', '2', null, 'admin/admin', '柳青青/BANK2000', '2016-09-01 20:19:40', '2016-07-13 16:07:15');


