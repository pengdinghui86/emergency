-- 邮件、短信、系统消息发送开关配置脚本 2016/11/16 10:25:39
insert into `sys_default_value` (`id`, `code`, `configType`, `value`) values('deb74dc2-5518-4d18-bcd0-c371ab0d5e71','msgType','msgConfigure','1,2,3');

-- 代办任务表字段过大 2016-11-21 15:42:49
ALTER TABLE `user_task`
DROP COLUMN `addType`,
DROP COLUMN `addContent`;

-- 新增文件管理操作权限
insert into sys_resource(`id`,`code`,`name`,`resourceType`,`longCode`,`longName`,`parentId`,`parentName`,`signature`,`createTime`)values
('2f875cf7-fb7a-4e5a-9816-76c7c329a415','6021701','创建文件夹','2','6!602!60217!6021701','系统管理!系统配置!文档管理!创建文件夹','8a1b0052-05c2-414d-9e14-e2e1db49c15b','文件管理','folder_add',NOW()),
('5dd50884-7e4e-4a90-b80d-6bb004d991df','6021702','编辑文件夹','2','6!602!60217!6021702','系统管理!系统配置!文档管理!编辑文件夹','8a1b0052-05c2-414d-9e14-e2e1db49c15b','文件管理','folder_update',NOW()),	
('bb7376c0-8131-4815-ab1f-2cf9f8be3a92','6021703','删除文件夹','2','6!602!60217!6021703','系统管理!系统配置!文档管理!删除文件夹','8a1b0052-05c2-414d-9e14-e2e1db49c15b','文件管理','folder_delete',NOW()),		
('ec3c763e-2406-4d14-9a87-8253b8a13226','6021704','上传文件','2','6!602!60217!6021704','系统管理!系统配置!文档管理!上传文件','8a1b0052-05c2-414d-9e14-e2e1db49c15b','文件管理','file_upload',NOW()),	
('f52f10fb-aa5c-4b8a-a337-30d33d493046','6021705','删除文件','2','6!602!60217!6021705','系统管理!系统配置!文档管理!删除文件','8a1b0052-05c2-414d-9e14-e2e1db49c15b','文件管理','file_delete',NOW()),		
('52d90f1a-dede-498d-9de4-3ed47df5de20','6021706','编辑文件','2','6!602!60217!6021706','系统管理!系统配置!文档管理!编辑文件','8a1b0052-05c2-414d-9e14-e2e1db49c15b','文件管理','file_update',NOW());		

