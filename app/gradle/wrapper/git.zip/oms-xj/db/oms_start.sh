#!/bin/bash
echo "--------start oms server------->>"
export JAVA_HOME=/escdata/jdk1.7.0_25
export PATH=$JAVA_HOME/bin:$PATH
export CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar
set JAVA_OPTS=-Xms512m -Xmx2048m -XX:PermSize=256m -XX:MaxPermSize=512m
java -version
java -jar oms.jar > /dev/null 2>&1 &