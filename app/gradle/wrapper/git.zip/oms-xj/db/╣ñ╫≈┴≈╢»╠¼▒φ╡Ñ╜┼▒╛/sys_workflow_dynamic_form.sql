
-- sys_workflow表中添加字段businessTable,用于关联业务记录
ALTER TABLE `sys_workflow`
ADD COLUMN `businessTable`  varchar(255) NULL COMMENT '关联业务表' AFTER `updateTime`;

update sys_workflow set businessTable = 'assets_material_repair_apply' where `code` = 'physical_asset_repairs';
update sys_workflow set businessTable = 'workhour_overtime' where `code` = 'outsource_manhour_overtime';
update sys_workflow set businessTable = 'relation_supplier_blacklist' where `code` = 'supplier_blacklist';
update sys_workflow set businessTable = 'assets_material_apply' where `code` = 'physical_asset_apply';
update sys_workflow set businessTable = 'outsourc_apply_quit_info' where `code` = 'outsource_person_dimission';
update sys_workflow set businessTable = 'workhour_vacation' where `code` = 'outsource_manhour_leave';
update sys_workflow set businessTable = 'workhour_travel' where `code` = 'outsource_manhour_on_business';
update sys_workflow set businessTable = 'assets_lowvalue_apply' where `code` = 'lowvalue_asset_apply';
update sys_workflow set businessTable = 'outsourc_apply_exit_info' where `code` = 'outsource_person_exit';
update sys_workflow set businessTable = 'agreement_close' where `code` = 'supplier_agreement_close';
update sys_workflow set businessTable = 'supplier_quit' where `code` = 'supplier_quit';
update sys_workflow set businessTable = 'outsourc_apply_enter_info' where `code` = 'outsource_person_enter';
update sys_workflow set businessTable = 'agreement_change' where `code` = 'supplier_agreement_change';
update sys_workflow set businessTable = 'assets_material_repair_scrap' where `code` = 'physical_asset_scrap';
update sys_workflow set businessTable = 'recruitment_application' where `code` = 'outsource_person_recruitment';


-- sys_workflow_step表添加字段formIds,用于关联sys_workflow_form_config表记录
ALTER TABLE `sys_workflow_step`
ADD COLUMN `formIds` text NULL COMMENT '表单配置id' AFTER `messageType`;


-- ----------------------------
-- Table structure for sys_workflow_form_config
-- ----------------------------
DROP TABLE IF EXISTS `sys_workflow_form_config`;
CREATE TABLE `sys_workflow_form_config` (
  `id` char(108) NOT NULL,
  `associated` varchar(8) DEFAULT NULL COMMENT '是否关联业务字段',
  `attId` varchar(64) DEFAULT NULL COMMENT '模型属性ID',
  `attName` varchar(320) DEFAULT NULL COMMENT '名称',
  `valueType` varchar(64) DEFAULT NULL COMMENT '值类型；字符型 整型 日期() 时间() 枚举型 数组',
  `maxlength` varchar(64) DEFAULT NULL COMMENT '最大长度',
  `defaultValue` varchar(64) DEFAULT NULL COMMENT '默认值',
  `notNull` varchar(8) DEFAULT NULL COMMENT '必填：1 是  0 否',
  `readOnly` varchar(8) DEFAULT NULL COMMENT '只读：1 是  0 否',
  `isOnly` varchar(8) DEFAULT NULL COMMENT '唯一：1 是  0 否',
  `sort` varchar(32) DEFAULT NULL COMMENT '排序',
  `dict` varchar(32) DEFAULT NULL COMMENT '是否用数据字典',
  `minFigure` varchar(32) DEFAULT NULL COMMENT '数值最小位数',
  `maxFigure` varchar(32) DEFAULT NULL COMMENT '数值最大位数',
  `place` varchar(32) DEFAULT NULL COMMENT '小数点位数',
  `createUser` varchar(200) DEFAULT NULL,
  `updateUser` varchar(200) DEFAULT NULL,
  `updateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `createTime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='工作流动态表配置';


-- ----------------------------
-- Table structure for sys_workflow_form_value
-- ----------------------------
DROP TABLE IF EXISTS `sys_workflow_form_value`;
CREATE TABLE `sys_workflow_form_value` (
  `id` char(36) NOT NULL,
  `instanceId` char(36) DEFAULT NULL,
  `formId` char(36) DEFAULT NULL,
  `auditId` char(36) DEFAULT NULL,
  `nodeName` varchar(255) DEFAULT NULL,
  `type` varchar(64) DEFAULT NULL,
  `dict` varchar(32) DEFAULT NULL,
  `attName` varchar(255) DEFAULT NULL,
  `attValue` varchar(255) DEFAULT NULL,
  `createUser` varchar(255) DEFAULT NULL,
  `createTime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='工作流动态表单值';